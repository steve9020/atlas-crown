const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const required = [
  'runtime/compass/VOICE_CADENCE_VALIDATION_RULES.json',
  'runtime/compass/VOICE_CADENCE_VALIDATION_RULES.md',
  'runtime/compass/VoiceCadenceValidationRules.js',
  'runtime/proof/MASTERSTEP55_VOICE_CADENCE_VALIDATION_RULES.md',
  'runtime/proof/MASTERSTEP55_TEST_RESULTS.md',
  'docs/MASTERSTEP55_VOICE_CADENCE_VALIDATION_RULES_MAP.md'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(root, rel)), 'missing ' + rel);
const proof = fs.readFileSync(path.join(root, 'runtime/proof/MASTERSTEP55_VOICE_CADENCE_VALIDATION_RULES.md'), 'utf8');
assert.ok(proof.includes('CLOSED — CURRENT KEEPER'));
assert.ok(proof.includes('backend-owned voice and cadence validation'));
const frontendFiles = [];
function walk(dir){
  for (const name of fs.readdirSync(dir)) {
    const p = path.join(dir, name);
    const st = fs.statSync(p);
    if (st.isDirectory()) walk(p); else frontendFiles.push(p);
  }
}
const plugin = path.join(root, 'CA/Continuity_Architecture/.obsidian/plugins/continuity-interface');
if (fs.existsSync(plugin)) walk(plugin);
for (const file of frontendFiles) {
  const rel = path.relative(root, file);
  const txt = fs.readFileSync(file, 'utf8');
  assert.ok(!/Doyle|semantic attachment|route scorer|response generation|Teaching Center logic|AI containment logic/i.test(txt), 'frontend intelligence residue in ' + rel);
}
console.log('masterStep55FullClosureKeeperReadinessTest PASSED');
