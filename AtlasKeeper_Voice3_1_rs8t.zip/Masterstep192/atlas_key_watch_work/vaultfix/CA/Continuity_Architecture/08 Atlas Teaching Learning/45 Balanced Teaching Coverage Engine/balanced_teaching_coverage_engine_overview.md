# Balanced Teaching Coverage Engine Overview

## Purpose
This engine makes sure auto teaching does not over-train one emotional family while neglecting others.

The goal is balanced learning across all scenario categories.

## Core Rule
Atlas should not only rotate categories. It should track coverage and intentionally fill missing teaching areas.

## What Balanced Teaching Prevents
- overusing the same category
- overusing the same emotional family
- neglecting rare categories
- creating biased teaching data
- missing weak points in untested areas
- overfitting to relationship/self-worth prompts only

## Runtime Flow
Scenario categories → coverage tracking → neglected category detection → balanced batch selection → auto teaching run → history update → coverage report.

## Boundary
Balanced teaching changes what gets tested next. It does not bypass proposal review or implementation approval.
