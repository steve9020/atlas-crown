# Proposal Quality Scoring Registry

## Scoring Dimensions
- required field completeness
- specificity
- usefulness
- target backend accuracy
- integration draft strength
- frontend lightness compatibility
- governance safety
- overfitting risk
- duplication / merge risk

## Score Bands
- 85–100: ready for review
- 68–84: review with caution
- 45–67: defer or revise
- below 45: hold / do not review

## Rule
Low-quality proposals should be held instead of crowding review.
