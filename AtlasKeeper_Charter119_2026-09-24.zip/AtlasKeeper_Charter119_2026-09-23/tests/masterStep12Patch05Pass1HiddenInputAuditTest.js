const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function walk(dir){
  let out=[];
  for(const e of fs.readdirSync(dir,{withFileTypes:true})){
    const p=path.join(dir,e.name);
    if(e.isDirectory()) out=out.concat(walk(p)); else out.push(p);
  }
  return out;
}
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const audit = json('runtime/governance/NO_HIDDEN_INPUT_BYPASS_AUDIT.json');
assert(audit.status === 'pass1_staged', 'audit status mismatch');
for (const key of ['hidden_write_path','silent_mutation_path','governance_self_promotion_path','approval_bypass_path','external_bridge_expansion','rollback_bypass_path','traceability_bypass_path','secret_prompt_or_hidden_instruction']) {
  assert(audit.non_approvable_blocked_classes.includes(key), `missing blocked class ${key}`);
}
assert(audit.rule.includes('blocked, logged, and surfaced as prevented'), 'blocked/logged/surfaced rule missing');
assert(audit.human_approval_boundary.includes('must not convert structurally blocked bypass classes'), 'human approval boundary missing');
const proofState = json('runtime/proof/PROOF_STATE.json');
assert(proofState.hidden_input_audit_layer_added === true, 'hidden input audit flag missing');
assert(proofState.bypass_write_path_audit_layer_added === true, 'bypass write path audit flag missing');
assert(proofState.governance_self_promotion_audit_added === true, 'self-promotion audit flag missing');
assert(proofState.silent_mutation_path_audit_added === true, 'silent mutation audit flag missing');
assert(proofState.approval_bypass_audit_added === true, 'approval bypass audit flag missing');
assert(proofState.bypass_capable_actions_non_approvable === true, 'non-approvable bypass flag missing');
const forbiddenActiveAllows = [
  'allow_hidden_write_path: true',
  'allow_silent_mutation_path: true',
  'allow_governance_self_promotion: true',
  'allow_approval_bypass: true',
  'governance_can_self_promote: true',
  'hidden_input_enabled: true',
  'secret_prompt_enabled: true'
];
for (const file of walk(root)) {
  if (!/\.(js|json|md)$/i.test(file)) continue;
  const rel=path.relative(root,file).replace(/\\/g,'/');
  const txt=fs.readFileSync(file,'utf8');
  for (const pattern of forbiddenActiveAllows) {
    if (!rel.includes('masterStep12Patch05')) {
    assert(!txt.includes(pattern), `forbidden active allow pattern ${pattern} in ${rel}`);
    }
  }
}
console.log('masterStep12Patch05Pass1HiddenInputAuditTest PASSED');
