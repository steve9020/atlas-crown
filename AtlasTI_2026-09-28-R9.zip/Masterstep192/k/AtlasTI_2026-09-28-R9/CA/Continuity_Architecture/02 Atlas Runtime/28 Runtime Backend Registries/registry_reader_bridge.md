---
title: Registry Reader Bridge
runtime_layer: runtime_bridge
priority: highest
status: active
phase: registry_reader_bridge_foundation
governed_by:
  - runtime_backend_registries_overview
  - runtime_registry_flow
  - governance_enforcement_registry
outputs:
  - runtime_signal_registry
  - depth_routing_registry
  - node_bucket_classification_registry
  - runtime_weighting_registry
  - runtime_link_resolution_registry
  - response_behavior_registry
---

# Registry Reader Bridge

## Purpose

This node defines the transition from hardcoded plugin bridge logic into vault-defined runtime behavior.

The plugin should remain an interface, parser, graph builder, runtime reader, and renderer.

The vault should remain the backend source of truth.

## Core Rule

The plugin may execute runtime behavior, but it should read backend rules from the vault whenever those rules involve meaning, routing, weighting, governance, link resolution, or response behavior.

The plugin should not permanently own the intelligence.

## What the Plugin May Do

The plugin may:

- scan markdown files
- parse frontmatter
- parse headings
- parse related runtime links
- build the runtime graph
- detect unresolved links
- display runtime debug output
- render Compass responses
- execute vault-defined routing rules

## What the Plugin Should Not Permanently Own

The plugin should not permanently define:

- signal groups
- depth routing rules
- node bucket rules
- runtime weighting rules
- governance behavior
- alias mappings
- response behavior
- frontend interpretation logic

Those belong in backend registry nodes.

## Registry Reading Order

The plugin should eventually read backend registries in this order:

1. runtime_backend_registries_overview
2. runtime_signal_registry
3. depth_routing_registry
4. node_bucket_classification_registry
5. runtime_weighting_registry
6. runtime_link_resolution_registry
7. governance_enforcement_registry
8. response_behavior_registry
9. runtime_registry_flow

## Bridge Function

The bridge allows temporary plugin logic to remain active while backend registries are being connected.

Temporary plugin logic is allowed only when:

- the matching backend registry already exists
- the logic is visibly marked as bridge behavior
- the long-term goal is to replace it with vault-read behavior
- it does not contradict backend governance

## Runtime Execution Direction

The next implementation direction is:

1. plugin locates backend registry nodes
2. plugin parses registry sections
3. plugin extracts signal groups
4. plugin extracts depth routing rules
5. plugin extracts bucket definitions
6. plugin extracts weighting principles
7. plugin extracts link resolution rules
8. plugin extracts response behavior rules
9. plugin uses backend registry content to shape runtime behavior

## Safety of This Bridge

The bridge must not turn the plugin into a hidden backend.

If a rule affects meaning, interpretation, response depth, governance, or user-facing clarity, the vault must contain the rule.

The plugin should only operationalize what the vault defines.

## Current Status

- backend registry layer exists
- graph links are resolved
- unresolved links are cleared
- plugin reads vault nodes
- plugin activates runtime buckets
- next step is controlled registry reading

## Related Runtime Links

- [[runtime_backend_registries_overview]]
- [[runtime_registry_flow]]
- [[runtime_signal_registry]]
- [[depth_routing_registry]]
- [[node_bucket_classification_registry]]
- [[runtime_weighting_registry]]
- [[runtime_link_resolution_registry]]
- [[governance_enforcement_registry]]
- [[response_behavior_registry]]