# Auto Teaching Debug Clutter Reduction

## Purpose
This node defines the debug cleanup required for a readable runtime console.

## Rule
The console should show:
- runtime graph summary
- backend registry count
- true unresolved runtime links
- critical warnings

The console should suppress:
- alias repair folder noise
- report-file link examples
- repeated non-critical broken-link examples
- full graph dumps unless debugging is explicitly needed
