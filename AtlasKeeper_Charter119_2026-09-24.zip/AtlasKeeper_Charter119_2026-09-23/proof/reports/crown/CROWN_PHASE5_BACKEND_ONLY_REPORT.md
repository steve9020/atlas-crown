# Crown Phase 5 — Lineage / Equivalence / Canonical Authority
Backend-only implementation. Adds directed scoped equivalence, conflict freeze, explicit canonical supersession, root epochs, and outside-anchor correspondence. Deterministic witness: `tests/crownPhase5LineageAuthorityTest.js`.
