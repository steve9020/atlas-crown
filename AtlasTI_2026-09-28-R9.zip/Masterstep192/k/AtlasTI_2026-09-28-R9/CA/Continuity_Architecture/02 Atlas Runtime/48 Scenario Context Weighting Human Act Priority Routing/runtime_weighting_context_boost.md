# Runtime Weighting Context Boost

## Purpose
This node defines runtime weighting boosts for scenario-specific interpretation.

## Boosts
- childhood trauma / abandonment context: +100
- human act explicitly named: +90
- vulnerability mishandled: +88
- boundary/respect pressure: +86
- self-worth attachment: +84
- relational inconsistency: +88
- protective monitoring/overthinking: +78
- practical low-depth context: +35

## Runtime Rule
Strong context signals should boost scenario-object and human-act routing above generic emotional processing.

## Result
Compass should become more precise without becoming heavier.
