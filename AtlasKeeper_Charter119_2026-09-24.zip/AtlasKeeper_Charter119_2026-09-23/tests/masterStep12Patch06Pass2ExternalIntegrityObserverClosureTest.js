const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const observer=json('runtime/governance/EXTERNAL_INTEGRITY_OBSERVER_LAYER.json');
assert(observer.status === 'closed_current_integrity_observer', 'observer should be closed current integrity observer');
assert(observer.closure_status === 'masterstep12_patch06_closed', 'observer closure status mismatch');
assert(observer.current_keeper === 'Masterstep12_patch06.zip', 'observer current keeper mismatch');
assert(observer.pass2_closure_verified === true, 'observer pass2 closure not verified');
assert(observer.fuzz_closure_verified === true, 'observer fuzz closure not verified');
assert(observer.scan_clean_hygiene_verified === true, 'observer scan clean not verified');
const imm = observer.immutability_verification || {};
for (const key of ['runtime_cannot_mutate_observer','observer_cannot_promote','observer_cannot_govern','observer_cannot_interpret','observer_cannot_own_truth','observer_cannot_self_modify','observer_only_flags_logs_holds_surfaces_requires_human_review']) {
  assert(imm[key] === true, `missing immutability verification ${key}`);
}
const ps=json('runtime/proof/PROOF_STATE.json');
assert(ps.masterstep12_patch06_closed === true, 'proof state patch06 closure missing');
assert(ps.patch06_pass2_closure_completed === true, 'patch06 pass2 closure missing');
assert(ps.external_integrity_observer_layer_closed === true, 'observer closed flag missing');
assert(ps.external_integrity_observer_layer_staged === false, 'observer staged flag should be false after closure');
console.log('masterStep12Patch06Pass2ExternalIntegrityObserverClosureTest PASSED');
