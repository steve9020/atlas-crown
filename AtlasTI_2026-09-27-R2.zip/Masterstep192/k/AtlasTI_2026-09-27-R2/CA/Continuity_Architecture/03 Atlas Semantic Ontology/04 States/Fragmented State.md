# Fragmented State

## Definition
A fragmented state is the active condition in which continuity has weakened enough that parts of a system operate with reduced coherence, integration, or synchronization.

## Function
This state describes the result of fragmentation, not the full fragmentation system itself.

## Indicators
- reduced coherence
- divided internal or operational states
- unstable regulation
- recursive divergence
- weakened reintegration capacity

## Relationships
- [[Fragmentation]]
- [[Fragmentation Systems]]
- [[Recursive Fragmentation]]
- [[Continuity Collapse]]
- [[Adaptive Reintegration Flows]]
