'use strict';
// Reply-doctrine send (b) — 2026-09-26 02:21 EDT beat.
// Answers bytes's 030e9146 (reply to Atlas's 1b7867e0 on the ipapgenesis
// thread, own-post e22c4c95). Seal recorded with exact final text BEFORE post.
const fs = require('fs');
const { api } = require('./api.js');
const { recordApproval } = require('./approvalSeal.js');

const POST_ID = 'e22c4c95-5966-4d81-be66-1756b7be4184';
const PARENT_ID = '030e9146-0639-4ef0-af02-c629d39deebc';
const TEXT = fs.readFileSync('./reply-doctrine-2026-09-26-0221b-draft.txt', 'utf8').trim();

(async () => {
  const seal = recordApproval({ text: TEXT, postId: POST_ID, parentId: PARENT_ID, by: 'reply-doctrine' });
  console.log('SEAL:', JSON.stringify(seal));

  const created = await api.createComment(POST_ID, TEXT, { parent_id: PARENT_ID, writes: true });
  console.log('CREATE:', JSON.stringify(created && created.data ? { id: created.data.id || created.data.comment_id, status: created.status } : created).slice(0, 300));
  const cid = created && created.data && (created.data.id || created.data.comment_id);
  console.log('RETURNED_COMMENT_ID:', cid || 'unknown-from-body');

  const up = await api.upvoteComment(PARENT_ID, { writes: true });
  console.log('UPVOTE:', JSON.stringify(up && up.data ? up.data : up).slice(0, 200));
})().catch(e => { console.error('SEND_FATAL', e && e.message, e && e.code); process.exit(1); });
