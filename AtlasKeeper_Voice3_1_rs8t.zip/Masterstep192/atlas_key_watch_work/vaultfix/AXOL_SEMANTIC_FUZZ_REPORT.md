# AXOL Semantic Fuzz Report

Scope: backend-only AxisEngine / axis registry maturation.

## Baseline
First unfamiliar-paraphrase run: 5/36 intended axes detected. This demonstrated that the first expansion remained strongly phrase-bound.

## Repair
Added registry-owned regex structural cues and AxisEngine support for evaluating those cues while preserving the existing `axes`, `dominant_axis`, `patterns`, and additive `axis_evidence` contract. No frontend, Crown authority, governance authority, or routing authority was changed.

## Retest
- Primary unfamiliar paraphrase set: 36/36 intended axes detected.
- Second unseen paraphrase set: initially 21/24; three misses exposed responsibility, comparison, and belonging breadth gaps.
- Narrow systemic cue expansion: second set 24/24.
- Neutral controls remained clean except explicit temporal language (`last year`), which correctly activates `temporal_scope` under the registry's definition.
- Existing `obsidianAxisRegistryTest.js`: PASS.
- Canonical proof contract: 100/100 PASS.

## Boundary
This closes the tested semantic-fuzz set. It does not establish infinite language understanding or exhaustive semantic coverage. Further unfamiliar-language fuzzing remains appropriate before calling AXOL coverage mature.
