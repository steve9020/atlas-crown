const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const hist=json('runtime/proof/HISTORICAL_KEEPER_INDEX.json');
assert(hist.mode === 'historical_integrity_not_current_state', 'historical mode mismatch');
assert(hist.active_keeper === 'Masterstep12_patch05.zip', 'historical index active keeper mismatch');
const required=['masterstep07','masterstep08','masterstep09','masterstep10','masterstep11','masterstep12','masterstep12_patch01','masterstep12_patch02','masterstep12_patch03','masterstep12_patch04','masterstep12_patch05_pass1','masterstep12_patch05'];
for (const key of required) {
  assert(hist.records[key], `missing historical record ${key}`);
  assert(hist.records[key].package || hist.records[key].snapshot, `missing package/snapshot for ${key}`);
}
const vs=json('tests/VERSION_STATUS.json');
for (const key of required.filter(k=>k!=='masterstep12_patch05')) {
  assert(vs.prior_keeper_history[key] || hist.records[key], `missing carry-forward reference ${key}`);
}
const carried=read('CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/PROOF_OF_WORK_CARRIED_FORWARD_INDEX.md');
assert(carried.includes('CURRENT STATE — READ FIRST'), 'carried index not current-first');
assert(carried.includes('Masterstep12_patch05.zip'), 'carried index missing current keeper');
assert(carried.includes('HISTORICAL_KEEPER_INDEX.json'), 'carried index missing historical pointer');
console.log('masterStep12Patch05HistoricalIntegrityCarryForwardTest PASSED');
