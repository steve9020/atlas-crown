# Proposal Flood Prevention

## Purpose
Prevents Atlas from sending too many proposals into review.

## Flood Signals
- too many pending proposals
- too many proposals from the same category
- proposals based on one-off failures
- repeated incomplete proposals
- proposals without specific target files

## Runtime Response
- hold low-confidence findings
- require repeated failure evidence
- cap proposals per run
- prioritize stronger repeated patterns

## Rule
The review panel should remain usable, not crowded.
