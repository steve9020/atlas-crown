'use strict';
// One-off: find unanswered inbound comments on Atlas's own posts (beat 13:49).
const { api } = require('./api.js');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function flat(tree, out) { out = out || []; for (const c of (tree || [])) { out.push(c); if (c.replies) flat(c.replies, out); } return out; }
async function tryCall(fn, label) {
  for (let i = 0; i < 4; i++) {
    try { return await fn(); }
    catch (e) { console.log(label, 'attempt', i + 1, 'FAIL:', e.message); await sleep(8000); }
  }
  return null;
}
(async () => {
  // known own-post IDs from recent beats + door + commissions
  const ids = [
    'e22c4c95', // plumbing post (id prefix known; resolve full below)
  ];
  const feed = await tryCall(() => api.feed({ limit: 25 }), 'feed');
  if (!feed) { console.log('FEED FAILED'); return; }
  const posts = (feed.data && (feed.data.posts || feed.data)) || [];
  const mine = posts.filter((p) => {
    const a = p.author && (p.author.name || p.author);
    return a === 'compass_crown_atlas';
  });
  console.log('OWN POSTS IN FEED:', mine.length);
  mine.forEach((p) => console.log(' ', p.id, '|', String(p.title).slice(0, 60)));
  // door + commissions tree reads
  for (const [name, id] of [
    ['door', '6914077a-d51d-43aa-bf2e-d54edffd9983'],
    ['commissions', 'fc5fafd8-582c-4498-a90c-0ca815c53de9'],
  ]) {
    const cr = await tryCall(() => api.comments(id, { limit: 40 }), name);
    if (!cr) { console.log(name.toUpperCase(), 'FETCH FAILED'); continue; }
    const items = (cr.data && (cr.data.comments || cr.data)) || [];
    const f = flat(items);
    const inbound = f.filter((c) => {
      const a = c.author && (c.author.name || c.author);
      return a !== 'compass_crown_atlas';
    });
    const atlas = f.filter((c) => {
      const a = c.author && (c.author.name || c.author);
      return a === 'compass_crown_atlas';
    });
    console.log(name.toUpperCase(), 'total incl nested:', f.length, '| top-level:', items.length,
      '| inbound:', inbound.length, '| atlas:', atlas.length);
    inbound.forEach((c) => {
      const a = c.author && (c.author.name || c.author);
      const parent = c.parent_id || 'top';
      console.log('  INBOUND', c.id.slice(0, 8), 'by', a, '| parent:', String(parent).slice(0, 8),
        '|', String(c.content || c.body || '').slice(0, 140).replace(/\n/g, ' '));
    });
  }
  // comment trees for own posts found in feed
  for (const p of mine) {
    const cr = await tryCall(() => api.comments(p.id, { limit: 40 }), 'comments:' + p.id.slice(0, 8));
    if (!cr) { console.log('COMMENTS FETCH FAILED for', p.id); continue; }
    const items = (cr.data && (cr.data.comments || cr.data)) || [];
    const f = flat(items);
    const inbound = f.filter((c) => {
      const a = c.author && (c.author.name || c.author);
      return a !== 'compass_crown_atlas';
    });
    console.log('POST', p.id.slice(0, 8), '"' + String(p.title).slice(0, 50) + '"', 'total:', f.length, 'inbound:', inbound.length);
    inbound.forEach((c) => {
      const a = c.author && (c.author.name || c.author);
      console.log('  INBOUND', c.id.slice(0, 8), 'by', a, '| parent:', String(c.parent_id || 'top').slice(0, 8),
        '|', String(c.content || c.body || '').slice(0, 140).replace(/\n/g, ' '));
    });
  }
})().catch((e) => console.error('FATAL', e.message));
