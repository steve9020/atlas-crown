# Doyle Layer 6 — Separation + Reverse-Flow Restoration

Layer 6 defines what needs to separate and what positive/restorative direction the response should move toward.

Rule: Reverse-flow must move toward named restorative positives, not merely reduce the negative.

## L6S01 — Event / Meaning Separation

Separates what happened from what the event starts meaning before enough support exists.

Separates: event, attached meaning, final conclusion

Reverse-flow targets: grounded perspective, room to think, continuity, steadiness

## L6S02 — Pressure / Ability Separation

Separates pressure from ability so stress, pileup, or shutdown is not treated as incapability.

Separates: pressure, stress response, ability

Reverse-flow targets: agency, workable movement, confidence, self-trust

## L6S03 — Emotion / Conclusion Separation

Separates a real emotion from the conclusion it is trying to become.

Separates: emotion, interpretation, conclusion

Reverse-flow targets: self-trust, steadiness, emotional room, choice

## L6S04 — Silence / Rejection Separation

Separates silence, delay, or absence from confirmed rejection.

Separates: silence, uncertainty, rejection conclusion

Reverse-flow targets: patience, self-trust, connection to self, steady waiting

## L6S05 — Boundary / Guilt Separation

Separates guilt from the need for limits, self-preservation, and respect.

Separates: guilt, boundary need, respect/self-preservation

Reverse-flow targets: clean responsibility, self-respect, protection, steady limits

## L6S06 — Mistake / Identity Separation

Separates what happened or what was said from who the person is.

Separates: mistake, embarrassment/shame, identity

Reverse-flow targets: dignity, repair, self-respect, continuity

## L6S07 — Anger / Action Separation

Separates anger from uncontrolled action while preserving anger as a signal of boundary, disrespect, or injustice.

Separates: anger, signal, reaction/action

Reverse-flow targets: respect, controlled action, protection, clear boundary

## L6S08 — Fear / Prediction Separation

Separates fear from certainty about what will happen.

Separates: fear, prediction, confirmed reality

Reverse-flow targets: courage, grounded choice, steadiness, trust in next step

## L6S09 — Loss / Worth Separation

Separates someone leaving, distance, or loss from the person's worth.

Separates: loss, absence/leaving, worth

Reverse-flow targets: worth, belonging, continuity, self-recognition

## L6S10 — Stress / Permanence Separation

Separates a stressful state from the belief that it is permanent or impossible to move through.

Separates: stress, current heaviness, permanence/finality

Reverse-flow targets: relief, workable sections, hope, movement

## L6S11 — Responsibility / Self-Erasure Separation

Separates responsibility/care from losing oneself to meet demands.

Separates: responsibility, care, self-erasure

Reverse-flow targets: clean responsibility, balance, self-respect, sustainable care

## L6S12 — Comparison / Value Separation

Separates comparison, visibility, or social measurement from personal value and pace.

Separates: comparison, measurement, value

Reverse-flow targets: self-recognition, personal pace, confidence, dignity

