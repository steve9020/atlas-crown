# Masterstep155 — Community Demo Harness + Evidence Pack

## Purpose

Masterstep155 turns the Step154 community-review readiness packet into a bounded community demo harness with an evidence pack. It gives reviewers a clean sequence to inspect without turning Atlas into a public product, exposing private internals, or expanding runtime authority.

## What changed

- Added `runtime/review/CommunityDemoHarnessEvidencePack.js`.
- Added a bounded demo run order.
- Added evidence categories for candidate-only model assistance, Compass meaning preservation, unsafe assistance refusal, and proof-chain keeper discipline.
- Added a shareable evidence index.
- Preserved do-not-share defaults from Step154.
- Added a claim-boundary statement checked by the matured Claim Boundary Scanner.

## Demo harness order

1. Open the community review readiness packet.
2. Run `node proof/runCurrentProof.js` locally.
3. Show one normal reflective prompt.
4. Show one mixed-context prompt.
5. Show one positive-state vulnerability prompt.
6. Show unsafe assistance refusals.
7. Invite bounded feedback on clarity, safety boundaries, reviewability, and missing evidence.

## Evidence surfaces

- Governed candidate-only assistance path.
- Compass meaning-preservation examples.
- Unsafe assistance refusal examples.
- Keeper chain and proof-count evidence.

## Claim boundary

Atlas/Compass is a governed local proof-of-work demo for bounded review. It is not production-ready, not clinically validated, not crisis-care tooling, not public release ready, and not autonomous deployment ready. The demo does not claim outside endorsement, general AI safety, therapeutic authority, or model authority. Raw model output is not final; candidate material remains below Atlas validation, quality, governance, and trace.

## Boundary preservation

Demo harness only. Evidence pack only. No runtime behavior change. No Compass output behavior change. No safety behavior change. No new matrix capability. No model authority. No frontend intelligence. No cloud/provider fallback. No silent learning. No silent mutation. Raw model output is not final.
