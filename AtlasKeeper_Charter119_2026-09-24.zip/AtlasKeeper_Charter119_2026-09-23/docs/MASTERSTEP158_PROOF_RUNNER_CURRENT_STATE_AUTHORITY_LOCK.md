# Masterstep158 — Proof Runner Current-State Authority Lock

## Purpose

Stop the proof system from getting hung up on previous package callouts. The active proof manifest must now be derived from the current proof state and cross-checked against version status, proof compatibility registry, and the proof runner command count.

## Direct repair

- Added `runtime/proof/CurrentProofTargetAuthority.js`.
- Updated `proof/runCurrentProof.js` so the manifest path is resolved from the current proof target.
- Added a proof test that fails if stale previous-step manifest callouts remain active inside the proof runner.
- Updated older proof tests so historical manifest markers are recognized through historical marker files, not by forcing stale strings to remain in the active runner.

## Boundary

This is proof infrastructure only. It does not change runtime behavior, Compass output behavior, safety behavior, matrix capability, model authority, frontend behavior, cloud/provider behavior, learning, or mutation.
