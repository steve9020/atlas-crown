# Before / After Retest Registry

## Purpose
After implementation, Atlas should retest the same scenario to verify whether the approved correction improved Compass output.

## Flow
1. Save original prompt and response.
2. Implement approved proposal.
3. Reload runtime.
4. Run the same prompt again.
5. Compare before/after response quality.
6. Mark improvement, no change, or regression.

## Rule
Implementation should create a retest plan automatically.
