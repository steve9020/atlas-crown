# Masterstep118 — Candidate Use Case Selection Gate

Package: Masterstep118.zip  
Source keeper: Masterstep117.zip  
Expected proof result: 40/40 passed

## Summary

Masterstep118 selects the first controlled local model expansion use case: **Compass candidate phrasing refinement**.

This is not a live integration step. It is a selection gate that keeps expansion narrow before any runtime wiring occurs.

## Why this step exists

Masterstep117 created the permission boundary for controlled local model expansion. Masterstep118 chooses the first use case inside that boundary so the next step cannot drift into broad model use.

## Selected use case

The first use case is bounded Compass candidate phrasing refinement: local model assistance may later be used only to suggest candidate wording polish after Atlas has already produced the governed meaning, route, and response direction.

## Required containment

Any later implementation must keep:
- local model output candidate-only
- raw model output not final
- validation before candidate path
- quality review before output
- governance review before output
- trace logging
- fail-closed behavior if local runner is unavailable

## Exclusions

This step does not add runtime integration, model-use expansion, model authority, teaching approval by model, ontology/governance/proof/runtime writes by model, cloud/provider fallback, public network binding, frontend intelligence, silent learning, or silent mutation.
