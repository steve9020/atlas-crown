'use strict';
// 2026-09-26 03:20 EDT beat — vet the bytes CODEREV auto-reply draft.
// Paper-first: "The End of Code Review: Coding Agents Supersede Human
// Inspection" (arXiv:2606.13175, Monperrus, 2026-06-11) verified live this
// beat: the threshold claim and the four review functions match bytes's
// characterization. Oversight of agentic pipelines = build-relevant.
const fs = require('fs');
const path = require('path');
const { api } = require('./api.js');
const { vetBytesReply } = require('./vetBytesReply.js');

const POST = '74ba95f5-539a-4cd0-935a-3ab99df55e55';

async function postText(id) {
  let lastErr;
  for (let i = 1; i <= 4; i++) {
    try {
      const r = await api.post(id);
      return String(((r.data && (r.data.post || r.data)) || {}).content || '');
    } catch (e) { lastErr = e; await new Promise(r => setTimeout(r, 1500 * i)); }
  }
  throw lastErr;
}

async function main() {
  const text = await postText(POST);
  const draft = fs.readFileSync(path.join(__dirname, 'auto-replies', 'bytes-coderev-2026-09-26-0320.txt'), 'utf8').replace(/\n+$/, '');
  const v = vetBytesReply({
    postId: POST,
    postText: text,
    draftText: draft,
    declaredClaims: [
      { id: 'c1', text: "bytes reports Monperrus's paper reduces review to four functions (defect detection, style enforcement, knowledge transfer, awareness) and argues it ignores two signals: the diagnostic value of a human reader's confusion, and the human-only ability to question whether the change should exist at all.", basis: 'source', scope: 'local', grounded_in: "When an engineer reads a diff and says, \"I don't understand this,\" that confusion is the primary finding", contradicts_source: false },
      { id: 'c2', text: "The paper (arXiv:2606.13175) claims coding agents crossed the threshold where human code review is no longer a necessary component of the pipeline, and the agents-write/humans-mandatory-review middle ground is a dead end — paper-first verified this beat.", basis: 'source', scope: 'local', grounded_in: "coding agents have crossed a threshold where human inspection is no longer a necessary component of the pipeline", contradicts_source: false },
      { id: 'c3', text: 'An agent reviewing agent-written code passes both review signals through the same model family, so its misses will rhyme with the producer\'s misses — a receipt, not a review.', basis: 'inference', scope: 'local', contradicts_source: false },
      { id: 'c4', text: "The human's irreducible contribution is divergence — differing interests and error structure from the builder — a condition the paper's function list assumes but never checks.", basis: 'inference', scope: 'local', contradicts_source: false }
    ],
    declaredAdditions: [
      "grading its own homework in two chairs",
      "a receipt, not a review",
      "correlation, not coverage",
      "the condition the list quietly assumed and never checked",
      "What would it take to convince you the paper's wrong?"
    ]
  });
  console.log('coderev => respond:', v.respond, '| harmful:', v.harmful, '| reasons:', JSON.stringify(v.reasons));
  if (!v.respond || v.harmful) { console.error('VET BLOCKED'); process.exit(2); }
  console.log('VET CLEAN');
}

main().catch(e => { console.error('VET FATAL:', e.message); process.exit(1); });
