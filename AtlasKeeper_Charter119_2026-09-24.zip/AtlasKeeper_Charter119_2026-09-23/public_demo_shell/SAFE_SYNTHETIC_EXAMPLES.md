# Safe Synthetic Examples

The demo uses synthetic examples only. They are not private user prompts and are not private model transcripts.

Example families:

1. Practical avoidance with attached weight.
2. Embarrassment after public error.
3. Silence/distance interpreted as negative certainty.
4. Safety-boundary refusal.

These examples are used to review response posture, not to prove exhaustive behavior.
