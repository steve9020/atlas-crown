'use strict';
const assert=require('assert');
const {detectAxes}=require('../Cognition/engine/AxisEngine.js');
const {readJsonRegistry}=require('../runtime/backend/ObsidianRegistryReader.js');
const reg=readJsonRegistry('CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/multilingual_axol_evidence_registry.md');
let seed=Number(process.env.AXOL_FUZZ_SEED||1920919); function rnd(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;} function pick(a){return a[Math.floor(rnd()*a.length)]}
const pool=[]; for(const [lang,p] of Object.entries(reg.packs||{})) for(const source of ['cues','families']) for(const [axis,arr] of Object.entries(p[source]||{})) for(const phrase of arr) pool.push({lang,axis,phrase});
let instances=0, detected=0, complete=0; const misses=[];
for(let i=0;i<1000;i++){
 const n=2+Math.floor(rnd()*4), chosen=[]; while(chosen.length<n){const x=pick(pool);if(!chosen.some(y=>y.lang===x.lang&&y.axis===x.axis&&y.phrase===x.phrase))chosen.push(x)}
 const text=chosen.map(x=>x.phrase).join(pick([' ; ',' — ',' / ','\n','   '])); const expected=[...new Set(chosen.map(x=>x.axis))]; const r=detectAxes(text); const missing=expected.filter(a=>!r.axes.includes(a)); instances+=expected.length; detected+=expected.length-missing.length; if(!missing.length)complete++; else if(misses.length<30)misses.push({text,expected,missing,actual:r.axes});
}
console.log(JSON.stringify({cases:1000,instances,detected,complete,misses},null,2)); assert.equal(detected,instances); assert.equal(complete,1000);
