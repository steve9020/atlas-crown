---
runtime_layer: clarification_grounding
registry_type: context_sufficiency_runtime
purpose: Backend-owned runtime rules for deciding when Atlas has enough context to respond without asking a grounding question.
governed_by:
  - clarification_grounding_question_registry
  - runtime_execution_permissions_registry
---

# Runtime Context Sufficiency Registry

This registry converts the older frontend clarification behavior into backend-executed runtime logic.

Core rule: Atlas does not ask a question because it detected one emotion word. Atlas asks only when the whole prompt lacks enough scenario context to respond without guessing.

## Context Sufficiency JSON

```json
{
  "thresholds": {
    "enough_context_score": 5,
    "strong_context_score": 7
  },
  "evidence": {
    "emotion_terms": ["guilt", "guilty", "relief", "relieved", "anger", "angry", "hurt", "sad", "fear", "afraid", "anxious", "shame", "ashamed", "resentment", "jealous", "envy", "numb", "confused", "lonely", "care", "cares", "love", "miss"],
    "source_terms": ["because", "when", "after", "since", "they", "someone", "friend", "partner", "girlfriend", "boyfriend", "argument", "distance", "distant", "pulling away", "crossed", "crossed lines", "hurt me", "left", "ignored", "dismissed", "said", "did", "happened"],
    "attached_meaning_terms": ["means", "mean", "prove", "proves", "proof", "i keep wondering", "i wonder if", "makes me feel", "made me feel", "like i am", "like i'm", "like im", "cold", "selfish", "too much", "not enough", "unwanted", "my fault", "wrong with me", "never cared", "didn't care", "dont care", "don't care"],
    "boundary_context_terms": ["boundary", "boundaries", "crossed lines", "crossed a line", "kept trying to explain", "kept explaining", "said no", "protect my peace", "need space", "needed distance", "lines i kept trying to explain"],
    "cost_terms": ["lost peace", "cost me", "exhausted", "drained", "overextended", "kept trying", "trying to keep", "keep the connection together", "carrying", "too much pressure"],
    "contradiction_terms": ["but", "at the same time", "part of me", "another part", "even though", "still", "also", "and yet", "confuses me", "mixed"]
  },
  "enough_when": [
    { "name": "emotion_source_meaning", "requires": ["emotion", "source", "attached_meaning"], "minimum_score": 5 },
    { "name": "mixed_emotion_with_source", "requires": ["mixed_emotion", "source"], "minimum_score": 5 },
    { "name": "boundary_relief_guilt", "requires": ["boundary_context", "relief", "guilt"], "minimum_score": 5 },
    { "name": "scenario_object_present", "requires": ["scenario_object", "emotion"], "minimum_score": 5 }
  ],
  "ask_only_when": [
    "emotion is vague and no source is present",
    "source is present but attached meaning is absent and route score is low",
    "single emotion word is present without scenario object, contradiction, or attached meaning"
  ]
}
```
