# Node Role Definitions

## Primitive
Foundational mechanics that the framework cannot function without.

Examples:
- [[Continuity Recognition]]
- [[Awareness]]
- [[Identity]]
- [[Meaning]]
- [[Emotional Weighting]]

---

## Dynamic
Mechanics that describe how systems move, reinforce, stabilize, fragment, or adapt over time.

Examples:
- [[Continuity Gravity]]
- [[Identity Momentum]]
- [[Continuity Drift]]
- [[Continuity Resonance]]
- [[Continuity Saturation]]

---

## State
Conditions continuity systems can exist within.

Examples:
- [[Peace]]
- [[Chaos]]
- [[Integrated Continuity]]
- [[Meaning Collapse]]
- [[Stability]]

---

## Process
Mechanisms that transform continuity structures.

Examples:
- [[Healing]]
- [[Recalibration]]
- [[Self-Authorship]]
- [[Continuity Reconstruction]]

---

## Distortion
Mechanics that destabilize, narrow, fragment, or corrupt continuity.

Examples:
- [[Shame]]
- [[Fear]]
- [[Addiction]]
- [[Validation Dependency]]
- [[Corruption]]

---

## Relational
Systems involving interpersonal continuity and shared emotional reinforcement.

Examples:
- [[Love]]
- [[Trust|Trust]]
- [[Attachment]]
- [[Betrayal]]
- [[Relational Continuity]]

---

## Meta-System
Nodes that explain the architecture itself.

Examples:
- [[Continuity Architecture]]
- [[Structural Awareness]]
- [[Recursive Continuity Mapping]]
- [[Continuity Centralization]]

---

## Loop
Recursive reinforcement systems.

Examples:
- [[Shame Loop]]
- [[Healing Loop]]
- [[Peace Loop]]
- [[Responsibility Loop]]

---

## Threshold
Critical transition points where continuity changes structurally.

Examples:
- [[Awareness Threshold]]
- [[Continuity Thresholds]]
- [[Continuity Integration Threshold]]

---

## Principle
Compressed governing truths underlying the architecture.

Examples:
- [[Core Principle]]