# Proposal Required Fields Registry

## Required Fields
- proposal_id
- source_prompt
- compass_response
- failure_pattern
- why_it_failed
- suggested_correction
- target_backend_file
- integration_draft
- status

## Runtime Rule
If any field is missing or empty, block storage, review, and implementation.
