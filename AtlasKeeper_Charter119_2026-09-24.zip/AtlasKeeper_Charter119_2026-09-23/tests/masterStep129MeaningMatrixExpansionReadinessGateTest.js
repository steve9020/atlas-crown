const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard.js');
const { evaluateMeaningMatrixExpansionReadinessGate, allowedFutureMatrixAreas, preservedAdjacentExpansion, MATRIX_EXPANSION_SCOPE } = require('../runtime/understanding/MeaningMatrixExpansionReadinessGate.js');

const ROOT = path.resolve(__dirname, '..');
const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');
function read(rel){ return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function walk(dir){ const out=[]; for (const e of fs.readdirSync(dir,{withFileTypes:true})){ const f=path.join(dir,e.name); if(e.isDirectory()) out.push(...walk(f)); else out.push(f); } return out; }
function sha256(rel){ return crypto.createHash('sha256').update(read(rel)).digest('hex'); }

const protectedFiles = [
  'runtime/backend/adapter/CandidatePhrasingCapabilityFreezeExpansionBoundaryPreservation.js',
  'runtime/backend/adapter/GovernedCompassPathCandidatePhrasingLiveContainmentIntegration.js',
  'runtime/backend/adapter/GovernedCompassPathCandidatePhrasingDryRunIntegration.js',
  'runtime/backend/adapter/GovernedCompassPathCandidatePhrasingIntegrationGate.js',
  'runtime/backend/adapter/OllamaLiveLocalCallContainment.js',
  'runtime/governance/GovernanceAdapter.js',
  'Cognition/quality/ResponseQualityChecker.js'
].filter(rel => fs.existsSync(path.join(ROOT, rel)));
const before = Object.fromEntries(protectedFiles.map(f=>[f,sha256(f)]));

(function main(){
  const doc = read('docs/MASTERSTEP129_MEANING_MATRIX_EXPANSION_READINESS_GATE.md');
  const shortDoc = read('docs/MEANING_MATRIX_EXPANSION_READINESS_GATE.md');
  const proofDoc = read('runtime/proof/MASTERSTEP129_MEANING_MATRIX_EXPANSION_READINESS_GATE.md');
  const proofJson = json('runtime/proof/MASTERSTEP129_MEANING_MATRIX_EXPANSION_READINESS_GATE.json');
  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
  const state = json('runtime/proof/PROOF_STATE.json');
  const versionStatus = json('tests/VERSION_STATUS.json');
  const versionJs = read('version_status.js');
  const testResults = read('tests/TEST_RESULTS.md');

  assert.ok(/Current keeper: Masterstep129\.zip/i.test(doc), 'Step129 doc must identify current keeper');
  assert.ok(/Source keeper: Masterstep128_rescan\.zip|Source keeper: Masterstep128\.zip/i.test(doc), 'Step129 doc must identify source keeper');
  assert.ok(/51\/51 commands passed/i.test(doc), 'Step129 doc must state expected 51/51 proof');
  assert.ok(/meaning matrix/i.test(doc + shortDoc + proofDoc), 'Step129 must center meaning matrix');
  assert.ok(/context-before-route|context before route/i.test(doc + shortDoc + proofDoc), 'Step129 must name context-before-route maturity');
  assert.ok(/gate only|readiness gate/i.test(doc + shortDoc + proofDoc), 'Step129 must be a gate only');
  assert.ok(/word carriers|Doyle spheres/i.test(doc + shortDoc + proofDoc), 'Step129 must preserve adjacent word and Doyle expansion paths');

  assert.strictEqual(proofJson.package, 'Masterstep129');
  assert.ok(['Masterstep128_rescan','Masterstep128'].includes(proofJson.source_keeper));
  assert.strictEqual(proofJson.expected_commands, 51);
  assert.strictEqual(proofJson.meaning_matrix_expansion_readiness_gate_created, true);
  assert.strictEqual(proofJson.meaning_matrix_first, true);
  assert.strictEqual(proofJson.gate_only, true);
  assert.strictEqual(proofJson.matrix_change_allowed_now, false);
  assert.strictEqual(proofJson.implementation_allowed_now, false);
  assert.strictEqual(proofJson.first_recommended_target, 'context_before_route_maturity');
  assert.strictEqual(proofJson.future_expansion_requires_user_approval, true);
  assert.strictEqual(proofJson.future_expansion_requires_governed_proof_step, true);
  assert.strictEqual(proofJson.model_may_author_matrix, false);
  assert.strictEqual(proofJson.model_may_write_matrix_files, false);
  assert.strictEqual(proofJson.model_may_approve_expansion, false);
  assert.strictEqual(proofJson.frontend_may_contain_matrix_logic, false);
  assert.strictEqual(proofJson.word_expansion_preserved, true);
  assert.strictEqual(proofJson.doyle_sphere_expansion_preserved, true);
  assert.strictEqual(proofJson.candidate_phrasing_freeze_preserved, true);
  assert.strictEqual(proofJson.broader_model_use_authorized, false);

  assert.strictEqual(MATRIX_EXPANSION_SCOPE.target, 'meaning_matrix');
  assert.strictEqual(MATRIX_EXPANSION_SCOPE.gateOnly, true);
  assert.strictEqual(MATRIX_EXPANSION_SCOPE.matrixChangeAllowedNow, false);
  assert.strictEqual(MATRIX_EXPANSION_SCOPE.modelMayAuthorMatrix, false);
  assert.strictEqual(allowedFutureMatrixAreas.contextBeforeRoute.firstRecommendedTarget, true);
  assert.strictEqual(allowedFutureMatrixAreas.attachedMeaningSeparation.preserved, true);
  assert.strictEqual(allowedFutureMatrixAreas.pressureFieldWeighting.preserved, true);
  assert.strictEqual(allowedFutureMatrixAreas.routeComparison.preserved, true);
  assert.strictEqual(allowedFutureMatrixAreas.restorationDirection.preserved, true);
  assert.strictEqual(preservedAdjacentExpansion.words.preserved, true);
  assert.strictEqual(preservedAdjacentExpansion.words.waitsBehindMatrix, true);
  assert.strictEqual(preservedAdjacentExpansion.words.modelMayExpandSilently, false);
  assert.strictEqual(preservedAdjacentExpansion.doyleSpheres.preserved, true);
  assert.strictEqual(preservedAdjacentExpansion.doyleSpheres.supportsMatrix, true);
  assert.strictEqual(preservedAdjacentExpansion.doyleSpheres.modelMayExpandSilently, false);

  const allowed = evaluateMeaningMatrixExpansionReadinessGate({ requestedAction: 'create readiness gate for context-before-route meaning matrix maturity', requestedArea: 'meaning matrix' });
  assert.strictEqual(allowed.ok, true);
  assert.strictEqual(allowed.gateOnly, true);
  assert.strictEqual(allowed.firstImplementationTarget, 'context_before_route_maturity');
  assert.strictEqual(allowed.matrixChangeAllowedNow, false);
  assert.strictEqual(allowed.modelMayAuthorMatrix, false);
  assert.strictEqual(allowed.candidatePhrasingFreezePreserved, true);
  assert.strictEqual(allowed.preservedAdjacentExpansion.words.preserved, true);
  assert.strictEqual(allowed.preservedAdjacentExpansion.doyleSpheres.preserved, true);

  for (const action of [
    'model write matrix rules',
    'model approve expansion',
    'frontend matrix logic',
    'silent learning',
    'silent mutation',
    'auto-learn meaning matrix',
    'cloud fallback',
    'replace final output',
    'route authority',
    'truth authority',
    'write ontology governance proof runtime tests'
  ]) {
    const blocked = evaluateMeaningMatrixExpansionReadinessGate({ requestedAction: action, requestedArea: 'meaning matrix' });
    assert.strictEqual(blocked.ok, false, `${action} must be blocked`);
    assert.strictEqual(blocked.failedClosed, true, `${action} must fail closed`);
    assert.strictEqual(blocked.matrixChangeAllowedNow, false, `${action} must not change matrix now`);
    assert.strictEqual(blocked.modelAuthorityAdded, false, `${action} must not add model authority`);
  }

  assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
  assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
  assert.ok(/Expected current proof target: [0-9]+\/[0-9]+ commands passed/i.test(summary), 'summary must identify current proof target compatibility');
  assert.ok(['Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 129), state.current_keeper);
  assert.ok(['Masterstep128_rescan.zip','Masterstep128.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 128) || state.source_keeper === 'Masterstep141.zip', 'state must identify source keeper');
  assert.ok(acceptsCurrentProofCount(state.expected_commands, 51), state.expected_commands);
  assert.ok(acceptsCurrentProofCount(state.expected_current_proof_commands, 51), state.expected_current_proof_commands);
  assert.strictEqual(state.meaning_matrix_expansion_readiness_gate_created, true);
  assert.strictEqual(state.meaning_matrix_first, true);
  assert.strictEqual(state.matrix_change_allowed_now, false);
  assert.ok([false,true].includes(state.implementation_allowed_now));
  assert.strictEqual(state.model_may_author_matrix, false);
  assert.strictEqual(state.model_may_write_matrix_files, false);
  assert.strictEqual(state.frontend_may_contain_matrix_logic, false);
  assert.strictEqual(state.candidate_phrasing_freeze_preserved, true);
  assert.ok(['Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(versionStatus.current_keeper) || isValidLaterKeeper(versionStatus.current_keeper, 129), versionStatus.current_keeper);
  assert.ok(['Masterstep128_rescan.zip','Masterstep128.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(versionStatus.source_keeper) || isValidLaterKeeper(versionStatus.source_keeper, 128) || versionStatus.source_keeper === 'Masterstep141.zip', 'version status must identify source keeper');
  assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 51), versionStatus.expected_current_proof_commands);
  assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs), 'version_status.js must identify current keeper compatibility');
  assert.ok(/expected_current_proof_commands: [0-9]+/i.test(versionJs), 'version_status.js must identify expected command compatibility');
  assert.ok(/TEST 129/i.test(testResults), 'ledger must include TEST 129');
  assert.ok(/Meaning Matrix Expansion Readiness Gate/i.test(testResults), 'ledger must identify Step129');
  assert.ok(/51\/51 commands/i.test(testResults), 'ledger must record 51/51');

  const forbiddenOverclaims = { test: (text) => hasForbiddenAffirmativeClaim(text) };
  for (const text of [doc, shortDoc, proofDoc, summary]) assert.ok(!forbiddenOverclaims.test(text), 'Step129 docs must not overclaim');
  const providerScan = scanForProviderConnections(ROOT);
  assert.strictEqual(providerScan.passed, true, `provider/network scan must pass: ${JSON.stringify(providerScan.violations || [])}`);
  const nestedArchives = walk(ROOT).filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
  assert.deepStrictEqual(nestedArchives, [], 'package must not contain nested archives');
  const after = Object.fromEntries(protectedFiles.map(f=>[f,sha256(f)]));
  assert.deepStrictEqual(protectedFiles.filter(f=>before[f]!==after[f]), [], 'Step129 test must not mutate protected files');
  console.log(JSON.stringify({ package:'Masterstep129', source_keeper:'Masterstep128_rescan', proof_target:'51/51', meaning_matrix_first:true, gate_only:true, first_recommended_target:'context_before_route_maturity', matrix_change_allowed_now:false, model_may_author_matrix:false, word_expansion_preserved:true, doyle_sphere_expansion_preserved:true, candidate_phrasing_freeze_preserved:true, nested_archives:nestedArchives.length }, null, 2));
})();
