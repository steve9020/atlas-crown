# Relational Translation

## Purpose
Translate relational dynamics into observable continuity structures.

## Function
Identifies:
- projection
- attachment activation
- trust disruption
- boundary instability
- validation seeking
- relational fragmentation

## Questions
- What relational pattern activated?
- Am I responding to present or memory?
- Is safety affecting interpretation?
- Is connection increasing or decreasing continuity?

## Goal
Increase relational clarity while preserving integrity.