
const assert = require('assert');
const map = require('../runtime/indexing/DoyleLayer2RelationalDomainMap');
const guard = require('../runtime/indexing/DoyleLayer2PlacementGuard');
const result = map.validateLayer();
assert.strictEqual(result.passed, true, result.errors.join(', '));
assert.strictEqual(map.countSpheres(), 12);
const required = ['Self Relationship','Other-Person Relationship','Family / Close Bond','Friendship / Social','Romantic / Attachment','Work / Responsibility','Daily-Life Maintenance','Belonging / Community','Authority / Power Dynamic','Conflict / Repair','Loss / Separation','Transition / Change'];
for (const sphere of required) assert.ok(map.getSphereByName(sphere), `missing ${sphere}`);
for (const s of map.getSpheres()) {
  assert.ok(Array.isArray(s.do_not_assume) && s.do_not_assume.length >= 3, `thin do_not_assume ${s.sphere}`);
  assert.ok(Array.isArray(s.common_attachments) && s.common_attachments.length >= 4, `thin attachments ${s.sphere}`);
}
const overreach = guard.validateNoLayer2Overreach();
assert.strictEqual(overreach.passed, true, overreach.failures.join(', '));
const placement = guard.placeRelationalDomain({ layer:'L2', sphere:'Other-Person Relationship' });
assert.strictEqual(placement.accepted, true);
assert.strictEqual(placement.final_route_decided, false);
assert.strictEqual(placement.emotion_decided, false);
assert.strictEqual(placement.meaning_decided, false);
assert.strictEqual(placement.authority_granted, false);
console.log('masterStep36Layer2CoreRelationalDomainsTest PASSED');
