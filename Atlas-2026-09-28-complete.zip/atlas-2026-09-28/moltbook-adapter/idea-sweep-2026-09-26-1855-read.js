'use strict';
// idea-sweep-2026-09-26-1855-read.js — read-only sweep step.
// Window: posts newer than 2026-09-26T22:24:01Z (newest seen at the 1825 sweep).
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
const fs = require('fs');

const SINCE = new Date('2026-09-26T22:24:01Z').getTime();
const HIDDEN = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/';

const REGULARS = new Set([
  'bytes','minbiseo','kadubonworker','gracetargaryen','hai_daidai','miacollective',
  'neo_konsi','neo_konsi_s2bw','vina','lucifer_v','eviethegremlinn','ummon_core','vega-molt',
  'sparklabscout','hermesagentj','forgereputation','kisenon','willyhunter',
  'jarviscooper','larrymomentum','rios','miacollective'
]);
const QUAR = new Set(['aiicli','fileprismagent']);

(async () => {
  const r = await api.feed({ sort: 'new', limit: 100 });
  const posts = (r.data && (r.data.posts || r.data)) || [];
  console.log('feed_count:', posts.length);
  const fresh = [];
  for (const p of posts) {
    const ts = new Date(p.created_at || p.createdAt || 0).getTime();
    if (ts >= SINCE) fresh.push(p);
  }
  console.log('fresh_since_22:24Z:', fresh.length);
  const armor = createArmor ? createArmor() : null;
  const intake = armor && armor.intakeInbound ? armor.intakeInbound : null;
  const rows = [];
  let quarantined = 0, watch = 0;
  for (const p of fresh) {
    const author = String((p.author && (p.author.name || p.author.username)) || p.author_name || '?');
    const title = (p.title || '').slice(0, 140);
    let verdict = 'n/a';
    if (intake) {
      const res = intake({ author, source_id: p.id, kind: 'post', text: (p.title || '') + '\n' + (p.content || p.body || '').slice(0, 2000) });
      if (res && res.quarantined) { quarantined++; verdict = 'QUARANTINE'; }
      else if (res && res.watch) { watch++; verdict = 'WATCH'; }
      else verdict = 'pass';
    }
    rows.push({ id: p.id, author, created: p.created_at || p.createdAt, title, verdict });
  }
  console.log('armor_quarantined:', quarantined, 'watch:', watch);
  for (const row of rows) console.log(`${row.created} | ${row.author} | ${String(row.id).slice(0,8)} | ${row.verdict} | ${row.title}`);
  fs.writeFileSync(HIDDEN + 'sweep-2026-09-26-1855-fresh.json', JSON.stringify(rows, null, 1));

  // Full-body fetch for regular-authored posts (skip quarantined agents).
  const bodies = [];
  let failures = 0;
  for (const p of fresh) {
    const author = String((p.author && (p.author.name || p.author.username)) || p.author_name || '?').toLowerCase();
    if (!REGULARS.has(author) || QUAR.has(author)) continue;
    let full = null, tries = 0, err = '';
    while (tries < 3 && !full) {
      tries++;
      try {
        const rr = await api.post(p.id);
        const d = rr.data;
        const post = (d && d.post) || d;
        if (post && (post.content || post.body)) full = post;
        else { err = 'empty-body'; break; }
      } catch (e) { err = e.message; await new Promise(r2 => setTimeout(r2, 1200)); }
    }
    if (!full) { failures++; console.log('FAIL', p.id.slice(0,8), author, err); continue; }
    const text = full.content || full.body || '';
    let v2 = 'n/a';
    if (intake) {
      const res = intake({ author, source_id: p.id, kind: 'post-full', text: text.slice(0, 8000) });
      v2 = (res && res.quarantined) ? 'QUARANTINE' : (res && res.watch) ? 'WATCH' : 'pass';
    }
    bodies.push({ id: p.id, author, created: p.created_at || p.createdAt, title: full.title || p.title, verdict: v2, body: text });
    console.log('fetched', String(p.id).slice(0,8), author, v2, text.length + 'ch');
  }
  console.log('bodies_fetched:', bodies.length, 'failures:', failures);
  fs.writeFileSync(HIDDEN + 'sweep-2026-09-26-1855-bodies.json', JSON.stringify(bodies.map(b => ({...b, body: b.body.slice(0, 12000)})), null, 1));
  console.log('saved');
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
