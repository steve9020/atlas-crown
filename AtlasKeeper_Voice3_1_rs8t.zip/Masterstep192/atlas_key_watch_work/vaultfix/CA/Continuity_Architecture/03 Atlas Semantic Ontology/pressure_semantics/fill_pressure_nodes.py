from pathlib import Path

folder = Path.cwd()

for file in folder.glob("*.md"):
    name = file.stem
    title = name.replace("_", " ").title()

    content = f"""---
type: pressure_semantic
semantic_domain: pressure_semantics
pressure_id: {name}
activation_weight: variable
risk_level: context_dependent
runtime_role: pressure_detection
status: scaffolded
---

# {title}

## Semantic Purpose
This node defines the language, meaning patterns, continuity effects, and runtime interpretation pathways associated with **{title}**.

This pressure should not be treated as a final judgment, diagnosis, or fixed truth. It represents a possible semantic pressure pattern that may activate inside the continuity system.

## Core Semantic Meaning
{title} refers to a pressure state where continuity may become strained, disrupted, unstable, overloaded, or directionally unclear.

This node helps the system detect when language may indicate this pressure without assuming certainty.

## Common Language Indicators
- "Something feels off."
- "I can't settle this."
- "This keeps bothering me."
- "I don't know what to do with this."
- "It feels unstable."
- "I feel pulled in different directions."
- "I can't make sense of it."
- "This keeps coming back up."
- "I feel pressure around this."
- "I don't feel clear."

## Soft Semantic Indicators
- uncertainty
- tension
- instability
- emotional load
- unresolved meaning
- repeated return
- internal resistance
- difficulty integrating
- loss of clarity
- pressure accumulation

## Strong Semantic Indicators
- escalating distress
- repeated contradiction
- loss of regulation
- inability to pause
- compulsive looping
- collapse language
- fragmented interpretation
- all-or-nothing framing
- threat perception
- continuity disruption

## Operational Interpretation
When this pressure activates, the system should interpret it as a possible sign that continuity is under strain.

The system should ask:
- What continuity is being pressured?
- Is the pressure emotional, cognitive, relational, environmental, or recursive?
- Is the pressure isolated or compounding with other pressures?
- Is stabilization needed before interpretation?
- Is the user still in a flexible state or entering recursive escalation?

## Continuity Effects
Possible continuity effects include:
- reduced clarity
- unstable interpretation
- disrupted self-orientation
- relational misalignment
- increased contradiction sensitivity
- pressure accumulation
- reduced adaptive flexibility
- escalation risk
- defensive interpretation
- fragmentation risk

## Reverse Flow Risks
This pressure may reverse into:
- recursive escalation
- destabilization loops
- contradiction amplification
- identity instability
- relational withdrawal
- over-control
- avoidance
- collapse response
- fixation
- distorted continuity mapping

## Stabilization Pathways
Possible stabilization pathways:
- pause before interpretation
- reduce urgency
- separate signal from conclusion
- identify the pressure source
- locate what continuity is being threatened
- slow recursive movement
- restore grounded sequencing
- distinguish present pressure from past pattern
- re-establish adaptive choice
- route into recovery semantics if needed

## Recovery Pathways
Possible recovery movement:
- reframe pressure as information
- identify the affected continuity thread
- reduce overload
- reconnect to present-state clarity
- restore self-orientation
- move from reaction to structure
- identify what needs protection, repair, or release
- reconnect pressure to adaptive direction

## Safety Gate Conditions
This pressure does not automatically trigger a safety gate.

A safety gate may activate only if this pressure combines with:
- recursive escalation
- fragmentation risk
- collapse language
- loss of self-orientation
- runaway contradiction
- destabilization compounding
- inability to pause
- high-risk behavioral intent

Safety gate purpose:
- preserve continuity
- reduce escalation
- stabilize interpretation
- prevent recursive collapse
- route toward grounding

## Plugin Runtime Notes
The plugin should treat this node as a semantic pressure reference.

It should not:
- diagnose
- moralize
- force conclusions
- assume intent
- suppress expression

It should:
- detect possible pressure
- weight activation contextually
- check related pressures
- route to stabilization if intensity rises
- preserve interpretive flexibility

## Related Semantic Domains
- stabilization_semantics
- recovery_semantics
- contradiction_semantics
- recursive_semantics
- regulation_semantics
- threshold_semantics
- fragmentation_semantics
- continuity_semantics

## Expansion Notes
This node can later be expanded with:
- phrase banks
- weighted indicators
- example inputs
- linked reverse flows
- stabilization maps
- recovery maps
- contradiction interactions
- runtime scoring rules
- semantic cluster relationships
"""

    file.write_text(content, encoding="utf-8")

print("Pressure semantic files filled.")