# Prompt Reuse Prevention Registry

## Purpose
Prevents Atlas from using the same prompt or category too often.

## Rules
- category cooldown before reuse
- prompt cooldown before reuse
- prompt variants should rotate when available
- repeated testing should change wording, emotional intensity, or scenario object
- single prompt examples should not dominate learning

## Runtime Direction
Atlas should test patterns, not memorize one wording.
