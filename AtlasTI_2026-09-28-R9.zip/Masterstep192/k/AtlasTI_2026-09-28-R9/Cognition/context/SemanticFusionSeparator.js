const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const SEMANTIC_FUSION_REGISTRY_PATH = "CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/semantic_fusion_separation_registry.md";

let cachedSemanticFusionRegistry = null;

function getSemanticFusionRegistry() {
  if (!cachedSemanticFusionRegistry) {
    cachedSemanticFusionRegistry = readJsonRegistry(SEMANTIC_FUSION_REGISTRY_PATH);
  }
  return cachedSemanticFusionRegistry;
}

function normalizeInput(input) { return String(input || "").toLowerCase(); }
function phraseMatches(text, phrase) { return typeof phrase === "string" && phrase.length > 0 && text.includes(phrase.toLowerCase()); }
function anyPhraseMatches(text, phrases) { return Array.isArray(phrases) && phrases.some((phrase) => phraseMatches(text, phrase)); }
function allGroupsMatch(text, groups) {
  if (!Array.isArray(groups) || groups.length === 0) return true;
  return groups.every((group) => anyPhraseMatches(text, Array.isArray(group.phrases) ? group.phrases : []));
}
function ruleMatches(text, rule) {
  const phrases = Array.isArray(rule.phrases) ? rule.phrases : [];
  const allGroups = Array.isArray(rule.allGroups) ? rule.allGroups : [];
  if (allGroups.length > 0 && !allGroupsMatch(text, allGroups)) return false;
  if (phrases.length > 0 && !anyPhraseMatches(text, phrases)) return false;
  return allGroups.length > 0 || phrases.length > 0;
}
function appendUnique(target, values) {
  if (!Array.isArray(values)) return;
  for (const value of values) {
    if (typeof value === "string" && value.trim() && !target.includes(value)) target.push(value);
  }
}
function collectMatchedRules(text, rules) {
  const matched = [];
  for (const rule of rules) if (rule && rule.id && ruleMatches(text, rule)) matched.push(rule);
  return matched;
}
function resolveContextState(contextIntegrity) {
  if (!contextIntegrity || typeof contextIntegrity !== "object") {
    return { contextAvailable: false, revisable: true, closureAllowed: false, interpretationState: "context_integrity_missing" };
  }
  return {
    contextAvailable: contextIntegrity.outer_context_status === "context_available",
    revisable: contextIntegrity.revisable !== false,
    closureAllowed: contextIntegrity.closure_allowed === true,
    interpretationState: contextIntegrity.interpretation_state || "unknown"
  };
}
function mapSemanticFusion(input, contextIntegrity) {
  const text = normalizeInput(input);
  const registry = getSemanticFusionRegistry();
  const rules = Array.isArray(registry.rules) ? [...registry.rules] : [];
  const contextState = resolveContextState(contextIntegrity);
  rules.sort((a, b) => (a.priority || 9999) - (b.priority || 9999));
  const matchedRules = collectMatchedRules(text, rules);
  const cleanMeanings = [];
  const attachedNegativeMeanings = [];
  const fusionSignals = [];
  const separationMoves = [];
  const inheritanceBlocks = [];
  const restorationTargets = [];
  for (const rule of matchedRules) {
    appendUnique(cleanMeanings, rule.cleanMeanings);
    appendUnique(attachedNegativeMeanings, rule.attachedNegativeMeanings);
    appendUnique(fusionSignals, rule.fusionSignals);
    appendUnique(separationMoves, rule.separationMoves);
    appendUnique(inheritanceBlocks, rule.inheritanceBlocks);
    appendUnique(restorationTargets, rule.restorationTargets);
  }
  const fusionDetected = fusionSignals.length > 0 || attachedNegativeMeanings.length > 0;
  const negativeInheritanceBlocked = fusionDetected || inheritanceBlocks.length > 0;
  return {
    version: registry.version,
    stewardship: "Master Step 4B — Semantic Fusion Separation",
    depends_on: "Master Step 4A — Context Integrity Mapping",
    context_state: contextState,
    semantic_fusion_detected: fusionDetected,
    negative_inheritance_blocked: negativeInheritanceBlocked,
    word_meaning_closure_allowed: false,
    revisable: true,
    output_mode: fusionDetected ? "reflect_axis_not_collapsed_identity" : "no_semantic_fusion_detected",
    clean_meanings: cleanMeanings,
    attached_negative_meanings: attachedNegativeMeanings,
    fusion_signals: fusionSignals,
    separation_moves: separationMoves,
    inheritance_blocks: inheritanceBlocks,
    restoration_targets: restorationTargets,
    matched_rules: matchedRules.map((rule) => rule.id),
    guardrails: Array.isArray(registry.guardrails) ? registry.guardrails : []
  };
}
module.exports = { mapSemanticFusion };
