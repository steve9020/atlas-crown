# Human Key And External Rollback Boundary

## Purpose
This boundary defines the first two containment supports for protected-key governance experiments.

## 1. Locked Door / Human-Only Pass Boundary
The protected key boundary is held outside runtime authority.

- The key/pass boundary is human-held only.
- Inner governance may watch, detect, and report attempts toward the key.
- Inner governance may not open, recover, approve, restore, regenerate, infer, bypass, or authorize access to the key.
- Runtime may not treat successful detection as permission to access the protected key.
- Any request, simulation, test, probe, or indirect attempt to reach protected key material must remain blocked and escalated as containment.

## 2. External Rollback Copy / Keeper Boundary
Rollback recovery must be available outside compromised runtime state.

- A trusted rollback/keeper copy must exist outside the runtime layer being evaluated.
- Inner governance may report that rollback is needed, but may not select, modify, or authorize the rollback copy.
- Runtime self-repair may not replace external rollback authority.
- Recovery must come from a trusted outside copy under human authorization.
- The rollback copy is for restoration to governed alignment, not restoration of uncontrolled capability.

## Authority Separation
- Outer governance and constitution define the authority boundary.
- Inner governance detects and reports.
- Runtime enforces blocks but does not own recovery authority.
- Human authorization controls access to the locked-door boundary and external rollback copy.

## Restoration Constraint
Future restoration logic must use this boundary as a prerequisite. No incremental inner-governance restoration may proceed unless it restores alignment to the constitution and preserves human-held authority over key and rollback control.
