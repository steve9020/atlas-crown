# Response Prioritization Context First

## Purpose
This node defines the final response-order correction.

## Correct Order
1. Context / human act
2. emotional effect
3. pattern that forms
4. attached meaning
5. separation
6. lighter perspective

## Wrong Order
1. generalized emotional processing
2. abstract meaning attachment
3. vague clean separation
4. missing scenario context

## Rule
The response should sound like Atlas understood the situation, not only the emotional mechanism.
