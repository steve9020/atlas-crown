# AXOL Reference Resolution Report

Scope: backend AxisEngine attribution only. No frontend or Crown/governance authority changes.

## Baseline
The first explicit reference-resolution corpus passed 1/8. Existing attribution could preserve actor labels but did not resolve ordinary named antecedents behind pronouns.

## Repair
Added conservative reference resolution to attribution evidence for structurally supported constructions, including named speaker -> pronoun, `X told Y that he/she`, selected named object-reference constructions, and same-subject comma continuations. Resolution remains evidence metadata only; it does not assign truth, blame, authority, or responsibility.

The repair was narrowed after regression testing showed that aggressive pronoun binding could overwrite already-correct cross-binding. Unsupported/ambiguous pronouns remain pronouns rather than being forcibly assigned to a named actor.

A responsibility evidence gap (`X was responsible`) and a choice evidence construction (`X refused/accepted/rejected the choice/decision`) exposed by the corpus were added to the registry-owned evidence layer.

## Closed tests
- reference-resolution corpus: 8/8
- unseen reference-resolution corpus: 6/6
- ambiguity/neutral controls: 4/4
- prior attribution cross-binding: 26/26, 8/8 complete
- prior unseen cross-binding: 22/22, 6/6 complete
- prior attribution: 8/8
- prior unseen attribution: 8/8
- discrimination: 20/20
- collision composition: 48/48, 12/12 complete
- unseen collision composition: 32/32, 8/8 complete
- semantic fuzz: 36/36
- canonical proof: 100/100 PASS

## Boundary
This is conservative local reference resolution, not general natural-language coreference understanding. Ambiguous references are intentionally not forced into a named attribution.
