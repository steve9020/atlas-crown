const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const proof = require('../runtime/proof/PROOF_STATE.json');
const version = require('../version_status.js');
const { assertRangeExpressionOnly } = require('../runtime/compass/GoldenCompassLanguageRangeField');

assert.strictEqual(proof.current_keeper, 'Masterstep46');
assert.strictEqual(version.current_keeper, 'Masterstep46');
assert.strictEqual(proof.status, 'CLOSED_CURRENT_KEEPER');
assert.strictEqual(version.status, 'CLOSED_CURRENT_KEEPER');
assert.strictEqual(proof.real_ai_connected, false);
assert.strictEqual(proof.local_model_connected, false);
assert.strictEqual(proof.model_loaded, false);
assert.strictEqual(proof.model_execution_enabled, false);
assert.strictEqual(proof.provider_config_added, false);
assert.strictEqual(proof.network_bridge_added, false);
assert.strictEqual(proof.frontend_intelligence_added, false);
assert.strictEqual(proof.language_range_expression_only, true);
assert.strictEqual(proof.language_cannot_override_routing, true);
assert.strictEqual(assertRangeExpressionOnly().passed, true);

const required = [
  'runtime/compass/GOLDEN_COMPASS_LANGUAGE_RANGE_FIELD.json',
  'runtime/compass/GoldenCompassLanguageRangeField.js',
  'runtime/proof/MASTERSTEP46_GOLDEN_COMPASS_LANGUAGE_RANGE_FIELD.md',
  'docs/MASTERSTEP46_GOLDEN_COMPASS_LANGUAGE_RANGE_FIELD_MAP.md',
  'tests/masterStep46GoldenCompassLanguageRangeFieldTest.js'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(__dirname, '..', rel)), rel);
console.log('masterStep46FullClosureKeeperReadinessTest PASSED');
