# Hierarchy Map

## Layer 1 — Core Primitives
- [[Continuity Recognition]]
- [[Awareness]]
- [[Identity]]
- [[Emotional Weighting]]
- [[Meaning]]
- [[Recalibration]]
- [[Integrity]]
- [[Self-Authorship]]

## Layer 2 — Core Dynamics
- [[Continuity Gravity]]
- [[Identity Momentum]]
- [[Perspective Filtering]]
- [[Recursive Awareness]]
- [[00-Core/10  Meta/Contradiction Tolerance|Contradiction Tolerance]]
- [[Continuity Drift]]
- [[Fragmentation]]
- [[Adaptive Continuity]]
- [[Integrated Continuity]]

## Layer 3 — Human Experience Nodes
- [[Love]]
- [[Fear]]
- [[Shame]]
- [[Guilt]]
- [[Grief]]
- [[Suffering]]
- [[Trust|Trust]]
- [[Loneliness|Loneliness]]
- [[Self-Worth]]
- [[Hope]]
- [[Peace]]

## Layer 4 — Distortion Systems
- [[Corruption]]
- [[Addiction]]
- [[Narcissism]]
- [[Validation Dependency]]
- [[Resentment]]
- [[Meaning Collapse]]
- [[Recursive Fragmentation]]

## Layer 5 — Stabilization Systems
- [[Healing]]
- [[Discipline]]
- [[Humility]]
- [[Wisdom]]
- [[Maturity]]
- [[Boundaries]]
- [[Stability]]
- [[Alignment]]
- [[Responsibility]]
- [[Freedom]]

## Layer 6 — Relational / Social Systems
- [[Relational Continuity]]
- [[Betrayal]]
- [[Vulnerability|Vulnerability]]
- [[Justice]]
- [[Authority]]

## Layer 7 — Meta-Architecture
- [[Continuity Architecture]]
- [[Recursive Continuity Mapping]]
- [[Structural Awareness]]
- [[Continuity Centralization]]
- [[Continuity Coherence]]
- [[Continuity Reconstruction]]