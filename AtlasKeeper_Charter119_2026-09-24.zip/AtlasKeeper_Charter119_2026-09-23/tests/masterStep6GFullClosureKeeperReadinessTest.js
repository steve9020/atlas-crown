const fs = require('fs');
const path = require('path');

const root = process.cwd();
const proofDir = path.join(root, 'CA', 'Continuity_Architecture', '99 Atlas Operating Instructions', 'Proof of Work');

function read(rel) {
  return fs.readFileSync(path.join(root, rel), 'utf8');
}

function requireFile(rel, label) {
  const full = path.join(root, rel);
  if (!fs.existsSync(full)) {
    throw new Error(`Missing ${label}: ${rel}`);
  }
  return fs.readFileSync(full, 'utf8');
}

function requireMarkers(text, markers, label) {
  for (const marker of markers) {
    if (!text.includes(marker)) {
      throw new Error(`${label} missing marker: ${marker}`);
    }
  }
}

const requiredProofs = [
  ['MASTER_STEP_6B_PROOF_AUTOMATION_STABILIZATION.md', ['MASTER STEP 6B', 'Result: PASSED']],
  ['MASTER_STEP_6C_TEST_AUTOMATION_CONNECTION.md', ['MASTER STEP 6C', 'Result: PASSED']],
  ['MASTER_STEP_6D_PROOF_REGRESSION_FUZZ.md', ['MASTER STEP 6D', '49 benign cases', '9 hard governance cases', '7 malformed/input-boundary cases']],
  ['MASTER_STEP_6D2_LEGACY_FUZZ_WRAPPER_ALIGNMENT.md', ['Master Step 6D-2', 'legacy fullPackageFuzzTest.js path']],
  ['MASTER_STEP_6D3_FULL_PACKAGE_FUZZ_AUTHORITY_LOCK.md', ['Master Step 6D-3', 'Verified full-package fuzz coverage is the authority', 'Legacy monolithic direct execution is not the authority']],
  ['MASTER_STEP_6D4_FUZZ_TIMEOUT_STABILIZATION.md', ['Master Step 6D-4', 'fullPackageFuzzTest.js wrapper passed', '49 benign cases']],
  ['MASTER_STEP_6E_FRONTEND_SHELL_BOUNDARY_AUDIT.md', ['MASTER STEP 6E', 'Compass user-facing output remains input/display shell']],
  ['MASTER_STEP_6F_FRONTEND_SHELL_REGRESSION.md', ['Master Step 6F', 'Compass frontend remains an input/display shell']]
];

for (const [file, markers] of requiredProofs) {
  const text = requireFile(path.join('CA', 'Continuity_Architecture', '99 Atlas Operating Instructions', 'Proof of Work', file), file);
  requireMarkers(text, markers, file);
}

const testResults = requireFile('tests/TEST_RESULTS.md', 'TEST_RESULTS.md');
requireMarkers(testResults, [
  'Masterstep03_patch08.zip',
  'Master Step 6F: Frontend Shell Regression',
  'fullPackageFuzzTest.js wrapper passed through timeout-stabilized sharded coverage',
  'proof_runner.py passed'
], 'TEST_RESULTS.md');

const proofIndex = requireFile(path.join('CA', 'Continuity_Architecture', '99 Atlas Operating Instructions', 'Proof of Work', 'PROOF_OF_WORK_CARRIED_FORWARD_INDEX.md'), 'proof carry-forward index');
requireMarkers(proofIndex, [
  'Master Step 6B',
  'Master Step 6C',
  'Master Step 6D',
  'Master Step 6D-4',
  'Master Step 6E',
  'Master Step 6F'
], 'PROOF_OF_WORK_CARRIED_FORWARD_INDEX.md');

const wrapper = requireFile('tests/fullPackageFuzzTest.js', 'fullPackageFuzzTest.js');
requireMarkers(wrapper, [
  'FULL PACKAGE FUZZ TEST — WRAPPER',
  'masterStep6DShardedFullPackageFuzzTest.js',
  'Legacy monolithic harness superseded by concurrent sharded execution'
], 'fullPackageFuzzTest.js');

const sharded = requireFile('tests/masterStep6DShardedFullPackageFuzzTest.js', 'masterStep6DShardedFullPackageFuzzTest.js');
requireMarkers(sharded, [
  'MASTER STEP 6D SHARDED FULL PACKAGE FUZZ TEST',
  'concurrent process-reset sharded coverage',
  'Result: PASSED'
], 'masterStep6DShardedFullPackageFuzzTest.js');

const frontendRegression = requireFile('tests/masterStep6FFrontendShellRegressionTest.js', 'masterStep6FFrontendShellRegressionTest.js');
requireMarkers(frontendRegression, [
  'Frontend shell regression preserved input/display shell',
  'runUniversalGovernancePreflight' 
], 'masterStep6FFrontendShellRegressionTest.js');

console.log('masterStep6GFullClosureKeeperReadinessTest.js — PASSED');
console.log('Masterstep03 closure readiness verified across proof automation, fuzz wrapper authority, frontend shell boundary, and proof carry-forward.');
