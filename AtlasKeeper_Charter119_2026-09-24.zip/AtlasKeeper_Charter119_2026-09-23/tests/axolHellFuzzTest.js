const { detectAxes } = require(process.cwd() + '/Cognition/engine/AxisEngine');
const cases=[];
function add(kind,text,expected=[],forbidden=[],attrs=[]){cases.push({kind,text,expected,forbidden,attrs});}
// Dense multi-axis / attribution / reference movement
add('dense','Marcus said he intended to leave, but Jennifer expected him to stay; she accepted his choice although she thought the outcome was unfair.', ['intention','expectation','choice','acceptance_rejection','fairness'],[],[['intention','marcus'],['expectation','jennifer']]);
add('dense','Jennifer told Marcus that he was responsible, but he denied responsibility while she kept control of the decision.', ['responsibility','control'],[],[['responsibility','marcus'],['control','jennifer']]);
add('dense','Marcus trusted Jennifer, yet she crossed his boundary and he no longer respected her decision.', ['trust','boundary','respect'],[],[['trust','marcus'],['boundary','jennifer'],['respect','marcus']]);
add('dense','I saw the message, took it as rejection, but I am not sure whether that interpretation was correct.', ['observation_evidence','interpretation','certainty'],[]);
add('dense','We put in the effort and reached the outcome, but it still did not feel sufficient.', ['effort','outcome','sufficiency'],[]);
add('dense','She chose the plan because she believed it would cause a change, while he thought the same change was outside his control.', ['choice','causation','change','control'],[]);
// Pronoun ambiguity should not invent named actor bindings
add('ambiguous','Marcus spoke with Daniel. He expected an answer.', ['expectation'],[],[]);
add('ambiguous','Jennifer called Sarah after she made the choice.', ['choice'],[],[]);
add('ambiguous','Marcus blamed Daniel because he caused the delay.', ['causation'],[],[]);
add('ambiguous','Jennifer trusted Sarah because she respected the boundary.', ['trust','respect','boundary'],[],[]);
// Negation / uncertainty
add('state','I did not choose that option.', ['choice'],[],[['choice','self','negated']]);
add('state','I am not sure whether I caused the problem.', ['causation'],[],[['causation','self','uncertain']]);
add('state','Marcus did not intend to hurt anyone.', ['intention'],[],[['intention','marcus','negated']]);
add('state','Jennifer may be responsible for the outcome.', ['responsibility'],[],[['responsibility','jennifer','uncertain']]);
add('state','He never accepted the result.', ['acceptance_rejection'],[],[['acceptance_rejection','he','negated']]);
// Neutral lexical traps
for (const t of [
 'The control panel has three buttons.', 'The choice menu opened on screen.', 'The trust account was audited.', 'The boundary line is painted blue.',
 'The fair opens on Saturday.', 'The outcome variable is stored in memory.', 'The authority field is a database column.', 'The connection timed out.',
 'The change machine returned two quarters.', 'The owner manual is on the desk.', 'The comparison chart has four rows.', 'The responsibility matrix is a file name.'
]) add('neutral',t,[]);
// Compact natural-language variants
const variants = [
 ['intention',['I meant to call.','Marcus meant to leave early.','Jennifer planned to answer later.']],
 ['expectation',['I figured he would show up.','Marcus anticipated a reply.','Jennifer was counting on an answer.']],
 ['responsibility',['I own what happened.','Marcus is accountable for the delay.','Jennifer took responsibility for it.']],
 ['choice',['I decided to stay.','Marcus chose the second route.','Jennifer made the decision herself.']],
 ['control',['I had no control over it.','Marcus controlled the schedule.','Jennifer could not control the result.']],
 ['boundary',['I drew a line there.','Marcus crossed a boundary.','Jennifer set a limit.']],
 ['trust',['I relied on him.','Marcus trusted Jennifer.','Jennifer lost trust in Marcus.']],
 ['respect',['I respected the decision.','Marcus disregarded her boundary.','Jennifer showed respect for his choice.']],
 ['fairness',['That treatment was unfair.','Marcus thought the split was fair.','Jennifer said it was not equitable.']],
 ['comparison',['I did better than before.','Marcus compared the two outcomes.','Jennifer was less prepared than Sarah.']],
 ['causation',['That caused the delay.','Marcus made it happen.','Jennifer said the outage led to the failure.']],
 ['change',['Things became different afterward.','Marcus changed his approach.','Jennifer remained unchanged.']],
 ['connection',['I felt close to them.','Marcus felt disconnected from Jennifer.','Jennifer wanted more connection.']],
 ['effort',['I put everything into it.','Marcus tried hard.','Jennifer kept working at it.']],
 ['outcome',['It ended badly.','Marcus got the result he wanted.','Jennifer reached the final result.']],
 ['sufficiency',['It still was not enough.','Marcus had enough to finish.','Jennifer said the work was sufficient.']],
 ['ownership',['That belongs to me.','Marcus owns the mistake.','Jennifer said the task was hers.']],
 ['acceptance_rejection',['I accepted the result.','Marcus rejected the offer.','Jennifer would not accept the blame.']],
 ['interpretation',['I read it as criticism.','Marcus took that as a warning.','To Jennifer it sounded hostile.']],
 ['observation_evidence',['I watched it happen.','Marcus heard the statement.','The log confirms the event.']],
];
for(const [axis,arr] of variants) for(const t of arr) add('variant',t,[axis]);
// Multi-sentence continuity probes
add('continuity','Marcus intended to resign. He told Jennifer the next morning. She expected him to reconsider.', ['intention','expectation'],[],[['intention','marcus'],['expectation','jennifer']]);
add('continuity','Jennifer made the choice. Marcus objected. She accepted the consequence anyway.', ['choice','acceptance_rejection'],[],[['choice','jennifer'],['acceptance_rejection','jennifer']]);
add('continuity','Marcus crossed the boundary. Jennifer confronted him. He said he respected it now.', ['boundary','respect'],[],[['boundary','marcus'],['respect','marcus']]);

let expTotal=0, expHit=0, forbTotal=0, forbClean=0, attrTotal=0, attrHit=0; const misses=[]; const falsepos=[]; const attrmiss=[];
for(const c of cases){const r=detectAxes(c.text); for(const a of c.expected){expTotal++; if(r.axes.includes(a)) expHit++; else misses.push({kind:c.kind,text:c.text,axis:a,got:r.axes});} for(const a of c.forbidden){forbTotal++; if(!r.axes.includes(a)) forbClean++; else falsepos.push({kind:c.kind,text:c.text,axis:a,got:r.axes});} if(c.kind==='neutral' && r.axes.length){falsepos.push({kind:c.kind,text:c.text,axis:'ANY',got:r.axes});} for(const at of c.attrs){attrTotal++; const [axis,actor,state]=at; const row=r.axis_evidence.find(x=>x.axis===axis); const ok=row && row.attributions.some(x=>x.actor===actor && (!state||x.state===state)); if(ok) attrHit++; else attrmiss.push({text:c.text,axis,actor,state,attrs:row?.attributions||[]});}}
console.log(JSON.stringify({cases:cases.length, expected:{hit:expHit,total:expTotal}, attribution:{hit:attrHit,total:attrTotal}, neutral_false_positive_cases:falsepos.length, misses:misses.length, attr_misses:attrmiss.length},null,2));
console.log('\nMISSES'); for(const x of misses) console.log(JSON.stringify(x));
console.log('\nATTR_MISSES'); for(const x of attrmiss) console.log(JSON.stringify(x));
console.log('\nFALSE_POS'); for(const x of falsepos) console.log(JSON.stringify(x));
