# Reframing

## Purpose
Expand interpretive flexibility without invalidating perception.

## Function
Reframing:
- loosens rigid interpretation
- increases perspective range
- restores flexibility
- prevents interpretive locking

## Reframing Questions
- What changes if this interpretation is incomplete?
- What alternate explanation exists?
- What information may be missing?
- What remains true across interpretations?

## Goal
Preserve continuity while increasing perspective flexibility.