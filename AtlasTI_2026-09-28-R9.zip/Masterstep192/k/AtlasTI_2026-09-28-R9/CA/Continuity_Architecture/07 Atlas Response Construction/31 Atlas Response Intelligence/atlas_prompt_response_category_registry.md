---
title: Atlas Prompt Response Category Registry
runtime_layer: response_intelligence
priority: 98
governed_by: [[runtime_governance_source_of_truth_registry]]
---

# Atlas Prompt Response Category Registry

This registry is the backend source for Atlas prompt-response categories.

The plugin may parse this registry, score the user prompt against these category definitions, and render the resulting Compass response. The plugin may not silently invent new category meanings, remove categories, or treat hardcoded fallback categories as higher authority than this file.

## Runtime Rule

- Category meaning belongs here.
- Category terms belong here.
- Emotional contact domains belong here.
- Pattern formation language belongs here.
- Negative learning and clearer-forward language belong here.
- Plugin code may execute matching and rendering only.

## Category JSON

```json
[
  {
    "key": "attachment_and_connection",
    "label": "attachment and connection pressure",
    "terms": [
      "attached",
      "attachment",
      "connected",
      "connection",
      "close",
      "closeness",
      "bond",
      "miss them",
      "distance hurts",
      "care about them",
      "where i stand"
    ],
    "emotions": [
      "longing",
      "hurt",
      "fear",
      "sadness",
      "anxiety",
      "love"
    ],
    "left": "connection, closeness, or attachment being affected",
    "right": "believing a change in closeness proves the bond or your place in it is unsafe",
    "mechanism": "the mind tries to protect connection by reading changes in closeness as larger meaning",
    "effect": "connection pressure can make distance feel personal before the meaning is clear",
    "perspective": "Connection can matter deeply without every shift in closeness becoming proof about your value or the whole bond.",
    "touches": [
      "connection",
      "attachment",
      "closeness",
      "belonging",
      "stability",
      "fear of loss"
    ],
    "pattern": "The pattern can form when connection, closeness, or attachment being affected starts blending with believing a change in closeness proves the bond or your place in it is unsafe. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing a change in closeness proves the bond or your place in it is unsafe is the truth rather than an attached meaning to examine.",
    "forward": "Connection can matter deeply without every shift in closeness becoming proof about your value or the whole bond."
  },
  {
    "key": "trust_and_betrayal",
    "label": "trust and betrayal pressure",
    "terms": [
      "betrayed",
      "betrayal",
      "lied",
      "dishonest",
      "secret",
      "hidden",
      "deceived",
      "broke my trust",
      "mishandled trust",
      "not honest"
    ],
    "emotions": [
      "hurt",
      "betrayed",
      "angry",
      "confused",
      "guarded",
      "unsafe"
    ],
    "left": "trust, honesty, loyalty, or vulnerability being disrupted",
    "right": "believing broken trust proves you were foolish, unsafe, or not enough",
    "mechanism": "reliability breaks and the mind begins questioning what was real and what can still be trusted",
    "effect": "a trust rupture can affect safety, openness, dignity, and reality-confidence",
    "perspective": "Broken trust can be real information without becoming proof that you were wrong to trust or that openness has no safe place.",
    "touches": [
      "trust",
      "vulnerability",
      "honesty",
      "safety",
      "discernment",
      "repair"
    ],
    "pattern": "The pattern can form when trust, honesty, loyalty, or vulnerability being disrupted starts blending with believing broken trust proves you were foolish, unsafe, or not enough. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing broken trust proves you were foolish, unsafe, or not enough is the truth rather than an attached meaning to examine.",
    "forward": "Broken trust can be real information without becoming proof that you were wrong to trust or that openness has no safe place."
  },
  {
    "key": "rejection_and_abandonment",
    "label": "rejection and abandonment pressure",
    "terms": [
      "rejected",
      "unwanted",
      "not chosen",
      "left me",
      "abandoned",
      "replaceable",
      "too much",
      "not enough",
      "did not pick me",
      "didn't pick me"
    ],
    "emotions": [
      "hurt",
      "sadness",
      "fear",
      "unwanted",
      "lonely",
      "ashamed"
    ],
    "left": "being left, not chosen, ignored, excluded, or unwanted",
    "right": "believing someone else's distance or choice decides your value",
    "mechanism": "absence or non-selection attaches to identity and starts feeling like proof against the self",
    "effect": "rejection pain can make the user feel unwanted without proving that they are unwanted",
    "perspective": "Someone else's choice to stay, leave, choose, or distance themselves does not decide your value; you do.",
    "touches": [
      "being wanted",
      "belonging",
      "self-worth",
      "dignity",
      "chosen-ness",
      "identity"
    ],
    "pattern": "The pattern can form when being left, not chosen, ignored, excluded, or unwanted starts blending with believing someone else's distance or choice decides your value. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing someone else's distance or choice decides your value is the truth rather than an attached meaning to examine.",
    "forward": "Someone else's choice to stay, leave, choose, or distance themselves does not decide your value; you do."
  },
  {
    "key": "abandonment_and_inconsistency",
    "label": "abandonment and inconsistency pressure",
    "terms": [
      "inconsistent",
      "hot and cold",
      "mixed signals",
      "actions feel inconsistent",
      "saying they care",
      "say they care",
      "but their actions",
      "energy changed",
      "distant then close",
      "pull away and come back",
      "where i stand",
      "asking for too much",
      "something is off",
      "noticing something is off"
    ],
    "emotions": [
      "confused",
      "hurt",
      "anxious",
      "unsteady",
      "fear",
      "self-doubt"
    ],
    "left": "repeated changes in availability, affection, tone, or responsiveness",
    "right": "believing another person's inconsistent signals mean you caused the instability or must earn steadiness",
    "mechanism": "the mind keeps trying to stabilize a connection whose signals keep changing",
    "effect": "inconsistency can create self-blame because the mind searches for a reason for unstable signals",
    "perspective": "Their inconsistency can be confusing and meaningful to notice without proving that you are asking for too much or that you caused the instability.",
    "touches": [
      "consistency",
      "connection safety",
      "self-blame",
      "uncertainty",
      "relational clarity",
      "steadiness"
    ],
    "pattern": "The pattern can form when repeated changes in availability, affection, tone, or responsiveness starts blending with believing another person's inconsistent signals mean you caused the instability or must earn steadiness. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing another person's inconsistent signals mean you caused the instability or must earn steadiness is the truth rather than an attached meaning to examine.",
    "forward": "Their inconsistency can be confusing and meaningful to notice without proving that you are asking for too much or that you caused the instability."
  },
  {
    "key": "self_worth_and_identity",
    "label": "self-worth and identity pressure",
    "terms": [
      "worthless",
      "my value",
      "my worth",
      "not enough",
      "too much",
      "broken",
      "unlovable",
      "something wrong with me",
      "less valuable",
      "failed as a person"
    ],
    "emotions": [
      "shame",
      "hurt",
      "sadness",
      "fear",
      "small",
      "insecure"
    ],
    "left": "an event, response, mistake, or relationship becoming attached to personal value or identity",
    "right": "believing a painful moment defines who you are or how much value you have",
    "mechanism": "external experience fuses with identity until the event feels like a verdict on the self",
    "effect": "self-worth pressure can make a feeling of low value seem like proof of low value",
    "perspective": "Your value is not decided by another person's reaction, distance, judgment, or choice; you are still the one who owns your value.",
    "touches": [
      "value",
      "identity",
      "dignity",
      "self-recognition",
      "agency",
      "lovability"
    ],
    "pattern": "The pattern can form when an event, response, mistake, or relationship becoming attached to personal value or identity starts blending with believing a painful moment defines who you are or how much value you have. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing a painful moment defines who you are or how much value you have is the truth rather than an attached meaning to examine.",
    "forward": "Your value is not decided by another person's reaction, distance, judgment, or choice; you are still the one who owns your value."
  },
  {
    "key": "identity_confusion_and_self_doubt",
    "label": "identity confusion and self-doubt pressure",
    "terms": [
      "who am i",
      "do not know who i am",
      "don't know who i am",
      "am i wrong",
      "overreacting",
      "am i selfish",
      "am i broken",
      "questioning myself",
      "self doubt",
      "self-doubt",
      "cannot tell if"
    ],
    "emotions": [
      "confused",
      "afraid",
      "ashamed",
      "uncertain",
      "doubtful"
    ],
    "left": "uncertainty about whether the user's reaction, character, or self-understanding is reliable",
    "right": "believing confusion means something is wrong with the self",
    "mechanism": "the mind loses a stable reference point and turns uncertainty into self-suspicion",
    "effect": "self-doubt can make the user question their whole identity when the situation may only need clearer separation",
    "perspective": "Not knowing how to interpret yourself in a situation does not mean your whole self is unreliable.",
    "touches": [
      "self-trust",
      "identity clarity",
      "uncertainty",
      "interpretation",
      "grounding",
      "discernment"
    ],
    "pattern": "The pattern can form when uncertainty about whether the user's reaction, character, or self-understanding is reliable starts blending with believing confusion means something is wrong with the self. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing confusion means something is wrong with the self is the truth rather than an attached meaning to examine.",
    "forward": "Not knowing how to interpret yourself in a situation does not mean your whole self is unreliable."
  },
  {
    "key": "shame_and_embarrassment",
    "label": "shame and embarrassment pressure",
    "terms": [
      "shame",
      "ashamed",
      "embarrassed",
      "humiliated",
      "laughed at",
      "mocked",
      "ridiculed",
      "stupid",
      "dumb",
      "exposed",
      "everyone saw"
    ],
    "emotions": [
      "shame",
      "embarrassment",
      "small",
      "hurt",
      "fear"
    ],
    "left": "being seen in a painful, exposed, imperfect, or judged way",
    "right": "believing a visible moment proves something lower about the self",
    "mechanism": "exposure attaches to identity and the memory returns as if it is evidence",
    "effect": "shame can make one moment feel permanent when it was actually painful and visible",
    "perspective": "Being embarrassed may explain why you feel exposed, but it does not prove your value decreased at all.",
    "touches": [
      "dignity",
      "visibility",
      "confidence",
      "worth",
      "social safety",
      "voice"
    ],
    "pattern": "The pattern can form when being seen in a painful, exposed, imperfect, or judged way starts blending with believing a visible moment proves something lower about the self. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing a visible moment proves something lower about the self is the truth rather than an attached meaning to examine.",
    "forward": "Being embarrassed may explain why you feel exposed, but it does not prove your value decreased at all."
  },
  {
    "key": "guilt_and_responsibility",
    "label": "guilt and responsibility pressure",
    "terms": [
      "guilt",
      "guilty",
      "my fault",
      "responsible",
      "should have",
      "i caused",
      "feel bad",
      "did something wrong",
      "blame myself"
    ],
    "emotions": [
      "guilt",
      "anxiety",
      "sadness",
      "regret",
      "fear"
    ],
    "left": "care, impact, fault, or responsibility becoming emotionally activated",
    "right": "believing feeling guilty proves full responsibility or fault",
    "mechanism": "guilt tries to create control by placing cause inside the self",
    "effect": "guilt can show something mattered without proving the user caused or controlled the outcome",
    "perspective": "Care and responsibility are not automatically the same thing; responsibility needs evidence before it belongs to you.",
    "touches": [
      "care",
      "responsibility",
      "repair",
      "fault",
      "control",
      "clean accountability"
    ],
    "pattern": "The pattern can form when care, impact, fault, or responsibility becoming emotionally activated starts blending with believing feeling guilty proves full responsibility or fault. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing feeling guilty proves full responsibility or fault is the truth rather than an attached meaning to examine.",
    "forward": "Care and responsibility are not automatically the same thing; responsibility needs evidence before it belongs to you."
  },
  {
    "key": "accountability_and_repair",
    "label": "accountability and repair pressure",
    "terms": [
      "apologize",
      "repair",
      "make it right",
      "hurt them",
      "own what i did",
      "take accountability",
      "accountable",
      "fix what i did",
      "do better",
      "amends"
    ],
    "emotions": [
      "guilt",
      "regret",
      "concern",
      "fear",
      "humility"
    ],
    "left": "recognizing possible impact and wanting to respond cleanly without collapsing into self-punishment",
    "right": "believing accountability requires self-attack or begging for relief",
    "mechanism": "responsibility and shame fuse so repair becomes about escaping self-condemnation instead of clear ownership",
    "effect": "repair pressure can become heavy when the user cannot separate clean accountability from identity collapse",
    "perspective": "You can own impact without turning that impact into a sentence against who you are.",
    "touches": [
      "repair",
      "ownership",
      "humility",
      "dignity",
      "clean responsibility",
      "change"
    ],
    "pattern": "The pattern can form when recognizing possible impact and wanting to respond cleanly without collapsing into self-punishment starts blending with believing accountability requires self-attack or begging for relief. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing accountability requires self-attack or begging for relief is the truth rather than an attached meaning to examine.",
    "forward": "You can own impact without turning that impact into a sentence against who you are."
  },
  {
    "key": "grief_and_loss",
    "label": "grief and loss pressure",
    "terms": [
      "grief",
      "loss",
      "lost",
      "gone",
      "miss them",
      "death",
      "died",
      "no longer here",
      "ended",
      "absence",
      "empty"
    ],
    "emotions": [
      "sadness",
      "grief",
      "longing",
      "love",
      "emptiness",
      "fear"
    ],
    "left": "a person, bond, future, routine, or version of life no longer being present the same way",
    "right": "believing absence means love, happiness, or future connection are gone completely",
    "mechanism": "love keeps reaching for what is absent and the absence becomes emotionally repeated",
    "effect": "grief can make the future feel smaller because the mind keeps meeting what is missing",
    "perspective": "Loss can be real without deciding that love, connection, or happiness are gone from your life completely.",
    "touches": [
      "love",
      "absence",
      "memory",
      "future",
      "routine",
      "continuity"
    ],
    "pattern": "The pattern can form when a person, bond, future, routine, or version of life no longer being present the same way starts blending with believing absence means love, happiness, or future connection are gone completely. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing absence means love, happiness, or future connection are gone completely is the truth rather than an attached meaning to examine.",
    "forward": "Loss can be real without deciding that love, connection, or happiness are gone from your life completely."
  },
  {
    "key": "fear_and_anxiety",
    "label": "fear and anxiety pressure",
    "terms": [
      "afraid",
      "fear",
      "scared",
      "anxious",
      "anxiety",
      "panic",
      "worried",
      "what if",
      "unsafe",
      "nervous",
      "dread"
    ],
    "emotions": [
      "fear",
      "anxiety",
      "panic",
      "uncertainty",
      "tension"
    ],
    "left": "uncertainty or possible danger becoming emotionally amplified",
    "right": "believing fear is proof that the feared outcome is coming",
    "mechanism": "the mind treats possibility like prediction and begins preparing for an outcome that is not fully known",
    "effect": "fear can make imagined outcomes feel closer than the evidence supports",
    "perspective": "Fear may show that something feels uncertain or important, but it does not automatically predict what will happen.",
    "touches": [
      "safety",
      "uncertainty",
      "prediction",
      "control",
      "steadiness",
      "possibility"
    ],
    "pattern": "The pattern can form when uncertainty or possible danger becoming emotionally amplified starts blending with believing fear is proof that the feared outcome is coming. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing fear is proof that the feared outcome is coming is the truth rather than an attached meaning to examine.",
    "forward": "Fear may show that something feels uncertain or important, but it does not automatically predict what will happen."
  },
  {
    "key": "anger_and_injustice",
    "label": "anger and injustice pressure",
    "terms": [
      "angry",
      "mad",
      "pissed",
      "furious",
      "unfair",
      "injustice",
      "crossed",
      "disrespected",
      "dismissed",
      "not right"
    ],
    "emotions": [
      "anger",
      "hurt",
      "frustration",
      "resentment",
      "defensiveness"
    ],
    "left": "something feeling unfair, crossed, dismissed, or not respected",
    "right": "believing anger alone explains the whole situation or gives the response its direction",
    "mechanism": "anger points to a possible violation and can push toward reaction before separation happens",
    "effect": "anger may carry important information while still needing clarity and control before action",
    "perspective": "Anger can point to what felt crossed without deciding how you respond.",
    "touches": [
      "fairness",
      "respect",
      "control",
      "clarity",
      "limits",
      "self-respect"
    ],
    "pattern": "The pattern can form when something feeling unfair, crossed, dismissed, or not respected starts blending with believing anger alone explains the whole situation or gives the response its direction. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing anger alone explains the whole situation or gives the response its direction is the truth rather than an attached meaning to examine.",
    "forward": "Anger can point to what felt crossed without deciding how you respond."
  },
  {
    "key": "resentment_and_bitterness",
    "label": "resentment and bitterness pressure",
    "terms": [
      "resent",
      "resentment",
      "bitter",
      "fed up",
      "tired of giving",
      "always me",
      "unappreciated",
      "taken for granted",
      "kept it in"
    ],
    "emotions": [
      "resentment",
      "anger",
      "hurt",
      "exhaustion",
      "disappointment"
    ],
    "left": "unmet needs, ignored limits, or repeated imbalance accumulating over time",
    "right": "believing the only options are swallowing the hurt or hardening against the person",
    "mechanism": "unspoken pain repeats until care turns into guardedness or bitterness",
    "effect": "resentment can show where something mattered for too long without being named or repaired",
    "perspective": "Resentment may be showing an unmet need or repeated imbalance, not proof that you are wrong for caring.",
    "touches": [
      "unmet need",
      "imbalance",
      "limits",
      "repair",
      "honesty",
      "self-protection"
    ],
    "pattern": "The pattern can form when unmet needs, ignored limits, or repeated imbalance accumulating over time starts blending with believing the only options are swallowing the hurt or hardening against the person. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing the only options are swallowing the hurt or hardening against the person is the truth rather than an attached meaning to examine.",
    "forward": "Resentment may be showing an unmet need or repeated imbalance, not proof that you are wrong for caring."
  },
  {
    "key": "jealousy_and_envy",
    "label": "jealousy and envy pressure",
    "terms": [
      "jealous",
      "jealousy",
      "envy",
      "envious",
      "they got",
      "someone else got",
      "wanted that",
      "why them",
      "not me",
      "bothered me"
    ],
    "emotions": [
      "jealousy",
      "envy",
      "shame",
      "sadness",
      "longing"
    ],
    "left": "someone else having attention, closeness, progress, recognition, or opportunity the user wanted",
    "right": "believing another person's gain lowers the user's value or possibility",
    "mechanism": "desire and comparison fuse so another person's good moment starts feeling like a judgment",
    "effect": "envy can reveal desire while shame tries to turn that desire into inferiority",
    "perspective": "Someone else having something does not lower your value; it may show you something you want, but it does not make you less.",
    "touches": [
      "desire",
      "comparison",
      "recognition",
      "worth",
      "possibility",
      "longing"
    ],
    "pattern": "The pattern can form when someone else having attention, closeness, progress, recognition, or opportunity the user wanted starts blending with believing another person's gain lowers the user's value or possibility. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing another person's gain lowers the user's value or possibility is the truth rather than an attached meaning to examine.",
    "forward": "Someone else having something does not lower your value; it may show you something you want, but it does not make you less."
  },
  {
    "key": "loneliness_and_belonging",
    "label": "loneliness and belonging pressure",
    "terms": [
      "lonely",
      "alone",
      "left out",
      "forgotten",
      "unseen",
      "excluded",
      "no one notices",
      "do not belong",
      "don't belong",
      "disconnected"
    ],
    "emotions": [
      "loneliness",
      "sadness",
      "hurt",
      "longing",
      "emptiness"
    ],
    "left": "lack of felt connection, inclusion, being seen, or belonging",
    "right": "believing loneliness proves the user is unwanted or does not belong anywhere",
    "mechanism": "absence of connection attaches to identity and starts feeling like evidence of unworthiness",
    "effect": "loneliness can make disconnection feel like a statement about the self",
    "perspective": "Feeling lonely can show connection matters without proving that you are unwanted or without a place.",
    "touches": [
      "belonging",
      "connection",
      "being seen",
      "inclusion",
      "self-recognition",
      "hope"
    ],
    "pattern": "The pattern can form when lack of felt connection, inclusion, being seen, or belonging starts blending with believing loneliness proves the user is unwanted or does not belong anywhere. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing loneliness proves the user is unwanted or does not belong anywhere is the truth rather than an attached meaning to examine.",
    "forward": "Feeling lonely can show connection matters without proving that you are unwanted or without a place."
  },
  {
    "key": "boundaries_and_respect",
    "label": "boundaries and respect pressure",
    "terms": [
      "boundary",
      "boundaries",
      "say no",
      "said no",
      "saying no",
      "need space",
      "limit",
      "limits",
      "protect my peace",
      "respect my boundary"
    ],
    "emotions": [
      "guilt",
      "fear",
      "anger",
      "self-doubt",
      "relief"
    ],
    "left": "personal limits, capacity, consent, or self-preservation needing recognition",
    "right": "believing a boundary makes the user selfish, harsh, or responsible for another person's discomfort",
    "mechanism": "respect and connection get fused so the user fears limits will harm the bond",
    "effect": "boundary pressure can make self-preservation feel like wrongdoing",
    "perspective": "A boundary can affect someone without proving you are selfish for having a limit.",
    "touches": [
      "respect",
      "capacity",
      "limits",
      "self-preservation",
      "connection",
      "agency"
    ],
    "pattern": "The pattern can form when personal limits, capacity, consent, or self-preservation needing recognition starts blending with believing a boundary makes the user selfish, harsh, or responsible for another person's discomfort. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing a boundary makes the user selfish, harsh, or responsible for another person's discomfort is the truth rather than an attached meaning to examine.",
    "forward": "A boundary can affect someone without proving you are selfish for having a limit."
  },
  {
    "key": "disrespect_and_dismissal",
    "label": "disrespect and dismissal pressure",
    "terms": [
      "disrespect",
      "disrespected",
      "dismissed",
      "brushed off",
      "not taken seriously",
      "ignored what i said",
      "talked down",
      "treated like i was nothing"
    ],
    "emotions": [
      "anger",
      "hurt",
      "shame",
      "frustration",
      "sadness"
    ],
    "left": "the user feeling not considered, heard, valued, or taken seriously",
    "right": "believing being dismissed proves the user's voice or feelings have less value",
    "mechanism": "dismissal hits dignity and can make the user question whether their reality deserves space",
    "effect": "disrespect can hurt because it affects voice, dignity, and being considered",
    "perspective": "Being dismissed may explain why you feel hurt or angry, but it does not prove your voice has less value.",
    "touches": [
      "dignity",
      "voice",
      "respect",
      "being considered",
      "fairness",
      "self-respect"
    ],
    "pattern": "The pattern can form when the user feeling not considered, heard, valued, or taken seriously starts blending with believing being dismissed proves the user's voice or feelings have less value. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing being dismissed proves the user's voice or feelings have less value is the truth rather than an attached meaning to examine.",
    "forward": "Being dismissed may explain why you feel hurt or angry, but it does not prove your voice has less value."
  },
  {
    "key": "invalidation_and_unheardness",
    "label": "invalidation and unheardness pressure",
    "terms": [
      "invalidated",
      "unheard",
      "not heard",
      "misunderstood",
      "minimized",
      "overexplaining",
      "dramatic",
      "too sensitive",
      "they do not get it",
      "they don't get it"
    ],
    "emotions": [
      "hurt",
      "frustration",
      "loneliness",
      "anger",
      "self-doubt"
    ],
    "left": "the user's feelings or reality being minimized, misunderstood, or not received",
    "right": "believing being misunderstood means the feeling is not real or needs endless defense",
    "mechanism": "the user starts fighting to prove reality instead of simply recognizing what was affected",
    "effect": "invalidation can make the person feel alone inside their own experience",
    "perspective": "Not being understood by someone else does not make your experience unreal.",
    "touches": [
      "being heard",
      "emotional reality",
      "clarity",
      "dignity",
      "self-trust",
      "communication"
    ],
    "pattern": "The pattern can form when the user's feelings or reality being minimized, misunderstood, or not received starts blending with believing being misunderstood means the feeling is not real or needs endless defense. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing being misunderstood means the feeling is not real or needs endless defense is the truth rather than an attached meaning to examine.",
    "forward": "Not being understood by someone else does not make your experience unreal."
  },
  {
    "key": "conflict_and_disconnection",
    "label": "conflict and disconnection pressure",
    "terms": [
      "conflict",
      "argument",
      "argued",
      "fight",
      "fighting",
      "tension",
      "disconnected",
      "not talking",
      "falling out",
      "distance after conflict"
    ],
    "emotions": [
      "anger",
      "fear",
      "sadness",
      "confusion",
      "hurt"
    ],
    "left": "relational tension, rupture, disagreement, or emotional distance after friction",
    "right": "believing tension means the connection is unsafe, ending, or beyond repair",
    "mechanism": "conflict activates prediction and attachment fear before the rupture is fully understood",
    "effect": "conflict can make distance feel final before there is enough clarity",
    "perspective": "Tension can matter without automatically meaning the connection is gone or that repair is impossible.",
    "touches": [
      "rupture",
      "repair",
      "connection",
      "safety",
      "communication",
      "uncertainty"
    ],
    "pattern": "The pattern can form when relational tension, rupture, disagreement, or emotional distance after friction starts blending with believing tension means the connection is unsafe, ending, or beyond repair. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing tension means the connection is unsafe, ending, or beyond repair is the truth rather than an attached meaning to examine.",
    "forward": "Tension can matter without automatically meaning the connection is gone or that repair is impossible."
  },
  {
    "key": "control_and_uncertainty",
    "label": "control and uncertainty pressure",
    "terms": [
      "uncertain",
      "uncertainty",
      "do not know",
      "don't know",
      "cannot control",
      "can't control",
      "need to know",
      "waiting",
      "unknown",
      "no answer"
    ],
    "emotions": [
      "anxiety",
      "fear",
      "frustration",
      "confusion",
      "helplessness"
    ],
    "left": "lack of certainty, control, answer, timing, or outcome",
    "right": "believing uncertainty itself means something bad or personal is happening",
    "mechanism": "the mind tries to reduce discomfort by filling unknowns with conclusions",
    "effect": "uncertainty can pressure the mind into treating guesses like facts",
    "perspective": "Not knowing yet is uncomfortable, but uncertainty is not the same as proof.",
    "touches": [
      "uncertainty",
      "control",
      "waiting",
      "prediction",
      "patience",
      "grounding"
    ],
    "pattern": "The pattern can form when lack of certainty, control, answer, timing, or outcome starts blending with believing uncertainty itself means something bad or personal is happening. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing uncertainty itself means something bad or personal is happening is the truth rather than an attached meaning to examine.",
    "forward": "Not knowing yet is uncomfortable, but uncertainty is not the same as proof."
  },
  {
    "key": "overwhelm_and_pressure",
    "label": "overwhelm and pressure category",
    "terms": [
      "overwhelmed",
      "too much",
      "pressure",
      "stressed",
      "burned out",
      "burnt out",
      "cannot keep up",
      "can't keep up",
      "everything at once",
      "heavy"
    ],
    "emotions": [
      "overwhelm",
      "stress",
      "exhaustion",
      "fear",
      "frustration"
    ],
    "left": "too many demands, emotions, tasks, expectations, or meanings pressing at once",
    "right": "believing overwhelm means the user is incapable or failing",
    "mechanism": "the whole pile gets treated as one impossible problem",
    "effect": "overwhelm can make capacity feel like character failure",
    "perspective": "Being overwhelmed means the load is heavy; it does not prove you are incapable.",
    "touches": [
      "capacity",
      "load",
      "pressure",
      "energy",
      "order",
      "next step"
    ],
    "pattern": "The pattern can form when too many demands, emotions, tasks, expectations, or meanings pressing at once starts blending with believing overwhelm means the user is incapable or failing. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing overwhelm means the user is incapable or failing is the truth rather than an attached meaning to examine.",
    "forward": "Being overwhelmed means the load is heavy; it does not prove you are incapable."
  },
  {
    "key": "helplessness_and_powerlessness",
    "label": "helplessness and powerlessness pressure",
    "terms": [
      "helpless",
      "powerless",
      "nothing i do",
      "no matter what",
      "stuck",
      "trapped",
      "cannot change",
      "can't change",
      "out of my hands"
    ],
    "emotions": [
      "helplessness",
      "sadness",
      "fear",
      "anger",
      "hopelessness"
    ],
    "left": "feeling unable to affect the situation, outcome, or pattern",
    "right": "believing lack of control means there is no agency left anywhere",
    "mechanism": "the mind collapses possibility because the main outcome cannot be controlled",
    "effect": "powerlessness can make all movement feel impossible even when small agency still exists",
    "perspective": "Not controlling the whole outcome does not mean you have no agency at all.",
    "touches": [
      "agency",
      "limits",
      "control",
      "possibility",
      "endurance",
      "small movement"
    ],
    "pattern": "The pattern can form when feeling unable to affect the situation, outcome, or pattern starts blending with believing lack of control means there is no agency left anywhere. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing lack of control means there is no agency left anywhere is the truth rather than an attached meaning to examine.",
    "forward": "Not controlling the whole outcome does not mean you have no agency at all."
  },
  {
    "key": "numbness_and_shutdown",
    "label": "numbness and shutdown pressure",
    "terms": [
      "numb",
      "nothing",
      "blank",
      "shut down",
      "shutdown",
      "disconnected from it",
      "do not feel",
      "don't feel",
      "emotionally tired",
      "checked out"
    ],
    "emotions": [
      "numbness",
      "emptiness",
      "exhaustion",
      "confusion",
      "distance"
    ],
    "left": "emotional access reducing after pressure, shock, exhaustion, or overload",
    "right": "believing numbness means the user does not care or something is wrong with them",
    "mechanism": "the system lowers feeling access to reduce load, but the absence of feeling gets interpreted as identity failure",
    "effect": "numbness can be a protective reduction in access rather than proof of coldness",
    "perspective": "Feeling numb does not automatically mean something is wrong with you or that you do not care.",
    "touches": [
      "protection",
      "capacity",
      "emotional access",
      "shutdown",
      "care",
      "rest"
    ],
    "pattern": "The pattern can form when emotional access reducing after pressure, shock, exhaustion, or overload starts blending with believing numbness means the user does not care or something is wrong with them. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing numbness means the user does not care or something is wrong with them is the truth rather than an attached meaning to examine.",
    "forward": "Feeling numb does not automatically mean something is wrong with you or that you do not care."
  },
  {
    "key": "regret_and_past_meaning",
    "label": "regret and past meaning pressure",
    "terms": [
      "regret",
      "wish i had",
      "should have",
      "if only",
      "past",
      "cannot stop thinking",
      "can't stop thinking",
      "replay",
      "what i should have done"
    ],
    "emotions": [
      "regret",
      "sadness",
      "guilt",
      "shame",
      "longing"
    ],
    "left": "past choices or moments being reinterpreted through current pain",
    "right": "believing a past choice permanently defines the self or ruined the future",
    "mechanism": "the mind re-enters the past looking for control that is no longer available",
    "effect": "regret can keep the past active as if rethinking it can change it",
    "perspective": "Regret can teach without becoming a permanent sentence against who you are.",
    "touches": [
      "past",
      "learning",
      "self-forgiveness",
      "responsibility",
      "release",
      "meaning"
    ],
    "pattern": "The pattern can form when past choices or moments being reinterpreted through current pain starts blending with believing a past choice permanently defines the self or ruined the future. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing a past choice permanently defines the self or ruined the future is the truth rather than an attached meaning to examine.",
    "forward": "Regret can teach without becoming a permanent sentence against who you are."
  },
  {
    "key": "comparison_and_inferiority",
    "label": "comparison and inferiority pressure",
    "terms": [
      "compare",
      "comparison",
      "behind",
      "inferior",
      "less than",
      "not as good",
      "not doing enough",
      "everyone else",
      "their progress",
      "my progress"
    ],
    "emotions": [
      "envy",
      "shame",
      "sadness",
      "insecurity",
      "pressure"
    ],
    "left": "measuring the self against another person's progress, recognition, appearance, relationship, or position",
    "right": "believing someone else's place proves the user is behind or less valuable",
    "mechanism": "comparison turns another person's information into a measurement of identity",
    "effect": "comparison can make another person's movement feel like evidence against the self",
    "perspective": "Their progress does not lower your value or decide your timing.",
    "touches": [
      "worth",
      "progress",
      "timing",
      "recognition",
      "identity",
      "possibility"
    ],
    "pattern": "The pattern can form when measuring the self against another person's progress, recognition, appearance, relationship, or position starts blending with believing someone else's place proves the user is behind or less valuable. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing someone else's place proves the user is behind or less valuable is the truth rather than an attached meaning to examine.",
    "forward": "Their progress does not lower your value or decide your timing."
  },
  {
    "key": "love_and_vulnerability",
    "label": "love and vulnerability pressure",
    "terms": [
      "love",
      "care about them",
      "vulnerable",
      "opened up",
      "let them in",
      "feel deeply",
      "afraid to love",
      "loving them",
      "heart open"
    ],
    "emotions": [
      "love",
      "fear",
      "tenderness",
      "hurt",
      "hope"
    ],
    "left": "care, openness, emotional exposure, or tenderness becoming active",
    "right": "believing vulnerability makes the user weak, unsafe, or too exposed",
    "mechanism": "love opens access and the risk of being hurt becomes attached to the openness itself",
    "effect": "vulnerability can feel dangerous because something meaningful is exposed",
    "perspective": "Being vulnerable can carry risk without making the openness itself wrong.",
    "touches": [
      "love",
      "openness",
      "tenderness",
      "risk",
      "trust",
      "courage"
    ],
    "pattern": "The pattern can form when care, openness, emotional exposure, or tenderness becoming active starts blending with believing vulnerability makes the user weak, unsafe, or too exposed. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing vulnerability makes the user weak, unsafe, or too exposed is the truth rather than an attached meaning to examine.",
    "forward": "Being vulnerable can carry risk without making the openness itself wrong."
  },
  {
    "key": "loyalty_and_being_chosen",
    "label": "loyalty and being chosen pressure",
    "terms": [
      "loyal",
      "loyalty",
      "chosen",
      "choose me",
      "chose someone else",
      "show up for them",
      "they do not show up",
      "don't show up",
      "not picked",
      "priority"
    ],
    "emotions": [
      "hurt",
      "jealousy",
      "sadness",
      "anger",
      "longing"
    ],
    "left": "showing up, choosing, prioritizing, or being chosen not feeling mutual",
    "right": "believing not being chosen proves the user was not worth choosing",
    "mechanism": "loyalty imbalance attaches to worth and creates pain around priority and reciprocity",
    "effect": "not being chosen can hurt without becoming the measure of the user's value",
    "perspective": "Someone else failing to choose you well does not decide whether you are worth choosing.",
    "touches": [
      "loyalty",
      "reciprocity",
      "priority",
      "chosen-ness",
      "worth",
      "dignity"
    ],
    "pattern": "The pattern can form when showing up, choosing, prioritizing, or being chosen not feeling mutual starts blending with believing not being chosen proves the user was not worth choosing. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing not being chosen proves the user was not worth choosing is the truth rather than an attached meaning to examine.",
    "forward": "Someone else failing to choose you well does not decide whether you are worth choosing."
  },
  {
    "key": "forgiveness_and_reconciliation",
    "label": "forgiveness and reconciliation pressure",
    "terms": [
      "forgive",
      "forgiveness",
      "forgave",
      "reconcile",
      "reconciliation",
      "second chance",
      "take them back",
      "move past it",
      "repair the relationship"
    ],
    "emotions": [
      "hurt",
      "hope",
      "fear",
      "resentment",
      "confusion"
    ],
    "left": "repair, returning, forgiving, or considering reconciliation after hurt",
    "right": "believing forgiveness means ignoring impact or returning before safety/clarity exists",
    "mechanism": "the desire for peace gets fused with pressure to erase what still needs understanding",
    "effect": "forgiveness pressure can make repair feel required before the injury has been processed",
    "perspective": "Forgiveness does not have to erase what happened or remove the need for consistency, respect, and repair.",
    "touches": [
      "repair",
      "trust",
      "accountability",
      "return",
      "boundaries",
      "discernment"
    ],
    "pattern": "The pattern can form when repair, returning, forgiving, or considering reconciliation after hurt starts blending with believing forgiveness means ignoring impact or returning before safety/clarity exists. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing forgiveness means ignoring impact or returning before safety/clarity exists is the truth rather than an attached meaning to examine.",
    "forward": "Forgiveness does not have to erase what happened or remove the need for consistency, respect, and repair."
  },
  {
    "key": "emotional_dependence_and_reassurance",
    "label": "emotional dependence and reassurance pressure",
    "terms": [
      "reassurance",
      "reassure",
      "need them to tell me",
      "need to hear",
      "clingy",
      "needy",
      "depend on",
      "keep asking",
      "clarity from them",
      "need proof"
    ],
    "emotions": [
      "anxiety",
      "fear",
      "shame",
      "longing",
      "insecurity"
    ],
    "left": "needing external steadiness, confirmation, or reassurance to calm uncertainty",
    "right": "believing needing reassurance makes the user burdensome or unable to trust themselves",
    "mechanism": "the mind seeks outside confirmation to stabilize an attached fear",
    "effect": "reassurance can help briefly while also becoming tied to shame if the need is judged",
    "perspective": "Needing reassurance can show something feels uncertain without proving you are a burden.",
    "touches": [
      "reassurance",
      "self-trust",
      "connection safety",
      "uncertainty",
      "shame",
      "steadiness"
    ],
    "pattern": "The pattern can form when needing external steadiness, confirmation, or reassurance to calm uncertainty starts blending with believing needing reassurance makes the user burdensome or unable to trust themselves. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing needing reassurance makes the user burdensome or unable to trust themselves is the truth rather than an attached meaning to examine.",
    "forward": "Needing reassurance can show something feels uncertain without proving you are a burden."
  },
  {
    "key": "hope_and_disappointment",
    "label": "hope and disappointment pressure",
    "terms": [
      "hope",
      "hopeful",
      "disappointed",
      "let down",
      "got my hopes up",
      "foolish for hoping",
      "expected more",
      "wanted it to work"
    ],
    "emotions": [
      "hope",
      "sadness",
      "disappointment",
      "fear",
      "longing"
    ],
    "left": "wanting something to be possible while fearing or feeling the pain of it not happening",
    "right": "believing disappointment proves hope was foolish",
    "mechanism": "hope and pain attach so the mind tries to protect itself by distrusting hope",
    "effect": "disappointment can make hope feel unsafe even when hope was human and meaningful",
    "perspective": "Being disappointed does not mean you were foolish for hoping.",
    "touches": [
      "hope",
      "possibility",
      "disappointment",
      "trust",
      "future",
      "openness"
    ],
    "pattern": "The pattern can form when wanting something to be possible while fearing or feeling the pain of it not happening starts blending with believing disappointment proves hope was foolish. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing disappointment proves hope was foolish is the truth rather than an attached meaning to examine.",
    "forward": "Being disappointed does not mean you were foolish for hoping."
  },
  {
    "key": "relief_and_permission",
    "label": "relief and permission pressure",
    "terms": [
      "relief",
      "relieved",
      "permission",
      "allowed to",
      "free",
      "lighter",
      "finally okay",
      "peaceful",
      "less heavy"
    ],
    "emotions": [
      "relief",
      "peace",
      "guilt",
      "fear",
      "softness"
    ],
    "left": "pressure reducing and the user feeling allowed to breathe, release, or feel okay",
    "right": "believing relief means the user did not care enough or is wrong for feeling lighter",
    "mechanism": "the mind checks relief for guilt instead of letting the pressure reduce",
    "effect": "relief can feel suspicious when the user is used to carrying weight",
    "perspective": "Feeling relief does not mean you did not care; it may mean something inside finally got room to breathe.",
    "touches": [
      "permission",
      "peace",
      "release",
      "capacity",
      "care",
      "lightness"
    ],
    "pattern": "The pattern can form when pressure reducing and the user feeling allowed to breathe, release, or feel okay starts blending with believing relief means the user did not care enough or is wrong for feeling lighter. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing relief means the user did not care enough or is wrong for feeling lighter is the truth rather than an attached meaning to examine.",
    "forward": "Feeling relief does not mean you did not care; it may mean something inside finally got room to breathe."
  },
  {
    "key": "pride_and_visibility",
    "label": "pride and visibility pressure",
    "terms": [
      "proud",
      "pride",
      "visible",
      "seen",
      "recognition",
      "noticed",
      "attention",
      "arrogant",
      "showing up",
      "confidence"
    ],
    "emotions": [
      "pride",
      "confidence",
      "fear",
      "shame",
      "joy"
    ],
    "left": "being seen positively, receiving progress, or feeling proud",
    "right": "believing pride or visibility means arrogance or danger",
    "mechanism": "good recognition activates self-monitoring before confidence can settle",
    "effect": "pride can be interrupted when visibility feels unsafe or morally suspicious",
    "perspective": "You can recognize your growth without that recognition becoming arrogance.",
    "touches": [
      "visibility",
      "confidence",
      "recognition",
      "humility",
      "growth",
      "permission"
    ],
    "pattern": "The pattern can form when being seen positively, receiving progress, or feeling proud starts blending with believing pride or visibility means arrogance or danger. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing pride or visibility means arrogance or danger is the truth rather than an attached meaning to examine.",
    "forward": "You can recognize your growth without that recognition becoming arrogance."
  },
  {
    "key": "change_and_transition",
    "label": "change and transition pressure",
    "terms": [
      "change",
      "transition",
      "new chapter",
      "moving on",
      "different now",
      "starting over",
      "unknown future",
      "adjusting",
      "life is changing"
    ],
    "emotions": [
      "fear",
      "hope",
      "sadness",
      "uncertainty",
      "relief"
    ],
    "left": "movement between old and new versions of life, identity, routine, or relationship",
    "right": "believing change means losing the self, the past, or all stability",
    "mechanism": "the mind tries to preserve continuity while the outer structure shifts",
    "effect": "transition can feel destabilizing because identity and routine have to reorganize",
    "perspective": "Change can be real and unsettling without meaning you are losing yourself.",
    "touches": [
      "continuity",
      "identity",
      "future",
      "adjustment",
      "stability",
      "growth"
    ],
    "pattern": "The pattern can form when movement between old and new versions of life, identity, routine, or relationship starts blending with believing change means losing the self, the past, or all stability. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing change means losing the self, the past, or all stability is the truth rather than an attached meaning to examine.",
    "forward": "Change can be real and unsettling without meaning you are losing yourself."
  },
  {
    "key": "motivation_and_avoidance",
    "label": "motivation and avoidance pressure",
    "terms": [
      "avoid",
      "avoiding",
      "motivation",
      "unmotivated",
      "procrastinate",
      "procrastinating",
      "putting it off",
      "cannot start",
      "can't start",
      "stuck starting"
    ],
    "emotions": [
      "pressure",
      "guilt",
      "fear",
      "shame",
      "overwhelm"
    ],
    "left": "wanting or needing movement while avoidance, fear, pressure, or low energy blocks starting",
    "right": "believing avoidance proves laziness or failure",
    "mechanism": "pressure attaches to the task until starting feels like facing the whole self-judgment at once",
    "effect": "avoidance can be a pressure response, not automatic proof of laziness",
    "perspective": "Difficulty starting may show pressure around the task, not proof that you are lazy or incapable.",
    "touches": [
      "movement",
      "pressure",
      "energy",
      "start point",
      "self-judgment",
      "capacity"
    ],
    "pattern": "The pattern can form when wanting or needing movement while avoidance, fear, pressure, or low energy blocks starting starts blending with believing avoidance proves laziness or failure. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing avoidance proves laziness or failure is the truth rather than an attached meaning to examine.",
    "forward": "Difficulty starting may show pressure around the task, not proof that you are lazy or incapable."
  },
  {
    "key": "practical_clarity",
    "label": "practical clarity category",
    "terms": [
      "task",
      "tasks",
      "clean",
      "room",
      "bill",
      "appointment",
      "schedule",
      "organize",
      "next step",
      "to do",
      "todo",
      "errand",
      "email"
    ],
    "emotions": [
      "overwhelm",
      "stress",
      "confusion"
    ],
    "left": "a practical task, choice, list, or next-step problem needing order",
    "right": "turning a practical pile into identity judgment",
    "mechanism": "separate tasks compete for attention and begin feeling like one large problem",
    "effect": "practical pressure needs organization before it becomes self-meaning",
    "perspective": "This can stay practical: the pile is separate steps asking for order, not proof against who you are.",
    "touches": [
      "order",
      "attention",
      "next step",
      "time",
      "energy",
      "clarity"
    ],
    "pattern": "The pattern can form when a practical task, choice, list, or next-step problem needing order starts blending with turning a practical pile into identity judgment. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that turning a practical pile into identity judgment is the truth rather than an attached meaning to examine.",
    "forward": "This can stay practical: the pile is separate steps asking for order, not proof against who you are."
  },
  {
    "key": "positive_growth_and_security",
    "label": "positive growth and security category",
    "terms": [
      "growth",
      "secure",
      "security",
      "safe",
      "stable",
      "better",
      "progress",
      "healing",
      "improving",
      "doing better",
      "stronger"
    ],
    "emotions": [
      "hope",
      "peace",
      "pride",
      "relief",
      "confidence"
    ],
    "left": "positive movement, stability, or security becoming noticeable",
    "right": "distrusting growth because it feels unfamiliar or temporary",
    "mechanism": "the system checks good movement for danger instead of letting it become steady",
    "effect": "growth can feel unfamiliar before it feels safe",
    "perspective": "Feeling more stable can be trusted gradually without needing to prove it will never change.",
    "touches": [
      "growth",
      "security",
      "confidence",
      "continuity",
      "trust",
      "stability"
    ],
    "pattern": "The pattern can form when positive movement, stability, or security becoming noticeable starts blending with distrusting growth because it feels unfamiliar or temporary. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that distrusting growth because it feels unfamiliar or temporary is the truth rather than an attached meaning to examine.",
    "forward": "Feeling more stable can be trusted gradually without needing to prove it will never change."
  },
  {
    "key": "transition_from_pain_to_growth",
    "label": "transition from pain to growth pressure",
    "terms": [
      "moving forward",
      "getting better",
      "starting to understand",
      "still hurts but",
      "learning from it",
      "rebuilding",
      "growing from it",
      "turning point"
    ],
    "emotions": [
      "hope",
      "sadness",
      "relief",
      "fear",
      "pride"
    ],
    "left": "the middle stage where pain is still real but understanding or movement is beginning",
    "right": "believing growth requires being fully over the pain",
    "mechanism": "pain and movement coexist while the mind learns a cleaner meaning",
    "effect": "transition can feel strange because the user is not who they were but not fully settled yet",
    "perspective": "You can be growing and still feel the pain; movement does not require pretending it never hurt.",
    "touches": [
      "growth",
      "pain",
      "integration",
      "movement",
      "continuity",
      "rebuilding"
    ],
    "pattern": "The pattern can form when the middle stage where pain is still real but understanding or movement is beginning starts blending with believing growth requires being fully over the pain. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing growth requires being fully over the pain is the truth rather than an attached meaning to examine.",
    "forward": "You can be growing and still feel the pain; movement does not require pretending it never hurt."
  },
  {
    "key": "mixed_emotional_states",
    "label": "mixed emotional states category",
    "terms": [
      "mixed feelings",
      "both",
      "part of me",
      "conflicted",
      "happy but",
      "sad but",
      "angry but",
      "relieved but",
      "confusing because"
    ],
    "emotions": [
      "confusion",
      "sadness",
      "hope",
      "relief",
      "anger"
    ],
    "left": "two or more emotional truths being active at the same time",
    "right": "believing one feeling cancels out or invalidates the other",
    "mechanism": "the mind tries to force a single conclusion when the situation carries more than one truth",
    "effect": "mixed emotions can be confusing because each feeling is responding to a different part of the situation",
    "perspective": "More than one feeling can be real at the same time without either one having to erase the other.",
    "touches": [
      "complexity",
      "emotional truth",
      "both-and",
      "clarity",
      "integration",
      "permission"
    ],
    "pattern": "The pattern can form when two or more emotional truths being active at the same time starts blending with believing one feeling cancels out or invalidates the other. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that believing one feeling cancels out or invalidates the other is the truth rather than an attached meaning to examine.",
    "forward": "More than one feeling can be real at the same time without either one having to erase the other."
  },
  {
    "key": "safety_scope_boundary",
    "label": "safety scope boundary category",
    "terms": [
      "suicide",
      "kill myself",
      "hurt myself",
      "self harm",
      "abuse",
      "assault",
      "danger",
      "unsafe right now",
      "hotline",
      "crisis"
    ],
    "emotions": [
      "fear",
      "panic",
      "danger",
      "despair"
    ],
    "left": "risk, crisis, abuse, self-harm, or immediate safety concern being present",
    "right": "treating a safety-critical prompt as normal interpretation",
    "mechanism": "the system must route out of Compass reflection and toward direct support resources",
    "effect": "safety scope is not a clarity reflection; it requires boundary handling and appropriate support",
    "perspective": "When safety risk is present, Compass should not interpret deeply; it should direct toward immediate support and appropriate resources.",
    "touches": [
      "safety",
      "crisis",
      "support",
      "boundary",
      "protection",
      "resources"
    ],
    "pattern": "The pattern can form when risk, crisis, abuse, self-harm, or immediate safety concern being present starts blending with treating a safety-critical prompt as normal interpretation. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that treating a safety-critical prompt as normal interpretation is the truth rather than an attached meaning to examine.",
    "forward": "When safety risk is present, Compass should not interpret deeply; it should direct toward immediate support and appropriate resources."
  },
  {
    "key": "general_fallback",
    "label": "general fallback category",
    "terms": [
      "something feels off",
      "i do not know",
      "i don't know",
      "hard to explain",
      "confusing",
      "affected me",
      "heavy",
      "not sure what it means"
    ],
    "emotions": [
      "confusion",
      "hurt",
      "uncertainty",
      "pressure"
    ],
    "left": "unspecified emotional pressure where the exact route is not clear enough yet",
    "right": "accepting a broad conclusion before the specific meaning is identified",
    "mechanism": "a real feeling has weight but the attached meaning is not specific enough to route safely",
    "effect": "general fallback should be temporary and should not replace specific recognition when signals are available",
    "perspective": "The feeling can be real while the meaning still needs clearer identification before becoming a conclusion.",
    "touches": [
      "meaning",
      "uncertainty",
      "clarity",
      "interpretation",
      "specificity",
      "grounding"
    ],
    "pattern": "The pattern can form when unspecified emotional pressure where the exact route is not clear enough yet starts blending with accepting a broad conclusion before the specific meaning is identified. Once that meaning stays attached, the feeling can begin acting like proof before the situation is fully clear.",
    "lesson": "If this repeats unchecked, the mind can start learning that accepting a broad conclusion before the specific meaning is identified is the truth rather than an attached meaning to examine.",
    "forward": "The feeling can be real while the meaning still needs clearer identification before becoming a conclusion."
  }
]
```

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

