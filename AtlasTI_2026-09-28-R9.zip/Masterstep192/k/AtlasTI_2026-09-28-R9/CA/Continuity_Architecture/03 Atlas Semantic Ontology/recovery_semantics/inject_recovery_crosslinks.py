from pathlib import Path

folder = Path.cwd()

crosslinks = """

## Related Activations
- stabilization_semantics/pause_stabilization
- regulation_semantics/emotional_regulation
- continuity_semantics/continuity_restoration

## Reintegration Routes
- reintegration_semantics/reintegration_balance
- reintegration_semantics/continuity_reintegration

## Adaptive Reroutes
- adaptive_semantics/adaptive_recovery
- adaptive_semantics/adaptive_continuity

## Resilience Links
- resilience_semantics/recovery_resilience
- resilience_semantics/adaptive_resilience

## Continuity Preservation Links
- continuity_semantics/continuity_preservation
- preservation_semantics/recovery_preservation

## Fragmentation Recovery Links
- fragmentation_semantics/fragmentation_recovery
- coherence_semantics/coherence_restoration

## Recursive Protection
- recursive_semantics/recursive_recovery
- threshold_semantics/recovery_thresholds
"""

for file in folder.glob("*.md"):
    content = file.read_text(encoding="utf-8")

    if "## Related Activations" in content:
        continue

    content += crosslinks

    file.write_text(content, encoding="utf-8")

print("Recovery semantic crosslinks injected.")