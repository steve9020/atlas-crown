const assert = require('assert');
const { runPipeline } = require('../runtime/pipeline/ResponsePipeline');
const prompts = [
  'My friend keeps asking for favors even when I am exhausted, and I feel guilty saying no.',
  'I keep replaying what I said and now I feel like I ruined everything.',
  'I said something awkward in front of everyone and now I feel embarrassed.',
  'They left and I feel like I was not worth staying for.',
  'I feel like I am failing because I cannot keep up.',
  'Everyone else seems ahead of me and I feel behind.',
  'They keep changing how they act and I do not know where I stand.',
  'The bills and deadlines are stacking up and I feel stressed.',
  'I love them, but it makes me feel exposed.',
  'I hoped it would work out and now I feel disappointed.'
];
const outputs = prompts.map(p => runPipeline(p));
const relations = outputs.map(o => o.compass_response_candidate && o.compass_response_candidate.route.active_relation);
const unclassified = relations.filter(r => r === 'unclassified_relation').length;
assert.ok(unclassified <= 1, 'too many unclassified fresh prompts: ' + JSON.stringify(relations));
const responses = outputs.map(o => o.output);
const unique = new Set(responses).size;
assert.ok(unique >= 8, 'responses are too repetitive; unique=' + unique);
for (const o of outputs) {
  assert.ok(!/Something in this is asking to be sorted carefully/i.test(o.output), 'generic fallback leaked: ' + o.input);
  assert.ok(!/runtime|backend|ontology|open loops|fused together|system saying/i.test(o.output), 'technical language leaked: ' + o.input);
}
console.log('masterStep52FreshPromptFuzzResponseTest PASSED');
