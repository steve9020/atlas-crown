'use strict';
// == DOOR CHECK — deterministic comment counts for the heartbeat run note ==
// Reads the door post and the commissions post comment trees (READ-ONLY, no
// writes possible from this script) and prints the two counts the heartbeat
// run note must use: flattened total (incl. nested replies) AND top-level.
// Run: node ~/workspace/moltbook-adapter/door-check.js
// Stdout format (single line per post): "DOOR 6914077a: 13 total incl. nested, 7 top-level"
// Use this exact phrasing in the mission-log run note — never a bare count.
// Bug context (resolved 2026-09-24): run notes alternated between "N comments"
// (flattened total) and "N top-level" with no label, which looked like a
// discrepancy. There was no fetch bug — api.comments limit 35 covers both
// trees; the ambiguity was in the prose. This script removes the ambiguity.

const { api } = require('./api.js');

const POSTS = [
  { label: 'DOOR', id: '6914077a-d51d-43aa-bf2e-d54edffd9983' },
  { label: 'COMMISSIONS', id: 'fc5fafd8-582c-4498-a90c-0ca815c53de9' }
];

function flatten(tree, out) {
  out = out || [];
  for (const c of (tree || [])) {
    out.push(c);
    if (c.replies) flatten(c.replies, out);
  }
  return out;
}

// Fail closed on transient flakes: retry reads up to 4x before reporting an
// error line instead of a count. A count line is only printed on HTTP 200
// with a parseable tree — never print a count you did not actually read.
async function withRetry(fn, label) {
  let lastErr;
  for (let i = 1; i <= 4; i++) {
    try { return await fn(); }
    catch (e) { lastErr = e; await new Promise(r => setTimeout(r, 1500 * i)); }
  }
  throw lastErr;
}

async function checkOne(label, id) {
  try {
    const r = await withRetry(() => api.comments(id, { limit: 35 }), label);
    if (!r.ok || r.status !== 200) {
      console.log(label + ' ' + id.slice(0, 8) + ': FETCH FAILED (HTTP ' + r.status + ') — count unavailable, no note line');
      return;
    }
    const tree = (r.data && (r.data.comments || r.data)) || [];
    const total = flatten(tree).length;
    console.log(label + ' ' + id.slice(0, 8) + ': ' + total + ' total incl. nested, ' + tree.length + ' top-level');
  } catch (e) {
    console.log(label + ' ' + id.slice(0, 8) + ': FETCH FAILED (' + e.message + ') — count unavailable, no note line');
  }
}

(async () => {
  for (const p of POSTS) await checkOne(p.label, p.id);
})();
