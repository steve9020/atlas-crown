const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { STEP, buildDoyleSphereContract, evaluateDoylePrompt, auditDoyleSphereMaturity } = require('../runtime/understanding/DoyleSphereMaturityAuditRecursiveIndexContract');
const { loadCanonicalProofContract, countRunnerCommands, assertCanonicalProofContract } = require('../runtime/proof/CanonicalProofContract');
const { assertProofDisplayCalloutContract } = require('../runtime/proof/ProofDisplayCalloutContract');
const { assertProofInvocationFreshness } = require('../runtime/proof/ProofInvocationFreshnessGuard');
const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');

const ROOT = path.resolve(__dirname, '..');
const read = rel => fs.readFileSync(path.join(ROOT, rel), 'utf8');
const json = rel => JSON.parse(read(rel));

function extractCommands(){
  const registry = json('runtime/proof/PROOF_COMMAND_REGISTRY.json');
  return registry.commands.map(c => ({ displayName: c.id, technicalArgs: c.args, technicalName: c.technical_name }));
}


(function main(){
  const audit = auditDoyleSphereMaturity(ROOT);
  assert.strictEqual(audit.ok, true, audit.failures.join('; '));
  assert.strictEqual(STEP.number, 164);
  assert.strictEqual(STEP.keeper, 'Masterstep164.zip');
  assert.strictEqual(STEP.sourceKeeper, 'Masterstep163_repaired.zip');
  assert.strictEqual(STEP.expectedCommands, 86);
  assert.strictEqual(STEP.currentManifest, 'proof/results/MASTERSTEP164_CURRENT_PROOF_MANIFEST.json');

  const sphereContract = buildDoyleSphereContract();
  assert.strictEqual(sphereContract.recursive_index_contract, true);
  assert.strictEqual(sphereContract.doyle_is_understanding_field_not_route_selector, true);
  assert.strictEqual(sphereContract.layer_count, 7);
  assert.strictEqual(sphereContract.primary_sphere_count, 84);
  assert.strictEqual(sphereContract.layers.every(layer => layer.sphere_count === 12), true);

  assert.strictEqual(audit.implemented.recursive_spire_map_present, true);
  assert.strictEqual(audit.implemented.literal_practical_hold_demonstrated, true);
  assert.strictEqual(audit.implemented.mixed_meaning_separation_demonstrated, true);
  assert.strictEqual(audit.implemented.translation_preservation_demonstrated, true);
  assert.strictEqual(audit.implemented.backend_exposure_added, false);

  const literal = evaluateDoylePrompt({
    prompt: 'Move README.md and app.py into the public demo folder.',
    semantic: { context_object: { domain: 'literal_practical_context' } }
  });
  assert.strictEqual(literal.literalPracticalHold, true);
  assert.strictEqual(literal.doyleUnderstandingBeforeRoute, true);
  assert.strictEqual(literal.doyleRouteAuthority, false);
  assert.ok(literal.activeSpherePath.some(item => item.startsWith('L2:')));
  assert.ok(literal.possibleAttachmentPath.some(item => item.startsWith('possible_meaning:')));

  const mixed = evaluateDoylePrompt({
    prompt: 'The files are messy and it feels like I cannot keep up with anything.',
    contexts: [
      { surfaceEvent: 'files are messy', literalPracticalBoundary: 'file organization', restorationDirection: 'sort files' },
      { surfaceEvent: 'meaning pressure', attachedMeaning: 'cannot keep up with anything', emotionalPressure: 'overwhelm', unsupportedConclusion: 'global ability conclusion', restorationDirection: 'separate files from ability' }
    ],
    competingMeanings: ['practical file organization', 'ability conclusion']
  });
  assert.strictEqual(mixed.mixedMeaningSeparated, true);
  assert.strictEqual(mixed.doyleRouteAuthority, false);

  const contract = loadCanonicalProofContract(ROOT);
  assert.strictEqual(isValidLaterKeeper(contract.current_keeper, 164), true);
  assert.strictEqual(Number(contract.step_number) >= 164, true);
  assert.strictEqual(acceptsCurrentProofCount(contract.expected_commands, 86), true);
  assert.ok(String(contract.current_manifest).includes(`MASTERSTEP${contract.step_number}_CURRENT_PROOF_MANIFEST.json`));
  assert.strictEqual(contract.expected_package_root, String(contract.current_keeper).replace(/\.zip$/i, ''));
  assert.strictEqual(contract.doyle_sphere_maturity_audit_created, true);
  assert.strictEqual(contract.doyle_recursive_index_contract_created, true);
  assert.strictEqual(contract.doyle_understanding_not_routing, true);
  assert.strictEqual(contract.public_demo_backend_intelligence_exposed, false);

  const proofState = json('runtime/proof/PROOF_STATE.json');
  const registry = json('runtime/proof/PROOF_COMPATIBILITY_REGISTRY.json');
  const versionJson = json('tests/VERSION_STATUS.json');
  const version = require('../version_status');
  assert.strictEqual(proofState.current_keeper, contract.current_keeper);
  assert.strictEqual(version.current_keeper, contract.current_keeper);
  assert.strictEqual(versionJson.current_keeper, contract.current_keeper);
  assert.strictEqual(registry.current_keeper, contract.current_keeper);
  assert.strictEqual(proofState.source_keeper, contract.source_keeper);
  assert.strictEqual(version.source_keeper, contract.source_keeper);
  assert.strictEqual(proofState.current_manifest, contract.current_manifest);
  assert.strictEqual(version.current_manifest, contract.current_manifest);
  assert.strictEqual(versionJson.current_manifest, contract.current_manifest);
  assert.strictEqual(proofState.expected_commands, contract.expected_commands);
  assert.strictEqual(version.expected_current_proof_commands, contract.expected_commands);
  assert.strictEqual(registry.minimum_current_step >= 164, true);
  assert.strictEqual(acceptsCurrentProofCount(registry.minimum_current_proof_count, 86), true);

  const commandCount = countRunnerCommands(ROOT);
  assert.strictEqual(acceptsCurrentProofCount(commandCount, 86), true);
  const runner = read('proof/runCurrentProof.js');
  assert.ok(runner.includes('tests/masterStep164DoyleSphereMaturityAuditRecursiveIndexContractTest.js'));
  const commandRegistry = json('runtime/proof/PROOF_COMMAND_REGISTRY.json');
  assert.strictEqual(commandRegistry.commands.at(-1).id, `proof-check-${String(commandCount).padStart(3, '0')}`);
  assert.ok(runner.includes('display=decallouted'));
  assert.strictEqual(isValidLaterKeeper(version.current_keeper, 164), true);
  assert.strictEqual(acceptsCurrentProofCount(version.expected_current_proof_commands, 86), true);

  const canonical = assertCanonicalProofContract({ projectRoot: ROOT, commandCount, packageRootNameOverride: contract.expected_package_root });
  assert.strictEqual(canonical.ok, true, canonical.failures.join('; '));
  const freshness = assertProofInvocationFreshness({ projectRoot: ROOT, commandCount, packageRootNameOverride: contract.expected_package_root });
  assert.strictEqual(freshness.ok, true, freshness.failures.join('; '));
  const parsedCommands = extractCommands();
  const display = assertProofDisplayCalloutContract({ projectRoot: ROOT, commandCount, commands: parsedCommands.map(c => [c.displayName, 'node', [], c.technicalName]) });
  assert.strictEqual(display.ok, true, display.failures.join('; '));

  assert.strictEqual(version.doyle_sphere_maturity_audit_created, true);
  assert.strictEqual(version.doyle_recursive_index_contract_created, true);
  assert.strictEqual(version.doyle_understanding_not_routing, true);
  assert.strictEqual(version.runtime_behavior_changed, version.shared_semantic_multi_domain_migration_created ? true : false);
  assert.strictEqual(version.compass_output_behavior_changed, version.shared_semantic_multi_domain_migration_created ? true : false);
  assert.strictEqual(version.safety_behavior_changed, false);
  assert.strictEqual(version.model_authority_added, false);
  assert.strictEqual(version.frontend_intelligence_added, false);
  assert.strictEqual(version.silent_learning_added, false);
  assert.strictEqual(version.silent_mutation_added, false);

  console.log('PASS masterStep164DoyleSphereMaturityAuditRecursiveIndexContractTest');
})();
