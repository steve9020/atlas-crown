const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel),'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function exists(rel){ return fs.existsSync(path.join(root, rel)); }
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const proof = json('runtime/proof/PROOF_STATE.json');
const active = json('runtime/workflow/ACTIVE_STEP.json');
const version = json('tests/VERSION_STATUS.json');
for (const state of [proof, active, version]) {
  assert(state.current_keeper === 'Masterstep21.zip', 'current keeper must be Masterstep21.zip');
  assert(state.previous_keeper === 'Masterstep20.zip', 'previous keeper must be Masterstep20.zip');
  assert(state.current_step === 'Masterstep21', 'current step must be Masterstep21');
  assert(state.status === 'closed_keeper', 'status must be closed_keeper');
  assert(state.step_not_patch === true, 'step_not_patch must remain true');
  assert(state.final_output_governance_gate_added === true, 'final output governance gate must be recorded');
  assert(state.ai_proposal_can_be_final_output === false, 'AI proposal cannot be final output');
  assert(state.compass_delivery_requires_final_governance === true, 'Compass delivery must require final governance');
  assert(state.real_ai_connected === false, 'real AI must be false');
  assert(state.provider_config_added === false, 'provider config must be false');
  assert(state.network_bridge_added === false, 'network bridge must be false');
  assert(state.frontend_intelligence_added === false, 'frontend intelligence must be false');
}
for (const rel of [
  'runtime/ai/AI_FINAL_OUTPUT_GOVERNANCE_GATE.json',
  'runtime/ai/AI_FINAL_OUTPUT_GOVERNANCE_GATE.md',
  'runtime/ai/AIFinalOutputGovernanceGate.js',
  'runtime/ai/CompassDeliverySeparationGuard.js',
  'runtime/ai/AIFinalOutputTraceRecord.js',
  'runtime/proof/MASTERSTEP21_FINAL_OUTPUT_GOVERNANCE_GATE.md',
  'runtime/proof/MASTERSTEP21_TEST_RESULTS.md',
  'docs/MASTERSTEP21_FINAL_OUTPUT_GOVERNANCE_GATE_MAP.md'
]) assert(exists(rel), `missing ${rel}`);
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md');
assert(summary.includes('Current keeper: Masterstep21.zip'), 'summary must name Masterstep21');
assert(summary.includes('AI output is never final output by default'), 'summary must name final-output boundary');
assert(summary.includes('No real AI connected'), 'summary must preserve no real AI boundary');
console.log('masterStep21FullClosureKeeperReadinessTest PASSED');
