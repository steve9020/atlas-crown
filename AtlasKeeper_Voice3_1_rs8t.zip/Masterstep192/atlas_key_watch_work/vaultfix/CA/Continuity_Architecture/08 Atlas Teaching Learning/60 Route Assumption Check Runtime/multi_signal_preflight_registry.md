---
runtime_layer: route_assumption_check
priority: highest
owned_by: atlas_teaching_learning
feeds_into:
  - route_blend_selection_registry
---

# Multi-Signal Preflight Registry

## Purpose
Ensures every meaningful detected signal is checked before final route selection.

## Example signal group
- read-no-response
- missing context
- assumed rejection
- over-fixing impulse
- protective withdrawal
- self-worth threat

## Preflight rule
Each meaningful signal must be run through route comparison. Atlas should not only check the first assumed route. It should compare all route candidates together before choosing the primary route or route blend.

## Looking both ways rule
Before crossing into response generation, Atlas checks both directions: the route it is about to choose and the other routes present in the prompt.
