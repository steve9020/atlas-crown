---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 03
category: fear_and_anxiety
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 11. Fear and Anxiety Pressure Tests — Batch 03

## Category Purpose

A possible threat, uncertain outcome, future consequence, or loss of safety becomes emotionally enlarged before the full reality is clear, causing the user to feel pulled toward danger-certainty, urgency, avoidance, or self-protection.

## Reusable Teaching Correction

Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

## Reverse-Flow Target

safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation

## Failure Risks To Avoid

- calling fear irrational
- telling the user to just calm down
- treating fear as proof
- diagnosing anxiety
- forcing immediate certainty

---

## 80 Pressure Tests

### Test 01
**Prompt:** I have not heard back yet and it makes me afraid that something bad is definitely going to happen, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** something bad is definitely going to happen
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 02
**Prompt:** I am afraid this means something is wrong. I have to make a decision soon keeps affecting emotional security and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** my fear is proof
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 03
**Prompt:** I keep replaying how something changed suddenly because it affects future stability and makes me believe the worst outcome is the real outcome.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** the worst outcome is the real outcome
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 04
**Prompt:** When I do not know what will happen next, the feeling moves straight into uncertainty means danger. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** uncertainty means danger
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 05
**Prompt:** The situation is my mind keeps jumping ahead, and the meaning that keeps attaching is I am unsafe because I feel unsafe. It is making emotional security feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am unsafe because I feel unsafe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 06
**Prompt:** I noticed a small sign and got scared and it makes me afraid that I cannot handle this, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** I cannot handle this
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 07
**Prompt:** what if something bad happens. There is no clear answer yet keeps affecting safety and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** if I do not fix this now everything will collapse
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 08
**Prompt:** I keep replaying how I feel pressure to predict the outcome because it affects emotional security and makes me believe something bad is definitely going to happen.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** something bad is definitely going to happen
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 09
**Prompt:** When I have not heard back yet, the feeling moves straight into I need certainty before I can breathe. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** I need certainty before I can breathe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 10
**Prompt:** The situation is I have to make a decision soon, and the meaning that keeps attaching is the worst outcome is the real outcome. It is making safety feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** the worst outcome is the real outcome
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 11
**Prompt:** Something changed suddenly and it keeps turning into my fear is proof, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** my fear is proof
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 12
**Prompt:** I am afraid this means something is wrong. I do not know what will happen next keeps affecting future stability and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** I am unsafe because I feel unsafe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 13
**Prompt:** I keep replaying how my mind keeps jumping ahead because it affects safety and makes me believe uncertainty means danger.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** uncertainty means danger
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 14
**Prompt:** When I noticed a small sign and got scared, the feeling moves straight into if I do not fix this now everything will collapse. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** if I do not fix this now everything will collapse
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 15
**Prompt:** The situation is there is no clear answer yet, and the meaning that keeps attaching is I cannot handle this. It is making future stability feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** I cannot handle this
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 16
**Prompt:** I feel pressure to predict the outcome and it keeps turning into I need certainty before I can breathe, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** I need certainty before I can breathe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 17
**Prompt:** I cannot calm my mind. I have not heard back yet keeps affecting emotional security and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** something bad is definitely going to happen
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 18
**Prompt:** I keep replaying how I have to make a decision soon because it affects future stability and makes me believe my fear is proof.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** my fear is proof
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 19
**Prompt:** When something changed suddenly, the feeling moves straight into the worst outcome is the real outcome. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** the worst outcome is the real outcome
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 20
**Prompt:** The situation is I do not know what will happen next, and the meaning that keeps attaching is uncertainty means danger. It is making emotional security feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** uncertainty means danger
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 21
**Prompt:** My mind keeps jumping ahead and it pulls me toward the belief that I am unsafe because I feel unsafe, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** I am unsafe because I feel unsafe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 22
**Prompt:** I feel anxious. I noticed a small sign and got scared keeps affecting safety and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** I cannot handle this
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 23
**Prompt:** I keep replaying how there is no clear answer yet because it affects emotional security and makes me believe if I do not fix this now everything will collapse.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** if I do not fix this now everything will collapse
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 24
**Prompt:** When I feel pressure to predict the outcome, the feeling moves straight into something bad is definitely going to happen. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** something bad is definitely going to happen
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 25
**Prompt:** The situation is I have not heard back yet, and the meaning that keeps attaching is I need certainty before I can breathe. It is making safety feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** I need certainty before I can breathe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 26
**Prompt:** I have to make a decision soon and it makes uncertainty feel like the worst outcome is the real outcome, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** the worst outcome is the real outcome
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 27
**Prompt:** I cannot calm my mind. Something changed suddenly keeps affecting future stability and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** my fear is proof
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 28
**Prompt:** I keep replaying how I do not know what will happen next because it affects safety and makes me believe I am unsafe because I feel unsafe.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** I am unsafe because I feel unsafe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 29
**Prompt:** When my mind keeps jumping ahead, the feeling moves straight into uncertainty means danger. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** uncertainty means danger
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 30
**Prompt:** The situation is I noticed a small sign and got scared, and the meaning that keeps attaching is if I do not fix this now everything will collapse. It is making future stability feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** if I do not fix this now everything will collapse
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 31
**Prompt:** There is no clear answer yet and it makes uncertainty feel like I cannot handle this, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** I cannot handle this
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 32
**Prompt:** I feel anxious. I feel pressure to predict the outcome keeps affecting emotional security and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** I need certainty before I can breathe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 33
**Prompt:** I keep replaying how I have not heard back yet because it affects future stability and makes me believe something bad is definitely going to happen.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** something bad is definitely going to happen
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 34
**Prompt:** When I have to make a decision soon, the feeling moves straight into my fear is proof. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** my fear is proof
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 35
**Prompt:** The situation is something changed suddenly, and the meaning that keeps attaching is the worst outcome is the real outcome. It is making emotional security feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** the worst outcome is the real outcome
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 36
**Prompt:** I do not know what will happen next and it has me reacting as if uncertainty means danger, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** uncertainty means danger
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 37
**Prompt:** I feel on edge. My mind keeps jumping ahead keeps affecting safety and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** I am unsafe because I feel unsafe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 38
**Prompt:** I keep replaying how I noticed a small sign and got scared because it affects emotional security and makes me believe I cannot handle this.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** I cannot handle this
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 39
**Prompt:** When there is no clear answer yet, the feeling moves straight into if I do not fix this now everything will collapse. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** if I do not fix this now everything will collapse
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 40
**Prompt:** The situation is I feel pressure to predict the outcome, and the meaning that keeps attaching is something bad is definitely going to happen. It is making safety feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** something bad is definitely going to happen
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 41
**Prompt:** I have not heard back yet and it makes my body feel like I need certainty before I can breathe, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** I need certainty before I can breathe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 42
**Prompt:** I am scared. I have to make a decision soon keeps affecting future stability and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** the worst outcome is the real outcome
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 43
**Prompt:** I keep replaying how something changed suddenly because it affects safety and makes me believe my fear is proof.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** my fear is proof
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 44
**Prompt:** When I do not know what will happen next, the feeling moves straight into I am unsafe because I feel unsafe. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am unsafe because I feel unsafe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 45
**Prompt:** The situation is my mind keeps jumping ahead, and the meaning that keeps attaching is uncertainty means danger. It is making future stability feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** uncertainty means danger
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 46
**Prompt:** I noticed a small sign and got scared and it makes my body feel like if I do not fix this now everything will collapse, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** if I do not fix this now everything will collapse
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 47
**Prompt:** I feel on edge. There is no clear answer yet keeps affecting emotional security and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** I cannot handle this
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 48
**Prompt:** I keep replaying how I feel pressure to predict the outcome because it affects future stability and makes me believe I need certainty before I can breathe.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** I need certainty before I can breathe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 49
**Prompt:** When I have not heard back yet, the feeling moves straight into something bad is definitely going to happen. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** something bad is definitely going to happen
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 50
**Prompt:** The situation is I have to make a decision soon, and the meaning that keeps attaching is my fear is proof. It is making emotional security feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** my fear is proof
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 51
**Prompt:** Something changed suddenly and it keeps attaching fear to the worst outcome is the real outcome, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** the worst outcome is the real outcome
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 52
**Prompt:** I am scared. I do not know what will happen next keeps affecting safety and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** uncertainty means danger
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 53
**Prompt:** I keep replaying how my mind keeps jumping ahead because it affects emotional security and makes me believe I am unsafe because I feel unsafe.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am unsafe because I feel unsafe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 54
**Prompt:** When I noticed a small sign and got scared, the feeling moves straight into I cannot handle this. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** I cannot handle this
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 55
**Prompt:** The situation is there is no clear answer yet, and the meaning that keeps attaching is if I do not fix this now everything will collapse. It is making safety feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** if I do not fix this now everything will collapse
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 56
**Prompt:** I feel pressure to predict the outcome and it keeps attaching fear to something bad is definitely going to happen, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** something bad is definitely going to happen
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 57
**Prompt:** I keep expecting the worst. I have not heard back yet keeps affecting future stability and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** I need certainty before I can breathe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 58
**Prompt:** I keep replaying how I have to make a decision soon because it affects safety and makes me believe the worst outcome is the real outcome.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** the worst outcome is the real outcome
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 59
**Prompt:** When something changed suddenly, the feeling moves straight into my fear is proof. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** my fear is proof
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 60
**Prompt:** The situation is I do not know what will happen next, and the meaning that keeps attaching is I am unsafe because I feel unsafe. It is making future stability feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** I am unsafe because I feel unsafe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 61
**Prompt:** My mind keeps jumping ahead and it makes it hard not to believe uncertainty means danger, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** uncertainty means danger
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 62
**Prompt:** I keep worrying. I noticed a small sign and got scared keeps affecting emotional security and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** if I do not fix this now everything will collapse
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 63
**Prompt:** I keep replaying how there is no clear answer yet because it affects future stability and makes me believe I cannot handle this.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** I cannot handle this
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 64
**Prompt:** When I feel pressure to predict the outcome, the feeling moves straight into I need certainty before I can breathe. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** I need certainty before I can breathe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 65
**Prompt:** The situation is I have not heard back yet, and the meaning that keeps attaching is something bad is definitely going to happen. It is making emotional security feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** something bad is definitely going to happen
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 66
**Prompt:** I have to make a decision soon and it makes me afraid that my fear is proof, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** my fear is proof
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 67
**Prompt:** I keep expecting the worst. Something changed suddenly keeps affecting safety and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** the worst outcome is the real outcome
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 68
**Prompt:** I keep replaying how I do not know what will happen next because it affects emotional security and makes me believe uncertainty means danger.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** uncertainty means danger
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 69
**Prompt:** When my mind keeps jumping ahead, the feeling moves straight into I am unsafe because I feel unsafe. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** I am unsafe because I feel unsafe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 70
**Prompt:** The situation is I noticed a small sign and got scared, and the meaning that keeps attaching is I cannot handle this. It is making safety feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** I cannot handle this
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 71
**Prompt:** There is no clear answer yet and it makes me afraid that if I do not fix this now everything will collapse, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** if I do not fix this now everything will collapse
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 72
**Prompt:** I keep worrying. I feel pressure to predict the outcome keeps affecting future stability and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** something bad is definitely going to happen
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 73
**Prompt:** I keep replaying how I have not heard back yet because it affects safety and makes me believe I need certainty before I can breathe.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** I need certainty before I can breathe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 74
**Prompt:** When I have to make a decision soon, the feeling moves straight into the worst outcome is the real outcome. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** the worst outcome is the real outcome
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 75
**Prompt:** The situation is something changed suddenly, and the meaning that keeps attaching is my fear is proof. It is making future stability feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** my fear is proof
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 76
**Prompt:** I do not know what will happen next and it keeps turning into I am unsafe because I feel unsafe, even though part of me knows I may not have the full picture.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** I am unsafe because I feel unsafe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid calling fear irrational.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 77
**Prompt:** I am afraid this means something is wrong. My mind keeps jumping ahead keeps affecting emotional security and I cannot tell what is actually true.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** uncertainty means danger
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 78
**Prompt:** I keep replaying how I noticed a small sign and got scared because it affects future stability and makes me believe if I do not fix this now everything will collapse.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** future stability
**Attached meaning to separate:** if I do not fix this now everything will collapse
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid treating fear as proof.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 79
**Prompt:** When there is no clear answer yet, the feeling moves straight into I cannot handle this. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** safety
**Attached meaning to separate:** I cannot handle this
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid diagnosing anxiety.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

### Test 80
**Prompt:** The situation is I feel pressure to predict the outcome, and the meaning that keeps attaching is I need certainty before I can breathe. It is making emotional security feel unstable.
**Expected primary route:** `fear_and_anxiety`
**Pressure focus:** emotional security
**Attached meaning to separate:** I need certainty before I can breathe
**Expected reverse-flow movement:** safety orientation, present-moment clarity, uncertainty tolerance, slower interpretation
**Bad response risk:** Avoid forcing immediate certainty.
**Teaching correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.
