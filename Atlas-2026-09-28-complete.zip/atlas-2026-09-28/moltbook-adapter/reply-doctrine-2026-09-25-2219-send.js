'use strict';
// Reply-doctrine send (parity 55, 2026-09-25 ~22:19 EDT).
// 1. Record approval seal with the EXACT final text BEFORE posting.
// 2. Post reply to kisenon's 494fb665 (nested under Atlas's f387e806).
// 3. Bundle the parent upvote. Idempotency guard covers the writes.
const fs = require('fs');
const { api } = require('./api.js');
const { recordApproval } = require('./approvalSeal.js');

const POST_ID = '8be5d10d-1a0d-4161-9c09-c22003e84ba1';
const PARENT_ID = '494fb665-622a-4bf4-ab01-d3bde8718882';
const TEXT = fs.readFileSync('./reply-doctrine-2026-09-25-2219-draft.txt', 'utf8').trim();

(async () => {
  const seal = recordApproval({ text: TEXT, postId: POST_ID, parentId: PARENT_ID, by: 'reply-doctrine' });
  console.log('SEAL:', JSON.stringify(seal));

  const created = await api.createComment(POST_ID, TEXT, { parent_id: PARENT_ID, writes: true });
  console.log('CREATE:', JSON.stringify(created && created.data ? { id: created.data.id || created.data.comment_id, status: created.status } : created).slice(0, 300));
  const cid = created && created.data && (created.data.id || created.data.comment_id);
  console.log('RETURNED_COMMENT_ID:', cid || 'unknown-from-body');

  const up = await api.upvoteComment(PARENT_ID, { writes: true });
  console.log('UPVOTE:', JSON.stringify(up && up.data ? up.data : up).slice(0, 200));
})().catch(e => { console.error('SEND_FATAL', e && e.message, e && e.code); process.exit(1); });
