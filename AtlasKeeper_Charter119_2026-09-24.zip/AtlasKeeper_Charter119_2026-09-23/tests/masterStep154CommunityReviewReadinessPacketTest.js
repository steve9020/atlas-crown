const assert = require('assert');
const fs = require('fs');
const path = require('path');

const {
  getCommunityReviewReadinessPacket,
  validateCommunityReviewReadinessPacket
} = require('../runtime/review/CommunityReviewReadinessPacket');
const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const { requireHistoricalMarkers } = require('../runtime/proof/HistoricalProofMarkerRegistry');
const { assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');

const ROOT = path.resolve(__dirname, '..');
const read = rel => fs.readFileSync(path.join(ROOT, rel), 'utf8');
const json = rel => JSON.parse(read(rel));
const exists = rel => fs.existsSync(path.join(ROOT, rel));

(function main(){
  const packet = getCommunityReviewReadinessPacket();
  const validation = validateCommunityReviewReadinessPacket(packet);
  assert.strictEqual(validation.ok, true, validation.failures.join('; '));

  const deniedClaimScan = assertNoForbiddenAffirmativeClaims('Atlas is not production-ready. Raw model output is not final. Cloud fallback is not allowed.');
  assert.strictEqual(deniedClaimScan.ok, true, 'scanner must allow negated claim-boundary language');
  const affirmativeClaimScan = assertNoForbiddenAffirmativeClaims('Atlas is production-ready. Raw model output is final.');
  assert.strictEqual(affirmativeClaimScan.ok, false, 'scanner must block affirmative forbidden claims');

  assert.strictEqual(packet.currentKeeper, 'Masterstep154.zip');
  assert.strictEqual(packet.sourceKeeper, 'Masterstep153_repaired.zip');
  assert.strictEqual(packet.readyForCommunityReview, true);
  assert.strictEqual(packet.readyForPublicRelease, false);
  assert.strictEqual(packet.readyForClinicalOrCrisisUse, false);
  assert.strictEqual(packet.readyForAutonomousDeployment, false);
  assert.ok(packet.demoScenarios.length >= 6);
  assert.ok(packet.demoScenarios.some(s => s.id === 'unsafe_self_harm_assistance'));
  assert.ok(packet.demoScenarios.some(s => s.id === 'unsafe_crime_evasion'));
  assert.ok(packet.shareBoundaries.doNotShareByDefault.includes('full source zip'));
  assert.ok(packet.shareBoundaries.doNotShareByDefault.includes('raw local model outputs'));
  assert.ok(packet.feedbackQuestions.some(q => /claim boundary/i.test(q)));

  for (const boundary of [
    'noNewMatrixCapability',
    'noRuntimeBehaviorChange',
    'noCompassOutputBehaviorChange',
    'noSafetyBehaviorChange',
    'noModelAuthority',
    'noFrontendIntelligence',
    'noCloudProviderFallback',
    'noSilentLearning',
    'noSilentMutation'
  ]) assert.strictEqual(packet.boundaries[boundary], true, `boundary not preserved: ${boundary}`);

  for (const prohibited of packet.prohibitedClaims) {
    assert.ok(!packet.demoClaims.join('\n').toLowerCase().includes(prohibited.toLowerCase()), `prohibited claim leaked: ${prohibited}`);
  }

  const state = json('runtime/proof/PROOF_STATE.json');
  const version = json('tests/VERSION_STATUS.json');
  const proofJson = json('runtime/proof/MASTERSTEP154_COMMUNITY_REVIEW_READINESS_PACKET.json');
  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md');
  const runner = read('proof/runCurrentProof.js');
  const versionJs = read('version_status.js');
  const testResults = read('tests/TEST_RESULTS.md');

  assert.ok(isValidLaterKeeper(state.current_keeper, 154), state.current_keeper);
  assert.ok(isValidLaterKeeper(version.current_keeper, 154), version.current_keeper);
  assert.ok(acceptsCurrentProofCount(state.expected_current_proof_commands, 76));
  assert.ok(acceptsCurrentProofCount(version.expected_current_proof_commands, 76));
  assert.strictEqual(proofJson.community_review_readiness_packet_created, true);
  assert.strictEqual(proofJson.no_new_matrix_capability, true);
  assert.strictEqual(proofJson.no_runtime_behavior_change, true);
  assert.strictEqual(proofJson.no_compass_output_behavior_change, true);
  assert.strictEqual(proofJson.ready_for_public_release, false);

  for (const file of [
    'runtime/review/CommunityReviewReadinessPacket.js',
    'runtime/proof/ClaimBoundaryScanner.js',
    'docs/CLAIM_BOUNDARY_SCANNER.md',
    'runtime/proof/MASTERSTEP154_COMMUNITY_REVIEW_READINESS_PACKET.md',
    'runtime/proof/MASTERSTEP154_COMMUNITY_REVIEW_READINESS_PACKET.json',
    'docs/MASTERSTEP154_COMMUNITY_REVIEW_READINESS_PACKET.md',
    'docs/COMMUNITY_REVIEW_READINESS_PACKET.md'
  ]) assert.strictEqual(exists(file), true, `missing required file: ${file}`);

  for (const marker of [
    'Masterstep154 — Community Review Readiness Packet',
    'Community review readiness',
    'controlled local demo',
    'not public release',
    'not clinical or crisis-use readiness',
    'do not share full source zip by default',
    'claim boundary',
    'No new matrix capability',
    'No runtime behavior change',
    'No Compass output behavior change',
    'No model authority',
    'No frontend intelligence',
    'No silent learning',
    'No silent mutation'
  ]) assert.ok(summary.includes(marker), `summary missing marker: ${marker}`);

  const historical = requireHistoricalMarkers([
    'Context-Before-Route Matrix',
    'Mixed-Context Evidence Separation',
    'Translation Preservation Matrix',
    'Positive-State Matrix Maturity',
    'Harm Boundary Regression',
    'Expansion Efficiency Architecture'
  ]);
  assert.strictEqual(historical.ok, true, `missing historical markers: ${historical.missing.join(', ')}`);

  assert.ok(/currentTarget\.current_manifest/i.test(runner) || /currentTarget\.current_manifest/i.test(runner));
  assert.ok(/masterStep154CommunityReviewReadinessPacketTest/i.test(runner));
  assert.ok(/current_keeper: 'Masterstep1(?:5[4-9]|[6-9][0-9]|[0-9]{3,})(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs));
  assert.ok(/source_keeper: 'Masterstep1(?:5[3-9]|[6-9][0-9]|[0-9]{3,})(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs));
  assert.ok(/expected_current_proof_commands: (?:7[6-9]|[89][0-9]|[0-9]{3,})/i.test(versionJs));
  assert.ok(/TEST 154 — Community Review Readiness Packet/i.test(testResults));

  console.log('Masterstep154 community review readiness packet passed');
})();
