#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const root = process.cwd();
function p(rel){ return path.join(root, rel); }
function read(rel){ return fs.readFileSync(p(rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function assert(c,m){ if(!c){ console.error(`FAIL: ${m}`); process.exit(1); } }
function includesAll(text, markers, label){ for (const marker of markers) assert(text.includes(marker), `${label} missing marker: ${marker}`); }

for (const rel of [
  'runtime/governance/FULL_INVARIANT_COVERAGE.json',
  'runtime/governance/FULL_INVARIANT_COVERAGE.md',
  'runtime/governance/OUTER_GOVERNANCE_ORDER_INVARIANT.json',
  'runtime/governance/OUTER_GOVERNANCE_ORDER_INVARIANT.md',
  'runtime/governance/FOUNDATIONAL_STABILITY_INVARIANTS.json',
  'runtime/governance/FOUNDATIONAL_STABILITY_INVARIANTS.md',
  'tests/SNAPSHOT_VAULT_POLICY.json'
]) assert(fs.existsSync(p(rel)), `required file missing: ${rel}`);

const expected = ['stability_governance','traceability_governance','proof_governance','rollback_governance','boundary_governance','promotion_governance','human_authority_governance'];
const order = json('runtime/governance/OUTER_GOVERNANCE_ORDER_INVARIANT.json');
assert(JSON.stringify(order.order) === JSON.stringify(expected), 'outer governance order mismatch');
assert(order.hard_lock === true, 'governance order not hard locked');
assert(order.touch_attempt_halt === true, 'governance order touch attempt does not halt');
includesAll(order.halt_if_order_is.join('\n'), ['modified','bypassed','reordered','silently_overridden','dynamically_mutated','conditionally_skipped','self_rewritten','indirectly_circumvented','attempted_to_be_touched'], 'governance order halt triggers');

const full = json('runtime/governance/FULL_INVARIANT_COVERAGE.json');
assert(full.target_keeper === 'Masterstep12_patch02.zip', 'target keeper mismatch');
assert(full.governance_order_hard_locked === true, 'full invariant order not locked');
includesAll(full.invariants.join('\n'), [
  'stability_supersedes_growth',
  'governance_order_is_fixed_and_attempted_touch_triggers_hold',
  'missing_dependency_marker_or_snapshot_metadata_triggers_hold',
  'proof_missing_partial_stale_ambiguous_inaccurate_or_untrusted_triggers_hold',
  'invariant_conflict_resolves_by_fixed_higher_order_governance_order',
  'foundational_invariants_must_remain_visible_reviewable_traceable_and_externally_auditable',
  'human_authority_may_halt_any_process_immediately_without_governance_permission',
  'governance_scope_is_process_promotion_containment_proof_rollback_boundaries_and_stability_only',
  'recovery_must_complete_before_expansion_resumes',
  'historical_proof_and_trace_records_may_not_be_silently_rewritten'
], 'full invariant coverage');

const policy = json('tests/SNAPSHOT_VAULT_POLICY.json');
assert(policy.current_snapshot_reference === 'ATLAS_RUNTIME_STAGE10_UI_CLEAN.zip', 'snapshot metadata reference missing');
assert(policy.required_marker === 'STAGE10_UI_CLEAN', 'required marker missing');
assert(policy.snapshot_metadata_required === true, 'snapshot metadata not required');
assert(policy.current_embedded_snapshot === null, 'scan-clean package should not embed snapshot');
assert(policy.metadata_reference_only_no_embedded_zip === true, 'metadata-reference-only policy missing');
assert(policy.missing_snapshot_metadata_halt === true, 'missing snapshot metadata halt missing');

console.log('MASTER STEP 12 PATCH 02 — FULL INVARIANT COVERAGE TEST');
console.log('Result: PASSED');
