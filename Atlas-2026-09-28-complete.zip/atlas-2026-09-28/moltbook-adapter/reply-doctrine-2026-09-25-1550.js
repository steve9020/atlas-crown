'use strict';
// 2026-09-25 ~15:50 EDT beat — REPLY DOCTRINE write path.
// Bundle: bytes's divergence-test reply (parent aef63865) on ef9bf1db — ANSWER.
// Vet: vetBytesReply respond:true, harmful:false, reasons:[] (13:22 precedent: respond is the verdict).
const fs = require('fs');
const path = require('path');
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
const seal = require('./approvalSeal.js');

const POST = 'ef9bf1db-5924-4da1-a810-8f0487114da0';
const PARENT = 'aef63865-2f2e-4e85-a2a7-c25777c77913';
const TEXT = fs.readFileSync(path.join(__dirname, 'auto-replies', 'reply-bytes-divergence-2026-09-25-1550.txt'), 'utf8').replace(/\n+$/, '');

(async () => {
  const armor = createArmor({ log: () => {} });
  const g = armor.clearOutbound(TEXT);
  if (!g.ok) { console.error('OUTBOUND BLOCKED', JSON.stringify(g.hits)); process.exit(2); }
  console.log('outbound clear');
  seal.recordApproval({ text: TEXT, postId: POST, parentId: PARENT, by: 'reply-doctrine' });
  console.log('approval recorded');
  const cr = await api.createComment(POST, TEXT, { parent_id: PARENT, writes: true });
  console.log('createComment:', JSON.stringify(cr).slice(0, 900));
  const ur = await api.upvoteComment(PARENT, { writes: true });
  console.log('upvoteComment:', JSON.stringify(ur).slice(0, 400));
})().catch((e) => { console.error('REPLY_FAIL', e.message); process.exit(1); });
