---
node_type: backend_teaching_registry
runtime_layer: scenario_specific_response_construction
status: active
priority: high
lesson_count: 100
---

# Mixed Emotion Scenario Branch Lessons

## Mechanical Definition

This registry teaches mixed-emotion branch logic across scenario-specific contexts. It prevents Compass from treating mixed emotions as generic combinations by teaching how the same arch emotion can change meaning depending on what it is attached to.

## Real-World Definition

Mixed emotions are common because one situation can affect more than one part of a person at the same time. Someone can feel relief and guilt, pride and shame, jealousy and care, hope and fear, or sadness and gratitude. Compass needs to understand what those emotions are connected to before responding.

## Teaching Rule

Do not only identify the mixed emotion. Identify what the mixed emotion is about.

## Lessons

## Mixed Branch Lesson 001: relief_guilt_honesty_impact

arch_emotion_mix: relief + guilt

scenario_object:
- speaking honestly

attached_meaning_risk:
- honesty means harsh, selfish, or bad

restorative_direction:
- clean honesty and care can exist together

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- You can mean what you said and still care about how it landed.

## Mixed Branch Lesson 002: relief_guilt_boundary_space

arch_emotion_mix: relief + guilt

scenario_object:
- taking space

attached_meaning_risk:
- space means abandoning or hurting someone

restorative_direction:
- capacity and care can exist together

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Having space can protect your capacity without proving you stopped caring.

## Mixed Branch Lesson 003: relief_sadness_ending_pressure

arch_emotion_mix: relief + sadness

scenario_object:
- something ending

attached_meaning_risk:
- relief means the ending did not matter

restorative_direction:
- relief and grief can both be understood

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling relief after pressure ends does not erase that something still mattered.

## Mixed Branch Lesson 004: relief_fear_pressure_lifted

arch_emotion_mix: relief + fear

scenario_object:
- pressure finally lowering

attached_meaning_risk:
- less pressure means something bad will return

restorative_direction:
- steadiness after pressure

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Relief can show pressure changed without proving the next bad thing is already coming.

## Mixed Branch Lesson 005: relief_shame_needing_help

arch_emotion_mix: relief + shame

scenario_object:
- receiving help

attached_meaning_risk:
- help means weakness or dependence

restorative_direction:
- receiving support with dignity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling relieved by support does not make you weak for needing it.

## Mixed Branch Lesson 006: pride_guilt_progress_others_struggling

arch_emotion_mix: pride + guilt

scenario_object:
- personal progress while others struggle

attached_meaning_risk:
- being happy means not caring

restorative_direction:
- progress and compassion can coexist

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Being proud of progress does not mean you stopped caring about people who are struggling.

## Mixed Branch Lesson 007: pride_shame_visibility

arch_emotion_mix: pride + shame

scenario_object:
- being seen succeeding

attached_meaning_risk:
- pride means arrogance

restorative_direction:
- confidence with humility

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling proud does not make your progress arrogant.

## Mixed Branch Lesson 008: pride_fear_losing_progress

arch_emotion_mix: pride + fear

scenario_object:
- finally making progress

attached_meaning_risk:
- feeling good means it will be taken away

restorative_direction:
- steadiness with progress

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Progress can be recognized without treating it like something you are about to lose.

## Mixed Branch Lesson 009: pride_discomfort_self_recognition

arch_emotion_mix: pride + discomfort

scenario_object:
- recognizing own effort

attached_meaning_risk:
- self-recognition means selfishness

restorative_direction:
- self-respect and grounded recognition

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Recognizing your effort does not mean you are making yourself better than anyone else.

## Mixed Branch Lesson 010: pride_sadness_late_progress

arch_emotion_mix: pride + sadness

scenario_object:
- progress after delay

attached_meaning_risk:
- progress came too late

restorative_direction:
- hope and recognition

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Late progress is still progress; it does not erase the effort it took to get there.

## Mixed Branch Lesson 011: jealousy_shame_progress_comparison

arch_emotion_mix: jealousy + shame

scenario_object:
- someone getting what you wanted

attached_meaning_risk:
- jealousy means you are bad or behind

restorative_direction:
- self-recognition and value

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Someone else’s progress may show what you want, but it does not lower your value.

## Mixed Branch Lesson 012: jealousy_sadness_being_chosen

arch_emotion_mix: jealousy + sadness

scenario_object:
- someone else being chosen

attached_meaning_risk:
- not chosen there means unwanted everywhere

restorative_direction:
- belonging and worth

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Someone else being chosen does not prove you are unwanted.

## Mixed Branch Lesson 013: jealousy_anger_unfairness

arch_emotion_mix: jealousy + anger

scenario_object:
- someone receiving what felt unfair

attached_meaning_risk:
- their gain means you were wronged beyond repair

restorative_direction:
- clarity without self-erasure

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Jealousy and anger may show something felt unfair, but they do not need to become a judgment against your worth.

## Mixed Branch Lesson 014: jealousy_fear_falling_behind

arch_emotion_mix: jealousy + fear

scenario_object:
- comparison to another timeline

attached_meaning_risk:
- being behind means never catching up

restorative_direction:
- steadiness and self-direction

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Someone else’s timing does not decide what is still possible for you.

## Mixed Branch Lesson 015: jealousy_guilt_good_person_conflict

arch_emotion_mix: jealousy + guilt

scenario_object:
- feeling jealous toward someone cared for

attached_meaning_risk:
- jealousy means lack of love or care

restorative_direction:
- care and desire can coexist

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling jealousy does not mean you stopped caring about them.

## Mixed Branch Lesson 016: hope_fear_disappointment

arch_emotion_mix: hope + fear

scenario_object:
- wanting something to work

attached_meaning_risk:
- hope means risking foolishness

restorative_direction:
- courage and steadiness

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Hope does not make you foolish; it shows something still matters to you.

## Mixed Branch Lesson 017: hope_sadness_past_loss

arch_emotion_mix: hope + sadness

scenario_object:
- wanting to believe again after loss

attached_meaning_risk:
- hope betrays what was lost

restorative_direction:
- possibility with respect for loss

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Hope can exist without erasing what hurt.

## Mixed Branch Lesson 018: hope_guilt_moving_forward

arch_emotion_mix: hope + guilt

scenario_object:
- feeling ready to move forward

attached_meaning_risk:
- moving forward means leaving someone behind

restorative_direction:
- permission to live forward

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling hope again does not mean the past stopped mattering.

## Mixed Branch Lesson 019: hope_shame_trying_again

arch_emotion_mix: hope + shame

scenario_object:
- trying again after failure

attached_meaning_risk:
- trying again means ignoring failure

restorative_direction:
- dignity and resilience

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Wanting to try again does not make the past failure your identity.

## Mixed Branch Lesson 020: hope_anxiety_waiting_result

arch_emotion_mix: hope + anxiety

scenario_object:
- waiting for an outcome

attached_meaning_risk:
- wanting it means losing control

restorative_direction:
- steadiness in uncertainty

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Hoping for something does not mean the outcome has to control you.

## Mixed Branch Lesson 021: anger_hurt_dismissal

arch_emotion_mix: anger + hurt

scenario_object:
- being dismissed

attached_meaning_risk:
- hurt means reaction must take over

restorative_direction:
- controlled clarity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Anger may show something felt dismissed, while the response still deserves control.

## Mixed Branch Lesson 022: anger_guilt_reaction

arch_emotion_mix: anger + guilt

scenario_object:
- reacting strongly

attached_meaning_risk:
- anger means badness

restorative_direction:
- clean accountability without self-condemnation

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling anger does not make you bad; what matters is how you move from it.

## Mixed Branch Lesson 023: anger_sadness_unheard

arch_emotion_mix: anger + sadness

scenario_object:
- not being heard

attached_meaning_risk:
- not heard means not important

restorative_direction:
- dignity and voice

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Not being heard can hurt without proving your voice has no value.

## Mixed Branch Lesson 024: anger_fear_conflict

arch_emotion_mix: anger + fear

scenario_object:
- conflict escalating

attached_meaning_risk:
- anger means danger or loss of control

restorative_direction:
- peace and controlled clarity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Conflict can bring anger and fear up without requiring either to run the response.

## Mixed Branch Lesson 025: anger_shame_boundary

arch_emotion_mix: anger + shame

scenario_object:
- feeling crossed

attached_meaning_risk:
- anger means you are wrong for having a boundary

restorative_direction:
- self-respect with control

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling crossed can matter without anger deciding the whole response.

## Mixed Branch Lesson 026: guilt_responsibility_real_impact

arch_emotion_mix: guilt + responsibility

scenario_object:
- possibly affecting someone

attached_meaning_risk:
- impact means total blame

restorative_direction:
- clean responsibility

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- You can care about impact without turning it into total blame against yourself.

## Mixed Branch Lesson 027: guilt_boundary_selfishness

arch_emotion_mix: guilt + boundary

scenario_object:
- saying no

attached_meaning_risk:
- no means selfishness

restorative_direction:
- capacity and respect

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Saying no does not prove you are selfish; it may show where your capacity needs respect.

## Mixed Branch Lesson 028: guilt_rest_pressure

arch_emotion_mix: guilt + exhaustion

scenario_object:
- resting when tired

attached_meaning_risk:
- rest means laziness

restorative_direction:
- recovery and capacity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Rest can be part of capacity, not proof of laziness.

## Mixed Branch Lesson 029: guilt_reassurance_burden

arch_emotion_mix: guilt + vulnerability

scenario_object:
- asking for reassurance

attached_meaning_risk:
- reassurance means burden

restorative_direction:
- steadiness and connection

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Needing reassurance does not prove you are asking for too much.

## Mixed Branch Lesson 030: guilt_progress_care_conflict

arch_emotion_mix: guilt + happiness

scenario_object:
- being happy while others struggle

attached_meaning_risk:
- happiness means lack of care

restorative_direction:
- care and happiness can coexist

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Your happiness does not have to take compassion away from anyone else.

## Mixed Branch Lesson 031: sadness_relief_end_of_pressure

arch_emotion_mix: sadness + relief

scenario_object:
- a hard situation ending

attached_meaning_risk:
- relief means the sadness is fake

restorative_direction:
- honest grief and relief

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Relief can show pressure ended without making the sadness false.

## Mixed Branch Lesson 032: sadness_anger_loss

arch_emotion_mix: sadness + anger

scenario_object:
- losing something unfairly

attached_meaning_risk:
- anger means sadness is weakness

restorative_direction:
- dignity and grief

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Anger can show the loss felt unfair, while sadness can still show what mattered.

## Mixed Branch Lesson 033: sadness_hope_future

arch_emotion_mix: sadness + hope

scenario_object:
- wanting a better future after pain

attached_meaning_risk:
- hope means ignoring pain

restorative_direction:
- possibility with honesty

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Hope does not erase the sadness; it gives the sadness somewhere else to move.

## Mixed Branch Lesson 034: sadness_numbness_too_much

arch_emotion_mix: sadness + numbness

scenario_object:
- feeling too much for too long

attached_meaning_risk:
- numbness means not caring

restorative_direction:
- reconnection and care

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Numbness can show overload without proving you do not care.

## Mixed Branch Lesson 035: sadness_shame_needing_support

arch_emotion_mix: sadness + shame

scenario_object:
- needing support

attached_meaning_risk:
- sadness means weakness

restorative_direction:
- dignity and support

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Being sad enough to need support does not lower your dignity.

## Mixed Branch Lesson 036: fear_confusion_uncertainty

arch_emotion_mix: fear + confusion

scenario_object:
- not knowing what something means

attached_meaning_risk:
- unclear means unsafe

restorative_direction:
- steadiness and clarity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Not knowing yet does not prove the worst answer is true.

## Mixed Branch Lesson 037: fear_guilt_letting_down

arch_emotion_mix: fear + guilt

scenario_object:
- not meeting expectations

attached_meaning_risk:
- fear of disappointing means failure

restorative_direction:
- clean responsibility and confidence

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Worrying you let someone down does not prove you failed them.

## Mixed Branch Lesson 038: fear_shame_vulnerability

arch_emotion_mix: fear + shame

scenario_object:
- being vulnerable

attached_meaning_risk:
- vulnerability means exposure or weakness

restorative_direction:
- courage and dignity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Being vulnerable does not mean you gave away your value.

## Mixed Branch Lesson 039: fear_hope_change

arch_emotion_mix: fear + hope

scenario_object:
- life changing

attached_meaning_risk:
- hope means risk of loss

restorative_direction:
- steadiness through change

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Change can feel scary without meaning hope is unsafe.

## Mixed Branch Lesson 040: fear_anger_threatened_boundary

arch_emotion_mix: fear + anger

scenario_object:
- boundary being pushed

attached_meaning_risk:
- fear and anger mean losing control

restorative_direction:
- controlled clarity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- A pushed boundary can matter without either fear or anger taking over.

## Mixed Branch Lesson 041: loneliness_shame_isolation

arch_emotion_mix: loneliness + shame

scenario_object:
- feeling alone

attached_meaning_risk:
- alone means unwanted

restorative_direction:
- belonging and dignity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling alone does not prove you are unwanted.

## Mixed Branch Lesson 042: loneliness_jealousy_others_connection

arch_emotion_mix: loneliness + jealousy

scenario_object:
- seeing others connected

attached_meaning_risk:
- others having connection means you have no place

restorative_direction:
- belonging and possibility

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Other people being connected does not mean connection is gone from you.

## Mixed Branch Lesson 043: loneliness_fear_not_chosen

arch_emotion_mix: loneliness + fear

scenario_object:
- not being chosen

attached_meaning_risk:
- not chosen now means never chosen

restorative_direction:
- belonging and steadiness

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Not being chosen in one place does not decide your belonging everywhere.

## Mixed Branch Lesson 044: loneliness_sadness_missing_someone

arch_emotion_mix: loneliness + sadness

scenario_object:
- missing someone

attached_meaning_risk:
- missing them means life cannot feel connected again

restorative_direction:
- connection and hope

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Missing someone does not mean connection is no longer possible.

## Mixed Branch Lesson 045: loneliness_anger_feeling_forgotten

arch_emotion_mix: loneliness + anger

scenario_object:
- feeling forgotten

attached_meaning_risk:
- forgotten means invisible

restorative_direction:
- dignity and voice

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling forgotten can hurt without proving you are invisible.

## Mixed Branch Lesson 046: shame_embarrassment_visibility

arch_emotion_mix: shame + embarrassment

scenario_object:
- being seen awkwardly

attached_meaning_risk:
- awkwardness means value decreased

restorative_direction:
- dignity and confidence

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- An awkward moment does not make your value smaller.

## Mixed Branch Lesson 047: shame_guilt_mistake

arch_emotion_mix: shame + guilt

scenario_object:
- making a mistake

attached_meaning_risk:
- mistake means bad person

restorative_direction:
- clean responsibility and dignity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- A mistake can deserve attention without becoming your identity.

## Mixed Branch Lesson 048: shame_fear_being_known

arch_emotion_mix: shame + fear

scenario_object:
- being known more fully

attached_meaning_risk:
- being known means being rejected

restorative_direction:
- dignity and connection

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Being seen more clearly does not mean you are less worthy of connection.

## Mixed Branch Lesson 049: shame_pride_self_visibility

arch_emotion_mix: shame + pride

scenario_object:
- feeling proud publicly

attached_meaning_risk:
- visibility means arrogance

restorative_direction:
- grounded confidence

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Being proud of real effort does not make your confidence arrogant.

## Mixed Branch Lesson 050: shame_sadness_rejection

arch_emotion_mix: shame + sadness

scenario_object:
- being rejected

attached_meaning_risk:
- rejection means defectiveness

restorative_direction:
- worth and dignity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Rejection can hurt without proving something is wrong with your value.

## Mixed Branch Lesson 051: confusion_self_doubt_judgment

arch_emotion_mix: confusion + self-doubt

scenario_object:
- not knowing how to read situation

attached_meaning_risk:
- confusion means cannot trust self

restorative_direction:
- clarity and self-trust

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Not knowing yet does not mean you cannot understand.

## Mixed Branch Lesson 052: confusion_fear_mixed_signals

arch_emotion_mix: confusion + fear

scenario_object:
- mixed signals

attached_meaning_risk:
- unclear means danger

restorative_direction:
- steady interpretation

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Mixed signals can feel unsettling without proving the worst meaning.

## Mixed Branch Lesson 053: confusion_guilt_reaction

arch_emotion_mix: confusion + guilt

scenario_object:
- not knowing if reaction was fair

attached_meaning_risk:
- uncertainty means guilt is deserved

restorative_direction:
- clean review

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Questioning your reaction does not prove you were wrong.

## Mixed Branch Lesson 054: confusion_anger_misunderstood

arch_emotion_mix: confusion + anger

scenario_object:
- being misunderstood

attached_meaning_risk:
- misunderstanding means attack

restorative_direction:
- clarity and control

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling misunderstood can matter without anger deciding the full story.

## Mixed Branch Lesson 055: confusion_sadness_change

arch_emotion_mix: confusion + sadness

scenario_object:
- someone changing

attached_meaning_risk:
- change means loss is final

restorative_direction:
- clarity and hope

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- A change can hurt before it proves what is gone.

## Mixed Branch Lesson 056: overwhelm_guilt_capacity

arch_emotion_mix: overwhelm + guilt

scenario_object:
- not keeping up

attached_meaning_risk:
- overwhelm means failure

restorative_direction:
- capacity and order

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Being overwhelmed can show capacity is stretched, not that you failed.

## Mixed Branch Lesson 057: overwhelm_fear_future

arch_emotion_mix: overwhelm + fear

scenario_object:
- too much ahead

attached_meaning_risk:
- too much means impossible

restorative_direction:
- order and capability

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- A lot ahead does not mean you cannot take the next step.

## Mixed Branch Lesson 058: overwhelm_shame_needing_break

arch_emotion_mix: overwhelm + shame

scenario_object:
- needing a break

attached_meaning_risk:
- break means weakness

restorative_direction:
- capacity and self-respect

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Needing a break can protect capacity without lowering your worth.

## Mixed Branch Lesson 059: overwhelm_anger_pressure

arch_emotion_mix: overwhelm + anger

scenario_object:
- pressure building

attached_meaning_risk:
- pressure means reaction must take over

restorative_direction:
- controlled clarity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Pressure can explain the intensity without needing to control the response.

## Mixed Branch Lesson 060: overwhelm_sadness_falling_behind

arch_emotion_mix: overwhelm + sadness

scenario_object:
- feeling behind

attached_meaning_risk:
- behind means hopeless

restorative_direction:
- possibility and movement

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling behind does not mean movement is gone.

## Mixed Branch Lesson 061: numbness_guilt_not_reacting

arch_emotion_mix: numbness + guilt

scenario_object:
- not reacting how expected

attached_meaning_risk:
- numbness means not caring

restorative_direction:
- reconnection and care

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Numbness can show overload without proving care is gone.

## Mixed Branch Lesson 062: numbness_fear_brokenness

arch_emotion_mix: numbness + fear

scenario_object:
- feeling nothing

attached_meaning_risk:
- numb means broken

restorative_direction:
- reconnection and steadiness

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling numb does not prove something is broken in you.

## Mixed Branch Lesson 063: numbness_sadness_loss

arch_emotion_mix: numbness + sadness

scenario_object:
- loss too hard to feel

attached_meaning_risk:
- not feeling means loss did not matter

restorative_direction:
- care and pacing

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Not feeling everything at once does not mean it did not matter.

## Mixed Branch Lesson 064: numbness_shame_disconnection

arch_emotion_mix: numbness + shame

scenario_object:
- feeling disconnected

attached_meaning_risk:
- disconnection means badness

restorative_direction:
- dignity and reconnection

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Disconnection can be a sign of overload, not a judgment on your character.

## Mixed Branch Lesson 065: numbness_relief_pressure_end

arch_emotion_mix: numbness + relief

scenario_object:
- pressure ending after overload

attached_meaning_risk:
- relief means lack of care

restorative_direction:
- recovery and care

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Relief after overload does not mean care disappeared.

## Mixed Branch Lesson 066: resentment_guilt_unmet_need

arch_emotion_mix: resentment + guilt

scenario_object:
- resenting someone you care about

attached_meaning_risk:
- resentment means lack of love

restorative_direction:
- honest recognition and care

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Resentment can show something felt repeatedly unmet without proving you stopped caring.

## Mixed Branch Lesson 067: resentment_sadness_repeated_disappointment

arch_emotion_mix: resentment + sadness

scenario_object:
- being disappointed repeatedly

attached_meaning_risk:
- disappointment means connection has no value

restorative_direction:
- honest recognition

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Repeated disappointment can hurt without erasing what mattered.

## Mixed Branch Lesson 068: resentment_anger_boundary

arch_emotion_mix: resentment + anger

scenario_object:
- boundary repeatedly ignored

attached_meaning_risk:
- anger means loss of control

restorative_direction:
- controlled boundary clarity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Resentment may show a repeated limit was ignored; the response can still stay clear.

## Mixed Branch Lesson 069: resentment_shame_needing_more

arch_emotion_mix: resentment + shame

scenario_object:
- wanting more from relationship

attached_meaning_risk:
- wanting more means selfishness

restorative_direction:
- need recognition

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Wanting more from a connection does not automatically make the need selfish.

## Mixed Branch Lesson 070: resentment_fear_speaking_up

arch_emotion_mix: resentment + fear

scenario_object:
- afraid to name unmet need

attached_meaning_risk:
- speaking up means rupture

restorative_direction:
- honesty and steadiness

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Naming an unmet need does not automatically mean the connection has to break.

## Mixed Branch Lesson 071: gratitude_grief_change

arch_emotion_mix: gratitude + grief

scenario_object:
- good thing ending

attached_meaning_risk:
- gratitude means grief should disappear

restorative_direction:
- both can belong

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Being grateful for what happened does not mean you stop grieving what changed.

## Mixed Branch Lesson 072: gratitude_guilt_receiving

arch_emotion_mix: gratitude + guilt

scenario_object:
- receiving help or kindness

attached_meaning_risk:
- receiving means taking too much

restorative_direction:
- receiving with dignity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Being grateful does not mean you have to feel guilty for receiving.

## Mixed Branch Lesson 073: gratitude_sadness_memory

arch_emotion_mix: gratitude + sadness

scenario_object:
- remembering something meaningful

attached_meaning_risk:
- sadness means gratitude is false

restorative_direction:
- memory with care

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Gratitude and sadness can both show something mattered.

## Mixed Branch Lesson 074: gratitude_fear_losing_good

arch_emotion_mix: gratitude + fear

scenario_object:
- good moment feeling fragile

attached_meaning_risk:
- gratitude means loss is near

restorative_direction:
- receiving present good

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling grateful does not require expecting the good to disappear.

## Mixed Branch Lesson 075: gratitude_shame_worth_receiving

arch_emotion_mix: gratitude + shame

scenario_object:
- being cared for

attached_meaning_risk:
- care means undeserved

restorative_direction:
- worthiness and receiving

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Receiving care does not prove you are undeserving of it.

## Mixed Branch Lesson 076: love_fear_loss

arch_emotion_mix: love + fear

scenario_object:
- caring deeply

attached_meaning_risk:
- love means risk will become loss

restorative_direction:
- connection and courage

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Caring deeply can feel vulnerable without proving loss is already coming.

## Mixed Branch Lesson 077: love_guilt_boundary

arch_emotion_mix: love + guilt

scenario_object:
- setting limit with someone loved

attached_meaning_risk:
- limit means lack of love

restorative_direction:
- love with capacity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- A boundary does not erase love; it can show capacity needs protection.

## Mixed Branch Lesson 078: love_anger_hurt

arch_emotion_mix: love + anger

scenario_object:
- being hurt by someone loved

attached_meaning_risk:
- anger means love is gone

restorative_direction:
- care with clarity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling hurt or angry does not automatically mean love disappeared.

## Mixed Branch Lesson 079: love_sadness_distance

arch_emotion_mix: love + sadness

scenario_object:
- distance from someone loved

attached_meaning_risk:
- distance means value lost

restorative_direction:
- connection and worth

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Distance can hurt without deciding your value or the meaning of the bond.

## Mixed Branch Lesson 080: love_shame_needing_connection

arch_emotion_mix: love + shame

scenario_object:
- wanting closeness

attached_meaning_risk:
- wanting closeness means neediness

restorative_direction:
- connection and dignity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Wanting closeness does not mean your need for connection is too much.

## Mixed Branch Lesson 081: trust_caution_new_connection

arch_emotion_mix: trust + caution

scenario_object:
- opening to someone

attached_meaning_risk:
- caution means distrust or failure

restorative_direction:
- steady openness

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Being cautious does not mean you cannot trust; it may mean trust is being built carefully.

## Mixed Branch Lesson 082: trust_fear_past_hurt

arch_emotion_mix: trust + fear

scenario_object:
- trust after being hurt before

attached_meaning_risk:
- fear means trust is unsafe

restorative_direction:
- discernment and steadiness

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Fear after past hurt does not prove trust is impossible now.

## Mixed Branch Lesson 083: trust_hope_uncertainty

arch_emotion_mix: trust + hope

scenario_object:
- wanting to believe someone

attached_meaning_risk:
- hope means ignoring risk

restorative_direction:
- discernment and hope

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Hope can exist with caution without making you careless.

## Mixed Branch Lesson 084: trust_guilt_needing_proof

arch_emotion_mix: trust + guilt

scenario_object:
- wanting consistency before trusting

attached_meaning_risk:
- needing consistency means unfairness

restorative_direction:
- discernment and self-respect

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Wanting consistency before fully trusting does not make you unfair.

## Mixed Branch Lesson 085: trust_sadness_broken_past

arch_emotion_mix: trust + sadness

scenario_object:
- trust was broken before

attached_meaning_risk:
- past break means future trust impossible

restorative_direction:
- possibility and care

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Broken trust can matter without making future trust impossible.

## Mixed Branch Lesson 086: confidence_vulnerability_seen

arch_emotion_mix: confidence + vulnerability

scenario_object:
- showing confidence while exposed

attached_meaning_risk:
- confidence means risk of judgment

restorative_direction:
- confidence with dignity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling confident while visible does not mean you are asking to be judged.

## Mixed Branch Lesson 087: confidence_fear_next_step

arch_emotion_mix: confidence + fear

scenario_object:
- taking a new step

attached_meaning_risk:
- fear means confidence is fake

restorative_direction:
- courage and steadiness

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Fear can be present without making your confidence false.

## Mixed Branch Lesson 088: confidence_guilt_outgrowing

arch_emotion_mix: confidence + guilt

scenario_object:
- growing beyond old role

attached_meaning_risk:
- growth means abandoning others

restorative_direction:
- growth and care

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Growing does not mean you stopped caring about where you came from.

## Mixed Branch Lesson 089: confidence_shame_visibility

arch_emotion_mix: confidence + shame

scenario_object:
- being noticed

attached_meaning_risk:
- being seen means arrogance

restorative_direction:
- grounded visibility

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Being visible does not mean you are trying to be above anyone.

## Mixed Branch Lesson 090: confidence_sadness_late_self_belief

arch_emotion_mix: confidence + sadness

scenario_object:
- finally believing after self-doubt

attached_meaning_risk:
- late confidence means wasted time

restorative_direction:
- self-recognition and possibility

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Finding confidence later does not erase the value of finding it now.

## Mixed Branch Lesson 091: contentment_fear_losing_peace

arch_emotion_mix: contentment + fear

scenario_object:
- feeling calm after chaos

attached_meaning_risk:
- calm means danger is waiting

restorative_direction:
- peace and trust

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Peace does not have to be treated like something you are about to lose.

## Mixed Branch Lesson 092: contentment_guilt_resting

arch_emotion_mix: contentment + guilt

scenario_object:
- feeling okay while resting

attached_meaning_risk:
- okay means not doing enough

restorative_direction:
- rest and capacity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling okay while resting does not mean you are failing.

## Mixed Branch Lesson 093: contentment_shame_not_striving

arch_emotion_mix: contentment + shame

scenario_object:
- not chasing more

attached_meaning_risk:
- contentment means laziness

restorative_direction:
- enoughness and steadiness

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling content does not mean you stopped growing.

## Mixed Branch Lesson 094: contentment_sadness_moving_on

arch_emotion_mix: contentment + sadness

scenario_object:
- feeling okay after loss

attached_meaning_risk:
- okay means the loss did not matter

restorative_direction:
- peace with memory

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling okay again does not mean what happened stopped mattering.

## Mixed Branch Lesson 095: contentment_hope_stability

arch_emotion_mix: contentment + hope

scenario_object:
- starting to feel stable

attached_meaning_risk:
- stability means something will disrupt it

restorative_direction:
- trust in steadiness

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Stability can be received without expecting it to be taken away.

## Mixed Branch Lesson 096: admiration_envy_desire

arch_emotion_mix: admiration + envy

scenario_object:
- seeing someone’s strength

attached_meaning_risk:
- envy means inferiority

restorative_direction:
- self-recognition

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Admiring someone can show what you value without making you less.

## Mixed Branch Lesson 097: admiration_sadness_distance

arch_emotion_mix: admiration + sadness

scenario_object:
- admiring from afar

attached_meaning_risk:
- distance means unreachable

restorative_direction:
- possibility and self-direction

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Someone else’s path can inspire you without proving your own is closed.

## Mixed Branch Lesson 098: admiration_guilt_comparison

arch_emotion_mix: admiration + guilt

scenario_object:
- comparing while admiring

attached_meaning_risk:
- comparison means badness

restorative_direction:
- honest desire and self-respect

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Feeling comparison beside admiration does not make the admiration fake.

## Mixed Branch Lesson 099: admiration_fear_trying

arch_emotion_mix: admiration + fear

scenario_object:
- wanting to try what someone does

attached_meaning_risk:
- fear means not capable

restorative_direction:
- confidence and movement

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Being afraid to try does not prove you cannot grow toward it.

## Mixed Branch Lesson 100: admiration_shame_visibility

arch_emotion_mix: admiration + shame

scenario_object:
- wanting similar recognition

attached_meaning_risk:
- wanting recognition means vanity

restorative_direction:
- value and desire clarity

response_construction_guidance:
- Name the scenario object before explaining the emotion branch.
- Build the proof boundary around the attached meaning risk, not around the emotion category alone.
- Move the response toward the restorative direction without using a fixed opposite-word formula.

carry_forward_anchor_example:
- Wanting to be recognized does not automatically mean you are vain.

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

