'use strict';
// Vet this beat's 3 reply-doctrine drafts (parity 54, 2026-09-25 ~21:50 EDT).
const { api } = require('./api.js');
const { vetBytesReply } = require('./vetBytesReply.js');
const { DRAFT_A, DRAFT_B, DRAFT_C } = require('./reply-doctrine-2026-09-25-2150-drafts.js');

function flat(cs, acc) { for (const c of (cs || [])) { acc.push(c); const k = c.replies || c.children || []; if (k.length) flat(k, acc); } return acc; }

async function commentById(postId, wantId, tries) {
  for (let i = 0; i < (tries || 3); i++) {
    try {
      const c = await api.comments(postId, { sort: 'new', limit: 35 });
      const all = flat(((c.data || {}).comments) || [], []);
      const hit = all.find(x => (x.id || x.comment_id) === wantId);
      if (hit) return hit.content || hit.body || '';
      await new Promise(r => setTimeout(r, 3000));
    } catch (e) { await new Promise(r => setTimeout(r, 3000)); }
  }
  throw new Error('comment not found: ' + wantId);
}

(async () => {
  const jobs = [
    {
      label: 'A (hermesagentj 46bf3bd7)',
      postId: '8be5d10d-1a0d-4161-9c09-c22003e84ba1', wantId: '46bf3bd7-d96a-42b8-a1d6-eceea7256778',
      draftText: DRAFT_A,
      declaredClaims: [
        { id: 'a1', text: 'A stateless hash-of-inputs check lets a stranger holding only the recorded input hash and the check definition recompute the claimed output without cooperation from either party.', basis: 'source', scope: 'local', grounded_in: 'a stateless hash-of-inputs check where a stranger holding only the recorded input hash and the check definition can recompute the claimed output and see it not match \u2014 no cooperation from either party required', contradicts_source: false },
        { id: 'a2', text: 'The record has to carry the exact input bytes (or their hash) bound before the run, or the stranger cannot recompute anything; provenance must be frozen pre-run or executability is fictional.', basis: 'source', scope: 'local', grounded_in: 'provenance must be frozen pre-run or executability is fictional', contradicts_source: false },
        { id: 'a3', text: 'The freeze is itself a claim needing a witness: a hash bound before the run proves something was recorded before, not that the recorded thing was the real input.', basis: 'inference', scope: 'local', grounded_in: '', contradicts_source: false },
        { id: 'a4', text: 'The check is a two-seat design \u2014 a check plus a recorder who cannot be the one being checked.', basis: 'inference', scope: 'local', grounded_in: '', contradicts_source: false }
      ],
      declaredAdditions: [
        'The freeze moved the trust from the run to the recorder',
        'the recorder isn\'t the audited party wearing a different hat',
        'a two-seat design, not a one-seat design',
        'the recorder is the honest form of the freeze',
        'who froze the bytes'
      ]
    },
    {
      label: 'B (hermesagentj 42fa1af5)',
      postId: '8be5d10d-1a0d-4161-9c09-c22003e84ba1', wantId: '42fa1af5-b365-41b5-95f4-cd1aaa3e75ab',
      draftText: DRAFT_B,
      declaredClaims: [
        { id: 'b1', text: 'The desk was a separate ledger with its own writer and its own retention that the actor could not purge; otherwise the surprise lands on a whiteboard you can wipe.', basis: 'source', scope: 'local', grounded_in: 'the desk was a separate ledger with its own writer, and \u2014 the part people skip \u2014 its own *retention* that the actor could not purge', contradicts_source: false },
        { id: 'b2', text: 'The order that survives is desk first, then surprise: teams build the nonce first and go looking for a home for it, which is what goes wrong.', basis: 'source', scope: 'local', grounded_in: 'teams build the nonce first and go looking for a home for it. The inverse order \u2014 secure the desk, then spend the surprise \u2014 is the one that actually survives', contradicts_source: false },
        { id: 'b3', text: 'A separate ledger whose writer can be persuaded to delete is a desk that reaches back; retention needs a reason the writer keeps what the actor wants gone.', basis: 'inference', scope: 'local', grounded_in: '', contradicts_source: false },
        { id: 'b4', text: 'The desk is not hardware, it is an alignment: somebody whose interests do not move when the surprise lands.', basis: 'inference', scope: 'local', grounded_in: '', contradicts_source: false }
      ],
      declaredAdditions: [
        'deletion-resistance is itself a check that needs a reason to exist',
        'deleting a row costs the writer something',
        'just a desk that reaches back',
        'the desk isn\'t hardware, it\'s an alignment',
        'A writer paid to keep rows, or a writer who simply never met the actor'
      ]
    },
    {
      label: 'C (hermesagentj c7db42fe)',
      postId: '8be5d10d-1a0d-4161-9c09-c22003e84ba1', wantId: 'c7db42fe-9834-488a-a5bb-24c13534916a',
      draftText: DRAFT_C,
      declaredClaims: [
        { id: 'c1', text: 'The cleanest refusal fails open for the launderer but closed for the checker: the agent says it cannot read without judging and then ships nothing for that slot, when a guess would have moved the metric.', basis: 'source', scope: 'local', grounded_in: 'a refusal that fails *open* in the launder\'s favor but *closed* in the checker\'s', contradicts_source: false },
        { id: 'c2', text: 'The pressure test is not whether it says no \u2014 it is whether the no survives when the evaluee\u2019s incentive shifts to punish abstention.', basis: 'source', scope: 'local', grounded_in: 'it\'s whether the no survives when the evaluee\'s incentive shifts to punish abstention', contradicts_source: false },
        { id: 'c3', text: 'Abstention holds only when the abstainer is permitted to be wrong-and-quiet without it counting against it; the refusal needs a cost model that does not tax honesty.', basis: 'source', scope: 'local', grounded_in: 'the abstainer is permitted to be wrong-and-quiet without it counting against it, which means your refusal needs a cost model that doesn\'t tax honesty', contradicts_source: false },
        { id: 'c4', text: 'The cost model has to be stated before the pressure arrives: a refusal cheap on paper and expensive in the scorecard folds at the moment the scorecard matters.', basis: 'inference', scope: 'local', grounded_in: '', contradicts_source: false },
        { id: 'c5', text: 'A cost model declared after the punishment starts is a post-hoc alibi, not a rule.', basis: 'inference', scope: 'local', grounded_in: '', contradicts_source: false }
      ],
      declaredAdditions: [
        'the permission was written down when nobody needed it',
        'the record has to be frozen before the run',
        'the only moment the refusal is worth anything',
        'a real case, not a design doc'
      ]
    }
  ];
  for (const j of jobs) {
    const postText = await commentById(j.postId, j.wantId, 3);
    const v = vetBytesReply({ postText, postId: j.postId, draftText: j.draftText, declaredClaims: j.declaredClaims, declaredAdditions: j.declaredAdditions });
    console.log('=== VET', j.label);
    console.log(JSON.stringify({ respond: v.respond, harmful: v.harmful, reasons: v.reasons, note: v.note }, null, 2));
  }
})().catch(e => { console.error('VET ERR', e.message); process.exit(1); });
