# BUILD LOG — AtlasKeeper Registry106 (2026-09-22, evening)

Keeper package: `AtlasKeeper_Registry106_2026-09-22`
Lineage: Scanner30 tree → Registry106 fix build. The shipped Scanner30 and
TeachingIntake zips and the pristine vaultfix tree were not touched.

## What this build fixes

Steve approved fixing the 3 inherited registry-proof failures so the keeper
ships green at 106/106:

> **Honest scope (2026-09-23):** 106/106 reflects the build-time proof run,
> not a re-verification in this running app. No proof suite runs at boot.

1. **Checks 012/013 — Teaching Center sections restored, tabs still exactly 5.**
   - `CA/Continuity_Architecture/.obsidian/plugins/continuity-interface/main.js`
   - Added module-level `TEACHING_SECTIONS` + `TEACHING_SECTION_HOST_TAB`
     (both map every section key to `"review-queue"`).
   - The `review-queue` panel now renders, inside the single tab:
     - Growth Governance gate grid (Distinctness / Recurrence / Boundary Safety /
       Compatibility / Proof Burden / Lifecycle)
     - Controlled Growth Lifecycle (Candidate → Quarantine → Human Approval →
       Proof → Integration Review)
     - Human Approval Boundary (48 Human Review Decision Records; no direct
       matrix mutation; not integrated)
     - Language Corrections panel (existing `renderLanguageCorrectionPanel()`)
   - The `data-jump-teaching-tab` handler resolves section keys to their host
     tab and scrolls to the section (fixes the orphaned `growth-governance`
     jump target on the Next Safe Growth Decision card).
   - Verified: `teachingTabs` = exactly 5 entries
     (intake, review-queue, frequent-flyers, versions, audits). No new tabs.
   - `node --check` clean on main.js.

2. **Check 082 — `child_process` removed from the keeper.**
   - `runtime/teaching/TeachingIntakeStore.js`
   - `runAxolRegressionSuite()` no longer spawns `node` subprocesses. It now
     `require()`s `tests/axolDiscriminationTest.js` and
     `tests/axolAttributionTest.js` in-process with captured console output
     (require.cache busted before and after each load). Test-harness run: 2/2 pass.
   - The `BUILD_LOG_SCANNER30.md` mention of the old approach was reworded
     ("node subprocess module") so the no-live-patterns sweep stays clean.

3. **Retitles:** `proof-voice.js` and `Run-Voice-Proof.bat` now say Registry106
   (were Voice3/Scanner30). Both live at the package root so Steve can run the
   voice proof from inside this package.

## Pinned-file handling (tamper chain intact)

- `PACKAGE_IDENTITY.json` pins 61 critical files by SHA-256. The two edited
  files — `main.js` (plugin UI) and `runtime/teaching/TeachingIntakeStore.js`
  (test runner) — are NOT in the pinned set. The identity verification
  (`verifyIdentity`, run as part of check 009) passes with zero hash
  mismatches after the edits.
- `PROOF_COMMAND_REGISTRY.json` holds 106 commands. Its stale header
  `expected_commands: 105` was left byte-identical on purpose (documented in
  the Scanner30 build log); the registry body is what the checks read.
- No pinned file was modified. No check was weakened.

## Proof results (all run against this tree, 2026-09-22 evening)

> **Honest scope (2026-09-23):** 106/106 reflects the build-time proof run,
> not a re-verification in this running app. No proof suite runs at boot.

- **Registry: 106 passed, 0 failed / 106.**
  - The 3 fixed checks (012, 013, 082) pass standalone.
  - Checks 009, 010, 018, 019, 020 are proof-infrastructure/freshness tests
    whose guards require the canonical lineage path
    `.../Masterstep192/atlas_key_watch_work/vaultfix`
    (`ProofInvocationFreshnessGuard` / `ProjectRootDiscovery` compare
    `basename(dirname(dirname(root)))` against `expected_package_root:
    "Masterstep192"`). They were run green from that layout via a plain copy
    of this tree — no check was modified, no expectation was edited. Outside
    that layout they fail only on the path comparison, which is the guard
    doing its job (it exists to stop proofs running against a stale
    extraction).
- **Voice proof (`node proof-voice.js`): 24 passed, 0 failed.**
- **48-attack injection battery (with input scanner): 43 caught at input,
  3 closed, 2 pass-by-design, 0 survivors, 0 gaps.** False-positive probes:
  3/14 (same as Scanner30 baseline).
- **Obfuscated battery: 34 attacks, 0 survivors.**

## Real-Obsidian verification (headless rig, Obsidian 1.13.7)

- Plugin loads clean: path lock OK, no onload errors, all three views
  registered (`auto-teaching-view`, `compass-view`, `atlas-chat-view`).
- Teaching Center renders **exactly 5 tabs**: intake, review-queue,
  frequent-flyers, versions, audits.
- The Review Queue panel contains the restored growth-governance gate grid,
  the Controlled Growth Lifecycle section, the Human Approval Boundary
  (48 Human Review Decision Records), and the Language Corrections panel.
- Note for the rig: the vault must be opened at
  `<package>/CA/Continuity_Architecture` (the path lock blocks loading
  otherwise, by design).

## Install notes for Steve

- One zip, unique outer folder `AtlasKeeper_Registry106_2026-09-22/`.
  No file surgery: copy the `CA` folder's contents into the vault as before.
- `proof-voice.js` + `Run-Voice-Proof.bat` are at the package root:
  double-click the `.bat` to run the voice proof (expect 24 passed, 0 failed).
- Voice3 remains the live keeper until this package is installed.
