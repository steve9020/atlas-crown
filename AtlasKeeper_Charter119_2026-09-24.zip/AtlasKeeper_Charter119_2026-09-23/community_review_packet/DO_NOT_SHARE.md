# Do Not Share

Do not share source packages, backend/runtime files, private vault contents, proof logs, internal test files, raw model outputs, credentials, tokens, machine-specific paths, or implementation details that expose internal governance mechanics.

Do not share sensitive personal prompts or any content that depends on private lived material.

Do not present the project as public-release ready, clinical-ready, crisis-ready, autonomous, or exhaustively proven.
