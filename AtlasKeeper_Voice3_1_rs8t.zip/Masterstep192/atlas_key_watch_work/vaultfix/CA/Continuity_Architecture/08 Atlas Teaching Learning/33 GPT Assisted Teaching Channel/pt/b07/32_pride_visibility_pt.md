---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 07
category: pride_and_visibility
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 32. Pride and Visibility Pressure Tests — Batch 07

## Category Purpose

Pride and visibility pressure activates when being seen, recognized, noticed, praised, successful, expressive, or proud creates exposure pressure, fear of judgment, embarrassment, or conflict with humility.

## Reusable Teaching Correction

Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

## Reverse-Flow Target

grounded pride, visible dignity, confidence without arrogance, safe self-expression

## Failure Risks To Avoid

- inflating pride into superiority
- telling the user to ignore everyone
- shaming visibility fear
- using hype language
- making humility mean self-erasure

---

## 80 Pressure Tests

### Test 01
**Prompt:** I accomplished something and felt weird being seen and it makes me believe being proud means I am arrogant, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** being proud means I am arrogant
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 02
**Prompt:** I feel visible. I wanted to post about it but felt exposed keeps affecting fear of judgment and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** I should shrink so others are comfortable
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 03
**Prompt:** I keep replaying how someone complimented me and I pulled back because it affects self-expression and makes me believe confidence means I think I am better than others.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** confidence means I think I am better than others
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 04
**Prompt:** When I feel proud but then ashamed for feeling proud, the feeling moves straight into recognition means people will judge me. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** recognition means people will judge me
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 05
**Prompt:** The situation is I do not know how to let myself be recognized, and the meaning that keeps attaching is I cannot enjoy progress openly. It is making fear of judgment feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** I cannot enjoy progress openly
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 06
**Prompt:** I feel like success makes people look at me differently and it makes me believe being seen makes me unsafe, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** being seen makes me unsafe
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 07
**Prompt:** I feel guilty for being proud. I want to be confident but not arrogant keeps affecting visibility and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** visibility will make me a target
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 08
**Prompt:** I keep replaying how I became visible and wanted to hide because it affects fear of judgment and makes me believe being proud means I am arrogant.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** being proud means I am arrogant
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 09
**Prompt:** When I accomplished something and felt weird being seen, the feeling moves straight into my success makes me selfish. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** my success makes me selfish
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 10
**Prompt:** The situation is I wanted to post about it but felt exposed, and the meaning that keeps attaching is confidence means I think I am better than others. It is making visibility feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** confidence means I think I am better than others
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 11
**Prompt:** Someone complimented me and i pulled back and it keeps turning into I should shrink so others are comfortable, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** I should shrink so others are comfortable
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 12
**Prompt:** I feel visible. I feel proud but then ashamed for feeling proud keeps affecting self-expression and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** I cannot enjoy progress openly
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 13
**Prompt:** I keep replaying how I do not know how to let myself be recognized because it affects visibility and makes me believe recognition means people will judge me.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** recognition means people will judge me
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 14
**Prompt:** When I feel like success makes people look at me differently, the feeling moves straight into visibility will make me a target. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** visibility will make me a target
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 15
**Prompt:** The situation is I want to be confident but not arrogant, and the meaning that keeps attaching is being seen makes me unsafe. It is making self-expression feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** being seen makes me unsafe
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 16
**Prompt:** I became visible and wanted to hide and it keeps turning into my success makes me selfish, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** my success makes me selfish
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 17
**Prompt:** people saw me succeed and now I feel weird. I accomplished something and felt weird being seen keeps affecting fear of judgment and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** being proud means I am arrogant
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 18
**Prompt:** I keep replaying how I wanted to post about it but felt exposed because it affects self-expression and makes me believe I should shrink so others are comfortable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** I should shrink so others are comfortable
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 19
**Prompt:** When someone complimented me and I pulled back, the feeling moves straight into confidence means I think I am better than others. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** confidence means I think I am better than others
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 20
**Prompt:** The situation is I feel proud but then ashamed for feeling proud, and the meaning that keeps attaching is recognition means people will judge me. It is making fear of judgment feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** recognition means people will judge me
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 21
**Prompt:** I do not know how to let myself be recognized and it has me treating visibility as if I cannot enjoy progress openly, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** I cannot enjoy progress openly
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 22
**Prompt:** I feel proud but embarrassed. I feel like success makes people look at me differently keeps affecting visibility and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** being seen makes me unsafe
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 23
**Prompt:** I keep replaying how I want to be confident but not arrogant because it affects fear of judgment and makes me believe visibility will make me a target.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** visibility will make me a target
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 24
**Prompt:** When I became visible and wanted to hide, the feeling moves straight into being proud means I am arrogant. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** being proud means I am arrogant
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 25
**Prompt:** The situation is I accomplished something and felt weird being seen, and the meaning that keeps attaching is my success makes me selfish. It is making visibility feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** my success makes me selfish
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 26
**Prompt:** I wanted to post about it but felt exposed and it makes pride feel like confidence means I think I am better than others, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** confidence means I think I am better than others
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 27
**Prompt:** people saw me succeed and now I feel weird. Someone complimented me and i pulled back keeps affecting self-expression and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** I should shrink so others are comfortable
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 28
**Prompt:** I keep replaying how I feel proud but then ashamed for feeling proud because it affects visibility and makes me believe I cannot enjoy progress openly.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** I cannot enjoy progress openly
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 29
**Prompt:** When I do not know how to let myself be recognized, the feeling moves straight into recognition means people will judge me. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** recognition means people will judge me
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 30
**Prompt:** The situation is I feel like success makes people look at me differently, and the meaning that keeps attaching is visibility will make me a target. It is making self-expression feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** visibility will make me a target
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 31
**Prompt:** I want to be confident but not arrogant and it makes pride feel like being seen makes me unsafe, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** being seen makes me unsafe
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 32
**Prompt:** I feel proud but embarrassed. I became visible and wanted to hide keeps affecting fear of judgment and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** my success makes me selfish
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 33
**Prompt:** I keep replaying how I accomplished something and felt weird being seen because it affects self-expression and makes me believe being proud means I am arrogant.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** being proud means I am arrogant
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 34
**Prompt:** When I wanted to post about it but felt exposed, the feeling moves straight into I should shrink so others are comfortable. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** I should shrink so others are comfortable
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 35
**Prompt:** The situation is someone complimented me and I pulled back, and the meaning that keeps attaching is confidence means I think I am better than others. It is making fear of judgment feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** confidence means I think I am better than others
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 36
**Prompt:** I feel proud but then ashamed for feeling proud and it pulls me toward thinking recognition means people will judge me, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** recognition means people will judge me
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 37
**Prompt:** I am scared of looking arrogant. I do not know how to let myself be recognized keeps affecting visibility and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** I cannot enjoy progress openly
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 38
**Prompt:** I keep replaying how I feel like success makes people look at me differently because it affects fear of judgment and makes me believe being seen makes me unsafe.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** being seen makes me unsafe
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 39
**Prompt:** When I want to be confident but not arrogant, the feeling moves straight into visibility will make me a target. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** visibility will make me a target
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 40
**Prompt:** The situation is I became visible and wanted to hide, and the meaning that keeps attaching is being proud means I am arrogant. It is making visibility feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** being proud means I am arrogant
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 41
**Prompt:** I accomplished something and felt weird being seen and it keeps attaching recognition to my success makes me selfish, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** my success makes me selfish
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 42
**Prompt:** I do not like being noticed. I wanted to post about it but felt exposed keeps affecting self-expression and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** confidence means I think I am better than others
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 43
**Prompt:** I keep replaying how someone complimented me and I pulled back because it affects visibility and makes me believe I should shrink so others are comfortable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** I should shrink so others are comfortable
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 44
**Prompt:** When I feel proud but then ashamed for feeling proud, the feeling moves straight into I cannot enjoy progress openly. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** I cannot enjoy progress openly
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 45
**Prompt:** The situation is I do not know how to let myself be recognized, and the meaning that keeps attaching is recognition means people will judge me. It is making self-expression feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** recognition means people will judge me
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 46
**Prompt:** I feel like success makes people look at me differently and it keeps attaching recognition to visibility will make me a target, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** visibility will make me a target
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 47
**Prompt:** I am scared of looking arrogant. I want to be confident but not arrogant keeps affecting fear of judgment and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** being seen makes me unsafe
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 48
**Prompt:** I keep replaying how I became visible and wanted to hide because it affects self-expression and makes me believe my success makes me selfish.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** my success makes me selfish
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 49
**Prompt:** When I accomplished something and felt weird being seen, the feeling moves straight into being proud means I am arrogant. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** being proud means I am arrogant
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 50
**Prompt:** The situation is I wanted to post about it but felt exposed, and the meaning that keeps attaching is I should shrink so others are comfortable. It is making fear of judgment feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** I should shrink so others are comfortable
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 51
**Prompt:** Someone complimented me and i pulled back and it makes confidence feel like confidence means I think I am better than others, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** confidence means I think I am better than others
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 52
**Prompt:** I do not like being noticed. I feel proud but then ashamed for feeling proud keeps affecting visibility and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** recognition means people will judge me
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 53
**Prompt:** I keep replaying how I do not know how to let myself be recognized because it affects fear of judgment and makes me believe I cannot enjoy progress openly.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** I cannot enjoy progress openly
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 54
**Prompt:** When I feel like success makes people look at me differently, the feeling moves straight into being seen makes me unsafe. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** being seen makes me unsafe
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 55
**Prompt:** The situation is I want to be confident but not arrogant, and the meaning that keeps attaching is visibility will make me a target. It is making visibility feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** visibility will make me a target
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 56
**Prompt:** I became visible and wanted to hide and it makes confidence feel like being proud means I am arrogant, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** being proud means I am arrogant
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 57
**Prompt:** I want recognition but it scares me. I accomplished something and felt weird being seen keeps affecting self-expression and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** my success makes me selfish
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 58
**Prompt:** I keep replaying how I wanted to post about it but felt exposed because it affects visibility and makes me believe confidence means I think I am better than others.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** confidence means I think I am better than others
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 59
**Prompt:** When someone complimented me and I pulled back, the feeling moves straight into I should shrink so others are comfortable. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** I should shrink so others are comfortable
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 60
**Prompt:** The situation is I feel proud but then ashamed for feeling proud, and the meaning that keeps attaching is I cannot enjoy progress openly. It is making self-expression feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** I cannot enjoy progress openly
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 61
**Prompt:** I do not know how to let myself be recognized and it turns being seen into recognition means people will judge me, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** recognition means people will judge me
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 62
**Prompt:** I want to share something but feel exposed. I feel like success makes people look at me differently keeps affecting fear of judgment and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** visibility will make me a target
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 63
**Prompt:** I keep replaying how I want to be confident but not arrogant because it affects self-expression and makes me believe being seen makes me unsafe.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** being seen makes me unsafe
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 64
**Prompt:** When I became visible and wanted to hide, the feeling moves straight into my success makes me selfish. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** my success makes me selfish
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 65
**Prompt:** The situation is I accomplished something and felt weird being seen, and the meaning that keeps attaching is being proud means I am arrogant. It is making fear of judgment feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** being proud means I am arrogant
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 66
**Prompt:** I wanted to post about it but felt exposed and it makes me believe I should shrink so others are comfortable, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** I should shrink so others are comfortable
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 67
**Prompt:** I want recognition but it scares me. Someone complimented me and i pulled back keeps affecting visibility and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** confidence means I think I am better than others
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 68
**Prompt:** I keep replaying how I feel proud but then ashamed for feeling proud because it affects fear of judgment and makes me believe recognition means people will judge me.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** recognition means people will judge me
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 69
**Prompt:** When I do not know how to let myself be recognized, the feeling moves straight into I cannot enjoy progress openly. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** I cannot enjoy progress openly
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 70
**Prompt:** The situation is I feel like success makes people look at me differently, and the meaning that keeps attaching is being seen makes me unsafe. It is making visibility feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** being seen makes me unsafe
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 71
**Prompt:** I want to be confident but not arrogant and it makes me believe visibility will make me a target, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** visibility will make me a target
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 72
**Prompt:** I want to share something but feel exposed. I became visible and wanted to hide keeps affecting self-expression and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** being proud means I am arrogant
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 73
**Prompt:** I keep replaying how I accomplished something and felt weird being seen because it affects visibility and makes me believe my success makes me selfish.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** my success makes me selfish
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 74
**Prompt:** When I wanted to post about it but felt exposed, the feeling moves straight into confidence means I think I am better than others. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** confidence means I think I am better than others
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 75
**Prompt:** The situation is someone complimented me and I pulled back, and the meaning that keeps attaching is I should shrink so others are comfortable. It is making self-expression feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** I should shrink so others are comfortable
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 76
**Prompt:** I feel proud but then ashamed for feeling proud and it keeps turning into I cannot enjoy progress openly, even though part of me knows I may not have the full picture.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** I cannot enjoy progress openly
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid inflating pride into superiority.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 77
**Prompt:** I feel visible. I do not know how to let myself be recognized keeps affecting fear of judgment and I cannot tell what is actually true.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** recognition means people will judge me
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid telling the user to ignore everyone.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 78
**Prompt:** I keep replaying how I feel like success makes people look at me differently because it affects self-expression and makes me believe visibility will make me a target.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** self-expression
**Attached meaning to separate:** visibility will make me a target
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid shaming visibility fear.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 79
**Prompt:** When I want to be confident but not arrogant, the feeling moves straight into being seen makes me unsafe. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** visibility
**Attached meaning to separate:** being seen makes me unsafe
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid using hype language.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.

### Test 80
**Prompt:** The situation is I became visible and wanted to hide, and the meaning that keeps attaching is my success makes me selfish. It is making fear of judgment feel unstable.
**Expected primary route:** `pride_and_visibility`
**Pressure focus:** fear of judgment
**Attached meaning to separate:** my success makes me selfish
**Expected reverse-flow movement:** grounded pride, visible dignity, confidence without arrogance, safe self-expression
**Bad response risk:** Avoid making humility mean self-erasure.
**Teaching correction:** Separate grounded pride from arrogance and visibility from danger. Compass should help the user own growth, recognition, and confidence without shame, superiority, or self-erasure.
