const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const version = require('../version_status');

const root = path.resolve(__dirname, '..');
const required = [
  'runtime/backend/closedLoop/CadenceValidatorIntegrationProof.js',
  'runtime/backend/closedLoop/AlgorithmicVoiceCadenceValidator.js',
  'runtime/proof/MASTERSTEP75_CADENCE_VALIDATOR_INTEGRATION_PROOF.json',
  'runtime/proof/MASTERSTEP75_CADENCE_VALIDATOR_INTEGRATION_PROOF.md',
  'docs/MASTERSTEP75_CADENCE_VALIDATOR_INTEGRATION_PROOF_MAP.md',
  'tests/masterStep75CadenceValidatorIntegrationProofTest.js'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(root, rel)), 'missing Step75 artifact: ' + rel);

const proof = JSON.parse(fs.readFileSync(path.join(root, 'runtime/proof/MASTERSTEP75_CADENCE_VALIDATOR_INTEGRATION_PROOF.json'), 'utf8'));
assert.strictEqual(proof.passed, true, 'proof JSON must record Step75 pass');
assert.strictEqual(proof.source_keeper, 'Masterstep74');
assert.strictEqual(proof.cloud_work_deferred, true);
assert.strictEqual(proof.provider_connected, false);
assert.strictEqual(proof.real_model_connected, false);
assert.strictEqual(proof.api_keys_added, false);
assert.strictEqual(proof.endpoints_added, false);
assert.strictEqual(proof.network_bridge_added, false);
assert.strictEqual(proof.frontend_intelligence_added, false);
assert.strictEqual(proof.real_model_execution_added, false);
assert.strictEqual(proof.integration_scope, 'backend_closed_loop_post_generation_proof_signal_only');
assert.strictEqual(proof.cadence_validator_final_authority, false);
assert.strictEqual(proof.cadence_validator_may_silently_mutate, false);
assert.strictEqual(proof.cadence_validator_may_auto_commit, false);
assert.strictEqual(proof.cadence_validator_may_override_post_generation_validator, false);
assert.strictEqual(proof.fail_count, 0);
assert.strictEqual(proof.required_chain_evidence.cadence_report_attached_to_backend_flow, true);
assert.strictEqual(proof.required_chain_evidence.cadence_review_signal_routes_weak_voice, true);
assert.strictEqual(proof.required_chain_evidence.cadence_does_not_silently_mutate, true);
assert.strictEqual(proof.required_chain_evidence.cadence_does_not_auto_commit, true);
assert.strictEqual(proof.required_chain_evidence.cadence_does_not_override_post_generation_validator, true);
assert.strictEqual(proof.required_chain_evidence.low_anchor_density_remains_advisory_only, true);
assert.strictEqual(proof.required_chain_evidence.frontend_shell_still_dumb, true);
assert.strictEqual(proof.required_chain_evidence.provider_model_cloud_still_disconnected, true);
assert.strictEqual(proof.decision, 'CLOSE_STEP_75_AND_MOVE_TO_VOICE_DRIFT_REGRESSION_BATCH');

assert.strictEqual(version.currentKeeper, 'Masterstep75', 'version_status currentKeeper must be Masterstep75');
assert.strictEqual(version.previousKeeper, 'Masterstep74', 'version_status previousKeeper must be Masterstep74');
assert.strictEqual(version.step, 'Cadence Validator Integration Proof', 'version_status step must be Step75 title');
assert.strictEqual(version.aiConnected, false, 'AI/cloud must remain disconnected');
assert.strictEqual(version.providerConfigured, false, 'provider must remain unconfigured');
assert.strictEqual(version.providerWrapperExecutionEnabled, false, 'provider wrapper execution must remain disabled');
assert.strictEqual(version.networkBridgeEnabled, false, 'network bridge must remain disabled');
assert.strictEqual(version.frontendIntelligenceAllowed, false, 'frontend intelligence must remain blocked');
assert.strictEqual(version.backendOwnsIntelligence, true, 'backend ownership must remain true');
assert.strictEqual(version.cloudProviderEvaluationStarted, false, 'cloud provider evaluation must remain deferred');
assert.strictEqual(version.cadenceValidatorIntegrationProofComplete, true, 'Step75 integration proof must be complete');
assert.strictEqual(version.cadenceValidatorIntegrationWeakCasesRemaining, 0, 'Step75 weak cases must be zero');
assert.strictEqual(version.cadenceValidatorFinalAuthority, false, 'Cadence validator must not become final authority');
assert.strictEqual(version.cadenceValidatorSilentMutationAllowed, false, 'Cadence validator must not silently mutate');
assert.strictEqual(version.cadenceValidatorAutoCommitAllowed, false, 'Cadence validator must not auto-commit');
assert.strictEqual(version.nextTarget, 'Masterstep76 — Voice Drift Regression Batch', 'next target must be local voice regression');

console.log('masterStep75FullClosureKeeperReadinessTest PASSED');
