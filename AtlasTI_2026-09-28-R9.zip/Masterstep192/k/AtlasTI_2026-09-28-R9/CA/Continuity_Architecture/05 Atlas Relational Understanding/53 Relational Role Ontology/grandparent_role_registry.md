# Grandparent Role Registry

## Roles
- grandmother / grandma / granny / nana / mamaw
- grandfather / grandpa / granddad / pawpaw

## Priority
Moderate-high emotional weight.

## Common Meaning Pressure
- care
- memory
- legacy
- family continuity
- grief
- protection
- belonging

## Runtime Rule
Grandparent references often carry continuity, loss, family meaning, or generational attachment weight.
