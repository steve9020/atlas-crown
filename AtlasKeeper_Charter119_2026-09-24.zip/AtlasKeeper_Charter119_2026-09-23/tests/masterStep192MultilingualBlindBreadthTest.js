'use strict'; const {detectAxes}=require('../Cognition/engine/AxisEngine.js');
const cases=[
['es','Mi idea era echarle una mano.','intention'],['es','Daba por hecho que vendría.','expectation'],
['fr','Je comptais lui donner un coup de main.','intention'],['fr','Je tenais pour acquis qu’il viendrait.','expectation'],
['de','Ich beabsichtigte, ihm zu helfen.','intention'],['de','Ich nahm an, er würde kommen.','expectation'],
['pt','Eu tinha em mente ajudá-lo.','intention'],['pt','Presumi que ele viria.','expectation'],
['it','Avevo in mente di aiutarlo.','intention'],['it','Davo per scontato che sarebbe venuto.','expectation'],
['nl','Ik was van plan hem te helpen.','intention'],['nl','Ik nam aan dat hij zou komen.','expectation'],
['pl','Zamierzałem mu pomóc.','intention'],['pl','Spodziewałem się, że przyjdzie.','expectation'],
['tr','Ona yardım etmeyi düşünüyordum.','intention'],['tr','Geleceğini bekliyordum.','expectation'],
['ru','Я намеревался ему помочь.','intention'],['ru','Я предполагал, что он придёт.','expectation'],
['ar','كنت أنوي مساعدته.','intention'],['ar','ظننت أنه سيأتي.','expectation'],
['hi','मैंने उसकी मदद करने का इरादा किया था।','intention'],['hi','मैंने मान लिया था कि वह आएगा।','expectation'],
['ja','彼を助ける予定だった。','intention'],['ja','彼は来るはずだと思っていた。','expectation'],
['ko','그를 도울 계획이었다.','intention'],['ko','그가 올 것으로 예상했다.','expectation'],
['zh','我计划去帮他。','intention'],['zh','我预计他会来。','expectation']];
let pass=0,miss=[];for(const [lang,text,axis] of cases){const r=detectAxes(text);if(r.axes.includes(axis))pass++;else miss.push({lang,text,axis,axes:r.axes});} console.log(JSON.stringify({total:cases.length,passed:pass,failed:miss.length,misses:miss},null,2));if(miss.length)process.exitCode=1;
