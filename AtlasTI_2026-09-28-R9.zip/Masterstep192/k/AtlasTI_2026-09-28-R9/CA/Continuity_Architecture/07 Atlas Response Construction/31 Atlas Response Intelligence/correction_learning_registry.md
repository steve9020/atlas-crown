---
title: Correction Learning Registry
runtime_layer: compass_response_intelligence
priority: high
governed_by: response_intelligence_overview
supports:
  - approved_response_training_examples
  - response_self_review_reference
outputs_to:
  - approved_response_training_examples
  - response_behavior_reference
status: active
---

# Correction Learning Registry

## Purpose

This node defines how Compass may learn from corrections.

Correction learning is approval-gated.

Compass may not silently add a correction as active learning.

---

## Correction Learning Flow

1. Compass produces a response.
2. The response is identified as too vague, misrouted, too broad, too mechanical, or missing emotional context.
3. A correction is drafted.
4. The correction is reviewed.
5. If approved, it becomes an approved response training example.
6. Future responses may compare against the approved example.

---

## Correction Record Format

### Correction: correction_name

status: pending_review

original_prompt:
- the user input that exposed the issue

incorrect_response_issue:
- what Compass missed or misread

approved_interpretation:
- the corrected emotional understanding

approved_response_direction:
- how Compass should respond to similar prompts in the future

user-facing_style:
- plain, grounded, non-clinical, emotionally specific

---

## Related Runtime Links

- [[response_intelligence_overview]]
- [[approved_response_training_examples]]
- [[response_self_review_registry]]
- [[response_behavior_registry]]

---

## Conditional Teaching Question Learning

Atlas should not ask teaching questions after every response. A teaching question should only appear when self-review detects weakness.

### Trigger Conditions

- primary route falls back to general
- response uses fallback meaning language
- pattern explanation is generic
- emotional contact is too broad
- clearer way forward is non-specific
- route score is weak for an emotional prompt
- response quality score falls below teaching threshold
- multiple emotions appear without a clear loop family

### Suppression Conditions

- response route is specific and confident
- pattern explanation is specific
- emotional contact is specific
- clearer way forward is specific
- practical prompt is correctly handled lightly
- issue is already queued, reviewed, merged, rejected, or integrated

### Learning Rule

Teaching answers from Steve should become structured proposals, not active system truth.

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

