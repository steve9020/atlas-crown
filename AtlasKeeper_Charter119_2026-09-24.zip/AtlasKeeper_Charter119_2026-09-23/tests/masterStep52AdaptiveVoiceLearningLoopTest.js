const assert = require('assert');
const { buildCompassResponse } = require('../runtime/compass/CompassResponseBuilderIntegration');
const { inspectResponseQuality } = require('../runtime/compass/CompassResponseQualityGate');
const { createAdaptiveVoiceLearningRecord } = require('../runtime/teaching/AdaptiveVoiceLearningLoop');

const unknown = buildCompassResponse('Blue curtains are on sale and the carpet is oval.');
assert.strictEqual(unknown.route.active_relation, 'unclassified_relation');
assert.strictEqual(unknown.quality.passed, false, 'unclassified fallback must not pass');
assert.strictEqual(unknown.status, 'teaching_center_learning_required');
assert.ok(unknown.adaptive_learning.requires_teaching);
assert.strictEqual(unknown.adaptive_learning.proposal.auto_integrate, false);
assert.strictEqual(unknown.adaptive_learning.proposal.approval_required, true);

const weak = createAdaptiveVoiceLearningRecord({ prompt:'x', response:'Something in this is asking to be sorted carefully.', route:{ active_relation:'unclassified_relation' }});
assert.ok(weak.requires_teaching);
assert.ok(weak.proposal.reusable_learning_target.includes('general_compass_quality') || weak.proposal.reusable_learning_target.includes('human_voice'));

const good = buildCompassResponse('My friend keeps asking for favors even when I am exhausted, and I feel guilty saying no.');
assert.notStrictEqual(good.route.active_relation, 'unclassified_relation');
assert.strictEqual(good.quality.passed, true, JSON.stringify(good.quality, null, 2));
assert.ok(/boundary|guilt|capacity|energy|limit/i.test(good.response), good.response);
assert.strictEqual(inspectResponseQuality(good).passed, true);

console.log('masterStep52AdaptiveVoiceLearningLoopTest PASSED');
