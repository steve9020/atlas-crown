# Present Unraveling Registry

## Purpose
Detects when the user is actively trying to understand what is happening inside them now.

## Signals
- trying to understand
- trying to unravel
- trying to work through
- trying to process
- I can feel it happening
- I am noticing

## Rule
Present awareness should be recognized as continuity intervention, not weakness.
