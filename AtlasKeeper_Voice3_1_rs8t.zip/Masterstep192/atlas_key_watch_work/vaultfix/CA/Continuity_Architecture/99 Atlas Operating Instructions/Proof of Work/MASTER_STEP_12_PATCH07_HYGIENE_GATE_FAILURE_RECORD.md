# MASTER STEP 12 PATCH07 — Hygiene Gate Failure Record

Package: `Masterstep12_patch07.zip`  
Result: `FAILED — HYGIENE / PROOF AUTOMATION ALIGNMENT CAUGHT`  
Disposition: Preserved as proof-of-work record. The failed package zip should remain external/archive evidence and must not be embedded in the clean distribution package.

## What the hygiene gate caught

The proof runner was still checking stale current-state expectations from older Stage10 / Masterstep07 proof automation:

- `STAGE10_UI_CLEAN`
- `ATLAS_RUNTIME_STAGE10_UI_CLEAN.zip` as an embedded/current snapshot expectation
- old carry-forward text markers as current proof requirements
- Masterstep07 closure readiness markers as current package truth

## Interpretation

This was not treated as a Compass runtime behavior failure. It was treated as a proof-chain hygiene failure: current package lineage, version status, snapshot policy, and proof-runner expectations were not aligned.

## Carry-forward rule created from this failure

Patch08 converts carry-forward from stale text-marker expectations to a manifest-driven validation flow:

- `CARRY_FORWARD_MANIFEST.json` is the machine-readable source of truth.
- `PROOF_OF_WORK_CARRIED_FORWARD_INDEX.md` is generated/derived documentation.
- `proof_runner.py` validates against the manifest and current checkpoint.
- metadata-only snapshot policy is accepted when declared in the manifest.
- failed packages are recorded in proof-of-work, not embedded inside the clean package.

## Boundary

The failed package may be kept externally as evidence that hygiene caught the mismatch. The clean distribution package should carry this record, not the failed zip itself.
