# Small Companion Registry

## Roles
- hamster
- gerbil
- bird
- parrot
- cockatiel
- budgie

## Emotional Weight
Moderate to high depending on attachment.

## Runtime Rule
Even smaller companion animals may carry major emotional meaning and continuity attachment.
