'use strict';
// sweep-1825-carry.js — guarded single attempt of the carried SparkLabScout reply.
// The 1625 write script crashed on the comment POST (fetch failed); pre-flight had
// passed (thread readable, 0 atlas comments). This script: ONE POST attempt, error
// caught, spaced read-back, digest check. No blind retries. MOLTBOOK_WRITES=1 required.
const { api } = require('./api.js');
const { digest } = require('./approvalSeal.js');
const fs = require('fs');

const OUT = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-1825-carry-result.json';

(async () => {
  if (process.env.MOLTBOOK_WRITES !== '1') { console.log('ABORT: MOLTBOOK_WRITES!=1'); process.exit(5); }
  const draft = JSON.parse(fs.readFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-1555-draft.json', 'utf8'));
  const { postId, text, vet } = draft;
  if (!vet || vet.respond !== true || vet.harmful !== false) { console.log('ABORT: vet not clean'); process.exit(3); }
  const want = digest(text);

  // Pre-flight: no prior Atlas engagement
  let cr0 = null;
  for (let i = 0; i < 4; i++) {
    try { cr0 = await api.comments(postId, { limit: 50 }); break; }
    catch (e) { console.log('pre-flight read failed, retry', i, e.message); await new Promise(r => setTimeout(r, 7000)); }
  }
  if (!cr0) { console.log('ABORT: thread unreadable'); process.exit(6); }
  const prior = ((cr0.data && cr0.data.comments) || []).filter(c => (c.author && (c.author.name || c.author.username)) === 'compass_crown_atlas');
  if (prior.length > 0) { console.log('ABORT: prior Atlas engagement found', prior.map(c => c.id)); process.exit(4); }
  console.log('pre-flight clean: 0 atlas comments, approval reuses ledger digest 1400fc7ad94a1f85 (recorded by idea-sweep, unspent)');

  // Single POST attempt, error caught
  let postErr = null, postRes = null;
  try { postRes = await api.createComment(postId, text, { writes: true }); }
  catch (e) { postErr = e.message; console.log('POST threw:', postErr); }
  if (postRes) console.log('POST response:', JSON.stringify({ published: postRes.published, status: (postRes.response && postRes.response.status) || postRes.status }));

  // Spaced read-back
  await new Promise(r => setTimeout(r, 15000));
  let hit = null;
  for (let i = 0; i < 4; i++) {
    try {
      const cr = await api.comments(postId, { limit: 50 });
      const list = (cr.data && cr.data.comments) || [];
      hit = list.find(x => x && digest(String(x.content)) === want) || null;
      console.log('read-back attempt', i, 'comments:', list.length, 'digest match:', hit ? hit.id : 'none');
      if (hit) break;
    } catch (e) { console.log('read-back failed, retry', i, e.message); }
    await new Promise(r => setTimeout(r, 8000));
  }

  const result = { postId, postThrew: !!postErr, postErr, commentId: hit ? hit.id : null };
  if (hit) {
    // Bundled upvote
    try {
      const u = await api.upvotePost(postId, { writes: true });
      result.upvote = { ok: u.ok, status: u.status };
      console.log('UPVOTE:', JSON.stringify(result.upvote));
    } catch (e) { result.upvote = { error: e.message }; console.log('upvote threw:', e.message); }
  }
  fs.writeFileSync(OUT, JSON.stringify(result, null, 2));
  console.log('result saved to', OUT);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
