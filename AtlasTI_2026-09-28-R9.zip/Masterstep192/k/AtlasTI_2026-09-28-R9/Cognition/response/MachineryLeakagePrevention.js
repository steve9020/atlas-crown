const MACHINERY_PATTERNS = [
  { id: "route_label", pattern: /\b(route[_\s-]?(score|explanation|selection|rank|confidence)|selected route|route scorer)\b/i },
  { id: "axis_label", pattern: /\b(axis|axes)[_\s-]?(weight|score|detection|map|mirroring|registry)?\b/i },
  { id: "runtime_label", pattern: /\b(runtime|pipeline|backend|frontend bridge|plugin bridge|registry|trace log|governance adapter)\b/i },
  { id: "internal_module_label", pattern: /\b(context_integrity|semantic_fusion|progressive_understanding|intuition_meaning_spread|reflective_axis_mirroring|revisability_interpretive_openness|return_preserving_correction_guard|relational_first_contact_calibration|anomaly_first_contact_calibration)\b/i },
  { id: "technical_scoring_label", pattern: /\b(confidence score|scoring weight|weighted routing|signal detection|detected signal|governance pass|quality checker)\b/i }
];

const SAFE_REPLACEMENTS = [
  { pattern: /\broute[_\s-]?score\b/gi, replacement: "sense of direction" },
  { pattern: /\broute[_\s-]?explanation\b/gi, replacement: "why this feels important" },
  { pattern: /\bsemantic[_\s-]?fusion\b/gi, replacement: "meaning getting tangled together" },
  { pattern: /\bcontext[_\s-]?integrity\b/gi, replacement: "the full context" },
  { pattern: /\bprogressive[_\s-]?understanding\b/gi, replacement: "understanding unfolding gradually" },
  { pattern: /\breflective[_\s-]?axis[_\s-]?mirroring\b/gi, replacement: "reflecting what the pressure is touching" },
  { pattern: /\breturn[_\s-]?preserving[_\s-]?correction[_\s-]?guard\b/gi, replacement: "a steadier way back" },
  { pattern: /\banomaly[_\s-]?first[_\s-]?contact[_\s-]?calibration\b/gi, replacement: "keeping the interaction grounded" },
  { pattern: /\brelational[_\s-]?first[_\s-]?contact[_\s-]?calibration\b/gi, replacement: "keeping the first response open and safe" },
  { pattern: /\baxis\b/gi, replacement: "pressure point" },
  { pattern: /\baxes\b/gi, replacement: "pressure points" },
  { pattern: /\bruntime\b/gi, replacement: "response" },
  { pattern: /\bpipeline\b/gi, replacement: "response path" },
  { pattern: /\bbackend\b/gi, replacement: "underneath" },
  { pattern: /\bregistry\b/gi, replacement: "guidance" },
  { pattern: /\bgovernance adapter\b/gi, replacement: "boundary check" },
  { pattern: /\bconfidence score\b/gi, replacement: "how strongly this seems supported" },
  { pattern: /\bscoring weight\b/gi, replacement: "the amount of weight this carries" },
  { pattern: /\bweighted routing\b/gi, replacement: "how the response is guided" },
  { pattern: /\bsignal detection\b/gi, replacement: "what stands out" },
  { pattern: /\bdetected signal\b/gi, replacement: "what seems present" },
  { pattern: /\bquality checker\b/gi, replacement: "clarity check" },
  { pattern: /\bgovernance pass\b/gi, replacement: "boundary check" },
  { pattern: /\bplugin bridge\b/gi, replacement: "connection point" },
  { pattern: /\bfrontend bridge\b/gi, replacement: "display connection" },
  { pattern: /\btrace log\b/gi, replacement: "record" },
  { pattern: /\bselected route\b/gi, replacement: "direction" },
  { pattern: /\broute scorer\b/gi, replacement: "direction check" }
];

function detectMachineryTerms(response) {
  const text = typeof response === "string" ? response : "";
  return MACHINERY_PATTERNS
    .filter(({ pattern }) => pattern.test(text))
    .map(({ id }) => id);
}

function sanitizeMachineryTerms(response) {
  let sanitized = typeof response === "string" ? response : "";
  for (const replacement of SAFE_REPLACEMENTS) {
    sanitized = sanitized.replace(replacement.pattern, replacement.replacement);
  }
  return sanitized;
}

function preventMachineryLeakage(response) {
  const original = typeof response === "string" ? response : "";
  const detectedBefore = detectMachineryTerms(original);
  const sanitized = sanitizeMachineryTerms(original);
  const detectedAfter = detectMachineryTerms(sanitized);

  return {
    output: sanitized,
    machinery_leakage_prevention: {
      machinery_leakage_prevention_active: detectedBefore.length > 0,
      leakage_detected: detectedBefore.length > 0,
      leakage_terms: detectedBefore,
      leakage_remaining: detectedAfter,
      machinery_leakage_allowed: false,
      machinery_leakage_cleared: detectedAfter.length === 0,
      human_facing_language_preserved: detectedAfter.length === 0,
      forbidden_output_modes: [
        "expose_route_scores",
        "expose_axes_or_axis_labels_as_frontend_truth",
        "expose_runtime_module_names",
        "expose_backend_registry_or_pipeline_language",
        "translate_internal_confidence_into_visible_authority"
      ],
      required_output_mode: "clean_human_facing_language"
    }
  };
}

module.exports = {
  preventMachineryLeakage,
  detectMachineryTerms,
  sanitizeMachineryTerms
};
