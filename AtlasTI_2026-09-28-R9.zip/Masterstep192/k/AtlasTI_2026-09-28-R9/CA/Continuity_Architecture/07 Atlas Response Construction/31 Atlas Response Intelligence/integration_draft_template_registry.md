# Integration Draft Template Registry

Defines integration draft wording guidance as backend data. Drafts should describe proposed understanding in human terms and avoid making backend labels sound like user-facing truth.

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

