# Framework Node Classification Map

## Primitive
Foundational mechanics the framework cannot function without.

Examples:
- Continuity
- Awareness
- Identity
- Meaning
- Emotional Weighting

---

## Structure
Major continuity architectures or organizational systems.

Examples:
- Relational Continuity
- Fragmented Systems
- Stabilization Systems
- Identity Field

---

## Dynamic
Mechanics describing movement, reinforcement, adaptation, fragmentation, stabilization, or recursive interaction.

Examples:
- Continuity Gravity
- Identity Momentum
- Continuity Drift
- Continuity Reinforcement

---

## State
Conditions continuity systems can exist within.

Examples:
- Peace
- Chaos
- Stability
- Alignment
- Meaning Collapse

---

## Process
Transformational mechanisms that reorganize continuity structures.

Examples:
- Healing
- Reflection
- Truthful Recalibration
- Experience Integration

---

## Loop
Recursive reinforcement cycles.

Examples:
- Healing Loop
- Peace Loop
- Corruption Loop
- Identity Loop

---

## Distortion
Mechanics that destabilize or corrupt adaptive continuity.

Examples:
- Addiction
- Validation Dependency
- Recursive Fragmentation
- Identity Calcification

---

## Stabilization System
Mechanics that preserve coherence and adaptive functioning.

Examples:
- Integrity
- Emotional Regulation
- Resilience
- Adaptive Continuity

---

## Relational System
Systems involving interpersonal continuity and shared reinforcement.

Examples:
- Love
- Trust
- Attachment
- Vulnerability
- Boundaries

---

## Meta-System
Systems that organize or explain the framework itself.

Examples:
- Meta-Architecture
- Structural Awareness
- Recursive Continuity Mapping
- Continuity Centralization