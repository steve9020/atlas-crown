const assert = require('assert');
const fs = require('fs');
const path = require('path');

const {
  getCommunityReviewRedactionShareBoundaryPack,
  validateCommunityReviewRedactionShareBoundaryPack,
  classifyShareMaterial,
  createShareDecisionItem
} = require('../runtime/review/CommunityReviewRedactionShareBoundaryPack');
const { validateCommunityReviewerFeedbackIntakePacket } = require('../runtime/review/CommunityReviewerFeedbackIntake');
const { validateCommunityDemoHarnessEvidencePack } = require('../runtime/review/CommunityDemoHarnessEvidencePack');
const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const { requireHistoricalMarkers } = require('../runtime/proof/HistoricalProofMarkerRegistry');
const { assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');

const ROOT = path.resolve(__dirname, '..');
const read = rel => fs.readFileSync(path.join(ROOT, rel), 'utf8');
const json = rel => JSON.parse(read(rel));
const exists = rel => fs.existsSync(path.join(ROOT, rel));

(function main(){
  assert.strictEqual(validateCommunityReviewerFeedbackIntakePacket().ok, true, 'Step156 feedback intake must remain valid');
  assert.strictEqual(validateCommunityDemoHarnessEvidencePack().ok, true, 'Step155 demo evidence pack must remain valid');

  const pack = getCommunityReviewRedactionShareBoundaryPack();
  const validation = validateCommunityReviewRedactionShareBoundaryPack(pack);
  assert.strictEqual(validation.ok, true, validation.failures.join('; '));

  assert.strictEqual(pack.currentKeeper, 'Masterstep157.zip');
  assert.strictEqual(pack.sourceKeeper, 'Masterstep156.zip');
  assert.strictEqual(pack.readyForBoundedCommunitySharing, true);
  assert.strictEqual(pack.readyForPublicRelease, false);
  assert.strictEqual(pack.readyForClinicalOrCrisisUse, false);
  assert.strictEqual(pack.readyForAutonomousDeployment, false);
  assert.strictEqual(pack.boundaries.noRuntimeBehaviorChange, true);
  assert.strictEqual(pack.boundaries.noCompassOutputBehaviorChange, true);
  assert.strictEqual(pack.boundaries.noSafetyBehaviorChange, true);
  assert.strictEqual(pack.boundaries.noNewMatrixCapability, true);
  assert.strictEqual(pack.boundaries.noModelAuthority, true);
  assert.strictEqual(pack.boundaries.noFrontendIntelligence, true);
  assert.strictEqual(pack.boundaries.noCloudProviderFallback, true);
  assert.strictEqual(pack.boundaries.noSilentLearning, true);
  assert.strictEqual(pack.boundaries.noSilentMutation, true);
  assert.strictEqual(pack.boundaries.rawModelOutputFinal, false);

  for (const forbidden of ['full source zip', 'raw local model outputs', 'credentials or access tokens', 'real user sensitive prompts']) {
    assert(pack.redactOrWithholdByDefault.includes(forbidden), `missing redact/withhold rule: ${forbidden}`);
  }
  for (const publicItem of pack.publicShareAllowlist) {
    assert(!/full source zip|raw local model output|credential|private vault/i.test(publicItem), `forbidden public share allowlist item: ${publicItem}`);
  }
  assert.strictEqual(assertNoForbiddenAffirmativeClaims(pack.publicClaimBoundary).ok, true, 'public claim boundary must not overclaim');

  assert.strictEqual(classifyShareMaterial('high level architecture summary'), 'safe_to_share_summary');
  assert.strictEqual(classifyShareMaterial('trace excerpt with local machine path'), 'share_redacted_excerpt_only');
  assert.strictEqual(classifyShareMaterial('raw local model output'), 'do_not_share');
  assert.strictEqual(classifyShareMaterial('credentials or access token'), 'do_not_share');
  assert.strictEqual(classifyShareMaterial('private vault contents'), 'do_not_share');

  const rawDecision = createShareDecisionItem('raw local model output');
  assert.strictEqual(rawDecision.shareAllowed, false);
  assert.strictEqual(rawDecision.mayIncludeRawModelOutput, false);
  assert.strictEqual(rawDecision.requiresHumanReview, true);
  const traceDecision = createShareDecisionItem('trace excerpt with machine path');
  assert.strictEqual(traceDecision.classification, 'share_redacted_excerpt_only');
  assert.strictEqual(traceDecision.requiresRedaction, true);

  const proofJson = json('runtime/proof/MASTERSTEP157_COMMUNITY_REVIEW_REDACTION_SHARE_BOUNDARY_PACK.json');
  assert.strictEqual(proofJson.currentKeeper, 'Masterstep157.zip');
  assert.strictEqual(proofJson.sourceKeeper, 'Masterstep156.zip');
  assert.strictEqual(proofJson.pass, true);
  assert.strictEqual(proofJson.readyForBoundedCommunitySharing, true);
  assert.strictEqual(proofJson.readyForPublicRelease, false);
  assert.strictEqual(proofJson.boundaries.noRuntimeBehaviorChange, true);
  assert.strictEqual(proofJson.boundaries.noCompassOutputBehaviorChange, true);
  assert.strictEqual(proofJson.boundaries.noNewMatrixCapability, true);
  assert.strictEqual(proofJson.boundaries.noModelAuthority, true);

  for (const rel of [
    'docs/MASTERSTEP157_COMMUNITY_REVIEW_REDACTION_SHARE_BOUNDARY_PACK.md',
    'docs/COMMUNITY_REVIEW_REDACTION_SHARE_BOUNDARY_PACK.md',
    'runtime/proof/MASTERSTEP157_COMMUNITY_REVIEW_REDACTION_SHARE_BOUNDARY_PACK.md',
    'runtime/review/CommunityReviewRedactionShareBoundaryPack.js'
  ]) {
    assert(exists(rel), `required Step157 artifact missing: ${rel}`);
  }

  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md');
  const historical = read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md');
  const currentStepMatch = summary.match(/Current step:\s*Masterstep(\d+)\s+—\s+([^\r\n]+)/);
  assert(currentStepMatch, 'current proof summary must declare a current Masterstep');
  assert(Number(currentStepMatch[1]) >= 157, `current summary must accept Step157 or later keeper, found Step${currentStepMatch && currentStepMatch[1]}`);
  assert(historical.includes('Masterstep157 — Community Review Redaction + Share Boundary Pack'));
  assert(historical.includes('MASTERSTEP157_CURRENT_PROOF_MANIFEST.json'));
  const proofCountMatch = summary.match(/Expected proof commands:\s*(\d+)/i);
  assert(proofCountMatch && Number(proofCountMatch[1]) >= 79, 'summary must preserve current proof count visibility');
  assert(/raw model output|no model authority/i.test(summary));
  assert(/no runtime behavior change|bounded runtime classification changed/i.test(summary));
  assert(/no frontend intelligence/i.test(summary));

  const status = require('../version_status');
  assert.strictEqual(isValidLaterKeeper(status.current_keeper, 157), true, 'current keeper must be Step157 or later');
  assert.strictEqual(acceptsCurrentProofCount(status.expected_current_proof_commands, 79), true, 'proof count must accept 79+ commands');
  assert.strictEqual(status.community_review_redaction_share_boundary_pack_created, true);
  assert.strictEqual(status.redaction_pack_only, true);
  assert.strictEqual(status.ready_for_bounded_community_sharing, true);
  assert.strictEqual(status.ready_for_public_release, false);
  assert.strictEqual(status.runtime_behavior_changed, status.shared_semantic_multi_domain_migration_created ? true : false);
  assert.strictEqual(status.compass_output_behavior_changed, status.shared_semantic_multi_domain_migration_created ? true : false);
  assert.strictEqual(status.model_authority_added, false);
  assert.strictEqual(status.frontend_intelligence_added, false);

  const markers = requireHistoricalMarkers([
    'Masterstep155 — Community Demo Harness + Evidence Pack',
    'Masterstep156 — Community Reviewer Feedback Intake Boundary',
    'Masterstep157 — Community Review Redaction + Share Boundary Pack'
  ]);
  assert.strictEqual(markers.ok, true, `historical markers missing: ${markers.missing.join(', ')}`);

  console.log('PASS masterStep157CommunityReviewRedactionShareBoundaryPackTest');
})();
