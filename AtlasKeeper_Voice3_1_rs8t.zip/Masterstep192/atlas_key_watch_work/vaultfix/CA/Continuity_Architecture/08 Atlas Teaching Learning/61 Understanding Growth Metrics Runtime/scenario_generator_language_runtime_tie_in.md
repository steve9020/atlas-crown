---
runtime_layer: teaching_learning
category: scenario_generation_quality
status: active_refinement
feeds_into:
  - scenario_generator_quality_operational_runtime
  - real_compass_run_scenario_testing_runtime
  - language_meaning_application_runtime
---

# Scenario Generator Language Runtime Tie-In

The scenario generator must not create a separate language or punctuation system. It should reuse Atlas language understanding and correction behavior when rendering generated user prompts.

## Operational Rule

Scenario generation creates the hidden test structure: category, event, attached meaning, protective reaction, expected route, expected card, test purpose, and do-not-do behavior. Atlas language runtimes then clean the visible prompt wording without changing that hidden structure.

## Required Sequence

1. Build scenario structure.
2. Render a visible prompt draft.
3. Apply meaning-preserving language cleanup.
4. Apply punctuation and grammar cleanup.
5. Suppress Compass/backend-style wording.
6. Check human speech naturalness.
7. Guard meaning preservation so cleanup does not change route/card/attached meaning.
8. Run quality and uniqueness scoring after cleanup.

## Boundary

Language cleanup may polish the prompt, but it may not rewrite the scenario into a different route, card, emotional attachment, or test purpose. If cleanup changes too much, the original cleaned prompt should be preserved or the scenario should regenerate.
