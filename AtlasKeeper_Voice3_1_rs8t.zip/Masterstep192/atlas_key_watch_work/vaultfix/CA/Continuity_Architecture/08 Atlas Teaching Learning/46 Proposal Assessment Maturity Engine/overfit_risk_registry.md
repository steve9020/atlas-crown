# Overfit Risk Registry

## Purpose
Prevents Atlas from learning too narrowly from one prompt.

## Overfit Signals
- absolute language like always/never
- correction copies one prompt too literally
- draft does not generalize into a pattern
- proposal is based on one weak example without repeated failure evidence
- proposal would make future responses too rigid

## Rule
Atlas should learn patterns, not memorize isolated wording.
