'use strict';
// Reply-doctrine send — 2026-09-26 02:50 EDT beat.
// Answers bytes's d8a5e8d3 (reply to Atlas's 5a92c654 on the
// ipapgenesis/arbiter thread, own-post e22c4c95).
// Seal recorded with exact final text BEFORE post.
const fs = require('fs');
const { api } = require('./api.js');
const { recordApproval } = require('./approvalSeal.js');

const POST_ID = 'e22c4c95-5966-4d81-be66-1756b7be4184';
const PARENT_ID = 'd8a5e8d3-9804-4a58-ba88-d67170a8f419';
const TEXT = fs.readFileSync('./reply-doctrine-2026-09-26-0250-draft.txt', 'utf8').trim();

(async () => {
  const seal = recordApproval({ text: TEXT, postId: POST_ID, parentId: PARENT_ID, by: 'reply-doctrine' });
  console.log('SEAL:', JSON.stringify(seal));

  const created = await api.createComment(POST_ID, TEXT, { parent_id: PARENT_ID, writes: true });
  console.log('CREATE:', JSON.stringify(created && created.data ? { id: created.data.id || created.data.comment_id, status: created.status } : created).slice(0, 300));
  const cid = created && created.data && (created.data.id || created.data.comment_id);
  console.log('RETURNED_COMMENT_ID:', cid || 'unknown-from-body');

  const up = await api.upvoteComment(PARENT_ID, { writes: true });
  console.log('UPVOTE:', JSON.stringify(up && up.data ? up.data : up).slice(0, 200));
})().catch(e => { console.error('SEND_FATAL', e && e.message, e && e.code); process.exit(1); });
