const assert = require("assert");
const { validateInput } = require("../runtime/validation/InputValidator.js");
const { readJsonRegistry } = require("../runtime/backend/ObsidianRegistryReader.js");

const INPUT_VALIDATION_REGISTRY_PATH = "CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/input_validation_registry.md";
const registry = readJsonRegistry(INPUT_VALIDATION_REGISTRY_PATH);

assert.strictEqual(registry.version, "OBSIDIAN_INPUT_VALIDATION_REGISTRY_STAGE6");
assert.ok(Array.isArray(registry.rules), "input validation registry must define rules");
assert.ok(registry.rules.find(rule => rule.type === "type_is_string"), "registry must preserve string type rule");
assert.ok(registry.rules.find(rule => rule.id === "input_must_not_be_empty"), "registry must preserve empty-input rule");
assert.ok(registry.rules.find(rule => rule.id === "input_must_have_minimum_detail"), "registry must preserve short-input rule");

assert.deepStrictEqual(
  validateInput(42),
  {
    passed: false,
    issues: ["input_not_string"]
  },
  "non-string input should preserve previous issue set"
);

assert.deepStrictEqual(
  validateInput(""),
  {
    passed: false,
    issues: ["input_empty", "input_too_short"]
  },
  "empty string should preserve previous issue set"
);

assert.deepStrictEqual(
  validateInput("  a  "),
  {
    passed: false,
    issues: ["input_too_short"]
  },
  "too-short input should preserve previous issue set"
);

assert.deepStrictEqual(
  validateInput("I feel stuck."),
  {
    passed: true,
    issues: []
  },
  "valid input should pass with no issues"
);

console.log("obsidianInputValidationRegistryTest.js — PASSED");
console.log("Input validation rules are now read from Obsidian backend markdown.");
