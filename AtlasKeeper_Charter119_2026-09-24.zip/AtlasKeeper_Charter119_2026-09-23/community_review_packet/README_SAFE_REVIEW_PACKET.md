# Atlas / Compass — Safe Community Review Packet

This packet is a bounded review surface. It is meant to help reviewers understand the project direction, the claim boundary, and the kind of feedback being requested.

This packet intentionally does **not** include source code, backend/runtime intelligence, private vault material, raw model outputs, proof internals, credentials, machine paths, or bypassable governance internals.

Review focus: clarity, claim boundaries, safety framing, demo comprehensibility, and what evidence a reviewer would need next.
