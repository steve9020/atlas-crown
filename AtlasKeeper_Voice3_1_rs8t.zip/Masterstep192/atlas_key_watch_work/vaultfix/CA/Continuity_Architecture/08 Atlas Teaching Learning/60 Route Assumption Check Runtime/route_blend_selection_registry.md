---
runtime_layer: route_assumption_check
priority: high
owned_by: atlas_teaching_learning
feeds_into:
  - final_route_selection
---

# Route Blend Selection Registry

## Purpose
Allows Atlas to choose a route blend when multiple routes are genuinely active.

## Blend rule
The primary route should lead the response. Secondary routes may appear only when they clarify the prompt without pulling Compass away from the core issue.

## Example
In a read-no-response prompt, relational uncertainty may lead, while self-worth remains secondary if the user also feels unwanted or reduced.

## Boundary
A route blend is not a dumping ground for every detected signal. It must preserve clarity.
