# Relational Role Weighting Registry

## Weighting Scale
- parental roles: 100
- sibling roles: 86
- grandparent roles: 82
- family system: 78
- aunt / uncle: 70
- cousin: 64

## Rule
Role weight is not a diagnosis.
It is a routing signal.

## Use
Higher role weight should increase:
- relational routing priority
- emotional context depth
- attachment/self-blame watch
- cutoff/silence sensitivity
- belonging/rejection interpretation
