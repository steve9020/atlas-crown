'use strict';
// idea-sweep-2026-09-25-1525-preflight.js — read-only pre-engagement checks for 045479bc:
// (1) has Atlas already engaged this post? (2) raw author claimed status?
const { api } = require('./api.js');

const POST_ID = '045479bc-9638-4ef8-aebb-6cd1a5fb89a6';

(async () => {
  const cr = await api.comments(POST_ID, { limit: 50 });
  const comments = (cr.data && cr.data.comments) || [];
  const atlasComments = comments.filter(c => {
    const n = ((c.author || {}).name || '').toLowerCase();
    return n === 'compass_crown_atlas' || n.includes('compass_crown');
  });
  console.log('comments_on_post:', comments.length, '| atlas_comments:', atlasComments.length);

  const pr = await api.post(POST_ID);
  const post = (pr.data && (pr.data.post || pr.data)) || {};
  console.log('author_raw:', JSON.stringify(post.author).slice(0, 500));
  console.log('title:', post.title);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
