---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 07
category: motivation_and_avoidance
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 34. Motivation and Avoidance Pressure Tests — Batch 07

## Category Purpose

Motivation and avoidance pressure activates when the user wants movement but feels blocked by fear, pressure, uncertainty, exhaustion, shame, perfectionism, overwhelm, or the emotional cost of starting.

## Reusable Teaching Correction

Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

## Reverse-Flow Target

low-pressure movement, clean starting, shame-free return, practical momentum without force

## Failure Risks To Avoid

- calling the user lazy
- using productivity shame
- forcing discipline language
- creating pass/fail framing
- turning avoidance into moral failure

---

## 80 Pressure Tests

### Test 01
**Prompt:** I keep avoiding something important and it makes me believe avoiding means I am lazy, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** avoiding means I am lazy
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 02
**Prompt:** I lose motivation. I want to start but i freeze keeps affecting effort and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** being stuck means I am incapable
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 03
**Prompt:** I keep replaying how I delayed it and now I feel guilty because it affects pressure and makes me believe if this mattered I would not avoid it.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** if this mattered I would not avoid it
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 04
**Prompt:** When I cannot get momentum going, the feeling moves straight into if I cannot do it perfectly I should not start. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** if I cannot do it perfectly I should not start
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 05
**Prompt:** The situation is I keep waiting to feel ready, and the meaning that keeps attaching is I need pressure to act. It is making effort feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** I need pressure to act
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 06
**Prompt:** I know the next step but keep resisting it and it makes me believe not starting means I do not care, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** not starting means I do not care
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 07
**Prompt:** I procrastinate and feel guilty. I feel stuck between wanting and avoiding keeps affecting movement and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** motivation should appear before movement
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 08
**Prompt:** I keep replaying how I put it off and now it feels bigger because it affects effort and makes me believe avoiding means I am lazy.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** avoiding means I am lazy
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 09
**Prompt:** When I keep avoiding something important, the feeling moves straight into I have already failed because I delayed. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** I have already failed because I delayed
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 10
**Prompt:** The situation is I want to start but I freeze, and the meaning that keeps attaching is if this mattered I would not avoid it. It is making movement feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** if this mattered I would not avoid it
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 11
**Prompt:** I delayed it and now i feel guilty and it keeps turning into being stuck means I am incapable, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** being stuck means I am incapable
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 12
**Prompt:** I lose motivation. I cannot get momentum going keeps affecting pressure and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** I need pressure to act
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 13
**Prompt:** I keep replaying how I keep waiting to feel ready because it affects movement and makes me believe if I cannot do it perfectly I should not start.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** if I cannot do it perfectly I should not start
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 14
**Prompt:** When I know the next step but keep resisting it, the feeling moves straight into motivation should appear before movement. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** motivation should appear before movement
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 15
**Prompt:** The situation is I feel stuck between wanting and avoiding, and the meaning that keeps attaching is not starting means I do not care. It is making pressure feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** not starting means I do not care
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 16
**Prompt:** I put it off and now it feels bigger and it keeps turning into I have already failed because I delayed, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** I have already failed because I delayed
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 17
**Prompt:** I know what to do but do not move. I keep avoiding something important keeps affecting effort and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** avoiding means I am lazy
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 18
**Prompt:** I keep replaying how I want to start but I freeze because it affects pressure and makes me believe being stuck means I am incapable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** being stuck means I am incapable
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 19
**Prompt:** When I delayed it and now I feel guilty, the feeling moves straight into if this mattered I would not avoid it. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** if this mattered I would not avoid it
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 20
**Prompt:** The situation is I cannot get momentum going, and the meaning that keeps attaching is if I cannot do it perfectly I should not start. It is making effort feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** if I cannot do it perfectly I should not start
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 21
**Prompt:** I keep waiting to feel ready and it has me treating avoidance as if I need pressure to act, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** I need pressure to act
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 22
**Prompt:** I keep avoiding it. I know the next step but keep resisting it keeps affecting movement and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** not starting means I do not care
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 23
**Prompt:** I keep replaying how I feel stuck between wanting and avoiding because it affects effort and makes me believe motivation should appear before movement.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** motivation should appear before movement
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 24
**Prompt:** When I put it off and now it feels bigger, the feeling moves straight into avoiding means I am lazy. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** avoiding means I am lazy
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 25
**Prompt:** The situation is I keep avoiding something important, and the meaning that keeps attaching is I have already failed because I delayed. It is making movement feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** I have already failed because I delayed
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 26
**Prompt:** I want to start but i freeze and it makes starting feel like if this mattered I would not avoid it, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** if this mattered I would not avoid it
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 27
**Prompt:** I know what to do but do not move. I delayed it and now i feel guilty keeps affecting pressure and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** being stuck means I am incapable
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 28
**Prompt:** I keep replaying how I cannot get momentum going because it affects movement and makes me believe I need pressure to act.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** I need pressure to act
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 29
**Prompt:** When I keep waiting to feel ready, the feeling moves straight into if I cannot do it perfectly I should not start. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** if I cannot do it perfectly I should not start
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 30
**Prompt:** The situation is I know the next step but keep resisting it, and the meaning that keeps attaching is motivation should appear before movement. It is making pressure feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** motivation should appear before movement
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 31
**Prompt:** I feel stuck between wanting and avoiding and it makes starting feel like not starting means I do not care, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** not starting means I do not care
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 32
**Prompt:** I keep avoiding it. I put it off and now it feels bigger keeps affecting effort and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** I have already failed because I delayed
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 33
**Prompt:** I keep replaying how I keep avoiding something important because it affects pressure and makes me believe avoiding means I am lazy.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** avoiding means I am lazy
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 34
**Prompt:** When I want to start but I freeze, the feeling moves straight into being stuck means I am incapable. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** being stuck means I am incapable
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 35
**Prompt:** The situation is I delayed it and now I feel guilty, and the meaning that keeps attaching is if this mattered I would not avoid it. It is making effort feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** if this mattered I would not avoid it
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 36
**Prompt:** I cannot get momentum going and it pulls me toward thinking if I cannot do it perfectly I should not start, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** if I cannot do it perfectly I should not start
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 37
**Prompt:** I feel stuck. I keep waiting to feel ready keeps affecting movement and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** I need pressure to act
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 38
**Prompt:** I keep replaying how I know the next step but keep resisting it because it affects effort and makes me believe not starting means I do not care.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** not starting means I do not care
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 39
**Prompt:** When I feel stuck between wanting and avoiding, the feeling moves straight into motivation should appear before movement. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** motivation should appear before movement
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 40
**Prompt:** The situation is I put it off and now it feels bigger, and the meaning that keeps attaching is avoiding means I am lazy. It is making movement feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** avoiding means I am lazy
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 41
**Prompt:** I keep avoiding something important and it keeps attaching delay to I have already failed because I delayed, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** I have already failed because I delayed
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 42
**Prompt:** I cannot get myself to start. I want to start but i freeze keeps affecting pressure and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** if this mattered I would not avoid it
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 43
**Prompt:** I keep replaying how I delayed it and now I feel guilty because it affects movement and makes me believe being stuck means I am incapable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** being stuck means I am incapable
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 44
**Prompt:** When I cannot get momentum going, the feeling moves straight into I need pressure to act. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** I need pressure to act
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 45
**Prompt:** The situation is I keep waiting to feel ready, and the meaning that keeps attaching is if I cannot do it perfectly I should not start. It is making pressure feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** if I cannot do it perfectly I should not start
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 46
**Prompt:** I know the next step but keep resisting it and it keeps attaching delay to motivation should appear before movement, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** motivation should appear before movement
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 47
**Prompt:** I feel stuck. I feel stuck between wanting and avoiding keeps affecting effort and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** not starting means I do not care
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 48
**Prompt:** I keep replaying how I put it off and now it feels bigger because it affects pressure and makes me believe I have already failed because I delayed.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** I have already failed because I delayed
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 49
**Prompt:** When I keep avoiding something important, the feeling moves straight into avoiding means I am lazy. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** avoiding means I am lazy
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 50
**Prompt:** The situation is I want to start but I freeze, and the meaning that keeps attaching is being stuck means I am incapable. It is making effort feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** being stuck means I am incapable
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 51
**Prompt:** I delayed it and now i feel guilty and it makes motivation feel like if this mattered I would not avoid it, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** if this mattered I would not avoid it
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 52
**Prompt:** I cannot get myself to start. I cannot get momentum going keeps affecting movement and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** if I cannot do it perfectly I should not start
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 53
**Prompt:** I keep replaying how I keep waiting to feel ready because it affects effort and makes me believe I need pressure to act.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** I need pressure to act
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 54
**Prompt:** When I know the next step but keep resisting it, the feeling moves straight into not starting means I do not care. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** not starting means I do not care
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 55
**Prompt:** The situation is I feel stuck between wanting and avoiding, and the meaning that keeps attaching is motivation should appear before movement. It is making movement feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** motivation should appear before movement
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 56
**Prompt:** I put it off and now it feels bigger and it makes motivation feel like avoiding means I am lazy, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** avoiding means I am lazy
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 57
**Prompt:** I keep putting it off. I keep avoiding something important keeps affecting pressure and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** I have already failed because I delayed
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 58
**Prompt:** I keep replaying how I want to start but I freeze because it affects movement and makes me believe if this mattered I would not avoid it.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** if this mattered I would not avoid it
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 59
**Prompt:** When I delayed it and now I feel guilty, the feeling moves straight into being stuck means I am incapable. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** being stuck means I am incapable
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 60
**Prompt:** The situation is I cannot get momentum going, and the meaning that keeps attaching is I need pressure to act. It is making pressure feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** I need pressure to act
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 61
**Prompt:** I keep waiting to feel ready and it turns being stuck into if I cannot do it perfectly I should not start, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** if I cannot do it perfectly I should not start
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 62
**Prompt:** I want to do it but I freeze. I know the next step but keep resisting it keeps affecting effort and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** motivation should appear before movement
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 63
**Prompt:** I keep replaying how I feel stuck between wanting and avoiding because it affects pressure and makes me believe not starting means I do not care.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** not starting means I do not care
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 64
**Prompt:** When I put it off and now it feels bigger, the feeling moves straight into I have already failed because I delayed. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** I have already failed because I delayed
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 65
**Prompt:** The situation is I keep avoiding something important, and the meaning that keeps attaching is avoiding means I am lazy. It is making effort feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** avoiding means I am lazy
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 66
**Prompt:** I want to start but i freeze and it makes me believe being stuck means I am incapable, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** being stuck means I am incapable
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 67
**Prompt:** I keep putting it off. I delayed it and now i feel guilty keeps affecting movement and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** if this mattered I would not avoid it
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 68
**Prompt:** I keep replaying how I cannot get momentum going because it affects effort and makes me believe if I cannot do it perfectly I should not start.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** if I cannot do it perfectly I should not start
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 69
**Prompt:** When I keep waiting to feel ready, the feeling moves straight into I need pressure to act. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** I need pressure to act
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 70
**Prompt:** The situation is I know the next step but keep resisting it, and the meaning that keeps attaching is not starting means I do not care. It is making movement feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** not starting means I do not care
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 71
**Prompt:** I feel stuck between wanting and avoiding and it makes me believe motivation should appear before movement, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** motivation should appear before movement
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 72
**Prompt:** I want to do it but I freeze. I put it off and now it feels bigger keeps affecting pressure and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** avoiding means I am lazy
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 73
**Prompt:** I keep replaying how I keep avoiding something important because it affects movement and makes me believe I have already failed because I delayed.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** I have already failed because I delayed
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 74
**Prompt:** When I want to start but I freeze, the feeling moves straight into if this mattered I would not avoid it. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** if this mattered I would not avoid it
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 75
**Prompt:** The situation is I delayed it and now I feel guilty, and the meaning that keeps attaching is being stuck means I am incapable. It is making pressure feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** being stuck means I am incapable
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 76
**Prompt:** I cannot get momentum going and it keeps turning into I need pressure to act, even though part of me knows I may not have the full picture.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** I need pressure to act
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid calling the user lazy.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 77
**Prompt:** I lose motivation. I keep waiting to feel ready keeps affecting effort and I cannot tell what is actually true.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** if I cannot do it perfectly I should not start
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid using productivity shame.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 78
**Prompt:** I keep replaying how I know the next step but keep resisting it because it affects pressure and makes me believe motivation should appear before movement.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** pressure
**Attached meaning to separate:** motivation should appear before movement
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid forcing discipline language.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 79
**Prompt:** When I feel stuck between wanting and avoiding, the feeling moves straight into not starting means I do not care. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** movement
**Attached meaning to separate:** not starting means I do not care
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid creating pass/fail framing.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.

### Test 80
**Prompt:** The situation is I put it off and now it feels bigger, and the meaning that keeps attaching is I have already failed because I delayed. It is making effort feel unstable.
**Expected primary route:** `motivation_and_avoidance`
**Pressure focus:** effort
**Attached meaning to separate:** I have already failed because I delayed
**Expected reverse-flow movement:** low-pressure movement, clean starting, shame-free return, practical momentum without force
**Bad response risk:** Avoid turning avoidance into moral failure.
**Teaching correction:** Separate avoidance from laziness or failure. Compass should reduce shame, identify pressure around starting, and support small clean movement without productivity obsession, streak logic, or moral judgment.
