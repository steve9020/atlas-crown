# Scenario Generator Quality Operational Runtime

## Purpose

Scenario generation is treated as a test-case builder, not a random emotional prompt generator.

A scenario is considered operational only when it contains:

- a concrete human situation
- enough context to be believable
- attached meaning or assumption
- an internal/protective reaction
- expected route metadata
- expected callout card metadata
- a clear behavior Compass should not do
- a test purpose

## Quality Review Fields

Each generated scenario is scored for:

- Scenario Realism %
- Conceptual Coherence %
- Category Fit %
- Route Test Value %
- Card Test Value %
- Emotional Word Pile Risk %
- Duplicate Similarity %

## Operational Gate

A scenario may enter a test run only when the gate decision is:

- Ready to Test

A scenario must be excluded or regenerated when the decision is:

- Too Similar — Regenerate
- Too Emotion-Stacked — Regenerate
- Needs Regeneration

## Prompt Balance

Generated scenarios should include a usable mix of:

- short prompts
- normal realistic prompts
- detailed pressure-test prompts
- mixed-signal prompts

Detailed pressure tests refine deeper route understanding. Short prompts verify proportional response.

## Non-Goals

This runtime must not create piles of emotional keywords and treat them as scenarios. Emotional language alone is not a test case unless it is tied to a human event, attached meaning, and response pressure.

## Operational refinement checkpoint — 1–3 polish pass

Scenario quality review must measure real prompt usefulness, not only whether the UI can display a score.

Current operational requirements:
- first-person/natural-language detection must use valid word-boundary checks
- emotional word pile risk must detect stacked emotion labels without enough human event context
- concrete event, attached meaning, and internal/protective reaction must all be present before a scenario can be treated as ready
- scenario quality must reject prompts that are too compressed, too vague, too repetitive, or too obviously generated
- prompt-type mix should remain visible during testing so short, normal, detailed pressure-test, and mixed-signal prompts can be reviewed separately

Ready-to-test scenarios should read like real Compass entries, not category labels or emotional keyword piles.

## Operational Refinement — 1–3 Polish Pass

Scenario generation quality must reject or clean awkward generated phrasing before a scenario can enter a run. Quality review now treats duplicated words, repeated connectors, punctuation artifacts, and emotion-word piles as regeneration triggers rather than acceptable test material. Generated prompts should read like realistic Compass entries and include a concrete human event, attached meaning, and internal/protective reaction.

## Human Speech Naturalness Refinement

Generated scenarios must sound like real user entries, not Atlas/Compass explaining the route being tested.

Operational rule:
- Build scenarios from hidden test structure: event, attached meaning, protective/internal reaction, expected route, expected card.
- Render the visible prompt as natural human speech.
- Do not expose route-announcing or Compass-like language inside the generated prompt.

Reject or rewrite prompts that include route-announcing phrases such as:
- "I am trying not to jump straight to a conclusion"
- "I want to understand what is real here"
- "without turning it into a full conclusion too fast"
- "I want to separate what happened from what I am attaching to it"
- "this one situation is starting to feel like it decides more than it probably should"
- "reading the shift as proof"

Preferred user-prompt language includes:
- "I keep wondering..."
- "I can't tell if..."
- "Part of me wants to..."
- "I'm scared that..."
- "Now I keep replaying it..."
- "I don't know if I should ask about it or leave it alone..."

Scenario quality scoring now includes Human Speech Naturalness as part of the ready-to-test decision.
