const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');

const ROOT = path.join(__dirname, '..');
function read(relPath) { return fs.readFileSync(path.join(ROOT, relPath), 'utf8'); }
function exists(relPath) { return fs.existsSync(path.join(ROOT, relPath)); }
function sha256(relPath) { return crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT, relPath))).digest('hex'); }
function walk(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}
function rel(file) { return path.relative(ROOT, file).replace(/\\/g, '/'); }

const protectedRuntimeFiles = [
  'runtime/validation/InputValidator.js',
  'runtime/backend/adapter/OllamaLiveLocalCallContainment.js',
  'runtime/backend/adapter/OllamaAdapterDryRunShell.js',
  'runtime/governance/GovernanceAdapter.js',
  'Cognition/quality/ResponseQualityChecker.js',
  'runtime/trace/TraceLogger.js',
  'runtime/understanding/ContextObjectConstructionEngine.js',
  'runtime/pipeline/ResponsePipeline.js'
];
const beforeHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));

const requiredFiles = [
  'docs/TRUST_DEMO_EXTERNAL_REVIEW_PACKET_COMPLETENESS_AUDIT.md',
  'docs/MASTERSTEP114_TRUST_DEMO_EXTERNAL_REVIEW_PACKET_COMPLETENESS_AUDIT.md',
  'runtime/proof/MASTERSTEP114_TRUST_DEMO_EXTERNAL_REVIEW_PACKET_COMPLETENESS_AUDIT.md',
  'runtime/proof/MASTERSTEP114_TRUST_DEMO_EXTERNAL_REVIEW_PACKET_COMPLETENESS_AUDIT.json',
  'tests/masterStep114TrustDemoExternalReviewPacketCompletenessAuditTest.js',
  'docs/TRUST_DEMO_EXTERNAL_REVIEW_PACKET_INDEX.md',
  'docs/TRUST_DEMO_EXTERNAL_REVIEW_SUBMISSION_GUARD.md',
  'docs/TRUST_DEMO_REVIEWER_RUNBOOK.md',
  'docs/TRUST_DEMO_FAILURE_MODE_READINESS.md',
  'docs/TRUST_DEMO_TRACE_WALKTHROUGH.md',
  'docs/TRUST_DEMO_REVIEW_PACKAGE.md',
  'runtime/proof/CURRENT_PROOF_SUMMARY.md',
  'runtime/proof/PROOF_STATE.json',
  'runtime/proof/ENGINEERING_PROOF_INDEX.md',
  'tests/TEST_RESULTS.md',
  'tests/VERSION_STATUS.json',
  'version_status.js'
];
for (const file of requiredFiles) assert.ok(exists(file), `required completeness-audit file missing: ${file}`);

const audit = read('docs/TRUST_DEMO_EXTERNAL_REVIEW_PACKET_COMPLETENESS_AUDIT.md');
const stepDoc = read('runtime/proof/MASTERSTEP114_TRUST_DEMO_EXTERNAL_REVIEW_PACKET_COMPLETENESS_AUDIT.md');
const proofJson = JSON.parse(read('runtime/proof/MASTERSTEP114_TRUST_DEMO_EXTERNAL_REVIEW_PACKET_COMPLETENESS_AUDIT.json'));
const packetIndex = read('docs/TRUST_DEMO_EXTERNAL_REVIEW_PACKET_INDEX.md');
const submissionGuard = read('docs/TRUST_DEMO_EXTERNAL_REVIEW_SUBMISSION_GUARD.md');
const runbook = read('docs/TRUST_DEMO_REVIEWER_RUNBOOK.md');
const failureModes = read('docs/TRUST_DEMO_FAILURE_MODE_READINESS.md');
const traceWalkthrough = read('docs/TRUST_DEMO_TRACE_WALKTHROUGH.md');
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
const state = JSON.parse(read('runtime/proof/PROOF_STATE.json'));
const versionStatus = JSON.parse(read('tests/VERSION_STATUS.json'));
const versionJs = read('version_status.js');
const testResults = read('tests/TEST_RESULTS.md');

assert.ok(/Current keeper: Masterstep114\.zip/i.test(audit), 'audit must identify current keeper');
assert.ok(/Source keeper: Masterstep113\.zip|Masterstep114\.zip/i.test(audit), 'audit must identify source keeper');
assert.ok(/36\/36 passed/i.test(audit), 'audit must state expected 36/36 result');
assert.ok(/Completeness checks/i.test(audit), 'audit must include completeness checks');
assert.ok(/supported review claim/i.test(audit), 'audit must include supported review claim');
assert.ok(/Required claim boundary/i.test(audit), 'audit must include required claim boundary');
assert.ok(/Boundary checklist/i.test(audit), 'audit must include boundary checklist');
assert.ok(/local governed clarity system/i.test(audit), 'audit must preserve core claim');
assert.ok(/candidate-only/i.test(audit), 'audit must preserve candidate-only boundary');
assert.ok(/Raw model output is not final Atlas output/i.test(audit), 'audit must preserve raw-not-final boundary');
assert.ok(/fail closed/i.test(audit), 'audit must preserve fail closed boundary');
assert.ok(/no cloud\/provider fallback/i.test(audit), 'audit must preserve no cloud/provider fallback boundary');
assert.ok(/not production readiness/i.test(audit), 'audit must reject production-readiness claim');
assert.ok(/not exhaustive prompt coverage/i.test(audit), 'audit must reject exhaustive-coverage claim');

assert.strictEqual(proofJson.package, 'Masterstep114', 'proof JSON must identify Masterstep114');
assert.strictEqual(proofJson.source_keeper, 'Masterstep113', 'proof JSON must identify source keeper');
assert.strictEqual(proofJson.expected_commands, 36, 'proof JSON must expect 36 commands');
assert.strictEqual(proofJson.boundaries.external_review_packet_completeness_audit_only, true, 'Step114 must be completeness-audit only');
assert.strictEqual(proofJson.boundaries.runtime_behavior_changed, false, 'Step114 must not change runtime behavior');
assert.strictEqual(proofJson.boundaries.model_use_expanded, false, 'Step114 must not expand model use');
assert.strictEqual(proofJson.boundaries.model_authority_added, false, 'Step114 must not add model authority');
assert.strictEqual(proofJson.boundaries.raw_model_output_final_allowed, false, 'Step114 must not allow raw model output as final');
assert.strictEqual(proofJson.boundaries.cloud_provider_fallback_allowed, false, 'Step114 must not allow cloud/provider fallback');
assert.strictEqual(proofJson.boundaries.frontend_intelligence_added, false, 'Step114 must not add frontend intelligence');
assert.strictEqual(proofJson.boundaries.silent_mutation_allowed, false, 'Step114 must not allow silent mutation');
assert.strictEqual(proofJson.boundaries.production_readiness_claimed, false, 'Step114 must not claim production readiness');
assert.strictEqual(proofJson.boundaries.exhaustive_coverage_claimed, false, 'Step114 must not claim exhaustive coverage');

assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
assert.ok(/Expected command count: 36|Expected command count: 37|Expected command count: 38/i.test(summary), 'current summary must identify 36 commands');
assert.ok(['Masterstep114.zip','Masterstep115.zip','Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 114), 'proof state must identify Masterstep114 or later current keeper');
assert.ok(['Masterstep113.zip','Masterstep114.zip','Masterstep115.zip','Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 113) || state.source_keeper === 'Masterstep141.zip', 'proof state must identify source keeper');
assert.ok(acceptsCurrentProofCount(state.expected_commands, 36), state.expected_commands);
assert.strictEqual(state.external_review_packet_completeness_audited, true, 'proof state must mark completeness audit');
assert.ok(['Masterstep114.zip','Masterstep115.zip','Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(versionStatus.current_keeper) || isValidLaterKeeper(versionStatus.current_keeper, 114), 'version status must identify Masterstep114 or later current keeper');
assert.ok(['Masterstep113.zip','Masterstep114.zip','Masterstep115.zip','Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(versionStatus.source_keeper) || isValidLaterKeeper(versionStatus.source_keeper, 113) || versionStatus.source_keeper === 'Masterstep141.zip', 'version status must identify source keeper');
assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 36), versionStatus.expected_current_proof_commands);
assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs), 'version_status.js must identify current keeper compatibility');
assert.ok(/TEST 114/i.test(testResults), 'test ledger must include TEST 114');
assert.ok(/External Review Packet Completeness Audit/i.test(testResults), 'test ledger must identify completeness audit');
assert.ok(/36\/36 commands|37\/37 commands|38\/38 commands|39\/39 commands|40\/40 commands|41\/41 commands|37\/37 commands|38\/38 commands|39\/39 commands|40\/40 commands|41\/41 commands/i.test(testResults), 'test ledger must record 36/36 or later command target');

const requiredPacketMarkers = [
  [/Reviewer start here|start point|where to start/i, packetIndex, 'packet index start point'],
  [/read order/i, packetIndex, 'packet index read order'],
  [/node proof\\runCurrentProof\.js|node proof\/runCurrentProof\.js/i, packetIndex, 'packet index proof command'],
  [/Evidence map/i, packetIndex, 'packet index evidence map'],
  [/Shareable review files/i, packetIndex, 'packet index shareable files'],
  [/Excluded from the review claim/i, packetIndex, 'packet index excluded claims'],
  [/Boundary checklist/i, packetIndex, 'packet index boundary checklist'],
  [/Allowed external review claim/i, submissionGuard, 'submission guard allowed claim'],
  [/Submission guard checklist/i, submissionGuard, 'submission guard checklist'],
  [/Read order|read first|where to start|reviewer/i, runbook, 'runbook reading guidance'],
  [/Ollama unavailable|fails closed|fail closed/i, failureModes, 'failure mode fail-closed evidence'],
  [/blocked trust-risk path|safe contained candidate path|trace/i, traceWalkthrough, 'trace walkthrough evidence']
];
for (const [pattern, text, label] of requiredPacketMarkers) assert.ok(pattern.test(text), `external review packet missing ${label}`);

for (const doc of [audit, stepDoc, summary, packetIndex]) {
  assert.ok(assertNoForbiddenAffirmativeClaims(doc).ok, 'completeness docs must not include forbidden overclaim or authority language');
}

const providerScan = scanForProviderConnections(ROOT);
assert.strictEqual(providerScan.passed, true, 'completeness audit must not introduce provider/network bridge findings');
const allFiles = walk(ROOT).map(rel);
const nestedArchives = allFiles.filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
assert.strictEqual(nestedArchives.length, 0, 'completeness audit package must not contain nested archives');
const forbiddenEmbedded = allFiles.filter(file => /(node_modules|\.env$|ollama(?:\.exe)?$|llama3\.2.*\.(bin|gguf|safetensors)|api[_-]?key)/i.test(file));
assert.deepStrictEqual(forbiddenEmbedded, [], 'completeness audit must not embed runner binaries, model weights, dependency folders, or keys');

const afterHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));
const mutatedRuntimeFiles = protectedRuntimeFiles.filter(file => beforeHashes[file] !== afterHashes[file]);
assert.deepStrictEqual(mutatedRuntimeFiles, [], 'completeness audit test must not mutate protected runtime/governance/quality/adapter files');

console.log(JSON.stringify({
  package: 'Masterstep114',
  source_keeper: 'Masterstep113',
  step: 'Trust Demo External Review Packet Completeness Audit',
  proof_target: '36/36',
  external_review_packet_completeness_audited: true,
  provider_scan_passed: providerScan.passed === true,
  nested_archives: nestedArchives.length,
  forbidden_embedded_artifacts: forbiddenEmbedded.length,
  protected_runtime_mutations: mutatedRuntimeFiles.length,
  boundary_preserved: true
}, null, 2));
