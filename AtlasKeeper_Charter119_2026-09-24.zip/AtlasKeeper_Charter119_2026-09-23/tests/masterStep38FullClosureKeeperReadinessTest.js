
const assert = require('assert');
const fs = require('fs');
const proof = JSON.parse(fs.readFileSync('runtime/proof/PROOF_STATE.json','utf8'));
const active = JSON.parse(fs.readFileSync('runtime/workflow/ACTIVE_STEP.json','utf8'));
const workflow = JSON.parse(fs.readFileSync('runtime/workflow/WORKFLOW_STATE.json','utf8'));
const status = require('../version_status');
for (const rec of [proof, active, workflow, status]) {
  assert.strictEqual(rec.current_keeper, 'Masterstep38.zip');
  assert.strictEqual(rec.current_step, 'Masterstep38');
  assert.strictEqual(rec.status, 'closed_keeper');
}
assert.ok(fs.existsSync('runtime/indexing/DOYLE_LAYER4_CONTEXT_SITUATION_PRESSURE.json'));
assert.ok(fs.existsSync('runtime/indexing/DoyleLayer4ContextPressureMap.js'));
assert.ok(fs.existsSync('runtime/indexing/DoyleLayer4PlacementGuard.js'));
assert.ok(fs.existsSync('runtime/semantics/Layer4ContextPressurePlacementGuard.js'));
assert.strictEqual(status.real_ai_connected, false);
assert.strictEqual(status.local_model_connected, false);
assert.strictEqual(status.network_bridge_added, false);
assert.strictEqual(status.frontend_intelligence_added, false);
console.log('masterStep38FullClosureKeeperReadinessTest PASSED');
