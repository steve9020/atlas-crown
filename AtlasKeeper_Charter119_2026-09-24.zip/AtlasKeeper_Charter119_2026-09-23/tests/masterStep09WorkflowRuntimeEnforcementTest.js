#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const root = process.cwd();
function p(rel) { return path.join(root, rel); }
function read(rel) { return fs.readFileSync(p(rel), 'utf8'); }
function json(rel) { return JSON.parse(read(rel)); }
function assert(condition, message) {
  if (!condition) {
    console.error(`FAIL: ${message}`);
    process.exit(1);
  }
}
function includesAll(text, markers, label) {
  for (const marker of markers) assert(text.includes(marker), `${label} missing marker: ${marker}`);
}

const required = [
  'runtime/workflow/WORKFLOW_STATE.json',
  'runtime/workflow/IMPLEMENTATION_SCOPE.json',
  'runtime/workflow/ACTIVE_STEP.json',
  'tests/VERSION_STATUS.json',
  'version_status.js',
  'tests/versionStatus.js',
  'tests/masterStep09WorkflowRuntimeEnforcementTest.js',
  'CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_9A_WORKFLOW_RUNTIME_ENFORCEMENT.md',
  'CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/PROOF_OF_WORK_CARRIED_FORWARD_INDEX.md'
];

for (const rel of required) assert(fs.existsSync(p(rel)), `required file missing: ${rel}`);

const workflow = json('runtime/workflow/WORKFLOW_STATE.json');
const scope = json('runtime/workflow/IMPLEMENTATION_SCOPE.json');
const active = json('runtime/workflow/ACTIVE_STEP.json');
const status = json('tests/VERSION_STATUS.json');

assert(workflow.mode === 'IMPLEMENTATION', 'workflow mode must remain IMPLEMENTATION in active package workflow');
includesAll(JSON.stringify(workflow), ['Inspect','Implement','Prove','Regress/Fuzz','Hygiene','Package'], 'workflow execution flow');
includesAll(JSON.stringify(workflow.stop_conditions), ['destructive_risk','governance_conflict','unclear_objective','package_corruption','must_not_happen_conflict'], 'workflow stop conditions');

const step9Proof = read('CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_9A_WORKFLOW_RUNTIME_ENFORCEMENT.md');
includesAll(step9Proof, [
  'Workflow Runtime Enforcement',
  'Masterstep09.zip',
  'metadata/workflow-state only',
  'No frontend changes',
  'No governance expansion',
  'No Compass response changes',
  'No route scoring changes',
  'No recursive spiral implementation'
], 'Masterstep09 proof carry-forward');

const step9History = status.prior_keeper_history && status.prior_keeper_history.masterstep09;
const step9Current = status.checkpoint === 'MASTER_STEP_9_FULL_CLOSURE_KEEPER_READINESS' && status.status === 'masterstep09_closed' && status.snapshot === 'Masterstep09.zip';
const step9Carried = step9History && step9History.checkpoint === 'MASTER_STEP_9_FULL_CLOSURE_KEEPER_READINESS' && step9History.status === 'masterstep09_closed' && step9History.snapshot === 'Masterstep09.zip';
assert(step9Current || step9Carried, 'Masterstep09 status not current or carried forward in prior keeper history');
assert(status.confirmed_layers.master_step_9_workflow_runtime_enforcement === true, 'workflow enforcement layer not confirmed');
assert(status.confirmed_layers.workflow_metadata_only === true, 'metadata-only boundary not confirmed');
assert(status.confirmed_layers.recursive_spiral_not_implemented === true, 'recursive spiral hold boundary not confirmed');

for (const rel of ['version_status.js', 'tests/versionStatus.js']) {
  const text = read(rel);
  includesAll(text, [
    'MASTER_STEP_9_FULL_CLOSURE_KEEPER_READINESS',
    'masterstep09_closed',
    'Masterstep09.zip',
    'runtime/workflow/WORKFLOW_STATE.json',
    'master_step_9_workflow_runtime_enforcement',
    'workflow_metadata_only',
    'recursive_spiral_not_implemented'
  ], rel);
}

const proof = read('CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_9A_WORKFLOW_RUNTIME_ENFORCEMENT.md');
includesAll(proof, [
  'MASTER STEP 9A',
  'Workflow Runtime Enforcement',
  'Masterstep09.zip',
  'metadata/workflow-state only',
  'No frontend changes',
  'No governance expansion',
  'No Compass response changes',
  'No route scoring changes',
  'No recursive spiral implementation'
], 'Step 9A proof');

console.log('MASTER STEP 09 — WORKFLOW RUNTIME ENFORCEMENT TEST');
console.log('Result: PASSED');
