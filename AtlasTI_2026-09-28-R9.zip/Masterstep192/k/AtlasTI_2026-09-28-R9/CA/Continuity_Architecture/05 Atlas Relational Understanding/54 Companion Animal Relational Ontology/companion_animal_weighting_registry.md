# Companion Animal Weighting Registry

## Weighting Scale
- dog: 92
- cat: 90
- bird: 76
- hamster: 70
- gerbil: 70
- companion animal generic: 84

## Rule
Companion animals should route as relational attachment context, not object context.

## Use
Increase:
- grief sensitivity
- attachment weighting
- emotional continuity weighting
- loss interpretation
- comfort/safety interpretation
