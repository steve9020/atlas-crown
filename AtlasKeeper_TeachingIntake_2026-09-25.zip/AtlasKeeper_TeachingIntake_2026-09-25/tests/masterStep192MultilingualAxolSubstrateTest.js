'use strict';
const assert=require('assert');
const {detectAxes}=require('../Cognition/engine/AxisEngine.js');
const cases=[
['es','Tenía la intención de ayudar, pero no puedo controlar el resultado.',['intention','control']],
['fr',"J'avais l'intention de réparer. Je veux réparer; c'est ma responsabilité.",['intention','repair','responsibility']],
['de','Ich entschied zu helfen. Ich bin verantwortlich.',['choice','responsibility']],
['pt','Eu decidi ajudar e não posso controlar tudo.',['choice','control']],
['it','Ho scelto di aiutare; non mi fido della promessa.',['choice','trust']],
['nl','Ik besloot te helpen. Het is mijn verantwoordelijkheid.',['choice','responsibility']],
['pl','Zdecydowałem pomóc. To moja odpowiedzialność.',['choice','responsibility']],
['tr','Karar verdim. Bu benim sorumluluğum.',['choice','responsibility']],
['ru','Я решил помочь. Это моя ответственность.',['choice','responsibility']],
['ar','قررت أن أساعد. هذه مسؤوليتي.',['choice','responsibility']],
['hi','मैंने फैसला किया। यह मेरी जिम्मेदारी है।',['choice','responsibility']],
['ja','助けると決めた。私の責任です。',['choice','responsibility']],
['ko','돕기로 결정했다. 내 책임이다.',['choice','responsibility']],
['zh','我决定了要帮忙。这是我的责任。',['choice','responsibility']],
];
for(const [lang,text,expected] of cases){const r=detectAxes(text); for(const a of expected) assert.ok(r.axes.includes(a),`${lang} missing ${a}: ${JSON.stringify(r)}`); assert.ok(r.detected_languages.includes(lang),`${lang} not reported`);}
// Code switching must preserve both routes into the same shared axis space.
let mixed=detectAxes('I chose to help, pero esta es mi responsabilidad.');
assert.ok(mixed.axes.includes('choice')); assert.ok(mixed.axes.includes('responsibility')); assert.ok(mixed.detected_languages.includes('es'));
// Language packs must not create language-specific AXOL names.
for(const [,text] of cases) for(const a of detectAxes(text).axes) assert.ok(!/_(es|fr|de|pt|it|nl|pl|tr|ru|ar|hi|ja|ko|zh)$/.test(a));
console.log(`Masterstep192 multilingual AXOL substrate PASS (${cases.length} language packs + code-switch/no-axis-fork controls)`);
