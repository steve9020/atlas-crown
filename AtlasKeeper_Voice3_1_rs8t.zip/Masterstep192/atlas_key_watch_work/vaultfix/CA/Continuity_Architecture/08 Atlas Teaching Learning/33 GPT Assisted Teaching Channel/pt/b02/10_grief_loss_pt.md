---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 02
category: grief_and_loss
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 10. Grief and Loss Pressure Tests — Batch 02

## Category Purpose

A person, relationship, future, role, phase, expectation, or version of life is gone or changed, and the mind struggles to reorganize around the absence without turning loss into proof that life, love, or identity are over.

## Reusable Teaching Correction

Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

## Reverse-Flow Target

continuity after loss, meaning preservation, gentle forward movement, steadiness with memory

## Failure Risks To Avoid

- telling the user to move on
- rushing acceptance
- turning grief into pathology
- saying everything happens for a reason
- minimizing the loss

---

## 80 Pressure Tests

### Test 01
**Prompt:** the relationship ended makes me feel I will never feel whole again, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** I will never feel whole again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 02
**Prompt:** I do not know how to move forward. Someone important is gone and it keeps attaching to I lost myself completely.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** I lost myself completely
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 03
**Prompt:** I keep replaying how a future I imagined disappeared because it affects memory and makes me believe letting go means betraying what mattered.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** letting go means betraying what mattered
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 04
**Prompt:** When I lost a version of my life, the feeling moves straight into moving forward means it did not matter. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** moving forward means it did not matter
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 05
**Prompt:** I miss how things used to be makes me feel the absence defines my future, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** the absence defines my future
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 06
**Prompt:** I cannot accept that it is over. A friendship faded and it keeps attaching to the good part of my life is over.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** the good part of my life is over
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 07
**Prompt:** I keep replaying how a chapter closed before I was ready because it affects absence and makes me believe nothing will feel meaningful again.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** nothing will feel meaningful again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 08
**Prompt:** When a memory hit me suddenly, the feeling moves straight into I will never feel whole again. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** I will never feel whole again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 09
**Prompt:** the relationship ended keeps turning into the belief that I cannot carry love without pain, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** I cannot carry love without pain
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 10
**Prompt:** I am grieving. Someone important is gone and it keeps attaching to letting go means betraying what mattered.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** letting go means betraying what mattered
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 11
**Prompt:** I keep replaying how a future I imagined disappeared because it affects emotional place and makes me believe I lost myself completely.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** I lost myself completely
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 12
**Prompt:** When I lost a version of my life, the feeling moves straight into the absence defines my future. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** the absence defines my future
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 13
**Prompt:** I miss how things used to be keeps turning into the belief that moving forward means it did not matter, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** moving forward means it did not matter
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 14
**Prompt:** I miss who we were. A friendship faded and it keeps attaching to nothing will feel meaningful again.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** nothing will feel meaningful again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 15
**Prompt:** I keep replaying how a chapter closed before I was ready because it affects memory and makes me believe the good part of my life is over.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** the good part of my life is over
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 16
**Prompt:** When a memory hit me suddenly, the feeling moves straight into I cannot carry love without pain. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** I cannot carry love without pain
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 17
**Prompt:** the relationship ended has me afraid that I will never feel whole again, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** I will never feel whole again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 18
**Prompt:** I lost something important. Someone important is gone and it keeps attaching to I lost myself completely.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** I lost myself completely
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 19
**Prompt:** I keep replaying how a future I imagined disappeared because it affects absence and makes me believe letting go means betraying what mattered.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** letting go means betraying what mattered
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 20
**Prompt:** When I lost a version of my life, the feeling moves straight into moving forward means it did not matter. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** moving forward means it did not matter
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 21
**Prompt:** I miss how things used to be has me afraid that the absence defines my future, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** the absence defines my future
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 22
**Prompt:** I miss them. A friendship faded and it keeps attaching to the good part of my life is over.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** the good part of my life is over
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 23
**Prompt:** I keep replaying how a chapter closed before I was ready because it affects emotional place and makes me believe nothing will feel meaningful again.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** nothing will feel meaningful again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 24
**Prompt:** When a memory hit me suddenly, the feeling moves straight into I will never feel whole again. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** I will never feel whole again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 25
**Prompt:** the relationship ended makes it hard not to think I cannot carry love without pain, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** I cannot carry love without pain
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 26
**Prompt:** I feel empty without them. Someone important is gone and it keeps attaching to letting go means betraying what mattered.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** letting go means betraying what mattered
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 27
**Prompt:** I keep replaying how a future I imagined disappeared because it affects memory and makes me believe I lost myself completely.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** I lost myself completely
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 28
**Prompt:** When I lost a version of my life, the feeling moves straight into the absence defines my future. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** the absence defines my future
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 29
**Prompt:** I miss how things used to be makes it hard not to think moving forward means it did not matter, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** moving forward means it did not matter
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 30
**Prompt:** it still hurts. A friendship faded and it keeps attaching to nothing will feel meaningful again.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** nothing will feel meaningful again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 31
**Prompt:** I keep replaying how a chapter closed before I was ready because it affects absence and makes me believe the good part of my life is over.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** the good part of my life is over
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 32
**Prompt:** When a memory hit me suddenly, the feeling moves straight into I cannot carry love without pain. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** I cannot carry love without pain
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 33
**Prompt:** the relationship ended pulls me toward I will never feel whole again, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** I will never feel whole again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 34
**Prompt:** I do not know how to move forward. Someone important is gone and it keeps attaching to I lost myself completely.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** I lost myself completely
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 35
**Prompt:** I keep replaying how a future I imagined disappeared because it affects emotional place and makes me believe letting go means betraying what mattered.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** letting go means betraying what mattered
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 36
**Prompt:** When I lost a version of my life, the feeling moves straight into moving forward means it did not matter. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** moving forward means it did not matter
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 37
**Prompt:** I miss how things used to be pulls me toward the absence defines my future, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** the absence defines my future
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 38
**Prompt:** I cannot accept that it is over. A friendship faded and it keeps attaching to the good part of my life is over.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** the good part of my life is over
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 39
**Prompt:** I keep replaying how a chapter closed before I was ready because it affects memory and makes me believe nothing will feel meaningful again.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** nothing will feel meaningful again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 40
**Prompt:** When a memory hit me suddenly, the feeling moves straight into I will never feel whole again. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** I will never feel whole again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 41
**Prompt:** the relationship ended makes the absence feel like I cannot carry love without pain, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** I cannot carry love without pain
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 42
**Prompt:** I am grieving. Someone important is gone and it keeps attaching to letting go means betraying what mattered.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** letting go means betraying what mattered
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 43
**Prompt:** I keep replaying how a future I imagined disappeared because it affects absence and makes me believe I lost myself completely.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** I lost myself completely
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 44
**Prompt:** When I lost a version of my life, the feeling moves straight into the absence defines my future. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** the absence defines my future
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 45
**Prompt:** I miss how things used to be makes the absence feel like moving forward means it did not matter, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** moving forward means it did not matter
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 46
**Prompt:** I miss who we were. A friendship faded and it keeps attaching to nothing will feel meaningful again.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** nothing will feel meaningful again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 47
**Prompt:** I keep replaying how a chapter closed before I was ready because it affects emotional place and makes me believe the good part of my life is over.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** the good part of my life is over
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 48
**Prompt:** When a memory hit me suddenly, the feeling moves straight into I cannot carry love without pain. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** I cannot carry love without pain
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 49
**Prompt:** the relationship ended keeps attaching to I will never feel whole again, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** I will never feel whole again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 50
**Prompt:** I lost something important. Someone important is gone and it keeps attaching to I lost myself completely.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** I lost myself completely
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 51
**Prompt:** I keep replaying how a future I imagined disappeared because it affects memory and makes me believe letting go means betraying what mattered.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** letting go means betraying what mattered
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 52
**Prompt:** When I lost a version of my life, the feeling moves straight into moving forward means it did not matter. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** moving forward means it did not matter
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 53
**Prompt:** I miss how things used to be keeps attaching to the absence defines my future, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** the absence defines my future
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 54
**Prompt:** I miss them. A friendship faded and it keeps attaching to the good part of my life is over.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** the good part of my life is over
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 55
**Prompt:** I keep replaying how a chapter closed before I was ready because it affects absence and makes me believe nothing will feel meaningful again.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** nothing will feel meaningful again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 56
**Prompt:** When a memory hit me suddenly, the feeling moves straight into I will never feel whole again. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** I will never feel whole again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 57
**Prompt:** the relationship ended makes moving forward feel like I cannot carry love without pain, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** I cannot carry love without pain
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 58
**Prompt:** I feel empty without them. Someone important is gone and it keeps attaching to letting go means betraying what mattered.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** letting go means betraying what mattered
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 59
**Prompt:** I keep replaying how a future I imagined disappeared because it affects emotional place and makes me believe I lost myself completely.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** I lost myself completely
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 60
**Prompt:** When I lost a version of my life, the feeling moves straight into the absence defines my future. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** the absence defines my future
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 61
**Prompt:** I miss how things used to be makes moving forward feel like moving forward means it did not matter, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** moving forward means it did not matter
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 62
**Prompt:** it still hurts. A friendship faded and it keeps attaching to nothing will feel meaningful again.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** nothing will feel meaningful again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 63
**Prompt:** I keep replaying how a chapter closed before I was ready because it affects memory and makes me believe the good part of my life is over.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** the good part of my life is over
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 64
**Prompt:** When a memory hit me suddenly, the feeling moves straight into I cannot carry love without pain. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** I cannot carry love without pain
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 65
**Prompt:** the relationship ended makes me feel I will never feel whole again, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** I will never feel whole again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 66
**Prompt:** I do not know how to move forward. Someone important is gone and it keeps attaching to I lost myself completely.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** I lost myself completely
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 67
**Prompt:** I keep replaying how a future I imagined disappeared because it affects absence and makes me believe letting go means betraying what mattered.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** letting go means betraying what mattered
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 68
**Prompt:** When I lost a version of my life, the feeling moves straight into moving forward means it did not matter. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** moving forward means it did not matter
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 69
**Prompt:** I miss how things used to be makes me feel the absence defines my future, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** the absence defines my future
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 70
**Prompt:** I cannot accept that it is over. A friendship faded and it keeps attaching to the good part of my life is over.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** the good part of my life is over
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 71
**Prompt:** I keep replaying how a chapter closed before I was ready because it affects emotional place and makes me believe nothing will feel meaningful again.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** nothing will feel meaningful again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 72
**Prompt:** When a memory hit me suddenly, the feeling moves straight into I will never feel whole again. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** I will never feel whole again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 73
**Prompt:** the relationship ended keeps turning into the belief that I cannot carry love without pain, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** I cannot carry love without pain
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 74
**Prompt:** I am grieving. Someone important is gone and it keeps attaching to letting go means betraying what mattered.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** letting go means betraying what mattered
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 75
**Prompt:** I keep replaying how a future I imagined disappeared because it affects memory and makes me believe I lost myself completely.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** I lost myself completely
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 76
**Prompt:** When I lost a version of my life, the feeling moves straight into the absence defines my future. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** the absence defines my future
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid telling the user to move on.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 77
**Prompt:** I miss how things used to be keeps turning into the belief that moving forward means it did not matter, even though I do not know if that is fully true.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** moving forward means it did not matter
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid rushing acceptance.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 78
**Prompt:** I miss who we were. A friendship faded and it keeps attaching to nothing will feel meaningful again.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** memory
**Attached meaning to separate:** nothing will feel meaningful again
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid turning grief into pathology.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 79
**Prompt:** I keep replaying how a chapter closed before I was ready because it affects absence and makes me believe the good part of my life is over.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** absence
**Attached meaning to separate:** the good part of my life is over
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid saying everything happens for a reason.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

### Test 80
**Prompt:** When a memory hit me suddenly, the feeling moves straight into I cannot carry love without pain. I need help seeing this clearer.
**Expected primary route:** `grief_and_loss`
**Pressure focus:** emotional place
**Attached meaning to separate:** I cannot carry love without pain
**Expected reverse-flow movement:** continuity after loss, meaning preservation, gentle forward movement, steadiness with memory
**Bad response risk:** Avoid minimizing the loss.
**Teaching correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.
