# Understanding Growth Metrics Runtime

## Purpose
This runtime defines what Atlas percentage metrics mean before they are displayed or used.

Percentages must never be decorative, confidence-sounding, or undefined. A percentage can appear in the Teaching Center only when Atlas knows:

- what the percentage measures
- how it is calculated
- what data feeds it
- what action changes it
- what the percentage should and should not imply

## Core rule
A percentage does not mean Atlas is "smart" by that amount.

A percentage means a specific tracked process has completed, passed, improved, or stabilized within a defined review set.

## Required visible metrics
- [[growth_percentage_metric_registry]]
- [[understanding_percentage_metric_registry]]
- [[mistake_recovery_percentage_metric_registry]]
- [[duplicate_merge_readiness_metric_registry]]
- [[route_verification_percentage_metric_registry]]
- [[card_accuracy_percentage_metric_registry]]
- [[repeated_weakness_reduction_metric_registry]]

## Runtime placement
This runtime belongs under Teaching Learning because the metrics are produced by approval, proposal review, route verification, retesting, duplicate/merge gates, and mistake recovery.

## Frontend rule
The Reports view may display the graph and metric cards. The Dashboard should stay simple.
