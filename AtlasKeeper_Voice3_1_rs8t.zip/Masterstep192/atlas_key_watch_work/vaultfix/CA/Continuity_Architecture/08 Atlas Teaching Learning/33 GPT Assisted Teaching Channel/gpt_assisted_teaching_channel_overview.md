---
title: GPT Assisted Teaching Channel
runtime_layer: external_teaching_channel
priority: high
governed_by: developer_teaching_mode_overview
supports:
  - gpt_assisted_teaching_log
  - response_intelligence_overview
  - correction_learning_reference
  - teaching_answer_to_proposal_flow
outputs_to:
  - external_teaching_to_proposal_flow
  - emotional_growth_proposal_queue
status: active
---

# GPT Assisted Teaching Channel

## Purpose

The **GPT Assisted Teaching Channel** defines a controlled outside-teacher pathway for improving Compass without placing an external model inside the runtime or giving it authority over the system.

This channel exists so Steven can send Compass outputs, project zips, response failures, correction notes, and teaching questions to GPT outside the application. GPT may then help identify what Compass missed, improve wording, generate teaching examples, and draft system proposals.

The channel is a bridge for teaching. It is not an authority system.

---

## Core Rule

GPT may review, suggest, explain, draft, and teach Compass response construction.

GPT may not silently approve, integrate, or activate system knowledge.

Every teaching output must still move through the existing governance path:

1. Teaching review
2. Teaching proposal
3. Proposal queue
4. Approval gate
5. Integration draft
6. Steven's final integration decision

---

## What This Channel Is For

This channel may be used to improve:

- Compass sentence construction
- meaning construction
- emotional context explanation
- pattern explanation
- clearer-way-forward language
- route correction
- detector correction
- merge assessment language
- response quality scoring
- approved training examples
- system proposal drafts
- user-facing clarity and fluency

---

## What This Channel Is Not For

This channel must not become:

- a direct runtime authority
- an automatic system editor
- an uncontrolled self-learning process
- a user therapy conversation
- a personal probing system
- a general AI personality layer
- a replacement for Steven's approval gate

---

## Teaching Flow

1. Steven tests Compass or reviews a Compass response.
2. Steven sends GPT the relevant output, prompt, screenshot, or project zip.
3. GPT reviews the response strictly for program behavior.
4. GPT identifies routing errors, vagueness, missing context, weak sentence construction, or missing pattern explanation.
5. GPT drafts a structured teaching update.
6. The update becomes a teaching proposal.
7. The proposal enters the approval system.
8. Nothing becomes active until Steven approves and integrates it.

---

## Required Boundaries

GPT-assisted teaching must remain:

- program-specific
- non-clinical
- non-diagnostic
- non-authoritative
- approval-gated
- source-based
- response-quality focused
- bounded to Compass behavior

---

## Related Runtime Links

- [[developer_teaching_mode_overview]]
- [[program_only_question_rules]]
- [[response_intelligence_overview]]
- [[approved_response_training_examples]]
- [[correction_learning_registry]]
- [[teaching_answer_to_proposal_flow]]
- [[external_teacher_input_format]]
- [[external_teaching_to_proposal_flow]]
- [[external_teacher_boundaries]]


## Teaching Log

The active teaching log is stored in [[gpt_assisted_teaching_log]].
