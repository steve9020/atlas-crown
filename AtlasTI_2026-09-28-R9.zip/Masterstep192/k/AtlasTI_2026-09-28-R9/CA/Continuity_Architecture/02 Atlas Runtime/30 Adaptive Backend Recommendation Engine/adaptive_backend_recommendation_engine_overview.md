---
title: Adaptive Backend Recommendation Engine Overview
runtime_layer: adaptive_backend_recommendation_engine
priority: high
governed_by: emotional_growth_approval_gate
supports:
  - backend_detector_generation_registry
  - missing_pattern_detection_registry
  - recommendation_scoring_registry
  - proposal_draft_generation_registry
outputs_to:
  - emotional_growth_proposal_queue
  - emotional_growth_approval_gate
status: active
---

# Adaptive Backend Recommendation Engine Overview

## Purpose

The **Adaptive Backend Recommendation Engine** defines how Compass can become more adaptive without silently changing itself.

This engine allows the backend to teach the runtime what to look for, while keeping all activation, merging, and integration approval-gated.

---

## Core Rule

The backend may teach.

The runtime may detect.

Compass may recommend.

Compass may draft.

Steve approves.

No recommendation, detector, merge, or proposal draft becomes active backend understanding without approval.

---

## Four Backend Processes

1. [[backend_detector_generation_registry]]
2. [[missing_pattern_detection_registry]]
3. [[recommendation_scoring_registry]]
4. [[proposal_draft_generation_registry]]

---

## Runtime Flow

Approved backend patterns are read by the plugin.

The plugin generates detector candidates from those approved patterns.

The plugin compares user input against those candidates using multi-signal evidence.

If a possible missing pattern appears, Compass may show a recommendation in the frontend.

The recommendation must include scoring, duplicate assessment, merge assessment, too-broad assessment, and a clear reason.

If the recommendation is sent to review, it enters [[emotional_growth_proposal_queue]].

The approval gate then controls whether it is approved, merged, deferred, or rejected through [[emotional_growth_approval_gate]].

Only approved items may generate integration drafts.

Only reviewed integration drafts may become active backend content.

---

## Non-Silent Activation Rule

The system must not:

- create active backend understanding without approval
- approve its own recommendations
- integrate drafts automatically
- silently merge patterns
- silently activate runtime-generated detectors as permanent truth
- recommend anything below the confidence threshold
- treat duplicate detection as a recommendation

---

## Frontend Rule

Compass may show recommendations, scoring, merge guidance, and drafts in the interface.

Compass must not expose backend machinery in normal user-facing reflection responses.

The recommendation interface is an admin/review layer.

---

## Related Runtime Links

- [[backend_detector_generation_registry]]
- [[missing_pattern_detection_registry]]
- [[recommendation_scoring_registry]]
- [[proposal_draft_generation_registry]]
- [[emotional_growth_proposal_queue]]
- [[emotional_growth_approval_gate]]
- [[emotional_loop_formation_registry]]
- [[emotional_attached_meaning_registry]]
- [[negative_learning_pattern_registry]]
