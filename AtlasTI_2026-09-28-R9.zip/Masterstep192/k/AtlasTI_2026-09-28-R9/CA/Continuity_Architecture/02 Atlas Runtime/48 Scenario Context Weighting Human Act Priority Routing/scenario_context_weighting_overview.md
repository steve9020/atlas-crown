# Scenario Context Weighting Overview

## Purpose
This layer prevents Compass from giving a generic emotional-processing response when the prompt contains specific context that should lead the interpretation.

The user-facing Compass reflection should understand what happened before explaining what the feeling means.

## Core Rule
Scenario context comes before emotional abstraction.

Compass should not begin with generalized emotional language when the prompt clearly names:
- childhood trauma
- abandonment-related history
- human acts
- vulnerability being mishandled
- boundaries being crossed
- relational inconsistency
- self-worth attachment
- practical low-depth stress

## Runtime Priority
When scenario context is strong, Atlas should prioritize:
1. what human/context event is named
2. what emotional pattern that context can form
3. what meaning may attach
4. what needs separated
5. how to restore perspective lightly

## Anti-Drift Boundary
This layer does not diagnose trauma, attachment style, or clinical cause.

It recognizes user-named context and routes the response accordingly.
