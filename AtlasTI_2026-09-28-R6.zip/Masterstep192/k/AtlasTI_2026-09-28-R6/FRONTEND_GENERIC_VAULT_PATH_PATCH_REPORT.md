# Frontend Generic Vault Path Patch Report

## Patch Name
Frontend Generic Vault Path Resolution

## Purpose
Remove active frontend dependency on a specific vault/package name and support dynamic backend-root detection for generic `/vaults` style storage.

## Changed Files
- `CA/Continuity_Architecture/.obsidian/plugins/continuity-interface/main.js`
- `CA/Continuity_Architecture/.obsidian/plugins/continuity-interface/StagingManager.js`
- `CA/Continuity_Architecture/.obsidian/plugins/continuity-interface/GovernanceValidator.js`
- `runtime/backend/ObsidianRegistryReader.js`

## What Changed
- `main.js` now detects the backend root by Atlas marker folders instead of assuming a hardcoded vault-name prefix.
- `StagingManager.js` no longer allowlists a hardcoded vault-name as a root folder by default.
- `GovernanceValidator.js` now references the registry by backend-relative suffix instead of `CA/Continuity_Architecture/...`.
- `ObsidianRegistryReader.js` can discover registry files by suffix when the package/vault folder name differs.

## Explicit Non-Goals
- No governance semantics changed.
- No response logic changed.
- No backend registry rules changed.
- No UI visual redesign.
- No Survival Vault naming added.

## Verification
- No active `Survival Vault` naming found.
- Active plugin path logic no longer requires the specific vault/package name.
