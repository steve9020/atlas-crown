---
title: Developer Teaching Mode Overview
runtime_layer: developer_teaching_mode
priority: high
governed_by: response_intelligence_overview
supports:
  - approved_response_training_examples
  - correction_learning_reference
  - emotional_growth_proposal_queue
  - emotional_growth_approval_gate
outputs_to:
  - program_only_question_rules
  - teaching_answer_to_proposal_flow
status: active
---

# Developer Teaching Mode Overview

## Purpose

Developer Teaching Mode lets Steve teach Compass how to respond better without giving Compass uncontrolled agency.

This mode is a builder/admin tool only. It is not a normal user chat, not emotional processing, and not a therapy-style follow-up system.

The purpose is to turn Steve's corrections about Compass behavior into structured system learning proposals.

---

## Core Rule

Compass may ask program-relevant teaching questions.

Compass may not ask personal follow-up questions for emotional exploration.

Compass may not silently activate anything it learns.

Every teaching answer must become a proposal first, then move through the approval gate and integration draft review before becoming active system understanding.

---

## Teaching Flow

1. Compass produces a response.
2. Steve opens Developer Teaching Mode.
3. Atlas asks a program-only correction question.
4. Steve explains what was wrong or missing.
5. The runtime converts the answer into a learning proposal.
6. The proposal enters [[emotional_growth_proposal_queue]].
7. The proposal is reviewed through [[emotional_growth_approval_gate]].
8. Approved proposals generate integration drafts.
9. Nothing becomes active until Steve integrates it.

---

## Allowed Teaching Targets

Developer Teaching Mode may ask about:

- wrong routing
- vague response wording
- missing emotional context
- missing attached meaning
- missing pattern explanation
- missing negative learning pattern
- missing clearer way forward
- wrong focal card
- duplicate recommendation
- merge vs approve decision
- too-broad recommendation
- not-broad-enough detector
- response sounding too mechanical
- response missing Compass direction

---

## Not Allowed

Developer Teaching Mode must not ask:

- personal therapeutic follow-up questions
- open-ended emotional processing questions
- questions about details unnecessary to program improvement
- questions that make the user re-live experiences for the system
- questions that ask the system to decide truth without approval

---

## Related Runtime Links

- [[program_only_question_rules]]
- [[response_correction_question_registry]]
- [[route_clarification_question_registry]]
- [[merge_decision_question_registry]]
- [[teaching_answer_to_proposal_flow]]
- [[teaching_mode_safety_boundaries]]
- [[approved_response_training_examples]]
- [[correction_learning_registry]]
- [[emotional_growth_proposal_queue]]
- [[emotional_growth_approval_gate]]
- [[conditional_teaching_question_registry]]
