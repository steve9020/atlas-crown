---
title: Emotional Exhaustion
runtime_layer: runtime_state
priority: medium
status: active
phase: runtime_link_cleanup
governed_by:
  - emotional_continuity_governance
  - governance_enforcement_registry
outputs:
  - Emotional Numbness
  - stability_return_pathways
---

# Emotional Exhaustion

## Purpose

Defines a state where emotional load has become heavy enough that numbness, shutdown, or reduced expression may appear.

## Core Function

The runtime should recognize exhaustion as load pressure and support continuity restoration without advice pressure, shame, or productivity framing.

## Runtime Boundary

This node exists because existing backend links already reference this concept. It should clarify the referenced pathway without creating duplicate ontology or changing Compass into a clinical, diagnostic, authoritative, or productivity-driven system.

## Related Runtime Links

- [[Emotional Numbness]]
- [[stability_return_pathways]]
- [[emotional_continuity_governance]]
- [[response_behavior_registry]]
