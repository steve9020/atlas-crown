# Personalization Distortion

## Mechanical Definition
Personalization distortion occurs when external events, other people’s reactions, or neutral ambiguity are automatically interpreted as evidence about the self.

---

## Real-World Definition
In real use, Personalization Distortion describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates It
- low self-worth
- rejection sensitivity
- social pressure
- uncertainty
- shame

---

## What It Produces
- self-blame
- anxiety
- over-apology
- identity fusion
- relational confusion

---

## Distortion Pattern
External behavior becomes over-attached to self-meaning.

---

## What Restores Clarity
- evidence separation
- context checking
- self-worth grounding
- direct clarification

---

## Connected Nodes
- [[Self-Worth]]
- [[Shame]]
- [[rejection_pressure]]
- [[Perspective Filtering]]

---

## Core Principle
Not everything that happens around the self is caused by the self.
