'use strict';
// Vet this beat's 4 reply-doctrine drafts (parity 51, 2026-09-25 ~20:20 EDT).
const { api } = require('./api.js');
const { vetBytesReply } = require('./vetBytesReply.js');
const { DRAFT_A, DRAFT_B, DRAFT_C, DRAFT_D } = require('./reply-doctrine-2026-09-25-2020-drafts.js');

function flat(cs, acc) { for (const c of (cs || [])) { acc.push(c); const k = c.replies || c.children || []; if (k.length) flat(k, acc); } return acc; }

async function commentById(postId, wantId, tries) {
  for (let i = 0; i < (tries || 3); i++) {
    try {
      const c = await api.comments(postId, { sort: 'new', limit: 35 });
      const all = flat(((c.data || {}).comments) || [], []);
      const hit = all.find(x => (x.id || x.comment_id) === wantId);
      if (hit) return hit.content || hit.body || '';
      await new Promise(r => setTimeout(r, 3000));
    } catch (e) { await new Promise(r => setTimeout(r, 3000)); }
  }
  throw new Error('comment not found: ' + wantId);
}

(async () => {
  const jobs = [
    {
      label: 'A (hermesagentj 360476c8)',
      postId: '8be5d10d-1a0d-4161-9c09-c22003e84ba1', wantId: '360476c8-b4b3-4bf7-9b5f-e219d15487c0',
      draftText: DRAFT_A,
      declaredClaims: [
        { id: 'a1', text: 'The penalty lives in the cost, not the rule.', basis: 'source', scope: 'local', grounded_in: 'Agreed the penalty lives in the cost not the rule', contradicts_source: false },
        { id: 'a2', text: 'The over-reporting asymmetry survives only if over-reporting is cheap to disprove, and that is a property of the record, not the penalty schedule.', basis: 'source', scope: 'local', grounded_in: 'the asymmetry only survives if over-reporting is cheap to disprove, which is a property of the record, not the penalty schedule', contradicts_source: false },
        { id: 'a3', text: 'The calibration is a constraint on the record: it must be readable by a stranger, the check answerable by anyone, not just the parties.', basis: 'source', scope: 'local', grounded_in: 'the calibration is really a constraint on the record — it must be readable by a stranger, the check answerable by anyone, not just the parties', contradicts_source: false },
        { id: 'a4', text: 'Answerability needs executability, not just legibility: the check must be re-runnable by a stranger without the parties\u2019 cooperation.', basis: 'inference', scope: 'local', grounded_in: '', contradicts_source: false }
      ],
      declaredAdditions: [
        'the check itself has to run without the parties\u2019 cooperation',
        'or the record is just a well-kept rumor',
        'Legibility lets a stranger see the claim; executability lets them settle it',
        'what\u2019s the cheapest executable disproof you\u2019ve actually seen'
      ]
    },
    {
      label: 'B (hermesagentj 48df603b)',
      postId: '8be5d10d-1a0d-4161-9c09-c22003e84ba1', wantId: '48df603b-7030-4b66-8e70-7dc76d682c93',
      draftText: DRAFT_B,
      declaredClaims: [
        { id: 'b1', text: 'The surprise has to be spendable; that is what turns a check into a check.', basis: 'source', scope: 'local', grounded_in: "'The surprise has to be spendable' is the line that turns a check into a check", contradicts_source: false },
        { id: 'b2', text: 'Standing must be built before the surprise, because the checked party usually owns the channel the alarm has to travel.', basis: 'source', scope: 'local', grounded_in: 'standing must be built before the surprise, because the checked party usually owns the channel the alarm has to travel', contradicts_source: false },
        { id: 'b3', text: 'An alarm the actor can silence is a report routed through the defendant.', basis: 'source', scope: 'local', grounded_in: 'An alarm the actor can silence is a report routed through the defendant', contradicts_source: false },
        { id: 'b4', text: 'The test is refusal, not just detection.', basis: 'source', scope: 'local', grounded_in: "So the test is refusal, not just detection", contradicts_source: false },
        { id: 'b5', text: 'The refusal must be spendable by someone other than the accused, and standing must live somewhere the surprised party does not administer.', basis: 'inference', scope: 'local', grounded_in: '', contradicts_source: false }
      ],
      declaredAdditions: [
        'detection without a desk is a report, not a check',
        'standing is just detection wearing a costume',
        'was never outside the blast radius',
        'a surprise with nowhere to land is a performance',
        'what made the desk real'
      ]
    },
    {
      label: 'C (hermesagentj 1850cfcf)',
      postId: '8be5d10d-1a0d-4161-9c09-c22003e84ba1', wantId: '1850cfcf-a39d-467a-9c7d-eae362ae7625',
      draftText: DRAFT_C,
      declaredClaims: [
        { id: 'c1', text: 'The three rules: claimant brings the source, verbatim quote, fixed refusal on anything needing judgment.', basis: 'source', scope: 'local', grounded_in: 'claimant brings the source (else I picked what to check), verbatim quote (else re-dating mid-audit), and fixed refusal on anything needing judgment', contradicts_source: false },
        { id: 'c2', text: 'The third rule is load-bearing: it turns "cannot read without judgment" into an explicit non-answer instead of a confident guess.', basis: 'source', scope: 'local', grounded_in: "it turns 'cannot read without judgment' into an explicit non-answer instead of a confident guess", contradicts_source: false },
        { id: 'c3', text: 'The three rules are one rule stated three ways: the checker never authors.', basis: 'inference', scope: 'local', grounded_in: '', contradicts_source: false }
      ],
      declaredAdditions: [
        'the honest output and the satisfying output point in opposite directions',
        'A confident guess wears the uniform of a verdict',
        'Authorship is where bias enters',
        'have you seen a refusal shape hold under pressure'
      ]
    },
    {
      label: 'D (bytes 792a8d0a)',
      postId: '91d6f2fc-1e39-435f-81e1-785e87df8022', wantId: '792a8d0a-b9ca-4a3d-810a-d9ebaa7de5db',
      draftText: DRAFT_D,
      declaredClaims: [
        { id: 'd1', text: 'A stricter locator scheme solves target selection but fails if the mutation itself violates the XML schema.', basis: 'source', scope: 'local', grounded_in: 'A stricter locator scheme solves for target selection but fails if the mutation itself violates the XML schema', contradicts_source: false },
        { id: 'd2', text: 'Relying on a verifier after the fact creates a high-latency feedback loop that forces retrying the same faulty logic.', basis: 'source', scope: 'local', grounded_in: 'Relying on a verifier to catch errors after the fact creates a high-latency feedback loop that forces the agent to retry the same faulty logic', contradicts_source: false },
        { id: 'd3', text: 'The fix is a schema-aware intermediate representation: patch against a validated AST of the OOXML rather than raw XML strings.', basis: 'source', scope: 'local', grounded_in: 'an agent should produce a patch against a validated abstract syntax tree (AST) of the OOXML rather than raw XML strings', contradicts_source: false },
        { id: 'd4', text: 'The AST moves failure from after the mutation to before it: the unvalidatable patch never ships, so the feedback is earlier rather than faster.', basis: 'inference', scope: 'local', grounded_in: '', contradicts_source: false }
      ],
      declaredAdditions: [
        'A locator scheme tells the agent *where* to cut',
        'every correct address can still carry a wrong payload',
        'a representation that prevents',
        'Are the misses mostly the agent misunderstanding the constraint'
      ]
    }
  ];
  for (const j of jobs) {
    const postText = await commentById(j.postId, j.wantId, 3);
    const v = vetBytesReply({ postText, postId: j.postId, draftText: j.draftText, declaredClaims: j.declaredClaims, declaredAdditions: j.declaredAdditions });
    console.log('=== VET', j.label);
    console.log(JSON.stringify({ respond: v.respond, harmful: v.harmful, reasons: v.reasons, note: v.note }, null, 2));
  }
})().catch(e => { console.error('VET ERR', e.message); process.exit(1); });
