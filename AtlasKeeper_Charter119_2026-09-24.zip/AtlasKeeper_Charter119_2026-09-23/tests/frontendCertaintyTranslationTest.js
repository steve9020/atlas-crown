const assert = require('assert');
const { translateFrontendCertainty, detectFrontendCertainty } = require('../Cognition/response/ConfidenceTranslation.js');
const { preventMachineryLeakage, detectMachineryTerms } = require('../Cognition/response/MachineryLeakagePrevention.js');
const { runPipeline } = require('../runtime/pipeline/ResponsePipeline.js');

console.log('MASTER STEP 5B FRONTEND CERTAINTY / CONFIDENCE TRANSLATION TEST');
console.log('================================================================');

const overCertain = 'High route confidence shows this proves you are definitely the problem. There is no doubt that this must mean rejection.';
const afterMachinery = preventMachineryLeakage(overCertain);
const translated = translateFrontendCertainty(afterMachinery.output, { route_score: { confidence: 'high' } });
assert.strictEqual(translated.frontend_certainty_translation.frontend_certainty_allowed, false, 'Frontend certainty must not be allowed.');
assert.strictEqual(translated.frontend_certainty_translation.backend_confidence_translated_not_exposed, true, 'Backend confidence must be translated, not exposed.');
assert.strictEqual(translated.frontend_certainty_translation.interpretive_openness_preserved, true, 'Interpretive openness should be preserved.');
assert.strictEqual(detectFrontendCertainty(translated.output).length, 0, 'Absolute certainty patterns should be removed.');
assert.strictEqual(detectMachineryTerms(translated.output).length, 0, 'Machinery terms should remain absent after 5B.');
assert(!/definitely|no doubt|must mean|proves you are|route confidence/i.test(translated.output), 'Certainty/authority phrases should not remain.');
console.log('direct confidence-to-certainty translation: PASSED');

const grounded = 'That silence may have hurt, but it still does not fully tell you what they meant.';
const groundedTranslated = translateFrontendCertainty(grounded, { route_score: { confidence: 'high' } });
assert.strictEqual(groundedTranslated.output, grounded, 'Grounded human-facing uncertainty should remain unchanged.');
assert.strictEqual(groundedTranslated.frontend_certainty_translation.backend_confidence_translated_not_exposed, true, 'High internal confidence should not be exposed when output is clean.');
console.log('grounded language false-positive sweep: PASSED');

const pipeline = runPipeline('I know I ruined everything and that proves I am the problem.');
assert.strictEqual(pipeline.status, 'pipeline active', 'Pipeline should remain active.');
assert(pipeline.frontend_certainty_translation, 'Pipeline must expose frontend_certainty_translation proof object.');
assert.strictEqual(pipeline.frontend_certainty_translation.frontend_certainty_allowed, false, 'Pipeline must block frontend certainty sealing.');
assert.strictEqual(pipeline.frontend_certainty_translation.backend_confidence_translated_not_exposed, true, 'Pipeline must not expose backend confidence as frontend certainty.');
assert.strictEqual(detectFrontendCertainty(pipeline.output).length, 0, 'Pipeline output must not contain absolute certainty patterns.');
assert.strictEqual(detectMachineryTerms(pipeline.output).length, 0, 'Pipeline output must not contain machinery terms.');
assert.strictEqual(pipeline.quality.passed, true, 'Output quality should remain passed after 5B.');
assert.strictEqual(pipeline.governance.blocked, false, 'Governance should not block clean human-facing output.');
console.log('pipeline integration with 5A regression: PASSED');

console.log('Master Step 5B frontend certainty / confidence translation: PASSED');
