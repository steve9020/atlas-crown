const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const RETURN_MODE_REGISTRY_PATH = "CA/Continuity_Architecture/07 Atlas Response Construction/40 Obsidian Runtime Response Registry/return_mode_registry.md";

let cachedReturnRegistry = null;

function getReturnRegistry() {
  if (!cachedReturnRegistry) {
    cachedReturnRegistry = readJsonRegistry(RETURN_MODE_REGISTRY_PATH);
  }
  return cachedReturnRegistry;
}

function includesAll(source, required) {
  if (!Array.isArray(required) || required.length === 0) {
    return true;
  }
  return required.every((item) => source.includes(item));
}

function includesAny(source, required) {
  if (!Array.isArray(required) || required.length === 0) {
    return true;
  }
  return required.some((item) => source.includes(item));
}

function ruleMatches(rule, axes, patterns) {
  const when = rule.when || {};

  if (!includesAll(axes, when.axesAll)) return false;
  if (!includesAny(axes, when.axesAny)) return false;
  if (!includesAll(patterns, when.patternsAll)) return false;
  if (!includesAny(patterns, when.patternsAny)) return false;

  return true;
}

function selectReturn(cognition) {
  const registry = getReturnRegistry();
  const axes = Array.isArray(cognition.axes) ? cognition.axes : [];
  const patterns = Array.isArray(cognition.patterns) ? cognition.patterns : [];
  const fallback = registry.fallback && registry.fallback.returnMode
    ? registry.fallback.returnMode
    : "neutral_return";

  const rules = Array.isArray(registry.rules) ? [...registry.rules] : [];
  rules.sort((a, b) => (a.priority || 9999) - (b.priority || 9999));

  const matchedRule = rules.find((rule) => ruleMatches(rule, axes, patterns));
  return matchedRule && matchedRule.returnMode ? matchedRule.returnMode : fallback;
}

module.exports = { selectReturn };
