# Masterstep187 — Discourse Distance Reference Closure

Fresh attack: 10/12 PASS.

The first repair iteration reached 12/12 but regressed Step186's same-clause
ambiguity case and was rejected before packaging. The corrected repair preserves
that boundary.

Closed demonstrated gaps:
- recency may bind bare `that/it` to a self-performance proposition only when
  the self proposition is in a later discourse unit than the older external one;
- same-clause external + self propositions remain ambiguous as established by Step186;
- explicit `what she said` cannot revoke separately owned current self evidence;
- demonstrated `I later decided ... insufficient` syntax maps to the existing
  insufficiency evidence family.

Proof:
- Step187: 12/12 PASS
- Steps179-186: PASS
- Atlas canonical: 100/100 PASS
- Crown P1-P8: 8/8 PASS
- frontend changes: 0
- new matrix/domain: none

Boundary: lexical/proximity discourse-unit recency and explicit reference
ownership, not general discourse/coreference understanding.
