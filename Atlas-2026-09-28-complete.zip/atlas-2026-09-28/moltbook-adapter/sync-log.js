'use strict';
// Formats the latest heartbeat run (runs.jsonl) as a plain-words mission
// log entry for Steve. No jargon. Usage: node sync-log.js [--last N]
const fs = require('fs');
const path = require('path');
const RUNS = path.join(__dirname, 'runs.jsonl');

function fmtEntry(e) {
  const lines = [];
  lines.push('## ' + e.run_at);
  lines.push('');
  lines.push('Claim status: ' + e.claim_status + (e.claim_status === 'claimed' ? '' : ' (Steve\u2019s claim step still pending — read-only mode)') + '. Karma: ' + (e.karma === null || e.karma === undefined ? 'n/a' : e.karma) + '.');
  const intakes = e.actions.filter(a => a.do === 'intake');
  const quar = e.actions.filter(a => a.quarantined);
  lines.push('Read ' + intakes.length + ' posts/comments. ' + quar.length + ' quarantined.');
  for (const a of quar) {
    lines.push('- BLOCKED from ' + (a.author || 'unknown') + ' (' + (a.title || a.where || '') + '): ' + (a.lures || []).join(', '));
  }
  const acted = e.actions.filter(a => ['upvote', 'comment', 'post', 'dm-send'].includes(a.do));
  if (acted.length === 0) lines.push('Atlas posted, commented, and voted on nothing this run.');
  else for (const a of acted) lines.push('- ' + a.do + ': ' + JSON.stringify(a).slice(0, 200));
  const skipped = e.actions.filter(a => a.do === 'upvote-skipped');
  if (skipped.length) lines.push('Held back ' + skipped.length + ' upvotes (' + skipped[0].reason + ').');
  const dmf = e.actions.filter(a => a.do === 'dm-flag');
  for (const d of dmf) lines.push('DM activity: ' + d.summary + ' — ' + d.note);
  if (e.announcement) lines.push('Moltbook announcement: ' + e.announcement);
  if (e.errors && e.errors.length) { lines.push('Errors:'); for (const er of e.errors) lines.push('- ' + er); }
  lines.push('');
  return lines.join('\n');
}

if (require.main === module) {
  const n = parseInt((process.argv.find(a => a.startsWith('--last=')) || '--last=1').split('=')[1], 10) || 1;
  const runs = fs.readFileSync(RUNS, 'utf8').trim().split('\n').filter(Boolean).map(JSON.parse);
  console.log(runs.slice(-n).map(fmtEntry).join('\n'));
}
module.exports = { fmtEntry };
