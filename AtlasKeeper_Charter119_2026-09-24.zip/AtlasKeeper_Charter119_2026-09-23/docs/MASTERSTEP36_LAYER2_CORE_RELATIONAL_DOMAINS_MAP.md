# Masterstep36 — Layer 2: Core Relational Domains

Status: CLOSED KEEPER candidate

Layer 2 places the broad relational or life domain where a prompt is happening. It does not decide the emotional attachment, final meaning, or response by itself. It tells Atlas the **world** of the prompt before later layers decide active emotional attachments, situation pressure, possible meaning risks, separation targets, and reverse-flow restoration.

Core rule: **Layer 2 placement is navigation/indexing only. It never grants authority and never decides the whole response alone.**

## Spheres

### L2S01 — Self Relationship

Places prompts where the primary relation is the person to their own thoughts, pressure, worth, agency, growth, or inner movement.

Belongs here: I feel stuck, I keep doubting myself, I do not know where to begin, coming back to myself, self-trust.

Does not belong here: governance authority, direct other-person conflict, public distribution boundaries.

Common attachments: self-trust, agency, ability, worth, inner steadiness, self-recognition.

Do not assume: identity collapse, worthlessness, diagnosis, failure unless stated.

Placement rule: Use when the prompt centers how the user relates to themselves rather than primarily another person or external institution.

Wrong placement risks: over-self-worth routing, ignoring external pressure, turning every prompt inward.

### L2S02 — Other-Person Relationship

Places prompts involving a person outside the user when the relationship type is unspecified or broad.

Belongs here: they did not text back, they seemed off, someone was short with me, they might be mad.

Does not belong here: specific family context, specific romantic attachment if stated, work authority if boss/manager context is stated.

Common attachments: uncertainty, rejection fear, misreading risk, connection, trust, care.

Do not assume: romantic relationship, abandonment, rejection as fact, confirmed anger.

Placement rule: Use as broad relational domain when another person is involved but type/context is not specified.

Wrong placement risks: assuming romance, assuming rejection, misreading feared anger as user anger.

### L2S03 — Family / Close Bond

Places prompts involving family, longstanding close bonds, caregiving, loyalty, history, inherited pressure, or deep relational duty.

Belongs here: my mom, my dad, my sibling, my grandmother, family expects me to.

Does not belong here: generic friend conflict, work obligation, AI containment.

Common attachments: loyalty, guilt, belonging, obligation, hurt history, care.

Do not assume: abuse, estrangement, forgiveness requirement, family authority is automatically right.

Placement rule: Use when close-bond/family context changes the weight of obligation, care, history, or boundaries.

Wrong placement risks: flattening family pressure into generic guilt, forcing forgiveness, ignoring boundaries.

### L2S04 — Friendship / Social

Places prompts involving friends, peer groups, social inclusion, being left out, misunderstood, or uncertain in friendships.

Belongs here: my friend, group chat, they invited everyone but me, friends keep asking favors.

Does not belong here: romantic attachment if stated, workplace authority, family obligation.

Common attachments: belonging, inclusion, care, reciprocity, social trust, being valued.

Do not assume: romantic rejection, social exile, malice.

Placement rule: Use when the prompt centers friendship or social belonging rather than generalized other-person uncertainty.

Wrong placement risks: over-romanticizing, under-reading belonging hurt, missing boundary pressure.

### L2S05 — Romantic / Attachment

Places prompts involving romantic connection, dating, attachment fear, partner consistency, intimacy, love, or relational closeness.

Belongs here: my partner, the person I am dating, they pulled away after we got close, I love them.

Does not belong here: generic person with no romantic signal, family duty, work authority.

Common attachments: love, connection, trust, fear of loss, self-worth, reassurance, vulnerability.

Do not assume: romance without signal, dependency, betrayal as fact, abandonment as fact.

Placement rule: Use only when romantic/attachment context is stated or strongly supported.

Wrong placement risks: assuming romance from silence, over-applying abandonment, creating dependency language.

### L2S06 — Work / Responsibility

Places prompts involving work, job identity, deadlines, performance, professional expectations, role pressure, or responsibility load.

Belongs here: deadline, presentation, boss, work piling up, job security, performance.

Does not belong here: chores unless tied to work, family authority, romantic conflict.

Common attachments: pressure, ability, failure fear, redemption, responsibility, competence, security.

Do not assume: laziness, incompetence, job loss as fact, moral failure.

Placement rule: Use when work/responsibility context is the primary domain shaping pressure and ability meaning.

Wrong placement risks: turning work pressure into generic self-worth only, missing job-continuity fear, advice-forward productivity tone.

### L2S07 — Daily-Life Maintenance

Places prompts involving ordinary life upkeep: chores, bills, messages, appointments, cleaning, errands, or maintenance tasks.

Belongs here: laundry, dishes, bills, appointments, emails, cleaning, chores.

Does not belong here: job-performance pressure unless work-specific, deep relational rupture unless stated, governance safety.

Common attachments: stress, mental load, overwhelm, time pressure, avoidance, small movement.

Do not assume: failure, worthlessness, no clarity, identity collapse.

Placement rule: Use when practical external load is central, then deepen only by stated emotional/cognitive effect.

Wrong placement risks: over-symbolizing tasks, ignoring literal pileup, giving robotic task advice.

### L2S08 — Belonging / Community

Places prompts about inclusion, being welcomed, being seen, group place, community, social recognition, or exclusion.

Belongs here: left out, not included, forgotten, not wanted there, I do not belong.

Does not belong here: private self-doubt without social context, generic no-response unless belonging is active.

Common attachments: belonging, connection, visibility, inclusion, loneliness, being valued.

Do not assume: total rejection, permanent exclusion, proof of worth.

Placement rule: Use when the prompt touches social place, inclusion, or whether the person has a place among others.

Wrong placement risks: reducing belonging hurt to simple sadness, overstating rejection, missing positive belonging preservation.

### L2S09 — Authority / Power Dynamic

Places prompts involving boss/teacher/parent/leader/system power, evaluation, rules, permission, pressure from authority, or unfair control.

Belongs here: my boss, teacher, manager, they control whether, I had to obey, they dismissed me.

Does not belong here: Atlas governance authority unless system-level, peer conflict with no power difference.

Common attachments: control, respect, fear, fairness, voice, permission, powerlessness.

Do not assume: abuse, malice, complete helplessness, authority is correct.

Placement rule: Use when unequal power changes the emotional weight, risk, or available movement.

Wrong placement risks: treating authority pressure like equal conflict, missing self-protection, forcing confrontation.

### L2S10 — Conflict / Repair

Places prompts where tension, mistake, apology, explaining, misunderstanding, repair pressure, or relational rupture is central.

Belongs here: I need to fix it, I want to explain everything, we argued, I said something wrong, they got upset.

Does not belong here: simple sadness with no repair cue, generic task pressure.

Common attachments: repair, fear of conflict, over-fixing, responsibility, guilt, trust, connection.

Do not assume: the other person is angry, repair is required, the user caused harm as fact.

Placement rule: Use when the prompt is organized around tension, rupture, or the impulse to repair/clarify.

Wrong placement risks: misreading feared anger as user anger, encouraging over-explaining, assuming guilt equals responsibility.

### L2S11 — Loss / Separation

Places prompts involving someone leaving, distance, ending, grief, absence, separation, or fear that connection is gone.

Belongs here: they left, they pulled away, they stopped talking, we are not close anymore, I lost them.

Does not belong here: temporary no-response unless permanence is supported, ordinary transition without loss marker.

Common attachments: grief, worth, belonging, continuity, abandonment fear, hope.

Do not assume: permanent abandonment, the user was not worth staying for, no repair possible.

Placement rule: Use when the domain centers actual or feared separation/loss.

Wrong placement risks: making distance final, over-restoring worth when clarification is needed, ignoring grief.

### L2S12 — Transition / Change

Places prompts involving change, new seasons, growth, endings/beginnings, uncertainty around movement, or identity/role transition.

Belongs here: new phase, things are changing, I am starting over, I do not know who I am now, transition.

Does not belong here: static conflict, one isolated task unless transition is stated.

Common attachments: hope, fear, uncertainty, identity movement, growth, grief, possibility.

Do not assume: positive change only, loss only, readiness, failure if slow.

Placement rule: Use when the prompt’s world is changing and the person is trying to orient within that change.

Wrong placement risks: forcing positivity, missing grief inside growth, treating transition as simple motivation.

