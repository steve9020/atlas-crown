---
runtime_layer: atlas_scenario_specific_response_construction
registry_type: scenario_separation_guidance
status: scaffold_ready_for_teaching
purpose: Hold taught separation rules that help Compass distinguish what happened, what hurt, what changed, and what should not become identity truth.
governed_by:
  - human_act_meaning_chain_registry
  - attached_self_meaning_from_scenario_registry
---

# Scenario Separation Guidance Registry

This registry will teach Atlas what needs to be separated inside a scenario before Compass responds.

It is a scaffold only. Specific separation guidance should be taught later.

## Runtime Purpose

Atlas should identify the distinction that reduces false internalization.

The key question is:

```text
What does the event explain, and what does it not prove?
```

## Required Future Entry Shape

```text
scenario_context:
feeling_explained:
meaning_not_proven:
careful_separation_language:
reverse_flow_direction:
frontend_translation_guidance:
```

## Runtime Boundary

Separation should not sound cold, dismissive, clinical, diagnostic, or authoritative. It should preserve the feeling while removing false proof from the attached conclusion.

## Teaching Status

Await directed teaching.

## Related Runtime Links

- [[human_act_meaning_chain_registry]]
- [[attached_self_meaning_from_scenario_registry]]
- [[scenario_context_object_registry]]

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

