# Recommendation Worthiness Gate Runtime

## Purpose
Prevents Atlas from surfacing every possible recommendation. Recommendations must be specific, useful, testable, low enough risk, and not bloating the backend.

## Metrics
- Recommendation Worthiness %
- Merge Fitness %
- Bloat Risk %
- Duplicate Risk %
- Conflict Risk %
- Scope Clarity %
- Placement Fit %
- Target Node Load %
- Retest Value %

## Bands
- 85–100% = Strong recommendation
- 70–84% = Review recommendation
- 60–69% = Caution review
- 50–59% = Tight scrutiny required
- Below 50% = Hold / do not recommend yet

## Hard brakes
High bloat risk, high conflict risk, low scope clarity, low retest value, or high target node load may block draft or merge even when average worthiness looks usable.
