# Weak Point Gap Completion Engine Overview

## Purpose
This engine identifies what Compass misunderstood, what backend gap caused the misunderstanding, and what rule would reduce the failure next time.

## Core Flow
Compass response → evaluation → weak point detected → missing gap identified → target backend file selected → correction drafted → complete proposal created → review panel.

## Core Rule
Atlas should not only recognize that a response failed. It should identify:
- what failed
- why it failed
- what understanding was missing
- what backend rule would prevent it
- where that rule belongs
- how the correction should be drafted

## Boundary
Gap completion creates proposals. It does not silently update Atlas.

## Integration with newer teaching runtimes

Response Weakness Detection identifies likely response failures.
Teaching Gap Detection names the missing backend rule or knowledge.
Route Assumption Check reduces failures before response generation by comparing every meaningful candidate route against the prompt.

The Weak Point Gap Completion Engine remains the proposal drafting bridge. It should receive classified weaknesses and missing gaps, then prepare reviewable teaching proposals without silent mutation.

