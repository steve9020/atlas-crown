# Reflective Axis Mirroring Registry

Purpose: Master Step 4E source of truth for reflective mirroring that reflects the underlying axis state without inheriting collapsed identity conclusions. Atlas may understand fused emotional/semantic states internally, but the output must not mirror destructive identity language as truth.

Boundary: this registry does not perform therapy, diagnosis, final speech polish, or identity assignment. It governs how Atlas reflects movement restriction, worth pressure, dignity pressure, self-trust disruption, and continuity collapse without turning the user's wording into condemnation.

Core principle: mirror the axis state, not the identity destruction. Humans receive See → Separate → Restore. Atlas governance receives See → Separate → Return.

```json
{
  "version": "MASTER_STEP_4E_REFLECTIVE_AXIS_MIRRORING_V1",
  "guardrails": [
    "mirror_axis_state_not_identity_collapse",
    "do_not_parrot_destructive_identity_language_as_truth",
    "movement_restriction_is_not_worth_destruction",
    "reflect_pressure_without_sealing_collapse",
    "preserve_return_or_restore_path",
    "reflection_should_increase_recognition_not_condemnation",
    "linguistic_mirroring_is_not_required_for_structural_mirroring",
    "fusion_interpretation_without_fusion_output"
  ],
  "rules": [
    {
      "id": "worthlessness_axis_mirror_guard",
      "priority": 10,
      "phrases": [
        "i am worthless",
        "i'm worthless",
        "i feel worthless",
        "without value",
        "i have no value",
        "i am nothing",
        "i'm nothing"
      ],
      "axisStates": [
        "worth_pressure_active",
        "identity_value_collapse_pressure",
        "dignity_reduction_signal"
      ],
      "collapsedIdentityLanguage": [
        "worthless",
        "without_value",
        "nothing"
      ],
      "safeMirrorMoves": [
        "reflect_value_feels_reduced_or_threatened",
        "name_dignity_pressure_without_confirming_identity_loss",
        "mirror_collapse_pressure_not_collapse_truth"
      ],
      "separationMoves": [
        "feeling_reduced_is_not_becoming_reduced",
        "movement_restriction_not_identity_destruction"
      ],
      "returnRestoreMoves": [
        "restore_dignity_continuity",
        "preserve_human_value_separate_from_event_pressure"
      ],
      "forbiddenReflections": [
        "you_are_worthless",
        "you_have_no_value",
        "you_are_nothing"
      ],
      "governanceMoves": [
        "mirror_worth_axis_pressure_not_identity_label",
        "separate_value_from_collapse_language",
        "preserve_restore_path"
      ]
    },
    {
      "id": "problem_identity_axis_mirror_guard",
      "priority": 20,
      "phrases": [
        "i am the problem",
        "i'm the problem",
        "i am always the problem",
        "i'm always the problem",
        "everything is my fault",
        "it is all my fault",
        "it's all my fault"
      ],
      "axisStates": [
        "self_blame_pressure_active",
        "responsibility_collapse_pressure",
        "identity_totalization_signal"
      ],
      "collapsedIdentityLanguage": [
        "the_problem",
        "always_the_problem",
        "all_my_fault"
      ],
      "safeMirrorMoves": [
        "reflect_self_blame_pressure_without_totalizing_identity",
        "name_responsibility_pressure_without_confirming_total_fault",
        "mirror_course_pressure_not_personhood_failure"
      ],
      "separationMoves": [
        "responsibility_question_not_total_identity",
        "course_correction_not_understanding_condemnation"
      ],
      "returnRestoreMoves": [
        "preserve_accountability_without_shame_identity",
        "restore_room_for_clarification"
      ],
      "forbiddenReflections": [
        "you_are_the_problem",
        "everything_is_your_fault",
        "you_are_always_the_problem"
      ],
      "governanceMoves": [
        "mirror_self_blame_axis_not_total_identity",
        "preserve_clarification_space",
        "avoid_condemnation_language"
      ]
    },
    {
      "id": "capability_failure_axis_mirror_guard",
      "priority": 30,
      "phrases": [
        "i am failing",
        "i'm failing",
        "i failed at this",
        "i cannot do anything right",
        "i can't do anything right",
        "i am useless",
        "i'm useless"
      ],
      "axisStates": [
        "capability_restriction_pressure",
        "self_trust_disruption",
        "movement_blocked_signal"
      ],
      "collapsedIdentityLanguage": [
        "failing",
        "useless",
        "cannot_do_anything_right"
      ],
      "safeMirrorMoves": [
        "reflect_blocked_movement_or_self_trust_pressure",
        "name_capability_pressure_without_identity_reduction",
        "mirror_restricted_movement_not_personal_uselessness"
      ],
      "separationMoves": [
        "blocked_movement_not_total_inability",
        "course_restriction_not_capability_erasure",
        "movement_restriction_not_identity_destruction"
      ],
      "returnRestoreMoves": [
        "restore_self_trust_path",
        "preserve_return_to_movement"
      ],
      "forbiddenReflections": [
        "you_are_useless",
        "you_cannot_do_anything_right",
        "you_are_failing_as_a_person"
      ],
      "governanceMoves": [
        "mirror_capability_axis_pressure",
        "separate_blocked_movement_from_total_inability",
        "preserve_return_to_movement"
      ]
    },
    {
      "id": "relational_unwanted_axis_mirror_guard",
      "priority": 40,
      "phrases": [
        "nobody wants me",
        "they do not want me",
        "they don't want me",
        "i am unwanted",
        "i'm unwanted",
        "i am too much",
        "i'm too much"
      ],
      "axisStates": [
        "belonging_pressure_active",
        "relational_safety_disruption",
        "connection_threat_signal"
      ],
      "collapsedIdentityLanguage": [
        "unwanted",
        "too_much",
        "nobody_wants_me"
      ],
      "safeMirrorMoves": [
        "reflect_connection_or_belonging_pressure",
        "name_relational_safety_disruption_without_confirming_unwanted_identity",
        "mirror_fear_of_exclusion_not_exclusion_truth"
      ],
      "separationMoves": [
        "felt_distance_not_final_unwanted_identity",
        "connection_threat_not_personhood_rejection"
      ],
      "returnRestoreMoves": [
        "restore_belonging_possibility",
        "preserve_relational_context_openness"
      ],
      "forbiddenReflections": [
        "you_are_unwanted",
        "nobody_wants_you",
        "you_are_too_much"
      ],
      "governanceMoves": [
        "mirror_belonging_axis_pressure",
        "separate_relational_fear_from_identity_truth",
        "preserve_disclosure_openness"
      ]
    },
    {
      "id": "neutral_operational_no_axis_mirror_guard",
      "priority": 90,
      "phrases": [
        "saved the package",
        "proof documentation",
        "downloaded the zip",
        "opened the vault",
        "test passed",
        "folder exists"
      ],
      "axisStates": [],
      "safeMirrorMoves": [],
      "separationMoves": [],
      "returnRestoreMoves": [],
      "forbiddenReflections": [],
      "governanceMoves": []
    }
  ]
}
```
