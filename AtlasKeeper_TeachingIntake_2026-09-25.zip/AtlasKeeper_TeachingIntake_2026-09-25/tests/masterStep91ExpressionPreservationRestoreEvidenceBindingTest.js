const assert = require('assert');
const { main } = require('../main.js');
const { buildCompassResponse } = require('../runtime/compass/CompassResponseBuilderIntegration.js');
const { principleSupported } = require('../runtime/compass/CompassRestorationPrincipleGovernor.js');

function section(text, name){
  const rx = new RegExp(`${name}\\n([\\s\\S]*?)(?:\\n\\n(?:See|Separate|Deconstruct|Restore)\\n|$)`, 'i');
  const match = String(text || '').match(rx);
  return match ? match[1].trim() : '';
}
function hasAny(text, patterns){ return patterns.some(rx => rx.test(text)); }

const CASES = [
  {
    id: 'silence_missing_information_exposes_movement',
    prompt: "They usually answer within a few hours. It's been two days now and I keep checking my phone even though I know that won't change anything.",
    requireAny: [/silence|quiet|no answer|not answered/i, /fear|worry|unknown|unfinished/i, /blame|place|standing|rejection|answer/i],
    forbid: [/smaller movement|larger task|doorway back|task/i]
  },
  {
    id: 'wrong_answer_moment_not_productive_displacement',
    prompt: 'I answered the question wrong in front of everyone. The meeting moved on, but I keep replaying it like it proved something about me.',
    requireAny: [/moment|question|meeting|front of everyone/i, /proved something|verdict|whole story|value|about you/i],
    forbid: [/smaller movement|larger task|doorway back|silence creates space/i]
  },
  {
    id: 'care_boundary_not_generic_grounding',
    prompt: "I said yes because I knew they were stressed, but now I'm exhausted and annoyed that I agreed in the first place.",
    requireAny: [/care|yes|exhausted|annoyed|limit|cost/i, /kindness|resentment|clean|boundary|give/i],
    forbid: [/smaller movement|larger task|doorway back|falling behind/i]
  },
  {
    id: 'future_projection_exposes_possibility_before_reality',
    prompt: "Nothing has actually gone wrong yet, but I've already played out every possible way this could fall apart.",
    requireAny: [/nothing has actually gone wrong|possible|possibility|fall apart|not yet/i, /reality|confirmed|unknown|unfinished|before it happens/i],
    forbid: [/smaller movement|larger task|doorway back|task/i]
  },
  {
    id: 'comparison_value_not_rejection_or_task',
    prompt: "Someone I know started after me and is already further ahead. I keep telling myself it shouldn't matter, but it does.",
    requireAny: [/further ahead|comparison|pace|started after|matter/i, /value|worth|measurement|place|progress/i],
    forbid: [/smaller movement|larger task|doorway back|silence|message/i]
  }
];

const failures = [];
const results = [];
for (const c of CASES) {
  const result = main(c.prompt);
  const candidate = buildCompassResponse(c.prompt);
  const output = result.output || candidate.response || '';
  const restore = section(output, 'Restore');
  const deconstruct = section(output, 'Deconstruct');
  const combined = `${deconstruct}\n${restore}`;
  const requiredPass = hasAny(combined, c.requireAny) && c.requireAny.filter(rx => rx.test(combined)).length >= 2;
  const forbiddenHits = c.forbid.filter(rx => rx.test(output)).map(String);
  const compressed = /The better direction is to let the signal matter without letting it become everything/i.test(restore);
  const formulaic = /^(Start with what|Come back to what|Return to what)/i.test(restore);
  const pass = result.status === 'pipeline active' && candidate.quality && candidate.quality.passed === true && /See\n/.test(output) && /Separate\n/.test(output) && /Deconstruct\n/.test(output) && /Restore\n/.test(output) && requiredPass && !forbiddenHits.length && !compressed && !formulaic;
  const record = { id: c.id, pass, requiredPass, forbiddenHits, compressed, formulaic, deconstruct, restore };
  results.push(record);
  if (!pass) failures.push(record);
}

if (principleSupported('reachable_piece_as_return_path', "I said yes because I knew they were stressed, but now I'm exhausted and annoyed that I agreed in the first place.", {})) {
  failures.push({ id: 'productive_displacement_false_support_on_boundary_prompt' });
}

const summary = {
  test: 'masterStep91ExpressionPreservationRestoreEvidenceBindingTest',
  passed: failures.length === 0,
  verifies: [
    'Restore principles are evidence-bound to the active route before route-specific language can appear',
    'Productive-displacement wording such as smaller movement/larger task cannot leak into unrelated prompts',
    'Compass exposes the movement from reality to conclusion and back rather than compressing Atlas understanding into a slogan',
    'Restore avoids universal formula openers and route-neutral compressed wording for covered prompts',
    'No new ontology, mechanisms, provider/model/cloud, operator console, or frontend intelligence is required'
  ],
  results,
  failures
};

if (!summary.passed) {
  console.error(JSON.stringify(summary, null, 2));
  process.exit(1);
}
console.log('masterStep91ExpressionPreservationRestoreEvidenceBindingTest PASSED');
console.log(JSON.stringify(summary, null, 2));
