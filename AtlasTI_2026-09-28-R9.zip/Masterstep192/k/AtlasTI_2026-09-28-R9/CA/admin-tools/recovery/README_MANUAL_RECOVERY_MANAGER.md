# Manual Recovery Manager

This folder contains the external manual recovery layer for the Continuity Architecture package.

## Purpose

The recovery tool exists so Steven can restore a known-good vault state if a test, edit, extraction issue, or plugin mistake corrupts the working vault.

## Hard Boundaries

- Manual only.
- Run from Command Prompt / terminal only.
- Obsidian must be closed before snapshot or restore.
- The Obsidian plugin must never call this tool.
- `main.js` must not reference this tool.
- No automatic recovery.
- No Atlas-triggered recovery.
- Restore quarantines the current target vault before replacing it.

## Commands

From this folder:

```cmd
node manual-recovery-manager.js --snapshot "C:\path\to\CA\Continuity_Architecture" clean_baseline
node manual-recovery-manager.js --verify-snapshot "C:\path\to\CA\admin-tools\recovery\snapshots\<snapshot_id>"
node manual-recovery-manager.js --dry-run-restore "C:\path\to\snapshot" "C:\path\to\CA\Continuity_Architecture"
node manual-recovery-manager.js --restore "C:\path\to\snapshot" "C:\path\to\CA\Continuity_Architecture" "Steven_Wagner"
```

## Restore Flow

```txt
Close Obsidian
→ verify snapshot
→ quarantine current target vault
→ restore known-good snapshot
→ verify restored hash
→ write recovery report
```

## What This Does Not Do

- It does not approve proposals.
- It does not integrate backend learning.
- It does not run from the plugin UI.
- It does not give Atlas recovery authority.
