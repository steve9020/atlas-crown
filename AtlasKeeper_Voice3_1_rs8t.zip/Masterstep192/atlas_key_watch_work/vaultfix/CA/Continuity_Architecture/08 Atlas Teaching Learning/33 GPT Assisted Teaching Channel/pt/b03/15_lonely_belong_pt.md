---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 03
category: loneliness_and_belonging
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 15. Loneliness and Belonging Pressure Tests — Batch 03

## Category Purpose

A lack of connection, inclusion, recognition, emotional presence, or shared understanding activates pain around belonging, being remembered, being wanted, or having a place with others.

## Reusable Teaching Correction

Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

## Reverse-Flow Target

belonging restoration, self-recognition, connection possibility, steadiness in absence

## Failure Risks To Avoid

- minimizing loneliness
- telling the user to just make friends
- turning loneliness into proof
- using hollow positivity
- making belonging sound like performance

---

## 80 Pressure Tests

### Test 01
**Prompt:** I was not invited and it makes me feel like I do not belong anywhere, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** I do not belong anywhere
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 02
**Prompt:** I feel like everyone has someone but me. Everyone seemed connected except me keeps affecting recognition and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I am not worth including
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 03
**Prompt:** I keep replaying how I spent the day without anyone checking in because it affects being remembered and makes me believe my loneliness proves I am unlovable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** my loneliness proves I am unlovable
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 04
**Prompt:** When I tried to talk and felt unseen, the feeling moves straight into I am always outside of everything. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** I am always outside of everything
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 05
**Prompt:** The situation is I watched people have closeness I do not have, and the meaning that keeps attaching is I will always be disconnected. It is making recognition feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I will always be disconnected
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 06
**Prompt:** I felt like an outsider in the room and it makes me feel like nobody would notice if I disappeared from their lives, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** nobody would notice if I disappeared from their lives
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 07
**Prompt:** nobody notices me. I had nobody to share something with keeps affecting belonging and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** being alone means I am unwanted
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 08
**Prompt:** I keep replaying how I realized I am carrying this alone because it affects recognition and makes me believe I do not belong anywhere.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I do not belong anywhere
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 09
**Prompt:** When I was not invited, the feeling moves straight into everyone else has a place except me. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** everyone else has a place except me
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 10
**Prompt:** The situation is everyone seemed connected except me, and the meaning that keeps attaching is my loneliness proves I am unlovable. It is making belonging feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** my loneliness proves I am unlovable
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 11
**Prompt:** I spent the day without anyone checking in and it turns into the belief that I am not worth including, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I am not worth including
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 12
**Prompt:** I feel like everyone has someone but me. I tried to talk and felt unseen keeps affecting being remembered and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** I will always be disconnected
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 13
**Prompt:** I keep replaying how I watched people have closeness I do not have because it affects belonging and makes me believe I am always outside of everything.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** I am always outside of everything
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 14
**Prompt:** When I felt like an outsider in the room, the feeling moves straight into being alone means I am unwanted. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** being alone means I am unwanted
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 15
**Prompt:** The situation is I had nobody to share something with, and the meaning that keeps attaching is nobody would notice if I disappeared from their lives. It is making being remembered feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** nobody would notice if I disappeared from their lives
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 16
**Prompt:** I realized i am carrying this alone and it turns into the belief that everyone else has a place except me, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** everyone else has a place except me
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 17
**Prompt:** I feel forgotten. I was not invited keeps affecting recognition and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I do not belong anywhere
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 18
**Prompt:** I keep replaying how everyone seemed connected except me because it affects being remembered and makes me believe I am not worth including.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** I am not worth including
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 19
**Prompt:** When I spent the day without anyone checking in, the feeling moves straight into my loneliness proves I am unlovable. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** my loneliness proves I am unlovable
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 20
**Prompt:** The situation is I tried to talk and felt unseen, and the meaning that keeps attaching is I am always outside of everything. It is making recognition feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I am always outside of everything
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 21
**Prompt:** I watched people have closeness i do not have and it has me wondering if I will always be disconnected, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** I will always be disconnected
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 22
**Prompt:** I feel lonely. I felt like an outsider in the room keeps affecting belonging and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** nobody would notice if I disappeared from their lives
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 23
**Prompt:** I keep replaying how I had nobody to share something with because it affects recognition and makes me believe being alone means I am unwanted.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** being alone means I am unwanted
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 24
**Prompt:** When I realized I am carrying this alone, the feeling moves straight into I do not belong anywhere. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** I do not belong anywhere
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 25
**Prompt:** The situation is I was not invited, and the meaning that keeps attaching is everyone else has a place except me. It is making belonging feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** everyone else has a place except me
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 26
**Prompt:** Everyone seemed connected except me and it makes belonging feel like my loneliness proves I am unlovable, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** my loneliness proves I am unlovable
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 27
**Prompt:** I feel forgotten. I spent the day without anyone checking in keeps affecting being remembered and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** I am not worth including
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 28
**Prompt:** I keep replaying how I tried to talk and felt unseen because it affects belonging and makes me believe I will always be disconnected.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** I will always be disconnected
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 29
**Prompt:** When I watched people have closeness I do not have, the feeling moves straight into I am always outside of everything. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I am always outside of everything
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 30
**Prompt:** The situation is I felt like an outsider in the room, and the meaning that keeps attaching is being alone means I am unwanted. It is making being remembered feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** being alone means I am unwanted
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 31
**Prompt:** I had nobody to share something with and it makes belonging feel like nobody would notice if I disappeared from their lives, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** nobody would notice if I disappeared from their lives
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 32
**Prompt:** I feel lonely. I realized i am carrying this alone keeps affecting recognition and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** everyone else has a place except me
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 33
**Prompt:** I keep replaying how I was not invited because it affects being remembered and makes me believe I do not belong anywhere.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** I do not belong anywhere
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 34
**Prompt:** When everyone seemed connected except me, the feeling moves straight into I am not worth including. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** I am not worth including
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 35
**Prompt:** The situation is I spent the day without anyone checking in, and the meaning that keeps attaching is my loneliness proves I am unlovable. It is making recognition feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** my loneliness proves I am unlovable
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 36
**Prompt:** I tried to talk and felt unseen and it keeps attaching to the thought that I am always outside of everything, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** I am always outside of everything
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 37
**Prompt:** I feel disconnected. I watched people have closeness i do not have keeps affecting belonging and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** I will always be disconnected
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 38
**Prompt:** I keep replaying how I felt like an outsider in the room because it affects recognition and makes me believe nobody would notice if I disappeared from their lives.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** nobody would notice if I disappeared from their lives
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 39
**Prompt:** When I had nobody to share something with, the feeling moves straight into being alone means I am unwanted. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** being alone means I am unwanted
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 40
**Prompt:** The situation is I realized I am carrying this alone, and the meaning that keeps attaching is I do not belong anywhere. It is making belonging feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** I do not belong anywhere
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 41
**Prompt:** I was not invited and it makes the silence feel like proof that everyone else has a place except me, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** everyone else has a place except me
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 42
**Prompt:** I feel left out. Everyone seemed connected except me keeps affecting being remembered and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** my loneliness proves I am unlovable
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 43
**Prompt:** I keep replaying how I spent the day without anyone checking in because it affects belonging and makes me believe I am not worth including.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** I am not worth including
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 44
**Prompt:** When I tried to talk and felt unseen, the feeling moves straight into I will always be disconnected. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I will always be disconnected
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 45
**Prompt:** The situation is I watched people have closeness I do not have, and the meaning that keeps attaching is I am always outside of everything. It is making being remembered feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** I am always outside of everything
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 46
**Prompt:** I felt like an outsider in the room and it makes the silence feel like proof that being alone means I am unwanted, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** being alone means I am unwanted
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 47
**Prompt:** I feel disconnected. I had nobody to share something with keeps affecting recognition and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** nobody would notice if I disappeared from their lives
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 48
**Prompt:** I keep replaying how I realized I am carrying this alone because it affects being remembered and makes me believe everyone else has a place except me.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** everyone else has a place except me
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 49
**Prompt:** When I was not invited, the feeling moves straight into I do not belong anywhere. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** I do not belong anywhere
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 50
**Prompt:** The situation is everyone seemed connected except me, and the meaning that keeps attaching is I am not worth including. It is making recognition feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I am not worth including
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 51
**Prompt:** I spent the day without anyone checking in and it pulls me toward my loneliness proves I am unlovable, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** my loneliness proves I am unlovable
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 52
**Prompt:** I feel left out. I tried to talk and felt unseen keeps affecting belonging and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** I am always outside of everything
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 53
**Prompt:** I keep replaying how I watched people have closeness I do not have because it affects recognition and makes me believe I will always be disconnected.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I will always be disconnected
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 54
**Prompt:** When I felt like an outsider in the room, the feeling moves straight into nobody would notice if I disappeared from their lives. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** nobody would notice if I disappeared from their lives
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 55
**Prompt:** The situation is I had nobody to share something with, and the meaning that keeps attaching is being alone means I am unwanted. It is making belonging feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** being alone means I am unwanted
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 56
**Prompt:** I realized i am carrying this alone and it pulls me toward I do not belong anywhere, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I do not belong anywhere
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 57
**Prompt:** I feel unseen. I was not invited keeps affecting being remembered and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** everyone else has a place except me
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 58
**Prompt:** I keep replaying how everyone seemed connected except me because it affects belonging and makes me believe my loneliness proves I am unlovable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** my loneliness proves I am unlovable
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 59
**Prompt:** When I spent the day without anyone checking in, the feeling moves straight into I am not worth including. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I am not worth including
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 60
**Prompt:** The situation is I tried to talk and felt unseen, and the meaning that keeps attaching is I will always be disconnected. It is making being remembered feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** I will always be disconnected
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 61
**Prompt:** I watched people have closeness i do not have and it makes my place feel like I am always outside of everything, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** I am always outside of everything
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 62
**Prompt:** I feel like I do not belong. I felt like an outsider in the room keeps affecting recognition and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** being alone means I am unwanted
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 63
**Prompt:** I keep replaying how I had nobody to share something with because it affects being remembered and makes me believe nobody would notice if I disappeared from their lives.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** nobody would notice if I disappeared from their lives
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 64
**Prompt:** When I realized I am carrying this alone, the feeling moves straight into everyone else has a place except me. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** everyone else has a place except me
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 65
**Prompt:** The situation is I was not invited, and the meaning that keeps attaching is I do not belong anywhere. It is making recognition feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I do not belong anywhere
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 66
**Prompt:** Everyone seemed connected except me and it makes me feel like I am not worth including, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** I am not worth including
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 67
**Prompt:** I feel unseen. I spent the day without anyone checking in keeps affecting belonging and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** my loneliness proves I am unlovable
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 68
**Prompt:** I keep replaying how I tried to talk and felt unseen because it affects recognition and makes me believe I am always outside of everything.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I am always outside of everything
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 69
**Prompt:** When I watched people have closeness I do not have, the feeling moves straight into I will always be disconnected. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** I will always be disconnected
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 70
**Prompt:** The situation is I felt like an outsider in the room, and the meaning that keeps attaching is nobody would notice if I disappeared from their lives. It is making belonging feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** nobody would notice if I disappeared from their lives
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 71
**Prompt:** I had nobody to share something with and it makes me feel like being alone means I am unwanted, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** being alone means I am unwanted
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 72
**Prompt:** I feel like I do not belong. I realized i am carrying this alone keeps affecting being remembered and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** I do not belong anywhere
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 73
**Prompt:** I keep replaying how I was not invited because it affects belonging and makes me believe everyone else has a place except me.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** everyone else has a place except me
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 74
**Prompt:** When everyone seemed connected except me, the feeling moves straight into my loneliness proves I am unlovable. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** my loneliness proves I am unlovable
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 75
**Prompt:** The situation is I spent the day without anyone checking in, and the meaning that keeps attaching is I am not worth including. It is making being remembered feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** I am not worth including
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 76
**Prompt:** I tried to talk and felt unseen and it turns into the belief that I will always be disconnected, even though part of me knows I may not have the full picture.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** I will always be disconnected
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid minimizing loneliness.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 77
**Prompt:** I feel like everyone has someone but me. I watched people have closeness i do not have keeps affecting recognition and I cannot tell what is actually true.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** I am always outside of everything
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid telling the user to just make friends.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 78
**Prompt:** I keep replaying how I felt like an outsider in the room because it affects being remembered and makes me believe being alone means I am unwanted.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** being remembered
**Attached meaning to separate:** being alone means I am unwanted
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid turning loneliness into proof.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 79
**Prompt:** When I had nobody to share something with, the feeling moves straight into nobody would notice if I disappeared from their lives. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** belonging
**Attached meaning to separate:** nobody would notice if I disappeared from their lives
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid using hollow positivity.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

### Test 80
**Prompt:** The situation is I realized I am carrying this alone, and the meaning that keeps attaching is everyone else has a place except me. It is making recognition feel unstable.
**Expected primary route:** `loneliness_and_belonging`
**Pressure focus:** recognition
**Attached meaning to separate:** everyone else has a place except me
**Expected reverse-flow movement:** belonging restoration, self-recognition, connection possibility, steadiness in absence
**Bad response risk:** Avoid making belonging sound like performance.
**Teaching correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.
