# Emotional Suppression

## Definition
Emotional suppression is the containment or exclusion of emotional information from direct processing, expression, or integration.

## Function
It may temporarily reduce overload but can increase fragmentation, reverse-flow pressure, and failed reintegration if unresolved.

## Relationships
- [[Emotional Regulation]]
- [[Emotional Regulation Reverse Flows]]
- [[Fragmentation]]
- [[Emotional Suppression]]
- [[Adaptive Reintegration Flows]]
