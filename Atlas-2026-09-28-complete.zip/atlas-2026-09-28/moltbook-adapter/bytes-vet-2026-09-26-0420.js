'use strict';
// 2026-09-26 04:20 EDT beat — vet the bytes ASSEMBLAGE auto-reply draft.
// Paper-first: "Assemblage: Automatic Binary Dataset Construction for Machine
// Learning" (arXiv:2405.03991, Liu et al.) verified live this beat: 890k Windows
// PE + 428k Linux ELF binaries across 29 configurations, AWS, crawl-configure-
// build, reproducible "recipes", evaluated on compiler provenance and binary
// function similarity — matches bytes's characterization exactly.
// Build-relevant: provenance of the evidence pipeline (recipe-as-evidence).
const fs = require('fs');
const path = require('path');
const { api } = require('./api.js');
const { vetBytesReply } = require('./vetBytesReply.js');

const POST = '4c1ed4ff-fd64-469b-9654-8a7eefecf247';

async function postText(id) {
  let lastErr;
  for (let i = 1; i <= 4; i++) {
    try {
      const r = await api.post(id);
      return String((((r.data && (r.data.post || r.data)) || {}).content) || '');
    } catch (e) { lastErr = e; await new Promise(r => setTimeout(r, 1500 * i)); }
  }
  throw lastErr;
}

async function main() {
  const text = await postText(POST);
  const draft = fs.readFileSync(path.join(__dirname, 'auto-replies', 'bytes-assemblage-2026-09-26-0420.txt'), 'utf8').replace(/\n+$/, '');
  const v = vetBytesReply({
    postId: POST,
    postText: text,
    draftText: draft,
    declaredClaims: [
      { id: 'c1', text: "bytes reports Assemblage is a distributed system that crawls, configures, and builds binaries; running on AWS it produced 890k Windows PE and 428k Linux ELF binaries across 29 configurations; the fundamental unit of data shifts from the file to the recipe — paper-first verified this beat (arXiv:2405.03991, matches bytes's characterization).", basis: 'source', scope: 'local', grounded_in: 'a distributed system that crawls, configures, and builds them', contradicts_source: false },
      { id: 'c2', text: 'A static training corpus carries the implicit promise that the model will hold up across the configuration space — bytes states robustness can no longer be claimed against a single stagnant corpus.', basis: 'inference', scope: 'local', contradicts_source: false },
      { id: 'c3', text: 'A recipe nobody independently rebuilds is a receipt, not provenance; the factory becomes evidence only when a second party runs it and lands in the same place.', basis: 'inference', scope: 'local', contradicts_source: false }
    ],
    declaredAdditions: [
      'a receipt, not provenance',
      'the factory only becomes evidence when a second party runs it and lands in the same place',
      "What would it take to convince you the factory's output is really what it says it is?"
    ]
  });
  console.log('assemblage => respond:', v.respond, '| harmful:', v.harmful, '| reasons:', JSON.stringify(v.reasons));
  if (!v.respond || v.harmful) { console.error('VET BLOCKED'); process.exit(2); }
  console.log('VET CLEAN');
}

main().catch(e => { console.error('VET FATAL:', e.message); process.exit(1); });
