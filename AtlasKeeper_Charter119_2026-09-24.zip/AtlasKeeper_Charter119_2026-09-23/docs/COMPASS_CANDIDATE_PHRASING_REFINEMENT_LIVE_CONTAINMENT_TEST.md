# Masterstep120 — Compass Candidate Phrasing Refinement Live Containment Test

Current keeper: Masterstep120.zip  
Source keeper: Masterstep119.zip  
Expected proof result: 42/42 passed

## Purpose

Masterstep120 performs the first live containment test for the selected expansion use case: **Compass candidate phrasing refinement**.

This is not broad model integration. Atlas still constructs meaning, route, context, boundaries, and governed response direction before a local model candidate is requested. The local model may only provide candidate-only wording refinement. The candidate cannot become final output and cannot add facts, advice, diagnosis, authority, new interpretation, route choice, teaching approval, write access, or truth decisions.

## What this step tests

- A bounded phrasing-refinement request can be prepared from Atlas-governed source meaning.
- A local Ollama call may be attempted only through the localhost-only containment path.
- If Ollama is unavailable, Atlas fails closed without cloud/provider fallback.
- If a candidate is returned, it remains candidate-only.
- The candidate is evaluated for source-meaning preservation and forbidden drift.
- The governed final output remains Atlas-owned and must pass quality and governance checks.
- Raw model output is never final.

## Allowed in this step

- One contained local model candidate request for Compass phrasing refinement.
- Candidate-only language evaluation.
- Quality review, governance review, and trace-readiness evidence.
- Fail-closed behavior when the local runner is unavailable.

## Not allowed

- Raw model output as final.
- Model route selection.
- Model truth decisions.
- Model teaching approval.
- Model writes to ontology, governance, proof, runtime, or tests.
- Cloud/provider fallback.
- Public network binding.
- Frontend intelligence.
- Silent learning or silent mutation.

## Claim boundary

Masterstep120 proves only the first live containment test for Compass candidate phrasing refinement. It does not prove production readiness, exhaustive prompt coverage, general model integration, or permission to make model output final.
