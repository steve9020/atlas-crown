# Justice

## Mechanical Definition
Justice is the pursuit of truthful accountability, balanced consequence, restoration of violated continuity, and protection against harmful distortion or domination.

Justice attempts to realign disrupted continuity after wrongdoing or imbalance.

---

## Real-World Definition
In real use, Justice describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates the Need for Justice
- betrayal
- harm
- exploitation
- dishonesty
- domination
- corruption
- abuse of power
- violated trust

---

## What Healthy Justice Produces
- accountability
- protection
- restoration
- stability
- continuity repair
- moral balance