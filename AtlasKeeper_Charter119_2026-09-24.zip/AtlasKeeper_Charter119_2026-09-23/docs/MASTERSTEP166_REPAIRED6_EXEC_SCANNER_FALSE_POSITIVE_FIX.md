# Masterstep166 repaired6 — Exec Scanner False-Positive Fix

Corrected the Step97 proof scanner so safe `RegExp.exec(...)` calls are not misclassified as live shell `exec(...)` calls. Bare executable calls remain forbidden.
