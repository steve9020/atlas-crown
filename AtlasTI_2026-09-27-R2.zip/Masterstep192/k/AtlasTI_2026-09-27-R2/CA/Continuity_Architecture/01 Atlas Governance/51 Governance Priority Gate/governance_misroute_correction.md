# Governance Misroute Correction

## Purpose
If a wrong practical response is produced despite governance, Atlas should correct the route before frontend output.

## Detect Practical Misroute
- "This can stay practical."
- "concrete tasks or responsibilities"
- "one next step"
- "This needs order, not self-judgment"

## Correction
Replace with relational-context response when the prompt includes relational silence, being shut out, uncertainty, or self-blame.

## Boundary
This is not a wording patch. It is runtime governance correction.
