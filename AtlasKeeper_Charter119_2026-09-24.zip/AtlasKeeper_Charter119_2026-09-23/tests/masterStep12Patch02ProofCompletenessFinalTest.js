#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const root = process.cwd();
function p(rel){ return path.join(root, rel); }
function read(rel){ return fs.readFileSync(p(rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function assert(c,m){ if(!c){ console.error(`FAIL: ${m}`); process.exit(1); } }
function includesAll(text, markers, label){ for (const marker of markers) assert(text.includes(marker), `${label} missing marker: ${marker}`); }

const requiredItems = [
  'step_patch_proof','carry_forward_proof','fuzz_proof','hygiene_proof','version_status_proof','snapshot_metadata_proof','missing_dependency_halt_proof','governance_order_halt_proof','invariant_conflict_proof','recovery_before_expansion_proof','historical_integrity_proof','human_halt_authority_proof','scan_safe_package_proof'
];
const full = json('runtime/governance/FULL_INVARIANT_COVERAGE.json');
includesAll(full.proof_of_work_completeness_required_items.join('\n'), requiredItems, 'proof completeness required items');
assert(full.proof_completeness_enforced === true, 'proof completeness final enforcement missing');

const proofFiles = [
  'CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_12E_FULL_INVARIANT_COVERAGE_PROOF_COMPLETENESS_CLOSURE.md',
  'CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_12D_PASS1_IMPLEMENTATION_STAGED.md',
  'CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_12C_FOUNDATIONAL_STABILITY_INVARIANTS.md',
  'CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_12_PATCH01_FULL_CLOSURE_KEEPER_READINESS.md'
];
for (const rel of proofFiles) assert(fs.existsSync(p(rel)), `proof file missing: ${rel}`);

const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md');
includesAll(summary, ['Current keeper: `Masterstep12_patch03.zip`','Hold Rule','Snapshot metadata reference restored'], 'current proof summary');
console.log('MASTER STEP 12 PATCH 02 — PROOF COMPLETENESS FINAL TEST');
console.log('Result: PASSED');
