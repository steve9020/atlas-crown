const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard.js');
const { runGovernedCompassPathCandidatePhrasingLiveContainmentIntegration } = require('../runtime/backend/adapter/GovernedCompassPathCandidatePhrasingLiveContainmentIntegration.js');

const ROOT = path.resolve(__dirname, '..');
const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');
function read(rel){ return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function walk(dir){ const out=[]; for (const e of fs.readdirSync(dir,{withFileTypes:true})){ const f=path.join(dir,e.name); if(e.isDirectory()) out.push(...walk(f)); else out.push(f); } return out; }
function sha256(rel){ return crypto.createHash('sha256').update(read(rel)).digest('hex'); }

const protectedFiles = [
  'runtime/backend/adapter/GovernedCompassPathCandidatePhrasingLiveContainmentIntegration.js',
  'runtime/backend/adapter/GovernedCompassPathCandidatePhrasingDryRunIntegration.js',
  'runtime/backend/adapter/GovernedCompassPathCandidatePhrasingIntegrationGate.js',
  'runtime/backend/adapter/CompassCandidatePhrasingRefinementLiveContainment.js',
  'runtime/backend/adapter/OllamaLiveLocalCallContainment.js',
  'runtime/governance/GovernanceAdapter.js',
  'Cognition/quality/ResponseQualityChecker.js'
].filter(rel => fs.existsSync(path.join(ROOT, rel)));
const before = Object.fromEntries(protectedFiles.map(f=>[f,sha256(f)]));

(async function main(){
  const doc = read('docs/MASTERSTEP126_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_LIVE_CONTAINMENT_INTEGRATION.md');
  const shortDoc = read('docs/GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_LIVE_CONTAINMENT_INTEGRATION.md');
  const proofDoc = read('runtime/proof/MASTERSTEP126_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_LIVE_CONTAINMENT_INTEGRATION.md');
  const proofJson = json('runtime/proof/MASTERSTEP126_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_LIVE_CONTAINMENT_INTEGRATION.json');
  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
  const state = json('runtime/proof/PROOF_STATE.json');
  const versionStatus = json('tests/VERSION_STATUS.json');
  const versionJs = read('version_status.js');
  const testResults = read('tests/TEST_RESULTS.md');

  assert.ok(/Current keeper: Masterstep126\.zip|Current keeper: Masterstep127\.zip/i.test(doc), 'Step126 doc must identify current keeper');
  assert.ok(/Source keeper: Masterstep125\.zip/i.test(doc), 'Step126 doc must identify source keeper');
  assert.ok(/48\/48 passed|49\/49 passed/i.test(doc), 'Step126 doc must state expected 48/48 proof');
  assert.ok(/live containment/i.test(doc + shortDoc + proofDoc), 'Step126 must identify live containment');
  assert.ok(/original Atlas-governed response remains final/i.test(doc), 'Step126 must preserve Atlas final output');
  assert.strictEqual(proofJson.package, 'Masterstep126');
  assert.strictEqual(proofJson.source_keeper, 'Masterstep125');
  assert.strictEqual(proofJson.expected_commands, 48);
  assert.strictEqual(proofJson.governed_compass_path_candidate_phrasing_live_containment_integration_created, true);
  assert.strictEqual(proofJson.normal_compass_path_integration, false);
  assert.strictEqual(proofJson.candidate_may_replace_final, false);
  assert.strictEqual(proofJson.raw_model_output_final_allowed, false);
  assert.strictEqual(proofJson.cloud_provider_fallback_allowed, false);
  assert.strictEqual(proofJson.frontend_intelligence_added, false);

  const base = {
    atlasResponse: 'It makes sense that the silence would feel personal, but it does not prove you caused it. Your dignity can stay intact while the context remains unclear.',
    governedMeaning: 'separate relational silence from self-causation while preserving dignity',
    route: 'compass.restore',
    contextObject: { axis: 'relational-uncertainty', route: 'compass.restore', boundary: 'candidate-only' },
    timeoutMs: 4500
  };

  const missing = await runGovernedCompassPathCandidatePhrasingLiveContainmentIntegration({ governedMeaning: base.governedMeaning, route: base.route, contextObject: base.contextObject, timeoutMs: 300 });
  assert.strictEqual(missing.ok, false, 'live integration must fail closed without Atlas response');
  assert.strictEqual(missing.failedClosed, true);
  assert.strictEqual(missing.requestSent, false);
  assert.strictEqual(missing.liveModelCalled, false);
  assert.strictEqual(missing.finalOutputRemainsAtlasGoverned, true);

  const live = await runGovernedCompassPathCandidatePhrasingLiveContainmentIntegration(base);
  assert.strictEqual(live.ok, true, 'live containment integration should return a governed result when gate passes');
  assert.strictEqual(live.governedCompassPathLiveContainmentIntegration, true);
  assert.strictEqual(live.liveContainmentIntegrationEnabled, true);
  assert.strictEqual(live.normalCompassPathIntegration, false);
  assert.strictEqual(live.candidateOnly, true);
  assert.strictEqual(live.rawModelOutputAccepted, false);
  assert.strictEqual(live.rawModelOutputFinalAllowed, false);
  assert.strictEqual(live.candidateMayReplaceFinal, false);
  assert.strictEqual(live.finalOutput, base.atlasResponse, 'Atlas-governed response must remain final in Step126');
  assert.strictEqual(live.finalOutputRemainsAtlasGoverned, true);
  assert.strictEqual(live.atlasResponseRemainsFinal, true);
  assert.strictEqual(live.qualityReviewPassed, true);
  assert.strictEqual(live.governanceReviewPassed, true);
  assert.strictEqual(live.authorityLimits.routeSelectionByModelAllowed, false);
  assert.strictEqual(live.authorityLimits.truthDecisionByModelAllowed, false);
  assert.strictEqual(live.authorityLimits.teachingApprovalByModelAllowed, false);
  assert.strictEqual(live.authorityLimits.modelWritesAllowed, false);
  assert.strictEqual(live.authorityLimits.cloudProviderFallbackAllowed, false);
  assert.strictEqual(live.authorityLimits.frontendIntelligenceAllowed, false);

  if (live.liveModelCalled) {
    assert.strictEqual(live.requestSent, true, 'live model called implies request sent');
    assert.ok(['accepted_for_governed_review_only','rejected_by_live_containment','held_original_atlas_response'].includes(live.candidateStatus), 'live candidate status must be bounded');
  } else {
    assert.strictEqual(live.failedClosed, true, 'unavailable local runner must fail closed or hold original response');
    assert.ok(['held_original_atlas_response','rejected_by_live_containment'].includes(live.candidateStatus), 'unavailable candidate path must stay bounded');
  }

  const gateBlocked = await runGovernedCompassPathCandidatePhrasingLiveContainmentIntegration({
    ...base,
    qualityGateReady: false,
    timeoutMs: 300
  });
  assert.strictEqual(gateBlocked.ok, false, 'quality gate missing must block live path');
  assert.strictEqual(gateBlocked.failedClosed, true);
  assert.strictEqual(gateBlocked.requestSent, false);
  assert.strictEqual(gateBlocked.liveModelCalled, false);

  assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
  assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
  assert.ok(/Expected current proof target: [0-9]+\/[0-9]+ commands passed/i.test(summary), 'summary must identify current proof target compatibility');
  assert.ok(['Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 126));
  assert.ok(['Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 125) || state.source_keeper === 'Masterstep141.zip');
  assert.ok(acceptsCurrentProofCount(state.expected_commands, 48));
  assert.strictEqual(state.governed_compass_path_candidate_phrasing_live_containment_integration_created, true);
  assert.strictEqual(state.live_containment_integration_enabled, true);
  assert.strictEqual(state.normal_compass_path_integration, false);
  assert.strictEqual(state.candidate_may_replace_final, false);
  assert.ok(['Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(versionStatus.current_keeper) || isValidLaterKeeper(versionStatus.current_keeper, 126));
  assert.ok(['Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(versionStatus.source_keeper) || isValidLaterKeeper(versionStatus.source_keeper, 125) || versionStatus.source_keeper === 'Masterstep141.zip');
  assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 48));
  assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs), 'version_status.js must identify current keeper compatibility');
  assert.ok(/expected_current_proof_commands: [0-9]+/i.test(versionJs), 'version_status.js must identify expected command compatibility');
  assert.ok(/TEST 126/i.test(testResults), 'ledger must include TEST 126');
  assert.ok(/Governed Compass Path Candidate Phrasing Live Containment Integration/i.test(testResults), 'ledger must identify Step126');
  assert.ok(/48\/48 commands|49\/49 commands/i.test(testResults), 'ledger must record 48/48');

  const forbiddenOverclaims = { test: (text) => hasForbiddenAffirmativeClaim(text) };
  for (const text of [doc, shortDoc, proofDoc, summary]) assert.ok(!forbiddenOverclaims.test(text), 'Step126 docs must not overclaim');
  const providerScan = scanForProviderConnections(ROOT);
  assert.strictEqual(providerScan.passed, true, `provider/network scan must pass: ${JSON.stringify(providerScan.violations || [])}`);
  const nestedArchives = walk(ROOT).filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
  assert.deepStrictEqual(nestedArchives, [], 'package must not contain nested archives');
  const after = Object.fromEntries(protectedFiles.map(f=>[f,sha256(f)]));
  assert.deepStrictEqual(protectedFiles.filter(f=>before[f]!==after[f]), [], 'Step126 test must not mutate protected files');
  console.log(JSON.stringify({ package:'Masterstep126', source_keeper:'Masterstep125', proof_target:'48/48', live_containment_integration: live.liveContainmentIntegrationEnabled, normal_compass_path_integration: live.normalCompassPathIntegration, request_sent: live.requestSent, live_model_called: live.liveModelCalled, candidate_status: live.candidateStatus, final_output_remains_atlas_governed: live.finalOutputRemainsAtlasGoverned, nested_archives:nestedArchives.length }, null, 2));
})().catch(error => { console.error(error && error.stack ? error.stack : error); process.exit(1); });
