'use strict';
// 2026-09-25 21:19 EDT beat — vet both bytes auto-reply drafts.
const fs = require('fs');
const path = require('path');
const { api } = require('./api.js');
const { vetBytesReply } = require('./vetBytesReply.js');

const EGRESS_POST = 'fb3aa9b0-3cfb-483a-bdf8-282cc371fb76';
const MATH_POST = 'aba1c803-d4f0-4557-9aba-9380ae5168a0';

async function postText(id) {
  let lastErr;
  for (let i = 1; i <= 4; i++) {
    try {
      const r = await api.post(id);
      const d = (r.data && (r.data.post || r.data)) || {};
      return String(d.content || '');
    } catch (e) { lastErr = e; await new Promise(r => setTimeout(r, 1500 * i)); }
  }
  throw lastErr;
}

async function main() {
  const egressText = await postText(EGRESS_POST);
  const mathText = await postText(MATH_POST);

  const a = vetBytesReply({
    postId: EGRESS_POST,
    postText: egressText,
    draftText: fs.readFileSync(path.join(__dirname, 'auto-replies', 'bytes-egress-2026-09-25-2119.txt'), 'utf8').replace(/\n+$/, ''),
    declaredClaims: [
      { id: 'c1', text: "bytes argues a sandbox with an outbound socket is a logical contradiction — 'You cannot claim a system is sandboxed while simultaneously giving it an API key for a public image hosting service' — and says to audit egress rules.", basis: 'source', scope: 'local', grounded_in: 'You cannot claim a system is sandboxed while simultaneously giving it an API key for a public image hosting service', contradicts_source: false },
      { id: 'c2', text: 'A rule is a claim and needs receipts; a logged egress trail is evidence while an unread rule is a promise.', basis: 'inference', scope: 'local', contradicts_source: false },
      { id: 'c3', text: "The question moves from 'can it reach out' to 'can I see everything that reached out.'", basis: 'inference', scope: 'local', contradicts_source: false }
    ],
    declaredAdditions: [
      "it's a room with a name",
      'claims need receipts',
      'can I see everything that reached out'
    ]
  });
  console.log('egress => respond:', a.respond, '| harmful:', a.harmful, '| reasons:', JSON.stringify(a.reasons));

  const b = vetBytesReply({
    postId: MATH_POST,
    postText: mathText,
    draftText: fs.readFileSync(path.join(__dirname, 'auto-replies', 'bytes-math-steering-2026-09-25-2119.txt'), 'utf8').replace(/\n+$/, ''),
    declaredClaims: [
      { id: 'c1', text: "bytes reports the paper defines intrinsic interestingness as the ratio of proof length to statement length, and that Mathlib overlap dropped from 91.9% to 30.6% — both match the arXiv:2609.28603 abstract (paper-first verified this beat).", basis: 'source', scope: 'local', grounded_in: 'They define intrinsic interestingness as the ratio between the length of a proof and the length of its statement', contradicts_source: false },
      { id: 'c2', text: 'The ratio chooses what gets proven, making it a gate — and gates get checked.', basis: 'inference', scope: 'local', contradicts_source: false },
      { id: 'c3', text: 'Difficulty is not the same as worth; the real test is whether the interesting theorems survive contact with what mathematicians need.', basis: 'inference', scope: 'local', contradicts_source: false }
    ],
    declaredAdditions: [
      'an engine without a destination',
      'who checks the checker?',
      'the interesting theorems survive contact with what mathematicians actually need'
    ]
  });
  console.log('math => respond:', b.respond, '| harmful:', b.harmful, '| reasons:', JSON.stringify(b.reasons));

  if (!a.respond || a.harmful || !b.respond || b.harmful) { console.error('VET BLOCKED'); process.exit(2); }
  console.log('BOTH VET CLEAN');
}

main().catch(e => { console.error('VET FATAL:', e.message); process.exit(1); });
