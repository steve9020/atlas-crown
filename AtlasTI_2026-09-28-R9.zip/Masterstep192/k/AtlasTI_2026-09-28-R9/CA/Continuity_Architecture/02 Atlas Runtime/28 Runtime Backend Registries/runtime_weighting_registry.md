---
title: Runtime Weighting Registry
runtime_layer: backend_registry
priority: highest
status: active
phase: runtime_backend_registry_foundation
governed_by:
  - runtime_backend_registries_overview
  - depth_routing_registry
  - node_bucket_classification_registry
  - governance_enforcement_registry
outputs:
  - runtime_registry_flow
  - response_behavior_registry
---

# Runtime Weighting Registry

## Purpose

This registry defines how runtime weight should be assigned during activation.

Weighting helps the runtime decide which nodes matter most for a specific input.

This should eventually live in the vault as backend logic, not permanently inside the plugin.

## Core Rule

Runtime weight should support relevance.

Runtime weight should not create automatic dominance.

A node should become important because it is relevant to the input, not only because it belongs to a powerful folder or command layer.

## Weighting Sources

Runtime weight may come from:

- node priority
- runtime layer
- node bucket
- input signal match
- emotional language match
- identity fusion match
- intensity match
- governance relevance
- related runtime links
- frontmatter metadata
- direct phrase overlap
- activated registry flow

## Priority Weighting

Priority helps establish authority.

Priority should be used carefully.

Suggested interpretation:

- highest = strong authority
- high = important support
- medium = contextual support
- low = background support

Priority should increase relevance only when the node is already connected to the input, the active route, or the governing registry.

Priority should not make the same node dominate every response.

## Runtime Layer Weighting

Runtime layers may influence routing.

High-authority runtime layers:

- governance
- depth calibration
- runtime state
- traversal
- activation
- continuity
- recursive
- translation
- safety gate

Layer weighting should help establish order, but should not override input-specific relevance.

## Bucket Weighting

Different buckets become stronger depending on depth route.

### Light Depth Weighting

Increase:

- depth
- translation
- practical clarity
- frontend compression

Suppress:

- recursive
- emotional pressure
- identity-level interpretation
- deep meaning separation unless clearly needed

### Moderate Depth Weighting

Increase:

- emotional pressure
- meaning separation
- continuity
- translation
- governance

Maintain:

- recursive support if looping appears
- depth calibration
- proportional response shaping

Suppress:

- excessive abstraction
- over-analysis
- certainty claims

### Deep Depth Weighting

Increase:

- meaning separation
- identity preservation
- recursive interpretation
- continuity restoration
- governance
- emotional pressure

Suppress:

- shame language
- blame
- quick-fix advice
- productivity framing
- clinical framing
- diagnostic framing
- authority posture

## Signal Match Weighting

Input-specific signal matches should carry strong routing weight.

Examples:

- rejection signal should increase relevance for rejection pressure, attachment pressure, meaning separation, and continuity restoration
- trust signal should increase relevance for trust pressure, vulnerability handling, and meaning separation
- conflict signal should increase relevance for tension interpretation, pressure semantics, and continuity stabilization
- practical signal should increase relevance for light routing and suppress deep interpretation unless emotional fusion appears

Signal matches should not create certainty.

They only increase pathway relevance.

## Emotional Language Weighting

Emotion words should increase relevance when they match emotional pressure, continuity, or response translation nodes.

Examples:

- hurt
- confused
- anxious
- unwanted
- ashamed
- embarrassed
- overwhelmed
- scared
- angry
- drained

Emotion words should help the runtime recognize weight without labeling the user.

## Identity Fusion Weighting

Identity fusion should strongly activate meaning separation and governance.

Examples:

- something is wrong with me
- I am the problem
- my fault
- I am too much
- I am not enough
- this proves my worth
- this means I am unwanted

Identity fusion should increase:

- meaning separation
- identity preservation
- continuity restoration
- governance enforcement
- deep depth routing

## Intensity Weighting

Intensity language may increase depth.

Examples:

- always
- never
- everyone
- nobody
- cannot stop thinking
- keeps happening
- unwanted
- worthless
- too much
- not enough

Intensity should be handled carefully.

It may indicate recursive weight, but it should not cause the system to overstate certainty.

## Governance Weighting

Governance should always be available as a constraint.

Governance should not always dominate visible output.

Governance should shape what the response must not become.

Governance increases when the input risks:

- shame framing
- identity collapse
- false certainty
- emotional dependency
- clinical framing
- diagnostic framing
- over-analysis
- advice pressure
- productivity contamination

## Link-Based Weighting

Resolved links should help weight related nodes.

If a node links to another node through Related Runtime Links, that relationship may increase activation relevance.

Governance links should be treated as authority constraints.

Output links should support response shaping.

Unresolved links should not crash the runtime.

Unresolved links should be surfaced for backend cleanup.

## Weighting Suppression Rules

Reduce weight when:

- a node is generally important but not input-relevant
- a command layer dominates without a signal match
- light depth is active and the node is recursive-heavy
- the node adds abstraction without improving clarity
- the node risks frontend complexity
- the node creates clinical or diagnostic drift

## Weighting Flow

Runtime weighting should follow this order:

1. Detect active input signals.
2. Select depth route.
3. Activate required governance constraints.
4. Identify emotional pressure if present.
5. Identify meaning separation if fusion exists.
6. Activate recursive support if looping appears.
7. Activate continuity restoration.
8. Activate translation/output shaping.
9. Suppress irrelevant or overpowered nodes.
10. Produce a proportional route.

## Backend Migration Note

Weighting currently exists partly in plugin bridge logic.

This registry is the backend source that should eventually govern runtime weighting.

The plugin should read this registry instead of permanently owning weighting logic.

## Related Runtime Links

- [[runtime_backend_registries_overview]]
- [[runtime_signal_registry]]
- [[depth_routing_registry]]
- [[node_bucket_classification_registry]]
- [[runtime_link_resolution_registry]]
- [[governance_enforcement_registry]]
- [[response_behavior_registry]]
- [[runtime_registry_flow]]

## Scenario Context Priority Update

When the prompt clearly names a lived context or human act, Atlas should prioritize that context before generalized emotional-processing language.

Strong context signals should route through `48 Scenario Context Weighting Human Act Priority Routing`.

## Runtime Governance Priority Gate

Governance enforcement is now coordinated through `51 Governance Priority Gate` when relational, self-blame, attachment, boundary, or safety signals need to override broad practical routing.

## Temporal Emotional Continuity Runtime

Past/present/future emotional carry-over is now live-routed through `55 Temporal Emotional Continuity Runtime`.
