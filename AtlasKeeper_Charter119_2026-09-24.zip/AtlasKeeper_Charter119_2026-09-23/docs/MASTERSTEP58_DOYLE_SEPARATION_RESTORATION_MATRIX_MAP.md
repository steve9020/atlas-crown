# Masterstep58 — Doyle Spire + Separation/Restoration Matrix Alignment Map

## Purpose
Align the backend relational core after factual parsing and axis scoring:

- Doyle Spire relational lookup
- active vs unverified attachment split
- context-locked separation target selection
- wedge-locked restoration gateway selection

## Boundary
All intelligence remains backend-owned. The frontend is not allowed to contain Doyle logic, relational attachments, separation selectors, restoration selectors, scoring, routing, validation, Teaching Center logic, or Compass generation.

## Core Rule
The highest axis score may propose a candidate, but it cannot force the final route. The final separation wedge requires intersection between:

1. factual anchor type
2. quarantined unverified attachment
3. candidate axis or verified secondary scan

## Reverse-Flow Rule
The restoration gateway must be selected from the locked separation wedge. Generic comfort is not accepted as restoration. Each wedge maps to a specific positive/restorative posture such as grounded belonging, immediate agency, clean responsibility, workable movement, steadiness, grounded choice, continuity, dignity, positive preservation, courage, or distance detachment.
