# Natural Response Structure Variation Registry

```json
{
  "registry_id": "natural_response_structure_variation",
  "master_step": "5C",
  "title": "Natural Response Structure Variation",
  "status": "active",
  "purpose": "Preserve consistent internal restorative movement while preventing visible fixed response templates from leaking into Compass output.",
  "core_rules": [
    "Visible response structure should remain fluid and natural.",
    "See / Separate / Restore may guide internally but should not appear as fixed labels in ordinary Compass output.",
    "Paragraph shape may vary according to emotional and contextual complexity.",
    "Natural variation must not remove the underlying restorative movement.",
    "Repeated visible templates are treated as potential machinery-pattern leakage."
  ],
  "forbidden_output_patterns": [
    "See:",
    "Separate:",
    "Restore:",
    "Step one / Step two / Step three",
    "mechanism labels",
    "axis labels",
    "fixed visible template repetition"
  ],
  "required_output_mode": "fluid_human_language_with_consistent_internal_restorative_movement",
  "carry_forward": [
    "Cognition/response/NaturalResponseStructureVariation.js",
    "tests/naturalResponseStructureVariationTest.js",
    "pipeline output key: natural_response_structure_variation"
  ]
}
```
