---
runtime_layer: atlas_layer_index
priority: index
---

# 03 Atlas Semantic Ontology

This folder groups related Atlas backend files for safer human navigation. Runtime authority is controlled by backend metadata, governance maps, and runtime execution order, not by folder position alone.
