---
runtime_layer: teaching_gap_detection
priority: high
owned_by: atlas_teaching_learning
runs_after:
  - response_weakness_detection
runs_before:
  - auto_teaching_proposal_creation
feeds_into:
  - atlas_proposal_review_implementation_overview
---

# Teaching Gap Detection Runtime Overview

## Purpose
Converts detected response weaknesses into missing backend knowledge, rules, or runtime priorities that can be reviewed through Auto Teach.

## Core question
What does Atlas need to understand, route, translate, or prioritize differently so this weakness is less likely next time?

## Gap examples
- missing relational silence / read-no-response route
- missing assumption-before-clarification rule
- missing over-fixing impulse detection
- missing protective withdrawal detection
- missing card priority rule
- missing soft frontend translation rule
- missing route comparison rule
- missing punctuation or capitalization cleanup rule

## Boundary
Teaching Gap Detection creates proposal-ready learning. It does not silently mutate durable backend files.
