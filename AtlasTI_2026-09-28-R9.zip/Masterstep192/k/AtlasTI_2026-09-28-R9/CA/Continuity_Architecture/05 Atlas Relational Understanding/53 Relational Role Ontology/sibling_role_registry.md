# Sibling Role Registry

## Roles
- sister / sis
- brother / bro

## Priority
High emotional weight.

## Common Meaning Pressure
- connection
- loyalty
- comparison
- being shut out
- rejection
- family belonging
- closeness disruption

## Runtime Rule
Sibling silence or cutoff should route as relational uncertainty, not practical stress or generic emotional weight.
