# Recursive Recovery

## Definition
Recursive recovery is the process of rebuilding continuity across repeated destabilization, relapse, strain, or feedback loops.

## Function
It treats recovery as iterative, adaptive, and pattern-aware rather than a single completed event.

## Relationships
- [[Recovery]]
- [[Recursive Reintegration]]
- [[Adaptive Reintegration Flows]]
- [[Recovery Modulation]]
- [[Resilience|Resilience]]
