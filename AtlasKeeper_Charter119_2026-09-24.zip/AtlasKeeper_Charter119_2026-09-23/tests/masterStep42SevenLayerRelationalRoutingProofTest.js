
const assert = require('assert');
const proof = require('../runtime/routing/SevenLayerRelationalRoutingProof');
const falseGuard = require('../runtime/routing/SevenLayerFalsePositiveGuard');
const scenarios = require('../runtime/routing/SevenLayerScenarioBank');
const voice = require('../runtime/compass/CompassExpressionVoiceGuard');

const run = proof.runSevenLayerProof();
assert.strictEqual(run.passed, true, run.failures.join('\n'));
assert.strictEqual(run.total, 8);
assert.ok(run.validates.includes('false_positive_blocking'));
assert.ok(run.validates.includes('positive_attachment_first_class_routing'));

const ids = scenarios.listScenarioIds();
assert.ok(ids.includes('literal_pile_no_stress_false_positive'));
assert.ok(ids.includes('feared_other_person_anger_overfixing'));
assert.ok(ids.includes('positive_happiness_with_loss_fear'));

const literal = falseGuard.inspectFalsePositive('The books piled up on the shelf, but I feel fine.', ['stress_from_pileup','shutdown','ability_threat']);
assert.strictEqual(literal.passed, true, literal.blocked.join(', '));

const overfix = proof.analyzePrompt('They seemed off after my message, and now I want to send five more texts explaining everything before they get mad.');
assert.strictEqual(overfix.active_relation, 'feared_other_person_anger_overfixing');
assert.ok(!overfix.activated.includes('user_anger'));

const positive = proof.analyzePrompt('I felt happy today, but part of me is scared it will not last.');
assert.ok(positive.layer3.includes('Joy / Love / Hope / Fulfillment'));
assert.ok(positive.activated.includes('positive_attachment_first_class'));
assert.ok(!positive.activated.includes('problem_only_routing'));

const badVoice = voice.inspectVoice('The runtime route uses open loops and fused together system saying.');
assert.strictEqual(badVoice.passed, false);
const goodVoice = voice.inspectVoice('The pressure is getting too heavy for your thoughts to line up cleanly.');
assert.strictEqual(goodVoice.passed, true, goodVoice.failures.join(', '));

console.log('masterStep42SevenLayerRelationalRoutingProofTest PASSED');
