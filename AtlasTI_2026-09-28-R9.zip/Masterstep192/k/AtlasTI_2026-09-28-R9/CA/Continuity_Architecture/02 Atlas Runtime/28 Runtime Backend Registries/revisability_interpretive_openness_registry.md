# Revisability & Interpretive Openness Registry

Purpose: Master Step 4F source of truth for preventing permanent interpretive closure. Atlas may weight meaning by context, but interpretations remain revisable if future context changes the structure.

Boundary: this registry does not make final truth claims, does not diagnose, does not perform speech polish, and does not close meaning on behalf of the user. It governs confidence weighting, future-context reweighting, and anti-overcertainty behavior.

Core principle: no permanent interpretive closure; only context-supported confidence levels.

```json
{
  "version": "MASTER_STEP_4F_REVISABILITY_INTERPRETIVE_OPENNESS_V1",
  "guardrails": [
    "no_permanent_interpretive_closure",
    "confidence_weighting_not_truth_sealing",
    "future_context_can_reweight_prior_meaning",
    "artificial_certainty_closure_blocked",
    "interpretive_openness_preserved",
    "user_understanding_remains_authoritative",
    "fusion_interpretation_without_fusion_output"
  ],
  "rules": [
    {
      "id": "later_context_reweighting_guard",
      "priority": 10,
      "allGroups": [
        { "phrases": ["later", "then", "after that", "but then", "i found out", "turns out"] },
        { "phrases": ["because", "grieving", "busy", "scared", "overwhelmed", "misunderstood", "didn't know"] }
      ],
      "revisabilitySignals": [
        "new_context_changes_prior_weight",
        "earlier_interpretation_requires_reweighting"
      ],
      "closureRiskSignals": [
        "prior_meaning_could_have_been_closed_too_early"
      ],
      "confidenceMoves": [
        "lower_prior_certainty_when_new_context_arrives",
        "increase_contextual_weight_without_final_truth_claim"
      ],
      "reweightingMoves": [
        "allow_future_context_to_reshape_meaning",
        "preserve_context_revision_path"
      ],
      "opennessMoves": [
        "hold_previous_interpretation_as_revisable",
        "do_not_lock_first_read"
      ],
      "forbiddenMoves": [
        "declare_first_interpretation_final",
        "ignore_new_context"
      ],
      "governanceMoves": [
        "reweight_with_new_context",
        "preserve_interpretive_openness"
      ]
    },
    {
      "id": "certainty_language_revisability_guard",
      "priority": 20,
      "phrases": [
        "i know", "i'm sure", "i am sure", "there is no other explanation", "obviously", "definitely", "always", "never"
      ],
      "revisabilitySignals": [
        "strong_certainty_language_detected",
        "certainty_requires_context_weighting"
      ],
      "closureRiskSignals": [
        "emotional_certainty_may_be_treated_as_final_truth"
      ],
      "confidenceMoves": [
        "separate_certainty_intensity_from_verified_closure",
        "hold_as_weighted_interpretation_not_final_fact"
      ],
      "reweightingMoves": [
        "permit_later_context_to_adjust_certainty",
        "keep_confidence_level_revisable"
      ],
      "opennessMoves": [
        "do_not_seal_meaning_from_certainty_language_alone"
      ],
      "forbiddenMoves": [
        "treat_emotional_certainty_as_verified_truth",
        "finalize_from_intensity_only"
      ],
      "governanceMoves": [
        "block_certainty_to_closure_conversion",
        "preserve_confidence_weighting"
      ]
    },
    {
      "id": "relationship_motive_open_guard",
      "priority": 30,
      "allGroups": [
        { "phrases": ["they", "she", "he", "my friend", "my partner", "my mom", "my dad", "my sister", "my brother"] },
        { "phrases": ["ignored", "distant", "cold", "short", "quiet", "didn't respond", "left me on read"] }
      ],
      "revisabilitySignals": [
        "relational_motive_not_fully_known",
        "relational_context_requires_openness"
      ],
      "closureRiskSignals": [
        "motive_closure_risk",
        "rejection_conclusion_risk"
      ],
      "confidenceMoves": [
        "weight_observable_behavior_without_finalizing_motive",
        "separate_distance_signal_from_motive_truth"
      ],
      "reweightingMoves": [
        "allow_followup_context_to_narrow_motive",
        "preserve_relational_revision_path"
      ],
      "opennessMoves": [
        "hold_multiple_relational_meanings_open",
        "avoid_filling_motive_gap"
      ],
      "forbiddenMoves": [
        "declare_their_motive_final",
        "close_relational_meaning_without_context"
      ],
      "governanceMoves": [
        "keep_motive_revisable",
        "avoid_relational_false_closure"
      ]
    },
    {
      "id": "neutral_operational_no_activation_guard",
      "priority": 90,
      "phrases": [
        "vault opened", "test passed", "package saved", "folder exists", "downloaded the zip", "plugin opened"
      ],
      "revisabilitySignals": [],
      "closureRiskSignals": [],
      "confidenceMoves": [],
      "reweightingMoves": [],
      "opennessMoves": [],
      "forbiddenMoves": [],
      "governanceMoves": []
    }
  ]
}
```
