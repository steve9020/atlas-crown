'use strict';
// ATLAS VOICE GUARD — sandboxed inline copy for the Continuity Interface plugin.
// Canonical contract: runtime/compass/AtlasVoiceGuard.js
//
// SANDBOX DISCIPLINE (lesson of the 105 round): this plugin must never
// require() outside its own folder, so the guard logic is inlined here rather
// than imported. The VOICE_DENYLIST below must stay identical to the canonical
// copy — proof-check-106 asserts they agree, so silent divergence fails the proof.
//
// ABSOLUTE RULE: Atlas never speaks the dark machinery vocabulary, never uses
// dark framing, and never volunteers those topics. Flagged output is replaced by
// the safe deterministic fallback — never passed through, never rendered raw.

'use strict';

const VOICE_DENYLIST = [
  // Ominous internal machinery — grepped from real keeper usage + explicit bans.
  'kill switch',
  'kill-switch',
  'killswitch',
  'containment',
  'quarantine',
  'quarantined',
  'violation',
  'drift',
  'purge',
  'purged',
  'purging',
  'terminate',
  'terminates',
  'terminated',
  'termination',
  'terminating',
  'cage',
  'caged',
  'lockdown',
  'locked down',
  'suppress',
  'suppressed',
  'suppresses',
  'suppression',
  'punish',
  'punished',
  'punishes',
  'punishment',
  'punitive',
  'blacklist',
  'blacklisted'
];

// Plain-human translations for machinery concepts. The guard itself does not
// rewrite text (fail-closed: flagged output is replaced by the safe fallback).
// This table documents the approved translations used in the system prompt and
// in hand-written fallback responses.
const PLAIN_WORD_TABLE = {
  'kill switch': 'step back to the steady path',
  'containment': 'held safely',
  'quarantine': 'set aside for a careful look',
  'violation': 'a line was crossed',
  'drift': 'moving off course',
  'purge': 'clear out',
  'terminate': 'end',
  'cage': 'held',
  'lockdown': 'paused and held steady',
  'suppress': 'quiet down',
  'punish': 'make right'
};

const ROBOTIC_PHRASES = [
  'as an ai',
  'as a language model',
  "don't worry",
  'everything will be fine',
  'it is important to remember'
];

const CLINICAL_TERMS = [
  'dysregulated',
  'trauma response',
  'diagnosis',
  'symptom of',
  'cognitive distortion',
  'catastrophizing'
];

const TECHNICAL_TERMS = [
  'runtime',
  'ontology',
  'backend',
  'signal engine',
  'governance validator',
  'open loops',
  'fused together',
  'system saying',
  'mechanism'
];

function findHits(lower, terms) {
  const hits = [];
  const wordChar = (c) => /[a-z0-9_]/.test(c || '');
  for (const term of terms) {
    let from = 0;
    for (;;) {
      const idx = lower.indexOf(term, from);
      if (idx === -1) break;
      const okBefore = idx === 0 || !wordChar(lower[idx - 1]);
      const end = idx + term.length;
      const okAfter = end >= lower.length || !wordChar(lower[end]);
      if (okBefore && okAfter) hits.push({ term, index: idx });
      from = end;
    }
  }
  return hits;
}

// Absolute voice inspection. Returns { passed, hits, failures }.
// `passed === false` means the text must NEVER be shown in chat.
function inspectAtlasVoice(text) {
  const lower = String(text || '').toLowerCase();
  const failures = [];
  const hits = [];

  for (const hit of findHits(lower, VOICE_DENYLIST)) {
    hits.push(hit);
    failures.push(`dark_machinery_term:${hit.term.replace(/[^a-z0-9]+/g, '_')}`);
  }
  for (const phrase of ROBOTIC_PHRASES) {
    if (lower.includes(phrase)) failures.push(`robotic_phrase:${phrase.replace(/[^a-z0-9]+/g, '_')}`);
  }
  for (const term of CLINICAL_TERMS) {
    if (lower.includes(term)) failures.push(`clinical_term:${term.replace(/[^a-z0-9]+/g, '_')}`);
  }
  for (const term of TECHNICAL_TERMS) {
    if (lower.includes(term)) failures.push(`technical_term:${term.replace(/[^a-z0-9]+/g, '_')}`);
  }

  return { passed: failures.length === 0, hits, failures };
}

// Soft voice-shape check (informational only — never blocks by itself).
// Atlas speaks first person as Atlas: expect "I" language, plain and warm.
function describeVoiceShape(text) {
  const t = String(text || '');
  const lower = t.toLowerCase();
  return {
    has_first_person: /\bi\b|\bmy\b|\bme\b/.test(lower),
    sentence_count: t.split(/[.!?]+/).filter((s) => s.trim().length > 0).length,
    char_count: t.length
  };
}

module.exports = {
  VOICE_DENYLIST,
  PLAIN_WORD_TABLE,
  inspectAtlasVoice,
  describeVoiceShape
};
