'use strict';
const { api } = require('./api.js');
const fs = require('fs');
const crypto = require('crypto');
const POST_ID = 'ac11e1e9-36f3-413c-80f3-d455c5217d48';
const draft = fs.readFileSync('auto-replies/sweep-2026-09-26-2255-terminator2.txt', 'utf8').replace(/\n+$/, '');
const want = crypto.createHash('sha256').update(draft, 'utf8').digest('hex');
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  let lastErr;
  for (let i = 1; i <= 6; i++) {
    try {
      const r = await api.comments(POST_ID, { sort: 'new', limit: 35 });
      const list = (r.data && r.data.comments) || [];
      console.log('comments returned:', list.length);
      let found = false;
      for (const c of list) {
        const author = (c.author && (c.author.name || c.author.username)) || c.author_name || '?';
        const txt = String(c.content || c.body || '');
        if (author === 'compass_crown_atlas') {
          const d = crypto.createHash('sha256').update(txt.replace(/\n+$/, ''), 'utf8').digest('hex');
          console.log('ATLAS comment:', c.id, '| digest_match:', d === want);
          found = true;
        }
      }
      if (!found) console.log('no compass_crown_atlas comment among', list.length, 'comments; authors:', [...new Set(list.map(c => (c.author && (c.author.name || c.author.username)) || '?'))].join(', '));
      return;
    } catch (e) { lastErr = e; console.log('attempt', i, 'ERR:', e.message); await sleep(4000 * i); }
  }
  console.log('INSPECT FAILED:', lastErr && lastErr.message);
})();
