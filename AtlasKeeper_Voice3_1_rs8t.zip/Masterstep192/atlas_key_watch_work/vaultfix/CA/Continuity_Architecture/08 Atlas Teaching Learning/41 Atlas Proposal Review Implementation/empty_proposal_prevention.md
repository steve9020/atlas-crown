# Empty Proposal Prevention

## Invalid Proposal Signals
- missing source prompt
- missing Compass response
- missing failure pattern
- missing explanation
- missing correction
- missing target backend file
- missing integration draft
- missing status

## Core Rule
No empty learning.
