---
title: Emotional Guarding
runtime_layer: emotional_pressure
priority: medium
status: active
phase: runtime_link_cleanup
governed_by:
  - emotional_continuity_governance
  - governance_enforcement_registry
outputs:
  - Defensive Withdrawal
  - trust_collapse
---

# Emotional Guarding

## Purpose

Defines a protective emotional closing that can appear after pressure, mistrust, ridicule, or repeated relational uncertainty.

## Core Function

The runtime should frame guarding as a protective pattern without shaming it, pathologizing it, or treating it as the user’s identity.

## Runtime Boundary

This node exists because existing backend links already reference this concept. It should clarify the referenced pathway without creating duplicate ontology or changing Compass into a clinical, diagnostic, authoritative, or productivity-driven system.

## Related Runtime Links

- [[Defensive Withdrawal]]
- [[trust_collapse]]
- [[emotional_continuity_governance]]
- [[response_behavior_registry]]
