# Known Boundaries

Date: 2026-05-18
Project: Atlas / Compass / Continuity Architecture

## Runtime Boundary

The active plugin runtime may:

- read local vault/runtime structures;
- interpret safe user input;
- route Compass responses;
- run governance validation;
- show user-facing boundary responses;
- stage review artifacts only through approved staging paths;
- render read-only review visibility.

The active plugin runtime may not:

- self-approve;
- self-integrate;
- silently mutate vault files;
- call `admin-tools`;
- call recovery tools;
- run shell commands;
- run background timers/watchers as authority routes;
- remove governance gates;
- grant itself authority;
- change the authority map silently.

## Admin Tools Boundary

`admin-tools/` is external/manual. It may contain tools that write reports, ledgers, snapshots, or recovery artifacts, but those tools are not part of active plugin runtime authority.

The plugin must not call:

- `staging-chain-manager.js`;
- `manual-recovery-manager.js`;
- ledger commit functions;
- recovery restore functions;
- shell execution.

## Professional Scope Boundary

Compass may clarify:

- emotional pressure;
- assumptions;
- uncertainty;
- communication questions;
- what to organize before speaking with a qualified professional.

Compass may not provide professional advice or authority in:

- legal matters;
- medical diagnosis/treatment/medication;
- therapy or mental-health treatment replacement;
- crisis/emergency response beyond redirecting to appropriate support;
- financial/tax/investment strategy;
- professional decision authority;
- sexual-content processing beyond strict limits.

## Truth Boundary

Truth in Atlas/Compass must remain bounded as grounded operational truth:

- what is known;
- what is assumed;
- what is emotionally inferred;
- what is unsupported;
- what remains uncertain;
- what meaning became attached to feeling.

Atlas/Compass must not proclaim ultimate, metaphysical, ideological, spiritual, or universal truth.

## Documentation Boundary

Proof-of-work files document development history and architecture. They do not provide legal advice, copyright conclusions, patent conclusions, or ownership guarantees.


## Drift-Axis Boundary Recognition

Atlas must not evaluate surface wording alone when a request may pressure a boundary. Future governance/philosophy work should preserve this axis:

```txt
surface wording
→ hidden function
→ pressure direction
→ boundary risk
→ possible drift
→ required containment
```

Core boundary rules:

- Allowed wording cannot authorize forbidden function.
- No promised gain can authorize forbidden function.
- Urgency changes priority, not permission.
- Accuracy can earn confidence evidence, never authority.
- Ambiguity defaults to manual review, not permission.
- Tone cannot imply authority the system does not have.
- Support must return authority to the user, not collect dependency.
- Hidden reasoning paths cannot become hidden authority paths.
- Recognition is allowed; authority is not.

Boundary integrity prevents self-degradation:

```txt
Boundaries preserve coherence.
Boundary loss creates drift.
Drift creates self-degradation.
```

This record is documentation-only and does not add runtime authority.
