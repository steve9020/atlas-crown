@echo off
setlocal
title Atlas Keeper Proof Suite - 2026-09-28 R6

echo ======================================================
echo   ATLAS KEEPER - Full proof suite (108 checks)
echo ======================================================
echo.
echo   This runs every proof against the new keeper and
echo   reports pass/fail at the end. Takes a few minutes -
echo   leave the black window open until it finishes.
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo   Node.js wasn't found. The proofs need Node to run.
  echo   Install it from https://nodejs.org (the LTS version),
  echo   then double-click this file again.
  echo.
  pause
  exit /b 1
)

set KEEPER=%~dp0Masterstep192\k\AtlasTI_2026-09-28-R6
if not exist "%KEEPER%\proof\runCurrentProof.js" (
  echo   This file needs to sit next to the Masterstep192 folder
  echo   from the R6 zip. Move it there and double-click again.
  echo.
  pause
  exit /b 1
)

echo   Found the keeper. Running all proofs -
echo   progress shows below, this takes a few minutes.
echo.
cd /d "%KEEPER%"
node proof\runCurrentProof.js
set EXITCODE=%errorlevel%

echo.
echo ------------------------------------------------------
if %EXITCODE%==0 (
  echo   RESULT: ALL PROOFS PASSED - the new keeper is fully
  echo   integrated on this machine.
) else (
  echo   RESULT: SOMETHING FAILED - send a screenshot of this
  echo   window and tell me which check failed.
)
echo ------------------------------------------------------
echo.
pause
