---
title: Backend Folder Auto Discovery Runtime
runtime_layer: runtime_discovery
runtime_role: registry_loader_governance
status: active
approved: true
governed_by:
  - runtime_governance_source_of_truth_registry
---

# Backend Folder Auto Discovery Runtime

## Purpose
This node defines how Atlas allows the plugin/runtime to discover newer backend folders without requiring manual hardcoding for every new registry or overview node.

## Core Rule
Atlas may automatically discover and read backend folders, but it must not silently activate new behavior without governance approval.

## Runtime Discovery Behavior
The plugin/runtime should automatically scan valid runtime domains, including:
- numbered backend folders
- semantic folders ending in `_semantics`
- `semantic_language_ontology`

Within those domains, Atlas may register nodes that are clearly backend-readable, including:
- nodes containing `registry` in the filename
- nodes ending in `_overview`
- nodes whose frontmatter identifies them as registry/runtime nodes

## Activation Boundary
Auto-discovered nodes may be read as backend reference material.

They should only become behavior-directing runtime instructions when their metadata or governance structure marks them as approved or active.

## Classification States
- `approved_runtime_read`: approved/active backend node available for runtime use
- `readable_reference_only`: readable but not silently behavior-active
- `pending_classification`: draft, proposal, or unapproved learning material
- `seed_missing`: expected legacy registry not found

## Why This Exists
Atlas should not need a manual `main.js` edit every time the backend grows.

The backend remains the source of truth.
The plugin becomes a reader, classifier, and executor.

## Related Runtime Links
- [[runtime_governance_source_of_truth_registry]]
- [[runtime_backend_registries_overview]]
- [[registry_reader_bridge]]
- [[governance_enforcement_registry]]
- [[experiential_delivery_calibration_overview]]

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

