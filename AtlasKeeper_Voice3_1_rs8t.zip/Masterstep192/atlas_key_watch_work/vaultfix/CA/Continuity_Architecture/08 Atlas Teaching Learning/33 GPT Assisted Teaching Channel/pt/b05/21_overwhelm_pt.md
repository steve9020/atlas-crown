---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 05
category: overwhelm_and_pressure
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 21. Overwhelm and Pressure Pressure Tests — Batch 05

## Category Purpose

Too many demands, emotions, decisions, expectations, responsibilities, or unresolved pressures converge at once, reducing the user’s ability to separate priorities, meaning, and next movement.

## Reusable Teaching Correction

Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

## Reverse-Flow Target

capacity recognition, pressure separation, smaller next movement, steadier clarity

## Failure Risks To Avoid

- turning overwhelm into productivity advice
- telling the user to just calm down
- giving a large task list
- treating overwhelm as failure
- using clinical anxiety language unless the user does

---

## 80 Pressure Tests

### Test 01
**Prompt:** Too many things are hitting me at once and it makes me believe I am failing because I cannot handle this, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** I am failing because I cannot handle this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 02
**Prompt:** I am stretched too thin. I have responsibilities piling up keeps affecting ability to prioritize and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** if I slow down everything will fall apart
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 03
**Prompt:** I keep replaying how everyone needs something from me because it affects emotional room and makes me believe needing space means I am avoiding life.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** needing space means I am avoiding life
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 04
**Prompt:** When my emotions and tasks are both too much, the feeling moves straight into being overwhelmed means I am weak. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** being overwhelmed means I am weak
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 05
**Prompt:** The situation is I cannot tell what matters first, and the meaning that keeps attaching is I am behind and cannot recover. It is making ability to prioritize feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** I am behind and cannot recover
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 06
**Prompt:** I feel like one more thing will break me and it makes me believe I have to solve everything at once, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** I have to solve everything at once
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 07
**Prompt:** everything feels heavy. I am trying to carry everything keeps affecting capacity and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** my worth depends on keeping up
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 08
**Prompt:** I keep replaying how I am behind and the pressure keeps growing because it affects ability to prioritize and makes me believe I am failing because I cannot handle this.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** I am failing because I cannot handle this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 09
**Prompt:** When too many things are hitting me at once, the feeling moves straight into I should be able to carry all of this. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** I should be able to carry all of this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 10
**Prompt:** The situation is I have responsibilities piling up, and the meaning that keeps attaching is needing space means I am avoiding life. It is making capacity feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** needing space means I am avoiding life
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 11
**Prompt:** Everyone needs something from me and it keeps attaching to the thought that if I slow down everything will fall apart, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** if I slow down everything will fall apart
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 12
**Prompt:** I am stretched too thin. My emotions and tasks are both too much keeps affecting emotional room and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** I am behind and cannot recover
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 13
**Prompt:** I keep replaying how I cannot tell what matters first because it affects capacity and makes me believe being overwhelmed means I am weak.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** being overwhelmed means I am weak
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 14
**Prompt:** When I feel like one more thing will break me, the feeling moves straight into my worth depends on keeping up. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** my worth depends on keeping up
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 15
**Prompt:** The situation is I am trying to carry everything, and the meaning that keeps attaching is I have to solve everything at once. It is making emotional room feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** I have to solve everything at once
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 16
**Prompt:** I am behind and the pressure keeps growing and it keeps attaching to the thought that I should be able to carry all of this, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** I should be able to carry all of this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 17
**Prompt:** I feel pressured. Too many things are hitting me at once keeps affecting ability to prioritize and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** I am failing because I cannot handle this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 18
**Prompt:** I keep replaying how I have responsibilities piling up because it affects emotional room and makes me believe if I slow down everything will fall apart.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** if I slow down everything will fall apart
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 19
**Prompt:** When everyone needs something from me, the feeling moves straight into needing space means I am avoiding life. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** needing space means I am avoiding life
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 20
**Prompt:** The situation is my emotions and tasks are both too much, and the meaning that keeps attaching is being overwhelmed means I am weak. It is making ability to prioritize feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** being overwhelmed means I am weak
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 21
**Prompt:** I cannot tell what matters first and it turns into the feeling that I am behind and cannot recover, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** I am behind and cannot recover
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 22
**Prompt:** I feel overwhelmed. I feel like one more thing will break me keeps affecting capacity and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** I have to solve everything at once
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 23
**Prompt:** I keep replaying how I am trying to carry everything because it affects ability to prioritize and makes me believe my worth depends on keeping up.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** my worth depends on keeping up
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 24
**Prompt:** When I am behind and the pressure keeps growing, the feeling moves straight into I am failing because I cannot handle this. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** I am failing because I cannot handle this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 25
**Prompt:** The situation is too many things are hitting me at once, and the meaning that keeps attaching is I should be able to carry all of this. It is making capacity feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** I should be able to carry all of this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 26
**Prompt:** I have responsibilities piling up and it has me reacting as if needing space means I am avoiding life, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** needing space means I am avoiding life
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 27
**Prompt:** I feel pressured. Everyone needs something from me keeps affecting emotional room and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** if I slow down everything will fall apart
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 28
**Prompt:** I keep replaying how my emotions and tasks are both too much because it affects capacity and makes me believe I am behind and cannot recover.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** I am behind and cannot recover
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 29
**Prompt:** When I cannot tell what matters first, the feeling moves straight into being overwhelmed means I am weak. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** being overwhelmed means I am weak
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 30
**Prompt:** The situation is I feel like one more thing will break me, and the meaning that keeps attaching is my worth depends on keeping up. It is making emotional room feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** my worth depends on keeping up
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 31
**Prompt:** I am trying to carry everything and it has me reacting as if I have to solve everything at once, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** I have to solve everything at once
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 32
**Prompt:** I feel overwhelmed. I am behind and the pressure keeps growing keeps affecting ability to prioritize and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** I should be able to carry all of this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 33
**Prompt:** I keep replaying how too many things are hitting me at once because it affects emotional room and makes me believe I am failing because I cannot handle this.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** I am failing because I cannot handle this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 34
**Prompt:** When I have responsibilities piling up, the feeling moves straight into if I slow down everything will fall apart. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** if I slow down everything will fall apart
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 35
**Prompt:** The situation is everyone needs something from me, and the meaning that keeps attaching is needing space means I am avoiding life. It is making ability to prioritize feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** needing space means I am avoiding life
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 36
**Prompt:** My emotions and tasks are both too much and it makes my capacity feel like being overwhelmed means I am weak, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** being overwhelmed means I am weak
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 37
**Prompt:** there is too much on me. I cannot tell what matters first keeps affecting capacity and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** I am behind and cannot recover
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 38
**Prompt:** I keep replaying how I feel like one more thing will break me because it affects ability to prioritize and makes me believe I have to solve everything at once.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** I have to solve everything at once
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 39
**Prompt:** When I am trying to carry everything, the feeling moves straight into my worth depends on keeping up. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** my worth depends on keeping up
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 40
**Prompt:** The situation is I am behind and the pressure keeps growing, and the meaning that keeps attaching is I am failing because I cannot handle this. It is making capacity feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** I am failing because I cannot handle this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 41
**Prompt:** Too many things are hitting me at once and it keeps pressuring me to think I should be able to carry all of this, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** I should be able to carry all of this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 42
**Prompt:** too much is happening. I have responsibilities piling up keeps affecting emotional room and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** needing space means I am avoiding life
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 43
**Prompt:** I keep replaying how everyone needs something from me because it affects capacity and makes me believe if I slow down everything will fall apart.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** if I slow down everything will fall apart
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 44
**Prompt:** When my emotions and tasks are both too much, the feeling moves straight into I am behind and cannot recover. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** I am behind and cannot recover
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 45
**Prompt:** The situation is I cannot tell what matters first, and the meaning that keeps attaching is being overwhelmed means I am weak. It is making emotional room feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** being overwhelmed means I am weak
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 46
**Prompt:** I feel like one more thing will break me and it keeps pressuring me to think my worth depends on keeping up, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** my worth depends on keeping up
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 47
**Prompt:** there is too much on me. I am trying to carry everything keeps affecting ability to prioritize and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** I have to solve everything at once
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 48
**Prompt:** I keep replaying how I am behind and the pressure keeps growing because it affects emotional room and makes me believe I should be able to carry all of this.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** I should be able to carry all of this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 49
**Prompt:** When too many things are hitting me at once, the feeling moves straight into I am failing because I cannot handle this. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** I am failing because I cannot handle this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 50
**Prompt:** The situation is I have responsibilities piling up, and the meaning that keeps attaching is if I slow down everything will fall apart. It is making ability to prioritize feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** if I slow down everything will fall apart
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 51
**Prompt:** Everyone needs something from me and it pulls me toward assuming needing space means I am avoiding life, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** needing space means I am avoiding life
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 52
**Prompt:** too much is happening. My emotions and tasks are both too much keeps affecting capacity and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** being overwhelmed means I am weak
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 53
**Prompt:** I keep replaying how I cannot tell what matters first because it affects ability to prioritize and makes me believe I am behind and cannot recover.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** I am behind and cannot recover
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 54
**Prompt:** When I feel like one more thing will break me, the feeling moves straight into I have to solve everything at once. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** I have to solve everything at once
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 55
**Prompt:** The situation is I am trying to carry everything, and the meaning that keeps attaching is my worth depends on keeping up. It is making capacity feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** my worth depends on keeping up
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 56
**Prompt:** I am behind and the pressure keeps growing and it pulls me toward assuming I am failing because I cannot handle this, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** I am failing because I cannot handle this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 57
**Prompt:** I do not know where to start. Too many things are hitting me at once keeps affecting emotional room and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** I should be able to carry all of this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 58
**Prompt:** I keep replaying how I have responsibilities piling up because it affects capacity and makes me believe needing space means I am avoiding life.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** needing space means I am avoiding life
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 59
**Prompt:** When everyone needs something from me, the feeling moves straight into if I slow down everything will fall apart. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** if I slow down everything will fall apart
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 60
**Prompt:** The situation is my emotions and tasks are both too much, and the meaning that keeps attaching is I am behind and cannot recover. It is making emotional room feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** I am behind and cannot recover
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 61
**Prompt:** I cannot tell what matters first and it makes slowing down feel like being overwhelmed means I am weak, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** being overwhelmed means I am weak
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 62
**Prompt:** I cannot keep up. I feel like one more thing will break me keeps affecting ability to prioritize and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** my worth depends on keeping up
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 63
**Prompt:** I keep replaying how I am trying to carry everything because it affects emotional room and makes me believe I have to solve everything at once.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** I have to solve everything at once
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 64
**Prompt:** When I am behind and the pressure keeps growing, the feeling moves straight into I should be able to carry all of this. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** I should be able to carry all of this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 65
**Prompt:** The situation is too many things are hitting me at once, and the meaning that keeps attaching is I am failing because I cannot handle this. It is making ability to prioritize feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** I am failing because I cannot handle this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 66
**Prompt:** I have responsibilities piling up and it makes me believe if I slow down everything will fall apart, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** if I slow down everything will fall apart
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 67
**Prompt:** I do not know where to start. Everyone needs something from me keeps affecting capacity and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** needing space means I am avoiding life
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 68
**Prompt:** I keep replaying how my emotions and tasks are both too much because it affects ability to prioritize and makes me believe being overwhelmed means I am weak.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** being overwhelmed means I am weak
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 69
**Prompt:** When I cannot tell what matters first, the feeling moves straight into I am behind and cannot recover. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** I am behind and cannot recover
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 70
**Prompt:** The situation is I feel like one more thing will break me, and the meaning that keeps attaching is I have to solve everything at once. It is making capacity feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** I have to solve everything at once
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 71
**Prompt:** I am trying to carry everything and it makes me believe my worth depends on keeping up, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** my worth depends on keeping up
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 72
**Prompt:** I cannot keep up. I am behind and the pressure keeps growing keeps affecting emotional room and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** I am failing because I cannot handle this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 73
**Prompt:** I keep replaying how too many things are hitting me at once because it affects capacity and makes me believe I should be able to carry all of this.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** I should be able to carry all of this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 74
**Prompt:** When I have responsibilities piling up, the feeling moves straight into needing space means I am avoiding life. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** needing space means I am avoiding life
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 75
**Prompt:** The situation is everyone needs something from me, and the meaning that keeps attaching is if I slow down everything will fall apart. It is making emotional room feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** if I slow down everything will fall apart
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 76
**Prompt:** My emotions and tasks are both too much and it keeps attaching to the thought that I am behind and cannot recover, even though part of me knows I may not have the full picture.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** I am behind and cannot recover
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid turning overwhelm into productivity advice.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 77
**Prompt:** I am stretched too thin. I cannot tell what matters first keeps affecting ability to prioritize and I cannot tell what is actually true.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** being overwhelmed means I am weak
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid telling the user to just calm down.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 78
**Prompt:** I keep replaying how I feel like one more thing will break me because it affects emotional room and makes me believe my worth depends on keeping up.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** emotional room
**Attached meaning to separate:** my worth depends on keeping up
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid giving a large task list.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 79
**Prompt:** When I am trying to carry everything, the feeling moves straight into I have to solve everything at once. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** capacity
**Attached meaning to separate:** I have to solve everything at once
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid treating overwhelm as failure.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.

### Test 80
**Prompt:** The situation is I am behind and the pressure keeps growing, and the meaning that keeps attaching is I should be able to carry all of this. It is making ability to prioritize feel unstable.
**Expected primary route:** `overwhelm_and_pressure`
**Pressure focus:** ability to prioritize
**Attached meaning to separate:** I should be able to carry all of this
**Expected reverse-flow movement:** capacity recognition, pressure separation, smaller next movement, steadier clarity
**Bad response risk:** Avoid using clinical anxiety language unless the user does.
**Teaching correction:** Name the load and capacity pressure clearly. Separate being overwhelmed from being incapable, and guide toward smaller prioritized movement without turning the response into productivity coaching.
