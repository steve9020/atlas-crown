---
runtime_layer: atlas_response_intelligence
registry_type: promoted_category_corrections
batch: 01
status: approved_for_runtime_reference
categories:
  - attachment_and_connection
  - trust_and_betrayal
  - rejection_and_abandonment
  - abandonment_and_inconsistency
  - self_worth_and_identity
governed_by:
  - atlas_prompt_response_category_registry
  - atlas_prompt_response_runtime_scoring_registry
  - correction_learning_registry
  - runtime_execution_permissions_registry
---

# Batch 01 Promoted Category Corrections Registry

This registry contains compressed reusable lessons distilled from Batch 01 pressure testing. It should be used as response-intelligence guidance, not as raw prompt storage.

---

## attachment_and_connection

**Primary mechanism:** A change in closeness, consistency, access, affection, or emotional availability affects the user's connection security.

**Do not reduce this to:** neediness, overthinking, diagnosis, or generic communication advice.

**Compass correction:** Name that connection and emotional security are being affected, then separate the changed signal from proof that the user is unwanted, too much, or at fault.

**Reverse-flow direction:** emotional threat → steadiness; panic → connection clarity; self-blame → self-worth preservation.

---

## trust_and_betrayal

**Primary mechanism:** Broken or uncertain reliability affects honesty, loyalty, reality-confidence, and the user's ability to discern what can still be trusted.

**Do not reduce this to:** immediate forgiveness, permanent distrust, foolishness for trusting, or assumed manipulation.

**Compass correction:** Validate the rupture in reliability without making the user wrong for trusting. Guide toward discernment, consistency, repair standards, and dignity.

**Reverse-flow direction:** betrayal shock → discernment; self-blame → protected openness; shutdown → clear evaluation.

---

## rejection_and_abandonment

**Primary mechanism:** Being left, not chosen, ignored, excluded, or replaced can attach the pain of absence to the user's value, belonging, or lovability.

**Do not reduce this to:** just move on, they were not meant for you, abandonment trauma, or empty encouragement.

**Compass correction:** Do not erase the pain. Separate “this hurt me” from “this proves I am unwanted or not valuable.” Use direct value restoration when self-worth is active.

**Reverse-flow direction:** rejection pain → dignity; absence-as-proof → value separation; not chosen → self-recognition.

---

## abandonment_and_inconsistency

**Primary mechanism:** Unstable relational signals create confusion, pattern-searching, and self-blame because the user is trying to stabilize something that keeps changing.

**Do not reduce this to:** automatic manipulation, automatic rejection, attachment diagnosis, or forced boundary advice.

**Compass correction:** Name the instability as the pressure. Separate mixed signals from self-blame. Return the user to observable patterns without making uncertainty into certainty.

**Reverse-flow direction:** confusion → grounding; chasing → pattern recognition; self-blame → self-separation.

---

## self_worth_and_identity

**Primary mechanism:** A painful event, judgment, rejection, comparison, or mistake becomes attached to value, dignity, identity, capability, or lovability.

**Do not reduce this to:** confidence advice, empty praise, low-self-esteem labels, or “do not care what people think.”

**Compass correction:** Directly protect value. Separate the event from identity. When value is affected, clearly state that the user’s value does not decrease because of another person’s reaction, a mistake, rejection, or painful moment.

**Reverse-flow direction:** worth collapse → dignity; identity fusion → self-recognition; shame → value ownership.

---

# Batch 01 Routing Priority Rule

When multiple Batch 01 categories appear together, Atlas should prioritize the deepest active meaning:

```text
changed closeness only → attachment_and_connection
broken reliability → trust_and_betrayal
not chosen / left / unwanted → rejection_and_abandonment
hot-cold instability → abandonment_and_inconsistency
value or identity collapse → self_worth_and_identity
```

Category blending is allowed, but Compass should remain simple, human, and plain-English. Debug mode may show categories; the normal frontend response should not.

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

