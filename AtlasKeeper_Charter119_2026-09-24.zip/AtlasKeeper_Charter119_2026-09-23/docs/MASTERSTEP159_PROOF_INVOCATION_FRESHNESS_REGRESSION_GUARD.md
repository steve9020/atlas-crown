# Masterstep159 — Proof Invocation Freshness Regression Guard

## Purpose

Step159 extends the Step158 proof-current-state authority lock with a proof invocation freshness guard. The goal is to prevent future proof runs from silently using a stale extracted package folder or stale current-state callout while the user thinks they are running the latest keeper.

## What changed

- Added `runtime/proof/ProofInvocationFreshnessGuard.js`.
- Added `tests/masterStep159ProofInvocationFreshnessRegressionGuardTest.js`.
- Updated `proof/runCurrentProof.js` so the current proof identity is resolved and printed before proof commands run.
- Added an expected package-root check tied to the current keeper stem.
- Kept historical proof markers externalized; historical markers cannot define the active manifest.

## Guarded failure surface

The guard fails if:

- the extracted package root does not match the active keeper stem;
- `PROOF_STATE.json`, `version_status.js`, and `PROOF_COMPATIBILITY_REGISTRY.json` disagree;
- the runner command count does not match the active expected proof count;
- stale hardcoded current-manifest callouts reappear inside the active proof runner.

## Boundary statement

This is proof infrastructure only. It adds no runtime behavior change, no Compass output behavior change, no safety behavior change, no matrix capability, no model authority, no frontend intelligence, no cloud/provider fallback, no silent learning, and no silent mutation.
