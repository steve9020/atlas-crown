# Future Pattern Fear Registry

## Purpose
Detects fear that unresolved emotional meaning will become a future pattern.

## Signals
- I don't want this to become
- become a pattern
- keep shaping me
- carry this forward
- what if this keeps happening
- make me someone I don't want to be

## Rule
Future fear is not always catastrophizing. Sometimes it is awareness trying to prevent unwanted pattern formation.
