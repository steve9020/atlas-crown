const assert = require('assert');
const fs = require('fs');
const path = require('path');
const projectRoot = path.resolve(__dirname, '..');
const pluginRoot = path.join(projectRoot, 'CA', 'Continuity_Architecture', '.obsidian', 'plugins', 'continuity-interface');
const backendServicePath = path.join(projectRoot, 'runtime', 'backend', 'BackendReviewPayloadService.js');

assert.ok(fs.existsSync(backendServicePath), 'BackendReviewPayloadService must exist');
const backendServiceText = fs.readFileSync(backendServicePath, 'utf8');
for (const required of ['Governance Review','Mutation Status','Human Review Status','Risk Classification','Rule Triggered']) {
  assert.ok(backendServiceText.includes(required), `backend payload service must own ${required}`);
}

const modalPath = path.join(pluginRoot, 'ControlVisibilityModal.js');
const modalText = fs.readFileSync(modalPath, 'utf8');
for (const forbidden of [
  'Governance Review',
  'Mutation Status',
  'Human Review Status',
  'Risk Classification',
  'Rule Triggered',
  'GOVERNANCE_RULE_UNKNOWN',
  'PENDING_MANUAL_REVIEW',
  'READ_ONLY',
  'Draft Blueprint Review',
  'Copy Review Text'
]) {
  assert.ok(!modalText.includes(forbidden), `frontend modal must not hardcode intelligence-aware label: ${forbidden}`);
}
for (const required of ['backend_prepared','buildBackendDisplayPayload','payload.rows','payload.content']) {
  assert.ok(modalText.includes(required), `frontend modal should render backend payload generically: ${required}`);
}

const frontendFiles = fs.readdirSync(pluginRoot).filter((f) => f.endsWith('.js'));
const forbiddenImplementationMarkers = [
  'DoyleLayer',
  'SemanticAttachment',
  'ActiveAttachment',
  'scoreRoute',
  'detectSignals',
  'detectAxes',
  'CompassResponseBuilderIntegration',
  'GoldenCompassLanguageWeaver',
  'TeachingCenterLearningProposalFlow',
  'AIProposalQuarantine',
  'AIAssistanceBoundary',
  'ResponseQualityChecker'
];
for (const file of frontendFiles) {
  const text = fs.readFileSync(path.join(pluginRoot, file), 'utf8');
  for (const marker of forbiddenImplementationMarkers) {
    assert.ok(!text.includes(marker), `${file} contains frontend intelligence marker: ${marker}`);
  }
}

const service = require('../runtime/backend/BackendReviewPayloadService');
const payload = service.buildBackendDisplayPayload({ rule_triggered: 'X', body: 'Body' }, 'governance-blocked');
assert.strictEqual(payload.backend_prepared, true);
assert.ok(Array.isArray(payload.rows));
assert.ok(service.validateBackendDisplayPayload(payload).ok);
console.log('masterStep51FrontendDumbShellCleanupTest PASSED');
