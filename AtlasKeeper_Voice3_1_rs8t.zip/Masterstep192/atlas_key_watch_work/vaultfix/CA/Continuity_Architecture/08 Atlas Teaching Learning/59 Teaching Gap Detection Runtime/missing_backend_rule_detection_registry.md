---
runtime_layer: teaching_gap_detection
priority: high
owned_by: atlas_teaching_learning
feeds_into:
  - teaching_gap_to_proposal_flow
---

# Missing Backend Rule Detection Registry

## Purpose
Determines whether a weak Compass response was caused by a missing backend rule.

## Detection questions
- Did Atlas lack a route for the specific scenario pattern?
- Did Atlas lack a priority rule between two routes?
- Did Atlas lack a card-selection rule?
- Did Atlas lack a soft translation rule?
- Did Atlas detect the signal but fail to apply it in response construction?

## Rule
A missing backend rule must be reusable. It must not encode only one exact prompt.
