const assert = require('assert');
const spire = require('../runtime/indexing/DoyleSpireLayerSphereMap');
const positives = require('../runtime/semantics/PositiveAttachmentIntegration');
const guard = require('../runtime/indexing/DoyleSpirePlacementGuard');

const shape = spire.validateShape();
assert.strictEqual(shape.passed, true, `shape failed: ${shape.errors.join(',')}`);
assert.strictEqual(spire.countPrimarySpheres(), 84, 'expected 84 primary spheres');
for (const layer of spire.getLayers()) assert.strictEqual(layer.spheres.length, 12, `bad sphere count for ${layer.layer_id}`);

const positiveCheck = positives.validatePositiveIntegration();
assert.strictEqual(positiveCheck.passed, true, `positive integration failed; missing ${positiveCheck.missing.join(',')}`);
assert.strictEqual(positives.isFirstClassPositiveAttachment('love'), true, 'love should be first-class');
assert.strictEqual(positives.isFirstClassPositiveAttachment('comfort'), true, 'comfort should be first-class');
assert.strictEqual(positives.isFirstClassPositiveAttachment('happiness'), true, 'happiness should be first-class');

const placementRules = guard.validatePlacementRules();
assert.strictEqual(placementRules.passed, true, 'placement rules failed');
assert.deepStrictEqual(guard.placeRelation({ layer: 'L3', sphere: 'Love / Care / Affection' }).authority_granted, false);
assert.strictEqual(guard.placeRelation({ layer: 'L9', sphere: 'Bad' }).accepted, false);

console.log('masterStep34DoyleSpireLayerSphereMapTest PASSED');
