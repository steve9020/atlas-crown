# Self-Worth

## Mechanical Definition
Self-worth is the internal sense of value, deservingness, and personal significance formed through identity, integrity, love, recognition, and continuity of needs being met.

Self-worth can be internally stabilized or externally dependent.

---

## Real-World Definition
In real use, Self Worth describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates Self-Worth
- love
- recognition
- integrity
- truthful identity
- emotional support
- meaningful contribution
- continuity of care
- internal belief in inherent value

---

## What Weakens Self-Worth
- rejection
- betrayal
- dishonesty
- abandonment
- comparison
- validation dependency
- unresolved shame
- lack of integrity

---

## What Self-Worth Produces
- confidence
- emotional stability
- resilience
- healthy boundaries
- authenticity
- reduced validation seeking

---

## What Happens Without Stable Self-Worth
- insecurity
- external dependency
- fear of rejection
- identity instability
- validation addiction
- emotional collapse under criticism

---

## What Stabilizes Self-Worth Long-Term
- integrity
- awareness
- truthful self-authorship
- emotional grounding
- healthy relationships
- internal alignment

---

## Connected Nodes
- [[Integrity]]
- [[Love]]
- [[Identity]]
- [[Authenticity|Authenticity]]
- [[Fear]]
- [[Loneliness|Loneliness]]
- [[Trust|Trust]]

---

## Core Principle
Integrity stabilizes self-worth when external continuity fluctuates.

## Related Flows
- [[Identity Flows]]
- [[Reinforcement Flows]]
- [[Fragmentation Flows]]
- [[Recovery Flows]]