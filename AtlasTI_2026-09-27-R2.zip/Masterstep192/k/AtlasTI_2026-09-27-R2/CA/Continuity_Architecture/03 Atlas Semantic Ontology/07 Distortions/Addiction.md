# Addiction

## Mechanical Definition
Addiction is repeated external attachment used to compensate for unresolved internal lack, fragmentation, emotional pain, or instability.

Addiction attempts to simulate completion without repairing underlying continuity.

---

## Real-World Definition
In real use, Addiction describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates Addiction
- unresolved suffering
- emotional pain
- fear
- loneliness
- lack of self-worth
- identity instability
- unresolved trauma
- internal emptiness

---

## What Sustains Addiction
- temporary relief
- emotional avoidance
- reward reinforcement
- lack of awareness
- external dependency
- suppression of underlying pain

---

## What Addiction Produces
- dependency
- identity fragmentation
- emotional instability
- avoidance of recalibration
- loss of freedom
- distorted continuity

---

## What Resolves Addiction Constructively
- awareness
- truthful self-confrontation
- emotional healing
- self-worth stabilization
- discipline
- support
- internal reconstruction

---

## What Addiction Is Doing Mechanically
Addiction externally imitates:
- peace
- love
- control
- acceptance
- stability
- completion
- emotional relief

without actually resolving the underlying absence.

---

## Connected Nodes
- [[Freedom]]
- [[Fear]]
- [[Self-Worth]]
- [[Loneliness|Loneliness]]
- [[Identity]]
- [[Suffering]]
- [[Discipline]]
- [[Continuity Recognition]]

---

## Core Principle
Addiction is external compensation for unresolved internal fragmentation.