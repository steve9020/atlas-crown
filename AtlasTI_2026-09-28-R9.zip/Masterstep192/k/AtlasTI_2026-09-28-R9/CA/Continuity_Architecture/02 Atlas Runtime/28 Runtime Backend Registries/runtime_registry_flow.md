---
title: Runtime Registry Flow
runtime_layer: backend_registry
priority: highest
status: active
phase: runtime_backend_registry_foundation
governed_by:
  - runtime_backend_registries_overview
  - governance_enforcement_registry
outputs:
  - runtime_signal_registry
  - depth_routing_registry
  - node_bucket_classification_registry
  - runtime_weighting_registry
  - runtime_link_resolution_registry
  - response_behavior_registry
---

# Runtime Registry Flow

## Purpose

This node defines how the backend registries work together as one runtime flow.

The registries are not isolated files.

They form the backend instruction layer that the plugin should eventually read instead of permanently owning signal detection, routing, weighting, governance, link resolution, or response behavior.

## Core Rule

The vault defines runtime intelligence.

The plugin reads, parses, routes, renders, and displays.

The plugin should not become the permanent source of backend meaning.

## Registry Flow Order

### 1. Runtime Signal Registry

The runtime first identifies what kind of input pressure may be present.

Examples:

- rejection
- trust
- conflict
- grief
- comparison
- ridicule
- responsibility
- practical/logistical pressure
- intensity
- identity fusion

Signals do not create certainty.

Signals only suggest relevant pathways.

### 2. Depth Routing Registry

After signals are detected, the runtime selects proportional depth.

Possible depth routes:

- light
- moderate
- deep

Depth routing determines how much interpretation is appropriate.

Light prevents over-analysis.

Deep prevents under-response when identity fusion or recursive weight is present.

### 3. Node Bucket Classification Registry

After depth is selected, active runtime nodes are grouped by operational role.

Primary buckets:

- depth
- governance
- meaning separation
- emotional pressure
- recursive
- continuity
- translation
- general

Buckets define runtime function, not total node meaning.

### 4. Runtime Weighting Registry

After nodes are bucketed, runtime weighting decides which nodes matter most.

Weighting uses:

- signal match
- depth route
- node priority
- runtime layer
- bucket relevance
- emotional language
- identity fusion
- intensity
- governance relevance
- related runtime links

Weighting must support relevance, not automatic dominance.

### 5. Runtime Link Resolution Registry

The runtime checks whether activated links resolve cleanly.

Link resolution handles:

- exact filename matches
- aliases
- display titles
- governance targets
- old node names
- formatting cleanup
- placeholder references

Unresolved links should be surfaced for cleanup, not hidden.

### 6. Governance Enforcement Registry

Governance constrains the full route.

Governance suppresses:

- clinical framing
- diagnostic framing
- authority posture
- shame mechanics
- productivity pressure
- gamification
- false certainty
- over-analysis
- under-response
- emotional dependency loops

Governance supports:

- clarity
- proportional depth
- emotional reality without false conclusion
- continuity restoration
- grounded perspective
- nonjudgmental movement

### 7. Response Behavior Registry

The final response is shaped into plain-English Compass language.

Normal response movement:

1. recognize scenario or context
2. recognize emotional effect
3. identify underlying mechanism or pressure
4. separate event from internalized meaning
5. clarify feeling versus conclusion
6. offer objective clarifying perspective
7. restore continuity without pressure

## Runtime Flow Summary

The backend registry route should move like this:

1. Detect input signals.
2. Select response depth.
3. Classify active nodes into buckets.
4. Apply runtime weighting.
5. Resolve aliases and link targets.
6. Enforce governance.
7. Shape the Compass response.
8. Render frontend output.

## Plugin Reading Order

When the plugin eventually reads these registries, it should prefer this order:

1. `runtime_backend_registries_overview`
2. `runtime_signal_registry`
3. `depth_routing_registry`
4. `node_bucket_classification_registry`
5. `runtime_weighting_registry`
6. `runtime_link_resolution_registry`
7. `governance_enforcement_registry`
8. `response_behavior_registry`
9. `runtime_registry_flow`

## Interface Boundary

The frontend should not expose this registry structure to normal users.

Normal users should not see:

- runtime buckets
- node weights
- governance enforcement
- backend registries
- ontology logic
- semantic architecture

Debug panels may show this during development.

The final user-facing Compass response should feel simple, human, and clarifying.

## Runtime Completion Status

This registry layer completes the backend migration foundation for the current hardcoded plugin bridge logic.

The following backend registry nodes are now defined:

- `runtime_backend_registries_overview`
- `runtime_signal_registry`
- `depth_routing_registry`
- `node_bucket_classification_registry`
- `runtime_weighting_registry`
- `runtime_link_resolution_registry`
- `governance_enforcement_registry`
- `response_behavior_registry`
- `runtime_registry_flow`

## Next Operational Direction

After this registry layer is saved, the next implementation direction is not more ontology expansion unless an operational gap appears.

The next direction is controlled plugin reading of these backend registries.

The plugin should gradually shift from hardcoded bridge logic toward vault-defined runtime behavior.

## Related Runtime Links

- [[runtime_backend_registries_overview]]
- [[runtime_signal_registry]]
- [[depth_routing_registry]]
- [[node_bucket_classification_registry]]
- [[runtime_weighting_registry]]
- [[runtime_link_resolution_registry]]
- [[governance_enforcement_registry]]
- [[response_behavior_registry]]
- [[governance_enforcement_flow|governance_enforcement_flow]]
- [[atlas_runtime_operational_construction_lock]]