---
title: Runtime Signal Registry
runtime_layer: backend_registry
priority: highest
status: active
phase: obsidian_signal_registry_stage9
governed_by:
  - runtime_backend_registries_overview
  - depth_routing_registry
  - governance_enforcement_registry
outputs:
  - depth_routing_registry
  - node_bucket_classification_registry
  - runtime_weighting_registry
  - response_behavior_registry
---

# Runtime Signal Registry

Purpose: stores Atlas/Compass signal-detection rules in the Obsidian backend so runtime code remains a generic reader/evaluator instead of owning Compass-specific detection branches.

Boundary: this registry may declare signal activation phrases and grouped phrase requirements. It may not diagnose the user, decide truth, bypass governance, mutate backend files, create authority, or override response quality checks.

Core rule: signals do not diagnose the user and do not decide truth. A signal only means: “this type of runtime pathway may be relevant.”

Runtime use: `SignalEngine.js` reads this JSON registry and returns unique signals whose phrase rules match the input. The signal list then flows into axis detection, route scoring, route explanation, response construction, quality verification, governance validation, trace logging, and output delivery.

```json
{
  "version": "OBSIDIAN_SIGNAL_REGISTRY_STAGE9",
  "matchingMode": "case_insensitive_phrase_includes",
  "dedupe": true,
  "rules": [
    {
      "id": "mistake_to_progress_collapse",
      "priority": 10,
      "signal": "mistake_to_progress_collapse",
      "allGroups": [
        {
          "id": "mistake_language",
          "phrases": [
            "mistake",
            "messed up",
            "messing up",
            "small mistake"
          ]
        },
        {
          "id": "progress_pressure_language",
          "phrases": [
            "falling behind",
            "fell behind",
            "behind",
            "not keeping up",
            "can't keep up",
            "cannot keep up"
          ]
        }
      ]
    },
    {
      "id": "meaning_attachment",
      "priority": 20,
      "signal": "meaning_attachment",
      "phrases": [
        "proof",
        "means",
        "must mean",
        "turning into"
      ]
    },
    {
      "id": "mistake_pressure",
      "priority": 30,
      "signal": "mistake_pressure",
      "phrases": [
        "mistake",
        "messed up",
        "messing up"
      ]
    },
    {
      "id": "progress_pressure",
      "priority": 40,
      "signal": "progress_pressure",
      "phrases": [
        "falling behind",
        "fell behind",
        "not keeping up",
        "can't keep up",
        "cannot keep up"
      ]
    },
    {
      "id": "relational_pressure",
      "priority": 50,
      "signal": "relational_pressure",
      "phrases": [
        "too much",
        "unwanted",
        "rejected",
        "pulled away",
        "distant",
        "silence"
      ]
    },
    {
      "id": "performance_pressure",
      "priority": 60,
      "signal": "performance_pressure",
      "phrases": [
        "perfect",
        "flawless",
        "failure",
        "failing"
      ]
    },
    {
      "id": "finality_pressure",
      "priority": 70,
      "signal": "finality_pressure",
      "phrases": [
        "always",
        "never",
        "forever",
        "final",
        "nothing will change"
      ]
    }
  ]
}
```
