# Integration Draft Runtime

## Purpose
Integration drafts convert approved proposals into backend registry-ready markdown.

## Rule
An approved proposal still does not become active until it is integrated into the correct backend registry.

## Target Selection
Atlas should choose likely target registries from proposal meaning, category, and existing backend overlap.

## Integration Principle
Write only what improves backend understanding while keeping frontend expression plain, light, and non-authoritative.
