const assert = require('assert');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const exists = rel => fs.existsSync(path.join(ROOT, rel));
const read = rel => fs.readFileSync(path.join(ROOT, rel), 'utf8');
const json = rel => JSON.parse(read(rel));

const {
  parseStepNumber,
  isValidLaterKeeper,
  acceptsCurrentProofCount,
  preservesHistoricalMarker,
  acceptsHistoricalAndCurrentTarget,
  evaluateProofCompatibilitySnapshot
} = require('../runtime/proof/ProofCompatibilityHelper');

function main() {
  assert.strictEqual(parseStepNumber('Masterstep144.zip'), 144);
  assert.strictEqual(parseStepNumber('MASTERSTEP143_CURRENT_PROOF_MANIFEST.json'), 143);
  assert.strictEqual(isValidLaterKeeper('Masterstep144.zip', 143), true);
  assert.strictEqual(isValidLaterKeeper('Masterstep142.zip', 143), false);
  assert.strictEqual(acceptsCurrentProofCount(66, 65), true);
  assert.strictEqual(acceptsCurrentProofCount(64, 65), false);
  assert.strictEqual(preservesHistoricalMarker('CROSS_WINDOW_PROOF_CONTINUITY_LEDGER marker', 'CROSS_WINDOW_PROOF_CONTINUITY_LEDGER'), true);

  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
  const state = json('runtime/proof/PROOF_STATE.json');
  const versionStatus = json('tests/VERSION_STATUS.json');
  const proofJson = json('runtime/proof/MASTERSTEP144_PROOF_COMPATIBILITY_HELPER_LATER_KEEPER_RECOGNITION.json');
  const runner = read('proof/runCurrentProof.js');
  const testResults = read('tests/TEST_RESULTS.md');
  const index = read('runtime/proof/ENGINEERING_PROOF_INDEX.md');
  const docsIndex = read('docs/ENGINEERING_PROOF_INDEX.md');

  assert.strictEqual(acceptsHistoricalAndCurrentTarget(summary, 'Mixed-Context Evidence Separation', 'Translation Preservation Matrix'), true);

  const goodSnapshot = evaluateProofCompatibilitySnapshot({
    currentKeeper: 'Masterstep144.zip',
    sourceKeeper: 'Masterstep143_repaired.zip',
    minimumStep: 143,
    actualProofCount: 66,
    minimumProofCount: 65,
    summaryText: summary,
    requiredSourceKeeper: 'Masterstep143_repaired.zip',
    requiredMarkers: [
      'CROSS_WINDOW_PROOF_CONTINUITY_LEDGER',
      'Candidate phrasing remains candidate-only',
      'Atlas-governed output remains final'
    ],
    historicalTargets: ['Mixed-Context Evidence Separation'],
    currentTargets: ['Translation Preservation Matrix'],
    boundaryMarkers: [
      'No model authority',
      'No frontend intelligence',
      'No silent learning',
      'No silent mutation'
    ],
    authorityExpansionAllowed: false,
    silentMutationAllowed: false,
    frontendIntelligenceAllowed: false
  });

  assert.strictEqual(goodSnapshot.ok, true);
  assert.strictEqual(goodSnapshot.helperScope, 'proof-compatibility-only');
  assert.strictEqual(goodSnapshot.mutatesRuntimeBehavior, false);
  assert.strictEqual(goodSnapshot.weakensHistoricalProofMarkers, false);

  const lowCount = evaluateProofCompatibilitySnapshot({
    currentKeeper: 'Masterstep144.zip',
    minimumStep: 143,
    actualProofCount: 64,
    minimumProofCount: 65,
    summaryText: summary,
    requiredMarkers: ['CROSS_WINDOW_PROOF_CONTINUITY_LEDGER']
  });
  assert.strictEqual(lowCount.ok, false);
  assert.strictEqual(lowCount.proofCountOk, false);

  const missingMarker = evaluateProofCompatibilitySnapshot({
    currentKeeper: 'Masterstep144.zip',
    minimumStep: 143,
    actualProofCount: 66,
    minimumProofCount: 65,
    summaryText: 'Candidate phrasing remains candidate-only',
    requiredMarkers: ['CROSS_WINDOW_PROOF_CONTINUITY_LEDGER']
  });
  assert.strictEqual(missingMarker.ok, false);
  assert.strictEqual(missingMarker.requiredMarkersOk, false);

  assert.strictEqual(proofJson.package, 'Masterstep144.zip');
  assert.strictEqual(proofJson.source_keeper, 'Masterstep143_repaired.zip');
  assert.strictEqual(proofJson.expected_commands, 66);
  assert.strictEqual(proofJson.proof_compatibility_helper_created, true);
  assert.strictEqual(proofJson.runtime_behavior_changed, false);
  assert.strictEqual(proofJson.matrix_capability_added, false);
  assert.strictEqual(proofJson.compass_output_logic_changed, false);
  assert.strictEqual(proofJson.model_authority_added, false);
  assert.strictEqual(proofJson.frontend_intelligence_added, false);
  assert.strictEqual(proofJson.silent_learning_allowed, false);
  assert.strictEqual(proofJson.silent_mutation_allowed, false);

  assert.ok(isValidLaterKeeper(state.current_keeper, 144), 'state.current_keeper must identify Masterstep144 or later keeper');
  assert.ok(isValidLaterKeeper(state.source_keeper, 143), 'state.source_keeper must identify Masterstep143 or later keeper');
  assert.ok(isValidLaterKeeper(state.step, 144), 'state.step must identify Masterstep144 or later');
  assert.ok(acceptsCurrentProofCount(state.expected_commands, 66), 'state.expected_commands must be 66 or greater');
  assert.ok(acceptsCurrentProofCount(state.expected_current_proof_commands, 66), 'state.expected_current_proof_commands must be 66 or greater');
  assert.strictEqual(state.proof_compatibility_helper_created, true);
  assert.strictEqual(state.runtime_behavior_changed, state.shared_semantic_multi_domain_migration_created ? true : false);
  assert.strictEqual(state.matrix_capability_added, state.shared_semantic_multi_domain_migration_created ? true : false);
  assert.strictEqual(state.compass_output_logic_changed, state.shared_semantic_multi_domain_migration_created ? true : false);

  assert.ok(isValidLaterKeeper(versionStatus.current_keeper, 144), 'versionStatus.current_keeper must identify Masterstep144 or later keeper');
  assert.ok(isValidLaterKeeper(versionStatus.source_keeper, 143), 'versionStatus.source_keeper must identify Masterstep143 or later keeper');
  assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 66), 'versionStatus.expected_current_proof_commands must be 66 or greater');
  assert.strictEqual(versionStatus.proof_compatibility_helper_created, true);

  const requiredFiles = [
    'runtime/proof/ProofCompatibilityHelper.js',
    'tests/masterStep144ProofCompatibilityHelperLaterKeeperRecognitionTest.js',
    'runtime/proof/MASTERSTEP144_PROOF_COMPATIBILITY_HELPER_LATER_KEEPER_RECOGNITION.md',
    'runtime/proof/MASTERSTEP144_PROOF_COMPATIBILITY_HELPER_LATER_KEEPER_RECOGNITION.json',
    'docs/MASTERSTEP144_PROOF_COMPATIBILITY_HELPER_LATER_KEEPER_RECOGNITION.md',
    'docs/PROOF_COMPATIBILITY_HELPER_LATER_KEEPER_RECOGNITION.md'
  ];
  for (const file of requiredFiles) assert.strictEqual(exists(file), true, `missing required file: ${file}`);

  assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
  assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
  assert.ok(/Expected current proof target: [0-9]+\/[0-9]+ commands passed/i.test(summary), 'summary must identify current proof target compatibility');
  assert.ok(/Proof Compatibility Helper/i.test(summary));
  assert.ok(/later-keeper recognition/i.test(summary));
  assert.ok(/equal-or-greater proof counts/i.test(summary));
  assert.ok(/historical proof markers/i.test(summary));
  assert.ok(/Masterstep143 — Translation Preservation Output Drift Regression/i.test(summary));
  assert.ok(/TEST 144/i.test(testResults));
  assert.ok(/Proof Compatibility Helper/i.test(testResults));
  assert.ok(/Masterstep144 — Proof Compatibility Helper/i.test(index));
  assert.ok(/Masterstep144 — Proof Compatibility Helper/i.test(docsIndex));
  assert.ok(/masterStep144ProofCompatibilityHelperLaterKeeperRecognitionTest/i.test(runner));
  assert.ok(/currentTarget\.current_manifest/i.test(runner), 'runner must identify current proof manifest compatibility');

  console.log('masterStep144ProofCompatibilityHelperLaterKeeperRecognitionTest passed');
}

main();
