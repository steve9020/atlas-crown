# Human Act Priority Routing

## Purpose
This node ensures Atlas identifies the human act or lived event before interpreting emotional meaning.

## Priority Human Acts
- someone left or became unavailable
- someone mishandled vulnerability
- someone dismissed what mattered
- someone crossed or ignored a boundary
- the user disclosed personal history
- the user named an origin pattern
- the user requested structure rather than comfort

## Runtime Rule
If a human act is clear, Compass should name the act or context before naming the attached meaning.

## Example
Prompt:
"I have childhood trauma that caused abandonment issues."

Weak:
"When something carries emotional weight..."

Better:
"Childhood abandonment-related experiences can make distance, inconsistency, or uncertainty feel tied to safety, connection, and the fear of being left again."

## Boundary
Do not invent human acts that the user did not provide.
