const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const vs=json('tests/VERSION_STATUS.json');
const ps=json('runtime/proof/PROOF_STATE.json');
const active=json('runtime/workflow/ACTIVE_STEP.json');
const manifest=json('CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/CARRY_FORWARD_MANIFEST.json');
for (const obj of [vs, ps, active]) {
  assert(JSON.stringify(obj).includes('Masterstep14'), 'state object must reference Masterstep14');
  assert(JSON.stringify(obj).includes('closed_keeper'), 'state object must be closed keeper');
}
assert(vs.snapshot === 'Masterstep14.zip', 'VERSION_STATUS snapshot must be Masterstep14.zip');
assert(ps.current_keeper === 'Masterstep14.zip', 'PROOF_STATE current keeper mismatch');
assert(active.current_keeper === 'Masterstep14.zip', 'ACTIVE_STEP current keeper mismatch');
assert(manifest.current_package === 'Masterstep14.zip', 'carry-forward current package mismatch');
assert(manifest.current_status === 'closed_keeper', 'carry-forward status mismatch');
assert(ps.ai_adapter_added === false && ps.real_ai_connected === false && ps.network_bridge_added === false, 'AI/network boundary must remain false');
console.log('masterStep14FullClosureKeeperReadinessTest PASSED');
