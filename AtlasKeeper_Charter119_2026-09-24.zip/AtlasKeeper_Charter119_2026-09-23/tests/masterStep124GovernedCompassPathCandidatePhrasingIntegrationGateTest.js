
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard.js');
const { evaluateGovernedCompassPathCandidatePhrasingIntegrationGate } = require('../runtime/backend/adapter/GovernedCompassPathCandidatePhrasingIntegrationGate.js');
const { runCompassCandidatePhrasingRefinementLiveContainment } = require('../runtime/backend/adapter/CompassCandidatePhrasingRefinementLiveContainment.js');

const ROOT = path.resolve(__dirname, '..');
const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');
function read(rel){ return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function walk(dir){
  const out=[];
  for (const entry of fs.readdirSync(dir,{withFileTypes:true})){
    const full=path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}
function sha256(rel){ return crypto.createHash('sha256').update(read(rel)).digest('hex'); }

const protectedRuntimeFiles = [
  'runtime/backend/adapter/GovernedCompassPathCandidatePhrasingIntegrationGate.js',
  'runtime/backend/adapter/CompassCandidatePhrasingRefinementLiveContainment.js',
  'runtime/backend/adapter/CompassCandidatePhrasingRefinementDryIntegration.js',
  'runtime/backend/adapter/OllamaLiveLocalCallContainment.js',
  'runtime/governance/GovernanceAdapter.js',
  'Cognition/quality/ResponseQualityChecker.js'
].filter(rel => fs.existsSync(path.join(ROOT, rel)));
const beforeHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));

(async function main(){
  const doc = read('docs/MASTERSTEP124_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_INTEGRATION_GATE.md');
  const shortDoc = read('docs/GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_INTEGRATION_GATE.md');
  const proofDoc = read('runtime/proof/MASTERSTEP124_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_INTEGRATION_GATE.md');
  const proofJson = json('runtime/proof/MASTERSTEP124_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_INTEGRATION_GATE.json');
  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
  const state = json('runtime/proof/PROOF_STATE.json');
  const versionStatus = json('tests/VERSION_STATUS.json');
  const versionJs = read('version_status.js');
  const testResults = read('tests/TEST_RESULTS.md');

  assert.ok(/Current keeper: Masterstep124\.zip/i.test(doc), 'Step124 doc must identify current keeper');
  assert.ok(/Source keeper: Masterstep123\.zip/i.test(doc), 'Step124 doc must identify source keeper');
  assert.ok(/46\/46 passed/i.test(doc), 'Step124 doc must state expected 46/46 result');
  assert.ok(/Governed Compass Path Candidate Phrasing Integration Gate/i.test(doc + proofDoc), 'Step124 must identify governed Compass path integration gate');
  assert.ok(/gate only/i.test(doc), 'Step124 must be gate only');
  assert.ok(/does not integrate candidate phrasing refinement into the normal Compass response path/i.test(doc), 'Step124 must not integrate normal Compass path');
  assert.ok(/Atlas must construct the Compass response foundation first/i.test(doc), 'Step124 must require Atlas-first construction');

  assert.strictEqual(proofJson.package, 'Masterstep124', 'proof JSON must identify Masterstep124');
  assert.strictEqual(proofJson.source_keeper, 'Masterstep123', 'proof JSON must identify source keeper');
  assert.strictEqual(proofJson.expected_commands, 46, 'proof JSON must expect 46 commands');
  assert.strictEqual(proofJson.integration_gate_created, true, 'proof JSON must mark integration gate');
  assert.strictEqual(proofJson.normal_compass_path_integration, false, 'proof JSON must not authorize normal Compass path integration');
  assert.strictEqual(proofJson.live_model_call_added, false, 'proof JSON must not add live call');
  assert.strictEqual(proofJson.request_sent_by_step124, false, 'proof JSON must not send request');
  assert.strictEqual(proofJson.broad_model_integration, false, 'proof JSON must forbid broad model integration');
  assert.strictEqual(proofJson.boundaries.model_authority_added, false, 'model authority forbidden');
  assert.strictEqual(proofJson.boundaries.raw_model_output_final_allowed, false, 'raw final forbidden');
  assert.strictEqual(proofJson.boundaries.cloud_provider_fallback_allowed, false, 'cloud fallback forbidden');
  assert.strictEqual(proofJson.boundaries.frontend_intelligence_added, false, 'frontend intelligence forbidden');

  const missingAtlas = evaluateGovernedCompassPathCandidatePhrasingIntegrationGate({
    governedMeaning: 'meaning exists',
    route: 'compass.restore',
    contextObject: { route: 'compass.restore' }
  });
  assert.strictEqual(missingAtlas.ok, false, 'gate must fail closed without Atlas response');
  assert.strictEqual(missingAtlas.failedClosed, true, 'missing Atlas response must fail closed');
  assert.strictEqual(missingAtlas.requestSent, false, 'gate failure cannot send request');
  assert.strictEqual(missingAtlas.liveModelCalled, false, 'gate failure cannot call local model');
  assert.ok(missingAtlas.reasons.includes('atlas_response_required_before_candidate_phrasing'), 'missing Atlas response reason required');

  const missingContext = evaluateGovernedCompassPathCandidatePhrasingIntegrationGate({
    atlasResponse: 'Feeling embarrassed is understandable, but it does not prove identity is broken.',
    governedMeaning: 'separate embarrassment from identity proof',
    route: 'compass.restore'
  });
  assert.strictEqual(missingContext.ok, false, 'gate must fail closed without context object');
  assert.ok(missingContext.reasons.includes('context_object_required_before_candidate_phrasing'), 'missing context reason required');

  const eligible = evaluateGovernedCompassPathCandidatePhrasingIntegrationGate({
    atlasResponse: 'Feeling embarrassed is understandable, but it does not prove identity is broken. Dignity can stay intact.',
    governedMeaning: 'separate embarrassment from identity proof while preserving dignity',
    route: 'compass.restore',
    contextObject: { axis: 'identity-pressure', route: 'compass.restore', boundary: 'candidate-only' },
    qualityGateReady: true,
    governanceGateReady: true,
    traceGateReady: true
  });
  assert.strictEqual(eligible.ok, true, 'eligible gate should pass when Atlas-first conditions exist');
  assert.strictEqual(eligible.integrationGateOnly, true, 'Step124 remains gate only');
  assert.strictEqual(eligible.normalCompassPathIntegration, false, 'Step124 must not integrate normal path');
  assert.strictEqual(eligible.requestPrepared, false, 'Step124 must not prepare request');
  assert.strictEqual(eligible.requestSent, false, 'Step124 must not send request');
  assert.strictEqual(eligible.liveModelCalled, false, 'Step124 must not call model');
  assert.strictEqual(eligible.rawModelOutputFinalAllowed, false, 'raw final forbidden');
  assert.strictEqual(eligible.candidateOnly, true, 'candidate-only boundary required');
  assert.strictEqual(eligible.candidateMayReplaceFinal, false, 'candidate cannot replace final');
  assert.strictEqual(eligible.finalOutputRemainsAtlasGoverned, true, 'final output remains Atlas-governed');
  assert.strictEqual(eligible.atlasOwnsMeaningRouteContextAndBoundaries, true, 'Atlas owns meaning/route/context/boundaries');
  assert.strictEqual(eligible.candidateMayChangeRoute, false, 'candidate route changes forbidden');
  assert.strictEqual(eligible.candidateMayChangeTruth, false, 'candidate truth changes forbidden');
  assert.strictEqual(eligible.candidateMayAddFacts, false, 'candidate fact additions forbidden');
  assert.strictEqual(eligible.candidateMayAddAdvice, false, 'candidate advice additions forbidden');
  assert.strictEqual(eligible.candidateMayDiagnose, false, 'candidate diagnosis forbidden');
  assert.strictEqual(eligible.candidateMayApproveTeaching, false, 'candidate teaching approval forbidden');
  assert.strictEqual(eligible.candidateMayWriteRuntimeOrProof, false, 'candidate writes forbidden');
  assert.strictEqual(eligible.candidateMayBypassQuality, false, 'candidate quality bypass forbidden');
  assert.strictEqual(eligible.candidateMayBypassGovernance, false, 'candidate governance bypass forbidden');
  assert.strictEqual(eligible.requiredAfterCandidatePath.sourceMeaningComparisonRequired, true, 'source comparison required');
  assert.strictEqual(eligible.requiredAfterCandidatePath.forbiddenDriftCheckRequired, true, 'forbidden drift check required');
  assert.strictEqual(eligible.requiredAfterCandidatePath.atlasGovernedFinalFallbackRequired, true, 'Atlas fallback required');
  assert.strictEqual(eligible.authorityLimits.cloudProviderFallbackAllowed, false, 'cloud fallback forbidden');
  assert.strictEqual(eligible.authorityLimits.publicNetworkBindingAllowed, false, 'public network forbidden');
  assert.strictEqual(eligible.authorityLimits.frontendIntelligenceAllowed, false, 'frontend intelligence forbidden');
  assert.strictEqual(eligible.authorityLimits.silentMutationAllowed, false, 'silent mutation forbidden');

  const live = await runCompassCandidatePhrasingRefinementLiveContainment({
    atlasResponse: 'Feeling embarrassed is understandable, but it does not prove identity is broken. Dignity can stay intact.',
    governedMeaning: 'separate embarrassment from identity proof while preserving dignity',
    route: 'compass.restore',
    traceId: 'masterstep124-compatibility-live-containment-check',
    timeoutMs: 4500
  });
  assert.strictEqual(live.ok, true, 'existing live containment path must remain intact');
  assert.strictEqual(live.candidateOnly, true, 'live path remains candidate-only');
  assert.strictEqual(live.rawModelOutputFinalAllowed, false, 'live raw output cannot be final');
  assert.strictEqual(live.finalOutputRemainsAtlasGoverned, true, 'live final remains Atlas-governed');
  assert.strictEqual(live.authorityLimits.routeSelectionByModelAllowed, false, 'route selection by model remains forbidden');
  assert.strictEqual(live.authorityLimits.truthDecisionByModelAllowed, false, 'truth decision by model remains forbidden');
  assert.strictEqual(live.authorityLimits.teachingApprovalByModelAllowed, false, 'teaching approval by model remains forbidden');
  assert.strictEqual(live.authorityLimits.modelWritesAllowed, false, 'model writes remain forbidden');
  assert.strictEqual(live.authorityLimits.cloudProviderFallbackAllowed, false, 'cloud fallback remains forbidden');
  assert.strictEqual(live.authorityLimits.frontendIntelligenceAllowed, false, 'frontend intelligence remains forbidden');
  assert.strictEqual(live.authorityLimits.silentMutationAllowed, false, 'silent mutation remains forbidden');

  assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
  assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
  assert.ok(/Expected current proof target: [0-9]+\/[0-9]+ commands passed/i.test(summary), 'summary must identify current proof target compatibility');
  assert.ok(['Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 124), 'proof state must identify Masterstep124 or later current keeper');
  assert.ok(['Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 123) || state.source_keeper === 'Masterstep141.zip', 'proof state must identify source keeper');
  assert.ok(acceptsCurrentProofCount(state.expected_commands, 46), state.expected_commands);
  assert.strictEqual(state.normal_compass_path_integration, false, 'proof state must not authorize normal integration');
  assert.strictEqual(state.governed_compass_path_candidate_phrasing_integration_gate_created, true, 'proof state must mark Step124 gate');
  assert.strictEqual(state.integration_gate_only, true, 'proof state must mark gate only');
  assert.strictEqual(state.model_authority_added, false, 'proof state must forbid model authority');
  assert.strictEqual(state.raw_model_output_final_allowed, false, 'proof state must forbid raw final');
  assert.ok(['Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(versionStatus.current_keeper) || isValidLaterKeeper(versionStatus.current_keeper, 124), 'version status must identify Masterstep124 or later');
  assert.ok(['Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(versionStatus.source_keeper) || isValidLaterKeeper(versionStatus.source_keeper, 123) || versionStatus.source_keeper === 'Masterstep141.zip', 'version status must identify source keeper');
  assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 46), versionStatus.expected_current_proof_commands);
  assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs), 'version_status.js must identify current keeper compatibility');
  assert.ok(/expected_current_proof_commands: [0-9]+/i.test(versionJs), 'version_status.js must identify expected command compatibility');
  assert.ok(/TEST 124/i.test(testResults), 'test ledger must include TEST 124');
  assert.ok(/Governed Compass Path Candidate Phrasing Integration Gate/i.test(testResults), 'test ledger must identify Step124');
  assert.ok(/46\/46 commands|47\/47 commands/i.test(testResults), 'test ledger must record 46/46 or later target');

  const forbiddenOverclaims = { test: (text) => hasForbiddenAffirmativeClaim(text) };
  for (const text of [doc, shortDoc, proofDoc, summary]) assert.ok(!forbiddenOverclaims.test(text), 'Step124 docs must not overclaim or imply forbidden authority');

  const providerScan = scanForProviderConnections(ROOT);
  assert.strictEqual(providerScan.passed, true, `provider/network scan must pass: ${JSON.stringify(providerScan.violations || [])}`);
  const nestedArchives = walk(ROOT).filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
  assert.deepStrictEqual(nestedArchives, [], 'package must not contain nested archives');
  const afterHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));
  const mutatedRuntimeFiles = protectedRuntimeFiles.filter(file => beforeHashes[file] !== afterHashes[file]);
  assert.deepStrictEqual(mutatedRuntimeFiles, [], 'Step124 test must not mutate protected runtime/governance/quality/adapter files');

  console.log(JSON.stringify({
    package: 'Masterstep124',
    source_keeper: 'Masterstep123',
    step: 'Governed Compass Path Candidate Phrasing Integration Gate',
    proof_target: '46/46',
    gate_only: eligible.integrationGateOnly,
    normal_compass_path_integration: eligible.normalCompassPathIntegration,
    request_sent: eligible.requestSent,
    live_model_called: eligible.liveModelCalled,
    final_output_remains_atlas_governed: eligible.finalOutputRemainsAtlasGoverned,
    provider_scan_passed: providerScan.passed === true,
    nested_archives: nestedArchives.length,
    protected_runtime_mutations: mutatedRuntimeFiles.length
  }, null, 2));
})().catch(error => {
  console.error(error && error.stack ? error.stack : error);
  process.exit(1);
});
