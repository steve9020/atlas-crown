'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { extractSharedSemanticEvidence } = require('../runtime/understanding/SharedSemanticEvidenceExtractor');
const { evaluatePressurePerformanceIdentity } = require('../runtime/understanding/PressurePerformanceIdentityMatrix');
const { evaluateRelationalSilenceSelfCausation } = require('../runtime/understanding/RelationalSilenceSelfCausationMatrix');
const { arbitrateSemanticPlacements } = require('../runtime/understanding/SemanticPlacementArbitrator');
const { buildContextObject } = require('../runtime/understanding/ContextObjectConstructionEngine');
const mixed = require('../runtime/understanding/MixedContextEvidenceSeparationMatrix');
const translation = require('../runtime/understanding/TranslationPreservationMatrix');
const weaver = require('../runtime/compass/CompassOntologyLanguageWeaver');

// 1: Step176 consumes shared normalized evidence; no local extraction catalogue remains.
const pressureSource = fs.readFileSync(path.join(__dirname, '../runtime/understanding/PressurePerformanceIdentityMatrix.js'), 'utf8');
assert(!pressureSource.includes('SIGNAL_PATTERNS'));
assert(pressureSource.includes('extractSharedSemanticEvidence'));
for (const prompt of [
  'I keep trying and it never feels like enough.',
  'I checked everything off, but nothing feels finished.',
  'I met every goal and still feel like I failed.'
]) {
  const shared = extractSharedSemanticEvidence(prompt);
  const result = evaluatePressurePerformanceIdentity({ prompt, sharedSemanticEvidence: shared });
  assert.strictEqual(result.matched, true, prompt);
  assert.strictEqual(result.migration.duplicated_local_extraction_removed, true);
  assert.strictEqual(buildContextObject(prompt).domain, 'performance_worth_pressure', prompt);
}

// 2-3: a structurally different relational domain consumes the same axes and remains distinct.
const relationalPrompts = [
  'I have not heard from my mom in weeks and I keep wondering if I did something wrong.',
  'My dad has been quiet and I think it is my fault.',
  'My sister has not replied and I am worried she is upset with me.',
  'They normally call by now, but my brother has gone quiet and I keep blaming myself.'
];
for (const prompt of relationalPrompts) {
  const shared = extractSharedSemanticEvidence(prompt);
  const relational = evaluateRelationalSilenceSelfCausation({ prompt, sharedSemanticEvidence: shared });
  const pressure = evaluatePressurePerformanceIdentity({ prompt, sharedSemanticEvidence: shared });
  assert.strictEqual(relational.matched, true, prompt);
  assert.strictEqual(pressure.matched, false, prompt);
  assert.strictEqual(buildContextObject(prompt).domain, 'family_silence_self_causation', prompt);
}

// 4-5: mixed evidence is preserved, exclusions arbitrate, unresolved competition is explicit.
const mixedPrompt = 'I finished everything at work and still feel like a failure, but my dad has not replied and I think I caused it.';
const arbitration = arbitrateSemanticPlacements(mixedPrompt);
assert.strictEqual(arbitration.collapse_prevented, true);
assert.strictEqual(arbitration.candidates.length, 2);
assert(arbitration.unresolved.length > 0);
const mixedContext = buildContextObject(mixedPrompt);
assert.strictEqual(mixedContext.domain, 'mixed_semantic_context');
assert.strictEqual(mixedContext.semantic_candidates.length, 2);
assert(mixed.inferContextsFromPrompt(mixedPrompt).some(x => x.id === 'performance_worth_pressure_context'));
assert(mixed.inferContextsFromPrompt(mixedPrompt).some(x => x.id === 'family_silence_self_causation_context'));

// 6: fallback exists but cannot override a qualified shared placement.
const contextSource = fs.readFileSync(path.join(__dirname, '../runtime/understanding/ContextObjectConstructionEngine.js'), 'utf8');
assert(contextSource.includes('legacyPerformancePressureMatch'));
assert(contextSource.includes('legacyFamilySilenceMatch'));
assert(contextSource.includes('semanticArbitration.fallback_required'));

// 7: output and translation preservation remain bounded; no backend labels leak.
assert.strictEqual(weaver.chooseProfileName({ active_relation: 'performance_worth_pressure' }, {}), 'performance_worth_pressure');
const preserved = translation.evaluateTranslationPreservationMatrix({
  prompt: relationalPrompts[0],
  finalCompassOutput: 'The silence is real, but the cause is still unknown. Not knowing why is not proof that blame belongs to you.'
});
assert.strictEqual(preserved.ok, true);

const frontendRoot = path.join(__dirname, '..', 'CA', 'Continuity_Architecture', '.obsidian', 'plugins', 'continuity-interface');
for (const file of fs.readdirSync(frontendRoot)) {
  if (!file.endsWith('.js')) continue;
  const body = fs.readFileSync(path.join(frontendRoot, file), 'utf8');
  assert(!body.includes('SharedSemanticEvidenceExtractor'));
  assert(!body.includes('SemanticPlacementArbitrator'));
  assert(!body.includes('RelationalSilenceSelfCausationMatrix'));
}
console.log('Masterstep178 shared semantic multi-domain migration no-collapse test: PASSED');
