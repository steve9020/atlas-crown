# Mixed Emotion Runtime Branch Registry

Defines mixed emotion branch detection as backend data. This prevents main.js from hard-owning branch names and meanings.


## Backend Data

```json
{
  "branches": [
    {
      "key": "personal_progress_guilt_care_conflict",
      "matchGroups": [
        [
          "happy",
          "happiness",
          "joy",
          "proud",
          "pride",
          "progress",
          "good for myself",
          "something good for myself",
          "chance to do something good"
        ],
        [
          "guilt",
          "guilty",
          "selfish",
          "stopped caring",
          "care",
          "others are struggling",
          "people around me are struggling",
          "other people struggling"
        ]
      ],
      "recommendation": "personal_progress_guilt_care_conflict_loop",
      "voice": {
        "opener": "I get why that would feel conflicted.",
        "situation": "When you finally get something good for yourself while people around you are struggling",
        "emotionalEffects": "it can affect happiness, pride, guilt, care, and whether receiving your own progress starts feeling selfish",
        "pattern": "It can move from, “I am happy this happened for me,” into, “Maybe I should not feel good while other people are struggling. Maybe being happy for myself means I stopped caring.” If those emotions stay attached to guilt, your progress can start feeling like something you have to defend before you are allowed to receive it.",
        "proofBoundary": "Being happy about your own progress may explain why guilt showed up, but it does not prove that you stopped caring about other people.",
        "whySeparate": "That difference matters because if happiness and guilt stay fused together, you may start treating good things in your own life like they take compassion away from someone else.",
        "reverse": "Your happiness deserves room because your progress matters too. The guilt could be slowed down because caring about your own life does not erase your care for others.",
        "anchor": "Being happy for yourself does not mean you stopped caring about others. Your progress and your compassion can exist at the same time."
      }
    },
    {
      "key": "jealousy_shame_comparison_branch",
      "matchGroups": [
        [
          "jealous",
          "jealousy",
          "envy",
          "envious",
          "comparing",
          "comparison",
          "behind",
          "not doing enough",
          "their good moment",
          "wanted for a long time"
        ],
        [
          "ashamed",
          "shame",
          "kind of ashamed",
          "bad person",
          "turning their good moment",
          "about me"
        ]
      ],
      "recommendation": "jealousy_shame_comparison_branch_loop",
      "voice": {
        "opener": "I get why that would feel personal.",
        "situation": "When someone close to you gets something you have wanted for yourself",
        "emotionalEffects": "it can affect jealousy, shame, progress, value, and whether their good moment starts feeling like a judgment against your own life",
        "pattern": "It can move from, “I wanted that too,” into, “Maybe I am behind. Maybe I am not doing enough. Maybe their good moment says something about me.” If those emotions stay attached to comparison, someone else’s progress can start feeling like a measurement of your value.",
        "proofBoundary": "Someone else’s progress may explain why you feel jealous, ashamed, or behind, but it does not prove that you are failing or that your value decreased.",
        "whySeparate": "That difference matters because if those emotions stay attached to comparison, you may start using their progress as a judgment against your own life.",
        "reverse": "The jealousy may be showing you something you want for yourself. The shame could be slowed down because feeling jealousy does not make you a bad person, and their good moment does not lower your value.",
        "anchor": "Their good moment does not lower your value. It may show you something you want for yourself, but it does not mean you are behind or failing."
      }
    },
    {
      "key": "relief_guilt_care_branch",
      "matchGroups": [
        [
          "relief",
          "relieved"
        ],
        [
          "guilt",
          "guilty",
          "care",
          "stopped caring",
          "lack of care",
          "didn't care",
          "did not care"
        ]
      ],
      "voice": {
        "opener": "I get why that would feel confusing.",
        "situation": "When relief shows up after something difficult or heavy",
        "emotionalEffects": "it can affect guilt, care, responsibility, and whether feeling relieved starts making you question your own heart",
        "pattern": "It can move from, “I feel relieved,” into, “Maybe that means I did not care enough.” If those emotions stay attached to guilt, relief can start feeling like proof against your care instead of a sign that pressure changed.",
        "proofBoundary": "Feeling relieved may explain that something became less heavy to carry, but it does not prove that you stopped caring.",
        "whySeparate": "That difference matters because if relief and lack of care stay fused together, you may punish yourself for feeling less pressure even when care is still there.",
        "reverse": "Relief can be understood without turning it into self-judgment. Less pressure does not automatically mean less care.",
        "anchor": "Relief does not prove you stopped caring. It may mean something became less heavy to carry."
      }
    },
    {
      "key": "pride_judgment_discomfort_branch",
      "matchGroups": [
        [
          "proud",
          "pride",
          "accomplished",
          "finished",
          "progress"
        ],
        [
          "arrogant",
          "arrogance",
          "selfish",
          "full of myself",
          "judged",
          "uncomfortable"
        ]
      ],
      "voice": {
        "opener": "I get why that would feel uncomfortable.",
        "situation": "When pride shows up and then gets questioned right away",
        "emotionalEffects": "it can affect confidence, visibility, judgment, and whether recognizing your own effort starts feeling wrong",
        "pattern": "It can move from, “I feel proud of this,” into, “Maybe that makes me arrogant.” If those emotions stay attached to judgment, progress can turn into self-monitoring instead of confidence.",
        "proofBoundary": "Feeling proud may explain why you feel visible or uncomfortable, but it does not prove that you are arrogant.",
        "whySeparate": "That difference matters because if pride and judgment stay fused together, you may question good moments before you let them become confidence.",
        "reverse": "Your effort deserves to be recognized. The discomfort could be slowed down because feeling good about your progress does not make that feeling wrong.",
        "anchor": "Pride can be recognition of effort. Feeling good about your progress does not make you arrogant."
      }
    },
    {
      "key": "hope_fear_disappointment_branch",
      "matchGroups": [
        [
          "hope",
          "hopeful",
          "want this",
          "want it to work"
        ],
        [
          "fear",
          "afraid",
          "scared",
          "disappointed",
          "disappointment",
          "foolish",
          "setting myself up"
        ]
      ],
      "voice": {
        "opener": "I get why that would feel risky.",
        "situation": "When hope shows up after disappointment has already hurt before",
        "emotionalEffects": "it can affect trust, expectation, fear, and whether wanting something good starts feeling foolish",
        "pattern": "It can move from, “I hope this works,” into, “Maybe I am setting myself up to be disappointed again.” If those emotions stay attached to fear, hope can start feeling like something you have to defend before you are allowed to want it.",
        "proofBoundary": "Feeling afraid of disappointment may explain why hope feels risky, but it does not prove that hoping is foolish.",
        "whySeparate": "That difference matters because if hope and fear stay fused together, you may start treating desire like a mistake before the outcome is even known.",
        "reverse": "Hope can stay grounded without becoming self-judgment. Wanting something good does not make you foolish.",
        "anchor": "Hope does not prove you are setting yourself up. It may show that something still matters to you."
      }
    }
  ]
}
```

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

