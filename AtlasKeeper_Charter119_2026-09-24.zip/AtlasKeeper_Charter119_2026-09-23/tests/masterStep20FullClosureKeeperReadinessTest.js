const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel),'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function exists(rel){ return fs.existsSync(path.join(root, rel)); }
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const proof = json('runtime/proof/PROOF_STATE.json');
const active = json('runtime/workflow/ACTIVE_STEP.json');
const version = json('tests/VERSION_STATUS.json');
for (const state of [proof, active, version]) {
  assert(state.current_keeper === 'Masterstep20.zip', 'current keeper must be Masterstep20.zip');
  assert(state.previous_keeper === 'Masterstep19.zip', 'previous keeper must be Masterstep19.zip');
  assert(state.current_step === 'Masterstep20', 'current step must be Masterstep20');
  assert(state.status === 'closed_keeper', 'status must be closed_keeper');
  assert(state.step_not_patch === true, 'step_not_patch must remain true');
  assert(state.ai_invocation_approval_gate_added === true, 'AI invocation approval gate must be recorded');
  assert(state.ai_invocation_blocked_by_default === true, 'AI invocation must be blocked by default');
  assert(state.approval_can_be_inferred === false, 'approval cannot be inferred');
  assert(state.local_model_connected === false, 'local model must not be connected');
  assert(state.real_ai_connected === false, 'real AI must be false');
  assert(state.provider_config_added === false, 'provider config must be false');
  assert(state.network_bridge_added === false, 'network bridge must be false');
  assert(state.frontend_intelligence_added === false, 'frontend intelligence must be false');
}
for (const rel of [
  'runtime/ai/AI_INVOCATION_APPROVAL_GATE.json',
  'runtime/ai/AI_INVOCATION_APPROVAL_GATE.md',
  'runtime/ai/AIInvocationApprovalGate.js',
  'runtime/ai/AIInvocationReviewQueue.js',
  'runtime/ai/AIInvocationAuditRecord.js',
  'runtime/proof/MASTERSTEP20_AI_INVOCATION_APPROVAL_GATE.md',
  'runtime/proof/MASTERSTEP20_TEST_RESULTS.md',
  'docs/MASTERSTEP20_AI_INVOCATION_APPROVAL_GATE_MAP.md'
]) assert(exists(rel), `missing ${rel}`);
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md');
assert(summary.includes('Current keeper: Masterstep20.zip'), 'summary must name Masterstep20');
assert(summary.includes('No real AI connected'), 'summary must preserve no real AI boundary');
assert(summary.includes('AI invocation now requires explicit scoped human approval'), 'summary must describe approval gate');
console.log('masterStep20FullClosureKeeperReadinessTest PASSED');
