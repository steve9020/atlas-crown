# Adaptive Regulation Reverse Flows

## Definition
Adaptive regulation reverse flows are pathways where adaptive regulation weakens, collapses, or becomes distorted under pressure, overload, contradiction, or recursive escalation.

## Function
They describe movement away from flexible regulation and toward rigidity, volatility, suppression, or fragmentation.

## Relationships
- [[Adaptive Regulation]]
- [[Emotional Regulation Reverse Flows]]
- [[Fragmentation Reverse Flows]]
- [[Destabilization]]
- [[Recovery Reverse Flows]]
