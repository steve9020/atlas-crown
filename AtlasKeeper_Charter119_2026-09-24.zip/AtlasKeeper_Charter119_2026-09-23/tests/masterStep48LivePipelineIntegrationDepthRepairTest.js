const assert = require('assert');
const { main } = require('../main');
const { scoreRoute } = require('../Cognition/scoring/RouteScorer');

function run(prompt){
  const result = main(prompt);
  assert.strictEqual(result.status, 'pipeline active');
  assert.strictEqual(result.live_response_path, 'CompassResponseBuilderIntegration');
  assert.ok(result.compass_response_candidate, 'missing compass candidate');
  assert.ok(result.response_depth, 'missing response depth');
  assert.strictEqual(result.response_depth.route_confidence_is_not_depth, true);
  assert.ok(['light','moderate','deep'].includes(result.response_depth.depth));
  assert.ok(typeof result.output === 'string' && result.output.length > 20);
  assert.ok(!/Part of you may want to pull back because staying engaged feels too heavy right now/.test(result.output), 'old response builder output leaked through');
  return result;
}

const pile = run('When things pile up, I shut down and can’t think clearly.');
assert.strictEqual(pile.compass_response_candidate.route.active_relation, 'semantic_overwhelm_shutdown_cognitive_crowding');
assert.strictEqual(pile.response_depth.depth, 'deep');
assert.ok(typeof pile.output === 'string' && pile.output.length > 0);
assert.ok(typeof pile.output === 'string' && pile.output.includes('See') && pile.output.includes('Separate') && pile.output.includes('Restore'));

const overfix = run('They seemed off after my message, and now I want to send five more texts explaining everything before they get mad.');
assert.strictEqual(overfix.compass_response_candidate.route.active_relation, 'semantic_communication_or_response_context');
assert.ok(typeof overfix.output === 'string' && overfix.output.includes('See') && overfix.output.includes('Separate') && overfix.output.includes('Restore'));
assert.ok(!overfix.compass_response_candidate.route.activated.includes('user_anger'));

const pride = run('I am proud I finally finished it.');
assert.strictEqual(pride.compass_response_candidate.route.active_relation, 'positive_pride_effort_completion');
assert.strictEqual(pride.response_depth.depth, 'light');
assert.ok(typeof pride.output === 'string' && pride.output.includes('See') && pride.output.includes('Separate') && pride.output.includes('Restore'));

const scored = scoreRoute({ axes: ['identity_axis'] }, ['relational_pressure','shutdown'], 'stability_return');
assert.ok(scored.score > 0, 'score should count signal array without requiring signals.signals wrapper');
assert.ok(['low','medium','high'].includes(scored.confidence));

console.log('masterStep48LivePipelineIntegrationDepthRepairTest PASSED');
