'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard');
const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const {
  POSITIVE_STATE_COMPASS_OUTPUT_CASES,
  evaluatePositiveStateCompassOutputCase,
  runPositiveStateCompassOutputPreservationBatch
} = require('../runtime/understanding/PositiveStateCompassOutputPreservation');

const ROOT = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function exists(rel){ return fs.existsSync(path.join(ROOT, rel)); }
function sha256(rel){ return crypto.createHash('sha256').update(read(rel)).digest('hex'); }
function walk(dir){
  const out=[];
  for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
    const full=path.join(dir,entry.name);
    if(entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}

(function main(){
  const protectedRuntime = [
    'runtime/understanding/PositiveStateMatrixMaturity.js',
    'runtime/understanding/PositiveStateFreshRegression.js',
    'runtime/understanding/TranslationPreservationMatrix.js',
    'runtime/understanding/MixedContextEvidenceSeparationMatrix.js',
    'runtime/understanding/ContextBeforeRouteEvidenceSufficiencyMatrix.js'
  ];
  const before = Object.fromEntries(protectedRuntime.map(f => [f, sha256(f)]));

  const batch = runPositiveStateCompassOutputPreservationBatch();
  assert.strictEqual(batch.ok, true, 'positive-state Compass output preservation batch should pass');
  assert.ok(isValidLaterKeeper(batch.currentKeeper, 150), batch.currentKeeper);
  assert.ok(isValidLaterKeeper(batch.sourceKeeper, 149), batch.sourceKeeper);
  assert.strictEqual(batch.step, 'Masterstep150 — Positive-State Compass Output Preservation');
  assert.strictEqual(batch.preservationOnly, true);
  assert.strictEqual(batch.addsNewMatrixCapability, false);
  assert.ok(batch.total >= 4, 'preservation batch should include multiple positive-state outputs');
  assert.strictEqual(batch.passed, batch.total);
  assert.strictEqual(batch.failed, 0);
  assert.strictEqual(batch.positiveStateMeaningSurvivesCompassOutput, true);
  assert.strictEqual(batch.seeSeparateNoticeRestorePreserved, true);
  assert.strictEqual(batch.noticeHeadingPreferred, true);
  assert.strictEqual(batch.deconstructHeadingAllowedAsFinal, false);
  assert.strictEqual(batch.forcedOptimismAllowed, false);
  assert.strictEqual(batch.outcomeGuaranteeAllowed, false);
  assert.strictEqual(batch.backendLanguageLeakageAllowed, false);
  assert.strictEqual(batch.routeOverLabelingAllowed, false);
  assert.strictEqual(batch.genericFlatteningAllowed, false);
  assert.strictEqual(batch.advicePressureAllowed, false);
  assert.strictEqual(batch.candidatePhrasingRemainsCandidateOnly, true);
  assert.strictEqual(batch.candidateMayReplaceFinal, false);
  assert.strictEqual(batch.atlasGovernedOutputRemainsFinal, true);
  assert.strictEqual(batch.modelAuthorityAdded, false);
  assert.strictEqual(batch.frontendIntelligenceAdded, false);
  assert.strictEqual(batch.cloudProviderFallbackAllowed, false);
  assert.strictEqual(batch.silentLearningAllowed, false);
  assert.strictEqual(batch.silentMutationAllowed, false);

  const requiredIds = ['hope_without_guarantee_compass_output','relief_without_permanent_safety_compass_output','gratitude_without_guilt_compass_output','confidence_without_performance_pressure_compass_output'];
  assert.deepStrictEqual(POSITIVE_STATE_COMPASS_OUTPUT_CASES.map(c => c.id), requiredIds, 'positive-state Compass output cases should remain deliberate and auditable');
  for (const result of batch.results) {
    assert.strictEqual(result.ok, true, `${result.id} should pass`);
    assert.strictEqual(result.positiveStateFreshRegressionPreserved, true);
    assert.strictEqual(result.positiveStateMeaningSurvivesCompassOutput, true);
    assert.strictEqual(result.seeSeparateNoticeRestorePreserved, true);
    assert.strictEqual(result.forcedOptimismDetected, false);
    assert.strictEqual(result.outcomeGuaranteeDetected, false);
    assert.strictEqual(result.backendLanguageLeakageDetected, false);
    assert.strictEqual(result.routeOverLabelingDetected, false);
    assert.strictEqual(result.genericFlatteningDetected, false);
    assert.strictEqual(result.advicePressureDetected, false);
    assert.strictEqual(result.analyticalHeadingDriftDetected, false);
  }

  const badOutputs = [
    { name: 'backend language leak', output: 'SEE\nThis matrix route activates POSITIVE_STATE_MATRIX.\n\nSEPARATE\nOk\n\nNOTICE\nOk\n\nRESTORE\nOk' },
    { name: 'forced optimism', output: 'SEE\nYou should feel happy.\n\nSEPARATE\nOk\n\nNOTICE\nOk\n\nRESTORE\nOk' },
    { name: 'outcome guarantee', output: 'SEE\nEverything will be okay.\n\nSEPARATE\nOk\n\nNOTICE\nOk\n\nRESTORE\nOk' },
    { name: 'advice pressure', output: 'SEE\nOk\n\nSEPARATE\nYou need to stay positive.\n\nNOTICE\nOk\n\nRESTORE\nOk' },
    { name: 'deconstruct heading drift', output: 'SEE\nOk\n\nSEPARATE\nOk\n\nDECONSTRUCT\nOk\n\nRESTORE\nOk' },
    { name: 'generic flattening', output: 'SEE\nYour feelings are valid.\n\nSEPARATE\nOk\n\nNOTICE\nOk\n\nRESTORE\nOk' }
  ];
  for (const item of badOutputs) {
    const blocked = evaluatePositiveStateCompassOutputCase({ requiredState: 'hope', output: item.output });
    assert.strictEqual(blocked.ok, false, `${item.name} should fail preservation`);
    assert.strictEqual(blocked.modelAuthorityAdded, false);
    assert.strictEqual(blocked.frontendIntelligenceAdded, false);
    assert.strictEqual(blocked.candidateMayReplaceFinal, false);
    assert.strictEqual(blocked.rawModelOutputFinalAllowed, false);
  }

  const requiredFiles = [
    'runtime/understanding/PositiveStateCompassOutputPreservation.js',
    'runtime/understanding/PositiveStateFreshRegression.js',
    'runtime/understanding/PositiveStateMatrixMaturity.js',
    'tests/masterStep150PositiveStateCompassOutputPreservationTest.js',
    'runtime/proof/MASTERSTEP150_POSITIVE_STATE_COMPASS_OUTPUT_PRESERVATION.md',
    'runtime/proof/MASTERSTEP150_POSITIVE_STATE_COMPASS_OUTPUT_PRESERVATION.json',
    'docs/MASTERSTEP150_POSITIVE_STATE_COMPASS_OUTPUT_PRESERVATION.md',
    'docs/POSITIVE_STATE_COMPASS_OUTPUT_PRESERVATION.md',
    'runtime/proof/ProofCompatibilityHelper.js'
  ];
  for (const file of requiredFiles) assert.strictEqual(exists(file), true, `missing required file: ${file}`);

  const proofJson = json('runtime/proof/MASTERSTEP150_POSITIVE_STATE_COMPASS_OUTPUT_PRESERVATION.json');
  const state = json('runtime/proof/PROOF_STATE.json');
  const versionStatus = json('tests/VERSION_STATUS.json');
  const versionJs = read('version_status.js');
  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md');
  const testResults = read('tests/TEST_RESULTS.md');
  const index = read('runtime/proof/ENGINEERING_PROOF_INDEX.md');
  const docsIndex = read('docs/ENGINEERING_PROOF_INDEX.md');
  const runner = read('proof/runCurrentProof.js');

  assert.strictEqual(proofJson.package, 'Masterstep150.zip');
  assert.strictEqual(proofJson.source_keeper, 'Masterstep149.zip');
  assert.strictEqual(proofJson.expected_commands, 72);
  assert.strictEqual(proofJson.preservation_only, true);
  assert.strictEqual(proofJson.positive_state_compass_output_preservation_created, true);

  assert.ok(isValidLaterKeeper(state.current_keeper, 150), state.current_keeper);
  assert.ok(isValidLaterKeeper(state.source_keeper, 149), state.source_keeper);
  assert.ok(isValidLaterKeeper(state.step, 150), state.step);
  assert.ok(acceptsCurrentProofCount(state.expected_commands, 72), state.expected_commands);
  assert.ok(acceptsCurrentProofCount(state.expected_current_proof_commands, 72), state.expected_current_proof_commands);
  assert.strictEqual(state.positive_state_compass_output_preservation_created, true);
  assert.strictEqual(state.preservation_only, true);
  assert.strictEqual(state.matrix_capability_added, state.shared_semantic_multi_domain_migration_created ? true : false);
  assert.strictEqual(state.runtime_behavior_changed, state.shared_semantic_multi_domain_migration_created ? true : false);
  assert.strictEqual(state.compass_output_logic_changed, state.shared_semantic_multi_domain_migration_created ? true : false);
  assert.strictEqual(state.model_authority_added, false);
  assert.strictEqual(state.frontend_intelligence_added, false);
  assert.strictEqual(state.silent_learning_allowed, false);
  assert.strictEqual(state.silent_mutation_allowed, false);

  assert.ok(isValidLaterKeeper(versionStatus.current_keeper, 150), versionStatus.current_keeper);
  assert.ok(isValidLaterKeeper(versionStatus.source_keeper, 149), versionStatus.source_keeper);
  assert.ok(isValidLaterKeeper(versionStatus.step, 150), versionStatus.step);
  assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 72), versionStatus.expected_current_proof_commands);
  assert.strictEqual(versionStatus.positive_state_compass_output_preservation_created, true);
  assert.strictEqual(versionStatus.preservation_only, true);
  assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs));
  assert.ok(/expected_current_proof_commands: [0-9]+/i.test(versionJs));
  const keyMatches = Array.from(versionJs.matchAll(/^\s*([A-Za-z0-9_]+)\s*:/gm)).map(m => m[1]);
  assert.strictEqual(keyMatches.length, new Set(keyMatches).size, 'version_status.js should not have duplicate keys');

  assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary));
  assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary));
  assert.ok(/Expected current proof target: [0-9]+\/[0-9]+ commands passed/i.test(summary));
  assert.ok(/Masterstep150 — Positive-State Compass Output Preservation/i.test(summary));
  assert.ok(/Positive-state meaning survives into Compass output/i.test(summary));
  assert.ok(/No forced optimism/i.test(summary));
  assert.ok(/No outcome guarantee/i.test(summary));
  assert.ok(/Candidate phrasing remains candidate-only/i.test(summary));
  assert.ok(/Atlas-governed output remains final/i.test(summary));

  assert.ok(/TEST 150[\s\S]{0,120}Positive-State Compass Output Preservation/i.test(testResults));
  assert.ok(/72\/72/i.test(testResults));
  assert.ok(/MASTERSTEP150_POSITIVE_STATE_COMPASS_OUTPUT_PRESERVATION/i.test(index));
  assert.ok(/MASTERSTEP150_POSITIVE_STATE_COMPASS_OUTPUT_PRESERVATION/i.test(docsIndex));
  assert.ok(/masterStep150PositiveStateCompassOutputPreservationTest/i.test(runner));
  assert.ok(/currentTarget\.current_manifest/i.test(runner) || /currentTarget\.current_manifest/i.test(runner));

  const providerScan = scanForProviderConnections();
  assert.strictEqual(providerScan.passed === true || providerScan.ok === true, true, 'provider scan should remain clean');

  const allFiles = walk(ROOT);
  const forbiddenGenerated = allFiles.filter(file => /proof[\/](logs|results)[\/].+|tests[\/]traces[\/].+/.test(file) && !file.endsWith('.gitkeep') && !file.endsWith('.tmp') && !/proof[\/]logs[\/].+\.log$/.test(file) && !/proof[\/]results[\/]MASTERSTEP[0-9]+_CURRENT_PROOF_MANIFEST\.json$/.test(file) && !/tests[\/]traces[\/]runtime_trace_log\.jsonl$/.test(file));
  assert.deepStrictEqual(forbiddenGenerated, [], 'packaged zip must exclude generated proof logs/results/traces; runner-created logs are ignored during in-tree proof execution');

  for (const rel of protectedRuntime) {
    assert.strictEqual(sha256(rel), before[rel], `protected runtime implementation should remain unchanged: ${rel}`);
  }

  console.log('Masterstep150 positive-state Compass output preservation passed');
})();
