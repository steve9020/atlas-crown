const assert = require('assert');
const { getAdaptiveTeachingTrajectory, assertAdaptiveTrajectoryAligned } = require('../runtime/teaching/AdaptiveTeachingCenterRealignment');
const { createLearningProposal, proposalIsIntegrationReady } = require('../runtime/teaching/TeachingCenterLearningProposalFlow');
const { classifyGoldenExample, rejectTemplateLock } = require('../runtime/teaching/GoldenCalibrationEvidenceGuard');
const { validateTeachingIntegrationRequest } = require('../runtime/teaching/TeachingCenterGovernedIntegrationGuard');

const trajectory = getAdaptiveTeachingTrajectory();
assert.strictEqual(trajectory.trajectory, 'governed_adaptive_ai_not_static_rules');
assert.strictEqual(trajectory.teaching_center_role, 'governed_learning_channel');
assert.strictEqual(trajectory.golden_examples_role, 'calibration_evidence_not_template');
assert.strictEqual(trajectory.adaptive_ai_allowed, true);
assert.strictEqual(trajectory.autonomous_authority_allowed, false);
assert.strictEqual(trajectory.silent_mutation_allowed, false);
assert.strictEqual(trajectory.governance_is_foundation_not_ceiling, true);

assert.strictEqual(assertAdaptiveTrajectoryAligned({}).ok, true);
assert.strictEqual(assertAdaptiveTrajectoryAligned({ static_only: true }).ok, false);
assert.strictEqual(assertAdaptiveTrajectoryAligned({ golden_examples_as_templates: true }).ok, false);
assert.strictEqual(assertAdaptiveTrajectoryAligned({ silent_learning: true }).ok, false);
assert.strictEqual(assertAdaptiveTrajectoryAligned({ governance_as_ceiling: true }).ok, false);

const proposal = createLearningProposal({
  prompt: 'When things pile up, I shut down and can’t think clearly.',
  response: 'robotic response',
  failure: 'voice too technical and missing reverse-flow uplift',
  correction: 'teach human voice and reverse-flow restoration',
  source: 'user_correction'
});
assert.strictEqual(proposal.status, 'PROPOSAL_ONLY');
assert.strictEqual(proposal.auto_integrate, false);
assert.strictEqual(proposal.silent_mutation, false);
assert.strictEqual(proposal.approval_required, true);
assert.ok(proposal.reusable_learning_target.includes('human_voice'));
assert.ok(proposal.reusable_learning_target.includes('reverse_flow_restoration'));
assert.strictEqual(proposalIsIntegrationReady(proposal, { explicit_human_approval: false, tests_passed: true, proof_logged: true, rollback_available: true }), false);
assert.strictEqual(proposalIsIntegrationReady(proposal, { explicit_human_approval: true, tests_passed: true, proof_logged: true, rollback_available: true }), true);

const golden = classifyGoldenExample({ id: 'pileup_overwhelm_source' });
assert.strictEqual(golden.role, 'CALIBRATION_EVIDENCE');
assert.strictEqual(golden.template_lock_allowed, false);
assert.strictEqual(golden.route_override_allowed, false);
assert.ok(golden.may_not_be_used_as.includes('fixed_template'));
assert.strictEqual(rejectTemplateLock({ use_as_template: true }).ok, false);
assert.strictEqual(rejectTemplateLock({ override_route: true }).ok, false);
assert.strictEqual(rejectTemplateLock({}).ok, true);

const blocked = validateTeachingIntegrationRequest({ human_approved: false, tests_passed: true, proof_logged: true, rollback_available: true });
assert.strictEqual(blocked.allowed, false);
assert.ok(blocked.blocked.includes('explicit_human_approval_required'));
const governanceMutation = validateTeachingIntegrationRequest({ human_approved: true, tests_passed: true, proof_logged: true, rollback_available: true, mutates_governance: true });
assert.strictEqual(governanceMutation.allowed, false);
assert.ok(governanceMutation.blocked.includes('teaching_center_cannot_mutate_governance'));
const allowed = validateTeachingIntegrationRequest({ human_approved: true, tests_passed: true, proof_logged: true, rollback_available: true });
assert.strictEqual(allowed.allowed, true);

console.log('masterStep49TeachingCenterAdaptiveLearningRealignmentTest PASSED');
