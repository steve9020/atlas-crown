# AXOL Randomized Compositional Fuzz Report

## Scope
Backend AXOL detection/composition only. No frontend, Crown authority, governance authority, or commercial-package changes.

## Campaign
Deterministic randomized compositional fuzzing across 20 structural AXOL families, 2–6 AXOL clauses per case, randomized named actors, mixed conjunction forms, and injected lexical-homonym neutral distractors.

## Baseline (before repair)
- Composition cases: 500
- Expected AXOL instances: 1,970
- AXOL detection: 1,947 / 1,970 (98.83%)
- Actor binding: 1,755 / 1,970 (89.09%)
- Fully correct cases: 397 / 500
- Neutral cases: 200
- Neutral false-positive cases: 0 / 200

The campaign exposed two systemic composition defects:
1. Rule-level exclusion patterns were applied to the entire input. A neutral homonym such as `control panel` or `boundary line` could suppress a legitimate `control` or `boundary` signal elsewhere in the same input.
2. Attribution segmentation could treat the sequencing token `then` as an actor after semicolon-delimited clauses.

## Repair
- Exclusion patterns now mask only their matched spans for the rule being evaluated instead of vetoing the entire rule across the full input.
- Masking preserves string length so evidence offsets remain aligned with the original input.
- Evidence attribution continues to use the unmasked source text.
- `then` is recognized as a clause sequencing token during actor extraction rather than as a candidate actor.

## Same-corpus rerun
- Composition cases: 500 / 500 fully correct
- Expected AXOL instances: 1,970 / 1,970 detected
- Actor bindings: 1,970 / 1,970 correct
- Neutral false-positive cases: 0 / 200

## Second deterministic blind seed
- Composition cases: 500 / 500 fully correct
- Expected AXOL instances: 2,057 / 2,057 detected
- Actor bindings: 2,057 / 2,057 correct
- Neutral false-positive cases: 0 / 200

## Regression closure
All AXOL test files passed, including semantic fuzz, hell fuzz, discrimination, collision, attribution, cross-binding, reference resolution, blind fuzz, neutral/adversarial controls, and randomized composition.

Canonical proof: 100 / 100 PASS.

## Claim boundary
This demonstrates closure of the tested randomized compositional corpus and regression contract. It does not establish exhaustive natural-language understanding or universal coreference resolution.
