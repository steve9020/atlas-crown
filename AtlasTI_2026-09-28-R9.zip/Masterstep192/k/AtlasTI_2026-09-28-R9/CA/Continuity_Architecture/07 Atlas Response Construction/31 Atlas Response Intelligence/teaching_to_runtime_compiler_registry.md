---
runtime_layer: atlas_response_intelligence
registry_type: teaching_to_runtime_compiler
purpose: Define how GPT-assisted teaching and pressure tests become executable runtime patterns rather than passive backend notes.
governed_by:
  - correction_learning_registry
  - runtime_execution_permissions_registry
---

# Teaching-to-Runtime Compiler Registry

Teaching material does not become live intelligence just because it exists. Atlas needs promoted lessons to compile into executable runtime fields.

## Compiler JSON

```json
{
  "compiled_runtime_fields": [
    "route_key",
    "match_terms",
    "match_groups",
    "scenario_object",
    "attached_meaning",
    "clarification_suppression",
    "voice_override",
    "proof_boundary",
    "reverse_flow_direction"
  ],
  "pressure_test_lesson_flow": [
    "raw pressure test",
    "failure pattern",
    "approved correction",
    "runtime pattern",
    "route scoring",
    "clarification suppression",
    "frontend translation"
  ],
  "runtime_rule": "A promoted lesson must either affect route scoring, scenario object extraction, clarification suppression, or voice rendering. If it affects none of those, it is documentation only."
}
```

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

