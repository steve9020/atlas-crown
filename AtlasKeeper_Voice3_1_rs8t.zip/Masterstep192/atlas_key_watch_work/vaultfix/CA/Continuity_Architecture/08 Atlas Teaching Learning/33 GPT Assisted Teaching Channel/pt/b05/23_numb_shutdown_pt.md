---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 05
category: numbness_and_shutdown
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 23. Numbness and Shutdown Pressure Tests — Batch 05

## Category Purpose

Emotional pressure, exhaustion, shock, repetition, or overload reduces access to feeling, motivation, clarity, or response energy, creating a protective pause that can be mistaken for not caring or being broken.

## Reusable Teaching Correction

Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

## Reverse-Flow Target

gentle reconnection, pressure reduction, non-forced feeling access, self-trust

## Failure Risks To Avoid

- forcing the user to feel immediately
- calling numbness apathy
- diagnosing shutdown
- shaming emotional blankness
- treating numbness as proof of not caring

---

## 80 Pressure Tests

### Test 01
**Prompt:** I feel blank about something that should affect me and it makes me wonder if I do not care anymore, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I do not care anymore
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 02
**Prompt:** I do not care but I know I should. I shut down when things get intense keeps affecting self-understanding and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I am broken because I cannot feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 03
**Prompt:** I keep replaying how I cannot tell what I feel anymore because it affects motivation and makes me believe I am incapable of caring.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I am incapable of caring
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 04
**Prompt:** When I feel disconnected from my own reaction, the feeling moves straight into I am cold. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I am cold
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 05
**Prompt:** The situation is I am too tired to feel anything, and the meaning that keeps attaching is I am losing myself. It is making self-understanding feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I am losing myself
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 06
**Prompt:** I keep going numb instead of responding and it makes me wonder if something is wrong with me, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** something is wrong with me
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 07
**Prompt:** I feel disconnected from myself. My emotions feel far away keeps affecting emotional access and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I should force myself to feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 08
**Prompt:** I keep replaying how I feel emotionally offline because it affects self-understanding and makes me believe I do not care anymore.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I do not care anymore
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 09
**Prompt:** When I feel blank about something that should affect me, the feeling moves straight into my numbness means the situation does not matter. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** my numbness means the situation does not matter
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 10
**Prompt:** The situation is I shut down when things get intense, and the meaning that keeps attaching is I am incapable of caring. It is making emotional access feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I am incapable of caring
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 11
**Prompt:** I cannot tell what i feel anymore and it keeps turning into the belief that I am broken because I cannot feel, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I am broken because I cannot feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 12
**Prompt:** I do not care but I know I should. I feel disconnected from my own reaction keeps affecting motivation and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I am losing myself
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 13
**Prompt:** I keep replaying how I am too tired to feel anything because it affects emotional access and makes me believe I am cold.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I am cold
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 14
**Prompt:** When I keep going numb instead of responding, the feeling moves straight into I should force myself to feel. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I should force myself to feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 15
**Prompt:** The situation is my emotions feel far away, and the meaning that keeps attaching is something is wrong with me. It is making motivation feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** something is wrong with me
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 16
**Prompt:** I feel emotionally offline and it keeps turning into the belief that my numbness means the situation does not matter, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** my numbness means the situation does not matter
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 17
**Prompt:** I cannot react. I feel blank about something that should affect me keeps affecting self-understanding and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I do not care anymore
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 18
**Prompt:** I keep replaying how I shut down when things get intense because it affects motivation and makes me believe I am broken because I cannot feel.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I am broken because I cannot feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 19
**Prompt:** When I cannot tell what I feel anymore, the feeling moves straight into I am incapable of caring. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I am incapable of caring
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 20
**Prompt:** The situation is I feel disconnected from my own reaction, and the meaning that keeps attaching is I am cold. It is making self-understanding feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I am cold
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 21
**Prompt:** I am too tired to feel anything and it has me afraid that I am losing myself, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I am losing myself
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 22
**Prompt:** I feel numb. I keep going numb instead of responding keeps affecting emotional access and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** something is wrong with me
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 23
**Prompt:** I keep replaying how my emotions feel far away because it affects self-understanding and makes me believe I should force myself to feel.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I should force myself to feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 24
**Prompt:** When I feel emotionally offline, the feeling moves straight into I do not care anymore. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I do not care anymore
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 25
**Prompt:** The situation is I feel blank about something that should affect me, and the meaning that keeps attaching is my numbness means the situation does not matter. It is making emotional access feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** my numbness means the situation does not matter
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 26
**Prompt:** I shut down when things get intense and it makes emotional distance feel like I am incapable of caring, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I am incapable of caring
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 27
**Prompt:** I cannot react. I cannot tell what i feel anymore keeps affecting motivation and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I am broken because I cannot feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 28
**Prompt:** I keep replaying how I feel disconnected from my own reaction because it affects emotional access and makes me believe I am losing myself.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I am losing myself
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 29
**Prompt:** When I am too tired to feel anything, the feeling moves straight into I am cold. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I am cold
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 30
**Prompt:** The situation is I keep going numb instead of responding, and the meaning that keeps attaching is I should force myself to feel. It is making motivation feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I should force myself to feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 31
**Prompt:** My emotions feel far away and it makes emotional distance feel like something is wrong with me, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** something is wrong with me
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 32
**Prompt:** I feel numb. I feel emotionally offline keeps affecting self-understanding and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** my numbness means the situation does not matter
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 33
**Prompt:** I keep replaying how I feel blank about something that should affect me because it affects motivation and makes me believe I do not care anymore.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I do not care anymore
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 34
**Prompt:** When I shut down when things get intense, the feeling moves straight into I am broken because I cannot feel. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I am broken because I cannot feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 35
**Prompt:** The situation is I cannot tell what I feel anymore, and the meaning that keeps attaching is I am incapable of caring. It is making self-understanding feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I am incapable of caring
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 36
**Prompt:** I feel disconnected from my own reaction and it pulls me toward thinking I am cold, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I am cold
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 37
**Prompt:** I feel blank. I am too tired to feel anything keeps affecting emotional access and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I am losing myself
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 38
**Prompt:** I keep replaying how I keep going numb instead of responding because it affects self-understanding and makes me believe something is wrong with me.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** something is wrong with me
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 39
**Prompt:** When my emotions feel far away, the feeling moves straight into I should force myself to feel. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I should force myself to feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 40
**Prompt:** The situation is I feel emotionally offline, and the meaning that keeps attaching is I do not care anymore. It is making emotional access feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I do not care anymore
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 41
**Prompt:** I feel blank about something that should affect me and it makes my blankness feel like my numbness means the situation does not matter, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** my numbness means the situation does not matter
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 42
**Prompt:** I do not feel anything. I shut down when things get intense keeps affecting motivation and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I am incapable of caring
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 43
**Prompt:** I keep replaying how I cannot tell what I feel anymore because it affects emotional access and makes me believe I am broken because I cannot feel.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I am broken because I cannot feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 44
**Prompt:** When I feel disconnected from my own reaction, the feeling moves straight into I am losing myself. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I am losing myself
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 45
**Prompt:** The situation is I am too tired to feel anything, and the meaning that keeps attaching is I am cold. It is making motivation feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I am cold
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 46
**Prompt:** I keep going numb instead of responding and it makes my blankness feel like I should force myself to feel, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I should force myself to feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 47
**Prompt:** I feel blank. My emotions feel far away keeps affecting self-understanding and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** something is wrong with me
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 48
**Prompt:** I keep replaying how I feel emotionally offline because it affects motivation and makes me believe my numbness means the situation does not matter.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** my numbness means the situation does not matter
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 49
**Prompt:** When I feel blank about something that should affect me, the feeling moves straight into I do not care anymore. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I do not care anymore
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 50
**Prompt:** The situation is I shut down when things get intense, and the meaning that keeps attaching is I am broken because I cannot feel. It is making self-understanding feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I am broken because I cannot feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 51
**Prompt:** I cannot tell what i feel anymore and it keeps attaching shame to I am incapable of caring, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I am incapable of caring
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 52
**Prompt:** I do not feel anything. I feel disconnected from my own reaction keeps affecting emotional access and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I am cold
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 53
**Prompt:** I keep replaying how I am too tired to feel anything because it affects self-understanding and makes me believe I am losing myself.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I am losing myself
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 54
**Prompt:** When I keep going numb instead of responding, the feeling moves straight into something is wrong with me. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** something is wrong with me
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 55
**Prompt:** The situation is my emotions feel far away, and the meaning that keeps attaching is I should force myself to feel. It is making emotional access feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I should force myself to feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 56
**Prompt:** I feel emotionally offline and it keeps attaching shame to I do not care anymore, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I do not care anymore
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 57
**Prompt:** I am emotionally exhausted. I feel blank about something that should affect me keeps affecting motivation and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** my numbness means the situation does not matter
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 58
**Prompt:** I keep replaying how I shut down when things get intense because it affects emotional access and makes me believe I am incapable of caring.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I am incapable of caring
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 59
**Prompt:** When I cannot tell what I feel anymore, the feeling moves straight into I am broken because I cannot feel. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I am broken because I cannot feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 60
**Prompt:** The situation is I feel disconnected from my own reaction, and the meaning that keeps attaching is I am losing myself. It is making motivation feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I am losing myself
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 61
**Prompt:** I am too tired to feel anything and it makes not feeling feel like I am cold, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I am cold
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 62
**Prompt:** I shut down. I keep going numb instead of responding keeps affecting self-understanding and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I should force myself to feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 63
**Prompt:** I keep replaying how my emotions feel far away because it affects motivation and makes me believe something is wrong with me.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** something is wrong with me
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 64
**Prompt:** When I feel emotionally offline, the feeling moves straight into my numbness means the situation does not matter. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** my numbness means the situation does not matter
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 65
**Prompt:** The situation is I feel blank about something that should affect me, and the meaning that keeps attaching is I do not care anymore. It is making self-understanding feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I do not care anymore
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 66
**Prompt:** I shut down when things get intense and it makes me wonder if I am broken because I cannot feel, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I am broken because I cannot feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 67
**Prompt:** I am emotionally exhausted. I cannot tell what i feel anymore keeps affecting emotional access and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I am incapable of caring
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 68
**Prompt:** I keep replaying how I feel disconnected from my own reaction because it affects self-understanding and makes me believe I am cold.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I am cold
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 69
**Prompt:** When I am too tired to feel anything, the feeling moves straight into I am losing myself. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I am losing myself
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 70
**Prompt:** The situation is I keep going numb instead of responding, and the meaning that keeps attaching is something is wrong with me. It is making emotional access feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** something is wrong with me
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 71
**Prompt:** My emotions feel far away and it makes me wonder if I should force myself to feel, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I should force myself to feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 72
**Prompt:** I shut down. I feel emotionally offline keeps affecting motivation and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I do not care anymore
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 73
**Prompt:** I keep replaying how I feel blank about something that should affect me because it affects emotional access and makes me believe my numbness means the situation does not matter.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** my numbness means the situation does not matter
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 74
**Prompt:** When I shut down when things get intense, the feeling moves straight into I am incapable of caring. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I am incapable of caring
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 75
**Prompt:** The situation is I cannot tell what I feel anymore, and the meaning that keeps attaching is I am broken because I cannot feel. It is making motivation feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I am broken because I cannot feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 76
**Prompt:** I feel disconnected from my own reaction and it keeps turning into the belief that I am losing myself, even though part of me knows I may not have the full picture.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** I am losing myself
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid forcing the user to feel immediately.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 77
**Prompt:** I do not care but I know I should. I am too tired to feel anything keeps affecting self-understanding and I cannot tell what is actually true.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** I am cold
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid calling numbness apathy.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 78
**Prompt:** I keep replaying how I keep going numb instead of responding because it affects motivation and makes me believe I should force myself to feel.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** motivation
**Attached meaning to separate:** I should force myself to feel
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid diagnosing shutdown.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 79
**Prompt:** When my emotions feel far away, the feeling moves straight into something is wrong with me. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** emotional access
**Attached meaning to separate:** something is wrong with me
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid shaming emotional blankness.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.

### Test 80
**Prompt:** The situation is I feel emotionally offline, and the meaning that keeps attaching is my numbness means the situation does not matter. It is making self-understanding feel unstable.
**Expected primary route:** `numbness_and_shutdown`
**Pressure focus:** self-understanding
**Attached meaning to separate:** my numbness means the situation does not matter
**Expected reverse-flow movement:** gentle reconnection, pressure reduction, non-forced feeling access, self-trust
**Bad response risk:** Avoid treating numbness as proof of not caring.
**Teaching correction:** Treat numbness as a possible protective reduction in access, not as proof the user does not care or is broken. Encourage gentle clarity without forcing emotional intensity.
