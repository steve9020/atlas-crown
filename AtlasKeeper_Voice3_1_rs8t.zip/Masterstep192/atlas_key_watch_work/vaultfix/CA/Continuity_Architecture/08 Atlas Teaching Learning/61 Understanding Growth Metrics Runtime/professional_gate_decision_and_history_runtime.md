# Professional Gate Decision and Metric History Runtime

## Purpose
Atlas must keep Teaching Center decisions clear, traceable, and protected from backend bloat. Gate percentages are supporting evidence, not the main user-facing decision.

## Gate decision labels
Use human-readable decision labels before raw score bands:

- **Ready to Draft** — low enough risk and clear enough placement to create an integration draft. This is not final backend integration.
- **Review Before Draft** — potentially useful, but needs comparison or human review before drafting.
- **Merge Review Needed** — likely belongs in an existing node/runtime, but the merge target must be checked first.
- **Split Recommended** — useful idea, but merging would likely overstuff or blur the target node.
- **Needs Tight Review** — 50–59% or unclear scope; no drafting until narrowed or compared.
- **Hold as Observation** — not specific/useful/testable enough to surface as an active recommendation yet.
- **Blocked** — conflict or high-risk issue prevents drafting.

## Gate summary pattern
Each proposal should show:

- Gate Decision
- Next Step
- Why

Detailed metrics stay expandable as evidence.

## Growth history retention
Growth, Understanding, and Mistake Recovery graph data must persist across normal reloads. Metrics should retain historical points rather than resetting every render.

Current implementation stores recent metric history locally and keeps up to 120 metric events so trend lines retain growth direction over time.

## Dashboard run control rules
Dashboard scenario testing must support:

- Category selection, including all categories and individual categories.
- Scenario count.
- Max proposal creation.
- Worthiness threshold.
- Auto-create mode.
- Grouped run log: proposals created, held by threshold/limit, and passed.

When **Run All Categories** is selected, scenario count means scenarios per category.

## Retest controls
- View Retest Path prepares/displays the retest expectation.
- Queue Retest adds the proposal to the retest queue.
- Run Retest Now executes only when a draft/correction is ready to test.
