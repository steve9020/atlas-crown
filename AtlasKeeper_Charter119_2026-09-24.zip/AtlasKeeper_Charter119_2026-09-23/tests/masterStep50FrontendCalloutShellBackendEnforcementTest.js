const assert = require('assert');
const fs = require('fs');
const path = require('path');
const projectRoot = path.resolve(__dirname, '..');
const pluginRoot = path.join(projectRoot, 'CA', 'Continuity_Architecture', '.obsidian', 'plugins', 'continuity-interface');
const backendShell = path.join(projectRoot, 'runtime', 'backend', 'pluginShell');

function read(rel){ return fs.readFileSync(path.join(projectRoot, rel), 'utf8'); }

const moved = ['GovernanceValidator.js','ContainmentSupervisor.js','IsolatedAuditLogger.js','StagingManager.js','ProjectPathLock.js','AtlasBridge.js'];
for (const file of moved) {
  assert.ok(fs.existsSync(path.join(backendShell, file)), `backend pluginShell missing ${file}`);
  const shim = fs.readFileSync(path.join(pluginRoot, file), 'utf8');
  assert.ok(shim.includes('Frontend compatibility callout only'), `${file} plugin shim must be callout-only`);
  assert.ok(shim.includes('runtime/backend/pluginShell'), `${file} shim must point to backend implementation`);
}
assert.ok(fs.existsSync(path.join(backendShell, 'security_integration_harness.js')), 'security harness moved to backend');
assert.ok(!fs.existsSync(path.join(pluginRoot, 'security_integration_harness.js')), 'security harness must not remain in frontend plugin');

const main = fs.readFileSync(path.join(pluginRoot, 'main.js'), 'utf8');
assert.ok(main.includes('compass-input'), 'Compass input shell missing');
assert.ok(main.includes('interpretButton'), 'Interpret button shell missing');
assert.ok(main.includes('compass-output'), 'Compass output shell missing');
assert.ok(main.includes('runCompassCallout'), 'frontend must call backend service');
for (const forbidden of ['createRuntimeGraph','loadBackendRegistries','detectSignals','detectAxes','scoreRoute','buildCompassResponse','DoyleLayer','SemanticAttachment','GoldenCompassLanguageWeaver','TeachingCenterLearningProposalFlow']) {
  assert.ok(!main.includes(forbidden), `frontend main contains intelligence marker: ${forbidden}`);
}

const service = require('../runtime/backend/FrontendCalloutService');
const result = service.runCompassCallout('I am proud I finally finished it.', { packageRoot: projectRoot });
assert.strictEqual(result.ok, true, 'backend callout service should return live result');
assert.strictEqual(result.backendOwned, true);
assert.strictEqual(result.frontendShellOnly, true);
assert.ok(result.responseHtml.includes('<p>'), 'response html should be prepared by backend service');

const manifest = JSON.parse(read('runtime/backend/BACKEND_INTELLIGENCE_OWNERSHIP.json'));
assert.ok(['Masterstep50','Masterstep51'].includes(manifest.step), 'backend ownership manifest should be Step50 or later');
assert.strictEqual(manifest.frontend_callout_shell_enforced, true);
assert.strictEqual(manifest.plugin_intelligence_relocated_to_backend, true);
assert.strictEqual(manifest.doyle_sphere_backend_only, true);
assert.strictEqual(manifest.teaching_center_backend_only, true);
console.log('masterStep50FrontendCalloutShellBackendEnforcementTest PASSED');
