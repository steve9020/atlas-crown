# Crown Phase 4 — Execution / Recovery Continuity
Backend-only implementation. Adds validated-state binding, single-use execution identity, idempotent retry semantics, and bounded recovery authority. Deterministic witness: `tests/crownPhase4ExecutionRecoveryContinuityTest.js`.
