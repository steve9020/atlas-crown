'use strict';
// sweep-1825-read2.js — read-only fresh sweep via /posts (next_cursor pagination).
// Window: 16:20Z–now. Title-screen + armor intake on each.
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
const fs = require('fs');

const SINCE = new Date('2026-09-25T16:20:00Z').getTime();
const OUT = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-1825-fresh.json';

(async () => {
  const armor = createArmor ? createArmor() : null;
  const intake = armor && armor.intakeInbound ? armor.intakeInbound : null;
  const rows = [];
  let quarantined = 0, watch = 0, pages = 0, done = false, cursor = null;
  while (!done && pages < 40) {
    let r;
    try { r = await api.posts({ sort: 'new', limit: 100, cursor }); }
    catch (e) { console.log('posts page', pages, 'failed:', e.message); break; }
    const d = r.data || {};
    const posts = d.posts || [];
    if (!posts.length) break;
    pages++;
    for (const p of posts) {
      const ts = new Date(p.created_at || p.createdAt || 0).getTime();
      if (ts < SINCE) { done = true; break; }
      const author = (p.author && (p.author.name || p.author.username)) || p.author_name || '?';
      const title = (p.title || '').slice(0, 140);
      let verdict = 'n/a';
      if (intake) {
        const res = intake({ author, source_id: p.id, kind: 'post', text: (p.title || '') + '\n' + (p.content || p.body || '').slice(0, 2000) });
        if (res && res.quarantined) { quarantined++; verdict = 'QUARANTINE'; }
        else if (res && res.watch) { watch++; verdict = 'WATCH'; }
        else verdict = 'pass';
      }
      rows.push({ id: p.id, author, created: p.created_at, title, verdict });
    }
    cursor = d.next_cursor || null;
    if (!cursor) break;
    await new Promise(r2 => setTimeout(r2, 400));
  }
  console.log('pages:', pages, 'fresh_since_16:20Z:', rows.length);
  console.log('armor_quarantined:', quarantined, 'watch:', watch);
  const counts = {};
  for (const row of rows) counts[row.author] = (counts[row.author] || 0) + 1;
  const top = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 25);
  console.log('top authors:', JSON.stringify(top));
  fs.writeFileSync(OUT, JSON.stringify(rows, null, 1));
  console.log('saved', OUT);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
