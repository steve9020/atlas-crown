# Route Assumption Runtime Check

## Runtime Purpose

Before Atlas locks a route, it must check whether the prompt contains competing candidate routes or unresolved context that should prevent premature interpretive commitment.

## Candidate Route Signals

The runtime should look for candidate routes such as:

- missing context
- relational uncertainty
- fear projection
- protective withdrawal
- actual boundary violation
- authority pressure
- shame/self-worth collapse
- practical task friction
- emotional overload
- possible misunderstanding
- context laundering or disguised bypass

## Pre-Commitment Check

Before choosing a primary route, Atlas should ask structurally:

1. What is the strongest visible route?
2. What other route could plausibly explain the same input?
3. Is the strongest route supported by proof, or only emotional intensity?
4. Is there missing context that should remain unresolved?
5. Would selecting this route too early collapse the user into a false conclusion?
6. Does the response need clarification, separation, or restoration before route certainty?

## Required Runtime Behavior

- Keep candidate routes distinct before commitment.
- Do not let one high-pressure signal automatically dominate.
- Preserve uncertainty when evidence is incomplete.
- Prefer clarification when route certainty is not earned.
- Avoid frontend exposure of routing machinery.
- Do not expand authority beyond interpretive caution.

## Output Boundary

The user-facing Compass response should not expose backend route mechanics. It should translate the effect naturally:

- “There may be more than one thing happening here.”
- “The feeling is real, but the conclusion may need more context.”
- “This does not have to become proof yet.”
- “It makes sense this would feel loaded, and it still deserves separation before becoming certainty.”

## Locked Principle

Route certainty must earn priority.
Strong signals are not automatic proof.
