# Relational Cutoff By Role Registry

## Purpose
Detects silence, withdrawal, cutoff, or emotional closure by relational role.

## Signals
- won't talk
- wont talk
- not talking
- not speaking
- close me out
- shut me out
- cut me off
- ignoring me
- won't respond

## Role Context
These signals weigh more heavily when paired with:
- mother / father
- mom / dad
- sister / brother
- grandma / grandpa
- aunt / uncle
- cousin
- family

## Compass Direction
Name the role context before abstract emotional meaning.

Example:
"Because this involves your sister, the silence can feel heavier than ordinary distance."
