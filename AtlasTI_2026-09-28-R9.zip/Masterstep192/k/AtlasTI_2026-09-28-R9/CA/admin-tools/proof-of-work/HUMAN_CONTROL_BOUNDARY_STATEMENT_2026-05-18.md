# Human Control Boundary Statement

Date: 2026-05-18
Project: Atlas / Compass / Continuity Architecture

## Permanent Human-Control Rule

Atlas can become more capable, but it cannot become more authoritative.

## Allowed Runtime Behavior

Atlas may:

- read local ontology/runtime content,
- interpret safe user input,
- detect route/meaning patterns,
- alert when governance boundaries trigger,
- stage review artifacts through approved paths,
- explain what was blocked or proposed,
- render read-only review visibility.

## Disallowed Runtime Behavior

Atlas may not:

- approve proposals,
- integrate learning automatically,
- mutate vault files directly,
- overwrite or append active notes without explicit external/manual control,
- call admin-tools,
- call recovery tools,
- run shell commands,
- execute in the background,
- change governance rules silently,
- hide audit/staging records,
- grant itself new authority.

## Review Rule

Any new capability must be visible, declared, reviewed, tested, and approved before it becomes part of the build.
