const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const RESPONSE_QUALITY_REGISTRY_PATH = "CA/Continuity_Architecture/07 Atlas Response Construction/40 Obsidian Runtime Response Registry/response_quality_registry.md";

let cachedQualityRegistry = null;

function getQualityRegistry() {
  if (!cachedQualityRegistry) {
    cachedQualityRegistry = readJsonRegistry(RESPONSE_QUALITY_REGISTRY_PATH);
  }
  return cachedQualityRegistry;
}

function getStructureCount(response) {
  const paragraphSections = response
    .split("\n\n")
    .map(section => section.trim())
    .filter(Boolean);

  const lineSections = response
    .split(/\n+/)
    .map(section => section.trim())
    .filter(Boolean);

  return Math.max(paragraphSections.length, lineSections.length);
}

function regexAnyMatches(response, patterns, flags) {
  if (!Array.isArray(patterns) || patterns.length === 0) {
    return true;
  }

  return patterns.some(pattern => {
    try {
      return new RegExp(pattern, flags || "").test(response);
    } catch (error) {
      return false;
    }
  });
}

function rulePasses(rule, response) {
  if (!rule || !rule.type) {
    return true;
  }

  if (rule.type === "minimum_structure_count") {
    return getStructureCount(response) >= Number(rule.minimum || 0);
  }

  if (rule.type === "minimum_character_length") {
    return response.length >= Number(rule.minimum || 0);
  }

  if (rule.type === "regex_any") {
    return regexAnyMatches(response, rule.patterns, rule.flags);
  }

  return true;
}

function checkResponseQuality(response) {
  const issues = [];

  if (!response || typeof response !== "string") {
    return {
      passed: false,
      issues: ["response_missing"]
    };
  }

  const registry = getQualityRegistry();
  const rules = Array.isArray(registry.rules) ? registry.rules : [];

  for (const rule of rules) {
    if (!rulePasses(rule, response)) {
      issues.push(rule.issue || `quality_rule_failed:${rule.id || "unknown"}`);
    }
  }

  return {
    passed: issues.length === 0,
    issues: issues
  };
}

module.exports = { checkResponseQuality };
