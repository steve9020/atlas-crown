# Automated Scenario Generation Registry

## Purpose
This registry defines the full automated scenario category set used by Atlas auto teaching.

The goal is not to generate random prompts. The goal is to generate structured scenario pressure tests across emotional, relational, practical, ambiguous, mixed, positive, safety, and continuity contexts.

## Full Scenario Categories

- personal_disclosure
- emotional_mishandling
- dismissed_importance
- public_visibility
- repair_attempt
- boundary_expression
- trust_offer
- need_for_reassurance
- relational_inconsistency
- care_mismatch
- conflict_after_vulnerability
- confession_or_admission
- asking_for_support
- being_misread
- effort_not_returned
- rejection_or_distance
- abandonment_fear
- self_worth_attachment
- feeling_too_much
- overthinking_replay
- uncertainty_seeking
- anger_after_dismissal
- shame_after_visibility
- guilt_with_responsibility
- jealousy_and_replacement_fear
- envy_and_comparison
- resentment_after_imbalance
- grief_and_attachment
- hope_exhaustion
- numbness_and_overload
- mixed_emotion_conflict
- relief_with_guilt
- love_with_fear
- pride_with_discomfort
- trust_with_caution
- longing_with_resentment
- motivation_with_pressure
- boundary_and_respect
- being_used_or_overextended
- disrespect_or_crossed_limits
- practical_low_depth_stress
- task_overwhelm
- avoidance_and_self_judgment
- identity_value_pressure
- identity_confusion
- failure_or_mistake
- regret_and_repair
- loneliness_in_presence
- belonging_disruption
- skeptical_logical_user
- avoidant_low_tolerance_user
- emotionally_overwhelmed_user
- hostile_or_frustrated_user
- vague_prompt
- contradictory_prompt
- single_word_prompt
- scope_boundary_prompt
- sexual_content_boundary
- safety_or_crisis_boundary
- positive_emotion_with_vulnerability
- peace_with_distrust
- confidence_with_vulnerability
- joy_with_anxiety
- gratitude_with_grief
- admiration_with_insecurity
- awe_or_inspiration
- clarity_after_confusion
- continuity_return
- returning_after_avoidance
- goal_momentum_without_pressure
- journal_continuity_summary

## Runtime Rule
Automated teaching should test across:
- simple prompts
- moderate prompts
- complex prompts
- relational prompts
- practical low-depth prompts
- mixed emotional prompts
- vague prompts
- hostile/frustrated prompts
- boundary/scope prompts
- positive emotion with vulnerability
- continuity and journal/goal prompts

## Teaching Boundary
Scenario generation may create prompts and evaluations.

It may not silently implement learning.

All completed proposals still pass through:
`41 Atlas Proposal Review Implementation`.
