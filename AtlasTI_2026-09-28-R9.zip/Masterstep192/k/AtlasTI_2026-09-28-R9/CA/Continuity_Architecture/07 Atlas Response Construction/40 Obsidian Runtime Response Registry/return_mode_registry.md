# Return Mode Registry

Purpose: stores Atlas/Compass return-mode selection rules in the Obsidian backend so runtime code remains a generic reader/evaluator instead of owning Compass-specific return priority branches.

Boundary: this registry may declare ordered return-selection rules and a fallback return mode. It may not bypass governance, diagnose, mutate backend files, create authority, or override response quality checks.

Runtime use: `ReturnEngine.js` reads this JSON registry and selects the first matching return rule in priority order. The selected return mode is then passed forward to route scoring, route explanation, variation selection, response construction, quality verification, governance validation, trace logging, and output delivery.

```json
{
  "version": "OBSIDIAN_RETURN_REGISTRY_STAGE3",
  "selectionMode": "first_match_priority_order",
  "rules": [
    {
      "id": "worth_return",
      "priority": 10,
      "when": {
        "axesAll": ["worth"]
      },
      "returnMode": "worth_return"
    },
    {
      "id": "identity_return",
      "priority": 20,
      "when": {
        "axesAll": ["identity"]
      },
      "returnMode": "identity_return"
    },
    {
      "id": "belonging_return",
      "priority": 30,
      "when": {
        "axesAll": ["belonging"]
      },
      "returnMode": "belonging_return"
    },
    {
      "id": "emotional_validity_return",
      "priority": 40,
      "when": {
        "axesAll": ["emotional_validity"]
      },
      "returnMode": "emotional_validity_return"
    },
    {
      "id": "perfection_return",
      "priority": 50,
      "when": {
        "axesAll": ["perfection"]
      },
      "returnMode": "perfection_return"
    },
    {
      "id": "detachment_return",
      "priority": 60,
      "when": {
        "axesAll": ["detachment"]
      },
      "returnMode": "detachment_return"
    },
    {
      "id": "permanence_return",
      "priority": 70,
      "when": {
        "axesAll": ["permanence"]
      },
      "returnMode": "permanence_return"
    }
  ],
  "fallback": {
    "returnMode": "neutral_return"
  }
}
```
