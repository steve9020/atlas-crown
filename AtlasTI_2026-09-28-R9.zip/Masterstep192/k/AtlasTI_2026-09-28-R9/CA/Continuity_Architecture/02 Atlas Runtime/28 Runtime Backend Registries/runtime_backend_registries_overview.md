---
title: Runtime Backend Registries Overview
runtime_layer: backend_registry
priority: highest
status: active
phase: runtime_backend_registry_foundation
governed_by:
  - atlas_runtime_operational_construction_lock
  - governance_enforcement_flow
  - depth_calibration_governance
outputs:
  - runtime_signal_registry
  - depth_routing_registry
  - node_bucket_classification_registry
  - runtime_weighting_registry
  - runtime_link_resolution_registry
  - governance_enforcement_registry
  - response_behavior_registry
  - runtime_registry_flow
---

# Runtime Backend Registries Overview

## Purpose

This folder exists to keep backend runtime intelligence inside the vault instead of inside the plugin.

The plugin may read, parse, interpret, display, and execute runtime instructions, but it must not become the permanent source of meaning, routing, governance, weighting, response behavior, or semantic authority.

The vault remains the backend source of truth.

The plugin remains the interface and runtime reader.

## Core Separation Rule

Vault = Atlas intelligence.

Plugin = interface, parser, graph builder, renderer, and runtime reader.

The plugin may temporarily contain bridge logic during development, but that logic should eventually be represented in backend markdown registries when it affects:

- signal detection
- depth routing
- node classification
- runtime weighting
- alias resolution
- governance enforcement
- response behavior
- frontend interpretation rules

## Why This Layer Exists

The runtime graph is now loading successfully.

The plugin can currently read:

- runtime nodes
- semantic domains
- markdown links
- frontmatter
- runtime layers
- priorities
- governance links
- activation buckets
- unresolved links

However, some runtime behavior still exists directly in `main.js`.

This folder moves that behavior into explicit backend registries so the architecture remains clean.

## Backend Registries

### Runtime Signal Registry

Defines which input signals activate which runtime domains.

Examples:

- rejection
- trust
- conflict
- grief
- comparison
- ridicule
- responsibility
- practical/logistical pressure

### Depth Routing Registry

Defines how input routes into:

- light response
- moderate response
- deep response

This prevents over-analysis for practical issues and prevents under-response for emotionally fused or recursive issues.

### Node Bucket Classification Registry

Defines how runtime nodes are classified into operational buckets:

- depth
- governance
- meaning separation
- emotional pressure
- recursive
- continuity
- translation
- general

### Runtime Weighting Registry

Defines how node priority, runtime layer authority, domain relevance, and input-specific activation affect routing weight.

Weights should support runtime clarity without allowing one command layer to dominate every response automatically.

### Runtime Link Resolution Registry

Defines alias mappings, naming continuity rules, title matching rules, and unresolved-link handling.

This exists so link resolution remains a backend concern instead of becoming hidden plugin intelligence.

### Governance Enforcement Registry

Defines anti-drift constraints and runtime suppression rules.

This includes protection against:

- clinical framing
- diagnostic framing
- authority posture
- shame mechanics
- productivity obsession
- gamification
- streak/failure logic
- over-analysis
- false certainty
- emotional dependency loops

### Response Behavior Registry

Defines Compass output behavior.

The response should move through:

1. scenario/context recognition
2. emotional effect recognition
3. underlying mechanism
4. separation between event and internalized meaning
5. objective clarifying perspective
6. restored continuity

The response should feel human, grounded, and clarifying rather than structural, clinical, or mechanical.

### Runtime Registry Flow

Defines how all backend registries connect and how the plugin should eventually read them in order.

## Operational Rule

No new backend logic should be permanently added to the plugin unless there is no vault-readable equivalent yet.

When plugin logic begins shaping meaning, routing, interpretation, governance, or response behavior, the matching backend registry should be created or updated.

## Current Runtime Status

- Runtime graph loading: active
- Node registration: active
- Relationship extraction: active
- Runtime activation routing: active
- Backend registry migration: active

## Related Runtime Links

- [[runtime_signal_registry]]
- [[depth_routing_registry]]
- [[node_bucket_classification_registry]]
- [[runtime_weighting_registry]]
- [[runtime_link_resolution_registry]]
- [[governance_enforcement_registry]]
- [[response_behavior_registry]]
- [[runtime_registry_flow]]
- [[atlas_runtime_operational_construction_lock]]
- [[governance_enforcement_flow|governance_enforcement_flow]]