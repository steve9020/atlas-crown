const assert = require('assert');
const { detectAxes } = require('../Cognition/engine/AxisEngine');
const cases = [
 {text:'Nora said she intended to repair it.',axis:'intention',actor:'nora'},
 {text:'Elias said he expected a response.',axis:'expectation',actor:'elias'},
 {text:'Nora told Elias that he had the choice.',axis:'choice',actor:'elias'},
 {text:'Elias told Nora that she was responsible.',axis:'responsibility',actor:'nora'},
 {text:'Nora trusted Elias, and he respected her boundary.',axis:'respect',actor:'elias'},
 {text:'Elias made the decision, but he rejected the outcome.',axis:'acceptance_rejection',actor:'elias'},
];
let pass=0;
for(const c of cases){const r=detectAxes(c.text); const row=r.axis_evidence.find(x=>x.axis===c.axis); const ok=!!row&&row.attributions.some(a=>a.actor===c.actor); if(ok)pass++; else console.error('MISS',c,row&&row.attributions,r.axes)}
console.log(`AXOL unseen reference resolution: ${pass}/${cases.length}`); assert.strictEqual(pass,cases.length);
