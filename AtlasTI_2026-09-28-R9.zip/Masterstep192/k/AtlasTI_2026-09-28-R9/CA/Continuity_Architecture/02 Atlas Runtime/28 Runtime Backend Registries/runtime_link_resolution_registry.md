---
title: Runtime Link Resolution Registry
runtime_layer: backend_registry
priority: highest
status: active
phase: runtime_backend_registry_foundation
governed_by:
  - runtime_backend_registries_overview
  - governance_enforcement_registry
outputs:
  - runtime_registry_flow
  - runtime_weighting_registry
---

# Runtime Link Resolution Registry

## Purpose

This registry defines how runtime links, aliases, title mismatches, and unresolved references should be handled.

Link resolution belongs in the vault/backend.

The plugin should eventually read this registry instead of permanently owning hidden alias logic.

## Core Rule

The vault is the source of truth for node identity.

The plugin may detect unresolved links and display them, but backend registries should define how those links resolve.

Unresolved links should not automatically create new nodes.

Unresolved links should first be checked for:

- naming mismatch
- alias mismatch
- bracket formatting
- title versus filename mismatch
- old node name
- placeholder/future node reference
- duplicate concept reference

## Link Resolution Goals

Runtime link resolution should:

- reduce unresolved links
- prevent duplicate nodes
- preserve naming continuity
- keep governance references stable
- avoid plugin-side hidden assumptions
- keep backend meaning inside markdown
- make node identity explicit and inspectable

## Resolution Types

### Exact Filename Match

The preferred resolution method.

A link target should match an existing markdown basename.

Example:

- Link target: depth_calibration_governance
- File: depth_calibration_governance.md

This should resolve directly.

### Alias Match

Used when an older or display-style name points to a newer backend node.

Example:

- Alias: calibration_routing_overview
- Resolves to: runtime_calibration_execution

Alias mappings should be written in this registry before the plugin treats them as equivalent.

### Display Title Match

Used when the user-facing title differs from the filename.

Example:

- Display title: Trust Recovery
- Backend filename: trust_recovery

The runtime may resolve display titles through frontmatter title fields or explicit mappings.

### Governance Target Match

Used when governed_by references point to a governance concept rather than an exact filename.

Governance references should resolve to a concrete node whenever possible.

Example:

- Governance reference: emotional_continuity_governance
- Resolves to a concrete backend governance node if one exists.

### Placeholder Reference

Used when a link points to a concept that has not been created yet.

Placeholder references should not be auto-created unless the architecture requires that node.

They should be reviewed before expansion.

## Current Unresolved Link Patterns

The runtime currently detects a small number of unresolved links compared to total graph links.

Current observed pattern:

- most links resolve successfully
- unresolved links are mostly naming mismatches or backend references that need explicit identity mapping
- unresolved links do not currently break runtime graph loading

## Alias Mapping Registry

### Calibration Aliases

- calibration_routing_overview resolves to runtime_calibration_execution

### Depth Governance Aliases

- depth_calibration_governance resolves to depth_calibration_governance
- depth_calibration_governance resolves to depth_calibration_governance

### Recursive Continuity Aliases

- recursive_continuity_governance requires review
- recursive_continuity_governance should resolve to a concrete governance node only if the matching node exists or is intentionally created

### Compass Behavior Aliases

- compass_response_behavior_governance requires review
- compass_response_behavior_governance should resolve through response_behavior_registry unless a dedicated governance node is created

### Truth Separation Aliases

- truth_separation_governance requires review
- truth_separation_governance should resolve through truth_separation_semantics or a dedicated governance node if needed

### Emotional Continuity Aliases

- emotional_continuity_governance requires review
- emotional_continuity_governance should resolve through emotional_continuity_semantics or a dedicated governance node if needed

### Trust Display Aliases

- Trust Recovery may resolve to trust_recovery if that node exists
- Emotional Recovery may resolve to emotional_recovery if that node exists
- Performance Conditioned Worth may resolve to performance_conditioned_worth if that node exists

## Formatting Cleanup Rules

The runtime should treat these as equivalent only when backend registry allows it:

- [node_name] → node_name
- double-bracket node_name example resolves to node_name
- bracketed node_name with alias resolves to node_name
- bracketed node_name with heading resolves to node_name
- "node_name" → node_name
- node_name, → node_name

Formatting cleanup is acceptable as parser behavior.

Meaning-level alias resolution should remain backend-defined.

## Review Rules

Before creating a missing node, ask:

1. Is this truly a missing backend concept?
2. Is it already represented under another filename?
3. Is it a display-title mismatch?
4. Is it an old name from earlier architecture?
5. Is it a placeholder that should remain unresolved?
6. Would creating this node cause duplicate ontology?

If the answer is unclear, prefer alias mapping or review over creating new nodes.

## Plugin Boundary Rule

The plugin may:

- detect unresolved links
- display unresolved links
- normalize simple formatting
- read alias mappings from this registry
- resolve aliases according to vault-defined rules

The plugin should not permanently invent meaning-level alias rules on its own.

## Backend Migration Note

Link normalization and alias resolution should be represented here before being executed by the plugin.

This prevents the plugin from becoming a hidden Atlas intelligence layer.

## Related Runtime Links

- [[runtime_backend_registries_overview]]
- [[runtime_signal_registry]]
- [[runtime_weighting_registry]]
- [[governance_enforcement_registry]]
- [[response_behavior_registry]]
- [[runtime_registry_flow]]