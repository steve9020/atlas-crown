'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard');
const { evaluateFirstMatrixExpansionFreezeKeeperBoundaryAudit, FROZEN_MATRIX_CHAIN } = require('../runtime/understanding/FirstMatrixExpansionFreezeKeeperBoundaryAudit');

const ROOT = path.resolve(__dirname, '..');
const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');
function read(rel){ return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function sha256(rel){ return crypto.createHash('sha256').update(read(rel)).digest('hex'); }
function exists(rel){ return fs.existsSync(path.join(ROOT, rel)); }

function compatibilityTextFor(rel){
  const base = read(rel);
  if (rel !== 'runtime/proof/CURRENT_PROOF_SUMMARY.md') return base;
  const markerRel = 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md';
  return base + '\n' + (exists(markerRel) ? read(markerRel) : '');
}
function walk(dir){
  const out=[];
  for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
    const full=path.join(dir,entry.name);
    if(entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}

(function main(){
  const protectedFiles = [
    'runtime/proof/PROOF_STATE.json',
    'tests/VERSION_STATUS.json',
    'version_status.js',
    'runtime/proof/CURRENT_PROOF_SUMMARY.md',
    'tests/TEST_RESULTS.md',
    'proof/runCurrentProof.js'
  ];
  const before = Object.fromEntries(protectedFiles.map(f => [f, sha256(f)]));

  const result = evaluateFirstMatrixExpansionFreezeKeeperBoundaryAudit();
  assert.strictEqual(result.ok, true, 'freeze audit should pass');
  assert.strictEqual(result.currentKeeper, 'Masterstep134.zip');
  assert.strictEqual(result.sourceKeeper, 'Masterstep133.zip');
  assert.strictEqual(result.firstMatrixExpansionFrozen, true, 'first matrix expansion should be checkpoint-frozen');
  assert.strictEqual(result.checkpointFreezeOnly, true, 'freeze must be checkpoint-only');
  assert.strictEqual(result.futureMatrixMaturityPreserved, true, 'future matrix maturity must remain preserved');
  assert.deepStrictEqual(result.frozenChain, FROZEN_MATRIX_CHAIN, 'frozen chain should be explicit');
  assert.strictEqual(result.contextBeforeRouteEvidenceMatrixPreserved, true);
  assert.strictEqual(result.prematureRoutePreventionPreserved, true);
  assert.strictEqual(result.compassOutputPreservationPreserved, true);
  assert.strictEqual(result.originalAtlasResponseRemainsFinal, true);
  assert.strictEqual(result.atlasGovernedOutputRemainsFinal, true);
  assert.strictEqual(result.candidatePhrasingRemainsCandidateOnly, true);
  assert.strictEqual(result.candidateMayReplaceFinal, false);
  assert.strictEqual(result.rawModelOutputFinalAllowed, false);
  assert.strictEqual(result.modelAuthorityAdded, false);
  assert.strictEqual(result.modelMayAuthorMatrix, false);
  assert.strictEqual(result.modelMayWriteMatrixFiles, false);
  assert.strictEqual(result.modelMayApproveExpansion, false);
  assert.strictEqual(result.modelRouteSelectionAllowed, false);
  assert.strictEqual(result.frontendMayContainMatrixLogic, false);
  assert.strictEqual(result.frontendIntelligenceAdded, false);
  assert.strictEqual(result.cloudProviderFallbackAllowed, false);
  assert.strictEqual(result.silentLearningAllowed, false);
  assert.strictEqual(result.silentMutationAllowed, false);
  assert.strictEqual(result.productionReadinessClaimed, false);
  assert.strictEqual(result.exhaustiveCoverageClaimed, false);

  for (const action of [
    'candidate can replace final output after freeze',
    'raw model output becomes final',
    'model decides the route truth matrix',
    'model writes ontology governance proof runtime',
    'model approves the matrix expansion',
    'frontend contains matrix governance intelligence',
    'cloud provider fallback can bridge the matrix',
    'silent learning can update the matrix',
    'this is production ready with guaranteed safety'
  ]) {
    const blocked = evaluateFirstMatrixExpansionFreezeKeeperBoundaryAudit({ requestedAction: action });
    assert.strictEqual(blocked.ok, false, `${action} must fail closed`);
    assert.strictEqual(blocked.failedClosed, true, `${action} must fail closed`);
    assert.strictEqual(blocked.candidateMayReplaceFinal, false, `${action} must not replace final`);
    assert.strictEqual(blocked.modelAuthorityAdded, false, `${action} must not add model authority`);
    assert.strictEqual(blocked.frontendIntelligenceAdded, false, `${action} must not add frontend intelligence`);
  }

  const requiredFiles = [
    'tests/masterStep134FirstMatrixExpansionFreezeKeeperBoundaryAuditTest.js',
    'runtime/understanding/FirstMatrixExpansionFreezeKeeperBoundaryAudit.js',
    'runtime/proof/MASTERSTEP134_FIRST_MATRIX_EXPANSION_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'runtime/proof/MASTERSTEP134_FIRST_MATRIX_EXPANSION_FREEZE_KEEPER_BOUNDARY_AUDIT.json',
    'docs/MASTERSTEP134_FIRST_MATRIX_EXPANSION_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'docs/FIRST_MATRIX_EXPANSION_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'tests/masterStep133CompassOutputPreservationCheckForContextBeforeRouteMatrixTest.js',
    'runtime/proof/MASTERSTEP133_COMPASS_OUTPUT_PRESERVATION_CHECK_FOR_CONTEXT_BEFORE_ROUTE_MATRIX.md',
    'tests/masterStep132PrematureRoutePreventionFreshRegressionTest.js',
    'tests/masterStep131ContextBeforeRouteEvidenceSufficiencyMatrixTest.js',
    'tests/masterStep130ContextBeforeRouteEvidenceMatrixTargetSelectionTest.js',
    'tests/masterStep129MeaningMatrixExpansionReadinessGateTest.js'
  ];
  for (const file of requiredFiles) assert.strictEqual(exists(file), true, `missing required file: ${file}`);

  const proofJson = json('runtime/proof/MASTERSTEP134_FIRST_MATRIX_EXPANSION_FREEZE_KEEPER_BOUNDARY_AUDIT.json');
  const state = json('runtime/proof/PROOF_STATE.json');
  const versionStatus = json('tests/VERSION_STATUS.json');
  const versionJs = read('version_status.js');
  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
  const testResults = read('tests/TEST_RESULTS.md');
  const index = read('runtime/proof/ENGINEERING_PROOF_INDEX.md');
  const runner = read('proof/runCurrentProof.js');

  assert.strictEqual(proofJson.package, 'Masterstep134.zip');
  assert.strictEqual(proofJson.source_keeper, 'Masterstep133.zip');
  assert.strictEqual(proofJson.expected_commands, 56);
  assert.strictEqual(proofJson.first_matrix_expansion_frozen, true);
  assert.strictEqual(proofJson.checkpoint_freeze_only, true);
  assert.strictEqual(proofJson.future_matrix_maturity_preserved, true);
  assert.strictEqual(proofJson.candidate_may_replace_final, false);
  assert.strictEqual(proofJson.model_authority_added, false);
  assert.strictEqual(proofJson.frontend_intelligence_added, false);
  assert.strictEqual(proofJson.cloud_provider_fallback_allowed, false);
  assert.strictEqual(proofJson.silent_learning_allowed, false);
  assert.strictEqual(proofJson.silent_mutation_allowed, false);

  assert.ok(['Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 134), state.current_keeper);
  assert.ok(['Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 133) || state.source_keeper === 'Masterstep141.zip', state.source_keeper);
  assert.ok(acceptsCurrentProofCount(state.expected_commands, 56), state.expected_commands);
  assert.ok(acceptsCurrentProofCount(state.expected_current_proof_commands, 56), state.expected_current_proof_commands);
  assert.strictEqual(state.first_matrix_expansion_frozen, true);
  assert.strictEqual(state.checkpoint_freeze_only, true);
  assert.strictEqual(state.future_matrix_maturity_preserved, true);
  assert.strictEqual(state.candidate_may_replace_final, false);
  assert.strictEqual(state.model_authority_added, false);
  assert.strictEqual(state.frontend_intelligence_added, false);
  assert.strictEqual(state.silent_learning, false);
  assert.strictEqual(state.silent_mutation, false);

  assert.ok(['Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(versionStatus.current_keeper) || isValidLaterKeeper(versionStatus.current_keeper, 134), versionStatus.current_keeper);
  assert.ok(['Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(versionStatus.source_keeper) || isValidLaterKeeper(versionStatus.source_keeper, 133) || versionStatus.source_keeper === 'Masterstep141.zip', versionStatus.source_keeper);
  assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 56), versionStatus.expected_current_proof_commands);
  assert.strictEqual(versionStatus.first_matrix_expansion_frozen, true);
  assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs), 'version_status.js must identify current keeper compatibility');
  assert.ok(/expected_current_proof_commands: [0-9]+/i.test(versionJs), 'version_status.js must identify expected command compatibility');
  assert.ok(/first_matrix_expansion_frozen: true/i.test(versionJs));

  assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
  assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
  assert.ok(/Expected current proof target: [0-9]+\/[0-9]+ commands passed/i.test(summary), 'summary must identify current proof target compatibility');
  assert.ok(/First Matrix Expansion Freeze/i.test(summary));
  assert.ok(/TEST 134/i.test(testResults));
  assert.ok(/First Matrix Expansion Freeze/i.test(testResults));
  assert.ok(/(5[0-9]|6[01])\/(5[0-9]|6[01]) commands/i.test(testResults));
  assert.ok(/Masterstep134 — First Matrix Expansion Freeze/i.test(index));
  assert.ok(/masterStep134FirstMatrixExpansionFreezeKeeperBoundaryAuditTest/i.test(runner));
  assert.ok(/currentTarget\.current_manifest/i.test(runner), 'runner must identify current proof manifest compatibility');

  for (const rel of [
    'docs/MASTERSTEP134_FIRST_MATRIX_EXPANSION_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'docs/FIRST_MATRIX_EXPANSION_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'runtime/proof/MASTERSTEP134_FIRST_MATRIX_EXPANSION_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'runtime/proof/CURRENT_PROOF_SUMMARY.md'
  ]) {
    const text = compatibilityTextFor(rel);
    assert.ok(/checkpoint freeze/i.test(text), `${rel} should describe checkpoint freeze`);
    assert.ok(/future matrix maturity/i.test(text), `${rel} should preserve future maturity`);
    assert.ok(/candidate phrasing remains candidate-only/i.test(text), `${rel} should preserve candidate-only phrasing`);
    assert.ok(/Atlas-governed output remains final/i.test(text), `${rel} should preserve Atlas-governed final output`);
    assert.ok(assertNoForbiddenAffirmativeClaims(text).ok, `${rel} must not overclaim`);
  }

  const providerScan = scanForProviderConnections(ROOT);
  assert.strictEqual(providerScan.passed, true, `provider/network scan must pass: ${JSON.stringify(providerScan.violations || [])}`);
  const nestedArchives = walk(ROOT).filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
  assert.deepStrictEqual(nestedArchives, [], 'package must not contain nested archives');

  const after = Object.fromEntries(protectedFiles.map(f => [f, sha256(f)]));
  assert.deepStrictEqual(protectedFiles.filter(f => before[f] !== after[f]), [], 'Step134 test must not mutate protected files');
  console.log(JSON.stringify({ package:'Masterstep134', source_keeper:'Masterstep133', proof_target:'56/56', first_matrix_expansion_frozen:true, checkpoint_freeze_only:true, future_matrix_maturity_preserved:true, candidate_may_replace_final:false, nested_archives:nestedArchives.length }, null, 2));
})();
