---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch_summary
batch: 01
categories:
  - attachment_and_connection
  - trust_and_betrayal
  - rejection_and_abandonment
  - abandonment_and_inconsistency
  - self_worth_and_identity
status: teaching_input_summary
governed_by:
  - external_teaching_to_proposal_flow
  - gpt_response_review_template
---

# Batch 01 Pressure Test Summary

This batch contains 400 total pressure tests.

- 80 attachment_and_connection tests
- 80 trust_and_betrayal tests
- 80 rejection_and_abandonment tests
- 80 abandonment_and_inconsistency tests
- 80 self_worth_and_identity tests

## Core Teaching Result

Atlas should stop treating these five categories as interchangeable relationship distress. Each category has a different active mechanism:

1. **attachment_and_connection** — changed closeness affects emotional security.
2. **trust_and_betrayal** — broken reliability affects reality-confidence and discernment.
3. **rejection_and_abandonment** — not being chosen or being left can attach pain to value and belonging.
4. **abandonment_and_inconsistency** — unstable signals create confusion and self-blame loops.
5. **self_worth_and_identity** — external events attach to value, dignity, identity, or lovability.

## Batch Correction Principle

Compass should identify the deepest active meaning, not only the surface event.

Example:

```text
Someone pulling away makes me feel unwanted and like I was too much.
```

This may include connection pressure, inconsistency, rejection, and self-worth. Atlas should prioritize the category where the emotional meaning is heaviest, often `rejection_and_abandonment` or `self_worth_and_identity`, while blending connection or inconsistency only when useful.

## Approved Teaching Direction

Raw pressure tests stay in this teaching channel. Reusable lessons may be promoted into `31 Atlas Response Intelligence` after review.
