---
title: Trust Collapse
runtime_layer: emotional_pressure
priority: high
status: active
phase: runtime_link_cleanup
governed_by:
  - emotional_continuity_governance
  - governance_enforcement_registry
outputs:
  - Projection From Past Pain
  - emotional_guarding
---

# Trust Collapse

## Purpose

Defines the collapse of trust that can happen when openness, vulnerability, or relational safety becomes connected to harm or abandonment.

## Core Function

The runtime should separate a specific trust disruption from the conclusion that openness itself is unsafe everywhere.

## Runtime Boundary

This node exists because existing backend links already reference this concept. It should clarify the referenced pathway without creating duplicate ontology or changing Compass into a clinical, diagnostic, authoritative, or productivity-driven system.

## Related Runtime Links

- [[Projection From Past Pain]]
- [[emotional_guarding]]
- [[emotional_continuity_governance]]
- [[truth_separation_governance]]
