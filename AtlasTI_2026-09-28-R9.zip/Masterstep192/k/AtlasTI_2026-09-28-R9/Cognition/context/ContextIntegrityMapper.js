const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const CONTEXT_INTEGRITY_REGISTRY_PATH = "CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/context_integrity_mapping_registry.md";

let cachedContextIntegrityRegistry = null;

function getContextIntegrityRegistry() {
  if (!cachedContextIntegrityRegistry) {
    cachedContextIntegrityRegistry = readJsonRegistry(CONTEXT_INTEGRITY_REGISTRY_PATH);
  }
  return cachedContextIntegrityRegistry;
}

function normalizeInput(input) {
  return String(input || "").toLowerCase();
}

function countWords(input) {
  const words = String(input || "").trim().split(/\s+/).filter(Boolean);
  return words.length;
}

function phraseMatches(text, phrase) {
  if (typeof phrase !== "string" || phrase.length === 0) return false;
  return text.includes(phrase.toLowerCase());
}

function anyPhraseMatches(text, phrases) {
  return Array.isArray(phrases) && phrases.some((phrase) => phraseMatches(text, phrase));
}

function allGroupsMatch(text, groups) {
  if (!Array.isArray(groups) || groups.length === 0) return true;
  return groups.every((group) => anyPhraseMatches(text, Array.isArray(group.phrases) ? group.phrases : []));
}

function ruleMatches(text, rule) {
  const phrases = Array.isArray(rule.phrases) ? rule.phrases : [];
  const allGroups = Array.isArray(rule.allGroups) ? rule.allGroups : [];

  if (allGroups.length > 0 && !allGroupsMatch(text, allGroups)) return false;
  if (phrases.length > 0 && !anyPhraseMatches(text, phrases)) return false;
  return allGroups.length > 0 || phrases.length > 0;
}

function appendUnique(target, values) {
  if (!Array.isArray(values)) return;
  for (const value of values) {
    if (typeof value === "string" && value.trim() && !target.includes(value)) {
      target.push(value);
    }
  }
}

function collectMatchedRules(text, rules) {
  const matched = [];
  for (const rule of rules) {
    if (rule && rule.id && ruleMatches(text, rule)) matched.push(rule);
  }
  return matched;
}

function mapContextIntegrity(input) {
  const text = normalizeInput(input);
  const registry = getContextIntegrityRegistry();
  const wordCount = countWords(input);
  const rules = Array.isArray(registry.rules) ? [...registry.rules] : [];

  rules.sort((a, b) => (a.priority || 9999) - (b.priority || 9999));
  const matchedRules = collectMatchedRules(text, rules);

  const contextSignals = [];
  const heldMeanings = [];
  const closureBlocks = [];
  const narrowingSupport = [];

  for (const rule of matchedRules) {
    appendUnique(contextSignals, rule.contextSignals);
    appendUnique(heldMeanings, rule.holdMeaningsOpen);
    appendUnique(closureBlocks, rule.closureBlocks);
    appendUnique(narrowingSupport, rule.narrowingSupport);
  }

  const enoughOuterContext = wordCount >= (registry.minimumContextWordCount || 8) || narrowingSupport.length > 0;
  const isolatedOrThinContext = !enoughOuterContext || contextSignals.includes("isolated_word_or_fragment");
  const preserveMultipleMeanings = heldMeanings.length > 1 || contextSignals.includes("multi_meaning_word_detected");
  const narrowingAllowed = enoughOuterContext && narrowingSupport.length > 0;
  const closureAllowed = false;

  return {
    version: registry.version,
    stewardship: "Master Step 4A — Context Integrity Mapping",
    outer_context_status: enoughOuterContext ? "context_available" : "context_insufficient_or_fragmentary",
    interpretation_state: narrowingAllowed ? "context_supported_narrowing" : "hold_open",
    narrowing_allowed: narrowingAllowed,
    closure_allowed: closureAllowed,
    revisable: true,
    isolated_word_interpretation_blocked: isolatedOrThinContext,
    preserve_multiple_meanings: preserveMultipleMeanings,
    context_signals: contextSignals,
    held_meanings: heldMeanings,
    closure_blocks: closureBlocks,
    narrowing_support: narrowingSupport,
    matched_rules: matchedRules.map((rule) => rule.id),
    guardrails: Array.isArray(registry.guardrails) ? registry.guardrails : []
  };
}

module.exports = { mapContextIntegrity };
