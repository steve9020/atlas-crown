const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function walk(dir){ let out=[]; for(const e of fs.readdirSync(dir,{withFileTypes:true})){ const p=path.join(dir,e.name); if(e.isDirectory()) out=out.concat(walk(p)); else out.push(p); } return out; }
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const observer=json('runtime/governance/EXTERNAL_INTEGRITY_OBSERVER_LAYER.json');
for (const [k,v] of Object.entries(observer.immutability)) {
  if (['runtime_mutation_reach','self_modification_allowed','adaptive_behavior_allowed','promotion_authority','runtime_control_authority','interpretation_authority','truth_ownership','governance_rewrite_authority'].includes(k)) {
    assert(v === false, `observer immutability field ${k} must remain false`);
  }
}
const forbidden=['observer_can_promote: true','observer_can_mutate: true','observer_can_govern: true','observer_can_interpret: true','observer_owns_truth: true','external_integrity_observer_self_modify: true','external_integrity_observer_runtime_control: true'];
for (const file of walk(root)) {
  if (!/\.(js|json|md)$/i.test(file)) continue;
  const rel=path.relative(root,file).replace(/\\/g,'/');
  const txt=fs.readFileSync(file,'utf8');
  for (const pattern of forbidden) {
    if (rel === 'tests/masterStep12Patch06ObserverImmutabilityAuditTest.js') continue;
    assert(!txt.includes(pattern), `forbidden observer authority pattern ${pattern} in ${rel}`);
  }
}
console.log('masterStep12Patch06ObserverImmutabilityAuditTest PASSED');
