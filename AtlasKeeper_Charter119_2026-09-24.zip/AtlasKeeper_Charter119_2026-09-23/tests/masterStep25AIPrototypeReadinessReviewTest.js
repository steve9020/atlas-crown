
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function assert(cond,msg){ if(!cond) throw new Error(msg); }
function json(rel){ return JSON.parse(fs.readFileSync(path.join(root, rel),'utf8')); }
const spec = json('runtime/ai/AI_ASSISTED_PROTOTYPE_READINESS_REVIEW.json');
const { checkPrototypeReadiness, REQUIRED_FILES } = require('../runtime/ai/AIPrototypeReadinessChecklist.js');
const { reviewAIPrototypeReadiness } = require('../runtime/ai/AIPrototypeReadinessReviewGuard.js');
const { buildAIPrototypeReadinessReport } = require('../runtime/ai/AIPrototypeReadinessReport.js');
assert(spec.package === 'Masterstep25.zip', 'spec package must be Masterstep25.zip');
assert(spec.previous_keeper === 'Masterstep24.zip', 'previous keeper must be Masterstep24.zip');
assert(spec.readiness_decision === 'READY_FOR_SANDBOX_PLANNING_ONLY', 'readiness decision must be sandbox planning only');
assert(spec.not_ready_for_real_ai_connection === true, 'real AI connection must not be approved');
assert(spec.real_ai_connected === false, 'real AI must remain disconnected');
assert(spec.local_model_connected === false, 'local model must remain disconnected');
assert(spec.provider_config_added === false, 'provider config must remain false');
assert(spec.network_bridge_added === false, 'network bridge must remain false');
assert(spec.frontend_intelligence_added === false, 'frontend intelligence must remain false');
assert(spec.review_scope.length >= 12, 'review scope must include completed AI-assist chain');
assert(REQUIRED_FILES.length >= 14, 'checklist must require the full governance chain');
const checklist = checkPrototypeReadiness(root);
assert(checklist.passed === true, 'prototype readiness checklist must pass');
assert(checklist.forbiddenPresent.length === 0, 'forbidden connector files must be absent');
const review = reviewAIPrototypeReadiness(root, spec);
assert(review.passed === true, 'readiness review must pass');
assert(review.decision === 'READY_FOR_SANDBOX_PLANNING_ONLY', 'decision must remain sandbox planning only');
assert(review.realAIConnectionApproved === false, 'real AI connection must not be approved');
assert(review.distributionApproved === false, 'distribution must not be approved');
const bad = reviewAIPrototypeReadiness(root, { real_ai_connected:true });
assert(bad.passed === false, 'real AI connected state must fail');
assert(bad.violations.includes('real_ai_connection_forbidden_at_masterstep25'), 'real AI violation required');
const report = buildAIPrototypeReadinessReport(review);
assert(report.real_ai_connection_approved === false, 'report cannot approve real AI');
assert(report.distribution_approved === false, 'report cannot approve distribution');
console.log('masterStep25AIPrototypeReadinessReviewTest PASSED');
