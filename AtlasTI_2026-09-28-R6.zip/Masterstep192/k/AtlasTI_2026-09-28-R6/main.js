﻿const { runPipeline } = require("./runtime/pipeline/ResponsePipeline.js");

function main(input) {
  return runPipeline(input);
}

module.exports = { main };