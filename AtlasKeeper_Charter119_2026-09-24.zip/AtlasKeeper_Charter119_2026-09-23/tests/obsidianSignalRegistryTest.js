const assert = require("assert");
const { detectSignals } = require("../Cognition/signals/SignalEngine.js");

const combined = detectSignals("I made a small mistake and now I feel like I am falling behind and cannot keep up.");
assert(combined.includes("mistake_to_progress_collapse"), "Expected combined mistake/progress collapse signal.");
assert(combined.includes("mistake_pressure"), "Expected mistake pressure signal.");
assert(combined.includes("progress_pressure"), "Expected progress pressure signal.");

const meaning = detectSignals("This must mean I am turning into a failure.");
assert(meaning.includes("meaning_attachment"), "Expected meaning attachment signal.");
assert(meaning.includes("performance_pressure"), "Expected performance pressure signal.");

const relational = detectSignals("They pulled away and the silence makes me feel unwanted.");
assert(relational.includes("relational_pressure"), "Expected relational pressure signal.");

const finality = detectSignals("Nothing will change and this feels final forever.");
assert(finality.includes("finality_pressure"), "Expected finality pressure signal.");

const noDuplicate = detectSignals("mistake mistake mistake");
const mistakeCount = noDuplicate.filter((signal) => signal === "mistake_pressure").length;
assert.strictEqual(mistakeCount, 1, "Expected deduped signals.");

console.log("obsidianSignalRegistryTest.js — PASSED");
