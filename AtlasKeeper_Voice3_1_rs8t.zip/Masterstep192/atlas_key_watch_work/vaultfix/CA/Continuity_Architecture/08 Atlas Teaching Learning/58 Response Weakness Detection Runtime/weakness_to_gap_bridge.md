---
runtime_layer: response_weakness_detection
priority: high
owned_by: atlas_teaching_learning
feeds_into:
  - teaching_gap_detection_runtime_overview
---

# Weakness to Gap Bridge

## Purpose
Passes detected response weaknesses into Teaching Gap Detection.

## Bridge flow
Response weakness detected → weakness classified → likely missing backend knowledge identified → teaching gap drafted → proposal created for approval.

## Rule
A weakness should become a teaching proposal only when the missing rule can be stated clearly and applied beyond the current prompt.
