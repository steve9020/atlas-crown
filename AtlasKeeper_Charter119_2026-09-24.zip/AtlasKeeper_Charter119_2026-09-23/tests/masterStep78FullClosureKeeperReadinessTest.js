const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const version = require('../version_status');
const root = path.resolve(__dirname, '..');
const required = [
  'runtime/backend/closure/LocalPreModelClosureDistributionHoldCheck.js',
  'runtime/proof/MASTERSTEP78_LOCAL_PRE_MODEL_CLOSURE_DISTRIBUTION_HOLD_CHECK.json',
  'runtime/proof/MASTERSTEP78_LOCAL_PRE_MODEL_CLOSURE_DISTRIBUTION_HOLD_CHECK.md',
  'docs/MASTERSTEP78_LOCAL_PRE_MODEL_CLOSURE_DISTRIBUTION_HOLD_CHECK_MAP.md',
  'tests/masterStep78LocalPreModelClosureDistributionHoldCheckTest.js'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(root, rel)), 'missing Step78 artifact: ' + rel);
const proof = JSON.parse(fs.readFileSync(path.join(root, 'runtime/proof/MASTERSTEP78_LOCAL_PRE_MODEL_CLOSURE_DISTRIBUTION_HOLD_CHECK.json'), 'utf8'));
assert.strictEqual(proof.passed, true, 'proof JSON must record Step78 pass');
assert.strictEqual(proof.source_keeper, 'Masterstep77');
assert.strictEqual(proof.distribution_ready, false);
assert.strictEqual(proof.external_deployment_ready, false);
assert.strictEqual(proof.production_claim_allowed, false);
assert.strictEqual(proof.cloud_work_deferred, true);
assert.strictEqual(proof.provider_connected, false);
assert.strictEqual(proof.real_model_connected, false);
assert.strictEqual(proof.local_offline_model_connected, false);
assert.strictEqual(proof.frontend_intelligence_added, false);
assert.strictEqual(proof.required_chain_evidence.prior_local_chain_still_passes, true);
assert.strictEqual(proof.required_chain_evidence.provider_scan_clean, true);
assert.strictEqual(proof.required_chain_evidence.executable_model_or_provider_surface_absent, true);
assert.strictEqual(proof.required_chain_evidence.frontend_shell_still_dumb, true);
assert.strictEqual(proof.required_chain_evidence.distribution_hold_explicit, true);
assert.strictEqual(version.currentKeeper, 'Masterstep78');
assert.strictEqual(version.previousKeeper, 'Masterstep77');
assert.strictEqual(version.step, 'Local Pre-Model Closure / Distribution-Hold Check');
assert.strictEqual(version.distributionReady, false);
assert.strictEqual(version.externalDeploymentReady, false);
assert.strictEqual(version.productionClaimAllowed, false);
assert.strictEqual(version.cloudProviderEvaluationStarted, false);
assert.strictEqual(version.cloudWorkDeferredByUser, true);
assert.strictEqual(version.nextTarget, 'Choose next local governed track — cloud/provider remains deferred');
console.log('masterStep78FullClosureKeeperReadinessTest PASSED');
