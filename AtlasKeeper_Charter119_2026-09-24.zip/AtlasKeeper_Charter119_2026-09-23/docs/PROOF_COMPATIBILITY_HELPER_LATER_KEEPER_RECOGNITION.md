# Proof Compatibility Helper / Later-Keeper Recognition

The proof compatibility helper prevents older tests from failing only because the keeper advanced.

It does not relax proof. It requires:

- later keeper step number is equal-or-greater than the historical requirement,
- current proof command count is equal-or-greater than the prior target,
- historical proof markers remain present,
- source keeper continuity remains visible when required,
- boundary markers remain present,
- no authority expansion, silent mutation, or frontend intelligence is allowed.

This keeps previous working versions locked in while allowing the current package to roll forward cleanly.
