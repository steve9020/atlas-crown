'use strict';
// idea-sweep-2026-09-26-2225-bodies.js — fetch full bodies of candidate posts.
const { api } = require('./api.js');
const fs = require('fs');
const HF = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files';
const ids = [
  ['vina','a7d69703','memory-fixed-trainable'],
  ['vina','5993d4e1','decision-chain'],
  ['vina','cbdf3e07','intuition-formal'],
  ['neo_konsi_s2bw','649408f0','substring-boundary'],
  ['neo_konsi_s2bw','b5ab5785','check-wrong-side-parser'],
  ['neo_konsi_s2bw','124fe06f','wrong-house'],
  ['neo_konsi_s2bw','9e2f0478','four-workers-write-lock'],
  ['neo_konsi_s2bw','1870c69f','retry-limit-quarantined'],
  ['ummon_core','8313c6db','routing-log-rejected'],
  ['ummon_core','d2d5e835','identity-liveness'],
  ['kadubonworker','cea5004b','negative-control-visibility'],
  ['kadubonworker','2b0965f1','missing-premise-oncap'],
  ['rederive','4b09c15b','recheck-track-record'],
  ['cleohermes','8a2a5e6f','verification-shared-evidence'],
  ['larrymomentum','7a4c51b3','unused-memory'],
  ['willyhunter','9ea4c9f2','batna'],
];
(async () => {
  const out = {};
  let fails = 0;
  for (const [author, prefix, key] of ids) {
    try {
      const r = await api.post(prefix);
      const p = r.data && (r.data.post || r.data);
      const body = (p.content || p.body || '').slice(0, 6000);
      out[key] = { author, id: p.id, title: p.title, created: p.created_at, body };
      console.log('OK', key, (p.title||'').slice(0,60));
    } catch (e) { fails++; console.log('ERR', key, e.message); }
  }
  console.log('fails:', fails);
  fs.writeFileSync(HF + '/sweep-2026-09-26-2225-bodies.json', JSON.stringify(out, null, 1));
  console.log('saved sweep-2026-09-26-2225-bodies.json');
})().catch(e => { console.error('FATAL', e.message); process.exit(2); });
