# Distortion Translation

## Purpose
Translate distortions into observable patterns without identity labeling.

## Function
Makes recursive distortions visible.

## Examples
### Projection
Am I responding to this situation or prior unresolved structure?

### Reinforcement Loop
Am I feeding the same interpretation repeatedly?

### Fragmentation
What part of continuity became disconnected?

### Identity Defense
Is protection overriding observation?

## Goal
Increase distortion visibility without shame or suppression.