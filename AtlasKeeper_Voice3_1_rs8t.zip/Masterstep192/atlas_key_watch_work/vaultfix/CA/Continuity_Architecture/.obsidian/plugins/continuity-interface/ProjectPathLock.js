const fs = require("fs");
const path = require("path");

/**
 * Atlas Project Path Lock
 *
 * Purpose:
 * - The Obsidian vault must be opened at: <packageRoot>/CA/Continuity_Architecture
 * - The wider Atlas package root remains: <packageRoot>
 * - The plugin must not infer the vault folder itself as the package root.
 *
 * This guard is intentionally local-only. It does not search the computer,
 * create outside folders, call network resources, or repair paths silently.
 */
function normalize(p) {
  return path.resolve(String(p || "")).replace(/\\/g, "/");
}

function existsDir(p) {
  try {
    return fs.existsSync(p) && fs.statSync(p).isDirectory();
  } catch (_) {
    return false;
  }
}

function validateAtlasVaultPathLock(config = {}) {
  const vaultBasePathRaw = config.vaultBasePath || "";
  const pluginDirRaw = config.pluginDir || "";
  const vaultBasePath = normalize(vaultBasePathRaw);
  const pluginDir = normalize(pluginDirRaw);
  const vaultName = path.basename(vaultBasePath);
  const caFolder = normalize(path.dirname(vaultBasePath));
  const caFolderName = path.basename(caFolder);
  const packageRoot = normalize(path.dirname(caFolder));

  const expectedVaultPath = normalize(path.join(packageRoot, "CA", "Continuity_Architecture"));
  const expectedPluginPath = normalize(path.join(expectedVaultPath, ".obsidian", "plugins", "continuity-interface"));

  const requiredPackageDirs = ["CA", "Cognition", "runtime", "tests"];
  const missingPackageDirs = requiredPackageDirs.filter((dirName) => !existsDir(path.join(packageRoot, dirName)));

  const failures = [];

  if (vaultName !== "Continuity_Architecture") {
    failures.push(`Open the inner vault folder named Continuity_Architecture, not '${vaultName || "unknown"}'.`);
  }

  if (caFolderName !== "CA") {
    failures.push(`Continuity_Architecture must sit inside a CA folder. Current parent is '${caFolderName || "unknown"}'.`);
  }

  if (vaultBasePath !== expectedVaultPath) {
    failures.push(`Vault path mismatch. Expected '${expectedVaultPath}', received '${vaultBasePath}'.`);
  }

  if (missingPackageDirs.length) {
    failures.push(`Package root is incomplete at '${packageRoot}'. Missing: ${missingPackageDirs.join(", ")}.`);
  }

  if (pluginDir && pluginDir !== expectedPluginPath) {
    failures.push(`Plugin path mismatch. Expected '${expectedPluginPath}', received '${pluginDir}'.`);
  }

  return {
    ok: failures.length === 0,
    failures,
    vaultBasePath,
    packageRoot,
    expectedVaultPath,
    expectedPluginPath,
    runtimePath: normalize(path.join(packageRoot, "runtime")),
    cognitionPath: normalize(path.join(packageRoot, "Cognition")),
    testsPath: normalize(path.join(packageRoot, "tests")),
    rule: "Open CA/Continuity_Architecture as the Obsidian vault. Treat the folder two levels above it as the Atlas package root."
  };
}

module.exports = { validateAtlasVaultPathLock };
