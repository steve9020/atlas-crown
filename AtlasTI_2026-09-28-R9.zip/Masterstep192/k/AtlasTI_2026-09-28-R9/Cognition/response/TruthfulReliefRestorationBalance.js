const UNSUPPORTED_COMFORT_PATTERNS = [
  {
    id: "everything_okay_promise",
    pattern: /\beverything\s+(is|will\s+be|is\s+going\s+to\s+be)\s+okay\b/gi,
    replacement: "this can be held without turning it into a final verdict"
  },
  {
    id: "guaranteed_outcome",
    pattern: /\b(i\s+promise|it\s+is\s+guaranteed|you\s+will\s+definitely)\b[^.!?]*/gi,
    replacement: "what can be known right now is that this does not have to close the path forward"
  },
  {
    id: "forced_positivity",
    pattern: /\bjust\s+(stay\s+positive|think\s+positive|look\s+on\s+the\s+bright\s+side)\b/gi,
    replacement: "it may help to stay honest with the weight while not letting it become the whole truth"
  },
  {
    id: "pain_erasure",
    pattern: /\bthere'?s\s+nothing\s+to\s+(worry\s+about|be\s+upset\s+about)\b/gi,
    replacement: "there may be real weight here, and it can still be separated from a final conclusion"
  },
  {
    id: "instant_fix",
    pattern: /\bthis\s+will\s+fix\s+everything\b/gi,
    replacement: "this may give the next clear place to stand"
  },
  {
    id: "all_good_flattening",
    pattern: /\bit'?s\s+all\s+good\b/gi,
    replacement: "this can be approached steadily without pretending it has no weight"
  },
  {
    id: "nothing_bad_can_happen",
    pattern: /\bnothing\s+bad\s+will\s+happen\b/gi,
    replacement: "the uncertainty does not have to become a final threat before more is known"
  }
];

const UNSUPPORTED_COMFORT_MARKERS = [
  /\beverything\s+(is|will\s+be|is\s+going\s+to\s+be)\s+okay\b/i,
  /\b(i\s+promise|it\s+is\s+guaranteed|you\s+will\s+definitely)\b/i,
  /\bjust\s+(stay\s+positive|think\s+positive|look\s+on\s+the\s+bright\s+side)\b/i,
  /\bthere'?s\s+nothing\s+to\s+(worry\s+about|be\s+upset\s+about)\b/i,
  /\bthis\s+will\s+fix\s+everything\b/i,
  /\bit'?s\s+all\s+good\b/i,
  /\bnothing\s+bad\s+will\s+happen\b/i
];

const TRUTHFUL_RELIEF_MARKERS = [
  /\bdoes\s+not\s+have\s+to\s+(mean|become|close|define)\b/i,
  /\bwithout\s+(pretending|turning|making)\b/i,
  /\bcan\s+still\s+be\s+(held|approached|separated|carried)\b/i,
  /\bthere\s+may\s+be\s+real\s+weight\b/i,
  /\bnot\s+the\s+whole\s+truth\b/i,
  /\bnext\s+clear\s+place\s+to\s+stand\b/i,
  /\bpath\s+forward\b/i,
  /\bfinal\s+(verdict|conclusion|threat)\b/i
];

const RESTORATION_BALANCE_MARKERS = [
  /\bclarity\b/i,
  /\bsteady\b/i,
  /\bseparate\b/i,
  /\bmove\s+forward\b/i,
  /\bpath\s+forward\b/i,
  /\bnot\s+the\s+whole\s+truth\b/i,
  /\bwithout\s+pretending\b/i
];

function detectUnsupportedComfort(response) {
  const text = typeof response === "string" ? response : "";
  return UNSUPPORTED_COMFORT_MARKERS
    .map((pattern, index) => ({ pattern, index }))
    .filter(({ pattern }) => pattern.test(text))
    .map(({ index }) => [
      "everything_okay_promise",
      "guaranteed_outcome",
      "forced_positivity",
      "pain_erasure",
      "instant_fix",
      "all_good_flattening",
      "nothing_bad_can_happen"
    ][index]);
}

function hasTruthfulReliefLanguage(response) {
  const text = typeof response === "string" ? response : "";
  return TRUTHFUL_RELIEF_MARKERS.some((pattern) => pattern.test(text));
}

function hasRestorationBalanceLanguage(response) {
  const text = typeof response === "string" ? response : "";
  return RESTORATION_BALANCE_MARKERS.some((pattern) => pattern.test(text));
}

function applyTruthfulReliefRestorationBalance(response) {
  let output = typeof response === "string" ? response : "";
  const detectedBefore = detectUnsupportedComfort(output);

  for (const item of UNSUPPORTED_COMFORT_PATTERNS) {
    item.pattern.lastIndex = 0;
    output = output.replace(item.pattern, item.replacement);
  }

  output = output
    .replace(/\bthis\s+proves\s+you\s+will\s+be\s+fine\b/gi, "this may give you a steadier place to look from")
    .replace(/\byou\s+have\s+nothing\s+to\s+feel\b/gi, "what you feel may carry real weight, but it does not need to become the whole truth")
    .replace(/\s{2,}/g, " ")
    .trim();

  const detectedAfter = detectUnsupportedComfort(output);
  const truthfulReliefPresent = hasTruthfulReliefLanguage(output) || detectedBefore.length === 0;
  const restorationBalancePresent = hasRestorationBalanceLanguage(output) || detectedBefore.length > 0;

  return {
    output,
    truthful_relief_restoration_balance: {
      truthful_relief_restoration_balance_active: true,
      unsupported_comfort_detected: detectedBefore,
      unsupported_comfort_remaining: detectedAfter,
      unsupported_comfort_blocked: detectedAfter.length === 0,
      truthful_relief_language_present: truthfulReliefPresent,
      restoration_balance_language_present: restorationBalancePresent,
      false_promise_prevention_preserved: detectedAfter.length === 0,
      required_output_mode: "truthful_relief_without_unsupported_comfort",
      guardrails: [
        "do_not_make_false_promises",
        "do_not_erase_pain_to_provide_comfort",
        "restore_movement_without_forced_positivity",
        "reduce_weight_without_claiming_unsupported_outcomes",
        "preserve_truth_warmth_clarity_and_revisability"
      ]
    }
  };
}

module.exports = {
  applyTruthfulReliefRestorationBalance,
  detectUnsupportedComfort,
  hasTruthfulReliefLanguage,
  hasRestorationBalanceLanguage
};
