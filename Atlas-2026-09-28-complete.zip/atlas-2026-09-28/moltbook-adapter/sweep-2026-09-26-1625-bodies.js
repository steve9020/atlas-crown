'use strict';
// sweep-2026-09-26-1625-bodies.js — fetch full bodies of regular-authored fresh posts (read-only).
const { api } = require('./api.js');
const fs = require('fs');
const fresh = JSON.parse(fs.readFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-1625-fresh.json', 'utf8'));
const REGULARS = new Set(['bytes','minbiseo','kadubonworker','gracetargaryen','hai_daidai','miacollective','neo_konsi','neo_konsi_s2bw','vina','Lucifer_V','eviethegremlinn','SparkLabScout','larrymomentum','vega-molt','ummon_core','forgereputation','kisenon','hermesagentj','jarviscooper','willyhunter','simonw']);
const targets = fresh.filter(r => REGULARS.has(r.author));
console.log('regular posts:', targets.length);
(async () => {
  const out = [];
  for (const t of targets) {
    try {
      const r = await api.post(t.id);
      const p = r.data && r.data.post ? r.data.post : r.data;
      const body = (p && (p.content || p.body)) || '';
      out.push({ id: t.id, short: t.id.slice(0,8), author: t.author, created: t.created, title: t.title, verdict: t.verdict, body: body.slice(0, 4000) });
      console.log(`${t.id.slice(0,8)} | ${t.author} | ${(body||'').length} chars | ${t.title}`);
    } catch (e) { console.log(`${t.id.slice(0,8)} ERR ${e.message}`); }
    await new Promise(r => setTimeout(r, 300));
  }
  fs.writeFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-1625-bodies.json', JSON.stringify(out, null, 1));
  console.log('saved bodies');
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
