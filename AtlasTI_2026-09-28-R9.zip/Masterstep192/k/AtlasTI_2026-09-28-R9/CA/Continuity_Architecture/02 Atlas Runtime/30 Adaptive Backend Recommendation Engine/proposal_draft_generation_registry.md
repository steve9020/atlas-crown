---
title: Proposal Draft Generation Registry
runtime_layer: adaptive_backend_recommendation_engine
priority: high
governed_by: adaptive_backend_recommendation_engine_overview
receives_from:
  - missing_pattern_detection_registry
  - recommendation_scoring_registry
outputs_to:
  - emotional_growth_proposal_queue
  - emotional_growth_approval_gate
status: active
---

# Proposal Draft Generation Registry

## Purpose

This registry defines how Compass may generate proposal drafts after a recommendation is sent to review.

Proposal drafts help Steve review the exact backend growth idea before it can become active.

---

## Core Rule

Compass may draft.

Compass may not silently activate.

A proposal draft must remain pending until reviewed.

An integration draft must remain inactive until Steve chooses Integrate.

---

## Proposal Draft Requirements

A proposal draft should include:

- proposal id
- category
- status
- detected language
- possible interpretation
- reason for proposal
- duplicate or merge assessment
- target registry
- frontend translation note
- risk if added without review

---

## Integration Draft Requirements

An integration draft should include:

- source proposal
- target registry
- emotional contact
- loop formation
- negative learning pattern
- clearer understanding
- frontend-safe expression
- governance note
- no diagnostic language
- no authority claim

---

## Merge Draft Requirements

When the gate suggests merge, the draft should explain:

- existing target pattern
- overlap reason
- what should be strengthened
- why a standalone pattern may not be needed

Merge does not create a new active pattern unless Steve approves the merge action.

---

## Approval Chain

Recommendation shown in Compass.

Steve chooses Send to Review.

Proposal enters [[emotional_growth_proposal_queue]].

Approval gate reviews through [[emotional_growth_approval_gate]].

Only approved proposals create integration drafts.

Only integrated drafts update active backend content.

---

## Related Runtime Links

- [[adaptive_backend_recommendation_engine_overview]]
- [[backend_detector_generation_registry]]
- [[missing_pattern_detection_registry]]
- [[recommendation_scoring_registry]]
- [[emotional_growth_proposal_queue]]
- [[emotional_growth_approval_gate]]
