# Post Implementation Retest Flow

## Purpose
Defines the automatic retest after an approved proposal is implemented.

## Retest Checks
- Did the response address the original weak point?
- Did it avoid the previous failure pattern?
- Did it preserve frontend lightness?
- Did it avoid overcorrecting?
- Did it maintain governance boundaries?
- Did it improve clarity and emotional realism?

## Results
- improved
- partially improved
- no change
- regression
- needs further proposal

## Rule
If the retest shows regression, Atlas should create a new proposal instead of assuming the implementation worked.
