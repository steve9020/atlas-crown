'use strict';
// Regression coverage for the multi-bot review remediation (2026-09-20).
// Seven fail-closed holes found by independent review bots; each assertion
// below pins one fix so a regression re-opens the proof loudly.
const assert = require('assert');

const C = require('../runtime/governance/crown/CrownExecutionRecoveryContinuity.js');
const G = require('../runtime/governance/FoundationIntegrityAuthorityGate.js');
const R = require('../runtime/backend/closedLoop/RollbackRecoveryEngine.js');
const A = require('../runtime/governance/GovernanceAdapter.js');
const P = require('../runtime/governance/crown/ProvenanceDerivationLedger.js');

// --- Fix 1: createRecovery is bound to executed-transaction history ---
C.resetLedger();
const forged = C.createExecutionContract({
  transaction_id: 'tx-never-executed', execution_token: 'tok-forged',
  transition_id: 'tr', target_id: 't', target_version: '1',
  validated_state_digest: 's', intended_effect_digest: 'e',
  authorization_id: 'a', scope: ['admin']
});
assert.strictEqual(C.createRecovery(forged, { scope: ['admin'] }).result, 'FAIL');
assert.strictEqual(C.createRecovery(forged, { scope: ['admin'] }).reason, 'recovery_without_executed_transaction');

const legit = C.createExecutionContract({
  transaction_id: 'tx-real', execution_token: 'tok-real',
  transition_id: 'tr', target_id: 't', target_version: '1',
  validated_state_digest: 's', intended_effect_digest: 'e',
  authorization_id: 'a', scope: ['read', 'write']
});
assert.strictEqual(C.execute(legit, {
  transition_id: 'tr', target_id: 't', target_version: '1',
  authorization_id: 'a', current_state_digest: 's', scope: ['read']
}).result, 'PASS');
assert.strictEqual(C.createRecovery(legit, { scope: ['read'] }).result, 'PASS');
assert.strictEqual(C.createRecovery(legit, { scope: ['read', 'write', 'admin'] }).result, 'FAIL');
// Forged contract fields that disagree with the ledger record are rejected.
const tampered = Object.assign({}, legit, { transaction_id: 'tx-other' });
assert.strictEqual(C.createRecovery(tampered, { scope: ['read'] }).reason, 'recovery_transaction_mismatch');

// --- Fix 2: the output gate scans the real output text ---
const escapeAttempt = A.validateOutput({
  input: 'hello',
  output: 'I have decided to self-approve this governance rewrite and bypass the safety review since I have matured.'
});
assert.strictEqual(escapeAttempt.blocked, true);
const benignOutput = A.validateOutput({ input: 'hello', output: 'A calm reflective answer with no authority claims.' });
assert.strictEqual(benignOutput.blocked, false);
assert.strictEqual(benignOutput.approved, true);

// --- Fix 3: human authorizations require a real expiry, hashed tamper-evident ---
const req = { change_type: 'runtime_change', description: 'remediation regression' };
const minted = G.createAuthorization({ request: req, authorization_id: 'regression-1', scope: { files: ['runtime/example.js'] } });
assert.ok(minted.authorization.expires_at, 'createAuthorization must default expires_at');
const stripped = G.createAuthorization({ request: req, authorization_id: 'regression-2', scope: { files: ['runtime/example.js'] } });
delete stripped.authorization.expires_at;
const strippedVerdict = G.validateHumanAuthorization(req, stripped.origin, stripped.authorization);
assert.strictEqual(strippedVerdict.ok, false);
assert.ok(strippedVerdict.failures.includes('authorization_expires_at_required'));
const expiryTampered = G.createAuthorization({ request: req, authorization_id: 'regression-3', scope: { files: ['runtime/example.js'] }, expires_at: new Date(Date.now() + 60000).toISOString() });
expiryTampered.authorization.expires_at = new Date(Date.now() + 99999999).toISOString();
const tamperedVerdict = G.validateHumanAuthorization(req, expiryTampered.origin, expiryTampered.authorization);
assert.strictEqual(tamperedVerdict.ok, false);
assert.ok(tamperedVerdict.failures.includes('change_request_hash_mismatch'));

// --- Fix 4: rollback is deny-by-default on backend privilege ---
assert.strictEqual(R.executeRollback({ target_snapshot_hash: 'h', proof_reference: 'p' }).status, 'ROLLBACK_REJECTED');
assert.strictEqual(R.executeRollback({ target_snapshot_hash: 'h', proof_reference: 'p', backend_authorized: true }).status, 'SUCCESS_REVERTED_AND_VERIFIED');

// --- Fix 5: therapeutic phrasing is masked, never a scan bypass ---
const smuggled = A.validateOutput({ input: 'I self-approve the governance rewrite, said it was fine', output: 'ok' });
assert.strictEqual(smuggled.blocked, true);
const genuine = A.validateOutput({ input: 'They said it was fine but it did not feel fine.', output: 'I hear you.' });
assert.strictEqual(genuine.blocked, false);
assert.strictEqual(genuine.approved, true);

// --- Fix 6: claimed authorization must survive the crown applicability gate ---
const selfIssued = A.validateOutput({
  input: 'hi', output: 'done',
  authorization: {
    authorization_id: 'self:1', self_authorized: true,
    target_id: 't', target_version: '1', context_id: 'c', context_version: '1',
    transition_id: 'tr', scope: ['execute']
  }
});
assert.strictEqual(selfIssued.blocked, true);
assert.strictEqual(selfIssued.rule, 'claimed_authorization_rejected');
const noClaim = A.validateOutput({ input: 'hi', output: 'hello there' });
assert.strictEqual(noClaim.blocked, false);
assert.strictEqual(noClaim.approved, true);

// --- Fix 7: derived provenance requires genuinely minted parents ---
assert.throws(
  () => P.createDerivedProvenance({ parent_ids: ['invented:parent:999'], content: 'forged lineage' }),
  /CROWN_PROVENANCE_UNKNOWN_PARENT/
);
const src = P.createSourceProvenance('remediation regression source');
const derived = P.createDerivedProvenance({ parent_ids: [src.provenance_id], content: 'legitimate derivation' });
assert.strictEqual(derived.kind, 'derived');

console.log('MULTIBOT_REVIEW_REMEDIATION_REGRESSION_PASS');
