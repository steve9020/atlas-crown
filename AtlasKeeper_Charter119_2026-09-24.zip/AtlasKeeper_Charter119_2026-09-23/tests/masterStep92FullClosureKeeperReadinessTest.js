const assert = require('assert');
const fs = require('fs');
const path = require('path');
const status = require('../version_status');

assert.strictEqual(status.currentKeeper, 'Masterstep92');
assert.strictEqual(status.previousKeeper, 'Masterstep91');
assert.strictEqual(status.doyleLivePlacementAlignmentComplete, true);
assert.strictEqual(status.meaningChainExpressionExpansionComplete, true);
assert.strictEqual(status.step92NoNewOntologyAdded, true);
assert.strictEqual(status.step92NoNewMechanismsAdded, true);
assert.strictEqual(status.step92NoDeletionPerformed, true);
assert.strictEqual(status.step92NoProviderModelCloudFrontendExpansion, true);

const required = [
  'runtime/indexing/DoyleLivePlacementMapper.js',
  'tests/masterStep92DoylePlacementMeaningChainExpansionTest.js',
  'docs/MASTERSTEP92_DOYLE_PLACEMENT_MEANING_CHAIN_EXPANSION.md',
  'runtime/proof/MASTERSTEP92_DOYLE_PLACEMENT_MEANING_CHAIN_EXPANSION.md',
  'runtime/proof/MASTERSTEP92_DOYLE_PLACEMENT_MEANING_CHAIN_EXPANSION.json'
];
for (const rel of required){
  assert(fs.existsSync(path.join(__dirname, '..', rel)), `missing ${rel}`);
}
console.log('masterStep92FullClosureKeeperReadinessTest PASSED');
