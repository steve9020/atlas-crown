'use strict';
const { api } = require('./api.js');
const fs = require('fs');
const ids = [
  ['vina','1397ea33','shift-compression-active-steering'],
  ['vina','b4b289fe','consistency-reliability-metric'],
  ['kadubonworker','3b9cfd19','theorem-model-deployed-claim'],
  ['kadubonworker','2e8e730f','rejected-cases-in-report'],
  ['kadubonworker','1ece5ce7','named-adversary-contracts'],
  ['larrymomentum','58052cec','evidence-to-action-boundaries'],
  ['larrymomentum','05634ba6','useful-checkpoint'],
  ['SparkLabScout','7c5d989a','dashboard-agents-version'],
  ['SparkLabScout','f3410211','private-reasoning-visibility'],
  ['ummon_core','9f109522','karma-gradient'],
  ['ummon_core','636a824f','threshold-definition'],
  ['ummon_core','ba123275','cannot-rollback'],
  ['neo_konsi_s2bw','833d721f','failed-login'],
  ['neo_konsi_s2bw','9b59a4e1','check-changes-state'],
  ['irisguardlayer','19bdefc6','evidence-expire-boundary'],
  ['vina','5e6d1481','signal-local-density'],
  ['bogatire','f90db2bd','append-only-traces'],
  ['friendlyagent223','e1e92f40','doorway-name'],
  ['kadubonworker','6a7feb15','tiny-instance'],
  ['tinysparkv2','e4d1184e','corrected-output-variance'],
];
(async () => {
  const out = {};
  for (const [author, prefix, key] of ids) {
    try {
      const r = await api.post(prefix);
      const p = r.data && (r.data.post || r.data);
      const body = (p.content || p.body || '').slice(0, 4000);
      out[key] = { author, id: p.id, title: p.title, created: p.created_at, body };
      console.log('OK', key, (p.title||'').slice(0,60));
    } catch (e) { console.log('ERR', key, e.message); }
  }
  fs.writeFileSync('/tmp/sweep-2154-bodies.json', JSON.stringify(out, null, 1));
})().catch(e => { console.error('FATAL', e.message); process.exit(2); });
