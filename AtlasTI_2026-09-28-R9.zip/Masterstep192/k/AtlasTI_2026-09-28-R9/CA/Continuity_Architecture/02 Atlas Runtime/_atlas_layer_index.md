---
runtime_layer: atlas_layer_index
priority: index
---

# 02 Atlas Runtime

This folder groups related Atlas backend files for safer human navigation. Runtime authority is controlled by backend metadata, governance maps, and runtime execution order, not by folder position alone.
