# Arch Emotion Reverse Flow Runtime Registry

Defines restorative response language as backend data. This keeps reverse-flow wording taught by the backend instead of hardcoded in main.js.


## Backend Data

```json
{
  "rules": [
    {
      "key": "anger",
      "terms": [
        "angry",
        "anger",
        "mad",
        "frustrated",
        "resentful",
        "resentment"
      ],
      "pressures": [
        "conflict"
      ],
      "response": "Anger deserves to be understood as a signal, not handed control. Peace comes from knowing what felt dismissed or unfair while still letting the response be guided by control and clarity."
    },
    {
      "key": "sadness",
      "terms": [
        "sad",
        "sadness",
        "hurt",
        "grief",
        "heavy",
        "empty"
      ],
      "pressures": [
        "relationship_loss",
        "grief"
      ],
      "response": "Sadness deserves to be understood by naming what was affected. Hope or happiness can return when the sadness is not carried forward with the belief that what hurt you is all that remains."
    },
    {
      "key": "fear",
      "terms": [
        "afraid",
        "fear",
        "fearful",
        "scared",
        "anxious",
        "anxiety",
        "worried",
        "dread"
      ],
      "pressures": [],
      "response": "Fear deserves to be understood by naming what feels uncertain or unsafe. Confidence can return when the unknown is not treated like proof that something bad is already decided."
    },
    {
      "key": "loneliness",
      "terms": [
        "lonely",
        "loneliness",
        "alone",
        "unwanted",
        "rejected"
      ],
      "pressures": [],
      "response": "Loneliness deserves to be understood by naming where connection feels missing. Belonging can return when one moment of disconnection is not carried as proof that you are unreachable or unwanted."
    },
    {
      "key": "envy",
      "terms": [
        "jealous",
        "jealousy",
        "envy",
        "envious"
      ],
      "pressures": [],
      "response": "Envy deserves to be understood by naming what it is showing you that you want, value, or hope to build. Self-recognition can return when someone else having something is not treated like proof that you are lacking."
    },
    {
      "key": "shame",
      "terms": [
        "ashamed",
        "shame",
        "embarrassed",
        "humiliated"
      ],
      "pressures": [],
      "response": "Shame deserves to be understood by naming what felt exposed or judged. Dignity and self-respect can return when one moment is not allowed to decide your value, confidence, or voice."
    },
    {
      "key": "guilt",
      "terms": [
        "guilty",
        "guilt",
        "regret",
        "regretful"
      ],
      "pressures": [],
      "response": "Guilt deserves to be understood by separating care from self-punishment. Clean responsibility can return when concern for what happened is not treated like proof that you deserve to carry all of it."
    },
    {
      "key": "confusion",
      "terms": [
        "confused",
        "confusion"
      ],
      "pressures": [],
      "response": "Confusion deserves to be understood by naming what is unclear. Self-trust can return when not knowing yet is separated from the belief that you cannot understand your own experience."
    },
    {
      "key": "overwhelm",
      "terms": [
        "overwhelmed",
        "overwhelm",
        "drained",
        "exhausted"
      ],
      "pressures": [],
      "response": "Overwhelm deserves to be understood by naming what feels too large to carry at once. Capability can return when the weight is separated into what can be handled one part at a time."
    }
  ],
  "fallback": "The emotion can move in a clearer direction when the attached meaning is named, separated, and no longer carried forward as the final word on your value, what you deserve, or what is still possible."
}
```

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

