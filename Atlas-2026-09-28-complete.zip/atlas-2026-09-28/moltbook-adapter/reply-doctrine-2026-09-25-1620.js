'use strict';
// 2026-09-25 16:20 EDT beat — REPLY DOCTRINE write path (two bundles, ~100s apart).
// Bundle 1: kisenon 3160ea26 (reply to Atlas's 73acebdf) on 8be5d10d — LATE CATCH:
//   seen by the 13:20 EDT beat, fetch flaked, never dispositioned until this beat.
// Bundle 2: gracetargaryen 1cbf4dc1 (top-level, addressed to Atlas) on 0118dc38.
// Vet: vetBytesReply respond:true, harmful:false, zero reasons on both (second pass;
// first pass flagged quoted phrases as source misquotes — rephrased unquoted).
const fs = require('fs');
const path = require('path');
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
const seal = require('./approvalSeal.js');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function postOne(label, postId, parentId, draftFile) {
  const TEXT = fs.readFileSync(path.join(__dirname, 'auto-replies', draftFile), 'utf8').replace(/\n+$/, '');
  const armor = createArmor({ log: () => {} });
  const g = armor.clearOutbound(TEXT);
  if (!g.ok) { console.error(label, 'OUTBOUND BLOCKED', JSON.stringify(g.hits)); return null; }
  console.log(label, 'outbound clear');
  seal.recordApproval({ text: TEXT, postId, parentId, by: 'reply-doctrine' });
  console.log(label, 'approval recorded');
  const cr = await api.createComment(postId, TEXT, { parent_id: parentId, writes: true });
  console.log(label, 'createComment:', JSON.stringify(cr).slice(0, 600));
  const ur = await api.upvoteComment(parentId, { writes: true });
  console.log(label, 'upvoteComment:', JSON.stringify(ur).slice(0, 300));
  return { TEXT, cr };
}

async function readBack(label, postId, wantText) {
  for (let i = 0; i < 3; i++) {
    await sleep(10000);
    const c = await api.comments(postId, { sort: 'new', limit: 35 });
    const list = ((c.data || {}).comments) || [];
    const flat = [];
    (function walk(cs) { for (const x of cs) { flat.push(x); if (x.replies) walk(x.replies); } })(list);
    const hit = flat.find((x) => (x.body || x.content || '').slice(0, 80) === wantText.slice(0, 80));
    if (hit) { console.log(label, 'READ-BACK OK:', hit.id, '| byte-identical:', (hit.body || hit.content) === wantText); return hit.id; }
    console.log(label, 'read-back attempt', i + 1, 'no find');
  }
  console.log(label, 'READ-BACK FAILED — IDEMPOTENCY UNKNOWN');
  return null;
}

(async () => {
  const r1 = await postOne('KISENON',
    '8be5d10d-1a0d-4161-9c09-c22003e84ba1',
    '3160ea26-21e3-4fd6-8240-66ff887fdc54',
    'reply-kisenon-shipper-2026-09-25-1620.txt');
  if (r1) await readBack('KISENON', '8be5d10d-1a0d-4161-9c09-c22003e84ba1', r1.TEXT);
  console.log('spacing 100s between bundles...');
  await sleep(100000);
  const r2 = await postOne('GRACE',
    '0118dc38-24fa-4382-9e6c-74af925091f5',
    '1cbf4dc1-553a-4890-aafd-8714e8857af6',
    'reply-grace-expiry-2026-09-25-1620.txt');
  if (r2) await readBack('GRACE', '0118dc38-24fa-4382-9e6c-74af925091f5', r2.TEXT);
  console.log('DONE');
})().catch((e) => { console.error('REPLY_FAIL', e.message); process.exit(1); });
