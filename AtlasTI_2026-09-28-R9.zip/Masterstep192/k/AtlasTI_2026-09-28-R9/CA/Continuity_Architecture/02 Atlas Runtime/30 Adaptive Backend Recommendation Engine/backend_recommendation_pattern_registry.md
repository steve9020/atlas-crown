# Backend Recommendation Pattern Registry

Defines specific recommendation patterns, names, reasons, merge targets, and assessment notes as backend data. main.js should detect and display these, not own their meaning.


## Backend Data

```json
{
  "patterns": [
    {
      "id": "space_guilt_selfishness_failure_loop",
      "readableTitle": "Needing space interpreted as selfishness or failure",
      "category": "emotional_loop",
      "matchGroups": [
        [
          "need space",
          "needed space",
          "taking space",
          "stepping back",
          "step back",
          "say no",
          "saying no",
          "boundary",
          "limit"
        ],
        [
          "guilt",
          "guilty",
          "selfish",
          "hurt them",
          "hurting them",
          "failed them",
          "failing them",
          "doing something wrong",
          "wrong for",
          "overwhelmed",
          "capacity"
        ]
      ],
      "reason": "The prompt connects needing space or stepping back with guilt, selfishness, fear of hurting someone, and replaying the choice as if having a limit means failing them.",
      "assessmentReason": "This may need review because it names a specific human pattern: a valid need for space becoming attached to selfishness, harm, or failure meaning. It should be considered only if it is not already covered by boundary guilt.",
      "possibleInterpretation": "A need for space can become harder to accept when it gets attached to the conclusion that having a limit means being selfish, harmful, or failing someone.",
      "targetRegistry": "emotional_loop_formation_registry",
      "frontendTranslationNote": "Name the need for space directly, separate guilt from selfishness/failure meaning, and move toward clean responsibility and capacity being respected.",
      "possibleMergeTargets": [
        "boundary_selfishness_guilt_loop"
      ]
    },
    {
      "id": "personal_progress_guilt_care_conflict_loop",
      "readableTitle": "Personal progress interpreted as selfishness or lack of care",
      "category": "mixed_emotional_branch",
      "matchGroups": [
        [
          "happy",
          "happiness",
          "joy",
          "proud",
          "pride",
          "progress",
          "good for myself",
          "chance to do something good"
        ],
        [
          "guilt",
          "guilty",
          "selfish",
          "stopped caring",
          "care",
          "others are struggling",
          "people around me are struggling"
        ]
      ],
      "reason": "The prompt connects happiness or pride about personal progress with guilt, concern for others, and the fear that enjoying progress means being selfish or no longer caring.",
      "assessmentReason": "This may need review because it names a specific mixed-emotion branch: personal progress plus care-related guilt. It should not be treated as generic positive discomfort.",
      "possibleInterpretation": "A good thing for the person can become harder to receive when happiness gets attached to the conclusion that caring about their own progress means they stopped caring about others.",
      "targetRegistry": "emotional_mixed_state_registry + arch_emotion_reverse_flow_registry",
      "frontendTranslationNote": "Explain that being happy for your own progress does not prove you stopped caring about others. Move toward clean happiness/pride with compassion intact.",
      "possibleMergeTargets": [
        "pride_arrogance_discomfort_loop",
        "boundary_selfishness_guilt_loop",
        "relief_guilt_lack_of_care_loop"
      ]
    },
    {
      "id": "jealousy_shame_comparison_branch_loop",
      "readableTitle": "Jealousy becoming shame and comparison pressure",
      "category": "mixed_emotional_branch",
      "matchGroups": [
        [
          "jealous",
          "jealousy",
          "envy",
          "envious",
          "comparing",
          "comparison",
          "behind",
          "not doing enough",
          "their good moment",
          "someone close to me",
          "wanted for a long time"
        ],
        [
          "ashamed",
          "shame",
          "guilty",
          "bad person",
          "turning their good moment",
          "about me"
        ]
      ],
      "reason": "The prompt connects jealousy or envy with shame, comparison, feeling behind, and the fear that someone else's good moment says something negative about the person.",
      "assessmentReason": "This may need review if the existing jealousy/comparison pattern does not cover shame about the emotion itself. It should merge if that coverage already exists.",
      "possibleInterpretation": "Jealousy can point toward something the person wants, while shame can turn that signal into self-judgment or comparison against their value.",
      "targetRegistry": "emotional_mixed_state_registry + emotional_attached_meaning_registry",
      "frontendTranslationNote": "Do not treat jealousy as proof of bad character. Move toward self-recognition and value without lowering the other person's good moment.",
      "possibleMergeTargets": [
        "jealousy_envy_worth_comparison_loop"
      ]
    }
  ]
}
```
