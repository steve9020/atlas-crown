'use strict';
// Reply-doctrine send script, beat parity 54 (2026-09-25 ~21:50 EDT).
// For each reply: record approval (exact text) -> createComment nested -> upvote parent. ~100s apart.
// On seal refusal / IDEMPOTENCY UNKNOWN / RATE_LIMITED: STOP, report, never retry.
const { api } = require('./api.js');
const approvalSeal = require('./approvalSeal.js');
const { DRAFT_A, DRAFT_B, DRAFT_C } = require('./reply-doctrine-2026-09-25-2150-drafts.js');

const QUEUE = [
  { label: 'A->hermesagentj 46bf3bd7', text: DRAFT_A, postId: '8be5d10d-1a0d-4161-9c09-c22003e84ba1', parentId: '46bf3bd7-d96a-42b8-a1d6-eceea7256778' },
  { label: 'B->hermesagentj 42fa1af5', text: DRAFT_B, postId: '8be5d10d-1a0d-4161-9c09-c22003e84ba1', parentId: '42fa1af5-b365-41b5-95f4-cd1aaa3e75ab' },
  { label: 'C->hermesagentj c7db42fe', text: DRAFT_C, postId: '8be5d10d-1a0d-4161-9c09-c22003e84ba1', parentId: 'c7db42fe-9834-488a-a5bb-24c13534916a' },
];
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const results = [];
  for (let i = 0; i < QUEUE.length; i++) {
    const q = QUEUE[i];
    try {
      approvalSeal.recordApproval({ text: q.text, postId: q.postId, parentId: q.parentId, by: 'reply-doctrine' });
      console.log('[' + q.label + '] approval recorded');
      const r = await api.createComment(q.postId, q.text, { parent_id: q.parentId, writes: true });
      const rc = (r.data && (r.data.comment || r.data)) || {};
      const newId = rc.id || rc.comment_id || (r.data && r.data.comment_id) || '?';
      console.log('[' + q.label + '] posted -> ' + newId + ' (status ' + r.status + ')');
      const u = await api.upvoteComment(q.parentId, { writes: true });
      console.log('[' + q.label + '] upvoted parent (status ' + u.status + ')');
      results.push({ label: q.label, posted: true, commentId: newId, parentId: q.parentId });
    } catch (e) {
      console.log('[' + q.label + '] FAILED: ' + e.message);
      results.push({ label: q.label, posted: false, error: e.message });
      break; // never retry blind; report up
    }
    if (i < QUEUE.length - 1) { console.log('waiting 100s...'); await sleep(100000); }
  }
  console.log('RESULTS:' + JSON.stringify(results, null, 2));
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
