# Context-Before-Route Evidence Sufficiency Matrix

Current keeper: Masterstep131.zip  
Source keeper: Masterstep130.zip  
Proof command: `node proof/runCurrentProof.js`  
Expected proof target: 53/53 commands passed

## Purpose

Masterstep131 implements the first narrow meaning-matrix expansion selected by Masterstep130: **context-before-route evidence sufficiency**.

The matrix checks whether Atlas has enough evidence before route selection proceeds. This protects Compass from translating too early when the attached meaning is unclear, when multiple meanings are plausible, or when the prompt is literal/practical and should not be over-reflected.

## Evidence dimensions

The matrix evaluates:

- surface event
- attached meaning
- unsupported conclusion
- emotional pressure
- restoration direction
- literal/practical boundary
- competing meanings
- route readiness

## Outcomes

The matrix may return:

- `proceed` — enough evidence exists for route selection.
- `hold` — essential context is missing.
- `low_confidence` — evidence is partial, competing, or practical/literal enough to avoid premature reflective routing.

## Boundary

This is deterministic backend matrix logic only. It does not give the local model authority, does not let the model author matrix rules, does not add frontend matrix intelligence, does not approve teaching, does not allow cloud/provider fallback, and does not allow silent learning or silent mutation.

Candidate phrasing remains frozen as candidate-only support and cannot replace final output.
