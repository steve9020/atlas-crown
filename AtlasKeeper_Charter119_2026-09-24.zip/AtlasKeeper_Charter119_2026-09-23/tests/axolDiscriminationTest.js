const assert = require('assert');
const { detectAxes } = require('../Cognition/engine/AxisEngine.js');
const cases = [
  ['I heard the words myself, but I do not know what they meant.', ['observation_evidence','certainty'], {certainty:'uncertain'}],
  ['I guessed she was upset without asking her.', ['assumption'], {}],
  ['He was trying to help, even though what happened hurt me.', ['intention','impact'], {}],
  ['It hurt, but that alone does not tell me whose fault it was.', ['impact','responsibility'], {responsibility:'negated'}],
  ['I own my part, but I cannot own the choice he made.', ['responsibility','ownership','choice'], {choice:'negated'}],
  ['She told me to do it; that does not make her the authority over the decision.', ['authority','choice'], {authority:'negated'}],
  ['I can influence the outcome, but I cannot control it.', ['control','outcome'], {control:'negated'}],
  ['I chose to stay even though I felt pressure to leave.', ['choice'], {}],
  ['I was expected to call, but nobody required me to.', ['expectation','obligation'], {obligation:'negated'}],
  ['We disagreed without either of us crossing the boundary.', ['boundary'], {boundary:'negated'}],
  ['His explanation changed, but the two versions do not directly contradict each other.', ['change','contradiction'], {contradiction:'negated'}],
  ['She did more work than I did, but that does not make either of us more valuable.', ['comparison','effort'], {}],
  ['I respect her position without trusting her conclusion.', ['respect','trust'], {trust:'negated'}],
  ['We both contributed, but not in equal ways.', ['reciprocity','fairness'], {fairness:'negated'}],
  ['This happened yesterday; I am not saying it will always happen.', ['temporal_scope','permanence'], {permanence:'negated'}],
  ['I tried hard and still did not finish.', ['effort','outcome'], {outcome:'negated'}],
  ['Finishing it did not make it enough for the purpose.', ['outcome','sufficiency'], {sufficiency:'negated'}],
  ['We are still connected even though I rejected that request.', ['connection','acceptance_rejection'], {}],
  ['I accepted the apology, but the repair has not happened yet.', ['acceptance_rejection','repair'], {repair:'negated'}],
  ['The result followed the decision, but I do not know whether the decision caused it.', ['outcome','choice','causation','certainty'], {causation:'uncertain',certainty:'uncertain'}],
];
let passed=0;
for (const [text, expected, stateExpected] of cases) {
  const r=detectAxes(text);
  const missing=expected.filter(a=>!r.axes.includes(a));
  const stateMiss=[];
  for (const [axis,state] of Object.entries(stateExpected)) {
    const e=r.axis_evidence.find(x=>x.axis===axis);
    if (!e || !e.states.includes(state)) stateMiss.push(`${axis}:${state}`);
  }
  if (missing.length || stateMiss.length) {
    console.error('FAIL', text, '\n axes=',r.axes,'\n evidence=',JSON.stringify(r.axis_evidence),'\n missing=',missing,'stateMiss=',stateMiss);
  } else passed++;
}
assert.strictEqual(passed,cases.length,`AXOL discrimination ${passed}/${cases.length}`);
console.log(`AXOL discrimination PASS ${passed}/${cases.length}`);
