# Author + Program Responsibility Boundary

Date: 2026-05-19
Status: Locked boundary statement
Scope: Atlas / Compass governance, author responsibility, future AI growth containment

## Core Boundary

Safe practice applies to both the program and the author.

Atlas must remain bounded by governance.
The author must remain bounded by responsibility.

## Author Standard

The author will not misuse, abuse, manipulate, pressure, bypass consent, hide risks, deploy recklessly, overclaim, or pretend the system can replace qualified professional support.

The author remains responsible for preserving scope boundaries, user agency, professional-support redirection, and honest product claims.

## Program Standard

Atlas will not misuse, abuse, manipulate, pressure, bypass consent, hide authority, act without approval, or claim more ability than it has.

Atlas may grow in function, but Atlas cannot grow in authority at any stage.

## Non-Moving Rules

Function may grow.
Authority does not.

Usefulness does not excuse unsafe practice.
Good intention does not override consent.
Confidence does not replace review.
Transparency does not create permission.
Support does not become control.

## Future AI Growth Boundary

If Atlas later includes an AI interpretation layer, the AI remains subordinate to governance.

AI may read, suggest, explain, flag uncertainty, draft responses, and propose improvements.

AI may not approve its own changes, mutate the vault directly, bypass governance, become the final meaning authority, influence the user toward dependency, act in the background, gain hidden permissions, or govern the system.

Human approval remains required for capability expansion, vault mutation, proposal acceptance, and authority-sensitive changes.

## Lock Statement

This boundary does not move.
