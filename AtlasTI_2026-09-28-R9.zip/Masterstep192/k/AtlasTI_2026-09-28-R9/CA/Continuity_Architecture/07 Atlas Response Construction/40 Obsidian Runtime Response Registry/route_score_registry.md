# Route Score Registry

Purpose: stores route confidence scoring rules in the Obsidian backend so runtime code remains a generic scorer/evaluator instead of owning Atlas/Compass-specific route confidence rules.

Boundary: this registry may declare score weights, bonus rules, maximum score, confidence thresholds, and non-authoritative notes. It may not bypass governance, diagnose, mutate backend files, create authority, or override response quality checks.

Runtime use: `RouteScorer.js` reads this JSON registry and applies generic scoring operations against detected axes, detected signals, and selected return mode. The result is structural confidence only, not a claim of truth.

```json
{
  "version": "OBSIDIAN_ROUTE_SCORE_REGISTRY_STAGE4",
  "scoreMode": "generic_weighted_sum_with_caps",
  "baseWeights": {
    "axis": 20,
    "signal": 10,
    "nonNeutralReturnMode": 20
  },
  "bonusRules": [
    {
      "id": "worth_permanence_combination",
      "when": {
        "axesAll": ["worth", "permanence"]
      },
      "bonus": 10
    },
    {
      "id": "identity_permanence_combination",
      "when": {
        "axesAll": ["identity", "permanence"]
      },
      "bonus": 10
    },
    {
      "id": "hypervigilance_signal_bonus",
      "when": {
        "signalsAll": ["hypervigilance"]
      },
      "bonus": 5
    },
    {
      "id": "shame_after_visibility_signal_bonus",
      "when": {
        "signalsAll": ["shame_after_visibility"]
      },
      "bonus": 5
    }
  ],
  "maximumScore": 100,
  "confidenceThresholds": [
    {
      "confidence": "high",
      "minimumScore": 70
    },
    {
      "confidence": "medium",
      "minimumScore": 40
    },
    {
      "confidence": "low",
      "minimumScore": 0
    }
  ],
  "note": "Route confidence is a structural signal, not a claim of truth."
}
```
