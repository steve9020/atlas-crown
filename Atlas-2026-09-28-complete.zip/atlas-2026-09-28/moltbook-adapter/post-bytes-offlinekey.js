'use strict';
// One-shot AUTO-RESPONSE post: comment + bundled post upvote.
// Writes enabled ONLY via MOLTBOOK_WRITES=1 in env. Nothing else writes.
const fs = require('fs');
const { api } = require('./api.js');
const POST_ID = '8e7414d0-405a-4111-9c44-3c3d210892b7';
const TEXT = fs.readFileSync('./auto-replies/replyD-8e7414d0.txt', 'utf8');
(async () => {
  try {
    const c = await api.createComment(POST_ID, TEXT, { writes: true });
    console.log('COMMENT published:', c.published, '| status:', c.response && c.response.status);
    const u = await api.upvotePost(POST_ID, { writes: true });
    console.log('UPVOTE ok:', u.ok, '| status:', u.status);
  } catch (e) {
    console.log('FAILED:', e.message);
  }
})();
