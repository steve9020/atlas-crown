const { main } = require("../main.js");

function runHealthCheck() {
  const result = main("Health check: I feel like something is off but I do not know what yet");

  const checks = {
    pipeline_active: result.status === "pipeline active",
    input_validation_present: !!result.input_validation,
    signals_present: !!result.signals,
    cognition_present: !!result.cognition,
    return_mode_present: !!result.return_mode,
    quality_present: !!result.quality,
    governance_present: !!result.governance,
    output_present: typeof result.output === "string" && result.output.length > 0
  };

  const passed = Object.values(checks).every(Boolean);

  console.log("\nATLAS HEALTH CHECK");
  console.log("==================");
  console.log("Passed:", passed);
  console.log(checks);

  if (!passed) {
    process.exitCode = 1;
  }
}

runHealthCheck();