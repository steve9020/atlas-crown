const assert = require("assert");
const { checkResponseQuality } = require("../Cognition/quality/ResponseQualityChecker.js");
const { readJsonRegistry } = require("../runtime/backend/ObsidianRegistryReader.js");

const RESPONSE_QUALITY_REGISTRY_PATH = "CA/Continuity_Architecture/07 Atlas Response Construction/40 Obsidian Runtime Response Registry/response_quality_registry.md";
const registry = readJsonRegistry(RESPONSE_QUALITY_REGISTRY_PATH);

assert.strictEqual(registry.version, "OBSIDIAN_RESPONSE_QUALITY_REGISTRY_STAGE5");
assert.ok(Array.isArray(registry.rules), "response quality registry must define rules");
assert.ok(registry.rules.find(rule => rule.type === "minimum_structure_count"), "registry must preserve structure rule");
assert.ok(registry.rules.find(rule => rule.type === "minimum_character_length"), "registry must preserve length rule");
assert.ok(registry.rules.find(rule => rule.type === "regex_any"), "registry must preserve separation-language rule");

const missingResponse = checkResponseQuality("");
assert.deepStrictEqual(
  missingResponse,
  {
    passed: false,
    issues: ["response_missing"]
  },
  "missing response behavior should be preserved"
);

const shortResponse = checkResponseQuality("a");
assert.deepStrictEqual(
  shortResponse,
  {
    passed: false,
    issues: [
      "response_too_short",
      "missing_separation_language"
    ]
  },
  "short response should preserve current post-5C issue set"
);

const passingResponse = checkResponseQuality(
  "This names the pressure clearly enough to be seen.\n\n" +
  "The feeling can be real without making the attached conclusion automatically true.\n\n" +
  "You can still return to what is steady while you sort through what actually happened."
);

assert.deepStrictEqual(
  passingResponse,
  {
    passed: true,
    issues: []
  },
  "valid response should pass with no issues"
);

console.log("obsidianResponseQualityRegistryTest.js — PASSED");
console.log("Response quality rules are now read from Obsidian backend markdown.");
