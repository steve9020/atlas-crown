# Auto Teaching Engine Overview

## Purpose
The Auto Teaching Engine generates scenario prompts, runs Compass responses, evaluates those responses, detects repeated failure patterns, and sends complete weak-point proposals into review.

## Core Flow
Generate scenario → run Compass → evaluate response → detect weakness → send to 42 Weak Point Gap Completion Engine → proposal review → approval / implementation.

## Core Rule
Auto teaching proposes learning. It does not silently mutate Atlas.

## Teaching Goal
Atlas should learn from repeated failure patterns rather than isolated preference corrections.


## Full Scenario Category Expansion
Auto teaching now includes the broader scenario category set, including vulnerability, relational inconsistency, self-worth, boundary/respect, mixed emotions, positive emotions with vulnerability, prompt-shape tests, scope boundaries, journal continuity, and goal momentum.


## Rotation + Load Control
Auto teaching should route through `44 Auto Teaching Rotation Load Control` before generating scenario batches or proposals.

This prevents prompt repetition, category overuse, proposal flooding, and overfitting to one emotional family.


## Balanced Teaching Coverage
Auto teaching should use balanced scenario coverage so every category receives testing over time instead of repeating the same emotional family.
