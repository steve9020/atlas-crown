# Variation Style Registry

Purpose: stores Compass variation selection rules in the Obsidian backend so runtime code remains a generic reader/evaluator instead of owning Atlas/Compass-specific style routing.

Boundary: this registry may declare ordered variation-selection rules and fallback style keys. It may not bypass governance, diagnose, create new authority, mutate backend files, or override response quality checks.

Runtime use: `VariationEngine.js` reads this JSON registry and selects the first matching rule in priority order. The selected style keys are then passed to the response line registry.

```json
{
  "version": "OBSIDIAN_VARIATION_REGISTRY_STAGE2",
  "selectionMode": "first_match_priority_order",
  "rules": [
    {
      "id": "mistake_progress_pressure",
      "priority": 10,
      "when": {
        "patternsAll": ["mistake_progress_pressure"]
      },
      "variation": {
        "seeStyle": "mistake_progress_pressure",
        "separateStyle": "mistake_not_progress_collapse",
        "returnStyle": "progress_continuity_restore"
      }
    },
    {
      "id": "worth_with_permanence",
      "priority": 20,
      "when": {
        "axesAll": ["worth", "permanence"]
      },
      "variation": {
        "seeStyle": "worth_pressure",
        "separateStyle": "moment_not_identity",
        "returnStyle": "worth_with_future_release"
      }
    },
    {
      "id": "worth_basic",
      "priority": 30,
      "when": {
        "axesAll": ["worth"]
      },
      "variation": {
        "seeStyle": "worth_pressure",
        "separateStyle": "moment_not_identity",
        "returnStyle": "worth_basic"
      }
    },
    {
      "id": "identity_basic",
      "priority": 40,
      "when": {
        "axesAll": ["identity"]
      },
      "variation": {
        "seeStyle": "identity_pressure",
        "separateStyle": "self_not_moment",
        "returnStyle": "identity_basic"
      }
    },
    {
      "id": "belonging_basic",
      "priority": 50,
      "when": {
        "axesAll": ["belonging"]
      },
      "variation": {
        "seeStyle": "belonging_pressure",
        "separateStyle": "feeling_not_rejection",
        "returnStyle": "belonging_basic"
      }
    },
    {
      "id": "emotional_validity_basic",
      "priority": 60,
      "when": {
        "axesAll": ["emotional_validity"]
      },
      "variation": {
        "seeStyle": "emotion_validity_pressure",
        "separateStyle": "feeling_not_wrong",
        "returnStyle": "emotional_validity_basic"
      }
    },
    {
      "id": "perfection_basic",
      "priority": 70,
      "when": {
        "axesAll": ["perfection"]
      },
      "variation": {
        "seeStyle": "perfection_pressure",
        "separateStyle": "imperfection_not_failure",
        "returnStyle": "perfection_basic"
      }
    },
    {
      "id": "detachment_basic",
      "priority": 80,
      "when": {
        "axesAll": ["detachment"]
      },
      "variation": {
        "seeStyle": "detachment_pressure",
        "separateStyle": "withdrawal_not_required",
        "returnStyle": "detachment_basic"
      }
    },
    {
      "id": "permanence_basic",
      "priority": 90,
      "when": {
        "axesAll": ["permanence"]
      },
      "variation": {
        "seeStyle": "future_locking",
        "separateStyle": "not_final",
        "returnStyle": "permanence_basic"
      }
    }
  ],
  "fallback": {
    "seeStyle": "general_pressure",
    "separateStyle": "general_separation",
    "returnStyle": "general_return"
  }
}
```
