# Extended Family Role Registry

## Roles
- aunt / auntie / aunty
- uncle
- cousin / cuz
- relatives
- family

## Priority
Context-sensitive emotional weight.

## Common Meaning Pressure
- belonging
- inclusion
- family loyalty
- approval
- being misunderstood
- comparison
- distance
- exclusion

## Runtime Rule
Extended family roles should increase relational context priority when paired with exclusion, judgment, silence, conflict, or family-system pressure.
