---
runtime_layer: scenario_specific_response_construction
registry_type: scenario_object_runtime
purpose: Backend-owned scenario object extraction patterns used before route selection and clarification gating.
governed_by:
  - scenario_object_extraction_registry
  - runtime_context_sufficiency_registry
---

# Scenario Object Runtime Registry

Scenario object extraction identifies what the prompt is actually about before Atlas asks questions or renders a response.

## Scenario Object JSON

```json
{
  "objects": [
    {
      "key": "relief_after_crossed_boundaries",
      "matchGroups": [
        ["relief", "relieved", "lighter", "peace"],
        ["guilt", "guilty", "cold", "never cared", "didn't care", "dont care", "don't care"],
        ["crossed lines", "crossed a line", "boundaries", "kept trying to explain", "hurt me", "lost peace", "trying to keep the connection together"]
      ],
      "primaryScenarioObject": "relief after distance from a connection that crossed lines",
      "primaryEmotionalMovement": "relief being misread as coldness or lack of care",
      "secondaryEmotions": ["guilt", "relief", "care", "anger"],
      "attachedMeanings": ["relief may mean coldness", "distance may mean you never cared", "peace may mean selfishness"],
      "preferredRoute": "relief_and_permission",
      "suppressClarification": true,
      "voice": {
        "opener": "I get why that would feel confusing and heavy.",
        "situation": "When you feel relief after distance from someone you still care about, especially after lines were crossed",
        "emotionalEffects": "it can affect guilt, care, anger, peace, and the fear that relief means you are cold or that you never cared",
        "pattern": "It can move from, “I feel lighter with distance,” into, “Maybe that means I am cold. Maybe I never really cared.” But relief can show that the pressure stopped, not that the person never mattered.",
        "proofBoundary": "Feeling relieved by distance does not prove you are cold. It may show that closeness had started costing more peace than it should have.",
        "whySeparate": "That separation matters because care and closeness are not the same thing. You can care about someone and still recognize that staying close was hurting your peace.",
        "reverse": "The movement here is from guilt about relief toward permission to recognize what the distance protected.",
        "anchor": "Relief does not erase care. It can simply show that your peace stopped being pulled into something that had become too costly."
      }
    },
    {
      "key": "conflict_with_perceived_putdown",
      "matchGroups": [
        ["argument", "fight", "conflict", "disagreement"],
        ["putting her down", "putting him down", "putting them down", "criticizing", "truth", "exposing the truth", "lifting her up", "lifting him up", "helping them"],
        ["process", "understand", "accountability", "responsibility", "truth"]
      ],
      "primaryScenarioObject": "trying to tell someone a hard truth during conflict",
      "primaryEmotionalMovement": "intention to help being received as harm",
      "secondaryEmotions": ["frustration", "anger", "care", "confusion"],
      "attachedMeanings": ["if the truth is meant to help, it should automatically feel supportive", "being right may mean the delivery is clear"],
      "preferredRoute": "conflict_and_disconnection",
      "suppressClarification": true,
      "voice": {
        "opener": "I get why that would feel frustrating.",
        "situation": "When you are trying to point out something you believe is true during an argument",
        "emotionalEffects": "it can affect intention, impact, respect, clarity, defensiveness, and whether help starts sounding like criticism",
        "pattern": "It can move from, “I am trying to help by naming the truth,” into, “If they feel put down, they must be avoiding the truth.” But the intention behind a message and the way it lands are not always the same thing.",
        "proofBoundary": "Believing you are lifting someone up does not automatically mean the delivery felt supportive to them. Their reaction does not automatically make your point false either.",
        "whySeparate": "That separation matters because conflict needs both truth and impact to be understood. If either side is ignored, the conversation can turn into defending the message instead of understanding what happened between you.",
        "reverse": "The movement here is from proving the truth toward clarifying how the truth is being carried, received, and repaired.",
        "anchor": "A hard truth can still need a clean delivery. Being helpful means understanding both what you meant and how it affected the other person."
      }
    },
    {
      "key": "distance_self_blame",
      "matchGroups": [
        ["pulling away", "pulled away", "distant", "distance", "acting different", "inconsistent"],
        ["my fault", "did something wrong", "too much", "unwanted", "not enough", "caused"]
      ],
      "primaryScenarioObject": "distance being interpreted as personal fault",
      "primaryEmotionalMovement": "relational uncertainty turning into self-blame",
      "secondaryEmotions": ["hurt", "fear", "confusion"],
      "attachedMeanings": ["distance means you caused it", "changed energy means you were too much"],
      "preferredRoute": "rejection_and_abandonment",
      "suppressClarification": true
    },
    {
      "key": "dismissal_overreaction_confusion",
      "matchGroups": [
        ["dismissed", "dramatic", "overreacting", "invalidated", "unheard", "minimized"],
        ["angry", "hurt", "frustrated", "confused", "questioning"]
      ],
      "primaryScenarioObject": "being dismissed and then questioning your reaction",
      "primaryEmotionalMovement": "invalidation turning into self-doubt",
      "secondaryEmotions": ["anger", "hurt", "confusion"],
      "attachedMeanings": ["having a reaction means you are dramatic", "being affected means you are wrong"],
      "preferredRoute": "invalidation_and_unheardness",
      "suppressClarification": true
    }
  ]
}
```

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

