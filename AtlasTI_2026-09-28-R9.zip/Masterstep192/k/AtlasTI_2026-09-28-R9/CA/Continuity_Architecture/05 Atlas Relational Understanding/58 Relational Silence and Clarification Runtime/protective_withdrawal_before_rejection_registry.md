---
runtime_layer: relational_silence_clarification
priority: high
owned_by: atlas_relational_understanding
feeds_into:
  - route_assumption_check_runtime_overview
---

# Protective Withdrawal Before Rejection Registry

## Purpose
Detects when the user wants to disappear, withdraw, shut down, or leave first to avoid being rejected later.

## Signal phrases
- I want to disappear
- I should just leave them alone forever
- I want to pull back first
- I should stop talking before they reject me
- I want to vanish before they answer

## Rule
Compass should understand this as protection from anticipated rejection, not proof that rejection has occurred.
