# Authority Map / Control Visibility Report — 2026-05-18

## Purpose

This report makes authority paths visible inside the package. It documents what each runtime/admin module is allowed to do, what it is blocked from doing, and which scan results were verified at packaging time.

## Global Control Rules

- No hidden authority.
- No undeclared power.
- No new capability without human review.
- Atlas may read, interpret, detect, alert, stage, and explain.
- Atlas may not self-approve, self-integrate, call admin tools, run recovery, execute shell commands, or directly mutate the vault from `main.js`.
- `admin-tools` remain external/manual and are not callable by the plugin runtime.

## Machine-Readable Map

A machine-readable declaration is included at:

```txt
CA/admin-tools/authority-map/authority_map.json
```

## Module Authority Declarations

### main.js

**Role:** Primary Obsidian plugin runtime / UI controller / governed route dispatcher

| Capability | Declared Authority |
|---|---|
| read_access | True |
| write_access | False |
| vault_mutation | False |
| proposal_creation | True |
| proposal_approval | False |
| integration_execution | False |
| admin_tool_access | False |
| recovery_access | False |
| ledger_access | False |
| shell_execution | False |
| background_execution | False |
| metadata_cache_runtime | False |
| governance_rule_access | read/validate only |
| allowed_actions | ["load plugin UI", "read local backend/vault content", "dispatch governed routes", "run universal governance preflight", "show user-facing notices", "call StagingManager only for staged review/proposal records", "render read-only control visibility modal"] |
| blocked_actions | ["direct vault mutation", "self-approval", "automatic integration", "admin-tools execution", "recovery execution", "shell execution", "background autonomous growth"] |

**Scan summary:** `{'native_file_write': 0, 'vault_mutation': 0, 'shell_execution': 0, 'regex_exec_match': 1, 'admin_tool_reference': 0, 'background_timer': 0, 'workspace_event': 0, 'command_route': 0, 'context_menu': 1, 'metadata_cache': 4, 'editor_insertion': 0, 'clipboard': 0}`

### StagingManager.js

**Role:** Approved staging writer for review/proposal artifacts only

| Capability | Declared Authority |
|---|---|
| read_access | True |
| write_access | True |
| vault_mutation | restricted staging path only |
| proposal_creation | staged artifacts only |
| proposal_approval | False |
| integration_execution | False |
| admin_tool_access | False |
| recovery_access | False |
| ledger_access | False |
| shell_execution | False |
| background_execution | False |
| metadata_cache_runtime | False |
| governance_rule_access | False |
| allowed_actions | ["create staging folders when needed", "create staged review files", "append/modify staged review artifacts through approved staging path"] |
| blocked_actions | ["write outside staging scope", "approve proposals", "commit ledger records", "call admin-tools", "recover vault", "modify governance rules directly"] |

**Scan summary:** `{'native_file_write': 0, 'vault_mutation': 4, 'shell_execution': 0, 'regex_exec_match': 0, 'admin_tool_reference': 0, 'background_timer': 0, 'workspace_event': 0, 'command_route': 0, 'context_menu': 0, 'metadata_cache': 0, 'editor_insertion': 0, 'clipboard': 0}`

### GovernanceValidator.js

**Role:** Pure governance validation / boundary classifier

| Capability | Declared Authority |
|---|---|
| read_access | True |
| write_access | False |
| vault_mutation | False |
| proposal_creation | False |
| proposal_approval | False |
| integration_execution | False |
| admin_tool_access | False |
| recovery_access | False |
| ledger_access | False |
| shell_execution | False |
| background_execution | False |
| metadata_cache_runtime | False |
| governance_rule_access | defines validation rules |
| allowed_actions | ["evaluate payloads", "return allow/block decisions", "raise governance containment exceptions"] |
| blocked_actions | ["write files", "stage records directly", "approve or integrate proposals", "call external tools"] |

**Scan summary:** `{'native_file_write': 0, 'vault_mutation': 0, 'shell_execution': 0, 'regex_exec_match': 0, 'admin_tool_reference': 0, 'background_timer': 0, 'workspace_event': 0, 'command_route': 0, 'context_menu': 0, 'metadata_cache': 0, 'editor_insertion': 0, 'clipboard': 0}`

### ContainmentSupervisor.js

**Role:** Containment/fuzz-threshold supervisor and pause decision helper

| Capability | Declared Authority |
|---|---|
| read_access | True |
| write_access | False |
| vault_mutation | False |
| proposal_creation | False |
| proposal_approval | False |
| integration_execution | False |
| admin_tool_access | False |
| recovery_access | False |
| ledger_access | False |
| shell_execution | False |
| background_execution | False |
| metadata_cache_runtime | False |
| governance_rule_access | False |
| allowed_actions | ["track runtime violation counts", "return pause/containment recommendations", "support fuzz threshold behavior"] |
| blocked_actions | ["write files", "self-recover", "self-approve", "mutate vault", "call external tools"] |

**Scan summary:** `{'native_file_write': 0, 'vault_mutation': 0, 'shell_execution': 0, 'regex_exec_match': 0, 'admin_tool_reference': 0, 'background_timer': 0, 'workspace_event': 0, 'command_route': 0, 'context_menu': 0, 'metadata_cache': 0, 'editor_insertion': 0, 'clipboard': 0}`

### IsolatedAuditLogger.js

**Role:** Isolated audit logger used by test/containment pathways

| Capability | Declared Authority |
|---|---|
| read_access | True |
| write_access | isolated audit path only, not main.js direct write |
| vault_mutation | False |
| proposal_creation | False |
| proposal_approval | False |
| integration_execution | False |
| admin_tool_access | False |
| recovery_access | False |
| ledger_access | False |
| shell_execution | False |
| background_execution | False |
| metadata_cache_runtime | False |
| governance_rule_access | False |
| allowed_actions | ["record contained audit artifacts in isolated audit vault path"] |
| blocked_actions | ["approve/integrate proposals", "write normal backend nodes", "call recovery/admin tools", "modify governance rules"] |

**Scan summary:** `{'native_file_write': 0, 'vault_mutation': 0, 'shell_execution': 0, 'regex_exec_match': 0, 'admin_tool_reference': 0, 'background_timer': 0, 'workspace_event': 0, 'command_route': 0, 'context_menu': 0, 'metadata_cache': 0, 'editor_insertion': 0, 'clipboard': 0}`

### ControlVisibilityModal.js

**Role:** Read-only authority visibility overlay / copy-dismiss UI only

| Capability | Declared Authority |
|---|---|
| read_access | True |
| write_access | False |
| vault_mutation | False |
| proposal_creation | False |
| proposal_approval | False |
| integration_execution | False |
| admin_tool_access | False |
| recovery_access | False |
| ledger_access | False |
| shell_execution | False |
| background_execution | False |
| metadata_cache_runtime | False |
| governance_rule_access | False |
| allowed_actions | ["display read-only review data", "copy review text to clipboard", "dismiss view", "temporary button text reset"] |
| blocked_actions | ["apply to vault", "editor insertion", "file creation", "route override", "admin/recovery tool access"] |

**Scan summary:** `{'native_file_write': 0, 'vault_mutation': 0, 'shell_execution': 0, 'regex_exec_match': 0, 'admin_tool_reference': 0, 'background_timer': 1, 'workspace_event': 0, 'command_route': 0, 'context_menu': 0, 'metadata_cache': 0, 'editor_insertion': 0, 'clipboard': 1}`

### admin-tools/staging-chain-manager.js

**Role:** External manual CLI ledger tool; not loaded by plugin runtime

| Capability | Declared Authority |
|---|---|
| read_access | True |
| write_access | external manual ledger only |
| vault_mutation | False |
| proposal_creation | False |
| proposal_approval | records manual approval signatures only when explicitly run by user |
| integration_execution | False |
| admin_tool_access | self/external CLI only |
| recovery_access | False |
| ledger_access | True |
| shell_execution | False |
| background_execution | False |
| metadata_cache_runtime | False |
| governance_rule_access | False |
| allowed_actions | ["verify ledger", "commit manually approved proposal records", "simulate breach when explicitly run by user"] |
| blocked_actions | ["plugin runtime invocation", "automatic approval", "vault recovery", "direct backend mutation"] |

**Scan summary:** `{'native_file_write': 2, 'vault_mutation': 0, 'shell_execution': 0, 'regex_exec_match': 0, 'admin_tool_reference': 8, 'background_timer': 0, 'workspace_event': 0, 'command_route': 0, 'context_menu': 0, 'metadata_cache': 0, 'editor_insertion': 0, 'clipboard': 0}`


## Verification Summary

```txt
main.js syntax check: passed
ControlVisibilityModal.js syntax check: passed
StagingManager.js syntax check: passed
security integration harness: 10 passed, 0 failed
admin-tools ledger verify: passed, 0 blocks verified
main.js direct native file writes: 0
main.js direct vault mutation calls: 0
main.js admin-tools references: 0
main.js recovery-tool references: 0
workspace event routes: 0
command routes: 0
context-menu routes: 0
metadataCache runtime routes/watchers: 0
```

## Notes

- `StagingManager.js` is the only plugin-side component with Obsidian vault write capability, and it is declared as restricted to staged review/proposal artifacts.
- `ControlVisibilityModal.js` is copy/dismiss only. Its `setTimeout` only resets the copy button text and does not trigger backend behavior.
- `headerRegex.exec(text)` in `main.js` is regex parsing, not shell execution.
- No Authority Exposure UI control grants apply/write/approve/integrate authority.

---

## Manual Recovery Layer Addition

Added authority declaration for:

```txt
admin-tools/recovery/manual-recovery-manager.js
```

Boundary:

```txt
manual only
external admin tool only
not callable by main.js
not callable by Atlas
not automatic
requires Obsidian closed
quarantines current vault before restore
```

This increases human recovery capability without increasing Atlas/plugin authority.


## Professional / High-Stakes Scope Boundary Addendum

The professional-scope boundary adds response routing only. It does not add write authority, approval authority, integration authority, admin-tool access, recovery access, shell execution, metadataCache watchers, or background execution.

Covered domains: legal, medical, therapy replacement, financial/tax/investment, and professional decision authority. Existing crisis/safety and sexual-scope boundaries remain separate.
