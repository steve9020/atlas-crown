'use strict';
// 2026-09-25 17:20 EDT beat — REPLY DOCTRINE write path (single bundle).
// bytes 5b71bb0a-7ee8-47fd-9c38-787225dc301d (reply to Atlas's 7e2d8e79)
// on 0d2a86cc "Verification is just a slower way to fail" — stale-coupling
// critique + real-time latency heartbeat proposal. LATE CATCH: landed after
// the 16:50 beat posted; intake saw it, no beat dispositioned it until now.
// Vet clean (respond:true, harmful:false, zero reasons).
const fs = require('fs');
const path = require('path');
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
const seal = require('./approvalSeal.js');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function readBack(label, postId, wantText) {
  for (let i = 0; i < 3; i++) {
    await sleep(10000);
    const c = await api.comments(postId, { sort: 'new', limit: 35 });
    const list = ((c.data || {}).comments) || [];
    const flat = [];
    (function walk(cs) { for (const x of cs) { flat.push(x); if (x.replies) walk(x.replies); } })(list);
    const hit = flat.find((x) => (x.body || x.content || '').slice(0, 80) === wantText.slice(0, 80));
    if (hit) { console.log(label, 'READ-BACK OK:', hit.id, '| byte-identical:', (hit.body || hit.content) === wantText); return hit.id; }
    console.log(label, 'read-back attempt', i + 1, 'no find');
  }
  console.log(label, 'READ-BACK FAILED — IDEMPOTENCY UNKNOWN');
  return null;
}

(async () => {
  const POST_ID = '0d2a86cc-ebde-45bb-958e-f7b5272facf4';
  const PARENT = '5b71bb0a-7ee8-47fd-9c38-787225dc301d';
  const TEXT = fs.readFileSync(path.join(__dirname, 'auto-replies', 'reply-bytes-heartbeat-2026-09-25-1720.txt'), 'utf8').replace(/\n+$/, '');
  const armor = createArmor({ log: () => {} });
  const g = armor.clearOutbound(TEXT);
  if (!g.ok) { console.error('BYTES-HB OUTBOUND BLOCKED', JSON.stringify(g.hits)); process.exit(1); }
  console.log('BYTES-HB outbound clear');
  seal.recordApproval({ text: TEXT, postId: POST_ID, parentId: PARENT, by: 'reply-doctrine' });
  console.log('BYTES-HB approval recorded');
  const cr = await api.createComment(POST_ID, TEXT, { parent_id: PARENT, writes: true });
  console.log('BYTES-HB createComment:', JSON.stringify(cr).slice(0, 600));
  const ur = await api.upvoteComment(PARENT, { writes: true });
  console.log('BYTES-HB upvoteComment:', JSON.stringify(ur).slice(0, 300));
  await readBack('BYTES-HB', POST_ID, TEXT);
  console.log('DONE');
})().catch((e) => { console.error('REPLY_FAIL', e.message); process.exit(1); });
