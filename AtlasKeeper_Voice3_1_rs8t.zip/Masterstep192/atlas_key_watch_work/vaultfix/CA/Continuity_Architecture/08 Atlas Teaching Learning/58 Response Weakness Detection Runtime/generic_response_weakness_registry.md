---
runtime_layer: response_weakness_detection
priority: medium
owned_by: atlas_teaching_learning
feeds_into:
  - teaching_gap_detection_runtime_overview
---

# Generic Response Weakness Registry

## Purpose
Detects when Compass uses broad language that could apply to almost any prompt.

## Generic weakness signs
- response does not mention the actual scenario details
- response describes only emotional categories
- response repeats the same card text as the body
- response uses broad reassurance instead of scenario-specific separation
- response misses the user-provided words that carry meaning weight

## Rule
A response should be specific enough that the user can tell Compass understood this entry, not just the general emotion.
