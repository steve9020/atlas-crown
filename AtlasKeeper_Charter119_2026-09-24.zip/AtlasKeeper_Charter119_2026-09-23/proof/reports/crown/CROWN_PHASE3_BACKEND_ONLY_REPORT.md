# Crown Phase 3 — Backend-Only Authorization + Applicability

## Boundary
Built directly on Crown Phase 2.

Frontend/public/CA hash comparison against Phase 2: **0 changes**.

## Added backend primitive
`runtime/governance/crown/CrownAuthorizationApplicability.js`

The contract binds authorization to:
- existing Atlas capability ID + requested action
- explicit human approval
- target ID/version
- context ID/version
- exact transition ID
- authorized scope
- effective time
- expiry
- revocation state
- consumed/replay state

The result is strictly:
- PASS
- FAIL
- UNKNOWN

Missing material authorization information produces UNKNOWN, never PASS.

## Existing Atlas authority reuse
The new Crown evaluator calls the existing:
`runtime/governance/AuthorityControlGuard.js`

Therefore Crown does not create a parallel capability authority system.
An action denied by the existing Atlas capability manifest remains denied even
when presented with an otherwise valid human authorization artifact.

## Transition integration
`CrownTransitionEnvelope.js` now accepts an immutable
`authorization_applicability` record and derives the envelope applicability
state from that record.

This still grants:
- route authority: false
- output authority: false

## Deterministic Phase 3 attack witness
`tests/crownPhase3AuthorizationApplicabilityTest.js`

The witness proves rejection of:
- wrong target version
- scope widening
- wrong context
- wrong transition
- revoked authorization
- consumed/replayed authorization
- expired authorization
- missing explicit human approval
- missing material applicability information
- an existing Atlas capability denial (`network_access`)

It also proves a correctly bound, current, explicit human authorization can
produce applicability PASS without becoming route or final-output authority.

Result:
`CROWN_PHASE3_AUTHORIZATION_APPLICABILITY_PASS`

## Regression proof
Canonical:
`node proof/runCurrentProof.js`

Result:
- total: 100
- passed: 100
- failed: 0
- exit: 0
- current manifest generated

Prior Crown witnesses:
- Phase 1: PASS
- Phase 2: PASS
- Phase 3: PASS

## Frontend zero-diff
Compared Phase 2 and Phase 3 across:
- `frontend/`
- `public/`
- `public_demo_shell/`
- `CA/`

Changed files: **0**

## Phase 3 status
**PASS**

Implemented chain now covers:
Source → Provenance → Transition Identity → Predicate Identity/Version/Input →
Authorization → Applicability.

## Next controlled phase
Phase 4: execution/recovery continuity. Bind validated state to execution,
introduce single-use execution identity/idempotence, and enforce that recovery
authority cannot exceed the original transaction authority.
