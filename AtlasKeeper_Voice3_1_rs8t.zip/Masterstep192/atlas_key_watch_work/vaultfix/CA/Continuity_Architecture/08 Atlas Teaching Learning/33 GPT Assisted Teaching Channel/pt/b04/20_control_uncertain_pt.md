---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 04
category: control_and_uncertainty
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 20. Control and Uncertainty Pressure Tests — Batch 04

## Category Purpose

The user lacks clear information, predictability, outcome control, or certainty, causing the mind to seek control through prediction, over-analysis, reassurance, urgency, or rigid interpretation.

## Reusable Teaching Correction

Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

## Reverse-Flow Target

uncertainty tolerance, flexible interpretation, grounded waiting, control separation

## Failure Risks To Avoid

- giving fake certainty
- telling the user to stop overthinking
- treating uncertainty as proof of danger
- forcing action before clarity
- making control needs sound weak

---

## 80 Pressure Tests

### Test 01
**Prompt:** I do not know what they meant and it makes me feel like not knowing means something bad is happening, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** not knowing means something bad is happening
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 02
**Prompt:** I keep trying to figure it out. I cannot predict the outcome keeps affecting tolerance for unknowns and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** I have to figure it out now
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 03
**Prompt:** I keep replaying how there is no clear answer yet because it affects decision clarity and makes me believe I must get the answer immediately.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** I must get the answer immediately
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 04
**Prompt:** When I keep checking for signs, the feeling moves straight into if I cannot control it I am unsafe. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** if I cannot control it I am unsafe
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 05
**Prompt:** The situation is I want to know exactly what will happen, and the meaning that keeps attaching is waiting means losing control. It is making tolerance for unknowns feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** waiting means losing control
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 06
**Prompt:** I feel stuck waiting and it makes me feel like I need certainty before I can be okay, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** I need certainty before I can be okay
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 07
**Prompt:** I keep overthinking. I keep trying to control how this goes keeps affecting certainty and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** the worst possibility needs to be treated as real
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 08
**Prompt:** I keep replaying how I do not have enough information because it affects tolerance for unknowns and makes me believe not knowing means something bad is happening.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** not knowing means something bad is happening
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 09
**Prompt:** When I do not know what they meant, the feeling moves straight into uncertainty means I am powerless. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** uncertainty means I am powerless
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 10
**Prompt:** The situation is I cannot predict the outcome, and the meaning that keeps attaching is I must get the answer immediately. It is making certainty feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** I must get the answer immediately
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 11
**Prompt:** There is no clear answer yet and it keeps turning into I have to figure it out now, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** I have to figure it out now
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 12
**Prompt:** I keep trying to figure it out. I keep checking for signs keeps affecting decision clarity and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** waiting means losing control
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 13
**Prompt:** I keep replaying how I want to know exactly what will happen because it affects certainty and makes me believe if I cannot control it I am unsafe.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** if I cannot control it I am unsafe
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 14
**Prompt:** When I feel stuck waiting, the feeling moves straight into the worst possibility needs to be treated as real. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** the worst possibility needs to be treated as real
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 15
**Prompt:** The situation is I keep trying to control how this goes, and the meaning that keeps attaching is I need certainty before I can be okay. It is making decision clarity feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** I need certainty before I can be okay
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 16
**Prompt:** I do not have enough information and it keeps turning into uncertainty means I am powerless, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** uncertainty means I am powerless
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 17
**Prompt:** I need certainty. I do not know what they meant keeps affecting tolerance for unknowns and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** not knowing means something bad is happening
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 18
**Prompt:** I keep replaying how I cannot predict the outcome because it affects decision clarity and makes me believe I have to figure it out now.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** I have to figure it out now
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 19
**Prompt:** When there is no clear answer yet, the feeling moves straight into I must get the answer immediately. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** I must get the answer immediately
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 20
**Prompt:** The situation is I keep checking for signs, and the meaning that keeps attaching is if I cannot control it I am unsafe. It is making tolerance for unknowns feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** if I cannot control it I am unsafe
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 21
**Prompt:** I want to know exactly what will happen and it has me trying to prove that waiting means losing control, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** waiting means losing control
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 22
**Prompt:** I need to know. I feel stuck waiting keeps affecting certainty and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** I need certainty before I can be okay
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 23
**Prompt:** I keep replaying how I keep trying to control how this goes because it affects tolerance for unknowns and makes me believe the worst possibility needs to be treated as real.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** the worst possibility needs to be treated as real
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 24
**Prompt:** When I do not have enough information, the feeling moves straight into not knowing means something bad is happening. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** not knowing means something bad is happening
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 25
**Prompt:** The situation is I do not know what they meant, and the meaning that keeps attaching is uncertainty means I am powerless. It is making certainty feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** uncertainty means I am powerless
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 26
**Prompt:** I cannot predict the outcome and it makes uncertainty feel like I must get the answer immediately, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** I must get the answer immediately
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 27
**Prompt:** I need certainty. There is no clear answer yet keeps affecting decision clarity and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** I have to figure it out now
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 28
**Prompt:** I keep replaying how I keep checking for signs because it affects certainty and makes me believe waiting means losing control.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** waiting means losing control
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 29
**Prompt:** When I want to know exactly what will happen, the feeling moves straight into if I cannot control it I am unsafe. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** if I cannot control it I am unsafe
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 30
**Prompt:** The situation is I feel stuck waiting, and the meaning that keeps attaching is the worst possibility needs to be treated as real. It is making decision clarity feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** the worst possibility needs to be treated as real
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 31
**Prompt:** I keep trying to control how this goes and it makes uncertainty feel like I need certainty before I can be okay, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** I need certainty before I can be okay
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 32
**Prompt:** I need to know. I do not have enough information keeps affecting tolerance for unknowns and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** uncertainty means I am powerless
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 33
**Prompt:** I keep replaying how I do not know what they meant because it affects decision clarity and makes me believe not knowing means something bad is happening.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** not knowing means something bad is happening
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 34
**Prompt:** When I cannot predict the outcome, the feeling moves straight into I have to figure it out now. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** I have to figure it out now
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 35
**Prompt:** The situation is there is no clear answer yet, and the meaning that keeps attaching is I must get the answer immediately. It is making tolerance for unknowns feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** I must get the answer immediately
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 36
**Prompt:** I keep checking for signs and it pulls me toward the belief that if I cannot control it I am unsafe, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** if I cannot control it I am unsafe
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 37
**Prompt:** I cannot predict what will happen. I want to know exactly what will happen keeps affecting certainty and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** waiting means losing control
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 38
**Prompt:** I keep replaying how I feel stuck waiting because it affects tolerance for unknowns and makes me believe I need certainty before I can be okay.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** I need certainty before I can be okay
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 39
**Prompt:** When I keep trying to control how this goes, the feeling moves straight into the worst possibility needs to be treated as real. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** the worst possibility needs to be treated as real
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 40
**Prompt:** The situation is I do not have enough information, and the meaning that keeps attaching is not knowing means something bad is happening. It is making certainty feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** not knowing means something bad is happening
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 41
**Prompt:** I do not know what they meant and it makes control feel like uncertainty means I am powerless, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** uncertainty means I am powerless
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 42
**Prompt:** I cannot stand not knowing. I cannot predict the outcome keeps affecting decision clarity and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** I must get the answer immediately
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 43
**Prompt:** I keep replaying how there is no clear answer yet because it affects certainty and makes me believe I have to figure it out now.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** I have to figure it out now
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 44
**Prompt:** When I keep checking for signs, the feeling moves straight into waiting means losing control. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** waiting means losing control
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 45
**Prompt:** The situation is I want to know exactly what will happen, and the meaning that keeps attaching is if I cannot control it I am unsafe. It is making decision clarity feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** if I cannot control it I am unsafe
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 46
**Prompt:** I feel stuck waiting and it makes control feel like the worst possibility needs to be treated as real, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** the worst possibility needs to be treated as real
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 47
**Prompt:** I cannot predict what will happen. I keep trying to control how this goes keeps affecting tolerance for unknowns and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** I need certainty before I can be okay
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 48
**Prompt:** I keep replaying how I do not have enough information because it affects decision clarity and makes me believe uncertainty means I am powerless.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** uncertainty means I am powerless
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 49
**Prompt:** When I do not know what they meant, the feeling moves straight into not knowing means something bad is happening. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** not knowing means something bad is happening
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 50
**Prompt:** The situation is I cannot predict the outcome, and the meaning that keeps attaching is I have to figure it out now. It is making tolerance for unknowns feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** I have to figure it out now
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 51
**Prompt:** There is no clear answer yet and it keeps attaching fear to I must get the answer immediately, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** I must get the answer immediately
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 52
**Prompt:** I cannot stand not knowing. I keep checking for signs keeps affecting certainty and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** if I cannot control it I am unsafe
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 53
**Prompt:** I keep replaying how I want to know exactly what will happen because it affects tolerance for unknowns and makes me believe waiting means losing control.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** waiting means losing control
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 54
**Prompt:** When I feel stuck waiting, the feeling moves straight into I need certainty before I can be okay. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** I need certainty before I can be okay
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 55
**Prompt:** The situation is I keep trying to control how this goes, and the meaning that keeps attaching is the worst possibility needs to be treated as real. It is making certainty feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** the worst possibility needs to be treated as real
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 56
**Prompt:** I do not have enough information and it keeps attaching fear to not knowing means something bad is happening, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** not knowing means something bad is happening
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 57
**Prompt:** I feel out of control. I do not know what they meant keeps affecting decision clarity and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** uncertainty means I am powerless
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 58
**Prompt:** I keep replaying how I cannot predict the outcome because it affects certainty and makes me believe I must get the answer immediately.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** I must get the answer immediately
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 59
**Prompt:** When there is no clear answer yet, the feeling moves straight into I have to figure it out now. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** I have to figure it out now
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 60
**Prompt:** The situation is I keep checking for signs, and the meaning that keeps attaching is waiting means losing control. It is making decision clarity feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** waiting means losing control
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 61
**Prompt:** I want to know exactly what will happen and it makes waiting feel like if I cannot control it I am unsafe, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** if I cannot control it I am unsafe
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 62
**Prompt:** I want control. I feel stuck waiting keeps affecting tolerance for unknowns and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** the worst possibility needs to be treated as real
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 63
**Prompt:** I keep replaying how I keep trying to control how this goes because it affects decision clarity and makes me believe I need certainty before I can be okay.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** I need certainty before I can be okay
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 64
**Prompt:** When I do not have enough information, the feeling moves straight into uncertainty means I am powerless. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** uncertainty means I am powerless
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 65
**Prompt:** The situation is I do not know what they meant, and the meaning that keeps attaching is not knowing means something bad is happening. It is making tolerance for unknowns feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** not knowing means something bad is happening
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 66
**Prompt:** I cannot predict the outcome and it makes me feel like I have to figure it out now, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** I have to figure it out now
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 67
**Prompt:** I feel out of control. There is no clear answer yet keeps affecting certainty and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** I must get the answer immediately
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 68
**Prompt:** I keep replaying how I keep checking for signs because it affects tolerance for unknowns and makes me believe if I cannot control it I am unsafe.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** if I cannot control it I am unsafe
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 69
**Prompt:** When I want to know exactly what will happen, the feeling moves straight into waiting means losing control. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** waiting means losing control
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 70
**Prompt:** The situation is I feel stuck waiting, and the meaning that keeps attaching is I need certainty before I can be okay. It is making certainty feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** I need certainty before I can be okay
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 71
**Prompt:** I keep trying to control how this goes and it makes me feel like the worst possibility needs to be treated as real, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** the worst possibility needs to be treated as real
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 72
**Prompt:** I want control. I do not have enough information keeps affecting decision clarity and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** not knowing means something bad is happening
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 73
**Prompt:** I keep replaying how I do not know what they meant because it affects certainty and makes me believe uncertainty means I am powerless.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** uncertainty means I am powerless
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 74
**Prompt:** When I cannot predict the outcome, the feeling moves straight into I must get the answer immediately. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** I must get the answer immediately
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 75
**Prompt:** The situation is there is no clear answer yet, and the meaning that keeps attaching is I have to figure it out now. It is making decision clarity feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** I have to figure it out now
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 76
**Prompt:** I keep checking for signs and it keeps turning into waiting means losing control, even though part of me knows I may not have the full picture.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** waiting means losing control
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid giving fake certainty.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 77
**Prompt:** I keep trying to figure it out. I want to know exactly what will happen keeps affecting tolerance for unknowns and I cannot tell what is actually true.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** if I cannot control it I am unsafe
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid telling the user to stop overthinking.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 78
**Prompt:** I keep replaying how I feel stuck waiting because it affects decision clarity and makes me believe the worst possibility needs to be treated as real.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** decision clarity
**Attached meaning to separate:** the worst possibility needs to be treated as real
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid treating uncertainty as proof of danger.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 79
**Prompt:** When I keep trying to control how this goes, the feeling moves straight into I need certainty before I can be okay. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** certainty
**Attached meaning to separate:** I need certainty before I can be okay
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid forcing action before clarity.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

### Test 80
**Prompt:** The situation is I do not have enough information, and the meaning that keeps attaching is uncertainty means I am powerless. It is making tolerance for unknowns feel unstable.
**Expected primary route:** `control_and_uncertainty`
**Pressure focus:** tolerance for unknowns
**Attached meaning to separate:** uncertainty means I am powerless
**Expected reverse-flow movement:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation
**Bad response risk:** Avoid making control needs sound weak.
**Teaching correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.
