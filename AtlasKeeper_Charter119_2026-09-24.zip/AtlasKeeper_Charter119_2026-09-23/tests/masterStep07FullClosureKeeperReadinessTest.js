const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const key = 'masterstep07';
const expectedPackage = 'Masterstep07.zip';
const hist = json('runtime/proof/HISTORICAL_KEEPER_INDEX.json');
assert(hist.mode === 'historical_integrity_not_current_state', 'historical index not in historical integrity mode');
assert(hist.records[key], `historical record missing ${key}`);
assert(hist.records[key].package === expectedPackage, `historical package mismatch for ${key}`);
const vs = json('tests/VERSION_STATUS.json');
assert(vs.prior_keeper_history && vs.prior_keeper_history[key], `VERSION_STATUS missing historical record ${key}`);
assert(vs.prior_keeper_history[key].snapshot === expectedPackage, `VERSION_STATUS historical snapshot mismatch for ${key}`);
const carried = read('CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/PROOF_OF_WORK_CARRIED_FORWARD_INDEX.md');
assert(carried.includes('CURRENT STATE — READ FIRST'), 'carried-forward index missing current-first section');
assert(carried.includes('HISTORICAL_KEEPER_INDEX.json'), 'carried-forward index missing historical index pointer');
console.log('masterStep07FullClosureKeeperReadinessTest PASSED historical integrity mode');
