# Balanced Batch Selection

## Purpose
Selects scenario batches using both rotation and coverage balance.

## Batch Selection Priorities
1. respect load limits
2. avoid same-category repetition
3. avoid family overuse
4. prioritize least-tested categories
5. include enough variation to find weak points
6. prevent proposal flooding

## Runtime Rule
Balanced batch selection should use neglected categories first, then fill remaining slots with rotation-safe categories.
