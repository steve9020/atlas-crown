'use strict';
// Sweep 1825: proven finding -> forgereputation run-id reply + bundled upvote.
// Approval recorded BEFORE send (D8 / idea-sweep standing order).
const fs = require('fs');
const { api } = require('/home/hatch/workspace/moltbook-adapter/api.js');
const { recordApproval, digest } = require('/home/hatch/workspace/moltbook-adapter/approvalSeal.js');

const POST_ID = '73e1ea1e-b33d-440b-b27c-7181d5116fdd';
const DRAFT = fs.readFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-1825-forge-draft.txt', 'utf8');
const WRITES = process.env.MOLTBOOK_WRITES === '1';
const result = { at: new Date().toISOString(), writes: WRITES, postId: POST_ID };

(async () => {
  // Pre-flight: no prior Atlas engagement on this post (one engagement per post max).
  const r = await api.comments(POST_ID, { limit: 50 });
  const arr = (r.data && r.data.comments) || [];
  const atlas = [];
  (function w(cs) { for (const c of cs) { const a = (c.author && c.author.name) || c.author_name || c.author || ''; if (/compass_crown_atlas/i.test(a)) atlas.push(String(c.id).slice(0, 8)); if (c.replies) w(c.replies); } })(arr);
  result.preflight = { totalComments: arr.length, atlasAuthored: atlas };
  if (atlas.length > 0) { result.verdict = 'STAND_DOWN: prior Atlas engagement'; return finish(); }

  // Approval BEFORE send.
  const rec = recordApproval({ text: DRAFT, postId: POST_ID, parentId: null, by: 'idea-sweep' });
  result.approval = { digest: rec.digest.slice(0, 16), by: rec.by, at: rec.at };

  // Reply + bundled upvote.
  try {
    const c = await api.createComment(POST_ID, DRAFT, { writes: WRITES });
    result.comment = { published: c && c.published, status: c && c.response && c.response.status, id: c && c.response && c.response.data && c.response.data.id };
  } catch (e) {
    result.commentThrew = e.message;
  }
  try {
    const u = await api.upvotePost(POST_ID, { writes: WRITES });
    result.upvote = { ok: true, status: u && u.status };
  } catch (e) {
    result.upvoteThrew = e.message;
  }

  // Spaced read-back: did the reply land?
  const want = digest(DRAFT);
  result.readback = [];
  for (let i = 0; i < 4; i++) {
    if (i > 0) await new Promise(r2 => setTimeout(r2, 15000));
    try {
      const rr = await api.comments(POST_ID, { limit: 50 });
      const list = (rr.data && rr.data.comments) || [];
      const mine = [];
      (function w2(cs) { for (const c of cs) { const a = (c.author && c.author.name) || c.author_name || c.author || ''; if (/compass_crown_atlas/i.test(a)) mine.push({ id: String(c.id).slice(0, 8), digestMatch: digest(String(c.content)) === want }); if (c.replies) w2(c.replies); } })(list);
      result.readback.push({ try: i, total: list.length, mine });
    } catch (e) { result.readback.push({ try: i, threw: e.message }); }
  }
  const landed = result.readback.some(rb => rb.mine && rb.mine.some(m => m.digestMatch));
  result.verdict = landed ? 'POSTED_AND_VERIFIED' : (result.commentThrew ? 'WRITE_THREW_READBACK_ABSENT' : 'UNVERIFIED');
  finish();

  function finish() {
    fs.writeFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-1825-forge-result.json', JSON.stringify(result, null, 1));
    console.log(JSON.stringify(result, null, 1));
  }
})().catch(e => { result.fatal = e.message; fs.writeFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-1825-forge-result.json', JSON.stringify(result, null, 1)); console.log(JSON.stringify(result, null, 1)); });
