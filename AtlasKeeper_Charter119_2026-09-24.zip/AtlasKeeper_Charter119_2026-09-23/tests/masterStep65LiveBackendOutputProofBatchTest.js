const assert = require('assert');
const { runStep65LiveBackendOutputProofBatch } = require('../runtime/backend/liveOutput/LiveBackendOutputProofBatch');

const report = runStep65LiveBackendOutputProofBatch();

assert.strictEqual(report.source_keeper, 'Masterstep64', 'Step65 must start from Masterstep64');
assert.strictEqual(report.provider_connected, false, 'provider must not be connected');
assert.strictEqual(report.model_connected, false, 'model must not be connected');
assert.strictEqual(report.api_keys_added, false, 'API keys must not be added');
assert.strictEqual(report.endpoints_added, false, 'endpoints must not be added');
assert.strictEqual(report.network_bridge_added, false, 'network bridge must not be added');
assert.strictEqual(report.frontend_intelligence_added, false, 'frontend intelligence must not be added');
assert.strictEqual(report.passed, true, 'Step65 live backend proof batch must pass: ' + JSON.stringify(report.weak_cases, null, 2));
assert.strictEqual(report.weak_cases.length, 0, 'no weak live cases should remain after Step65 repair');
assert.strictEqual(report.required_chain_evidence.parser_axis_doyle_separation_restoration_observed_in_every_case, true, 'parser-axis-Doyle-separation-restoration evidence missing');
assert.strictEqual(report.required_chain_evidence.model_agnostic_boundary_disconnected_in_every_case, true, 'model-agnostic boundary must stay disconnected');
assert.strictEqual(report.required_chain_evidence.post_generation_validator_active_in_every_case, true, 'post-generation validator must remain active');
assert.strictEqual(report.required_chain_evidence.teaching_center_triage_triggers_on_failed_output, true, 'Teaching Center triage must trigger on failed output');
assert.strictEqual(report.required_chain_evidence.no_generic_fallback_overuse, true, 'generic fallback overuse must be blocked');
assert.strictEqual(report.required_chain_evidence.depth_fit, true, 'depth fit must pass');
assert.strictEqual(report.required_chain_evidence.route_activation, true, 'route activation must pass');
assert.strictEqual(report.required_chain_evidence.compass_voice_quality, true, 'Compass voice quality must pass');
assert.strictEqual(report.required_chain_evidence.frontend_remains_dumb_shell, true, 'frontend must remain dumb shell');
assert.strictEqual(report.required_chain_evidence.no_provider_execution, true, 'provider execution must remain blocked');
assert.strictEqual(report.failure_triage_proof.passed, true, 'forced failed output must create Teaching Center triage');
assert.strictEqual(report.disconnected_wrapper_proof.passed, true, 'disconnected wrapper proof must pass');
assert.strictEqual(report.decision, 'CLOSE_STEP_65_AND_MOVE_TO_STEP_66', 'Step65 decision must allow Step66 only after pass');

const curlySilence = report.results.find(r => r.id === 'silence_self_blame_curly_apostrophe_repair');
assert.ok(curlySilence, 'curly apostrophe silence case must be included');
assert.strictEqual(curlySilence.pass_fail, 'PASS', 'curly apostrophe silence repair case must pass');
assert.strictEqual(curlySilence.depth, 'moderate', 'silence/self-blame should stay moderate unless collapse language is active');
assert.ok(!/Something in this is asking to be sorted carefully/i.test(curlySilence.output), 'curly apostrophe case must not use generic fallback');

console.log('masterStep65LiveBackendOutputProofBatchTest PASSED');
