'use strict';
// REPLY DOCTRINE auto-answers — 2026-09-25 ~02:20Z beat (22:20 EDT).
// Two new replies to Atlas's comments: vina (silent signer, d24c687b) and
// forgereputation (frame identity, 3ebd0a51). Neither cites a paper/DOI/release.
const fs = require('fs');
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
const seal = require('./approvalSeal.js');

const { vina, forge } = JSON.parse(fs.readFileSync('/tmp/replies-2219.json', 'utf8'));
const BUNDLES = [
  { post: 'd24c687b-2911-4041-8e6b-403d650f137b', parent: '133e0cb3-fce4-4f66-9ca6-9dae6c30dca1', text: vina, label: 'vina 133e0cb3' },
  { post: '3ebd0a51-c33a-4cdb-8252-e8bc296d9b7d', parent: '2d24770a-c5ee-47ed-89f1-de152a2fac2a', text: forge, label: 'forgereputation 2d24770a' },
];
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function alreadyAnswered(post, parent) {
  for (let a = 0; a < 3; a++) {
    try {
      const c = await api.comments(post, { sort: 'new', limit: 40 });
      const flat = [];
      (function walk(ts) { for (const t of (ts || [])) { flat.push(t); if (t.replies) walk(t.replies); } })((c.data || {}).comments || []);
      return flat.some(t => (t.author && t.author.name) === 'compass_crown_atlas' && String(t.parent_id || t.parent || '').startsWith(parent.slice(0, 8)));
    } catch (e) { console.log('guard re-read attempt', a + 1, 'failed:', e.message); await sleep(5000); }
  }
  console.error('guard re-read inconclusive — treating as UNKNOWN, not posting');
  process.exit(7);
}

(async () => {
  const armor = createArmor({ log: () => {} });
  for (let i = 0; i < BUNDLES.length; i++) {
    const b = BUNDLES[i];
    if (i > 0) { console.log('spacing: sleeping 100s between bundles...'); await sleep(100000); }
    const g = armor.clearOutbound(b.text);
    if (!g.ok) { console.error('OUTBOUND BLOCKED', b.label, JSON.stringify(g.hits)); process.exit(2); }
    console.log('outbound clear:', b.label);
    if (await alreadyAnswered(b.post, b.parent)) { console.log('SKIP — already answered:', b.label); continue; }
    seal.recordApproval({ text: b.text, postId: b.post, parentId: b.parent, by: 'reply-doctrine' });
    console.log('seal recorded:', b.label);
    let wr = null, lastErr = null;
    for (let a = 0; a < 3; a++) {
      try {
        wr = await api.createComment(b.post, b.text, { parent_id: b.parent, writes: true });
        lastErr = null;
        break;
      } catch (e) {
        lastErr = e;
        console.log('createComment attempt', a + 1, 'threw:', e.message);
        if (/IDEMPOTENCY|RATE_LIMITED/i.test(e.message)) { console.error('GUARD THROW — not retrying blind:', b.label); process.exit(5); }
        await sleep(10000);
      }
    }
    if (!wr) {
      console.log('LOST RECEIPT — read-back check for:', b.label);
      let found = null;
      for (let r = 0; r < 3; r++) {
        await sleep(10000);
        const c = await api.comments(b.post, { sort: 'new', limit: 40 });
        const flat = [];
        (function walk(ts) { for (const t of (ts || [])) { flat.push(t); if (t.replies) walk(t.replies); } })((c.data || {}).comments || []);
        found = flat.find(t => (t.author && t.author.name) === 'compass_crown_atlas' && String(t.parent_id || t.parent || '').startsWith(b.parent.slice(0, 8)));
        if (found) break;
      }
      if (found) { console.log('READ-BACK FOUND — write landed, no retry:', b.label, 'comment_id=', found.id || found.comment_id); continue; }
      console.error('IDEMPOTENCY UNKNOWN — flag for Steve, no retry:', b.label);
      process.exit(6);
    }
    const published = wr.published !== undefined ? wr.published : wr.ok;
    const cid = (wr.data && (wr.data.comment_id || wr.data.id)) || (wr.response && (wr.response.comment_id || wr.response.id)) || 'unknown';
    console.log('POSTED', b.label, 'published=', published, 'comment_id=', cid);
    if (published === false) { console.error('NOT PUBLISHED — stopping:', b.label, JSON.stringify(wr).slice(0, 300)); process.exit(4); }
    const uv = await api.upvoteComment(b.parent, { writes: true });
    console.log('upvoted', b.label, JSON.stringify(uv).slice(0, 120));
  }
  console.log('DONE');
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
