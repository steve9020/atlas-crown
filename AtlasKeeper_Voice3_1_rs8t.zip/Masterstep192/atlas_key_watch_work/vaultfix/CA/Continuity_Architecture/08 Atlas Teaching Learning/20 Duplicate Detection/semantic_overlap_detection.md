---
node_type: duplicate_detection_rule
runtime_layer: duplicate_detection_layer
priority: critical
governed_by:
  - duplicate_detection_overview
frontend_visibility: hidden
---

# Semantic Overlap Detection

## Purpose

This node detects when multiple ontology structures express substantially overlapping semantic meaning or runtime purpose.

Semantic overlap increases ontology density without necessarily increasing operational clarity.

## Core Principle

Distinct terminology alone does not justify distinct ontology structures.

Ontology separation must provide meaningful operational distinction.

## Semantic Overlap Indicators

Semantic overlap indicators include:

- equivalent conceptual meaning
- highly similar runtime behavior
- overlapping recursive interpretation functions
- duplicate emotional interpretation structures
- repeated continuity restoration behaviors
- semantic abstractions expressing the same mechanism
- concept clusters differing mostly in wording
- repeated escalation logic
- repeated governance enforcement concepts

## Runtime Overlap Detection

Runtime overlap occurs when:

- different nodes trigger the same runtime pathway
- multiple structures produce equivalent interpretive outputs
- semantic routing produces redundant results
- recursive branches converge repeatedly without functional distinction

## Abstraction Overlap

Abstraction overlap occurs when:

- higher-level abstractions repeat lower-level meanings
- semantic layers recursively restate the same concept
- ontology terminology multiplies without improving clarity
- semantic density increases while operational value remains unchanged

## Recursive Semantic Mirrors

Recursive semantic mirrors occur when:

- recursive structures generate conceptual reflections of existing nodes
- ontology pathways repeatedly duplicate prior recursive concepts
- recursive terminology expands around the same underlying mechanism

## Overlap Evaluation Principle

Semantic overlap should be evaluated through:

- operational function comparison
- runtime pathway comparison
- semantic equivalence analysis
- governance role similarity
- recursive behavior similarity
- clarity contribution

## Important Restriction

Semantic overlap detection may:

- observe
- compare
- identify
- flag

It may not autonomously:

- merge semantic systems
- collapse ontology branches
- rewrite node structures
- remove abstraction layers

Human review remains required.

## Runtime Goal

The purpose of semantic overlap detection is to preserve:

- semantic clarity
- operational distinction
- ontology efficiency
- recursive precision
- governance stability
- conceptual usefulness

while preventing:

- semantic redundancy
- abstraction inflation
- recursive semantic duplication
- ontology density escalation
- unnecessary conceptual fragmentation

## Related Runtime Links

- [[duplicate_detection_overview]]
- [[semantic_drift_detection]]
- [[recursive_drift_detection]]
- [[governance_runtime_authority]]
- [[drift_detection_runtime_flow]]