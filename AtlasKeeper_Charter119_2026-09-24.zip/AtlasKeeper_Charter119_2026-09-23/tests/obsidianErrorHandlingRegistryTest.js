const assert = require("assert");
const { handleRuntimeError } = require("../runtime/errors/ErrorHandler.js");
const { readJsonRegistry } = require("../runtime/backend/ObsidianRegistryReader.js");

const ERROR_HANDLING_REGISTRY_PATH = "CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/error_handling_registry.md";
const registry = readJsonRegistry(ERROR_HANDLING_REGISTRY_PATH);

assert.strictEqual(registry.version, "OBSIDIAN_ERROR_HANDLING_REGISTRY_STAGE7");
assert.strictEqual(registry.errorHandlingMode, "generic_registry_backed_error_response");
assert.strictEqual(registry.status, "runtime error handled");
assert.ok(registry.fallbackOutput.includes("system stayed stable"), "registry must preserve stable fallback wording");
assert.ok(Array.isArray(registry.exposedErrorFields), "registry must declare exposed error fields");
assert.ok(registry.exposedErrorFields.includes("message"), "registry must expose error message");
assert.ok(registry.exposedErrorFields.includes("name"), "registry must expose error name");

const handled = handleRuntimeError(new TypeError("boom"), "test input");
assert.deepStrictEqual(
  handled,
  {
    status: "runtime error handled",
    input: "test input",
    error: {
      message: "boom",
      name: "TypeError"
    },
    output: "Something did not process correctly, but the system stayed stable. Please try again with a little more detail."
  },
  "handled runtime errors should preserve prior output shape while reading fallback behavior from Obsidian"
);

const defaultHandled = handleRuntimeError({}, "test input");
assert.deepStrictEqual(
  defaultHandled.error,
  {
    message: "Unknown runtime error",
    name: "Error"
  },
  "default error normalization should be registry-backed and stable"
);

console.log("obsidianErrorHandlingRegistryTest.js — PASSED");
console.log("Error handling behavior is now read from Obsidian backend markdown.");
