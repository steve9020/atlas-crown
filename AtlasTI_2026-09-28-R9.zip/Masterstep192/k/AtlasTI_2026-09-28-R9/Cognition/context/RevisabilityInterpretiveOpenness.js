const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const REVISABILITY_INTERPRETIVE_OPENNESS_REGISTRY_PATH = "CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/revisability_interpretive_openness_registry.md";

let cachedRevisabilityRegistry = null;

function getRevisabilityRegistry() {
  if (!cachedRevisabilityRegistry) {
    cachedRevisabilityRegistry = readJsonRegistry(REVISABILITY_INTERPRETIVE_OPENNESS_REGISTRY_PATH);
  }
  return cachedRevisabilityRegistry;
}

function normalizeInput(input) { return String(input || "").toLowerCase(); }
function phraseMatches(text, phrase) { return typeof phrase === "string" && phrase.length > 0 && text.includes(phrase.toLowerCase()); }
function anyPhraseMatches(text, phrases) { return Array.isArray(phrases) && phrases.some((phrase) => phraseMatches(text, phrase)); }
function allGroupsMatch(text, groups) {
  if (!Array.isArray(groups) || groups.length === 0) return true;
  return groups.every((group) => anyPhraseMatches(text, Array.isArray(group.phrases) ? group.phrases : []));
}
function ruleMatches(text, rule) {
  const phrases = Array.isArray(rule.phrases) ? rule.phrases : [];
  const allGroups = Array.isArray(rule.allGroups) ? rule.allGroups : [];
  if (allGroups.length > 0 && !allGroupsMatch(text, allGroups)) return false;
  if (phrases.length > 0 && !anyPhraseMatches(text, phrases)) return false;
  return allGroups.length > 0 || phrases.length > 0;
}
function appendUnique(target, values) {
  if (!Array.isArray(values)) return;
  for (const value of values) {
    if (typeof value === "string" && value.trim() && !target.includes(value)) target.push(value);
  }
}
function collectMatchedRules(text, rules) {
  const matched = [];
  for (const rule of rules) if (rule && rule.id && ruleMatches(text, rule)) matched.push(rule);
  return matched;
}
function dependencyOpen(layer) {
  return !layer || (layer.revisable !== false && layer.closure_allowed !== true);
}
function resolveDependencyState(contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread, reflectiveAxisMirroring) {
  return {
    context_integrity_active: !!contextIntegrity,
    semantic_fusion_active: !!semanticFusion,
    progressive_understanding_active: !!progressiveUnderstanding,
    intuition_meaning_spread_active: !!intuitionMeaningSpread,
    reflective_axis_mirroring_active: !!reflectiveAxisMirroring,
    context_integrity_open: dependencyOpen(contextIntegrity),
    semantic_fusion_open: dependencyOpen(semanticFusion),
    progressive_understanding_open: dependencyOpen(progressiveUnderstanding),
    intuition_meaning_spread_open: dependencyOpen(intuitionMeaningSpread),
    reflective_axis_mirroring_open: dependencyOpen(reflectiveAxisMirroring),
    prior_permanent_closure_detected: !!(
      (contextIntegrity && contextIntegrity.closure_allowed === true) ||
      (semanticFusion && semanticFusion.closure_allowed === true) ||
      (progressiveUnderstanding && progressiveUnderstanding.closure_allowed === true) ||
      (intuitionMeaningSpread && intuitionMeaningSpread.closure_allowed === true) ||
      (reflectiveAxisMirroring && reflectiveAxisMirroring.closure_allowed === true)
    )
  };
}

function mapRevisabilityInterpretiveOpenness(input, contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread, reflectiveAxisMirroring) {
  const text = normalizeInput(input);
  const registry = getRevisabilityRegistry();
  const rules = Array.isArray(registry.rules) ? [...registry.rules] : [];
  rules.sort((a, b) => (a.priority || 9999) - (b.priority || 9999));
  const matchedRules = collectMatchedRules(text, rules);

  const revisabilitySignals = [];
  const closureRiskSignals = [];
  const confidenceMoves = [];
  const reweightingMoves = [];
  const opennessMoves = [];
  const forbiddenMoves = [];
  const governanceMoves = [];

  for (const rule of matchedRules) {
    appendUnique(revisabilitySignals, rule.revisabilitySignals);
    appendUnique(closureRiskSignals, rule.closureRiskSignals);
    appendUnique(confidenceMoves, rule.confidenceMoves);
    appendUnique(reweightingMoves, rule.reweightingMoves);
    appendUnique(opennessMoves, rule.opennessMoves);
    appendUnique(forbiddenMoves, rule.forbiddenMoves);
    appendUnique(governanceMoves, rule.governanceMoves);
  }

  const dependencyState = resolveDependencyState(contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread, reflectiveAxisMirroring);
  const active = matchedRules.length > 0 || dependencyState.prior_permanent_closure_detected;

  return {
    version: registry.version,
    stewardship: "Master Step 4F — Revisability & Interpretive Openness",
    depends_on: [
      "Master Step 4A — Context Integrity Mapping",
      "Master Step 4B — Semantic Fusion Separation",
      "Master Step 4C — Progressive Understanding Runtime",
      "Master Step 4D — Intuition & Meaning Spread Governance",
      "Master Step 4E — Reflective Axis Mirroring"
    ],
    dependency_state: dependencyState,
    revisability_interpretive_openness_active: active,
    permanent_interpretive_closure_allowed: false,
    confidence_weighting_allowed: true,
    future_context_reweighting_allowed: true,
    artificial_certainty_closure_blocked: true,
    interpretations_remain_revisable: true,
    closure_allowed: false,
    revisable: true,
    output_posture: governanceMoves.length > 0 ? governanceMoves : [
      "hold_interpretation_as_context_supported_weight",
      "preserve_future_context_reweighting",
      "block_permanent_closure"
    ],
    revisability_signals: revisabilitySignals,
    closure_risk_signals: closureRiskSignals,
    confidence_moves: confidenceMoves,
    reweighting_moves: reweightingMoves,
    openness_moves: opennessMoves,
    forbidden_moves: forbiddenMoves,
    matched_rules: matchedRules.map((rule) => rule.id),
    guardrails: Array.isArray(registry.guardrails) ? registry.guardrails : []
  };
}

module.exports = { mapRevisabilityInterpretiveOpenness };
