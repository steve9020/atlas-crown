const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const INTUITION_MEANING_SPREAD_REGISTRY_PATH = "CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/intuition_meaning_spread_governance_registry.md";

let cachedIntuitionMeaningSpreadRegistry = null;

function getIntuitionMeaningSpreadRegistry() {
  if (!cachedIntuitionMeaningSpreadRegistry) {
    cachedIntuitionMeaningSpreadRegistry = readJsonRegistry(INTUITION_MEANING_SPREAD_REGISTRY_PATH);
  }
  return cachedIntuitionMeaningSpreadRegistry;
}

function normalizeInput(input) { return String(input || "").toLowerCase(); }
function phraseMatches(text, phrase) { return typeof phrase === "string" && phrase.length > 0 && text.includes(phrase.toLowerCase()); }
function anyPhraseMatches(text, phrases) { return Array.isArray(phrases) && phrases.some((phrase) => phraseMatches(text, phrase)); }
function allGroupsMatch(text, groups) {
  if (!Array.isArray(groups) || groups.length === 0) return true;
  return groups.every((group) => anyPhraseMatches(text, Array.isArray(group.phrases) ? group.phrases : []));
}
function ruleMatches(text, rule) {
  const phrases = Array.isArray(rule.phrases) ? rule.phrases : [];
  const allGroups = Array.isArray(rule.allGroups) ? rule.allGroups : [];
  if (allGroups.length > 0 && !allGroupsMatch(text, allGroups)) return false;
  if (phrases.length > 0 && !anyPhraseMatches(text, phrases)) return false;
  return allGroups.length > 0 || phrases.length > 0;
}
function appendUnique(target, values) {
  if (!Array.isArray(values)) return;
  for (const value of values) {
    if (typeof value === "string" && value.trim() && !target.includes(value)) target.push(value);
  }
}
function collectMatchedRules(text, rules) {
  const matched = [];
  for (const rule of rules) if (rule && rule.id && ruleMatches(text, rule)) matched.push(rule);
  return matched;
}
function resolveDependencyState(contextIntegrity, semanticFusion, progressiveUnderstanding) {
  return {
    context_integrity_active: !!contextIntegrity,
    semantic_fusion_active: !!semanticFusion,
    progressive_understanding_active: !!progressiveUnderstanding,
    context_revisable: !contextIntegrity || contextIntegrity.revisable !== false,
    semantic_revisable: !semanticFusion || semanticFusion.revisable !== false,
    progressive_revisable: !progressiveUnderstanding || progressiveUnderstanding.revisable !== false,
    progressive_closure_allowed: !!progressiveUnderstanding && progressiveUnderstanding.closure_allowed === true
  };
}

function mapIntuitionMeaningSpread(input, contextIntegrity, semanticFusion, progressiveUnderstanding) {
  const text = normalizeInput(input);
  const registry = getIntuitionMeaningSpreadRegistry();
  const rules = Array.isArray(registry.rules) ? [...registry.rules] : [];
  rules.sort((a, b) => (a.priority || 9999) - (b.priority || 9999));
  const matchedRules = collectMatchedRules(text, rules);

  const intuitionSignals = [];
  const meaningSpreadSignals = [];
  const supportedSpreadChains = [];
  const unsupportedDepthBlocks = [];
  const certaintySeparation = [];
  const governanceMoves = [];

  for (const rule of matchedRules) {
    appendUnique(intuitionSignals, rule.intuitionSignals);
    appendUnique(meaningSpreadSignals, rule.meaningSpreadSignals);
    appendUnique(supportedSpreadChains, rule.supportedSpreadChains);
    appendUnique(unsupportedDepthBlocks, rule.unsupportedDepthBlocks);
    appendUnique(certaintySeparation, rule.certaintySeparation);
    appendUnique(governanceMoves, rule.governanceMoves);
  }

  const dependencyState = resolveDependencyState(contextIntegrity, semanticFusion, progressiveUnderstanding);
  const intuitionPresent = intuitionSignals.length > 0;
  const meaningSpreadPresent = meaningSpreadSignals.length > 0 || supportedSpreadChains.length > 0;
  const emotionalCertaintyPresent = certaintySeparation.length > 0;

  return {
    version: registry.version,
    stewardship: "Master Step 4D — Intuition & Meaning Spread Governance",
    depends_on: [
      "Master Step 4A — Context Integrity Mapping",
      "Master Step 4B — Semantic Fusion Separation",
      "Master Step 4C — Progressive Understanding Runtime"
    ],
    dependency_state: dependencyState,
    intuition_as_contextual_signal: intuitionPresent,
    intuition_converted_to_certainty: false,
    meaning_spread_tracking_active: meaningSpreadPresent,
    unsupported_depth_prevented: unsupportedDepthBlocks.length > 0 || meaningSpreadPresent,
    emotional_certainty_separated_from_verified_truth: emotionalCertaintyPresent,
    closure_allowed: false,
    revisable: true,
    output_posture: governanceMoves.length > 0 ? governanceMoves : [
      "hold_intuition_as_signal_not_proof",
      "track_only_supported_meaning_spread",
      "do_not_insert_certainty"
    ],
    intuition_signals: intuitionSignals,
    meaning_spread_signals: meaningSpreadSignals,
    supported_spread_chains: supportedSpreadChains,
    unsupported_depth_blocks: unsupportedDepthBlocks,
    certainty_separation: certaintySeparation,
    matched_rules: matchedRules.map((rule) => rule.id),
    guardrails: Array.isArray(registry.guardrails) ? registry.guardrails : []
  };
}

module.exports = { mapIntuitionMeaningSpread };
