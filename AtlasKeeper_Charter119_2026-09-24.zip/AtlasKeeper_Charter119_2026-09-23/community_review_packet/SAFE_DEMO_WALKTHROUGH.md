# Safe Demo Walkthrough

1. Read the project summary.
2. Read the claim boundary.
3. Review the redaction and exposure lock.
4. Review the redacted evidence summary.
5. Use the feedback guide to respond only within the requested lanes.

Do not request backend files, private vault files, internal proof logs, raw model output, or source packages as part of this community packet review.
