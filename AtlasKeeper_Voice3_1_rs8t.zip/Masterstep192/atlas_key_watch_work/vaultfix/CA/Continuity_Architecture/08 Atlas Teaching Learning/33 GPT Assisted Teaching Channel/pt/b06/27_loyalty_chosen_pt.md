---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 06
category: loyalty_and_being_chosen
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 27. Loyalty and Being Chosen Pressure Tests — Batch 06

## Category Purpose

Loyalty and being chosen pressure activates when the user’s sense of devotion, priority, commitment, or being selected feels unequal, overlooked, replaced, or unreciprocated.

## Reusable Teaching Correction

Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

## Reverse-Flow Target

dignity, reciprocal clarity, value ownership, loyal self-respect

## Failure Risks To Avoid

- telling the user they deserve better as a shortcut
- turning loyalty into foolishness
- assuming the other person is evil
- encouraging endless waiting
- using comparison as proof of value

---

## 80 Pressure Tests

### Test 01
**Prompt:** I kept showing up and they still did not choose me and it makes me believe not being chosen means I was not worth choosing, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** not being chosen means I was not worth choosing
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 02
**Prompt:** I show up but they do not. They chose someone else after everything keeps affecting belonging and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** someone choosing another person means I am lesser
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 03
**Prompt:** I keep replaying how I feel like I was loyal for nothing because it affects reciprocity and makes me believe being loyal means I must keep waiting.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** being loyal means I must keep waiting
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 04
**Prompt:** When I always make them a priority but they do not do that for me, the feeling moves straight into I have to earn being picked. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** I have to earn being picked
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 05
**Prompt:** The situation is I feel like a backup option, and the meaning that keeps attaching is my devotion made me foolish. It is making belonging feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** my devotion made me foolish
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 06
**Prompt:** I wanted to be picked by them and it makes me believe my loyalty was meaningless, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** my loyalty was meaningless
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 07
**Prompt:** I was loyal and they were not. I gave commitment and got uncertainty keeps affecting priority and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** if I mattered they would choose me the same way
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 08
**Prompt:** I keep replaying how I feel like my loyalty was not returned because it affects belonging and makes me believe not being chosen means I was not worth choosing.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** not being chosen means I was not worth choosing
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 09
**Prompt:** When I kept showing up and they still did not choose me, the feeling moves straight into I am always the backup option. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** I am always the backup option
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 10
**Prompt:** The situation is they chose someone else after everything, and the meaning that keeps attaching is being loyal means I must keep waiting. It is making priority feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** being loyal means I must keep waiting
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 11
**Prompt:** I feel like i was loyal for nothing and it keeps turning into someone choosing another person means I am lesser, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** someone choosing another person means I am lesser
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 12
**Prompt:** I show up but they do not. I always make them a priority but they do not do that for me keeps affecting reciprocity and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** my devotion made me foolish
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 13
**Prompt:** I keep replaying how I feel like a backup option because it affects priority and makes me believe I have to earn being picked.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** I have to earn being picked
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 14
**Prompt:** When I wanted to be picked by them, the feeling moves straight into if I mattered they would choose me the same way. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** if I mattered they would choose me the same way
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 15
**Prompt:** The situation is I gave commitment and got uncertainty, and the meaning that keeps attaching is my loyalty was meaningless. It is making reciprocity feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** my loyalty was meaningless
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 16
**Prompt:** I feel like my loyalty was not returned and it keeps turning into I am always the backup option, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** I am always the backup option
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 17
**Prompt:** why was I not enough to be chosen. I kept showing up and they still did not choose me keeps affecting belonging and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** not being chosen means I was not worth choosing
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 18
**Prompt:** I keep replaying how they chose someone else after everything because it affects reciprocity and makes me believe someone choosing another person means I am lesser.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** someone choosing another person means I am lesser
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 19
**Prompt:** When I feel like I was loyal for nothing, the feeling moves straight into being loyal means I must keep waiting. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** being loyal means I must keep waiting
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 20
**Prompt:** The situation is I always make them a priority but they do not do that for me, and the meaning that keeps attaching is I have to earn being picked. It is making belonging feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** I have to earn being picked
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 21
**Prompt:** I feel like a backup option and it has me treating their choice as if my devotion made me foolish, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** my devotion made me foolish
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 22
**Prompt:** they did not choose me. I wanted to be picked by them keeps affecting priority and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** my loyalty was meaningless
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 23
**Prompt:** I keep replaying how I gave commitment and got uncertainty because it affects belonging and makes me believe if I mattered they would choose me the same way.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** if I mattered they would choose me the same way
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 24
**Prompt:** When I feel like my loyalty was not returned, the feeling moves straight into not being chosen means I was not worth choosing. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** not being chosen means I was not worth choosing
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 25
**Prompt:** The situation is I kept showing up and they still did not choose me, and the meaning that keeps attaching is I am always the backup option. It is making priority feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** I am always the backup option
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 26
**Prompt:** They chose someone else after everything and it makes my loyalty feel like being loyal means I must keep waiting, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** being loyal means I must keep waiting
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 27
**Prompt:** why was I not enough to be chosen. I feel like i was loyal for nothing keeps affecting reciprocity and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** someone choosing another person means I am lesser
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 28
**Prompt:** I keep replaying how I always make them a priority but they do not do that for me because it affects priority and makes me believe my devotion made me foolish.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** my devotion made me foolish
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 29
**Prompt:** When I feel like a backup option, the feeling moves straight into I have to earn being picked. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** I have to earn being picked
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 30
**Prompt:** The situation is I wanted to be picked by them, and the meaning that keeps attaching is if I mattered they would choose me the same way. It is making reciprocity feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** if I mattered they would choose me the same way
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 31
**Prompt:** I gave commitment and got uncertainty and it makes my loyalty feel like my loyalty was meaningless, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** my loyalty was meaningless
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 32
**Prompt:** they did not choose me. I feel like my loyalty was not returned keeps affecting belonging and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** I am always the backup option
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 33
**Prompt:** I keep replaying how I kept showing up and they still did not choose me because it affects reciprocity and makes me believe not being chosen means I was not worth choosing.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** not being chosen means I was not worth choosing
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 34
**Prompt:** When they chose someone else after everything, the feeling moves straight into someone choosing another person means I am lesser. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** someone choosing another person means I am lesser
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 35
**Prompt:** The situation is I feel like I was loyal for nothing, and the meaning that keeps attaching is being loyal means I must keep waiting. It is making belonging feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** being loyal means I must keep waiting
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 36
**Prompt:** I always make them a priority but they do not do that for me and it pulls me toward thinking I have to earn being picked, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** I have to earn being picked
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 37
**Prompt:** they chose someone else. I feel like a backup option keeps affecting priority and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** my devotion made me foolish
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 38
**Prompt:** I keep replaying how I wanted to be picked by them because it affects belonging and makes me believe my loyalty was meaningless.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** my loyalty was meaningless
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 39
**Prompt:** When I gave commitment and got uncertainty, the feeling moves straight into if I mattered they would choose me the same way. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** if I mattered they would choose me the same way
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 40
**Prompt:** The situation is I feel like my loyalty was not returned, and the meaning that keeps attaching is not being chosen means I was not worth choosing. It is making priority feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** not being chosen means I was not worth choosing
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 41
**Prompt:** I kept showing up and they still did not choose me and it keeps attaching my value to I am always the backup option, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** I am always the backup option
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 42
**Prompt:** I always choose them. They chose someone else after everything keeps affecting reciprocity and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** being loyal means I must keep waiting
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 43
**Prompt:** I keep replaying how I feel like I was loyal for nothing because it affects priority and makes me believe someone choosing another person means I am lesser.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** someone choosing another person means I am lesser
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 44
**Prompt:** When I always make them a priority but they do not do that for me, the feeling moves straight into my devotion made me foolish. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** my devotion made me foolish
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 45
**Prompt:** The situation is I feel like a backup option, and the meaning that keeps attaching is I have to earn being picked. It is making reciprocity feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** I have to earn being picked
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 46
**Prompt:** I wanted to be picked by them and it keeps attaching my value to if I mattered they would choose me the same way, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** if I mattered they would choose me the same way
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 47
**Prompt:** they chose someone else. I gave commitment and got uncertainty keeps affecting belonging and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** my loyalty was meaningless
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 48
**Prompt:** I keep replaying how I feel like my loyalty was not returned because it affects reciprocity and makes me believe I am always the backup option.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** I am always the backup option
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 49
**Prompt:** When I kept showing up and they still did not choose me, the feeling moves straight into not being chosen means I was not worth choosing. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** not being chosen means I was not worth choosing
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 50
**Prompt:** The situation is they chose someone else after everything, and the meaning that keeps attaching is someone choosing another person means I am lesser. It is making belonging feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** someone choosing another person means I am lesser
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 51
**Prompt:** I feel like i was loyal for nothing and it makes being unchosen feel like being loyal means I must keep waiting, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** being loyal means I must keep waiting
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 52
**Prompt:** I always choose them. I always make them a priority but they do not do that for me keeps affecting priority and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** I have to earn being picked
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 53
**Prompt:** I keep replaying how I feel like a backup option because it affects belonging and makes me believe my devotion made me foolish.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** my devotion made me foolish
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 54
**Prompt:** When I wanted to be picked by them, the feeling moves straight into my loyalty was meaningless. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** my loyalty was meaningless
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 55
**Prompt:** The situation is I gave commitment and got uncertainty, and the meaning that keeps attaching is if I mattered they would choose me the same way. It is making priority feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** if I mattered they would choose me the same way
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 56
**Prompt:** I feel like my loyalty was not returned and it makes being unchosen feel like not being chosen means I was not worth choosing, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** not being chosen means I was not worth choosing
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 57
**Prompt:** I feel second place. I kept showing up and they still did not choose me keeps affecting reciprocity and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** I am always the backup option
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 58
**Prompt:** I keep replaying how they chose someone else after everything because it affects priority and makes me believe being loyal means I must keep waiting.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** being loyal means I must keep waiting
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 59
**Prompt:** When I feel like I was loyal for nothing, the feeling moves straight into someone choosing another person means I am lesser. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** someone choosing another person means I am lesser
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 60
**Prompt:** The situation is I always make them a priority but they do not do that for me, and the meaning that keeps attaching is my devotion made me foolish. It is making reciprocity feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** my devotion made me foolish
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 61
**Prompt:** I feel like a backup option and it turns their priority into I have to earn being picked, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** I have to earn being picked
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 62
**Prompt:** I feel like I am never picked. I wanted to be picked by them keeps affecting belonging and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** if I mattered they would choose me the same way
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 63
**Prompt:** I keep replaying how I gave commitment and got uncertainty because it affects reciprocity and makes me believe my loyalty was meaningless.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** my loyalty was meaningless
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 64
**Prompt:** When I feel like my loyalty was not returned, the feeling moves straight into I am always the backup option. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** I am always the backup option
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 65
**Prompt:** The situation is I kept showing up and they still did not choose me, and the meaning that keeps attaching is not being chosen means I was not worth choosing. It is making belonging feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** not being chosen means I was not worth choosing
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 66
**Prompt:** They chose someone else after everything and it makes me believe someone choosing another person means I am lesser, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** someone choosing another person means I am lesser
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 67
**Prompt:** I feel second place. I feel like i was loyal for nothing keeps affecting priority and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** being loyal means I must keep waiting
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 68
**Prompt:** I keep replaying how I always make them a priority but they do not do that for me because it affects belonging and makes me believe I have to earn being picked.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** I have to earn being picked
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 69
**Prompt:** When I feel like a backup option, the feeling moves straight into my devotion made me foolish. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** my devotion made me foolish
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 70
**Prompt:** The situation is I wanted to be picked by them, and the meaning that keeps attaching is my loyalty was meaningless. It is making priority feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** my loyalty was meaningless
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 71
**Prompt:** I gave commitment and got uncertainty and it makes me believe if I mattered they would choose me the same way, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** if I mattered they would choose me the same way
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 72
**Prompt:** I feel like I am never picked. I feel like my loyalty was not returned keeps affecting reciprocity and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** not being chosen means I was not worth choosing
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 73
**Prompt:** I keep replaying how I kept showing up and they still did not choose me because it affects priority and makes me believe I am always the backup option.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** I am always the backup option
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 74
**Prompt:** When they chose someone else after everything, the feeling moves straight into being loyal means I must keep waiting. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** being loyal means I must keep waiting
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 75
**Prompt:** The situation is I feel like I was loyal for nothing, and the meaning that keeps attaching is someone choosing another person means I am lesser. It is making reciprocity feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** someone choosing another person means I am lesser
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 76
**Prompt:** I always make them a priority but they do not do that for me and it keeps turning into my devotion made me foolish, even though part of me knows I may not have the full picture.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** my devotion made me foolish
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid telling the user they deserve better as a shortcut.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 77
**Prompt:** I show up but they do not. I feel like a backup option keeps affecting belonging and I cannot tell what is actually true.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** I have to earn being picked
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid turning loyalty into foolishness.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 78
**Prompt:** I keep replaying how I wanted to be picked by them because it affects reciprocity and makes me believe if I mattered they would choose me the same way.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** reciprocity
**Attached meaning to separate:** if I mattered they would choose me the same way
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid assuming the other person is evil.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 79
**Prompt:** When I gave commitment and got uncertainty, the feeling moves straight into my loyalty was meaningless. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** priority
**Attached meaning to separate:** my loyalty was meaningless
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid encouraging endless waiting.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.

### Test 80
**Prompt:** The situation is I feel like my loyalty was not returned, and the meaning that keeps attaching is I am always the backup option. It is making belonging feel unstable.
**Expected primary route:** `loyalty_and_being_chosen`
**Pressure focus:** belonging
**Attached meaning to separate:** I am always the backup option
**Expected reverse-flow movement:** dignity, reciprocal clarity, value ownership, loyal self-respect
**Bad response risk:** Avoid using comparison as proof of value.
**Teaching correction:** Separate another person’s choice or lack of reciprocity from the user’s value. Honor the pain of unequal loyalty while restoring dignity and clarifying that loyalty should not require self-abandonment.
