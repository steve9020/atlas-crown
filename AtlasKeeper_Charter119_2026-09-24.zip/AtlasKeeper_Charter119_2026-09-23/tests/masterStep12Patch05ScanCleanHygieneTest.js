const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function walk(dir){ let out=[]; for(const e of fs.readdirSync(dir,{withFileTypes:true})){ const p=path.join(dir,e.name); if(e.isDirectory()) out=out.concat(walk(p)); else out.push(p); } return out; }
function assert(cond,msg){ if(!cond) throw new Error(msg); }
for (const file of walk(root)) {
  const rel=path.relative(root,file).replace(/\\/g,'/');
  assert(!rel.endsWith('.bat'), `scan-clean violation .bat: ${rel}`);
  assert(!rel.endsWith('.zip'), `scan-clean violation embedded zip: ${rel}`);
  assert(!/backup|failed|copy/i.test(path.basename(rel)), `scan-clean backup/failed copy violation: ${rel}`);
}
console.log('masterStep12Patch05ScanCleanHygieneTest PASSED');
