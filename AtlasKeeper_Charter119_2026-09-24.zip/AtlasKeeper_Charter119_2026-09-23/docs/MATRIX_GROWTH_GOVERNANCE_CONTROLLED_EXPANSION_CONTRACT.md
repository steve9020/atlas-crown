# Matrix Growth Governance + Controlled Expansion Contract

Atlas can continue growing, but growth is evidence-gated and human-controlled.

A candidate is not promoted because it sounds useful. It must be distinct, recurring, boundary-safe, compatible, testable, reversible, and explicitly approved. Duplicate candidates are merged or reused; speculative and contradictory candidates are rejected; incomplete candidates are quarantined.

Human approval authorizes proof work only. It does not directly write to the active matrix or Doyle sphere map.
