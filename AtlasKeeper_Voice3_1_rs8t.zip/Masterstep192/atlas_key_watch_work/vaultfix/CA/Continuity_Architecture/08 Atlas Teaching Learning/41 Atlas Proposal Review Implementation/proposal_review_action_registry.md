# Proposal Review Action Registry

## Actions
- Approve: moves proposal into approved status.
- Implement: writes approved proposal into target backend markdown and reloads runtime.
- Defer: holds proposal for later.
- Reject: marks proposal unusable.
- Revoke: invalidates/removes proposal from the learning path.

## Rule
Implementation is blocked unless the proposal is complete and approved.
