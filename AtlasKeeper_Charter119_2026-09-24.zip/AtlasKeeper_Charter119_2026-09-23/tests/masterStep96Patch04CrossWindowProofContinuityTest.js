const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function exists(rel){ return fs.existsSync(path.join(ROOT, rel)); }
function json(rel){ return JSON.parse(read(rel)); }
const required = [
  'runtime/proof/CROSS_WINDOW_PROOF_CONTINUITY_LEDGER.md',
  'runtime/proof/CROSS_WINDOW_PROOF_CONTINUITY_LEDGER.json',
  'runtime/proof/MASTERSTEP96_PATCH04_CROSS_WINDOW_PROOF_CONTINUITY.md',
  'runtime/proof/MASTERSTEP96_PATCH04_CROSS_WINDOW_PROOF_CONTINUITY.json',
  'docs/MASTERSTEP96_PATCH04_CROSS_WINDOW_PROOF_CONTINUITY.md'
];
assert.deepStrictEqual(required.filter(rel => !exists(rel)), [], 'Missing Patch04 cross-window proof files');
const ledger = json('runtime/proof/CROSS_WINDOW_PROOF_CONTINUITY_LEDGER.json');
const proof = json('runtime/proof/MASTERSTEP96_PATCH04_CROSS_WINDOW_PROOF_CONTINUITY.json');
assert.strictEqual(ledger.package, 'Masterstep96_04patch.zip');
assert.strictEqual(ledger.source_keeper, 'Masterstep96_03patch.zip');
assert.strictEqual(ledger.patch, '04');
assert.ok(/does not claim complete proof from every ChatGPT project window/i.test(ledger.claim_boundary));
assert.ok(ledger.inventory_summary.masterstep_docs_found >= 80, 'Expected broad package-carried masterstep docs inventory');
assert.ok(ledger.inventory_summary.current_runner_commands_found >= 13, 'Expected prior current proof runner commands represented');
assert.ok(Array.isArray(ledger.known_cross_window_handoffs) && ledger.known_cross_window_handoffs.length >= 8, 'Expected known cross-window handoffs');
assert.ok(Array.isArray(ledger.missing_external_evidence) && ledger.missing_external_evidence.length >= 2, 'Expected missing external evidence list');
assert.ok(ledger.known_cross_window_handoffs.some(x => /Masterstep93/.test(x.available_evidence) || /Masterstep93/.test(x.window_or_handoff)), 'Expected current project-window chain evidence');
assert.ok(ledger.known_cross_window_handoffs.some(x => /Masterstep79/.test(x.window_or_handoff) || /Masterstep79/.test(x.available_evidence)), 'Expected carried Step79 window handoff');
assert.strictEqual(ledger.boundaries_preserved.deletion, false);
assert.strictEqual(ledger.boundaries_preserved.provider_model_cloud_api_network_bridge, false);
assert.strictEqual(proof.cross_window_ledger_added, true);
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (exists('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
const state = json('runtime/proof/PROOF_STATE.json');
const version = json('tests/VERSION_STATUS.json');
const runner = read('proof/runCurrentProof.js');
assert.ok((/Masterstep96_0[45678]patch|Masterstep97|Masterstep98|Masterstep99|Masterstep100|Masterstep101|Masterstep102|Masterstep103|Masterstep104|Masterstep105|Masterstep106|Masterstep107|Masterstep108|Masterstep109|Masterstep110|Masterstep111|Masterstep112|Masterstep113|Masterstep135|Masterstep114|Masterstep135|Masterstep115|Masterstep135|Masterstep116|Masterstep117|Masterstep118|Masterstep119|Masterstep120|Masterstep1[89][0-9]/).test(summary), 'Current summary must reference Masterstep96_04patch or later keeper patch');
assert.ok(/CROSS_WINDOW_PROOF_CONTINUITY_LEDGER/.test(summary), 'Current summary must reference cross-window ledger');
assert.ok(/MASTERSTEP(96_PATCH0[45678]|9[789]|10[0-9]|11[0-9]|12[0-9]|13[0-9]|14[0-9]|15[0-9]|16[0-9]|17[0-9]|1[89][0-9])_CURRENT_PROOF_MANIFEST/.test(state.current_manifest), 'state manifest must be Patch04 or later');
assert.ok(isValidLaterKeeper(version.current_keeper_patch || version.current_keeper, 96), 'version keeper must be Patch04 or later');
assert.ok(runner.includes('masterStep96Patch04CrossWindowProofContinuityTest'), 'Current proof runner must include Patch04 test');
console.log(JSON.stringify({pass:true, package: ledger.package, known_cross_window_handoffs: ledger.known_cross_window_handoffs.length, missing_external_evidence: ledger.missing_external_evidence.length}, null, 2));
