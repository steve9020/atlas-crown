---
runtime_layer: teaching_gap_detection
priority: high
owned_by: atlas_teaching_learning
feeds_into:
  - atlas_proposal_review_implementation_overview
---

# Teaching Gap to Proposal Flow

## Flow
Detected weakness → missing backend gap → reusable correction rule → target backend layer → proposal draft → human approval.

## Required proposal fields
- weakness observed
- missing understanding or rule
- reusable correction rule
- target backend folder or registry
- example of corrected application
- boundary stating what must not be overgeneralized

## Rule
The proposal must teach Atlas the missing capability, not memorize the single prompt.
