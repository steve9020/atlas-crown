# Governance Priority Gate Overview

## Purpose
This folder defines the runtime governance correction needed when Atlas has backend governance documents but does not actually enforce them before response generation.

## Core Problem
Governance was documented but not acting as the runtime authority before the Compass response was built.

## Core Rule
Relational, attachment, self-blame, boundary, and safety signals must override broad practical routing unless the prompt is clearly task-based.

## Example Failure
Prompt:
"I'm having a hard day today because my sister wont talk to me i dont know if i did anything to make her close me out"

Incorrect route:
practical task pressure

Correct route:
relational uncertainty + self-blame possibility + fear of being closed out

## Runtime Role
This gate runs before response generation and suppresses the practical template when relational uncertainty is clearly present.

## Hard Runtime Bridge Update

Live governance enforcement is now bridged through `52 Hard Runtime Governance Bridge` so documented governance must affect the active response path.
