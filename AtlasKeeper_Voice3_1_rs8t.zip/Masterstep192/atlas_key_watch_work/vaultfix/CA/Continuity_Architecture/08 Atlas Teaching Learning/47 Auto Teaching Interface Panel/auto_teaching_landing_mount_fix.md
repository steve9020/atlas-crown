# Auto Teaching Landing Mount Fix

## Purpose
The Auto Teaching dashboard previously existed but only rendered after a Compass prompt was submitted.

This fix mounts Auto Teaching directly from the Compass landing page.

## Behavior
- Adds visible `📖 Auto Teaching` button under Compass subtitle.
- Button opens the Auto Teaching dashboard without submitting a prompt.
- Dashboard remains available after runtime reload.
- Existing post-prompt Auto Teaching rendering remains supported.

## Reason
The teaching center should be reachable as its own interface space, not only as a response attachment.
