const assert = require('assert');
const fs = require('fs');
const path = require('path');
const status = require('../version_status.js');
const root = path.resolve(__dirname, '..');
const required = [
  'runtime/semantics/ActiveAttachmentScorer.js',
  'runtime/semantics/SeparationTargetMapper.js',
  'runtime/compass/CompassOntologyLanguageWeaver.js',
  'tests/masterStep89ContextBeforeRouteSemanticAttachmentTest.js',
  'tests/masterStep89FullClosureKeeperReadinessTest.js',
  'docs/MASTERSTEP89_CONTEXT_BEFORE_ROUTE_SEMANTIC_ATTACHMENT.md',
  'runtime/proof/MASTERSTEP89_CONTEXT_BEFORE_ROUTE_SEMANTIC_ATTACHMENT.md',
  'runtime/proof/MASTERSTEP89_CONTEXT_BEFORE_ROUTE_SEMANTIC_ATTACHMENT.json',
  'proof/runCurrentProof.js',
  'version_status.js'
];
const missing = required.filter(rel => !fs.existsSync(path.join(root, rel)));
assert.deepStrictEqual(missing, []);
assert.ok(['Masterstep89','Masterstep90','Masterstep91','Masterstep92'].includes(status.currentKeeper));
assert.ok(['Masterstep88','Masterstep89','Masterstep90','Masterstep91'].includes(status.previousKeeper));
assert.strictEqual(status.contextBeforeRouteSemanticAttachmentComplete, true);
assert.strictEqual(status.broadPhraseRouteSuppressionComplete, true);
assert.strictEqual(status.relationalResponseUncertaintyContextPromoted, true);
assert.strictEqual(status.step89NoNewOntologyAdded, true);
assert.strictEqual(status.step89NoNewMechanismsAdded, true);
assert.strictEqual(status.step89NoDeletionPerformed, true);
assert.strictEqual(status.step89NoProviderModelCloudFrontendExpansion, true);
assert.strictEqual(status.providerConfigured, false);
assert.strictEqual(status.realModelConnected, false);
assert.strictEqual(status.networkBridgeEnabled, false);
assert.strictEqual(status.frontendIntelligenceAllowed, false);
assert.strictEqual(status.operatorConsoleAdded, false);
console.log('masterStep89FullClosureKeeperReadinessTest PASSED');
