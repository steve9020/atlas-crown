# Teach Atlas Runtime Flow

## Purpose
Teach Atlas is the manual correction channel for improving program behavior.

## When It Appears
Teach Atlas may appear when Compass detects:
- vague response behavior
- weak routing
- missing emotional context
- missing attached meaning
- missing pattern explanation
- too mechanical delivery
- unclear response correction need

## What It Does
Teach Atlas turns a correction into a proposal, not active learning.

## Flow
User correction → teaching proposal → approval queue → approval gate → integration draft → backend registry write.

## Rule
Teaching is program-only. It should improve Atlas behavior without turning the user conversation into therapy, diagnosis, or personal authority.
