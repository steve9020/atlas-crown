const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const version = require('../version_status');
const root = path.resolve(__dirname, '..');
const required = [
  'runtime/backend/stability/LocalGovernedRuntimeStabilitySweep.js',
  'runtime/proof/MASTERSTEP77_LOCAL_GOVERNED_RUNTIME_STABILITY_SWEEP.json',
  'runtime/proof/MASTERSTEP77_LOCAL_GOVERNED_RUNTIME_STABILITY_SWEEP.md',
  'docs/MASTERSTEP77_LOCAL_GOVERNED_RUNTIME_STABILITY_SWEEP_MAP.md',
  'tests/masterStep77LocalGovernedRuntimeStabilitySweepTest.js'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(root, rel)), 'missing Step77 artifact: ' + rel);
const proof = JSON.parse(fs.readFileSync(path.join(root, 'runtime/proof/MASTERSTEP77_LOCAL_GOVERNED_RUNTIME_STABILITY_SWEEP.json'), 'utf8'));
assert.strictEqual(proof.passed, true, 'proof JSON must record Step77 pass');
assert.strictEqual(proof.source_keeper, 'Masterstep76');
assert.strictEqual(proof.cloud_work_deferred, true);
assert.strictEqual(proof.provider_connected, false);
assert.strictEqual(proof.real_model_connected, false);
assert.strictEqual(proof.local_offline_model_connected, false);
assert.strictEqual(proof.api_keys_added, false);
assert.strictEqual(proof.endpoints_added, false);
assert.strictEqual(proof.network_bridge_added, false);
assert.strictEqual(proof.frontend_intelligence_added, false);
assert.strictEqual(proof.real_model_execution_added, false);
assert.strictEqual(proof.stability_fail_count, 0);
assert.strictEqual(proof.required_chain_evidence.prior_proof_chain_still_passes, true);
assert.strictEqual(proof.required_chain_evidence.stability_prompt_cases_pass, true);
assert.strictEqual(proof.required_chain_evidence.teaching_center_review_boundary_blocks_silent_mutation, true);
assert.strictEqual(proof.required_chain_evidence.provider_model_cloud_still_disconnected, true);
assert.strictEqual(proof.required_chain_evidence.frontend_shell_still_dumb, true);
assert.strictEqual(proof.required_chain_evidence.no_nested_archives, true);
assert.strictEqual(proof.required_chain_evidence.no_patch_commit_without_human_review, true);
assert.strictEqual(version.currentKeeper, 'Masterstep77');
assert.strictEqual(version.previousKeeper, 'Masterstep76');
assert.strictEqual(version.step, 'Local Governed Runtime Stability Sweep');
assert.strictEqual(version.aiConnected, false);
assert.strictEqual(version.providerConfigured, false);
assert.strictEqual(version.providerWrapperExecutionEnabled, false);
assert.strictEqual(version.networkBridgeEnabled, false);
assert.strictEqual(version.frontendIntelligenceAllowed, false);
assert.strictEqual(version.backendOwnsIntelligence, true);
assert.strictEqual(version.cloudProviderEvaluationStarted, false);
assert.strictEqual(version.localGovernedRuntimeStabilitySweepComplete, true);
assert.strictEqual(version.localGovernedRuntimeStabilityWeakCasesRemaining, 0);
assert.strictEqual(version.nextTarget, 'Masterstep78 — Local Pre-Model Closure / Distribution-Hold Check');
console.log('masterStep77FullClosureKeeperReadinessTest PASSED');
