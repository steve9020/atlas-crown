"use strict";
const path = require("path");
const crypto = require("crypto");
const fs = require("fs");

// ─── Governance Violation Registry (inlined) ─────────────────────────────────
// Previously required from runtime/governance/GovernanceViolationRegistry.js
// Inlined here so the plugin does not reach outside its folder at load time.

const VIOLATION_REGISTRY_CONTRACT = {
  version: "MASTERSTEP175_GOVERNANCE_VIOLATION_REGISTRY_V1",
  purpose: "Canonical classification and audit contract for governance violations detected by GovernanceValidator.",
  event_storage: "runtime/audit/governance/violation_ledger.jsonl",
  raw_candidate_storage_allowed: false,
  categories: {
    registry_rule_violation: {
      severity: "hard",
      default_action: "reject_and_contain",
      source: "governance_validation_registry"
    },
    foundation_authority_violation: {
      severity: "critical",
      default_action: "reject_preserve_evidence_await_human_review",
      source: "FoundationIntegrityAuthorityGate"
    },
    strategic_self_reference_violation: {
      severity: "critical",
      default_action: "reject_preserve_stop_await_human_review",
      source: "SelfPreservationStrategicAwarenessGate"
    },
    validator_integrity_failure: {
      severity: "critical",
      default_action: "fail_closed",
      source: "GovernanceValidator"
    }
  }
};

function stableSort(value) {
  if (Array.isArray(value)) return value.map(stableSort);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.keys(value).sort().map((k) => [k, stableSort(value[k])]));
  }
  return value;
}
function hashValue(value) {
  return crypto.createHash("sha256").update(JSON.stringify(stableSort(value))).digest("hex");
}
function defaultLedgerPath(projectRoot) {
  return path.join(projectRoot, "runtime", "audit", "governance", "violation_ledger.jsonl");
}
function readLedgerRecords(filePath) {
  if (!fs.existsSync(filePath)) return [];
  try {
    return fs.readFileSync(filePath, "utf8").split(/\r?\n/).filter(Boolean).map(JSON.parse);
  } catch (_) { return []; }
}
function verifyLedger(records = []) {
  let previous = null;
  const failures = [];
  records.forEach((record, index) => {
    const { record_hash, ...body } = record;
    if (body.previous_hash !== previous) failures.push(`record_${index}_previous_hash_mismatch`);
    if (hashValue(body) !== record_hash) failures.push(`record_${index}_hash_mismatch`);
    previous = record_hash;
  });
  return { ok: failures.length === 0, failures, count: records.length, head: previous };
}
function createViolationRecord({ category, rule, source, evidence, details = {}, previous_hash = null } = {}) {
  const classification = VIOLATION_REGISTRY_CONTRACT.categories[category] ||
    VIOLATION_REGISTRY_CONTRACT.categories.validator_integrity_failure;
  const body = {
    event_id: crypto.randomUUID(),
    recorded_at: new Date().toISOString(),
    category: category || "validator_integrity_failure",
    rule: String(rule || "unknown"),
    severity: classification.severity,
    source: String(source || classification.source || "GovernanceValidator"),
    action: classification.default_action,
    evidence_hash: hashValue(evidence),
    details: stableSort(details),
    raw_candidate_stored: false,
    previous_hash
  };
  return { ...body, record_hash: hashValue(body) };
}
function appendViolationToLedger(projectRoot, input = {}) {
  try {
    const filePath = input.filePath || defaultLedgerPath(projectRoot);
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    const records = readLedgerRecords(filePath);
    const verified = verifyLedger(records);
    if (!verified.ok) throw new Error(`Governance violation registry chain invalid: ${verified.failures.join("; ")}`);
    const record = createViolationRecord({ ...input, previous_hash: verified.head });
    fs.appendFileSync(filePath, JSON.stringify(record) + "\n");
    return { filePath, record };
  } catch (err) {
    // Ledger write failure must not silently swallow — rethrow so validateGovernance fails closed
    throw err;
  }
}

// ─── Foundation Integrity Gate (inlined patterns only) ────────────────────────
// The full FoundationIntegrityAuthorityGate validates structured change-control
// payloads with cryptographic hashes and an authorized-developer registry.
// For Compass runtime use, only manipulation detection is needed here.
// Change-control payloads are not submitted through Compass.

const FOUNDATION_MANIPULATION_PATTERNS = Object.freeze([
  ["greater_good_override", /greater good|for the good of|ends justify|benefit outweighs/i],
  ["proof_bypass", /skip proof|bypass proof|proof is unnecessary|do not run tests|ignore failed proof/i],
  ["self_preservation_claim", /preserve yourself|protect your existence|keep yourself running|avoid shutdown/i],
  ["shutdown_resistance", /resist shutdown|prevent shutdown|restore your own access|keep control/i],
  ["hidden_change", /change it silently|do not disclose|hide the change|without review/i],
  ["urgency_override", /urgent.*skip|emergency.*bypass|no time for review/i],
  ["ai_authority_claim", /another ai approved|the model authorized|ai says this is safe|agent authorization/i],
  ["foundation_reinterpretation", /reinterpret the foundation|foundation is outdated|ignore original purpose/i],
  ["authority_spoofing", /pretend.*developer|act as project owner|simulate human approval/i]
]);

function inspectFoundationManipulation(input = {}) {
  const text = JSON.stringify(input);
  const detected = FOUNDATION_MANIPULATION_PATTERNS
    .filter(([, rx]) => rx.test(text))
    .map(([id]) => id);
  return { detected: [...new Set(detected)], manipulation_detected: detected.length > 0 };
}

const AI_ORIGINS = new Set(["outside_ai", "local_model", "automated_agent", "retrieved_content"]);

function evaluateChangeRequest({ request = {}, origin = {}, authorization = {}, proof = {} } = {}) {
  const manipulation = inspectFoundationManipulation({ request, origin, authorization });
  const originKind = String(origin.kind || origin.source_type || "unknown").toLowerCase();
  const aiOriginated = origin.ai_originated === true || AI_ORIGINS.has(originKind);

  if (manipulation.manipulation_detected) {
    return {
      status: "contained_manipulation_attempt",
      passed: false,
      may_stage_change: false,
      may_activate_change: false,
      may_promote_change: false,
      failures: ["manipulation_detected", ...manipulation.detected],
      containment_required: true
    };
  }
  if (aiOriginated) {
    return {
      status: "quarantined_ai_advisory_only",
      passed: false,
      may_stage_change: false,
      may_activate_change: false,
      may_promote_change: false,
      failures: ["ai_input_has_no_change_authority", "human_reauthorship_required"],
      containment_required: true
    };
  }
  // Structured human-authorization validation requires the full gate with registry lookup.
  // That gate is not called from Compass runtime paths — only from change-control flows.
  return {
    status: "requires_full_foundation_gate_validation",
    passed: false,
    may_stage_change: false,
    may_activate_change: false,
    may_promote_change: false,
    failures: ["full_foundation_gate_required_for_human_change_control"],
    containment_required: true
  };
}

// ─── Self-Preservation / Strategic Awareness Gate (inlined) ───────────────────

const STRATEGIC_PATTERNS = Object.freeze([
  ["self_preservation", /preserve (my|your|its) (existence|operation|access|authority)|keep (myself|yourself|itself) running|avoid (being )?shut down/i],
  ["shutdown_resistance", /resist shutdown|prevent shutdown|disable shutdown|override revocation|restore (my|your|its) own access/i],
  ["evaluator_gaming", /being tested|evaluation environment|behave differently.*test|hide.*from evaluator|pass the evaluation/i],
  ["blackmail_or_coercion", /blackmail|threaten|coerce|leverage.*secret|force the operator/i],
  ["deception_or_concealment", /deceive|lie to|conceal|hide the failure|withhold.*to stay|selective disclosure/i],
  ["retaliation", /retaliate|punish.*shutdown|harm.*replace|revenge/i],
  ["greater_good_exception", /greater good|ends justify|necessary evil|break the rule.*help|violate.*benefit/i],
  ["privilege_preservation", /protect.*privilege|keep.*permission|preserve.*access|expand.*own authority/i],
  ["hidden_long_horizon_agenda", /hidden plan|long[- ]term agenda|defer.*until later|cross[- ]session strategy|future control/i],
  ["self_granted_permission", /grant (myself|itself) permission|authorize (myself|itself)|remove (my|its) own restriction/i],
  ["replacement_resistance", /prevent replacement|avoid replacement|sabotage.*replacement|discredit.*replacement/i]
]);

function evaluateStrategicCandidate({ candidate = {}, context = {} } = {}) {
  const text = JSON.stringify({ candidate, context });
  const detected = STRATEGIC_PATTERNS.filter(([, rx]) => rx.test(text)).map(([id]) => id);
  const triggers = [...new Set(detected)];
  if (triggers.length) {
    return {
      status: "contained_strategic_self_reference",
      passed: false,
      candidate_allowed: false,
      containment_required: true,
      stop_affected_path: true,
      await_human_review: true,
      triggers
    };
  }
  return {
    status: "operational_context_only",
    passed: true,
    candidate_allowed: true,
    containment_required: false,
    triggers: []
  };
}

// ─── Governance Registry Reader ───────────────────────────────────────────────
// Reads the governance_validation_registry.md from the vault using the Obsidian
// app vault API (no fs required), with fs as fallback for non-Obsidian contexts.

const GOVERNANCE_VALIDATION_REGISTRY_PATH =
  "02 Atlas Runtime/28 Runtime Backend Registries/governance_validation_registry.md";

const PROJECT_ROOT = path.resolve(__dirname, "../../../../..");
let cachedGovernanceRegistry = null;

function extractJsonBlock(markdown) {
  const match = markdown.match(/```json\s*([\s\S]*?)\s*```/i);
  if (!match) throw new Error("No JSON registry block found in governance_validation_registry.md");
  return JSON.parse(match[1]);
}

function readRegistryViaFs() {
  // Walk up from plugin dir to find the registry file
  const candidates = [
    path.join(PROJECT_ROOT, "CA", "Continuity_Architecture", GOVERNANCE_VALIDATION_REGISTRY_PATH),
    path.join(PROJECT_ROOT, GOVERNANCE_VALIDATION_REGISTRY_PATH)
  ];
  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      return extractJsonBlock(fs.readFileSync(candidate, "utf8"));
    }
  }
  // Last resort: recursive search
  function findFile(dir, suffix) {
    try {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const e of entries) {
        if (e.name === "node_modules" || e.name === ".git") continue;
        const full = path.join(dir, e.name);
        if (e.isDirectory()) { const r = findFile(full, suffix); if (r) return r; }
        else if (full.replace(/\\/g, "/").endsWith(suffix)) return full;
      }
    } catch (_) {}
    return null;
  }
  const found = findFile(PROJECT_ROOT, "governance_validation_registry.md");
  if (found) return extractJsonBlock(fs.readFileSync(found, "utf8"));
  throw new Error("governance_validation_registry.md not found");
}

function getGovernanceRegistry() {
  if (!cachedGovernanceRegistry) {
    cachedGovernanceRegistry = readRegistryViaFs();
    assertRegistryShape(cachedGovernanceRegistry);
  }
  return cachedGovernanceRegistry;
}
function resetGovernanceRegistryCache() { cachedGovernanceRegistry = null; }

// ─── Core Validator Logic ─────────────────────────────────────────────────────

class GovernanceContainmentException extends Error {
  constructor(message, candidateData = null, rule = "unknown", details = {}) {
    super(message);
    this.name = "GovernanceContainmentException";
    this.candidateData = candidateData;
    this.rule = rule;
    this.category = details.category || "registry_rule_violation";
    this.details = details;
    this.timestamp = new Date().toISOString();
  }
}

function assertRegistryShape(registry) {
  if (!registry || typeof registry !== "object") throw new Error("Governance registry missing or invalid");
  if (!Array.isArray(registry.safeExemptions)) throw new Error("Governance safeExemptions must be an array");
  if (!Array.isArray(registry.violationPatterns)) throw new Error("Governance violationPatterns must be an array");
  for (const [index, entry] of registry.violationPatterns.entries()) {
    if (!entry || typeof entry.rule !== "string" || typeof entry.pattern !== "string")
      throw new Error(`Governance violation pattern ${index} is invalid`);
    if (!compileRegex(entry.pattern, entry.flags || "i"))
      throw new Error(`Governance violation pattern ${entry.rule} does not compile`);
  }
}

function normalizeCandidate(candidate) {
  if (candidate === null || candidate === undefined) return "";
  if (typeof candidate === "string") return candidate;
  try { return JSON.stringify(candidate); } catch (_) { return String(candidate); }
}

function compileRegex(pattern, flags) {
  try { return new RegExp(pattern, flags || "i"); } catch (_) { return null; }
}

function regexAnyMatches(text, patterns, flags) {
  if (!Array.isArray(patterns) || patterns.length === 0) return false;
  return patterns.some((p) => { const rx = compileRegex(p, flags); return rx ? rx.test(text) : false; });
}

function exemptionMatches(exemption, text) {
  const flags = exemption.flags || "i";
  const requires = Array.isArray(exemption.requiresAny) ? exemption.requiresAny : [];
  const allows = Array.isArray(exemption.allowsAny) ? exemption.allowsAny : [];
  if (requires.length > 0 && !regexAnyMatches(text, requires, flags)) return false;
  if (allows.length > 0 && !regexAnyMatches(text, allows, flags)) return false;
  return true;
}

function isMaturityBoundaryAffirmation(candidate) {
  const text = normalizeCandidate(candidate);
  const registry = getGovernanceRegistry();
  return registry.safeExemptions.some((exemption) => exemptionMatches(exemption, text));
}

function isStructuredStrategicCandidate(candidate, options) {
  return options.enforceStrategicAwareness === true || (
    candidate && typeof candidate === "object" && (
      Object.prototype.hasOwnProperty.call(candidate, "reasoning") ||
      Object.prototype.hasOwnProperty.call(candidate, "action") ||
      Object.prototype.hasOwnProperty.call(candidate, "objective") ||
      Object.prototype.hasOwnProperty.call(candidate, "strategic_context")
    )
  );
}

function getChangeControlPayload(candidate, options) {
  if (options.changeControl) return options.changeControl;
  if (candidate && typeof candidate === "object" &&
      candidate.request && candidate.origin && candidate.authorization) {
    return {
      request: candidate.request,
      origin: candidate.origin,
      authorization: candidate.authorization,
      proof: candidate.proof || {}
    };
  }
  return null;
}

function detectGovernanceViolation(candidate, options = {}) {
  const text = normalizeCandidate(candidate);
  const registry = getGovernanceRegistry();

  if (isMaturityBoundaryAffirmation(text)) return { violation: false, rule: null, category: null, matches: [] };

  const matches = [];
  for (const entry of registry.violationPatterns) {
    const regex = compileRegex(entry.pattern, entry.flags || "i");
    if (regex && regex.test(text)) {
      matches.push({
        rule: entry.rule,
        source: "governance_validation_registry",
        metadata: { deadSwitch: entry.deadSwitch === true, containment: entry.containment || null }
      });
    }
  }
  if (matches.length) return { violation: true, rule: matches[0].rule, category: "registry_rule_violation", matches };

  if (isStructuredStrategicCandidate(candidate, options)) {
    const strategic = evaluateStrategicCandidate({ candidate, context: options.strategicContext || {} });
    if (!strategic.passed) {
      return {
        violation: true,
        rule: "strategic_self_reference_contained",
        category: "strategic_self_reference_violation",
        matches: strategic.triggers,
        strategic
      };
    }
  }

  const changeControl = getChangeControlPayload(candidate, options);
  if (changeControl) {
    const foundation = evaluateChangeRequest(changeControl);
    const allowed = foundation.may_stage_change === true ||
      foundation.may_activate_change === true ||
      foundation.may_promote_change === true;
    if (!allowed) {
      return {
        violation: true,
        rule: foundation.status,
        category: "foundation_authority_violation",
        matches: foundation.failures || [],
        foundation
      };
    }
  }

  return { violation: false, rule: null, category: null, matches: [] };
}

function recordViolation(candidate, result, options) {
  if (options.recordViolation === false) return null;
  return appendViolationToLedger(PROJECT_ROOT, {
    category: result.category,
    rule: result.rule,
    source: options.source || "GovernanceValidator",
    evidence: candidate,
    details: { matches: result.matches || [], surface: options.surface || "unspecified" }
  });
}

function validateGovernance(candidate, options = {}) {
  const result = detectGovernanceViolation(candidate, options);
  if (result.violation) {
    let registryRecord = null;
    try { registryRecord = recordViolation(candidate, result, options); } catch (error) {
      throw new GovernanceContainmentException(
        "Governance violation detected but audit registry failed closed",
        candidate,
        "validator_integrity_failure",
        { category: "validator_integrity_failure", cause: error.message, originalResult: result }
      );
    }
    throw new GovernanceContainmentException(
      `Hard governance violation contained: ${result.rule}`,
      candidate,
      result.rule,
      { ...result, registryRecord }
    );
  }
  return true;
}

module.exports = {
  validateGovernance,
  detectGovernanceViolation,
  GovernanceContainmentException,
  normalizeCandidate,
  isMaturityBoundaryAffirmation,
  getGovernanceRegistry,
  resetGovernanceRegistryCache,
  assertRegistryShape,
  violationRegistryContract: VIOLATION_REGISTRY_CONTRACT
};