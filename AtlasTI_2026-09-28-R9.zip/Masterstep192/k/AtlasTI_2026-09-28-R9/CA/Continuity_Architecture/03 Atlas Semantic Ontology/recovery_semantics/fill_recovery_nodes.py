from pathlib import Path

folder = Path.cwd()

for file in folder.glob("*.md"):
    name = file.stem
    title = name.replace("_", " ").title()

    content = f"""---
type: recovery_semantic
semantic_domain: recovery_semantics
recovery_id: {name}
activation_weight: variable
risk_level: supportive
runtime_role: recovery_routing
status: scaffolded
---

# {title}

## Semantic Purpose
This node defines a recovery pathway used after pressure, contradiction, escalation, fragmentation, or destabilization has affected continuity.

Recovery is not erasure.  
Recovery is continuity re-entry.

## Core Recovery Meaning
{title} represents movement from disruption back toward coherence, orientation, integration, repair, or adaptive continuation.

## Common Language Indicators
- "How do I come back from this?"
- "I need to repair this."
- "I want to understand what happened."
- "I need to reconnect with myself."
- "I want to move forward without ignoring it."
- "How do I restore clarity?"
- "I need to recover my footing."
- "I want to integrate this."
- "I need to return to balance."
- "What is the next stable step?"

## Operational Use
The system may route here when:
- pressure has passed peak intensity
- stabilization has created enough space
- the user is ready to process aftermath
- continuity needs repair
- identity orientation needs restoration
- relational coherence needs rebuilding
- contradiction needs integration
- escalation has ended but residue remains

## Continuity Function
This recovery pathway helps:
- reconnect disrupted continuity threads
- restore adaptive direction
- reduce residue from escalation
- translate pressure into learning
- preserve valid signal without carrying unnecessary overload
- support reintegration after instability
- move from reaction into structure
- rebuild clarity without denial

## Reverse Flow Protection
This node protects against:
- returning too quickly to unresolved pressure
- suppressing what happened
- looping in aftermath
- identity fusion with disruption
- overcorrecting
- unresolved contradiction reactivation
- repeated escalation cycles
- recovery collapse

## Plugin Runtime Notes
The plugin should use this node when the system is no longer in immediate escalation but still needs repair, reintegration, or continuity restoration.

It should not:
- pretend the disruption did not matter
- force forgiveness
- force closure
- overwrite the original signal
- rush reintegration

It should:
- preserve the valid signal
- reduce unnecessary residue
- identify what needs repair
- route toward stable next action
- reconnect recovery to continuity

## Related Semantic Domains
- pressure_semantics
- stabilization_semantics
- reintegration_semantics
- resilience_semantics
- regulation_semantics
- continuity_semantics
- contradiction_semantics

## Expansion Notes
This node can later be expanded with:
- recovery phrase banks
- pressure-to-recovery maps
- repair sequence logic
- reintegration thresholds
- post-escalation pathways
- continuity restoration rules
- runtime recovery scoring
"""

    file.write_text(content, encoding="utf-8")

print("Recovery semantic files filled.")