const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const summaryPath = path.join(root,'runtime','proof','CURRENT_PROOF_SUMMARY.md');
assert(fs.existsSync(summaryPath),'CURRENT_PROOF_SUMMARY.md missing');
const s = fs.readFileSync(summaryPath,'utf8');
const order = [
  '## 1. Current Keeper / Current Package',
  '## 2. Current Snapshot Status',
  '## 3. Latest Proof Result',
  '## 4. Latest Fuzz Result',
  '## 5. Latest Hygiene Result',
  '## 6. Active HOLD / Risks / Missing Items',
  '## 7. Latest Changes',
  '## 8. Carry-Forward Proof',
  '## 9. Archive / Historical Proof'
];
let last=-1;
for (const marker of order){
  const idx=s.indexOf(marker);
  assert(idx>=0, `missing proof ordering marker: ${marker}`);
  assert(idx>last, `proof ordering marker out of order: ${marker}`);
  last=idx;
}
const topSegment=s.slice(0, s.indexOf('## Prior Current Proof Summary'));
assert(topSegment.includes('Current keeper: `Masterstep12_patch07.zip`') || topSegment.includes('Current staged package: `Masterstep12_patch07_pass1.zip`'), 'patch07 current/staged package not top-loaded');
assert(topSegment.includes('Required snapshot reference: `ATLAS_RUNTIME_STAGE10_UI_CLEAN.zip`'), 'snapshot status not top-loaded');
console.log('masterStep12Patch07Pass1ProofOrderingIntegrityTest PASSED');
