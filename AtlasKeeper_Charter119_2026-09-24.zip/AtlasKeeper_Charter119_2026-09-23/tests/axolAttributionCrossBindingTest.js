const assert = require('assert');
const { detectAxes } = require('../Cognition/engine/AxisEngine.js');

const cases = [
  ['I intended to help, she expected me to leave, and Marcus chose to stay.', { intention:['self'], expectation:['she'], choice:['marcus'] }],
  ['Jennifer controls the schedule, I own my response, and they accepted the delay.', { control:['jennifer'], ownership:['self'], acceptance_rejection:['they'] }],
  ['He caused the delay, we took responsibility for cleanup, but she blamed Marcus.', { causation:['he'], responsibility:['we'] }],
  ['I trust her, she respects him, and he expects them to answer.', { trust:['self'], respect:['she'], expectation:['he'] }],
  ['Marcus intended to call, Jennifer chose to wait, while I expected an answer.', { intention:['marcus'], choice:['jennifer'], expectation:['self'] }],
  ['They crossed our boundary, we accepted the consequence, and she intended to repair it.', { boundary:['they'], acceptance_rejection:['we'], intention:['she'], repair:['she'] }],
  ['She owns the decision, he controls the budget, and I do not accept the outcome.', { ownership:['she'], control:['he'], acceptance_rejection:['self'], outcome:['self'] }],
  ['We expected support, they chose another route, and Marcus took responsibility for the result.', { expectation:['we'], choice:['they'], responsibility:['marcus'], outcome:['marcus'] }]
];

let complete = 0; let expectedCount = 0; let hitCount = 0;
for (const [text, expected] of cases) {
  const r = detectAxes(text); const misses=[]; const wrong=[];
  for (const [axis, actors] of Object.entries(expected)) {
    const ev = r.axis_evidence.find(x=>x.axis===axis);
    const actual = ev?.attributions?.map(x=>x.actor) || [];
    for (const actor of actors) { expectedCount++; if(actual.includes(actor)) hitCount++; else misses.push(`${axis}:${actor}`); }
    const expectedSet = new Set(actors);
    for (const actor of actual) if (actor && !expectedSet.has(actor)) wrong.push(`${axis}:${actor}`);
  }
  if (!misses.length && !wrong.length) complete++;
  else console.error('FAIL', text, '\nmisses=',misses,'wrong=',wrong,'\n',JSON.stringify(r.axis_evidence,null,2));
}
console.log(`AXOL attribution cross-binding ${hitCount}/${expectedCount}; complete ${complete}/${cases.length}`);
assert.strictEqual(complete,cases.length);
