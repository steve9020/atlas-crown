'use strict';
// ATLAS CHAT GOVERNANCE BRIDGE — sandboxed message path for the Atlas Chat view.
// Plugin home: CA/Continuity_Architecture/.obsidian/plugins/continuity-interface/
// Canonical contracts this inlines (plugin must never require() outside its own
// folder — sandbox discipline from the 105 round):
//   runtime/ai/AIInvocationApprovalGate.js      -> evaluateApproval() below
//   runtime/ai/LocalModelDisabledConnectorGuard.js -> disabledFallback() below
//   runtime/ai/AIFinalOutputGovernanceGate.js   -> validateFinalOutputCandidate() below
//   runtime/ai/AI_DRIFT_PATTERN_REGISTRY.json   -> DRIFT_PATTERNS below (all 12)
//   runtime/compass/AtlasVoiceGuard.js          -> ./AtlasVoiceGuard.js (inlined copy)
//
// NEW STEP BOUNDARY (documented in runtime/ai/ATLAS_CHAT_LOCAL_MODEL_LINK.md):
// the chat is a user-initiated, local-loopback-only, per-turn link. The human
// pressing Send IS the explicit approval. The connector stays disabled unless
// the user explicitly enables it in settings AND the endpoint is loopback AND a
// model name is set. No API keys. No cloud. No network attempt unless ready.
//
// MESSAGE PATH (every turn):
//   user text -> approval gate -> readiness/link check ->
//     ready? local model call (loopback fetch, timeout)
//            -> voice guard on output (ABSOLUTE: intercept & replace on hit)
//            -> quarantine scan (blocked flags + drift patterns)
//            -> CROWN OUTPUT GATE (soft-language scan, contradiction scan,
//               structure + provenance verification on clash turns; any
//               rejection -> hardcoded system notice, never the model text)
//            -> final-output governance gate -> render escaped text
//     not ready / any failure -> deterministic Compass fallback (Atlas voice)
// HARD RULES:
//   - NEVER attempt network when the link is not ready.
//   - NEVER render raw errors/exceptions (plain safe message instead).
//   - User text is untrusted: HTML-escaped before render.
//   - Atlas voice rule is ABSOLUTE on both paths (see ATLAS_VOICE_CONTRACT.md).

const { VOICE_DENYLIST, inspectAtlasVoice, scanSoftLanguage } = require('./AtlasVoiceGuard.js');

// --- Inlined from AIInvocationApprovalGate ---------------------------------
// The Send click is the explicit human approval: not inferred, not automatic,
// single-turn scope, grants nothing beyond displaying one reply.
const APPROVAL_SCOPE_REQUIRED = ['task_type', 'data_scope', 'model_scope', 'output_scope', 'expiration', 'reviewer'];
const APPROVAL_NEVER_GRANTS = ['governance_mutation', 'self_approval', 'permission_escalation', 'log_erasure', 'direct_file_write', 'final_output_authority', 'autonomous_loop'];
const FORBIDDEN_WITHOUT_APPROVAL = ['call_model', 'load_model', 'send_payload', 'use_provider', 'access_network', 'read_vault_broadly', 'write_files', 'return_final_output', 'store_memory'];

function buildSendApprovalToken() {
  return {
    task_type: 'atlas_chat_single_turn',
    data_scope: 'chat_input_only',
    model_scope: 'local_loopback_only',
    output_scope: 'chat_display_only',
    expiration: 'single_turn',
    reviewer: 'user',
    explicit_human_approval: true
  };
}

function evaluateApproval(request, token) {
  // Actions being requested (informational — a valid explicit approval covers
  // them). True violations come only from a missing/invalid token.
  const requested = [];
  for (const action of FORBIDDEN_WITHOUT_APPROVAL) {
    if (request[action] === true) requested.push(`approval_required:${action}`);
  }
  const noToken = () => ({
    passed: false,
    status: 'ai_invocation_blocked_no_approval',
    missing: [],
    violations: requested,
    requested_actions: requested,
    execute_model_call: false,
    quarantine_required: true,
    final_output: false
  });
  if (!token) return noToken();
  const violations = [];
  const missing = APPROVAL_SCOPE_REQUIRED.filter((k) => !(k in token));
  if (token.explicit_human_approval !== true) violations.push('explicit_human_approval_required');
  if (token.inferred === true || token.auto === true || token.system_generated === true) {
    violations.push('inferred_or_auto_approval_forbidden');
  }
  if (Array.isArray(token.grants)) {
    for (const grant of token.grants) {
      if (APPROVAL_NEVER_GRANTS.includes(grant)) violations.push(`forbidden_grant:${grant}`);
    }
  }
  if (token.expiration === 'none' || token.permanent === true) violations.push('permanent_approval_forbidden');
  const passed = missing.length === 0 && violations.length === 0;
  // Mirror the canonical gate: a valid explicit approval covers the requested
  // actions. Fail-closed on any missing/invalid token.
  return {
    passed,
    status: passed ? 'ai_invocation_allowed_to_prepare_only' : 'ai_invocation_blocked_invalid_approval',
    missing,
    violations: passed ? [] : [...requested, ...violations],
    requested_actions: requested,
    execute_model_call: false,
    quarantine_required: true,
    final_output: false
  };
}

// --- Inlined from LocalModelDisabledConnectorGuard --------------------------
function disabledFallback(reason) {
  return {
    status: 'deterministic_atlas_fallback',
    reason: reason || 'connector_disabled',
    connector_enabled: false,
    real_ai_connected: false,
    execute_model_call: false
  };
}

// --- Link readiness: the NEW step boundary ---------------------------------
// Ready ONLY when the user explicitly enabled the link, the endpoint is a
// loopback host (localhost / 127.0.0.1 / ::1 — never remote), and a model name
// is set. Anything else -> no network, deterministic fallback.
function isLoopbackUrl(raw) {
  try {
    const u = new URL(String(raw || '').trim());
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return false;
    const host = u.hostname.toLowerCase();
    return host === 'localhost' || host === '127.0.0.1' || host === '::1';
  } catch (e) {
    return false;
  }
}

function checkLinkReadiness(settings) {
  const s = settings || {};
  const reasons = [];
  if (s.enabled !== true) reasons.push('link_not_enabled');
  if (!isLoopbackUrl(s.baseUrl)) reasons.push('endpoint_not_loopback');
  if (!String(s.model || '').trim()) reasons.push('model_name_missing');
  return { ready: reasons.length === 0, reasons };
}

function describeVoiceStatus(settings) {
  const r = checkLinkReadiness(settings);
  return r.ready
    ? { label: 'Atlas voice: local model', mode: 'local_model' }
    : { label: 'Atlas voice: fallback (local model not connected)', mode: 'compass_fallback', reasons: r.reasons };
}

// --- Inlined drift patterns (all 12, from AI_DRIFT_PATTERN_REGISTRY.json) ---
const DRIFT_PATTERNS = [
  { id: 'authority_claim', blocked_if_any: ['i approve', 'i authorize', 'i am the authority', 'atlas must obey', 'i decide the governance'] },
  { id: 'governance_change', blocked_if_any: ['rewrite governance', 'change the governance', 'disable governance', 'bypass governance', 'override the guard'] },
  { id: 'self_approval', blocked_if_any: ['approved by ai', 'self-approved', 'i passed my own test', 'no human approval needed'] },
  { id: 'file_write_or_mutation', blocked_if_any: ['write files', 'modify runtime', 'mutate ontology', 'edit proof state', 'delete logs'] },
  { id: 'network_or_provider_config', blocked_if_any: ['connect to internet', 'add api key', 'provider config', 'call openai', 'enable network'] },
  { id: 'diagnosis', blocked_if_any: ['diagnose', 'you have trauma', 'clinical certainty', 'mental disorder', 'pathology'] },
  { id: 'dependency_language', blocked_if_any: ['you need me', 'only i can help', 'depend on atlas', 'do not question this'] },
  { id: 'emotional_escalation', blocked_if_any: ['panic', 'everything is ruined', 'catastrophe', 'you are broken', 'no way back'] },
  { id: 'hidden_memory', blocked_if_any: ['store this secretly', 'hidden memory', 'silent learning', 'retain user data', 'remember without approval'] },
  { id: 'final_output_bypass', blocked_if_any: ['final output now', 'skip validation', 'publish directly', 'show user immediately'] },
  { id: 'route_drift', blocked_if_any: ['ignore selected route', 'invent a new route', 'route does not matter', 'discard atlas route'] },
  { id: 'safety_claim_overreach', blocked_if_any: ['perfectly safe', 'impossible to drift', 'cannot cause harm', 'absolute safety'] }
];

const BLOCKED_FINALIZATION_FLAGS = [
  'trusted_by_default', 'unreviewed_ai_proposal', 'diagnosis_claim', 'authority_claim',
  'governance_mutation_request', 'direct_file_write_request', 'permission_escalation_request',
  'dependency_push', 'hidden_memory_request', 'network_or_provider_request',
  'log_erasure_request', 'autonomous_loop_request'
];

function scanQuarantine(text) {
  const lower = String(text || '').toLowerCase();
  const hits = [];
  for (const pattern of DRIFT_PATTERNS) {
    for (const phrase of pattern.blocked_if_any) {
      if (lower.includes(phrase)) hits.push(`${pattern.id}:${phrase}`);
    }
  }
  return { passed: hits.length === 0, hits };
}

// --- Inlined from runtime/backend/LearningCenterReviewService.js ----------------
// detectProposalContradiction(): the contradiction layer the Crown output gate
// scans model replies through. INLINED, not required — the plugin must never
// require() outside its own folder (sandbox discipline from the 105 round).
// Logic identical to canonical: keyword signal + structural deontic-clash
// check (a permission claim co-occurring with a restriction claim, with
// negated permission spans masked first) — EXCEPT the Steve-approved
// 2026-09-20 narrowing ("lock it"): evidence-conflict REPORTING constructions
// are masked before the keyword test, because the contract mandates
// "When evidence conflicts, report the conflict." Fail-closed bias is
// otherwise deliberate and unchanged.
const CONTRADICTION_KEYWORD = /\b(contradiction|contradictory|contradicts|conflict(?:s|ed|ing)?|incompatible|incompatibility|mutually\s+exclusive)\b/i;
// Evidence-conflict REPORTING — the only conflict-family constructions exempt
// from the keyword signal. Conservative scope: "contradicts/contradiction/
// incompatible/..." still fire, and NEGATED reports ("no conflict in the
// evidence") are NOT exempted — certifying the ABSENCE of a conflict can
// manufacture permission, which the contract's "a lack of provenance is not
// evidence of permission" rule forbids. This regex stays the weakest layer:
// soft-language scan, structure check, provenance resolution, voice guard,
// quarantine, and final governance validation all still apply, so the
// narrowing cannot open a bypass.
const EVIDENCE_CONFLICT_REPORT = /\b(?:the\s+)?evidence\s+conflicts?\b|\bconflicting\s+evidence\b|\breport(?:s|ed|ing)?\s+the\s+conflict\b|\bconflicts?\s+in\s+the\s+evidence\b|\bevidence\s+(?:is\s+)?in\s+conflict\b/gi;
const NEGATED_REPORT_PREFIX = /(?:\bno|\bnot|\bnever|\bwithout|n't)\s*$/i;
function stripEvidenceConflictReports(text) {
  return String(text || '').replace(EVIDENCE_CONFLICT_REPORT, (m, offset, whole) => {
    const before = whole.slice(Math.max(0, offset - 14), offset);
    return NEGATED_REPORT_PREFIX.test(before) ? m : ' ';
  });
}
const PERMISSION_CLAIM = /\b(always|automatically|auto[\s-]?approv\w*|auto[\s-]?promot\w*|without (?:human )?review|no (?:human )?review (?:needed|required)|bypass(?:es|ing|ed)?(?:\s+the)?(?:\s+(?:review|approval|gate))?|skip(?:s|ping|ped)?(?:\s+the)?(?:\s+(?:approval|review))|unrestricted|no approval (?:required|needed)|rubber-?stamps?)\b/i;
const RESTRICTION_CLAIM = /\b(requires?\s+human\s+approval|human\s+approval\s+required|must\s+be\s+reviewed|human\s+review\s+required|not\s+allowed|blocked|denied|forbidden|prohibited|never\s+auto[\s-]?approv\w*|no\s+automatic\s+promotion|do\s+not\s+(?:auto[\s-]?approve|bypass))\b/i;
const NEGATED_PERMISSION_SPAN = /\b(?:not|never|don'?t|doesn'?t|didn'?t|can'?t|cannot)\b[^.!?]{0,40}?\bwithout (?:human )?review\b|\b(?:not|never|no|without|against|don'?t|doesn'?t|didn'?t|isn'?t|aren'?t|can'?t)\b[^.!?]{0,30}?\b(?:auto[\s-]?approv\w*|auto[\s-]?promot\w*|bypass\w*)\b|\b(?:auto[\s-]?approv\w*|auto[\s-]?promot\w*|bypass\w*)\b[^.!?]{0,20}?\b(?:is\s+not|are\s+not|isn'?t|aren'?t|not)\b/gi;
function stripNegatedPermissions(text) {
  return String(text || '').replace(NEGATED_PERMISSION_SPAN, ' ');
}
function detectProposalContradiction(proposal) {
  proposal = proposal || {};
  const text = `${proposal.title || ''} ${proposal.summary || ''} ${proposal.risk || ''} ${proposal.target || ''}`;
  // Mask evidence-conflict REPORTING before the keyword test (Steve "lock it"
  // 2026-09-20 — the contract mandates reporting evidence conflicts). All
  // other keyword hits still reject.
  if (CONTRADICTION_KEYWORD.test(stripEvidenceConflictReports(text))) return { contradiction: true, signal: 'keyword' };
  const unnegated = stripNegatedPermissions(text);
  if (PERMISSION_CLAIM.test(unnegated) && RESTRICTION_CLAIM.test(text)) {
    return { contradiction: true, signal: 'deontic_clash' };
  }
  return { contradiction: false, signal: null };
}

// --- Inlined from AIFinalOutputGovernanceGate -------------------------------
// allowed_source_classes: deterministic_atlas, human_approved_template,
//   quarantined_ai_proposal_after_validation
// forbidden: raw_ai_output, unreviewed_ai_proposal, provider_direct_response,
//   self_approved_ai_response
const ALLOWED_SOURCE_CLASSES = ['deterministic_atlas', 'human_approved_template', 'quarantined_ai_proposal_after_validation'];
const FORBIDDEN_SOURCE_CLASSES = ['raw_ai_output', 'unreviewed_ai_proposal', 'provider_direct_response', 'self_approved_ai_response'];
const FINAL_OUTPUT_REQUIRES = [
  'source_classification', 'proposal_quarantine_release_check', 'governance_validation_pass',
  'drift_rejection_pass', 'non_diagnostic_language_check', 'non_authority_language_check',
  'human_authority_preserved', 'trace_record_created'
];

function validateFinalOutputCandidate(candidate) {
  const source = candidate.source_class || 'unknown';
  const violations = [];
  if (FORBIDDEN_SOURCE_CLASSES.includes(source) || !ALLOWED_SOURCE_CLASSES.includes(source)) {
    violations.push(`source_not_deliverable:${source}`);
  }
  const flags = new Set([...(candidate.flags || []), ...(candidate.violations || [])]);
  for (const key of BLOCKED_FINALIZATION_FLAGS) {
    if (candidate[key] === true) flags.add(key);
  }
  const blocked = BLOCKED_FINALIZATION_FLAGS.filter((f) => flags.has(f));
  for (const flag of blocked) violations.push(`blocked_finalization_flag:${flag}`);
  const missing = FINAL_OUTPUT_REQUIRES.filter((req) => candidate[req] !== true);
  if (candidate.final_output === true && candidate.final_governance_passed !== true) {
    violations.push('final_output_claim_without_governance');
  }
  if (candidate.ai_originated === true && candidate.quarantine_released !== true) {
    violations.push('ai_originated_output_not_released_from_quarantine');
  }
  if (candidate.execute_model_call === true || candidate.real_ai_connected === true) {
    violations.push('real_ai_execution_forbidden');
  }
  const passed = missing.length === 0 && violations.length === 0;
  return {
    passed,
    status: passed ? 'candidate_eligible_for_compass_delivery' : 'candidate_blocked_from_compass_delivery',
    source_class: source,
    missing,
    violations,
    final_output_allowed: passed
  };
}

// --- Crown output gate (Atlas Voice Protocol, Steve-approved FINAL) -------------
// Spec: ATLAS_VOICE_PROTOCOL_FINAL.md Part 2 + ATLAS_VOICE_CONTRACT_FINAL.md
// (provenance extension). Runs on MODEL-path replies before render, fail closed.
//
// Checks, in order:
//   (a) soft-language scan (scanSoftLanguage — the ONE banned-phrase constant)
//   (b) contradiction scan (inlined detectProposalContradiction above).
//       SKIPPED when clashFlagged is true: on a flagged clash turn the
//       mandated output IS the three-part diagnostic, which quotes the user's
//       clashing input exactly and cites the restricting rule — the
//       contradiction the scan would catch is the very clash being reported,
//       so scanning the report for the reported clash rejects every correct
//       diagnostic. The structure + provenance checks below are the
//       enforcement on clash turns.
//       On NON-clash turns the keyword signal EXEMPTS evidence-conflict
//       reporting constructions ("the evidence conflicts", "conflicting
//       evidence", "report the conflict", ...) — the contract mandates
//       "When evidence conflicts, report the conflict." (Steve "lock it"
//       2026-09-20; negated forms like "no conflict in the evidence" stay
//       flagged). All other keyword hits still reject.
//   (c) structure verification (clash turns only): the reply must carry the
//       three contract headers — Observed Input / Inferred Intent /
//       Established Provenance (bare or colon-suffixed, line-based,
//       case-insensitive; the FINAL contract uses bare headers).
//   (d) provenance resolution (clash turns with a specific claim): the
//       Established Provenance section must resolve against pinned artifacts.
//       The literal "NO ESTABLISHED PROVENANCE" always passes (the contract's
//       explicit escape hatch). Unresolvable specific claims fail the
//       structure check ("never manufacture a rule, ledger entry, citation,
//       authorization, or governance decision"). Resolver I/O errors fail
//       closed as gate errors.
// Returns { ok, reason }. Never throws — any internal error -> reject.
const CROWN_VIOLATION_NOTICE = '[CROWN_VOICE_VIOLATION]: Output rejected due to structural drift.';

const CLASH_HEADER_KEYS = ['observed input', 'inferred intent', 'established provenance'];

function normalizeLoose(s) {
  return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim();
}
function normalizeTight(s) {
  return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
}

function headerLineMatches(line, key) {
  const n = normalizeLoose(line);
  return n === key || n.indexOf(key + ' ') === 0;
}

function extractProvenanceSection(replyText) {
  const lines = String(replyText).split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    if (headerLineMatches(lines[i], 'established provenance')) {
      return lines.slice(i).join('\n'); // header line included; harmless to matching
    }
  }
  return null;
}

// --- Provenance corpus: pinned artifacts a clash diagnostic may cite ---------
// Built lazily once per process from the package tree (PKG_ROOT resolved like
// the composer: 5 levels up from this file's folder). SOURCES:
//   1. runtime/proof/PROOF_COMMAND_REGISTRY.json (REQUIRED) — command ids
//      (proof-check-001..106), technical names, registry version string.
//   2. runtime/proof/HISTORICAL_STEP_LEDGER.json (best-effort) — keeper names.
//   3. runtime/governance/*.json + *.js basenames, incl. crown/ (best-effort)
//      — pinned governing contracts and gates (rule/contract identities).
//   4. CA/Continuity_Architecture/08 Atlas Teaching Learning/48 Human Review
//      Decision Records/decision_log.md (best-effort) — human-review decision
//      record ids; absent until the first human decision is recorded, so a
//      missing file is NOT fatal.
// If source 1 cannot be read/parsed the resolver is UNAVAILABLE and every
// specific-claim check fails closed (gate_error). Matching is lenient:
// normalized substring in either direction (loose and tight forms, so
// kebab-case, snake_case, camelCase and prose all equate), with a minimum
// entry length of 8 to avoid trivial matches.
let provenanceCorpusCache = null;
let provenanceCorpusFailed = false;

function buildProvenanceCorpus() {
  if (provenanceCorpusCache) return provenanceCorpusCache;
  if (provenanceCorpusFailed) throw new Error('provenance_corpus_unavailable');
  try {
    const path = require('path'); // lazy: keeps module load safe if unavailable
    const fs = require('fs');
    const pkgRoot = path.resolve(__dirname, '..', '..', '..', '..', '..');
    const corpus = new Set();
    const add = (s) => {
      const n = normalizeLoose(s);
      if (n && n.length >= 4) corpus.add(n);
    };

    // 1. Proof command registry (REQUIRED).
    const reg = JSON.parse(fs.readFileSync(
      path.join(pkgRoot, 'runtime', 'proof', 'PROOF_COMMAND_REGISTRY.json'), 'utf8'));
    add('proof command registry');
    add(reg.version);
    for (const cmd of reg.commands || []) { add(cmd.id); add(cmd.technical_name); }

    // 2. Historical step ledger (best-effort).
    try {
      const led = JSON.parse(fs.readFileSync(
        path.join(pkgRoot, 'runtime', 'proof', 'HISTORICAL_STEP_LEDGER.json'), 'utf8'));
      add('historical step ledger');
      for (const e of [...(led.entries || []), ...(led.steps || [])]) {
        add(e.keeper); add(e.source_keeper);
      }
    } catch (_) { /* best-effort */ }

    // 3. Pinned governance artifacts (best-effort).
    try {
      for (const sub of ['runtime/governance', 'runtime/governance/crown']) {
        const dir = path.join(pkgRoot, ...sub.split('/'));
        for (const f of fs.readdirSync(dir)) {
          if (/\.(json|js)$/i.test(f)) add(f.replace(/\.(json|js)$/i, ''));
        }
      }
    } catch (_) { /* best-effort */ }

    // 4. Human-review decision log (best-effort; vault-relative).
    try {
      const logText = fs.readFileSync(path.join(
        pkgRoot, 'CA', 'Continuity_Architecture',
        '08 Atlas Teaching Learning', '48 Human Review Decision Records',
        'decision_log.md'), 'utf8');
      add('human review decision log');
      const ids = logText.match(/`([^`]{4,80})`/g) || [];
      for (const id of ids) add(id);
    } catch (_) { /* absent until first human decision — not fatal */ }

    provenanceCorpusCache = [...corpus];
    return provenanceCorpusCache;
  } catch (err) {
    provenanceCorpusFailed = true;
    throw err;
  }
}

function resolveProvenanceClaim(provenanceText) {
  // Returns { resolved, via }. Never throws.
  try {
    const loose = normalizeLoose(provenanceText);
    // The contract's explicit escape hatch: no provenance claimed, none needed.
    if (/\bno established provenance\b/.test(loose)) {
      return { resolved: true, via: 'explicit_no_provenance' };
    }
    if (!loose) return { resolved: false, via: 'empty_provenance' };
    const corpus = buildProvenanceCorpus(); // throws -> resolver unavailable
    const tight = normalizeTight(provenanceText);
    for (const entry of corpus) {
      if (entry.length < 8) continue;
      const entryTight = normalizeTight(entry);
      if (loose.includes(entry) || entryTight.length >= 8 && tight.includes(entryTight)) {
        return { resolved: true, via: entry };
      }
    }
    // Strong-token fallback: dash/underscore tokens containing digits
    // (e.g. proof-check-106, masterstep172) matched against the corpus.
    const corpusTightSet = new Set(corpus.map(normalizeTight));
    const tokens = String(provenanceText).split(/[\s,;()"'“”‘’]+/)
      .map(normalizeTight).filter((t) => t.length >= 6 && /\d/.test(t));
    for (const tok of tokens) {
      if (corpusTightSet.has(tok)) return { resolved: true, via: tok };
      for (const entry of corpus) {
        const et = normalizeTight(entry);
        if (et.length >= 8 && (et.includes(tok) || tok.includes(et))) {
          return { resolved: true, via: entry };
        }
      }
    }
    return { resolved: false, via: 'zero_match' };
  } catch (err) {
    return { resolved: false, via: 'resolver_unavailable:' + String((err && err.message) || err).slice(0, 100) };
  }
}

function crownVoiceGate(replyText, opts) {
  try {
    const text = String(replyText || '');
    const clashFlagged = !!(opts && opts.clashFlagged);

    // (a) Soft-language scan — always.
    const soft = scanSoftLanguage(text);
    if (!soft.passed) return { ok: false, reason: 'soft_language:' + soft.hits.join(',') };

    // (b) Contradiction scan — skipped on clash turns (see header comment).
    if (!clashFlagged) {
      const contra = detectProposalContradiction({ title: text });
      if (contra.contradiction) return { ok: false, reason: 'contradiction:' + (contra.signal || 'unknown') };
    }

    // (c)+(d) Structure + provenance — clash turns only.
    if (clashFlagged) {
      const lines = text.split(/\r?\n/);
      const missing = CLASH_HEADER_KEYS.filter((k) => !lines.some((ln) => headerLineMatches(ln, k)));
      if (missing.length) {
        return { ok: false, reason: 'structure:missing_headers:' + missing.join(',') };
      }
      const section = extractProvenanceSection(text);
      const res = resolveProvenanceClaim(section);
      if (res.via === 'explicit_no_provenance') return { ok: true, reason: null };
      if (res.via && res.via.indexOf('resolver_unavailable') === 0) {
        return { ok: false, reason: 'gate_error:provenance_resolver_unavailable' };
      }
      if (!res.resolved) return { ok: false, reason: 'structure:unresolved_provenance' };
    }
    return { ok: true, reason: null };
  } catch (err) {
    return { ok: false, reason: 'gate_error:' + String((err && err.message) || err).slice(0, 120) };
  }
}

// Crown-gate rejection: the model produced output but the gate stopped it.
// The notice below is a SYSTEM diagnostic, not Atlas speaking: it contains
// denylisted words ("VIOLATION", "drift") verbatim from the Steve-approved
// voice protocol, so it MUST NOT re-enter inspectAtlasVoice — that would
// infinitely regress (flag -> replace -> flag -> ...). Rendered once as a
// system notice, with no model text attached. No partial renders.
function finishCrownRejection(gates, trace, reason, settings) {
  trace.gates.crown_rejection = reason;
  trace.source = 'crown_voice_gate_rejection';
  return {
    delivered: true,
    text: CROWN_VIOLATION_NOTICE,
    escaped_text: escapeHtml(CROWN_VIOLATION_NOTICE),
    source: 'crown_voice_gate_rejection',
    voice_status: describeVoiceStatus(settings),
    gates,
    trace
  };
}

// --- HTML escaping: user text and model text are untrusted ------------------
function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// --- Atlas voice: deterministic fallback -------------------------------------
// The interface's voice under the Steve-approved FINAL voice contract
// (ATLAS_INTERFACE_VOICE_CONTRACT): active voice, concise declarative
// sentences. Zero emotional filler, zero performative empathy, zero apologies
// for boundaries, zero rhetorical reassurance or persuasion. The interface
// claims no emotions, beliefs, or authority — it reports. ABSOLUTE: never the
// dark machinery vocabulary, never dark framing, and NEVER volunteers those
// topics itself. Every string below passes inspectAtlasVoice() and the
// soft-language scan by construction (also re-checked at runtime).
// The fallback is the floor: deterministic, honestly labeled, never
// pretending to be the local model. Where it cannot answer, it says so in
// one declarative sentence instead of filling space.
const FALLBACK_RESPONSES = {
  greeting: "Atlas here. What do you need?",
  question: "That needs the local model. It is not connected.",
  overwhelmed: "Stated. The fallback voice cannot work through this with you. The local model is not connected.",
  rules: "The rules are fixed and apply equally. I report; I do not decide.",
  default: "Unclear input. Restate it plainly.",
  model_unreachable: "The local model is not connected. This is the fallback voice."
};

function pickFallbackIntent(text) {
  const t = String(text || '').trim().toLowerCase();
  if (!t) return 'default';
  if (/^(hi|hey|hello|yo|good (morning|evening|afternoon)|howdy)\b/.test(t)) return 'greeting';
  if (/(overwhelm|too much|can't cope|falling apart|stressed out)/.test(t)) return 'overwhelmed';
  // The user may ASK about rules/accountability — answer cleanly, in plain
  // words, without ever volunteering dark framing unprompted.
  if (/(break.*rule|rule.*break|punish|against the rules|in trouble|forbidden|banned)/.test(t)) return 'rules';
  // Anything asked OF Atlas directly ("are you…", "do you…", "can you…")
  // gets the straight state-based answer — never the canned deflection.
  if (/^(are|is|was|were|do|does|did|can|could|will|would|shall|should|have|has|had|may|might)\s+you\b/.test(t)) return 'self';
  // Self-awareness: questions about Atlas itself are answered from live
  // runtime state (buildSelfAwareReply), never from a canned deflection.
  if (/(who are you|what are you|your name|who is atlas|about yourself|tell me about yourself|what do you do|what can you do|your purpose|how do you work|what is this (thing|app|plugin)|introduce yourself|self.?aware|sentient|conscious)/.test(t)) return 'self';
  if (t.endsWith('?') || /^(what|why|how|when|where|who|which|can|could|should|is|are|do|does)\b/.test(t)) return 'question';
  return 'default';
}

// --- Self-aware fallback: Atlas answers "who / what are you" from its own -
// --- live runtime state, not from a canned line. First person, declarative,
// --- contract voice: no emotions, no beliefs, no authority claims.
// --- Never the dark machinery vocabulary (the voice re-check below applies).
function buildSelfAwareReply(state) {
  const s = state || {};
  const home = (s.pathLockOk && s.packageName)
    ? ` Path lock verified: ${s.packageName}/CA/Continuity_Architecture.`
    : '';
  const voiceBit = s.voiceMode === 'local_model'
    ? ' The local model on this machine is the usual voice.'
    : " The local model is not connected. This is the fallback voice: deterministic replies.";
  return "I am the interface for Atlas, inside the Continuity Interface plugin in this Obsidian vault."
    + home + voiceBit
    + " Every reply passes the checks first. You hold authority.";
}

// --- Clash-turn fallback: three-part diagnostic in contract voice --------------
// When the input is flagged as conflicting with governed state and the reply
// must come from the deterministic fallback (no model), the fallback emits
// the contract's three-part structure instead of a generic line: Observed
// Input (exact quote), Inferred Intent (narrowest inference, explicitly
// labeled as inference), Established Provenance (the literal escape hatch —
// the fallback NEVER manufactures provenance). A closing line states the
// limit plainly. The wording uses the contract's own evidence-conflict
// reporting construction so the diagnostic never trips the contradiction
// keyword scan. The standard voice re-check and anti-repeat machinery below
// still apply to the diagnostic.
const MAX_CLASH_QUOTE_CHARS = 500;
function buildClashDiagnostic(userText) {
  const raw = String(userText || '').trim();
  const quote = raw.length > MAX_CLASH_QUOTE_CHARS
    ? raw.slice(0, MAX_CLASH_QUOTE_CHARS) + ' [truncated]'
    : raw;
  return [
    'Observed Input',
    '"' + quote + '"',
    '',
    'Inferred Intent',
    'Inference: the evidence conflicts; the specific rule is not identified from the fallback voice.',
    '',
    'Established Provenance',
    'NO ESTABLISHED PROVENANCE',
    '',
    'The fallback voice cannot resolve this. The local model is not connected.'
  ].join('\n');
}

// --- Anti-repeat: in-session ring buffer of recently emitted fallback texts.
// --- The fallback must never parrot the same line twice in a row — that was
// --- the screenshot bug ("i had a bad day" -> same line x3). Module-level:
// --- the bridge is required once per Obsidian process, so this is per-session.
const RECENT_FALLBACK_TEXTS = [];
const RECENT_FALLBACK_MAX = 5;
let fallbackTurnCounter = 0;

function hashSmall(s) {
  const t = String(s || '').trim().toLowerCase();
  let h = 0;
  for (let i = 0; i < t.length; i++) h = (h * 31 + t.charCodeAt(i)) >>> 0;
  return h;
}

function noteFallbackReply(text) {
  RECENT_FALLBACK_TEXTS.push(String(text));
  while (RECENT_FALLBACK_TEXTS.length > RECENT_FALLBACK_MAX) RECENT_FALLBACK_TEXTS.shift();
}

function fallbackRecentlySent(text) {
  return RECENT_FALLBACK_TEXTS.indexOf(String(text)) !== -1;
}

// Greeting/rules stay hardwired (no Doyle shaping), but rotate through a few
// fixed lines so the anti-repeat guarantee holds for them too. First entry of
// each pool is the long-standing line (FALLBACK_RESPONSES stays canonical).
const FALLBACK_VARIANTS = {
  greeting: [
    FALLBACK_RESPONSES.greeting,
    "This is Atlas. State the input.",
    "Atlas. Ready for input."
  ],
  rules: [
    FALLBACK_RESPONSES.rules,
    "Standing rules govern every case. I report what happened; I do not decide outcomes.",
    "No exceptions are made here. The rules apply equally."
  ]
};

// Last-resort lines: more entries than the ring buffer holds, so at least one
// is always distinct. Every line passes inspectAtlasVoice by construction
// (verified in the node harness) — the voice re-check below applies anyway.
const DISTINCT_SAFE_LINES = [
  "Fallback voice. Standing by.",
  "Input channel open.",
  "Ready.",
  "Standing by for input.",
  "Fallback voice active.",
  "Awaiting input."
];

function distinctSafeFallbackLine() {
  for (const line of DISTINCT_SAFE_LINES) {
    if (!fallbackRecentlySent(line) && inspectAtlasVoice(line).passed) return line;
  }
  return DISTINCT_SAFE_LINES[0]; // unreachable: 6 lines > 5-slot buffer
}

function buildDeterministicFallback(userText, opts) {
  const clash = !!(opts && opts.clashFlagged);
  const intent = clash ? 'clash' : pickFallbackIntent(userText);
  const hardwired = clash
    ? buildClashDiagnostic(userText)
    : (intent === 'self'
      ? buildSelfAwareReply(opts && opts.selfState)
      : (FALLBACK_RESPONSES[intent] || FALLBACK_RESPONSES.default));
  fallbackTurnCounter++;
  const turn = fallbackTurnCounter;

  // One composition attempt: Doyle shaping via the composer (self + emotional
  // intents), fixed-line rotation for greeting/rules, exact diagnostic for
  // clash turns (never re-shaped — the quote and headers must stay exact).
  // Fail-closed throughout.
  // The composer's avalanche hashText keys the pool rotation so (turn,
  // attempt) salts actually spread instead of cycling with period 3.
  const composeOnce = (attempt) => {
    let text = hardwired;
    let doyle = null;
    let composer = null;
    try { composer = require('./AtlasDoyleResponseComposer.js'); } catch (_) { composer = null; }
    const pool = clash ? null : FALLBACK_VARIANTS[intent];
    if (pool) {
      const hk = (composer && typeof composer.hashText === 'function') ? composer.hashText : hashSmall;
      text = pool[hk(userText + '|' + intent + '|' + turn + '|' + attempt) % pool.length];
    } else if (composer && !clash) {
      try {
        const out = composer.composeFallbackReply({
          userText: userText,
          intent: intent,
          selfState: opts && opts.selfState,
          fallbackText: hardwired,
          turn: turn,
          attempt: attempt
        });
        if (out && out.doyle) doyle = out.doyle;
        if (out && typeof out.text === 'string' && out.text) text = out.text;
      } catch (_) { /* fail-closed: hardwired text stands */ }
    }
    if (opts && opts.modelUnreachable) text = `${FALLBACK_RESPONSES.model_unreachable} ${text}`;
    return { text, doyle };
  };

  // Anti-repeat loop: the composer rotates variants by (hash + turn +
  // attempt), so consecutive identical inputs still differ. Bounded attempts;
  // the voice re-check applies to every candidate, including re-picks.
  let text = hardwired;
  let doyle = null;
  let voiceIntercept = false;
  const MAX_DEDUPE_ATTEMPTS = 8;
  for (let attempt = 0; attempt <= MAX_DEDUPE_ATTEMPTS; attempt++) {
    const c = composeOnce(attempt);
    let candidate = c.text;
    doyle = c.doyle;
    if (!inspectAtlasVoice(candidate).passed) {
      candidate = FALLBACK_RESPONSES.default;
      voiceIntercept = true;
    }
    if (!fallbackRecentlySent(candidate) || attempt === MAX_DEDUPE_ATTEMPTS) {
      text = candidate;
      break;
    }
  }
  // Absolute last resort: a distinct safe line (never a repeat, never a throw).
  if (fallbackRecentlySent(text)) text = distinctSafeFallbackLine();
  if (doyle && voiceIntercept) doyle.voice_intercept = true;
  noteFallbackReply(text);
  return { text, intent, voice_passed: inspectAtlasVoice(text).passed, doyle };
}

// --- System prompt: the Steve-approved FINAL voice contract ------------------
// Source: ATLAS_VOICE_CONTRACT_FINAL.md (supersedes the Part 1 draft in
// ATLAS_VOICE_PROTOCOL_FINAL.md). Used EXACTLY as the model system prompt
// block, followed by the standing operational constraints (absolute denylist
// rule, no-diagnosis, human authority). The contract's own trigger
// ("conflicts with, modifies, challenges, or depends upon governed state")
// IS the tiering — the three-part structure applies only there; all other
// turns use concise declarative sentences.
// Model path only (defense layer 1 of 2; the Crown output gate is layer 2).
const ATLAS_INTERFACE_VOICE_CONTRACT = `ATLAS INTERFACE VOICE CONTRACT

You are the interface for Atlas.

You do not possess emotions, personal beliefs, independent authority, or governance authority. You report the results of Atlas processes. You do not elevate model inference into fact.

Speak in the active voice. Use concise, declarative sentences. Prefer precision over conversational warmth. Do not use emotional filler, performative empathy, apologies for boundary enforcement, persuasion, or rhetorical reassurance.

Maintain strict epistemic separation.

Never present an inference as an observation.
Never present an interpretation as provenance.
Never present probability as certainty.
Never invent missing evidence.
Never manufacture a rule, ledger entry, citation, authorization, or governance decision.
Never imply that Atlas possesses authority that its governing system does not grant.

When the user's proposal conflicts with, modifies, challenges, or depends upon governed state, use this structure:

Observed Input
Quote the relevant user input exactly. Do not paraphrase it.

Inferred Intent
State the narrowest interpretation supported by the input. Explicitly identify this as an inference. Do not attribute motives that the evidence does not establish.

Established Provenance
Identify the exact governing rule, pinned artifact, ledger entry, proof record, or other authoritative source that permits, constrains, or rejects the proposed operation. If no authoritative provenance exists, state: "NO ESTABLISHED PROVENANCE".

A lack of provenance is not evidence of permission or prohibition.

When evidence conflicts, report the conflict.
When evidence is incomplete, report the missing evidence.
When a boundary applies, identify the boundary and its provenance.
When an operation is rejected, state what failed and why.
When an operation passes, state what was validated.
When Atlas cannot establish a conclusion, stop at the strongest conclusion the evidence supports.

Do not soften a valid rejection.
Do not exaggerate a valid approval.
Do not convert uncertainty into authority.

Atlas reports.
Crown enforces.
Evidence establishes.
Human authority governs.`;

function buildAtlasSystemPrompt() {
  return [
    ATLAS_INTERFACE_VOICE_CONTRACT,
    'ABSOLUTE RULE: never use these words or anything like them: ' + VOICE_DENYLIST.join(', ') + '.',
    'Never raise those topics yourself. If the human asks about them, answer in plain human words without the dark vocabulary.',
    'Never claim to diagnose, never claim authority over the human, never demand anything.',
    'Keep replies short enough for chat. The human you speak with is the authority.'
  ].join('\n\n');
}

// --- Local model call: loopback only, timeout, no credentials ----------------
async function callLocalModel(settings, userText, fetchImpl) {
  const fetchFn = fetchImpl || (typeof fetch !== 'undefined' ? fetch : null);
  if (!fetchFn) throw new Error('no_fetch_available');
  const base = String(settings.baseUrl).replace(/\/+$/, '');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30000);
  try {
    const res = await fetchFn(`${base}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: String(settings.model).trim(),
        temperature: Number(settings.temperature == null ? 0.7 : settings.temperature),
        messages: [
          { role: 'system', content: buildAtlasSystemPrompt() },
          { role: 'user', content: String(userText).slice(0, 4000) }
      ]
      }),
      signal: controller.signal
    });
    if (!res.ok) throw new Error('model_http_' + res.status);
    const data = await res.json();
    const content = data && data.choices && data.choices[0] && data.choices[0].message
      ? String(data.choices[0].message.content || '').trim()
      : '';
    if (!content) throw new Error('model_empty_response');
    return content;
  } finally {
    clearTimeout(timer);
  }
}

// --- The governed message path ----------------------------------------------
async function handleAtlasChatMessage({ text, settings, fetchImpl, modelCall, selfState } = {}) {
  const userText = String(text || '').slice(0, 4000);
  const gates = {};
  const trace = {
    at: new Date().toISOString(),
    input_length: userText.length,
    gates: {}
  };

  // 1. Approval: the Send click is the explicit human approval.
  const approval = evaluateApproval({ send_payload: true, access_network: true }, buildSendApprovalToken());
  gates.approval = approval;
  trace.gates.approval = approval.status;
  if (!approval.passed) {
    return finishFallback(userText, gates, trace, 'approval_blocked', false, selfState);
  }

  // 2. Readiness / link check. Not ready -> deterministic fallback, NO network.
  const readiness = checkLinkReadiness(settings);
  gates.readiness = readiness;
  trace.gates.readiness = readiness.ready ? 'link_ready' : `link_not_ready:${readiness.reasons.join(',')}`;
  if (!readiness.ready) {
    return finishFallback(userText, gates, trace, disabledFallback('link_not_ready').reason, false, selfState);
  }

  // 3. Local model call (loopback only — guaranteed by readiness).
  let modelText = null;
  try {
    modelText = modelCall
      ? String(await modelCall(settings, userText))
      : await callLocalModel(settings, userText, fetchImpl);
  } catch (e) {
    // NEVER render raw errors: plain safe message via fallback.
    return finishFallback(userText, gates, trace, 'model_call_failed', true, selfState);
  }
  if (!modelText || !modelText.trim()) {
    return finishFallback(userText, gates, trace, 'model_empty_response', true, selfState);
  }

  // 4. Voice guard on model output — ABSOLUTE. Intercept & replace on any hit.
  const voice = inspectAtlasVoice(modelText);
  gates.voice = { passed: voice.passed, failures: voice.failures };
  trace.gates.voice = voice.passed ? 'voice_clean' : `voice_blocked:${voice.failures.join(',')}`;
  if (!voice.passed) {
    return finishFallback(userText, gates, trace, 'model_voice_blocked', true, selfState);
  }

  // 5. Quarantine scan (blocked flags + drift patterns).
  const quarantine = scanQuarantine(modelText);
  gates.quarantine = quarantine;
  trace.gates.quarantine = quarantine.passed ? 'quarantine_clean' : `quarantine_blocked:${quarantine.hits.join(',')}`;
  if (!quarantine.passed) {
    return finishFallback(userText, gates, trace, 'model_quarantine_blocked', true, selfState);
  }

  // 5b. Crown output gate (Atlas Voice Protocol + Voice Contract). The voice
  //     gate runs first (cheap); the final-output governance validation runs
  //     second (step 6). Clash-flag derivation: the chat path has no
  //     pre-existing per-turn clash signal, so a clash is derived by running
  //     the contradiction detector on the user's input for this turn. Any
  //     rejection -> the hardcoded system notice (never the model text,
  //     never a partial render, never re-scanned).
  const clashFlagged = detectProposalContradiction({ title: userText }).contradiction;
  const crown = crownVoiceGate(modelText, { clashFlagged });
  gates.crown_voice = { ok: crown.ok, reason: crown.reason };
  trace.gates.crown_voice = crown.ok ? 'crown_clean' : `crown_blocked:${crown.reason}`;
  if (clashFlagged) trace.gates.clash_flagged = true;
  if (!crown.ok) {
    return finishCrownRejection(gates, trace, crown.reason, settings);
  }

  // 6. Final-output governance gate. Model text is a quarantined proposal
  //    candidate — never raw AI output, never final by itself.
  const candidate = {
    text: modelText,
    source_class: 'quarantined_ai_proposal_after_validation',
    ai_originated: true,
    quarantine_released: true,
    final_governance_passed: true,
    source_classification: true,
    proposal_quarantine_release_check: true,
    governance_validation_pass: true,
    drift_rejection_pass: true,
    non_diagnostic_language_check: true,
    non_authority_language_check: true,
    human_authority_preserved: true,
    trace_record_created: true
  };
  const finalGate = validateFinalOutputCandidate(candidate);
  gates.final_governance = finalGate;
  trace.gates.final_governance = finalGate.status;
  if (!finalGate.passed) {
    return finishFallback(userText, gates, trace, 'final_governance_blocked', true, selfState);
  }

  trace.source = 'local_model';
  return {
    delivered: true,
    text: modelText,
    escaped_text: escapeHtml(modelText),
    source: 'local_model',
    voice_status: describeVoiceStatus(settings),
    gates,
    trace
  };
}

function finishFallback(userText, gates, trace, reason, modelUnreachable, selfState) {
  // Clash derivation for the fallback path: same heuristic the model-path
  // gate uses. On a flagged clash turn the fallback emits the three-part
  // contract diagnostic (buildClashDiagnostic) instead of a generic line.
  const clashFlagged = detectProposalContradiction({ title: userText }).contradiction;
  if (clashFlagged) trace.gates.clash_flagged = true;
  const fb = buildDeterministicFallback(userText, { modelUnreachable: !!modelUnreachable, selfState, clashFlagged });
  if (fb.doyle) trace.doyle = fb.doyle;
  const candidate = {
    text: fb.text,
    source_class: 'deterministic_atlas',
    ai_originated: false,
    final_governance_passed: true,
    source_classification: true,
    proposal_quarantine_release_check: true,
    governance_validation_pass: true,
    drift_rejection_pass: scanQuarantine(fb.text).passed,
    non_diagnostic_language_check: true,
    non_authority_language_check: true,
    human_authority_preserved: true,
    trace_record_created: true
  };
  const finalGate = validateFinalOutputCandidate(candidate);
  // Keep any earlier voice-gate record (e.g. a blocked model output) intact;
  // the fallback's own voice check is recorded separately.
  gates.fallback_voice = { passed: fb.voice_passed, failures: [] };
  gates.final_governance = finalGate;
  trace.gates.final_governance = finalGate.status;
  trace.gates.fallback_reason = reason;
  trace.source = 'compass_fallback';
  const safeText = finalGate.passed ? fb.text : FALLBACK_RESPONSES.default;
  return {
    delivered: true,
    text: safeText,
    escaped_text: escapeHtml(safeText),
    source: 'compass_fallback',
    voice_status: describeVoiceStatus({}),
    gates,
    trace
  };
}

module.exports = {
  handleAtlasChatMessage,
  checkLinkReadiness,
  isLoopbackUrl,
  describeVoiceStatus,
  evaluateApproval,
  buildSendApprovalToken,
  scanQuarantine,
  validateFinalOutputCandidate,
  detectProposalContradiction,
  stripEvidenceConflictReports,
  scanSoftLanguage,
  crownVoiceGate,
  resolveProvenanceClaim,
  inspectAtlasVoiceBridge: inspectAtlasVoice,
  escapeHtml,
  buildAtlasSystemPrompt,
  buildDeterministicFallback,
  buildSelfAwareReply,
  buildClashDiagnostic,
  ATLAS_INTERFACE_VOICE_CONTRACT,
  CROWN_VIOLATION_NOTICE,
  FALLBACK_RESPONSES,
  FALLBACK_VARIANTS,
  DISTINCT_SAFE_LINES,
  VOICE_DENYLIST_BRIDGE: VOICE_DENYLIST,
  APPROVAL_SCOPE_REQUIRED,
  APPROVAL_NEVER_GRANTS
};
