const { readJsonRegistry } = require("../../../runtime/backend/ObsidianRegistryReader.js");

const VARIATION_STYLE_REGISTRY_PATH = "CA/Continuity_Architecture/07 Atlas Response Construction/40 Obsidian Runtime Response Registry/variation_style_registry.md";

let cachedVariationRegistry = null;

function getVariationRegistry() {
  if (!cachedVariationRegistry) {
    cachedVariationRegistry = readJsonRegistry(VARIATION_STYLE_REGISTRY_PATH);
  }
  return cachedVariationRegistry;
}

function includesAll(source, required) {
  if (!Array.isArray(required) || required.length === 0) {
    return true;
  }
  return required.every((item) => source.includes(item));
}

function includesAny(source, required) {
  if (!Array.isArray(required) || required.length === 0) {
    return true;
  }
  return required.some((item) => source.includes(item));
}

function ruleMatches(rule, axes, patterns, returnMode) {
  const when = rule.when || {};

  if (!includesAll(axes, when.axesAll)) return false;
  if (!includesAny(axes, when.axesAny)) return false;
  if (!includesAll(patterns, when.patternsAll)) return false;
  if (!includesAny(patterns, when.patternsAny)) return false;

  if (Array.isArray(when.returnModesAny) && when.returnModesAny.length > 0) {
    return when.returnModesAny.includes(returnMode);
  }

  return true;
}

function normalizeVariation(variation, fallback) {
  return {
    seeStyle: variation && variation.seeStyle ? variation.seeStyle : fallback.seeStyle,
    separateStyle: variation && variation.separateStyle ? variation.separateStyle : fallback.separateStyle,
    returnStyle: variation && variation.returnStyle ? variation.returnStyle : fallback.returnStyle
  };
}

function chooseVariation(cognition, returnMode) {
  const registry = getVariationRegistry();
  const axes = Array.isArray(cognition.axes) ? cognition.axes : [];
  const patterns = Array.isArray(cognition.patterns) ? cognition.patterns : [];
  const fallback = registry.fallback || {
    seeStyle: "general_pressure",
    separateStyle: "general_separation",
    returnStyle: "general_return"
  };

  const rules = Array.isArray(registry.rules) ? [...registry.rules] : [];
  rules.sort((a, b) => (a.priority || 9999) - (b.priority || 9999));

  const matchedRule = rules.find((rule) => ruleMatches(rule, axes, patterns, returnMode));
  return normalizeVariation(matchedRule ? matchedRule.variation : fallback, fallback);
}

module.exports = { chooseVariation };
