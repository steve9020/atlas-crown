const assert=require('assert'); const {detectAxes}=require('../Cognition/engine/AxisEngine');
const cases=[
 {text:'He expected agreement, but she chose another option.',axis:'choice',actor:'she'},
 {text:'Maria chose to wait, while he intended to call.',axis:'intention',actor:'he'},
 {text:'We expected support, they chose another route.',axis:'choice',actor:'they'},
 {text:'They crossed our boundary, we accepted the consequence, and she intended to repair it.',axis:'intention',actor:'she'}
];
let pass=0; for(const c of cases){const r=detectAxes(c.text); const row=r.axis_evidence.find(x=>x.axis===c.axis); const ok=row&&row.attributions.some(a=>a.actor===c.actor); if(ok)pass++; else console.error('MISS',c,row&&row.attributions)} console.log(`AXOL reference neutral: ${pass}/${cases.length}`); assert.strictEqual(pass,cases.length);
