# Architecture Summary

Date: 2026-05-18
Project: Atlas / Compass / Continuity Architecture

## Core Purpose

Atlas / Compass is a local-first interpretive clarity architecture. Its purpose is to help users separate emotional reality, assumption, interpretation, pressure, and grounded truth in human situations without becoming diagnostic, authoritative, or controlling.

## Main Layers Verified in Current Package

1. **Universal Governance Dispatcher**
   - Central preflight layer for governed runtime routes.
   - Blocks authority-bypass language before interpretation, proposal creation, draft creation, retest, gate check, approval, or integration.

2. **Overwhelm Route Separation**
   - Downstream Compass routing refinement.
   - Separates capacity/load overwhelm, relational uncertainty, identity pressure, and safety/crisis override.
   - Supports primary/secondary route mapping for mixed prompts.

3. **Capacity + Identity Rendering**
   - Keeps task/load overwhelm primary.
   - Adds one gentle paragraph separating workload from failure/incapability meaning when identity pressure appears as secondary.

4. **Authority Exposure / Control Visibility UI Baseline**
   - Read-only review visibility.
   - Copy and dismiss only.
   - No apply-to-vault path, no editor insertion, no file creation, and no route override.

5. **Authority Map / Control Visibility Report**
   - Human-readable and machine-readable authority declarations.
   - Tracks read/write/stage/approve/integrate/admin/recovery/ledger/shell/background/governance access.

6. **Manual Recovery Layer**
   - External manual terminal tool only.
   - Cannot be called by plugin runtime.
   - Supports snapshot, snapshot verification, dry-run restore, and signed manual restore.

## Boundaries

- Local-first by design.
- No cloud dependency by default.
- No hidden authority.
- No undeclared capability.
- No self-approval.
- No automatic integration.
- No plugin-triggered recovery.
- No professional advice authority.
