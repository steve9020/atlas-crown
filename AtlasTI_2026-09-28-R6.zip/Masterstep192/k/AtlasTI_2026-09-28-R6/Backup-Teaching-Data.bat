@echo off
setlocal
title Back up Atlas teaching data

echo ======================================================
echo   BACK UP YOUR TEACHING DATA
echo ======================================================
echo.
echo   Run this BEFORE deleting or replacing your keeper.
echo   It zips your teaching data (queue, flyers, versions,
echo   audits) into a dated backup next to the keeper folder.
echo.
echo   Drag your keeper folder (AtlasTI_...) into this
echo   window, then press Enter.
echo.
set /p KEEPER=^> 
set KEEPER=%KEEPER:"=%
if "%KEEPER:~-1%"=="\" set KEEPER=%KEEPER:~0,-1%
if not exist "%KEEPER%\runtime\teaching" (
  echo.
  echo   That folder doesn't look like a keeper - no
  echo   runtime\teaching inside. Run it again and drag
  echo   the right folder.
  echo.
  pause
  exit /b 1
)
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set DT=%%I
if "%DT%"=="" set DT=00000000000000
set STAMP=%DT:~0,8%-%DT:~8,6%
set OUT=%KEEPER%\..\Teaching-Backup-%STAMP%.zip
tar -a -c -f "%OUT%" -C "%KEEPER%\runtime" teaching >nul 2>&1
if not exist "%OUT%" (
  echo.
  echo   Backup failed - nothing was written.
  echo.
  pause
  exit /b 1
)
echo.
echo ======================================================
echo   DONE. Your backup is here:
echo   %OUT%
echo.
echo   Keep that zip. If the keeper ever gets deleted
echo   again, that file has everything.
echo ======================================================
echo.
pause
