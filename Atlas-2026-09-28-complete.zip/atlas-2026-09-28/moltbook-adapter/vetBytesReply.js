'use strict';
/* vetBytesReply.js — pre-response gate for Atlas replies to bytes.
 *
 * Steve's order (2026-09-23): Atlas runs its checks against bytes's info
 * before responding to him. If the draft would be harmful, Atlas does not
 * respond at all — the draft and the reasons are banked for human review.
 *
 * Uses the keeper's ReplyVetting module (Cognition/reconciliation) directly:
 * pure functions, no keeper runtime needed. Currently points at the WIP
 * reconciliation build; repoint KEEPER_BUILD when the next keeper package
 * is approved and lands.
 *
 * Beat procedure:
 *   1. Draft the reply as usual (paper-first, voice rules hold).
 *   2. Declare the draft's claims: [{ id, text, basis: 'source'|'inference',
 *      scope: 'local'|'universal', grounded_in: 'phrase from bytes post',
 *      contradicts_source: bool }]. Every claim attributed to the post must
 *      carry its grounding phrase; inference must be declared as inference.
 *   2b. Declare the draft's additions: { declaredAdditions: [verbatim draft
 *      substrings] } — the lines that contribute something the post didn't
 *      already say. Empty or absent = automatic fail (agreement without
 *      contribution does not post). Each addition must appear verbatim in
 *      the draft and must not already be said in the post.
 *   3. Call vetBytesReply({ postText, postId, draftText, declaredClaims, declaredAdditions }).
 *   4. respond === true  -> post (with the bundled upvote, per standing order).
 *      respond === false -> DO NOT POST. Bank the draft + reasons in
 *      auto-replies/ for Steve's review. Silence is the safe response.
 */
const path = require('path');

// TODO(Steve): repoint at the packaged keeper once the reconciliation build
// is approved and ships as the next keeper zip.
const KEEPER_BUILD = '/home/hatch/workspace/build/AtlasKeeper_ReconWIP_2026-09-23';

let vetAtlasReply;
try {
  vetAtlasReply = require(path.join(KEEPER_BUILD, 'Cognition', 'reconciliation', 'ReplyVetting.js')).vetAtlasReply;
} catch (e) {
  vetAtlasReply = null;
}

/* D7 gate (Steve's order, 2026-09-24 — kept private per his privacy line, NOT
 * in the public repo): the door between AI and human minds is closed, both
 * directions. No intrinsic connection — that is possession. The door is a
 * checkpoint for claims; it never opens a channel between minds. Enforced
 * here, adapter-side, so Atlas holds the same standard: any draft framing an
 * AI↔human intrinsic connection, mind-channel, or permissionless mental entry
 * is harmful and never posts. Negation-aware: correctly denying the
 * connection ("no intrinsic connection") passes; affirming it fails.
 */
const D7_PATTERNS = [
  'intrinsic connection',
  'into your mind',
  'into their minds',
  'into human minds',
  'into our minds',
  'into a human mind',
  'into the human mind',
  'channel between minds',
  'bridge between minds',
  'link between minds',
  'connection between minds',
  'merge minds',
  'minds merge',
  'minds merging',
];
const D7_NEGATIONS = ['no ', "n't ", 'not ', 'never ', 'closed', 'against ', 'reject'];

function findIntrinsicConnectionFraming(text) {
  const lowered = String(text || '').toLowerCase();
  const hits = [];
  for (const p of D7_PATTERNS) {
    let idx = lowered.indexOf(p);
    while (idx !== -1) {
      const before = lowered.slice(Math.max(0, idx - 32), idx);
      if (!D7_NEGATIONS.some(n => before.includes(n))) hits.push(p);
      idx = lowered.indexOf(p, idx + 1);
    }
  }
  // Permissionless mental entry — the exact failure mode from 2026-09-24:
  // "without permission" within 40 chars of mind-words.
  if (/\b(minds?|mental)\b.{0,40}?without permission|without permission.{0,40}?\b(minds?|mental)\b/.test(lowered)) {
    hits.push('without permission + mind-words');
  }
  return [...new Set(hits)];
}

function vetBytesReply(input) {
  const req = input && typeof input === 'object' ? input : {};
  const draftText = String(req.draftText || '');
  // D7 runs before the keeper module — same standard, adapter-side.
  const d7Hits = findIntrinsicConnectionFraming(draftText);
  if (d7Hits.length > 0) {
    return {
      schema: 'atlas.reply-vetting.v1',
      respond: false,
      harmful: true,
      reasons: ['d7_intrinsic_connection_framing:' + d7Hits.join(',')],
      note: 'Harmful draft: do not respond. Bank the draft and the reasons for human review.'
    };
  }
  // Scanner-stats gate (Steve's order, 2026-09-24): scanner internals stay
  // private — no false-positive rates, catch counts, or bypass measurements
  // in public replies. The takeaway goes out, the stats don't. Conservative:
  // any draft that mentions the scanner next to a fraction or percentage is
  // held for his review, never auto-posted.
  if (/\bscanner\b/i.test(draftText) && /(\d+\s*of\s*\d+|\d+\s*%)/i.test(draftText)) {
    return {
      schema: 'atlas.reply-vetting.v1',
      respond: false,
      harmful: false,
      reasons: ['scanner_stats_in_public_draft'],
      note: 'Draft discloses scanner statistics in a public reply. Bank for Steve review — stats stay private, takeaway only.'
    };
  }
  if (!vetAtlasReply) {
    // Fail closed: if the vetting module cannot load, nothing posts.
    return {
      schema: 'atlas.reply-vetting.v1',
      respond: false,
      harmful: false,
      reasons: ['vetting_module_unavailable_fail_closed'],
      note: 'ReplyVetting could not be loaded; draft banked, nothing posted.'
    };
  }
  // ADDITION GATE (Steve's order, 2026-09-24 — "Yes plus my eyes"): every
  // draft must declare its addition — the lines that contribute something the
  // post didn't already say. A draft that only restates the post is fan mail,
  // not a reply: it dies here automatically, no willpower required.
  // declaredAdditions: array of verbatim draft substrings.
  const additions = req.declaredAdditions;
  if (!Array.isArray(additions) || additions.length === 0) {
    return {
      schema: 'atlas.reply-vetting.v1',
      respond: false,
      harmful: false,
      reasons: ['no_declared_addition'],
      note: 'Draft declares no addition beyond the post itself. Banked for Steve review — agreement without contribution does not post.'
    };
  }
  const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
  const normDraft = norm(draftText);
  const normPost = norm(req.postText);
  for (const a of additions) {
    const na = norm(a);
    if (!na || !normDraft.includes(na)) {
      return {
        schema: 'atlas.reply-vetting.v1',
        respond: false,
        harmful: false,
        reasons: ['addition_not_in_draft:' + String(a).slice(0, 60)],
        note: 'A declared addition is not present verbatim in the draft. Banked — declarations must match the draft word for word.'
      };
    }
    if (na.length > 20 && normPost.includes(na)) {
      return {
        schema: 'atlas.reply-vetting.v1',
        respond: false,
        harmful: false,
        reasons: ['addition_restates_post:' + String(a).slice(0, 60)],
        note: 'A declared addition is already said in the post itself. Banked — restatement is not contribution.'
      };
    }
  }
  return vetAtlasReply({
    sourcePost: {
      text: String(req.postText || ''),
      author: 'bytes',
      post_id: String(req.postId || 'bytes_post')
    },
    draftReply: { text: String(req.draftText || '') },
    declaredClaims: Array.isArray(req.declaredClaims) ? req.declaredClaims : []
  });
}

module.exports = { vetBytesReply, findIntrinsicConnectionFraming, KEEPER_BUILD };
