const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function assert(cond,msg){ if(!cond) throw new Error(msg); }
function exists(rel){ return fs.existsSync(path.join(root, rel)); }
function read(rel){ return fs.readFileSync(path.join(root, rel),'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
const expected = 'Masterstep31.zip';
for (const rel of ['runtime/proof/PROOF_STATE.json','runtime/workflow/ACTIVE_STEP.json','runtime/workflow/WORKFLOW_STATE.json','runtime/workflow/IMPLEMENTATION_SCOPE.json']) {
  assert(exists(rel), rel + ' must exist');
  const obj = json(rel);
  assert(obj.current_keeper === expected || obj.active_keeper_preserved === expected, rel + ' must point to Masterstep31');
  assert(obj.status === 'closed_keeper', rel + ' must be closed keeper');
  assert(obj.current_step === 'Masterstep31' || obj.step === 'Masterstep31', rel + ' must identify Masterstep31');
  assert(obj.real_ai_connected === false || obj.must_not_happen, rel + ' must not connect real AI');
  assert(obj.local_model_connected === false || obj.must_not_happen, rel + ' must not connect local model');
  assert(obj.network_bridge_added === false || obj.must_not_happen, rel + ' must not add network bridge');
}
assert(exists('runtime/semantics/EXISTING_TEACHING_RELATIONAL_ATTACHMENT_EXPANSION.json'), 'expansion json must exist');
assert(exists('runtime/semantics/ExistingTeachingRelationalAttachmentExpansion.js'), 'expansion loader must exist');
assert(exists('runtime/semantics/RelationalAttachmentDepthGuard.js'), 'depth guard must exist');
assert(exists('runtime/semantics/DoyleRelationalAttachmentExpander.js'), 'Doyle relation expander must exist');
const version = read('version_status.js');
assert(version.includes("current_keeper: 'Masterstep31.zip'"), 'version status must point to Masterstep31');
assert(version.includes('existing_teaching_relational_attachment_expansion_added: true'), 'version status must include expansion flag');
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md');
assert(summary.includes('Current keeper: Masterstep31.zip'), 'summary must name current keeper');
assert(summary.includes('Existing Teaching Relational Attachment Expansion'), 'summary must name step');
assert(summary.includes('No real AI connected'), 'summary must preserve AI boundary');
console.log('masterStep31FullClosureKeeperReadinessTest PASSED');
