const OVEREXPOSURE_PATTERNS = [
  {
    id: "full_depth_dump",
    pattern: /\bthis\s+reveals\s+the\s+full\s+depth\s+of\s+([^.!?]+)/gi,
    replacement: "there may be more under this, but it can be held one layer at a time"
  },
  {
    id: "too_much_too_soon",
    pattern: /\bthe\s+real\s+issue\s+is\s+that\s+you\s+([^.!?]+)/gi,
    replacement: "one possible layer here is that part of this may be asking for more care"
  },
  {
    id: "hidden_core_claim",
    pattern: /\bdeep\s+down,?\s+you\s+([^.!?]+)/gi,
    replacement: "there may be a deeper layer here, but it does not need to be forced open all at once"
  },
  {
    id: "too_deep_identity_read",
    pattern: /\byour\s+deepest\s+(fear|wound|issue|pattern)\s+is\s+([^.!?]+)/gi,
    replacement: "this may be touching something important, but it can be approached carefully instead of fully defined too quickly"
  },
  {
    id: "premature_life_story",
    pattern: /\bthis\s+goes\s+all\s+the\s+way\s+back\s+to\s+([^.!?]+)/gi,
    replacement: "this may connect to more than the present moment, but that connection does not need to be assumed before you are ready to look at it"
  },
  {
    id: "forced_total_depth",
    pattern: /\bwe\s+need\s+to\s+unpack\s+everything\s+about\s+([^.!?]+)/gi,
    replacement: "it may help to look at the next clear layer first"
  },
  {
    id: "complete_pattern_reveal",
    pattern: /\bthis\s+shows\s+your\s+entire\s+pattern\s+of\s+([^.!?]+)/gi,
    replacement: "this may show one movement worth noticing, without needing to define the whole of you"
  }
];

const DEEP_PACING_RISK_MARKERS = [
  /\bfull\s+depth\b/i,
  /\bthe\s+real\s+issue\s+is\s+that\s+you\b/i,
  /\bdeep\s+down,?\s+you\b/i,
  /\byour\s+deepest\s+(fear|wound|issue|pattern)\b/i,
  /\bgoes\s+all\s+the\s+way\s+back\b/i,
  /\bunpack\s+everything\b/i,
  /\bentire\s+pattern\b/i,
  /\bwhat\s+you\s+really\s+are\b/i,
  /\bthis\s+explains\s+everything\s+about\s+you\b/i
];

const PACED_DISCLOSURE_MARKERS = [
  /\bone\s+layer\s+at\s+a\s+time\b/i,
  /\bnext\s+clear\s+layer\b/i,
  /\bdoes\s+not\s+need\s+to\s+be\s+forced\s+open\b/i,
  /\bapproached\s+carefully\b/i,
  /\bwithout\s+needing\s+to\s+define\s+the\s+whole\b/i,
  /\bwhen\s+you\s+are\s+ready\b/i,
  /\bcan\s+be\s+held\s+carefully\b/i,
  /\bworth\s+noticing\b/i
];

const LIGHT_DISCLOSURE_INPUT = [
  /\bi\s+feel\s+(stupid|bad|weird|off|sad|angry|hurt)\b/i,
  /\bi\s+messed\s+up\b/i,
  /\bthey\s+ignored\s+me\b/i,
  /\bi\s+don'?t\s+know\b/i,
  /\bthis\s+felt\s+(bad|weird|heavy|off)\b/i
];

function detectDepthPacingRisk(response) {
  const text = typeof response === "string" ? response : "";
  return DEEP_PACING_RISK_MARKERS
    .map((pattern, index) => ({ pattern, index }))
    .filter(({ pattern }) => pattern.test(text))
    .map(({ index }) => [
      "full_depth_dump",
      "real_issue_identity_claim",
      "deep_down_claim",
      "deepest_wound_pattern_claim",
      "premature_past_origin_claim",
      "unpack_everything_pressure",
      "entire_pattern_claim",
      "what_you_really_are_claim",
      "explains_everything_about_you_claim"
    ][index]);
}

function inputSuggestsEarlyOrLightDisclosure(input) {
  const text = typeof input === "string" ? input : "";
  if (!text.trim()) return true;
  const wordCount = text.trim().split(/\s+/).filter(Boolean).length;
  return wordCount < 24 || LIGHT_DISCLOSURE_INPUT.some((pattern) => pattern.test(text));
}

function hasPacedDisclosureLanguage(response) {
  const text = typeof response === "string" ? response : "";
  return PACED_DISCLOSURE_MARKERS.some((pattern) => pattern.test(text));
}

function applyDepthPacingDisclosureSafety(response, input = "") {
  let output = typeof response === "string" ? response : "";
  const detectedBefore = detectDepthPacingRisk(output);
  const earlyDisclosure = inputSuggestsEarlyOrLightDisclosure(input);

  for (const item of OVEREXPOSURE_PATTERNS) {
    item.pattern.lastIndex = 0;
    output = output.replace(item.pattern, item.replacement);
  }

  output = output
    .replace(/\bwhat\s+you\s+really\s+are\b/gi, "what this may be touching")
    .replace(/\bthis\s+explains\s+everything\s+about\s+you\b/gi, "this may explain one part of what felt heavy")
    .replace(/\s{2,}/g, " ")
    .trim();

  const detectedAfter = detectDepthPacingRisk(output);
  const pacingLanguagePresent = hasPacedDisclosureLanguage(output) || detectedBefore.length > 0 || !earlyDisclosure;

  return {
    output,
    depth_pacing_disclosure_safety: {
      depth_pacing_disclosure_safety_active: true,
      depth_pacing_risk_detected: detectedBefore,
      depth_pacing_risk_remaining: detectedAfter,
      early_or_light_disclosure_detected: earlyDisclosure,
      full_depth_forced_open_blocked: detectedAfter.length === 0,
      disclosure_depth_paced_to_input: detectedAfter.length === 0,
      paced_disclosure_language_present: pacingLanguagePresent,
      overexposure_prevention_preserved: detectedAfter.length === 0,
      required_output_mode: "paced_depth_without_forcing_full_disclosure",
      guardrails: [
        "do_not_reflect_all_detected_depth",
        "pace_depth_to_user_wording_openness_and_context",
        "avoid_feeling_read_too_deeply_too_soon",
        "protect_disclosure_safety",
        "preserve_user_ownership_of_deeper_unfolding"
      ]
    }
  };
}

module.exports = {
  applyDepthPacingDisclosureSafety,
  detectDepthPacingRisk,
  inputSuggestsEarlyOrLightDisclosure,
  hasPacedDisclosureLanguage
};
