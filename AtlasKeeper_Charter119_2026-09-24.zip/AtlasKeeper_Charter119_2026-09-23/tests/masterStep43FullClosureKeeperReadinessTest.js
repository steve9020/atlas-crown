const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
function exists(p){ return fs.existsSync(path.join(root,p)); }

[
  'runtime/compass/COMPASS_RESPONSE_BUILDER_INTEGRATION.json',
  'runtime/compass/COMPASS_RESPONSE_BUILDER_INTEGRATION.md',
  'runtime/compass/CompassResponseBuilderIntegration.js',
  'runtime/compass/CompassResponseQualityGate.js',
  'runtime/proof/MASTERSTEP43_COMPASS_RESPONSE_BUILDER_INTEGRATION.json',
  'runtime/proof/MASTERSTEP43_COMPASS_RESPONSE_BUILDER_INTEGRATION.md',
  'runtime/proof/MASTERSTEP43_TEST_RESULTS.md',
  'docs/MASTERSTEP43_COMPASS_RESPONSE_BUILDER_INTEGRATION_MAP.md'
].forEach(p => assert.ok(exists(p), `missing ${p}`));

const state = JSON.parse(fs.readFileSync(path.join(root,'runtime/proof/PROOF_STATE.json'),'utf8'));
assert.ok(['Masterstep43.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 43), state.current_keeper);
assert.strictEqual(state.current_step, 'Masterstep43');
assert.strictEqual(state.status, 'closed_keeper');
assert.strictEqual(state.compass_response_builder_integration_added, true);
assert.strictEqual(state.response_builder_ai_free, true);
assert.strictEqual(state.real_ai_connected, false);
assert.strictEqual(state.local_model_connected, false);
assert.strictEqual(state.network_bridge_added, false);
assert.strictEqual(state.frontend_intelligence_added, false);

const active = JSON.parse(fs.readFileSync(path.join(root,'runtime/workflow/ACTIVE_STEP.json'),'utf8'));
assert.strictEqual(active.current_keeper, 'Masterstep43.zip');
assert.strictEqual(active.current_step, 'Masterstep43');

const version = require('../version_status.js');
assert.strictEqual(version.current_keeper, 'Masterstep43.zip');
assert.strictEqual(version.current_step, 'Masterstep43');
assert.strictEqual(version.real_ai_connected, false);
assert.strictEqual(version.network_bridge_added, false);

console.log('masterStep43FullClosureKeeperReadinessTest PASSED');
