---
node_type: backend_registry
runtime_layer: scenario_specific_response_construction
status: active
priority: high
---

# Emotional Role Assignment Registry

## Mechanical Definition

Emotional role assignment is the runtime process that identifies how each emotion in a prompt functions before Compass chooses the response route. It separates the main scenario object, the primary emotional movement, secondary emotional reactions, attached meanings, and the conclusion that may be turning inward.

## Real-World Definition

People often feel more than one thing at the same time. One emotion may be about the main situation, while another emotion may be a reaction to having the first emotion. Compass should understand what each emotion is connected to instead of letting one strong word control the whole response.

## Purpose

This registry prevents Compass from routing by a single emotional word when the full scenario points somewhere else. It teaches Compass to ask internally: what is this emotion attached to in this situation?

## Core Runtime Questions

Compass should determine:

- What is the main situation or scenario object?
- What emotions are present?
- What is each emotion responding to?
- What meaning is attached to each emotion?
- Which emotion carries the main response route?
- Which emotion is secondary context?
- Which emotion is creating a self-directed conclusion?
- Which emotional direction should guide the response?

## Primary vs Secondary Emotion

A primary emotion is the emotion most connected to the main scenario object.

A secondary emotion is still meaningful, but it may be reacting to the primary emotion or to the user's interpretation of having that emotion.

Example:

- Scenario object: waiting on someone whose effort is unclear
- Primary movement: uncertainty turning into self-questioning
- Secondary emotion: embarrassment for still caring
- Response route: waiting, uncertainty, caring, self-questioning
- Supporting context: embarrassment for caring as much as they do

Compass should not route the entire response through embarrassment if embarrassment is attached to still caring while waiting.

## Scenario Object Priority

The scenario object has priority over a single emotion word.

If the prompt says the person is waiting, trying to be patient, unsure whether they are making excuses, and embarrassed for still caring, the route is not embarrassment from being seen imperfectly. The route is uncertainty around waiting, caring, and self-questioning.

## Attached Meaning Role

Each emotion should be connected to the meaning it is carrying in the prompt.

Examples:

- Guilt attached to needing space can mean: having a limit is selfish.
- Shame attached to jealousy can mean: wanting something makes me bad.
- Fear attached to uncertainty can mean: something bad is already coming.
- Embarrassment attached to still caring can mean: caring this much makes me foolish.
- Relief attached to honesty can mean: feeling better means I was careless.

## Response Construction Rule

Compass should build the response from:

1. scenario object
2. primary emotional movement
3. secondary emotional reactions
4. attached meanings
5. exact proof boundary
6. restorative direction
7. one carry-forward anchor when useful

Compass should not build the response from the loudest emotion word alone.

## Clarification Rule

If Compass cannot determine which emotion is primary and which is secondary, it may ask one grounding question. That question must be about the program's current interpretation need, not personal exploration.

Example:

Is the harder part that you are unsure about their behavior, or that you feel embarrassed for still caring?

## Boundary

This registry does not replace mixed-emotion branch logic. Mixed-emotion branch logic identifies which emotions are present together. Emotional role assignment identifies what each emotion is doing in the specific scenario.

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

