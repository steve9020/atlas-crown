# Auto Teaching Proposal Generation

## Purpose
Converts auto teaching evaluation findings into complete Atlas proposals.

## Required Proposal Contents
- source prompt
- Compass response
- failure pattern
- why it failed
- suggested correction
- target backend file
- integration draft
- status

## Rule
If any required field is missing, do not store or review the proposal.
