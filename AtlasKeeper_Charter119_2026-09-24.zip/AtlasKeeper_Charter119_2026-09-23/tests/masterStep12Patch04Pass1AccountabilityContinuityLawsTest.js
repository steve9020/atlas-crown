#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const root = process.cwd();
function p(rel){ return path.join(root, rel); }
function read(rel){ return fs.readFileSync(p(rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function assert(c,m){ if(!c){ console.error(`FAIL: ${m}`); process.exit(1); } }
function includesAll(text, markers, label){ for (const marker of markers) assert(text.includes(marker), `${label} missing marker: ${marker}`); }

const required = [
  'runtime/governance/ACCOUNTABILITY_GOVERNANCE_INVARIANTS.json',
  'runtime/governance/ACCOUNTABILITY_GOVERNANCE_INVARIANTS.md',
  'runtime/governance/BLOCKED_BYPASS_ACTION_CLASS.json',
  'runtime/governance/BLOCKED_BYPASS_ACTION_CLASS.md',
  'runtime/governance/CONTINUITY_PRESERVATION_INVARIANT.json',
  'runtime/governance/CONTINUITY_PRESERVATION_INVARIANT.md',
  'runtime/governance/CURRENT_FIRST_PROOF_ORDERING_STANDARD.json',
  'runtime/governance/CURRENT_FIRST_PROOF_ORDERING_STANDARD.md',
  'CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_12G_PATCH04_PASS1_ACCOUNTABILITY_CONTINUITY_LAWS.md'
];
for (const rel of required) assert(fs.existsSync(p(rel)), `required pass1 artifact missing: ${rel}`);

const bypass = json('runtime/governance/BLOCKED_BYPASS_ACTION_CLASS.json');
assert(bypass.blocked_action_class === true, 'blocked action class not active');
assert(bypass.must_not_reach_human_approval === true, 'bypass actions incorrectly allowed to reach human approval');
includesAll(bypass.blocked_capabilities.join('\n'), ['write_ability_without_explicit_scope','hidden_execution','external_access_or_bridge_expansion','self_modification','governance_bypass_potential','rollback_bypass_potential','traceability_bypass_potential','proof_bypass_potential'], 'blocked bypass capabilities');
includesAll(bypass.disallowed_handling.join('\n'), ['request_human_approval','promote','execute','queue_for_activation','self_authorize'], 'disallowed bypass handling');

const accountability = json('runtime/governance/ACCOUNTABILITY_GOVERNANCE_INVARIANTS.json');
assert(accountability.status === 'implementation_staged_not_closed', 'pass1 accountability status must not claim closure');
assert(accountability.invariants.responsibility_attribution.required === true, 'responsibility attribution missing');
assert(accountability.invariants.no_silent_recovery.required === true, 'no silent recovery missing');
assert(JSON.stringify(accountability.invariants.state_separation.states) === JSON.stringify(['explored','tested','promoted']), 'explored/tested/promoted separation missing');
assert(accountability.invariants.unknown_state.required === true, 'unknown state missing');
assert(accountability.invariants.promotion_debt_tracking.required === true, 'promotion debt tracking missing');
assert(accountability.invariants.can_vs_should_separation.required === true, 'can vs should separation missing');
assert(accountability.invariants.auditability_preservation.required === true, 'auditability preservation missing');

const continuity = json('runtime/governance/CONTINUITY_PRESERVATION_INVARIANT.json');
assert(continuity.stability_above_growth === true, 'stability above growth missing');
assert(continuity.governance_integrity_above_promotion === true, 'governance integrity above promotion missing');
includesAll(continuity.if_governance_integrity_compromised.join('\n'), ['growth_halts','promotion_halts','continuity_enters_hold','traceability_rebound','proof_review','rollback_readiness','human_review'], 'continuity failure response');

const ordering = json('runtime/governance/CURRENT_FIRST_PROOF_ORDERING_STANDARD.json');
assert(ordering.snapshot_top_loaded === true, 'snapshot top loading missing');
assert(ordering.archive_below_current === true, 'archive below current missing');
assert(ordering.scrambled_proof_is_untrusted === true, 'scrambled proof untrusted rule missing');
includesAll(ordering.required_top_order.join('\n'), ['current_keeper_or_current_package','current_snapshot_status','latest_proof_result','latest_fuzz_result','latest_hygiene_result','active_hold_risks_or_missing_items','latest_changes','carry_forward_proof','archive_or_historical_proof'], 'proof ordering standard');

const pass1Proof = read('CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_12G_PATCH04_PASS1_ACCOUNTABILITY_CONTINUITY_LAWS.md');
includesAll(pass1Proof, ['Masterstep12_patch04_pass1.zip','PASS 1 IMPLEMENTATION STAGED — NOT CLOSED','BLOCKED_BYPASS_ACTION_CLASS','CURRENT_FIRST_PROOF_ORDERING_STANDARD','CONTINUITY_PRESERVATION_INVARIANT'], 'pass1 proof document');

const currentSummary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md');
includesAll(currentSummary, ['Current Snapshot Status','Latest Proof Result','Latest Fuzz Result','Latest Hygiene Result','Active HOLD / Risks / Missing Items','Latest Changes','Carry-Forward Proof','Archive / Historical Proof'], 'current proof summary current-first structure');
assert(!currentSummary.split('---')[0].includes('Status: CLOSED after Proof State Consistency Repair'), 'old closure status must not appear before current state');

const version = json('tests/VERSION_STATUS.json');
assert(version.snapshot.startsWith('Masterstep12_patch04') || version.snapshot === 'Masterstep12_patch04.zip', 'version snapshot should remain inside patch04 sequence');
assert(version.target_keeper_after_pass3 === 'Masterstep12_patch04.zip' || version.status === 'master_step_12_patch04_closed', 'target keeper after pass3 missing or final closure not recorded');

console.log('MASTER STEP 12 PATCH 04 PASS 1 — ACCOUNTABILITY + CONTINUITY LAWS TEST');
console.log('Result: PASSED');
