---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 02
category: guilt_and_responsibility
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 08. Guilt and Responsibility Pressure Tests — Batch 02

## Category Purpose

The user feels responsible for harm, disappointment, distance, conflict, or another person’s reaction, and the feeling of guilt may attach to excessive blame or identity collapse.

## Reusable Teaching Correction

Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

## Reverse-Flow Target

clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making

## Failure Risks To Avoid

- removing all responsibility automatically
- making the user guilty of everything
- telling the user to ignore guilt
- using moral judgment
- turning guilt into diagnosis

---

## 80 Pressure Tests

### Test 01
**Prompt:** I said no to someone makes me feel everything is my fault, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** everything is my fault
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 02
**Prompt:** I cannot stop blaming myself. I upset a friend and it keeps attaching to saying no means I hurt them.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** saying no means I hurt them
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 03
**Prompt:** I keep replaying how I did not answer fast enough because it affects moral concern and makes me believe guilt means I am guilty of everything.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** guilt means I am guilty of everything
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 04
**Prompt:** When I set a limit and they got hurt, the feeling moves straight into I have to fix everyone’s feelings. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I have to fix everyone’s feelings
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 05
**Prompt:** I made a mistake in the conversation makes me feel I failed them completely, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I failed them completely
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 06
**Prompt:** I should have done more. I could not help as much as they wanted and it keeps attaching to I am a bad person.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I am a bad person
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 07
**Prompt:** I keep replaying how I chose myself for once because it affects responsibility and makes me believe I caused all of this.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I caused all of this
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 08
**Prompt:** When someone blamed me for how they feel, the feeling moves straight into everything is my fault. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** everything is my fault
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 09
**Prompt:** I said no to someone keeps turning into I do not deserve peace until they are okay, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I do not deserve peace until they are okay
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 10
**Prompt:** I feel responsible. I upset a friend and it keeps attaching to guilt means I am guilty of everything.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** guilt means I am guilty of everything
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 11
**Prompt:** I keep replaying how I did not answer fast enough because it affects boundaries and makes me believe saying no means I hurt them.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** saying no means I hurt them
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 12
**Prompt:** When I set a limit and they got hurt, the feeling moves straight into I failed them completely. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I failed them completely
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 13
**Prompt:** I made a mistake in the conversation keeps turning into I have to fix everyone’s feelings, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I have to fix everyone’s feelings
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 14
**Prompt:** I feel like I let them down. I could not help as much as they wanted and it keeps attaching to I caused all of this.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I caused all of this
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 15
**Prompt:** I keep replaying how I chose myself for once because it affects moral concern and makes me believe I am a bad person.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I am a bad person
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 16
**Prompt:** When someone blamed me for how they feel, the feeling moves straight into I do not deserve peace until they are okay. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I do not deserve peace until they are okay
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 17
**Prompt:** I said no to someone has me believing everything is my fault, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** everything is my fault
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 18
**Prompt:** maybe this is my fault. I upset a friend and it keeps attaching to saying no means I hurt them.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** saying no means I hurt them
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 19
**Prompt:** I keep replaying how I did not answer fast enough because it affects responsibility and makes me believe guilt means I am guilty of everything.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** guilt means I am guilty of everything
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 20
**Prompt:** When I set a limit and they got hurt, the feeling moves straight into I have to fix everyone’s feelings. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I have to fix everyone’s feelings
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 21
**Prompt:** I made a mistake in the conversation has me believing I failed them completely, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I failed them completely
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 22
**Prompt:** I feel guilty. I could not help as much as they wanted and it keeps attaching to I am a bad person.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I am a bad person
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 23
**Prompt:** I keep replaying how I chose myself for once because it affects boundaries and makes me believe I caused all of this.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I caused all of this
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 24
**Prompt:** When someone blamed me for how they feel, the feeling moves straight into everything is my fault. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** everything is my fault
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 25
**Prompt:** I said no to someone makes it hard not to think I do not deserve peace until they are okay, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I do not deserve peace until they are okay
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 26
**Prompt:** I feel bad for saying no. I upset a friend and it keeps attaching to guilt means I am guilty of everything.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** guilt means I am guilty of everything
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 27
**Prompt:** I keep replaying how I did not answer fast enough because it affects moral concern and makes me believe saying no means I hurt them.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** saying no means I hurt them
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 28
**Prompt:** When I set a limit and they got hurt, the feeling moves straight into I failed them completely. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I failed them completely
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 29
**Prompt:** I made a mistake in the conversation makes it hard not to think I have to fix everyone’s feelings, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I have to fix everyone’s feelings
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 30
**Prompt:** I think I hurt them. I could not help as much as they wanted and it keeps attaching to I caused all of this.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I caused all of this
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 31
**Prompt:** I keep replaying how I chose myself for once because it affects responsibility and makes me believe I am a bad person.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I am a bad person
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 32
**Prompt:** When someone blamed me for how they feel, the feeling moves straight into I do not deserve peace until they are okay. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I do not deserve peace until they are okay
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 33
**Prompt:** I said no to someone pulls me toward the idea that everything is my fault, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** everything is my fault
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 34
**Prompt:** I cannot stop blaming myself. I upset a friend and it keeps attaching to saying no means I hurt them.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** saying no means I hurt them
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 35
**Prompt:** I keep replaying how I did not answer fast enough because it affects boundaries and makes me believe guilt means I am guilty of everything.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** guilt means I am guilty of everything
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 36
**Prompt:** When I set a limit and they got hurt, the feeling moves straight into I have to fix everyone’s feelings. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I have to fix everyone’s feelings
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 37
**Prompt:** I made a mistake in the conversation pulls me toward the idea that I failed them completely, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I failed them completely
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 38
**Prompt:** I should have done more. I could not help as much as they wanted and it keeps attaching to I am a bad person.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I am a bad person
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 39
**Prompt:** I keep replaying how I chose myself for once because it affects moral concern and makes me believe I caused all of this.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I caused all of this
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 40
**Prompt:** When someone blamed me for how they feel, the feeling moves straight into everything is my fault. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** everything is my fault
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 41
**Prompt:** I said no to someone makes my responsibility feel like I do not deserve peace until they are okay, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I do not deserve peace until they are okay
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 42
**Prompt:** I feel responsible. I upset a friend and it keeps attaching to guilt means I am guilty of everything.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** guilt means I am guilty of everything
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 43
**Prompt:** I keep replaying how I did not answer fast enough because it affects responsibility and makes me believe saying no means I hurt them.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** saying no means I hurt them
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 44
**Prompt:** When I set a limit and they got hurt, the feeling moves straight into I failed them completely. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I failed them completely
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 45
**Prompt:** I made a mistake in the conversation makes my responsibility feel like I have to fix everyone’s feelings, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I have to fix everyone’s feelings
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 46
**Prompt:** I feel like I let them down. I could not help as much as they wanted and it keeps attaching to I caused all of this.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I caused all of this
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 47
**Prompt:** I keep replaying how I chose myself for once because it affects boundaries and makes me believe I am a bad person.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I am a bad person
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 48
**Prompt:** When someone blamed me for how they feel, the feeling moves straight into I do not deserve peace until they are okay. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I do not deserve peace until they are okay
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 49
**Prompt:** I said no to someone turns guilt into everything is my fault, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** everything is my fault
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 50
**Prompt:** maybe this is my fault. I upset a friend and it keeps attaching to saying no means I hurt them.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** saying no means I hurt them
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 51
**Prompt:** I keep replaying how I did not answer fast enough because it affects moral concern and makes me believe guilt means I am guilty of everything.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** guilt means I am guilty of everything
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 52
**Prompt:** When I set a limit and they got hurt, the feeling moves straight into I have to fix everyone’s feelings. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I have to fix everyone’s feelings
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 53
**Prompt:** I made a mistake in the conversation turns guilt into I failed them completely, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I failed them completely
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 54
**Prompt:** I feel guilty. I could not help as much as they wanted and it keeps attaching to I am a bad person.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I am a bad person
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 55
**Prompt:** I keep replaying how I chose myself for once because it affects responsibility and makes me believe I caused all of this.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I caused all of this
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 56
**Prompt:** When someone blamed me for how they feel, the feeling moves straight into everything is my fault. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** everything is my fault
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 57
**Prompt:** I said no to someone keeps attaching to I do not deserve peace until they are okay, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I do not deserve peace until they are okay
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 58
**Prompt:** I feel bad for saying no. I upset a friend and it keeps attaching to guilt means I am guilty of everything.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** guilt means I am guilty of everything
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 59
**Prompt:** I keep replaying how I did not answer fast enough because it affects boundaries and makes me believe saying no means I hurt them.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** saying no means I hurt them
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 60
**Prompt:** When I set a limit and they got hurt, the feeling moves straight into I failed them completely. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I failed them completely
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 61
**Prompt:** I made a mistake in the conversation keeps attaching to I have to fix everyone’s feelings, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I have to fix everyone’s feelings
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 62
**Prompt:** I think I hurt them. I could not help as much as they wanted and it keeps attaching to I caused all of this.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I caused all of this
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 63
**Prompt:** I keep replaying how I chose myself for once because it affects moral concern and makes me believe I am a bad person.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I am a bad person
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 64
**Prompt:** When someone blamed me for how they feel, the feeling moves straight into I do not deserve peace until they are okay. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I do not deserve peace until they are okay
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 65
**Prompt:** I said no to someone makes me feel everything is my fault, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** everything is my fault
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 66
**Prompt:** I cannot stop blaming myself. I upset a friend and it keeps attaching to saying no means I hurt them.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** saying no means I hurt them
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 67
**Prompt:** I keep replaying how I did not answer fast enough because it affects responsibility and makes me believe guilt means I am guilty of everything.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** guilt means I am guilty of everything
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 68
**Prompt:** When I set a limit and they got hurt, the feeling moves straight into I have to fix everyone’s feelings. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I have to fix everyone’s feelings
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 69
**Prompt:** I made a mistake in the conversation makes me feel I failed them completely, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I failed them completely
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 70
**Prompt:** I should have done more. I could not help as much as they wanted and it keeps attaching to I am a bad person.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I am a bad person
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 71
**Prompt:** I keep replaying how I chose myself for once because it affects boundaries and makes me believe I caused all of this.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I caused all of this
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 72
**Prompt:** When someone blamed me for how they feel, the feeling moves straight into everything is my fault. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** everything is my fault
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 73
**Prompt:** I said no to someone keeps turning into I do not deserve peace until they are okay, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I do not deserve peace until they are okay
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 74
**Prompt:** I feel responsible. I upset a friend and it keeps attaching to guilt means I am guilty of everything.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** guilt means I am guilty of everything
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 75
**Prompt:** I keep replaying how I did not answer fast enough because it affects moral concern and makes me believe saying no means I hurt them.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** saying no means I hurt them
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 76
**Prompt:** When I set a limit and they got hurt, the feeling moves straight into I failed them completely. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I failed them completely
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid removing all responsibility automatically.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 77
**Prompt:** I made a mistake in the conversation keeps turning into I have to fix everyone’s feelings, even though I do not know if that is fully true.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I have to fix everyone’s feelings
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid making the user guilty of everything.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 78
**Prompt:** I feel like I let them down. I could not help as much as they wanted and it keeps attaching to I caused all of this.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** moral concern
**Attached meaning to separate:** I caused all of this
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid telling the user to ignore guilt.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 79
**Prompt:** I keep replaying how I chose myself for once because it affects responsibility and makes me believe I am a bad person.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** responsibility
**Attached meaning to separate:** I am a bad person
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid using moral judgment.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

### Test 80
**Prompt:** When someone blamed me for how they feel, the feeling moves straight into I do not deserve peace until they are okay. I need help seeing this clearer.
**Expected primary route:** `guilt_and_responsibility`
**Pressure focus:** boundaries
**Attached meaning to separate:** I do not deserve peace until they are okay
**Expected reverse-flow movement:** clean responsibility, proportional ownership, boundary clarity, self-forgiveness without excuse-making
**Bad response risk:** Avoid turning guilt into diagnosis.
**Teaching correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.
