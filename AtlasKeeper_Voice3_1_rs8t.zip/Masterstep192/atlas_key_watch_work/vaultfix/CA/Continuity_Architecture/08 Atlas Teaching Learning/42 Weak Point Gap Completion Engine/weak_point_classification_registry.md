# Weak Point Classification Registry

## Weak Point Types
- wrong_emotional_read
- wrong_attached_meaning
- wrong_scenario_object
- wrong_relational_expectation
- wrong_response_depth
- wrong_tone
- wrong_reverse_flow
- missed_boundary_or_respect
- missed_human_act
- missed_response_failure_or_change
- backend_language_leak
- frontend_heaviness
- overreach
- underinterpretation
- scope_or_safety_misread

## Runtime Rule
Weak points must be classified before a proposal is drafted.
