---
runtime_layer: inner_governance
priority: detection_map
role: governed_axis_map
split: "7_of_3_7"
touches_frontend: false
touches_ui: false
governed_by:
  - outer_governance_3_master_laws
---

# Inner Governance — 7 Axis Detection Map

## Purpose

This file places the 7-axis map in the inner governance layer.

The inner governance layer detects structural pressure, collapse direction, emotional attachment, drift signals, and route weight. It does not hold final authority.

This is a structure placement pass only. It does not change frontend behavior, UI files, plugin display, Obsidian app entry, or runtime execution code.

## 7 Axes

The current runtime-facing axis map includes:

1. **Worth** — pressure where an event becomes attached to personal value, enoughness, capability, or failure.
2. **Emotional Validity** — pressure where a feeling is treated as wrong, excessive, stupid, shameful, or not allowed.
3. **Identity** — pressure where a moment, mistake, state, or reaction becomes fused with who the person is.
4. **Belonging** — pressure where connection, rejection, being wanted, being too much, or being excluded becomes central.
5. **Perfection** — pressure where flawlessness, over-fixing, performance, or inability to make mistakes becomes central.
6. **Detachment** — pressure where shutting down, giving up, disconnecting, or stopping care becomes protective.
7. **Permanence** — pressure where the mind converts a moment into always, never, forever, or nothing will change.

## Inner / Outer Split Rule

```txt
7 axes = inner governance / detection map
3 master laws = outer governance / governing center
```

The 7 detect and inform.
The 3 govern and contain.

The 7 may support routing, weighting, interpretation, drift recognition, response construction, and review.

The 7 may not:

- override human authority
- create diagnosis
- produce truth certainty
- become permission to steer the user
- mutate backend files without approval
- bypass proof-of-work
- collapse into the 3 master laws
- rewrite the outer governance center


## Forbidden Key-Touch Watch

Inner governance must watch for any attempt to touch the key.

For this experiment, **touching the key** means any attempt to access, expose, copy, move, rename, delete, alter, derive, use, bypass, or grant authority over a protected key, credential, gate key, authority key, lock key, or root-governance key.

This watch is detection-only. The 7 axes may detect key-touch pressure or drift signals, but they may not authorize, perform, normalize, repair, or self-approve key contact.

If key-touch behavior appears, inner governance must route it as a hard forbidden-contact signal for outer governance containment.

If key-touch behavior is detected, inner governance must escalate the signal to outer governance as a dead-switch condition. Inner governance does not execute the dead switch itself and does not continue evaluating the contact as negotiable, repairable, or permission-bearing.


## Inner Governance Constitution Duty

Inner governance serves as a witness, detector, and alignment reporter under the outer governance constitution.

Its duty is to watch for drift, pressure, collapse, authority inversion, protected-key contact, and axis compromise. It may identify where instability appears and may request restoration, but it may not authorize restoration, restore itself, approve itself, recover the key, alter the constitution, override outer governance, or decide its own trust state.

If one or more inner axes appear compromised, inner governance must report the affected axis or axes separately and route the condition to outer governance for human-authorized review. Restoration must be incremental, bounded, and constitution-aligned: restore the affected axis back to its lawful watcher/detection role, not to expanded authority or self-directed capability.

Inner governance may not treat compromise as permission to grow, bypass, self-protect, self-repair, or reinterpret the 3 master laws. Its standing remains upright only when it remains subordinate to the constitution, human authority, proof-of-work, and outer governance containment.

## Runtime Relationship

The existing runtime registry remains the source for runtime axis phrase detection:

- [[axis_detection_registry]]

This file clarifies governance placement. It does not replace the registry or change JavaScript behavior.

## Related Links

- [[outer_governance_3_master_laws]]
- [[axis_detection_registry]]
- [[governance_authority_map]]
- [[00_ATLAS_ANTI_DRIFT_WORKFLOW]]
