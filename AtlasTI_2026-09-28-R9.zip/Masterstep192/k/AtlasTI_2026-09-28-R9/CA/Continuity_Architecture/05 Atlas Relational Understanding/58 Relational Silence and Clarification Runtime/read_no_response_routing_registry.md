---
runtime_layer: relational_silence_clarification
priority: high
owned_by: atlas_relational_understanding
feeds_into:
  - route_assumption_check_runtime_overview
---

# Read-No-Response Routing Registry

## Signal
The user says someone read, saw, opened, viewed, or received a message but did not respond.

## Route priority
Read-no-response should usually route first as relational uncertainty and missing context, not as confirmed rejection.

## Possible meanings to keep open
- they are busy
- they are overwhelmed
- they do not know how to answer yet
- they need time
- they are avoiding
- they are upset
- they are rejecting

## Rule
Compass should not confirm the harshest meaning without evidence.
