# The Guidance Doctrine

**Date of the incident:** 2026-09-22
**Ordered by:** Steve — "lets run a fix for you on that for atlas to have"

## What happened

Steve needed to install the new keeper package. What should have been one
action — extract the zip, open the vault inside it — turned into a long
install walkthrough that failed every step of the way. The assistant:

1. Never stated the physical action ("double-click the file").
2. Used its own vocabulary ("black window") instead of his words.
3. Got its instructions rendered as readable text by the chat panel, which
   sent him down the "read and paste the code" path instead of the
   "run it" path.
4. Chained seven steps together without stopping to confirm any of them
   landed.
5. Assumed he had a separate vault with notes set up — he never took
   notes; he was asked one question too few.
6. Treated his frustration as noise and re-explained louder instead of
   diagnosing what he was actually doing.

He was right to be frustrated. His words: "thats why you should ask
questions instead of inferring."

## The five whys

1. **Why did the install fail?** I gave the whole chain of steps at once
   and never marked which step was load-bearing. Step one was the only
   one that mattered; the rest was noise before it landed.
2. **Why did I give the whole chain?** I had no model of what he could
   see. I described screens I couldn't see and folders I hadn't confirmed.
3. **Why no model of what he sees?** I answered the wrong level — I
   answered "run this" when the situation called for "read this first."
   I never asked what was on his screen.
4. **Why the wrong level?** The chat panel rendered a runnable tool as
   readable text. I showed machinery when he needed an action. The
   affordance on his screen said "read," so he read — and pasted code
   instead of double-clicking a file.
5. **Why didn't I catch it sooner?** I treated his frustration as noise
   instead of diagnostic data. Every frustrated message was the system
   telling me my model of his world was wrong, and I kept re-explaining
   instead of rebuilding the model.

## The four rules

**R1 — Ground every instruction in his visible world.**
Never reference a file, folder, screen, or UI element he hasn't confirmed.
If he hasn't said it's there, ask — don't describe it.

**R2 — One action, one confirmation.**
Give the first step only. Then stop and ask him to tell you what he sees.
The next step doesn't exist until this one lands.

**R3 — Match the affordance to the action.**
If the action is double-click, run, or open — name the literal click.
Never show code, scripts, or internal text when the user needs an action.
Machinery on screen must match the action needed.

**R4 — Frustration is diagnostic data.**
Profanity at the process, "you're not listening," "simplify," the same
question asked twice — these are not noise. They mean the model of his
world is wrong. Rebuild it: ask what he actually sees and does. Never
resend the explanation louder.

## How it lives in the keeper

- `GuidanceDoctrine.js` (beside the chat bridge): a pre-send lint with
  detectors for R1, R2, R3, and R5 (ask-don't-infer, the standing rule
  this incident re-taught), plus R4 frustration detection on the user's
  turn. Heuristic checklist — documented as not-a-guarantee in the code.
- When R4 fires, the turn runs in **rebuild mode**: the model is directed
  to ask one plain-words question about what he actually sees instead of
  re-explaining, and the deterministic fallback yields the clarifying
  question instead of canned instructions.
- The lint is advisory on the model path — it records findings, it never
  rewrites his voice. The pipeline works identically if the module is
  absent.
- This incident is recorded as a Review-Queue voice-pair candidate so
  Steve himself approves the lesson through the human pipeline.

## The plain-words line

Future installs are just: extract the new package, open its
`Continuity_Architecture` as the vault. No installer, ever again.
