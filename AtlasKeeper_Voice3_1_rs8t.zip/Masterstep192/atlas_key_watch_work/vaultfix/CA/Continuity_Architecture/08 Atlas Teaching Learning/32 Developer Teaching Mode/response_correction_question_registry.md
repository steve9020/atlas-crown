---
title: Response Correction Question Registry
runtime_layer: developer_teaching_mode
priority: high
governed_by: program_only_question_rules
outputs_to:
  - teaching_answer_to_proposal_flow
  - correction_learning_reference
status: active
---

# Response Correction Question Registry

## Purpose

This reference defines correction categories Developer Teaching Mode can offer after Compass produces a response.

---

## Correction Categories

### Wrong Route

Use when Compass recognized the wrong emotional pathway.

Question:

- What should this have routed as instead?

---

### Too Vague

Use when the response is structurally correct but not emotionally specific enough.

Question:

- What needed to be made more specific?

---

### Missing Emotional Context

Use when the response names the feeling but misses what it touches.

Question:

- What emotional context did Compass miss?

---

### Missing Loop Explanation

Use when the response does not explain how the feeling and meaning feed each other.

Question:

- What loop should Compass have explained?

---

### Missing Clearer Way Forward

Use when the response identifies separation but does not explain how to understand it going forward.

Question:

- What clearer understanding should the user carry forward?

---

### Too Mechanical

Use when the response sounds like framework language instead of clear human interpretation.

Question:

- What sounded mechanical, and what should it sound like instead?

---

## Related Runtime Links

- [[developer_teaching_mode_overview]]
- [[program_only_question_rules]]
- [[teaching_answer_to_proposal_flow]]
- [[correction_learning_registry]]
