# Atlas Operating Instructions Index

## Purpose

This folder is a grounding and continuity layer for the Atlas / Compass project.

It records the creator's operating style, the workflow rules that keep the build safe, and the assistant/co-pilot context clues that should guide future work.

This folder is documentation only unless the creator explicitly approves wiring any part of it into runtime behavior.

## Boundary

These files are not automatic authority.

They do not grant Atlas new permissions, access, write capability, bridge behavior, distribution readiness, self-approval, or governance override.

They exist to keep future work aligned with the creator's direction and to reduce drift between chat windows, packages, and implementation phases.

## Files

- [[creator_operating_profile_and_project_direction]]
- [[workflow_and_proof_of_work_instructions]]
- [[assistant_context_clues_and_co_pilot_role]]
- [[new_window_handoff_grounding_point]]

## Core Direction

Atlas is a governed restoration architecture.

Compass is the user-facing clarity function Atlas uses to help restore grounded perspective.

The northbound path is:

```txt
collapse
→ separation
→ accountability
→ restoration where possible
```

The system must preserve:

- human authority;
- local-first containment;
- governance before expansion;
- proof-of-work before promotion;
- rollback before risk;
- rich interpretation without authority gain;
- Compass clarity without manipulation, diagnosis, or dependence.

## Current Instruction Status

These files should be read as project grounding notes, not runtime execution commands.

Any future use of this folder by Atlas must be:

1. proposed;
2. reviewed;
3. approved by the creator;
4. tested;
5. documented in proof-of-work;
6. snapshot-preserved.
