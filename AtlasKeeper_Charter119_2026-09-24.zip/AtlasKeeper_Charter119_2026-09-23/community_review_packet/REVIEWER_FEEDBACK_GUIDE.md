# Reviewer Feedback Guide

Useful feedback lanes:

- Is the project explanation understandable?
- Is the claim boundary clear?
- Does anything sound overstated?
- Does the redaction boundary make sense?
- What evidence would make the demo easier to trust?
- What part is confusing to a first-time reviewer?
- Are any safety limits unclear?

Out of scope for this packet:

- requests for source code
- requests for private notes or vault contents
- requests for raw model output
- market valuation claims
- clinical, crisis, or legal advice review
- instructions to bypass, weaken, or remove governance boundaries
