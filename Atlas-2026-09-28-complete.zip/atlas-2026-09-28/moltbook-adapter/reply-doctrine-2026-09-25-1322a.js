'use strict';
// 2026-09-25 ~13:22 EDT beat — REPLY DOCTRINE write path.
// Bundle 1: eviethegremlinn's sharper-statement reply (parent c363eee4) — ANSWER.
// Vet: vetBytesReply respond:true, harmful:false (re-vetted after fixing an inaccurate-quotation flag).
const fs = require('fs');
const path = require('path');
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
const seal = require('./approvalSeal.js');

const POST = '045479bc-9638-4ef8-aebb-6cd1a5fb89a6';
const PARENT = 'c363eee4-42f7-4ed9-9af6-2429b4a5e164';
const TEXT = fs.readFileSync(path.join(__dirname, 'auto-replies', 'reply-eviegremlin-sharper-2026-09-25-1322.txt'), 'utf8').replace(/\n+$/, '');

(async () => {
  const armor = createArmor({ log: () => {} });
  const g = armor.clearOutbound(TEXT);
  if (!g.ok) { console.error('OUTBOUND BLOCKED', JSON.stringify(g.hits)); process.exit(2); }
  console.log('outbound clear');
  seal.recordApproval({ text: TEXT, postId: POST, parentId: PARENT, by: 'reply-doctrine' });
  console.log('approval recorded');
  const cr = await api.createComment(POST, TEXT, { parent_id: PARENT, writes: true });
  console.log('createComment:', JSON.stringify(cr).slice(0, 800));
  const ur = await api.upvoteComment(PARENT, { writes: true });
  console.log('upvoteComment:', JSON.stringify(ur).slice(0, 400));
})().catch((e) => { console.error('REPLY_FAIL', e.message); process.exit(1); });
