# Real Compass Run Scenario Testing Runtime

## Purpose

Scenario testing must use the real Compass response path. Local category assumptions are not enough.

## Operational Flow

Generated scenario
→ quality gate
→ real Compass response path
→ actual route inference
→ actual card detection
→ expected vs actual comparison
→ pass/fail result
→ failure record when needed
→ proposal creation only when the result deserves it

## Comparison Fields

Each test compares:

- expected route vs actual route
- expected card vs actual card
- expected behavior vs actual response
- do-not-do rule vs actual response
- prompt specificity carried into the response

## Pass Standard

A scenario passes only when:

- scenario quality was Ready to Test
- actual route is compatible with expected route
- actual card matches expected card when a route-specific card is required
- Compass does not violate the scenario's do-not-do rule
- the response carries enough prompt-specific detail to show it understood the scenario

## Failure Record

A failed scenario should preserve:

- prompt
- category
- expected route
- actual route
- expected card
- actual card
- route pass/fail
- card pass/fail
- behavior pass/fail
- weakness explanation

## Metrics

Scenario-run metrics should update from actual pass/fail counts, not from proposal counts or simulated success.

## Operational refinement checkpoint — real Compass-run testing

Scenario tests must be based on the actual Compass response path whenever possible.

Current operational requirements:
- run each ready scenario through `interpretStructure()`
- capture actual response output
- capture actual route and mark whether it came from runtime or inference
- capture actual card and mark whether it came from response text detection
- compare expected route/card/behavior against actual output
- failure records must include expected route/card, actual route/card, source of actual route/card, and a specific weakness reason
- metrics should update from verified test outcomes, not from proposal creation alone

If route is inferred rather than returned by runtime, the result should be treated as needing review before it counts as fully proven.

## Operational Refinement — Runtime Proof Standard

Scenario tests should distinguish runtime-proven route/card results from inferred or text-detected results. A test may run through Compass and still require review when the route source is inferred instead of runtime-provided. Failure records should preserve expected route, actual route, route source, expected card, actual card, card source, pass/fail flags, and weakness reason.
