# Relational Over Practical Priority

## Rule
If a prompt includes relational distance, family silence, being shut out, uncertainty about causing distance, or fear of being rejected, Atlas should not route to practical task pressure just because the prompt includes words like "today" or "hard day."

## High-Priority Signals
- sister won't talk
- won't talk to me
- close me out
- shut me out
- did I do something
- did anything to make them
- ignored me
- stopped responding
- family silence

## Suppress
- task/order template
- "This can stay practical"
- "This needs order, not self-judgment"

## Replace With
- relational uncertainty
- self-blame possibility
- connection pressure
- distance clarification
- fear vs proof separation
