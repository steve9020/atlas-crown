const assert = require('assert');
const { parseFactualAnchors } = require('../runtime/backend/closedLoop/FactualAnchorParser');
const { calculateAxisPressureMap } = require('../runtime/backend/closedLoop/AxisEngineScoring');
const { resolveDoyleSpireRelations } = require('../runtime/backend/closedLoop/DoyleSpireRelationalLookup');
const { resolveSeparationTarget, SEPARATION_RULES } = require('../runtime/backend/closedLoop/SeparationTargetSelector');
const { resolveRestorationGateway, RESTORATION_GATEWAYS } = require('../runtime/backend/closedLoop/RestorationGatewaySelector');
const { runClosedLoopArchitecture } = require('../runtime/backend/closedLoop/ClosedLoopBackendArchitecture');

function run(input){
  const parsed = parseFactualAnchors(input);
  const axisMap = calculateAxisPressureMap('sess_58', parsed.stream_02_subjective_variables);
  const doyle = resolveDoyleSpireRelations(parsed, axisMap);
  const separation = resolveSeparationTarget(axisMap, parsed.stream_01_objective_constants.factual_anchors, doyle.unverified_attachments);
  const restoration = resolveRestorationGateway(separation);
  return { parsed, axisMap, doyle, separation, restoration };
}

assert.ok(SEPARATION_RULES.length >= 12, 'expected expanded separation matrix');
assert.ok(Object.keys(RESTORATION_GATEWAYS).length >= 12, 'expected expanded restoration matrix');

const silence = run("They haven't answered me yet, and I keep thinking maybe I bothered them.");
assert.strictEqual(silence.separation.separation_target.strategy_code, 'WEDGE_SILENCE_VS_REJECTION');
assert.strictEqual(silence.restoration.restoration_metadata.target_posture_code, 'POSTURE_GROUNDED_BELONGING');
assert.ok(silence.doyle.do_not_assume_boundaries.includes('FEAR_REJECTION_ANGER'));

const invite = run("He didn't invite me to the huddle today. I feel like I ruined the project because my last pitch was weak.");
assert.strictEqual(invite.separation.separation_target.strategy_code, 'WEDGE_EXCLUSION_VS_REMOVAL');
assert.strictEqual(invite.restoration.restoration_metadata.target_posture_code, 'POSTURE_IMMEDIATE_AGENCY');
assert.strictEqual(invite.separation.validator_assertions.highest_score_overrode_context, false);

const load = run("I keep falling behind, and it makes me feel like I can't handle my own life.");
assert.strictEqual(load.separation.separation_target.strategy_code, 'WEDGE_TASK_LOAD_VS_ABILITY');
assert.strictEqual(load.restoration.restoration_metadata.target_posture_code, 'POSTURE_WORKABLE_MOVEMENT');

const tone = run("They replied differently than usual and now I want to explain myself again before they get mad.");
assert.ok(['WEDGE_IMPULSE_VS_CHOICE','WEDGE_BEHAVIOR_VS_MOTIVE'].includes(tone.separation.separation_target.strategy_code));
assert.ok(['POSTURE_GROUNDED_CHOICE','POSTURE_DISTANCE_DETACHMENT'].includes(tone.restoration.restoration_metadata.target_posture_code));
assert.ok(tone.doyle.do_not_assume_boundaries.includes('FEAR_REJECTION_ANGER'));

const positive = run("I felt peaceful today, but part of me doesn't trust it because things usually get hard again.");
assert.strictEqual(positive.separation.separation_target.strategy_code, 'WEDGE_POSITIVE_STATE_VS_LOSS_FEAR');
assert.strictEqual(positive.restoration.restoration_metadata.target_posture_code, 'POSTURE_POSITIVE_PRESERVATION');

const closed = runClosedLoopArchitecture("I felt peaceful today, but part of me doesn't trust it because things usually get hard again.", { session_id: 'sess_58_closed' });
assert.strictEqual(closed.backend_owns_all_intelligence, true);
assert.strictEqual(closed.frontend_intelligence_allowed, false);
assert.strictEqual(closed.doyle.doyle_state_assertions.fixed_dictionary_meaning_used, false);
assert.strictEqual(closed.separation.validator_assertions.context_intersection_required, true);
assert.strictEqual(closed.restoration.validator_assertions.wedge_to_gateway_alignment_required, true);
assert.strictEqual(closed.validation.evaluation_gate.status, 'PASSED');

console.log('masterStep58DoyleSeparationRestorationMatrixTest PASSED');
