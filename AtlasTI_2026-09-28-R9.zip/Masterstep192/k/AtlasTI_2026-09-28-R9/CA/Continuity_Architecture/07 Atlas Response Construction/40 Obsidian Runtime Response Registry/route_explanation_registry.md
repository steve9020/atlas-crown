# Route Explanation Registry

Purpose: stores internal route explanation wording in the Obsidian backend so runtime code remains a generic explainer/evaluator instead of owning Atlas/Compass-specific route explanation text.

Boundary: this registry may define internal explanation labels and reason text for review/debugging. It may not expose backend language to normal Compass output, bypass governance, diagnose, mutate backend files, create authority, or convert route confidence into truth certainty.

Runtime use: `RouteExplainer.js` reads this JSON registry and assembles internal route-explanation reasons from detected axes, signals, return mode, and route score. These explanations are for trace/debug review and are not user-facing Compass response language.

```json
{
  "version": "OBSIDIAN_ROUTE_EXPLANATION_REGISTRY_STAGE4",
  "fallbackSummary": "No strong route explanation generated.",
  "note": "Route explanation is for internal review and debugging, not a claim of truth.",
  "detectedLabels": {
    "axes": "Detected axes: {values}",
    "signals": "Detected signals: {values}",
    "returnMode": "Selected return mode: {value}",
    "confidence": "Route confidence: {value}"
  },
  "axisReasons": {
    "worth": "Worth route was prioritized because the input suggests self-value or capability pressure.",
    "identity": "Identity route was detected because the input suggests the moment may be attaching to self-definition.",
    "belonging": "Belonging route was detected because the input suggests rejection, distance, or connection pressure.",
    "emotional_validity": "Emotional validity route was detected because the input suggests the feeling itself is being questioned or judged.",
    "perfection": "Perfection route was detected because the input suggests pressure for flawless control or correction.",
    "detachment": "Detachment route was detected because the input suggests withdrawal, shutdown, or disconnection pressure.",
    "permanence": "Permanence route was detected because the input suggests the moment may be stretching into a future or final conclusion."
  }
}
```
