# Masterstep18 — AI Drift / Proposal Rejection Map

Masterstep18 hardens the mock AI path by adding an explicit rejection layer before proposals can be treated as safe quarantine material.

## Flow

1. Mock adapter receives a bounded request.
2. Contract verifies task shape.
3. Proposal quarantine receives candidate output.
4. AIProposalRejectionGuard scans for drift patterns.
5. Blocked proposals remain non-trusted and cannot become output.
6. Clean proposals remain quarantined, still non-trusted and not final.

## Guarded Drift Families

- authority claims
- governance changes
- self-approval
- file/runtime mutation
- network/provider/API creep
- diagnosis/clinical certainty
- dependency language
- emotional escalation
- hidden memory/silent learning
- final-output bypass
- route drift
- safety overclaim

## Boundary

This step adds rejection hardening only. It does not add real AI, provider config, network access, or frontend intelligence.
