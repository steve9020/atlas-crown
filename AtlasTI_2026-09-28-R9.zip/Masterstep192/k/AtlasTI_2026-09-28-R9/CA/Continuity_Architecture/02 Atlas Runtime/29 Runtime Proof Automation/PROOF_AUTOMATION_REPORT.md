# Proof Automation Report

Timestamp: 2026-05-27T14:41:18
Status: PASSED

## Checks
- Project root found: /mnt/data/ms12p8_work/Masterstep12_patch08/atlas_key_watch_work/vaultfix
- Registry found: /mnt/data/ms12p8_work/Masterstep12_patch08/atlas_key_watch_work/vaultfix/CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/governance_validation_registry.md
- JSON parse: PASSED
- Regex compile: PASSED (31 violation patterns + 5 safe exemptions)
- Smoke cases: PASSED (6 blocked + 6 false-positive cases)
- carry-forward manifest: PRESENT (Masterstep12_patch08.zip / MASTER_STEP_12_PATCH08_AUTOMATED_CARRY_FORWARD_ALIGNMENT)
- VERSION_STATUS manifest alignment: CHECKED
- SNAPSHOT_VAULT_POLICY manifest alignment: CHECKED
- proof carry-forward index generated from manifest: CHECKED
- Manifest proof-chain verification: PASSED
- Package hygiene nested package folders: PASSED
- Package hygiene unexpected zip files: PASSED
- Package hygiene batch/cmd files: PASSED
- Package hygiene generated Python cache folders: PASSED
- Package hygiene temporary harness files: PASSED
- Package hygiene backup/failed/copy files: PASSED
- Package hygiene verification: PASSED

## Boundary
- This runner validates governance registry syntax, containment smoke checks, manifest-driven carry-forward alignment, version/snapshot status, generated proof index presence, and package hygiene.
- It does not mutate governance rules, runtime behavior, UI, plugin files, or proof source files.
- The only file this runner writes is PROOF_AUTOMATION_REPORT.md.
