const fs = require("fs");
const path = require("path");

const atlasRoot = path.join(__dirname, "..");
const pluginRoot = path.join(atlasRoot, "CA", "Continuity_Architecture", ".obsidian", "plugins", "continuity-interface");
const mainPath = path.join(pluginRoot, "main.js");
const stylesPath = path.join(pluginRoot, "styles.css");

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const mainText = fs.readFileSync(mainPath, "utf8");
const stylesText = fs.readFileSync(stylesPath, "utf8");
const combined = `${mainText}\n${stylesText}`;

assert(combined.includes("Atlas UI Viewport Containment Patch"), "Viewport containment patch marker missing.");
assert(/\.compass-root[\s\S]*max-height:\s*calc\(100vh\s*-\s*56px\)/.test(combined), "Compass root does not reserve viewport bottom space.");
assert(/\.compass-root[\s\S]*padding-bottom:\s*72px/.test(combined), "Compass root does not include bottom breathing room.");
assert(/\.atlas-auto-teaching-shell[\s\S]*max-height:\s*calc\(100vh\s*-\s*72px\)/.test(combined), "Auto Teaching shell does not have viewport containment.");
assert(/\.atlas-auto-layout[\s\S]*min-height:\s*0\s*!important/.test(combined), "Auto Teaching layout min-height was not neutralized for constrained panes.");
assert(!/\.status-bar\s*\{[\s\S]*display\s*:\s*none/.test(combined), "Plugin CSS must not hide Obsidian status bar.");
assert(!/\.status-bar\s*\{[\s\S]*visibility\s*:\s*hidden/.test(combined), "Plugin CSS must not hide Obsidian status bar visibility.");

console.log("UI VIEWPORT CONTAINMENT TEST");
console.log("============================");
console.log("Compass viewport containment: PASSED");
console.log("Auto Teaching viewport containment: PASSED");
console.log("Bottom breathing room: PASSED");
console.log("Status bar non-hide rule: PASSED");
