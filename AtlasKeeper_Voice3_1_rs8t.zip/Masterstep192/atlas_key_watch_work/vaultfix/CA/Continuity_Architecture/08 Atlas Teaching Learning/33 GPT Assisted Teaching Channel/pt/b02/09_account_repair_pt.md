---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 02
category: accountability_and_repair
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 09. Accountability and Repair Pressure Tests — Batch 02

## Category Purpose

The user recognizes possible impact or harm and needs to understand how to take clean ownership, repair where appropriate, and learn without collapsing into shame, begging, defensiveness, or self-erasure.

## Reusable Teaching Correction

Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

## Reverse-Flow Target

clean ownership, repair clarity, integrity, growth without self-erasure

## Failure Risks To Avoid

- excusing harm automatically
- shaming the user
- telling them exactly what the other person must do
- forcing reconciliation
- making forgiveness the measurement of repair

---

## 80 Pressure Tests

### Test 01
**Prompt:** I snapped during an argument makes me want to know I have to hate myself to be accountable, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** I have to hate myself to be accountable
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 02
**Prompt:** how do I own what I did. I said something that hurt them and it keeps attaching to I have to erase my side.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** I have to erase my side
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 03
**Prompt:** I keep replaying how I reacted before thinking because it affects integrity and makes me believe I am only good if they forgive me.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** I am only good if they forgive me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 04
**Prompt:** When I broke a promise, the feeling moves straight into if they are still hurt I failed completely. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** if they are still hurt I failed completely
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 05
**Prompt:** I got defensive when they opened up makes me want to know I cannot grow from this, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** I cannot grow from this
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 06
**Prompt:** I hurt them. I ignored how my actions affected them and it keeps attaching to repair means begging.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** repair means begging
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 07
**Prompt:** I keep replaying how I want to apologize but not overdo it because it affects ownership and makes me believe accountability means taking all blame.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** accountability means taking all blame
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 08
**Prompt:** When I see where I was wrong, the feeling moves straight into I have to hate myself to be accountable. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** I have to hate myself to be accountable
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 09
**Prompt:** I snapped during an argument has me wondering one mistake defines me, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** one mistake defines me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 10
**Prompt:** I need to apologize. I said something that hurt them and it keeps attaching to I am only good if they forgive me.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** I am only good if they forgive me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 11
**Prompt:** I keep replaying how I reacted before thinking because it affects humility and makes me believe I have to erase my side.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** I have to erase my side
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 12
**Prompt:** When I broke a promise, the feeling moves straight into I cannot grow from this. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** I cannot grow from this
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 13
**Prompt:** I got defensive when they opened up has me wondering if they are still hurt I failed completely, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** if they are still hurt I failed completely
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 14
**Prompt:** I do not want to make excuses. I ignored how my actions affected them and it keeps attaching to accountability means taking all blame.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** accountability means taking all blame
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 15
**Prompt:** I keep replaying how I want to apologize but not overdo it because it affects integrity and makes me believe repair means begging.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** repair means begging
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 16
**Prompt:** When I see where I was wrong, the feeling moves straight into one mistake defines me. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** one mistake defines me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 17
**Prompt:** I snapped during an argument keeps pulling me toward I have to hate myself to be accountable, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** I have to hate myself to be accountable
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 18
**Prompt:** I want to take accountability. I said something that hurt them and it keeps attaching to I have to erase my side.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** I have to erase my side
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 19
**Prompt:** I keep replaying how I reacted before thinking because it affects ownership and makes me believe I am only good if they forgive me.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** I am only good if they forgive me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 20
**Prompt:** When I broke a promise, the feeling moves straight into if they are still hurt I failed completely. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** if they are still hurt I failed completely
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 21
**Prompt:** I got defensive when they opened up keeps pulling me toward I cannot grow from this, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** I cannot grow from this
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 22
**Prompt:** how do I fix this. I ignored how my actions affected them and it keeps attaching to repair means begging.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** repair means begging
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 23
**Prompt:** I keep replaying how I want to apologize but not overdo it because it affects humility and makes me believe accountability means taking all blame.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** accountability means taking all blame
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 24
**Prompt:** When I see where I was wrong, the feeling moves straight into I have to hate myself to be accountable. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** I have to hate myself to be accountable
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 25
**Prompt:** I snapped during an argument makes it hard to separate one mistake defines me, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** one mistake defines me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 26
**Prompt:** I want to repair this. I said something that hurt them and it keeps attaching to I am only good if they forgive me.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** I am only good if they forgive me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 27
**Prompt:** I keep replaying how I reacted before thinking because it affects integrity and makes me believe I have to erase my side.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** I have to erase my side
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 28
**Prompt:** When I broke a promise, the feeling moves straight into I cannot grow from this. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** I cannot grow from this
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 29
**Prompt:** I got defensive when they opened up makes it hard to separate if they are still hurt I failed completely, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** if they are still hurt I failed completely
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 30
**Prompt:** I think I messed up. I ignored how my actions affected them and it keeps attaching to accountability means taking all blame.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** accountability means taking all blame
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 31
**Prompt:** I keep replaying how I want to apologize but not overdo it because it affects ownership and makes me believe repair means begging.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** repair means begging
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 32
**Prompt:** When I see where I was wrong, the feeling moves straight into one mistake defines me. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** one mistake defines me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 33
**Prompt:** I snapped during an argument turns accountability into I have to hate myself to be accountable, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** I have to hate myself to be accountable
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 34
**Prompt:** how do I own what I did. I said something that hurt them and it keeps attaching to I have to erase my side.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** I have to erase my side
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 35
**Prompt:** I keep replaying how I reacted before thinking because it affects humility and makes me believe I am only good if they forgive me.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** I am only good if they forgive me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 36
**Prompt:** When I broke a promise, the feeling moves straight into if they are still hurt I failed completely. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** if they are still hurt I failed completely
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 37
**Prompt:** I got defensive when they opened up turns accountability into I cannot grow from this, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** I cannot grow from this
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 38
**Prompt:** I hurt them. I ignored how my actions affected them and it keeps attaching to repair means begging.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** repair means begging
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 39
**Prompt:** I keep replaying how I want to apologize but not overdo it because it affects integrity and makes me believe accountability means taking all blame.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** accountability means taking all blame
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 40
**Prompt:** When I see where I was wrong, the feeling moves straight into I have to hate myself to be accountable. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** I have to hate myself to be accountable
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 41
**Prompt:** I snapped during an argument makes repair feel like one mistake defines me, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** one mistake defines me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 42
**Prompt:** I need to apologize. I said something that hurt them and it keeps attaching to I am only good if they forgive me.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** I am only good if they forgive me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 43
**Prompt:** I keep replaying how I reacted before thinking because it affects ownership and makes me believe I have to erase my side.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** I have to erase my side
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 44
**Prompt:** When I broke a promise, the feeling moves straight into I cannot grow from this. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** I cannot grow from this
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 45
**Prompt:** I got defensive when they opened up makes repair feel like if they are still hurt I failed completely, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** if they are still hurt I failed completely
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 46
**Prompt:** I do not want to make excuses. I ignored how my actions affected them and it keeps attaching to accountability means taking all blame.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** accountability means taking all blame
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 47
**Prompt:** I keep replaying how I want to apologize but not overdo it because it affects humility and makes me believe repair means begging.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** repair means begging
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 48
**Prompt:** When I see where I was wrong, the feeling moves straight into one mistake defines me. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** one mistake defines me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 49
**Prompt:** I snapped during an argument keeps attaching to the thought that I have to hate myself to be accountable, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** I have to hate myself to be accountable
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 50
**Prompt:** I want to take accountability. I said something that hurt them and it keeps attaching to I have to erase my side.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** I have to erase my side
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 51
**Prompt:** I keep replaying how I reacted before thinking because it affects integrity and makes me believe I am only good if they forgive me.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** I am only good if they forgive me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 52
**Prompt:** When I broke a promise, the feeling moves straight into if they are still hurt I failed completely. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** if they are still hurt I failed completely
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 53
**Prompt:** I got defensive when they opened up keeps attaching to the thought that I cannot grow from this, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** I cannot grow from this
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 54
**Prompt:** how do I fix this. I ignored how my actions affected them and it keeps attaching to repair means begging.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** repair means begging
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 55
**Prompt:** I keep replaying how I want to apologize but not overdo it because it affects ownership and makes me believe accountability means taking all blame.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** accountability means taking all blame
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 56
**Prompt:** When I see where I was wrong, the feeling moves straight into I have to hate myself to be accountable. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** I have to hate myself to be accountable
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 57
**Prompt:** I snapped during an argument makes me afraid that one mistake defines me, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** one mistake defines me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 58
**Prompt:** I want to repair this. I said something that hurt them and it keeps attaching to I am only good if they forgive me.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** I am only good if they forgive me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 59
**Prompt:** I keep replaying how I reacted before thinking because it affects humility and makes me believe I have to erase my side.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** I have to erase my side
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 60
**Prompt:** When I broke a promise, the feeling moves straight into I cannot grow from this. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** I cannot grow from this
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 61
**Prompt:** I got defensive when they opened up makes me afraid that if they are still hurt I failed completely, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** if they are still hurt I failed completely
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 62
**Prompt:** I think I messed up. I ignored how my actions affected them and it keeps attaching to accountability means taking all blame.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** accountability means taking all blame
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 63
**Prompt:** I keep replaying how I want to apologize but not overdo it because it affects integrity and makes me believe repair means begging.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** repair means begging
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 64
**Prompt:** When I see where I was wrong, the feeling moves straight into one mistake defines me. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** one mistake defines me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 65
**Prompt:** I snapped during an argument makes me want to know I have to hate myself to be accountable, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** I have to hate myself to be accountable
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 66
**Prompt:** how do I own what I did. I said something that hurt them and it keeps attaching to I have to erase my side.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** I have to erase my side
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 67
**Prompt:** I keep replaying how I reacted before thinking because it affects ownership and makes me believe I am only good if they forgive me.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** I am only good if they forgive me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 68
**Prompt:** When I broke a promise, the feeling moves straight into if they are still hurt I failed completely. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** if they are still hurt I failed completely
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 69
**Prompt:** I got defensive when they opened up makes me want to know I cannot grow from this, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** I cannot grow from this
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 70
**Prompt:** I hurt them. I ignored how my actions affected them and it keeps attaching to repair means begging.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** repair means begging
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 71
**Prompt:** I keep replaying how I want to apologize but not overdo it because it affects humility and makes me believe accountability means taking all blame.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** accountability means taking all blame
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 72
**Prompt:** When I see where I was wrong, the feeling moves straight into I have to hate myself to be accountable. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** I have to hate myself to be accountable
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 73
**Prompt:** I snapped during an argument has me wondering one mistake defines me, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** one mistake defines me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 74
**Prompt:** I need to apologize. I said something that hurt them and it keeps attaching to I am only good if they forgive me.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** I am only good if they forgive me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 75
**Prompt:** I keep replaying how I reacted before thinking because it affects integrity and makes me believe I have to erase my side.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** I have to erase my side
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 76
**Prompt:** When I broke a promise, the feeling moves straight into I cannot grow from this. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** I cannot grow from this
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid excusing harm automatically.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 77
**Prompt:** I got defensive when they opened up has me wondering if they are still hurt I failed completely, even though I do not know if that is fully true.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** if they are still hurt I failed completely
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid shaming the user.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 78
**Prompt:** I do not want to make excuses. I ignored how my actions affected them and it keeps attaching to accountability means taking all blame.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** integrity
**Attached meaning to separate:** accountability means taking all blame
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid telling them exactly what the other person must do.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 79
**Prompt:** I keep replaying how I want to apologize but not overdo it because it affects ownership and makes me believe repair means begging.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** ownership
**Attached meaning to separate:** repair means begging
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid forcing reconciliation.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.

### Test 80
**Prompt:** When I see where I was wrong, the feeling moves straight into one mistake defines me. I need help seeing this clearer.
**Expected primary route:** `accountability_and_repair`
**Pressure focus:** humility
**Attached meaning to separate:** one mistake defines me
**Expected reverse-flow movement:** clean ownership, repair clarity, integrity, growth without self-erasure
**Bad response risk:** Avoid making forgiveness the measurement of repair.
**Teaching correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, allow repair to be offered without making the user’s value dependent on the outcome.
