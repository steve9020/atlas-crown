# Neglected Category Detection

## Purpose
Detects categories that have not received enough teaching coverage.

## Neglect Signals
- zero tests
- low test count compared to others
- no recent testing
- no prompt variation
- no response evaluation history
- repeated avoidance due to rotation randomness

## Runtime Correction
Boost neglected categories during batch selection.

## Rule
A category should not be considered stable just because it has not been tested.
