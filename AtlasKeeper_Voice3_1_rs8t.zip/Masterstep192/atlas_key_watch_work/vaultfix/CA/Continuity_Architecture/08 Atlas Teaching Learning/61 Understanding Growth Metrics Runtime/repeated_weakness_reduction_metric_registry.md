# Repeated Weakness Reduction Metric Registry

## Metric
Repeated Weakness Reduction %

## Formula
repeated weakness categories reduced after correction ÷ repeated weakness categories tracked

## Meaning
This metric measures whether the same weakness category happens less after teaching and retesting.

## What changes it
- tracking a repeated weakness category increases denominator
- reducing that repeated weakness after approved correction increases numerator
