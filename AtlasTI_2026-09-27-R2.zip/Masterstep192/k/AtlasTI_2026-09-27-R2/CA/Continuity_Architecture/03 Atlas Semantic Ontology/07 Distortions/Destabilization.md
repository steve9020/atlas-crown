# Destabilization

## Definition
Destabilization is the weakening of continuity, regulation, coherence, or adaptive structure under pressure, contradiction, overload, distortion, or recursive escalation.

## Function
It identifies movement away from stable operation and toward fragmentation, collapse, or reverse-flow activation.

## Relationships
- [[Recursive Destabilization]]
- [[Destabilization Flows]]
- [[Operational Destabilization Mapping]]
- [[Fragmentation]]
- [[Systemic Destabilization Architecture]]
