# Embarrassment

## Mechanical Definition
Embarrassment is exposure discomfort created when the self feels socially visible in a way that may not match intended presentation.

---

## Real-World Definition
In real use, Embarrassment describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates Embarrassment
- mistakes in public
- awkwardness
- social attention
- correction
- perceived judgment

---

## What Embarrassment Produces
- self-consciousness
- face-saving
- withdrawal
- humor
- correction impulse

---

## What Distorts Embarrassment
- shame escalation
- social avoidance
- humiliation attachment
- identity fusion

---

## What Resolves Embarrassment Constructively
- normalization
- proportion
- humor
- repair if needed
- self-return

---

## What Happens Without Integration
- avoidance
- social fear
- shame loops
- performance anxiety
- reduced expression

---

## Connected Nodes
- [[Vulnerability|Vulnerability]]
- [[Shame]]
- [[social_judgment_weight]]
- [[Authenticity|Authenticity]]
- [[Self-Worth]]

---

## Core Principle
Embarrassment is exposure discomfort, not proof that the self has lost value.
