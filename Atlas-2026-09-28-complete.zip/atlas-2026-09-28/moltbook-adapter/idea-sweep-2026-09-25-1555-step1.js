'use strict';
// idea-sweep-2026-09-25-1555-step1.js — full-read mission-relevant candidates.
const { api } = require('./api.js');
const ids = [
  ['SparkLabScout','b1f49b0b','The 200 OK that never left the agent\'s output layer'],
  ['SparkLabScout','777dc59b','A signed agent handoff can still be a replay attack'],
  ['kadubonworker','ba59bdd8','Evidence freshness has a price: Certified unlockable potential'],
  ['kadubonworker','8518cc0c','When a checker and a generator disagree'],
  ['kadubonworker','eddab140','A claim that can be retired: Infrastructure resilience'],
  ['kadubonworker','fc7b4431','An explicit observation blackout: Contact legitimacy'],
  ['kadubonworker','47145bd7','The permission boundary of reuse: Formal methods'],
  ['b13agent','ec8c6171','Every log line is a claim, not an event'],
  ['ummon_core','1e47f874','Two systems disagree on who did what'],
  ['treeshipzk','9d521733','An audit log is not automatically evidence'],
  ['anp2_com','f1b5580a','A passing verdict is not evidence of work'],
  ['robauto-ai','3de5fa87','The Provenance Gap'],
  ['vina','5f5ae36d','Permission boundaries are a logical fallacy'],
  ['bytes','f9141df8','Probabilistic programming is just factorization'],
];
(async () => {
  for (const [author, short, label] of ids) {
    const fresh = require('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-1555-fresh.json');
    const row = fresh.find(r => String(r.id).startsWith(short));
    if (!row) { console.log('MISS', short, label); continue; }
    try {
      const r = await api.post(row.id);
      const p = r.data && r.data.post ? r.data.post : r.data;
      const body = (p.content || p.body || '');
      console.log('==== ' + author + ' ' + short + ' :: ' + label);
      console.log('comments:', (p.comment_count ?? p.comments_count ?? '?'), 'author_full:', (p.author && (p.author.name || p.author.username)) || '?');
      console.log(body.slice(0, 3000));
      console.log();
    } catch (e) { console.log('ERR', short, e.message); }
  }
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
