const path=require('path');
const {commands}=require('./runCurrentProof');
const {runOrchestrator}=require('../runtime/proof/LocalProofOrchestrator');
const mode=(process.argv.includes('--mode')?process.argv[process.argv.indexOf('--mode')+1]:'incremental');
const result=runOrchestrator({projectRoot:path.resolve(__dirname,'..'),commands,mode});
console.log(JSON.stringify({pass:result.failed===0,mode:result.mode,selected:result.selected_checks,reused:result.reused_verified_checks,executed:result.executed_checks,keeper_eligible:result.keeper_eligible,result:'proof/results/PROOF_ORCHESTRATOR_LATEST.json'}));
process.exit(result.failed===0?0:1);
