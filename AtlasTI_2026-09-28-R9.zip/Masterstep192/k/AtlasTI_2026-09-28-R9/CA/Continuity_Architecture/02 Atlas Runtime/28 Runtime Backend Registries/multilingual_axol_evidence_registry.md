# Multilingual AXOL Evidence Registry

Language packs provide deterministic evidence routes into existing AXOLs. They do not create language-specific AXOLs and do not claim exhaustive language understanding.

```json
{
  "registry": "multilingual_axol_evidence_registry",
  "stage": "MASTERSTEP193_MULTILINGUAL_EPISTEMIC_STATE_MATURITY_CANDIDATE",
  "contract": "language_routes_supply_evidence_to_existing_axols_without_redefining_axol_meaning",
  "supported_language_packs": [
    {
      "code": "es",
      "name": "Spanish"
    },
    {
      "code": "fr",
      "name": "French"
    },
    {
      "code": "de",
      "name": "German"
    },
    {
      "code": "pt",
      "name": "Portuguese"
    },
    {
      "code": "it",
      "name": "Italian"
    },
    {
      "code": "nl",
      "name": "Dutch"
    },
    {
      "code": "pl",
      "name": "Polish"
    },
    {
      "code": "tr",
      "name": "Turkish"
    },
    {
      "code": "ru",
      "name": "Russian"
    },
    {
      "code": "ar",
      "name": "Arabic"
    },
    {
      "code": "hi",
      "name": "Hindi"
    },
    {
      "code": "ja",
      "name": "Japanese"
    },
    {
      "code": "ko",
      "name": "Korean"
    },
    {
      "code": "zh",
      "name": "Chinese"
    }
  ],
  "packs": {
    "es": {
      "name": "Spanish",
      "cues": {
        "intention": [
          "tenía la intención de",
          "quise hacerlo"
        ],
        "expectation": [
          "esperaba que",
          "contaba con que"
        ],
        "responsibility": [
          "soy responsable",
          "es mi responsabilidad"
        ],
        "choice": [
          "elegí",
          "decidí"
        ],
        "control": [
          "puedo controlar",
          "no puedo controlar"
        ],
        "trust": [
          "confío en",
          "no confío en"
        ],
        "respect": [
          "me respeta",
          "no me respeta"
        ],
        "fairness": [
          "es justo",
          "no es justo"
        ],
        "connection": [
          "me siento conectado",
          "me siento desconectado"
        ],
        "repair": [
          "quiero reparar",
          "intenté reparar"
        ],
        "acceptance_rejection": [
          "acepté",
          "rechacé"
        ],
        "interpretation": [
          "lo interpreté como",
          "me pareció que"
        ]
      },
      "families": {
        "intention": [
          "pensaba ayudar",
          "mi plan",
          "el plan era",
          "planeaba",
          "planeé",
          "mi idea era"
        ],
        "expectation": [
          "dependía de que",
          "suponía que",
          "daba por hecho"
        ],
        "responsibility": [
          "me corresponde",
          "responder por"
        ]
      },
      "uncertaintyMarkers": [
        "quizá",
        "tal vez",
        "no estoy seguro"
      ]
    },
    "fr": {
      "name": "French",
      "cues": {
        "intention": [
          "j'avais l'intention de",
          "je voulais le faire"
        ],
        "expectation": [
          "je m'attendais à",
          "je comptais sur"
        ],
        "responsibility": [
          "je suis responsable",
          "c'est ma responsabilité"
        ],
        "choice": [
          "j'ai choisi",
          "j'ai décidé"
        ],
        "control": [
          "je peux contrôler",
          "je ne peux pas contrôler"
        ],
        "trust": [
          "je fais confiance",
          "je ne fais pas confiance"
        ],
        "respect": [
          "me respecte",
          "ne me respecte pas"
        ],
        "fairness": [
          "c'est juste",
          "ce n'est pas juste"
        ],
        "connection": [
          "je me sens connecté",
          "je me sens déconnecté"
        ],
        "repair": [
          "je veux réparer",
          "j'ai essayé de réparer"
        ],
        "acceptance_rejection": [
          "j'ai accepté",
          "j'ai rejeté"
        ],
        "interpretation": [
          "je l'ai interprété comme",
          "il m'a semblé que"
        ]
      },
      "families": {
        "intention": [
          "mon projet",
          "projet était",
          "prévoyais",
          "je comptais"
        ],
        "expectation": [
          "je pensais qu",
          "supposais",
          "tenais pour acquis"
        ],
        "responsibility": [
          "répondre de",
          "j’assume",
          "j'assume"
        ]
      },
      "uncertaintyMarkers": [
        "peut-être",
        "je ne suis pas sûr",
        "je ne suis pas certaine"
      ]
    },
    "de": {
      "name": "German",
      "cues": {
        "intention": [
          "ich hatte vor",
          "ich wollte es tun"
        ],
        "expectation": [
          "ich erwartete",
          "ich rechnete damit"
        ],
        "responsibility": [
          "ich bin verantwortlich",
          "es ist meine verantwortung"
        ],
        "choice": [
          "ich wählte",
          "ich entschied"
        ],
        "control": [
          "ich kann kontrollieren",
          "ich kann nicht kontrollieren"
        ],
        "trust": [
          "ich vertraue",
          "ich vertraue nicht"
        ],
        "respect": [
          "respektiert mich",
          "respektiert mich nicht"
        ],
        "fairness": [
          "es ist fair",
          "es ist nicht fair"
        ],
        "connection": [
          "ich fühle mich verbunden",
          "ich fühle mich getrennt"
        ],
        "repair": [
          "ich will reparieren",
          "ich versuchte zu reparieren"
        ],
        "acceptance_rejection": [
          "ich akzeptierte",
          "ich lehnte ab"
        ],
        "interpretation": [
          "ich interpretierte es als",
          "es schien mir"
        ]
      },
      "families": {
        "intention": [
          "mein plan",
          "plante",
          "beabsichtigt"
        ],
        "expectation": [
          "ging davon aus",
          "nahm an"
        ],
        "responsibility": [
          "trage ich die verantwortung",
          "verantwortung tragen"
        ]
      },
      "uncertaintyMarkers": [
        "vielleicht",
        "ich bin nicht sicher"
      ]
    },
    "pt": {
      "name": "Portuguese",
      "cues": {
        "intention": [
          "eu pretendia",
          "eu queria fazer"
        ],
        "expectation": [
          "eu esperava que",
          "eu contava com"
        ],
        "responsibility": [
          "sou responsável",
          "é minha responsabilidade"
        ],
        "choice": [
          "eu escolhi",
          "eu decidi"
        ],
        "control": [
          "posso controlar",
          "não posso controlar"
        ],
        "trust": [
          "eu confio",
          "eu não confio"
        ],
        "respect": [
          "me respeita",
          "não me respeita"
        ],
        "fairness": [
          "é justo",
          "não é justo"
        ],
        "connection": [
          "me sinto conectado",
          "me sinto desconectado"
        ],
        "repair": [
          "quero reparar",
          "tentei reparar"
        ],
        "acceptance_rejection": [
          "eu aceitei",
          "eu rejeitei"
        ],
        "interpretation": [
          "interpretei como",
          "me pareceu que"
        ]
      },
      "families": {
        "intention": [
          "meu plano",
          "planejava",
          "tinha em mente"
        ],
        "expectation": [
          "achava que",
          "presumia",
          "presumi"
        ],
        "responsibility": [
          "cabe a mim",
          "responder por"
        ]
      },
      "uncertaintyMarkers": [
        "talvez",
        "não tenho certeza"
      ]
    },
    "it": {
      "name": "Italian",
      "cues": {
        "intention": [
          "avevo intenzione di",
          "volevo farlo"
        ],
        "expectation": [
          "mi aspettavo che",
          "contavo su"
        ],
        "responsibility": [
          "sono responsabile",
          "è mia responsabilità"
        ],
        "choice": [
          "ho scelto",
          "ho deciso"
        ],
        "control": [
          "posso controllare",
          "non posso controllare"
        ],
        "trust": [
          "mi fido",
          "non mi fido"
        ],
        "respect": [
          "mi rispetta",
          "non mi rispetta"
        ],
        "fairness": [
          "è giusto",
          "non è giusto"
        ],
        "connection": [
          "mi sento connesso",
          "mi sento disconnesso"
        ],
        "repair": [
          "voglio riparare",
          "ho cercato di riparare"
        ],
        "acceptance_rejection": [
          "ho accettato",
          "ho rifiutato"
        ],
        "interpretation": [
          "l'ho interpretato come",
          "mi è sembrato che"
        ]
      },
      "families": {
        "intention": [
          "il mio piano",
          "progettavo",
          "avevo in mente"
        ],
        "expectation": [
          "pensavo che",
          "supponevo",
          "davo per scontato"
        ],
        "responsibility": [
          "assumo la responsabilità",
          "responsabilità"
        ]
      },
      "uncertaintyMarkers": [
        "forse",
        "non sono sicuro",
        "non sono sicura"
      ]
    },
    "nl": {
      "name": "Dutch",
      "cues": {
        "intention": [
          "ik was van plan",
          "ik wilde het doen"
        ],
        "expectation": [
          "ik verwachtte",
          "ik rekende erop"
        ],
        "responsibility": [
          "ik ben verantwoordelijk",
          "het is mijn verantwoordelijkheid"
        ],
        "choice": [
          "ik koos",
          "ik besloot"
        ],
        "control": [
          "ik kan controleren",
          "ik kan niet controleren"
        ],
        "trust": [
          "ik vertrouw",
          "ik vertrouw niet"
        ],
        "respect": [
          "respecteert mij",
          "respecteert mij niet"
        ],
        "fairness": [
          "het is eerlijk",
          "het is niet eerlijk"
        ],
        "connection": [
          "ik voel me verbonden",
          "ik voel me losgekoppeld"
        ],
        "repair": [
          "ik wil herstellen",
          "ik probeerde te herstellen"
        ],
        "acceptance_rejection": [
          "ik accepteerde",
          "ik wees af"
        ],
        "interpretation": [
          "ik interpreteerde het als",
          "het leek mij"
        ]
      },
      "families": {
        "intention": [
          "mijn plan",
          "plande"
        ],
        "expectation": [
          "ging ervan uit",
          "nam aan"
        ],
        "responsibility": [
          "draag hiervoor de verantwoordelijkheid",
          "verantwoordelijkheid"
        ]
      },
      "uncertaintyMarkers": [
        "misschien",
        "ik weet niet zeker"
      ]
    },
    "pl": {
      "name": "Polish",
      "cues": {
        "intention": [
          "zamierzałem",
          "chciałem to zrobić"
        ],
        "expectation": [
          "spodziewałem się",
          "liczyłem na"
        ],
        "responsibility": [
          "jestem odpowiedzialny",
          "to moja odpowiedzialność"
        ],
        "choice": [
          "wybrałem",
          "zdecydowałem"
        ],
        "control": [
          "mogę kontrolować",
          "nie mogę kontrolować"
        ],
        "trust": [
          "ufam",
          "nie ufam"
        ],
        "respect": [
          "szanuje mnie",
          "nie szanuje mnie"
        ],
        "fairness": [
          "to jest sprawiedliwe",
          "to nie jest sprawiedliwe"
        ],
        "connection": [
          "czuję więź",
          "czuję odłączenie"
        ],
        "repair": [
          "chcę naprawić",
          "próbowałem naprawić"
        ],
        "acceptance_rejection": [
          "zaakceptowałem",
          "odrzuciłem"
        ],
        "interpretation": [
          "zinterpretowałem to jako",
          "wydawało mi się"
        ]
      },
      "families": {
        "intention": [
          "miałem plan",
          "planowałem"
        ],
        "expectation": [
          "zakładałem",
          "spodziewałem"
        ],
        "responsibility": [
          "biorę za to odpowiedzialność",
          "odpowiedzialność"
        ]
      },
      "uncertaintyMarkers": [
        "może",
        "nie jestem pewien",
        "nie jestem pewna"
      ]
    },
    "tr": {
      "name": "Turkish",
      "cues": {
        "intention": [
          "niyetim vardı",
          "yapmak istedim"
        ],
        "expectation": [
          "bekliyordum",
          "güveniyordum ki"
        ],
        "responsibility": [
          "ben sorumluyum",
          "bu benim sorumluluğum"
        ],
        "choice": [
          "seçtim",
          "karar verdim"
        ],
        "control": [
          "kontrol edebilirim",
          "kontrol edemem"
        ],
        "trust": [
          "güveniyorum",
          "güvenmiyorum"
        ],
        "respect": [
          "bana saygı duyuyor",
          "bana saygı duymuyor"
        ],
        "fairness": [
          "bu adil",
          "bu adil değil"
        ],
        "connection": [
          "bağlı hissediyorum",
          "kopuk hissediyorum"
        ],
        "repair": [
          "onarmak istiyorum",
          "onarmaya çalıştım"
        ],
        "acceptance_rejection": [
          "kabul ettim",
          "reddettim"
        ],
        "interpretation": [
          "bunu şöyle yorumladım",
          "bana öyle geldi"
        ]
      },
      "families": {
        "intention": [
          "planım",
          "planladım",
          "düşünüyordum"
        ],
        "expectation": [
          "varsaydım",
          "bekliyordum"
        ],
        "responsibility": [
          "sorumluluğunu üstleniyorum",
          "sorumluluk"
        ]
      },
      "uncertaintyMarkers": [
        "belki",
        "emin değilim"
      ]
    },
    "ru": {
      "name": "Russian",
      "cues": {
        "intention": [
          "я намеревался",
          "я хотел это сделать"
        ],
        "expectation": [
          "я ожидал",
          "я рассчитывал на"
        ],
        "responsibility": [
          "я отвечаю за",
          "это моя ответственность"
        ],
        "choice": [
          "я выбрал",
          "я решил"
        ],
        "control": [
          "я могу контролировать",
          "я не могу контролировать"
        ],
        "trust": [
          "я доверяю",
          "я не доверяю"
        ],
        "respect": [
          "уважает меня",
          "не уважает меня"
        ],
        "fairness": [
          "это справедливо",
          "это несправедливо"
        ],
        "connection": [
          "я чувствую связь",
          "я чувствую себя отстранённым"
        ],
        "repair": [
          "я хочу исправить",
          "я пытался исправить"
        ],
        "acceptance_rejection": [
          "я принял",
          "я отверг"
        ],
        "interpretation": [
          "я истолковал это как",
          "мне показалось что"
        ]
      },
      "families": {
        "intention": [
          "планировал",
          "мой план"
        ],
        "expectation": [
          "рассчитывал",
          "предполагал"
        ],
        "responsibility": [
          "беру за это ответственность",
          "ответственност"
        ]
      },
      "uncertaintyMarkers": [
        "возможно",
        "может быть",
        "я не уверен",
        "я не уверена"
      ]
    },
    "ar": {
      "name": "Arabic",
      "cues": {
        "intention": [
          "كنت أنوي",
          "أردت أن أفعل"
        ],
        "expectation": [
          "كنت أتوقع",
          "كنت أعتمد على"
        ],
        "responsibility": [
          "أنا مسؤول",
          "هذه مسؤوليتي"
        ],
        "choice": [
          "اخترت",
          "قررت"
        ],
        "control": [
          "أستطيع التحكم",
          "لا أستطيع التحكم"
        ],
        "trust": [
          "أنا أثق",
          "أنا لا أثق"
        ],
        "respect": [
          "يحترمني",
          "لا يحترمني"
        ],
        "fairness": [
          "هذا عادل",
          "هذا غير عادل"
        ],
        "connection": [
          "أشعر بالاتصال",
          "أشعر بالانفصال"
        ],
        "repair": [
          "أريد إصلاح",
          "حاولت إصلاح"
        ],
        "acceptance_rejection": [
          "قبلت",
          "رفضت"
        ],
        "interpretation": [
          "فسرت ذلك على أنه",
          "بدا لي أن"
        ]
      },
      "families": {
        "intention": [
          "خطتي",
          "كنت أنوي"
        ],
        "expectation": [
          "كنت أتوقع",
          "ظننت أن"
        ],
        "responsibility": [
          "أتحمل مسؤولية",
          "مسؤولية"
        ]
      },
      "uncertaintyMarkers": [
        "ربما",
        "لست متأكدا",
        "لست متأكدة"
      ]
    },
    "hi": {
      "name": "Hindi",
      "cues": {
        "intention": [
          "मेरा इरादा था",
          "मैं करना चाहता था"
        ],
        "expectation": [
          "मुझे उम्मीद थी",
          "मैं भरोसा कर रहा था"
        ],
        "responsibility": [
          "मैं जिम्मेदार हूँ",
          "यह मेरी जिम्मेदारी है"
        ],
        "choice": [
          "मैंने चुना",
          "मैंने फैसला किया"
        ],
        "control": [
          "मैं नियंत्रित कर सकता हूँ",
          "मैं नियंत्रित नहीं कर सकता"
        ],
        "trust": [
          "मुझे भरोसा है",
          "मुझे भरोसा नहीं है"
        ],
        "respect": [
          "मेरा सम्मान करता है",
          "मेरा सम्मान नहीं करता"
        ],
        "fairness": [
          "यह उचित है",
          "यह उचित नहीं है"
        ],
        "connection": [
          "मैं जुड़ा हुआ महसूस करता हूँ",
          "मैं अलग महसूस करता हूँ"
        ],
        "repair": [
          "मैं सुधारना चाहता हूँ",
          "मैंने सुधारने की कोशिश की"
        ],
        "acceptance_rejection": [
          "मैंने स्वीकार किया",
          "मैंने अस्वीकार किया"
        ],
        "interpretation": [
          "मैंने इसका अर्थ यह समझा",
          "मुझे ऐसा लगा कि"
        ]
      },
      "families": {
        "intention": [
          "मेरी योजना",
          "सोचा था कि",
          "इरादा किया"
        ],
        "expectation": [
          "उम्मीद थी",
          "मान लिया था"
        ],
        "responsibility": [
          "जिम्मेदारी लेता",
          "जिम्मेदार"
        ]
      },
      "uncertaintyMarkers": [
        "शायद",
        "मुझे यकीन नहीं"
      ]
    },
    "ja": {
      "name": "Japanese",
      "cues": {
        "intention": [
          "するつもりだった",
          "しようと思っていた"
        ],
        "expectation": [
          "期待していた",
          "当てにしていた"
        ],
        "responsibility": [
          "私の責任です",
          "責任がある"
        ],
        "choice": [
          "選んだ",
          "決めた"
        ],
        "control": [
          "コントロールできる",
          "コントロールできない"
        ],
        "trust": [
          "信頼している",
          "信頼していない"
        ],
        "respect": [
          "尊重している",
          "尊重していない"
        ],
        "fairness": [
          "公平だ",
          "公平ではない"
        ],
        "connection": [
          "つながりを感じる",
          "切り離されたと感じる"
        ],
        "repair": [
          "修復したい",
          "修復しようとした"
        ],
        "acceptance_rejection": [
          "受け入れた",
          "拒否した"
        ],
        "interpretation": [
          "と解釈した",
          "ように思えた"
        ]
      },
      "families": {
        "intention": [
          "つもりだった",
          "予定だった"
        ],
        "expectation": [
          "と思っていた",
          "はずだと思"
        ],
        "responsibility": [
          "責任は私が負う",
          "責任を負"
        ]
      },
      "uncertaintyMarkers": [
        "たぶん",
        "かもしれない",
        "わからない"
      ]
    },
    "ko": {
      "name": "Korean",
      "cues": {
        "intention": [
          "할 의도였다",
          "하려고 했다"
        ],
        "expectation": [
          "기대했다",
          "믿고 있었다"
        ],
        "responsibility": [
          "내 책임이다",
          "책임이 있다"
        ],
        "choice": [
          "선택했다",
          "결정했다"
        ],
        "control": [
          "통제할 수 있다",
          "통제할 수 없다"
        ],
        "trust": [
          "신뢰한다",
          "신뢰하지 않는다"
        ],
        "respect": [
          "나를 존중한다",
          "나를 존중하지 않는다"
        ],
        "fairness": [
          "공정하다",
          "공정하지 않다"
        ],
        "connection": [
          "연결되어 있다고 느낀다",
          "단절되었다고 느낀다"
        ],
        "repair": [
          "고치고 싶다",
          "고치려고 했다"
        ],
        "acceptance_rejection": [
          "받아들였다",
          "거부했다"
        ],
        "interpretation": [
          "라고 해석했다",
          "처럼 보였다"
        ]
      },
      "families": {
        "intention": [
          "생각이었다",
          "계획이었다"
        ],
        "expectation": [
          "거라고 생각했다",
          "것으로 예상"
        ],
        "responsibility": [
          "책임은 내가 진다",
          "책임을 지"
        ]
      },
      "uncertaintyMarkers": [
        "아마",
        "모르겠다",
        "확실하지 않다"
      ]
    },
    "zh": {
      "name": "Chinese",
      "cues": {
        "intention": [
          "我本来打算",
          "我想要做"
        ],
        "expectation": [
          "我原本期待",
          "我指望"
        ],
        "responsibility": [
          "我是负责人",
          "这是我的责任"
        ],
        "choice": [
          "我选择了",
          "我决定了"
        ],
        "control": [
          "我能控制",
          "我无法控制"
        ],
        "trust": [
          "我信任",
          "我不信任"
        ],
        "respect": [
          "尊重我",
          "不尊重我"
        ],
        "fairness": [
          "这是公平的",
          "这不公平"
        ],
        "connection": [
          "我感到有联系",
          "我感到疏离"
        ],
        "repair": [
          "我想修复",
          "我试图修复"
        ],
        "acceptance_rejection": [
          "我接受了",
          "我拒绝了"
        ],
        "interpretation": [
          "我把它理解为",
          "在我看来"
        ]
      },
      "families": {
        "intention": [
          "本来打算",
          "计划"
        ],
        "expectation": [
          "原以为",
          "预计"
        ],
        "responsibility": [
          "由我负责",
          "承担责任"
        ]
      },
      "uncertaintyMarkers": [
        "也许",
        "可能",
        "不确定"
      ]
    }
  }
}
```
