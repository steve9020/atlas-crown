# Temporal Response Guidance

## Response Order
1. name the time-layer
2. identify what is being carried
3. identify what is happening now
4. identify what the user fears it may become
5. separate carried meaning from inevitable future pattern
6. restore agency through present awareness

## Avoid
- the past controls you
- this will become a pattern
- deterministic language
- diagnosis
- trauma-only framing

## Use
- may be carried
- can remain active
- may begin shaping
- awareness gives a chance to interrupt
