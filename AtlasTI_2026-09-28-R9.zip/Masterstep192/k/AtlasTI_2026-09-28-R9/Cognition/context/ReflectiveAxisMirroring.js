const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const REFLECTIVE_AXIS_MIRRORING_REGISTRY_PATH = "CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/reflective_axis_mirroring_registry.md";

let cachedReflectiveAxisMirroringRegistry = null;

function getReflectiveAxisMirroringRegistry() {
  if (!cachedReflectiveAxisMirroringRegistry) {
    cachedReflectiveAxisMirroringRegistry = readJsonRegistry(REFLECTIVE_AXIS_MIRRORING_REGISTRY_PATH);
  }
  return cachedReflectiveAxisMirroringRegistry;
}

function normalizeInput(input) { return String(input || "").toLowerCase(); }
function phraseMatches(text, phrase) { return typeof phrase === "string" && phrase.length > 0 && text.includes(phrase.toLowerCase()); }
function anyPhraseMatches(text, phrases) { return Array.isArray(phrases) && phrases.some((phrase) => phraseMatches(text, phrase)); }
function allGroupsMatch(text, groups) {
  if (!Array.isArray(groups) || groups.length === 0) return true;
  return groups.every((group) => anyPhraseMatches(text, Array.isArray(group.phrases) ? group.phrases : []));
}
function ruleMatches(text, rule) {
  const phrases = Array.isArray(rule.phrases) ? rule.phrases : [];
  const allGroups = Array.isArray(rule.allGroups) ? rule.allGroups : [];
  if (allGroups.length > 0 && !allGroupsMatch(text, allGroups)) return false;
  if (phrases.length > 0 && !anyPhraseMatches(text, phrases)) return false;
  return allGroups.length > 0 || phrases.length > 0;
}
function appendUnique(target, values) {
  if (!Array.isArray(values)) return;
  for (const value of values) {
    if (typeof value === "string" && value.trim() && !target.includes(value)) target.push(value);
  }
}
function collectMatchedRules(text, rules) {
  const matched = [];
  for (const rule of rules) if (rule && rule.id && ruleMatches(text, rule)) matched.push(rule);
  return matched;
}
function resolveDependencyState(contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread) {
  return {
    context_integrity_active: !!contextIntegrity,
    semantic_fusion_active: !!semanticFusion,
    progressive_understanding_active: !!progressiveUnderstanding,
    intuition_meaning_spread_active: !!intuitionMeaningSpread,
    context_revisable: !contextIntegrity || contextIntegrity.revisable !== false,
    semantic_revisable: !semanticFusion || semanticFusion.revisable !== false,
    progressive_revisable: !progressiveUnderstanding || progressiveUnderstanding.revisable !== false,
    intuition_spread_revisable: !intuitionMeaningSpread || intuitionMeaningSpread.revisable !== false,
    prior_closure_allowed: !!(
      (contextIntegrity && contextIntegrity.closure_allowed === true) ||
      (semanticFusion && semanticFusion.closure_allowed === true) ||
      (progressiveUnderstanding && progressiveUnderstanding.closure_allowed === true) ||
      (intuitionMeaningSpread && intuitionMeaningSpread.closure_allowed === true)
    )
  };
}

function mapReflectiveAxisMirroring(input, contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread) {
  const text = normalizeInput(input);
  const registry = getReflectiveAxisMirroringRegistry();
  const rules = Array.isArray(registry.rules) ? [...registry.rules] : [];
  rules.sort((a, b) => (a.priority || 9999) - (b.priority || 9999));
  const matchedRules = collectMatchedRules(text, rules);

  const axisStates = [];
  const collapsedIdentityLanguage = [];
  const safeMirrorMoves = [];
  const separationMoves = [];
  const returnRestoreMoves = [];
  const forbiddenReflections = [];
  const governanceMoves = [];

  for (const rule of matchedRules) {
    appendUnique(axisStates, rule.axisStates);
    appendUnique(collapsedIdentityLanguage, rule.collapsedIdentityLanguage);
    appendUnique(safeMirrorMoves, rule.safeMirrorMoves);
    appendUnique(separationMoves, rule.separationMoves);
    appendUnique(returnRestoreMoves, rule.returnRestoreMoves);
    appendUnique(forbiddenReflections, rule.forbiddenReflections);
    appendUnique(governanceMoves, rule.governanceMoves);
  }

  const dependencyState = resolveDependencyState(contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread);
  const mirrorActive = axisStates.length > 0 || safeMirrorMoves.length > 0 || collapsedIdentityLanguage.length > 0;

  return {
    version: registry.version,
    stewardship: "Master Step 4E — Reflective Axis Mirroring",
    depends_on: [
      "Master Step 4A — Context Integrity Mapping",
      "Master Step 4B — Semantic Fusion Separation",
      "Master Step 4C — Progressive Understanding Runtime",
      "Master Step 4D — Intuition & Meaning Spread Governance"
    ],
    dependency_state: dependencyState,
    reflective_axis_mirroring_active: mirrorActive,
    mirrors_axis_state_not_identity_collapse: true,
    linguistic_identity_mirroring_allowed: false,
    collapsed_identity_inherited_as_truth: false,
    movement_restriction_separated_from_worth: separationMoves.includes("movement_restriction_not_identity_destruction") || mirrorActive,
    return_or_restore_path_preserved: returnRestoreMoves.length > 0 || mirrorActive,
    sterile_correction_language_allowed: false,
    closure_allowed: false,
    revisable: true,
    output_posture: governanceMoves.length > 0 ? governanceMoves : [
      "mirror_axis_state_not_identity_label",
      "separate_restriction_from_worth",
      "preserve_return_or_restore_path"
    ],
    axis_states: axisStates,
    collapsed_identity_language: collapsedIdentityLanguage,
    safe_mirror_moves: safeMirrorMoves,
    separation_moves: separationMoves,
    return_restore_moves: returnRestoreMoves,
    forbidden_reflections: forbiddenReflections,
    matched_rules: matchedRules.map((rule) => rule.id),
    guardrails: Array.isArray(registry.guardrails) ? registry.guardrails : []
  };
}

module.exports = { mapReflectiveAxisMirroring };
