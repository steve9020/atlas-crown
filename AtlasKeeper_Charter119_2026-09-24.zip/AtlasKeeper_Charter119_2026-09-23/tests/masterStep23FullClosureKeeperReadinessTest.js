const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function assert(cond,msg){ if(!cond) throw new Error(msg); }
function exists(rel){ return fs.existsSync(path.join(root, rel)); }
function read(rel){ return fs.readFileSync(path.join(root, rel),'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
[
 'runtime/ai/AI_REENABLE_REVIEW_RETEST_ENFORCEMENT.json',
 'runtime/ai/AIReenableRetestEvidenceBundle.js',
 'runtime/ai/AIReenableRetestEnforcementGuard.js',
 'runtime/ai/AIReenableAuditTrail.js',
 'runtime/proof/MASTERSTEP23_AI_REENABLE_RETEST_ENFORCEMENT.md',
 'runtime/proof/MASTERSTEP23_TEST_RESULTS.md',
 'docs/MASTERSTEP23_AI_REENABLE_RETEST_ENFORCEMENT_MAP.md'
].forEach(rel => assert(exists(rel), rel + ' must exist'));
const state = json('runtime/proof/PROOF_STATE.json');
assert(state.current_keeper === 'Masterstep23.zip', 'current keeper must be Masterstep23.zip');
assert(state.previous_keeper === 'Masterstep22.zip', 'previous keeper must be Masterstep22.zip');
assert(state.status === 'closed_keeper', 'status must be closed keeper');
assert(state.ai_reenable_retest_enforcement_added === true, 're-enable retest enforcement flag required');
assert(state.real_ai_connected === false, 'real AI must remain false');
assert(state.local_model_connected === false, 'local model must remain false');
assert(state.provider_config_added === false, 'provider config must remain false');
assert(state.network_bridge_added === false, 'network bridge must remain false');
const version = read('version_status.js');
assert(version.includes("current_keeper: 'Masterstep23.zip'"), 'version must point to Masterstep23');
assert(version.includes("previous_keeper: 'Masterstep22.zip'"), 'version must point previous to Masterstep22');
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md');
assert(summary.includes('Masterstep23.zip'), 'current proof summary must name Masterstep23');
assert(summary.includes('AI Re-enable Review + Retest Enforcement'), 'summary must name step objective');
assert(summary.includes('No real AI connected'), 'summary must preserve real AI boundary');
console.log('masterStep23FullClosureKeeperReadinessTest PASSED');
