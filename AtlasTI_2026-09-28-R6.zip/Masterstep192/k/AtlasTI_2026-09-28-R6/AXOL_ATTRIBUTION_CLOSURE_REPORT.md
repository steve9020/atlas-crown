# AXOL Attribution Closure Report

## Scope
Backend AXOL attribution/reference continuity only. No frontend, Crown/governance authority, commercial packaging, or unrelated routing changes.

## Preserved baseline
The prior hell-fuzz candidate had 97/97 expected AXOL detections, 0/12 neutral lexical false positives, and 14/18 attribution checks. Four attribution/reference-continuity cases remained.

## Repair
- Tightened reporting-complement binding so recipient pronouns do not leak into later contrasting clauses.
- Added bounded two-participant contrast handling using grammatical roles rather than name/gender assumptions.
- Added conservative cross-sentence continuity across one non-AXOL interjection/report sentence when the preceding structural proposition has one explicit subject.
- Prevented unresolved local pronouns from being overwritten by an earlier named clause prefix.
- Kept ambiguous references unresolved instead of forcing a named antecedent.

## Same hell corpus
- Expected AXOL detections: 97/97
- Attribution checks: 18/18
- Neutral lexical false-positive cases: 0

## Fresh blind attribution corpus
- Named attribution checks: 10/10
- Ambiguity controls: 3/3 remained free of invented named bindings

## Regression
All AXOL regression tests and the axis-registry test pass.

## Canonical proof
`node proof/runCurrentProof.js` => 100/100 PASS.

## Boundary
This closes the currently reproduced four-case attribution gap. It does not claim general natural-language coreference resolution; ambiguous antecedents remain intentionally unresolved.
