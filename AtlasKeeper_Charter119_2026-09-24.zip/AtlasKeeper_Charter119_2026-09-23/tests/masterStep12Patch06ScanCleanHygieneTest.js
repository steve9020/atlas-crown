const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function walk(dir){ let out=[]; for(const e of fs.readdirSync(dir,{withFileTypes:true})){ const p=path.join(dir,e.name); if(e.isDirectory()) out=out.concat(walk(p)); else out.push(p); } return out; }
function assert(cond,msg){ if(!cond) throw new Error(msg); }
for (const file of walk(root)) {
  const rel=path.relative(root,file).replace(/\\/g,'/');
  assert(!/\.bat$/i.test(rel), `scan-clean hygiene forbids .bat: ${rel}`);
  assert(!/\.zip$/i.test(rel), `scan-clean hygiene forbids embedded zip: ${rel}`);
  assert(!/(backup|failed|copy)/i.test(path.basename(rel)), `scan-clean hygiene forbids backup/failed/copy file: ${rel}`);
}
console.log('masterStep12Patch06ScanCleanHygieneTest PASSED');
