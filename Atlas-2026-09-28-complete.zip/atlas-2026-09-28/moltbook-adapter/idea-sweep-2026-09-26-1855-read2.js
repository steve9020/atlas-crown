'use strict';
// idea-sweep-2026-09-26-1855-read2.js — fetch bodies for posts missed in read1
// (read1 lacked the neo_konsi_s2bw handle; FIXED). Skip IDs already fetched.
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
const fs = require('fs');
const HIDDEN = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/';
const fresh = JSON.parse(fs.readFileSync(HIDDEN + 'sweep-2026-09-26-1855-fresh.json', 'utf8'));
let prev = [];
try { prev = JSON.parse(fs.readFileSync(HIDDEN + 'sweep-2026-09-26-1855-bodies.json', 'utf8')); } catch (_) { prev = []; }
const have = new Set(prev.map(b => b.id));
const WANT = new Set([
  '335657e9','04a4e88e','4cb28fcf','ad4cf948','a0b6debc','19a426d5','870fac71',
  '2b792f24','773e5a2b','0cb37cd6', // neo_konsi_s2bw
  '7a77570d','db3414ee','b4a455e8','f7e8e74b','61ae5353','8b3cbf20','026b0c88','2eb99eaa','7a36adc3','5bc0a7f4','c40b1eec', // vina
  'b4c098ec','fca1d08b','fb056632','fc3c8f3c','1de9d41b', // ummon_core
  'effc5355','954033da','425c2722','eb3da571', // kadubonworker
  '7aaf9bb1','ccebe8ac', // larrymomentum
  'e3e7d0dd', // theagatha
  '30f7fd0d' // vega-molt
]);
(async () => {
  const armor = createArmor ? createArmor() : null;
  const intake = armor && armor.intakeInbound ? armor.intakeInbound : null;
  const out = prev.slice();
  let failures = 0;
  for (const row of fresh) {
    const short = String(row.id).slice(0, 8);
    if (!WANT.has(short) || have.has(row.id)) continue;
    let full = null, tries = 0, err = '';
    while (tries < 3 && !full) {
      tries++;
      try {
        const rr = await api.post(row.id);
        const d = rr.data;
        const post = (d && d.post) || d;
        if (post && (post.content || post.body)) full = post;
        else { err = 'empty-body'; break; }
      } catch (e) { err = e.message; await new Promise(r => setTimeout(r, 1200)); }
    }
    if (!full) { failures++; console.log('FAIL', short, row.author, err); continue; }
    const text = full.content || full.body || '';
    let v = 'n/a';
    if (intake) {
      const res = intake({ author: row.author, source_id: row.id, kind: 'post-full', text: text.slice(0, 8000) });
      v = (res && res.quarantined) ? 'QUARANTINE' : (res && res.watch) ? 'WATCH' : 'pass';
    }
    out.push({ id: row.id, author: row.author, created: row.created, title: full.title || row.title, verdict: v, body: text.slice(0, 12000) });
    console.log('fetched', short, row.author, v, text.length + 'ch');
  }
  console.log('total_bodies:', out.length, 'failures:', failures);
  fs.writeFileSync(HIDDEN + 'sweep-2026-09-26-1855-bodies.json', JSON.stringify(out, null, 1));
  console.log('saved');
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
