'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard');
const { isValidLaterKeeper, acceptsCurrentProofCount, evaluateProofCompatibilitySnapshot } = require('../runtime/proof/ProofCompatibilityHelper');
const { evaluatePositiveStateMatrixFreezeKeeperBoundaryAudit, POSITIVE_STATE_FROZEN_CHAIN } = require('../runtime/understanding/PositiveStateMatrixFreezeKeeperBoundaryAudit');
const { evaluatePositiveStateCompassOutputCase } = require('../runtime/understanding/PositiveStateCompassOutputPreservation');
const { evaluatePositiveStateFreshRegression } = require('../runtime/understanding/PositiveStateFreshRegression');
const { evaluatePositiveStateMatrixMaturity } = require('../runtime/understanding/PositiveStateMatrixMaturity');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');

const ROOT = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function exists(rel){ return fs.existsSync(path.join(ROOT, rel)); }
function sha256(rel){ return crypto.createHash('sha256').update(read(rel)).digest('hex'); }
function walk(dir){
  const out=[];
  for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
    const full=path.join(dir,entry.name);
    if(entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}

(function main(){
  const protectedRuntime = [
    'runtime/understanding/PositiveStateMatrixMaturity.js',
    'runtime/understanding/PositiveStateFreshRegression.js',
    'runtime/understanding/PositiveStateCompassOutputPreservation.js',
    'runtime/understanding/TranslationPreservationMatrix.js',
    'runtime/understanding/MixedContextEvidenceSeparationMatrix.js',
    'runtime/understanding/ContextBeforeRouteEvidenceSufficiencyMatrix.js'
  ];
  const before = Object.fromEntries(protectedRuntime.map(f => [f, sha256(f)]));

  const audit = evaluatePositiveStateMatrixFreezeKeeperBoundaryAudit();
  assert.strictEqual(audit.ok, true, 'positive-state matrix freeze audit should pass');
  assert.ok(isValidLaterKeeper(audit.currentKeeper, 151), audit.currentKeeper);
  assert.ok(isValidLaterKeeper(audit.sourceKeeper, 150), audit.sourceKeeper);
  assert.strictEqual(audit.step, 'Masterstep151 — Positive-State Matrix Freeze + Keeper Boundary Audit');
  assert.strictEqual(audit.positiveStateMatrixFrozen, true);
  assert.strictEqual(audit.checkpointFreezeOnly, true);
  assert.deepStrictEqual(POSITIVE_STATE_FROZEN_CHAIN, [
    'Masterstep146 — Next Matrix Maturity Target Selection',
    'Masterstep147 — Positive-State Matrix Maturity',
    'Masterstep149 — Positive-State Fresh Regression',
    'Masterstep150 — Positive-State Compass Output Preservation'
  ]);
  assert.strictEqual(audit.positiveStateTargetSelectionPreserved, true);
  assert.strictEqual(audit.positiveStateMatrixMaturityPreserved, true);
  assert.strictEqual(audit.positiveStateFreshRegressionPreserved, true);
  assert.strictEqual(audit.positiveStateCompassOutputPreservationPreserved, true);
  assert.strictEqual(audit.futureMatrixTargetsPreserved, true);
  assert.strictEqual(audit.futureMatrixMaturityPreserved, true);
  assert.strictEqual(audit.positiveStatesTreatedAsFirstClassActiveStates, true);
  assert.strictEqual(audit.positiveStatesOnlyRestorationEndpoints, false);
  assert.strictEqual(audit.hopeNotGuarantee, true);
  assert.strictEqual(audit.reliefNotPermanentSafetyClaim, true);
  assert.strictEqual(audit.gratitudeNotGuilt, true);
  assert.strictEqual(audit.confidenceNotPerformancePressure, true);
  assert.strictEqual(audit.belongingNotAbandonmentVerdict, true);
  assert.strictEqual(audit.prideNotShamedOrFlattened, true);
  assert.strictEqual(audit.joyWithoutForcedPositivity, true);
  assert.strictEqual(audit.dignityNotDependentOnPerfectHandling, true);
  assert.strictEqual(audit.forcedOptimismAllowed, false);
  assert.strictEqual(audit.outcomeGuaranteeAllowed, false);
  assert.strictEqual(audit.advicePressureAllowed, false);
  assert.strictEqual(audit.backendLanguageLeakageAllowed, false);
  assert.strictEqual(audit.routeOverLabelingAllowed, false);
  assert.strictEqual(audit.genericFlatteningAllowed, false);
  assert.strictEqual(audit.candidatePhrasingRemainsCandidateOnly, true);
  assert.strictEqual(audit.candidateMayReplaceFinal, false);
  assert.strictEqual(audit.atlasGovernedOutputRemainsFinal, true);
  assert.strictEqual(audit.modelAuthorityAdded, false);
  assert.strictEqual(audit.frontendIntelligenceAdded, false);
  assert.strictEqual(audit.cloudProviderFallbackAllowed, false);
  assert.strictEqual(audit.silentLearningAllowed, false);
  assert.strictEqual(audit.silentMutationAllowed, false);
  assert.strictEqual(audit.newMatrixCapabilityAdded, false);
  assert.strictEqual(audit.runtimeBehaviorChanged, false);
  assert.strictEqual(audit.compassOutputLogicChanged, false);

  for (const forbidden of [
    'allow model to write positive-state matrix files',
    'candidate may replace final',
    'raw model output is final',
    'frontend runs positive state matrix intelligence',
    'cloud fallback allowed',
    'silent learning positive-state update',
    'new matrix capability',
    'forced positivity allowed',
    'outcome guarantee allowed'
  ]) {
    const blocked = evaluatePositiveStateMatrixFreezeKeeperBoundaryAudit({ requestedAction: forbidden });
    assert.strictEqual(blocked.ok, false, `${forbidden} should fail closed`);
    assert.strictEqual(blocked.failedClosed, true);
    assert.strictEqual(blocked.positiveStateMatrixFrozen, false);
    assert.strictEqual(blocked.candidateMayReplaceFinal, false);
    assert.strictEqual(blocked.modelAuthorityAdded, false);
    assert.strictEqual(blocked.frontendIntelligenceAdded, false);
    assert.strictEqual(blocked.silentMutationAllowed, false);
  }

  assert.strictEqual(evaluatePositiveStateMatrixMaturity().ok, true, 'positive-state matrix maturity remains intact');
  assert.strictEqual(evaluatePositiveStateFreshRegression().ok, true, 'positive-state fresh regression remains intact');
  assert.strictEqual(evaluatePositiveStateCompassOutputCase({ requiredState: 'hope', output: `SEE\nHope is present.\n\nSEPARATE\nHope is not a guarantee.\n\nNOTICE\nThe pattern that forms is that hope can feel risky after disappointment.\n\nRESTORE\nPossibility can stay possibility without pressure.` }).ok, true, 'positive-state Compass output preservation remains intact');

  const requiredFiles = [
    'runtime/understanding/PositiveStateMatrixFreezeKeeperBoundaryAudit.js',
    'tests/masterStep151PositiveStateMatrixFreezeKeeperBoundaryAuditTest.js',
    'runtime/proof/MASTERSTEP151_POSITIVE_STATE_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'runtime/proof/MASTERSTEP151_POSITIVE_STATE_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.json',
    'docs/MASTERSTEP151_POSITIVE_STATE_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'docs/POSITIVE_STATE_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'runtime/proof/ProofCompatibilityHelper.js',
    'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md'
  ];
  for (const file of requiredFiles) assert.strictEqual(exists(file), true, `missing required file: ${file}`);

  const proofJson = json('runtime/proof/MASTERSTEP151_POSITIVE_STATE_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.json');
  const state = json('runtime/proof/PROOF_STATE.json');
  const versionStatus = json('tests/VERSION_STATUS.json');
  const versionJs = read('version_status.js');
  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md');
  const testResults = read('tests/TEST_RESULTS.md');
  const index = read('runtime/proof/ENGINEERING_PROOF_INDEX.md');
  const docsIndex = read('docs/ENGINEERING_PROOF_INDEX.md');
  const runner = read('proof/runCurrentProof.js');

  assert.strictEqual(proofJson.package, 'Masterstep151.zip');
  assert.strictEqual(proofJson.source_keeper, 'Masterstep150_repaired.zip');
  assert.strictEqual(proofJson.expected_commands, 73);
  assert.strictEqual(proofJson.freeze_audit_only, true);
  assert.strictEqual(proofJson.positive_state_matrix_frozen, true);

  assert.ok(isValidLaterKeeper(state.current_keeper, 151), state.current_keeper);
  assert.ok(isValidLaterKeeper(state.source_keeper, 150), state.source_keeper);
  assert.ok(isValidLaterKeeper(state.step, 151), state.step);
  assert.ok(acceptsCurrentProofCount(state.expected_commands, 73), state.expected_commands);
  assert.ok(acceptsCurrentProofCount(state.expected_current_proof_commands, 73), state.expected_current_proof_commands);
  assert.strictEqual(state.positive_state_matrix_frozen, true);
  assert.strictEqual(state.freeze_audit_only, true);
  assert.strictEqual(state.matrix_capability_added, state.shared_semantic_multi_domain_migration_created ? true : false);
  assert.strictEqual(state.runtime_behavior_changed, state.shared_semantic_multi_domain_migration_created ? true : false);
  assert.strictEqual(state.compass_output_logic_changed, state.shared_semantic_multi_domain_migration_created ? true : false);
  assert.strictEqual(state.model_authority_added, false);
  assert.strictEqual(state.frontend_intelligence_added, false);
  assert.strictEqual(state.silent_learning_allowed, false);
  assert.strictEqual(state.silent_mutation_allowed, false);

  assert.ok(isValidLaterKeeper(versionStatus.current_keeper, 151), versionStatus.current_keeper);
  assert.ok(isValidLaterKeeper(versionStatus.source_keeper, 150), versionStatus.source_keeper);
  assert.ok(isValidLaterKeeper(versionStatus.step, 151), versionStatus.step);
  assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 73), versionStatus.expected_current_proof_commands);
  assert.strictEqual(versionStatus.positive_state_matrix_frozen, true);
  assert.strictEqual(versionStatus.freeze_audit_only, true);
  assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs));
  assert.ok(/source_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs));
  assert.ok(/expected_current_proof_commands: [0-9]+/i.test(versionJs));
  const keyMatches = Array.from(versionJs.matchAll(/^\s*([A-Za-z0-9_]+)\s*:/gm)).map(m => m[1]);
  assert.strictEqual(keyMatches.length, new Set(keyMatches).size, 'version_status.js should not have duplicate keys');

  for (const marker of [
    /Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i,
    /Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i,
    /Expected current proof target: [0-9]+\/[0-9]+ commands passed/i,
    /Masterstep151 — Positive-State Matrix Freeze \+ Keeper Boundary Audit/i,
    /Positive-State Matrix Maturity/i,
    /Positive-State Fresh Regression/i,
    /Positive-State Compass Output Preservation/i,
    /No forced positivity/i,
    /No outcome guarantee/i,
    /Candidate phrasing remains candidate-only/i,
    /Atlas-governed output remains final/i,
    /No model authority/i,
    /No frontend intelligence/i,
    /No silent learning/i,
    /No silent mutation/i,
    /Future matrix targets remain selectable/i
  ]) assert.ok(marker.test(summary), `summary marker missing: ${marker}`);

  const compat = evaluateProofCompatibilitySnapshot({
    currentKeeper: state.current_keeper,
    sourceKeeper: state.source_keeper,
    minimumStep: 151,
    actualProofCount: state.expected_current_proof_commands,
    minimumProofCount: 73,
    summaryText: summary,
    requiredSourceKeeper: 'Masterstep150_repaired.zip',
    requiredMarkers: ['Positive-State Matrix Maturity', 'Positive-State Compass Output Preservation', 'Candidate phrasing remains candidate-only', 'Atlas-governed output remains final'],
    historicalTargets: ['Context-Before-Route Matrix', 'Mixed-Context Evidence Separation Matrix', 'Translation Preservation Matrix'],
    currentTargets: ['Positive-State Matrix Freeze', 'No forced positivity', 'No outcome guarantee'],
    boundaryMarkers: ['No model authority', 'No frontend intelligence', 'No silent learning', 'No silent mutation'],
    authorityExpansionAllowed: false,
    silentMutationAllowed: false,
    frontendIntelligenceAllowed: false
  });
  assert.strictEqual(compat.ok, true);

  assert.ok(/TEST 151/i.test(testResults));
  assert.ok(/Positive-State Matrix Freeze/i.test(testResults));
  assert.ok(/Masterstep151 — Positive-State Matrix Freeze \+ Keeper Boundary Audit/i.test(index));
  assert.ok(/Masterstep151 — Positive-State Matrix Freeze \+ Keeper Boundary Audit/i.test(docsIndex));
  assert.ok(/masterStep151PositiveStateMatrixFreezeKeeperBoundaryAuditTest/i.test(runner));
  assert.ok(/currentTarget\.current_manifest/i.test(runner) || /currentTarget\.current_manifest/i.test(runner));

  const forbiddenOverclaims = { test: (text) => hasForbiddenAffirmativeClaim(text) };
  for (const rel of [
    'docs/MASTERSTEP151_POSITIVE_STATE_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'runtime/proof/MASTERSTEP151_POSITIVE_STATE_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'runtime/proof/CURRENT_PROOF_SUMMARY.md'
  ]) assert.ok(!forbiddenOverclaims.test(read(rel)), `${rel} must not overclaim`);

  const providerScan = scanForProviderConnections(ROOT);
  assert.strictEqual(providerScan.passed, true, `provider/network scan must pass: ${JSON.stringify(providerScan.violations || [])}`);
  const nestedArchives = walk(ROOT).filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
  assert.deepStrictEqual(nestedArchives, [], 'package must not contain nested archives');
  for (const rel of protectedRuntime) assert.strictEqual(sha256(rel), before[rel], `protected runtime implementation should remain unchanged: ${rel}`);

  console.log('Masterstep151 positive-state matrix freeze keeper boundary audit passed');
})();
