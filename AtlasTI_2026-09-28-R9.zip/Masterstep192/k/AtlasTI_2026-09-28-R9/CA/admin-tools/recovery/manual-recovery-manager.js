const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ============================================================
// Manual Recovery Manager
// External, manual, out-of-band recovery tool.
//
// Hard boundary:
// - Do not call this file from main.js or the Obsidian plugin runtime.
// - Keep this file outside .obsidian/plugins.
// - Run manually from a terminal only, with Obsidian closed.
// - No automatic recovery. No Atlas-triggered recovery.
// ============================================================

const TOOL_VERSION = '1.0.0';
const RECOVERY_ROOT = path.resolve(__dirname);
const SNAPSHOT_ROOT = path.join(RECOVERY_ROOT, 'snapshots');
const QUARANTINE_ROOT = path.join(RECOVERY_ROOT, 'quarantine');
const REPORT_ROOT = path.join(RECOVERY_ROOT, 'reports');

function nowIso() {
  return new Date().toISOString();
}

function safeTimestamp() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

function sha256Buffer(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

function sha256String(str) {
  return crypto.createHash('sha256').update(str).digest('hex');
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function writeJsonAtomic(filePath, data) {
  const tmp = `${filePath}.tmp-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmp, filePath);
}

function writeFileAtomic(filePath, content) {
  const tmp = `${filePath}.tmp-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  fs.writeFileSync(tmp, content, 'utf8');
  fs.renameSync(tmp, filePath);
}

function assertOutOfBandLocation() {
  const normalized = __dirname.replace(/\\/g, '/').toLowerCase();
  if (normalized.includes('/.obsidian/plugins/')) {
    throw new Error('BOUNDARY VIOLATION: manual-recovery-manager.js must not live inside .obsidian/plugins or the active runtime path.');
  }
}

function sanitizeLabel(label) {
  const raw = String(label || 'manual_snapshot').trim();
  const safe = raw.replace(/[^A-Za-z0-9._-]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 60);
  return safe || 'manual_snapshot';
}

function resolveExistingPath(inputPath, label) {
  if (!inputPath) throw new Error(`Missing ${label} path.`);
  const resolved = path.resolve(process.cwd(), inputPath);
  if (!fs.existsSync(resolved)) throw new Error(`${label} path does not exist: ${resolved}`);
  return resolved;
}

function assertVaultRoot(vaultPath) {
  const obsidianDir = path.join(vaultPath, '.obsidian');
  const governanceDir = path.join(vaultPath, '01 Atlas Governance');
  const coreDir = path.join(vaultPath, '00 Atlas Core');
  if (!fs.existsSync(obsidianDir) || !fs.statSync(obsidianDir).isDirectory()) {
    throw new Error(`Target is not a Continuity_Architecture vault: missing .obsidian at ${vaultPath}`);
  }
  if (!fs.existsSync(governanceDir) && !fs.existsSync(coreDir)) {
    throw new Error(`Target is not a recognized Continuity_Architecture vault: missing Atlas core/governance folders at ${vaultPath}`);
  }
}

function assertObsidianClosed(vaultPath) {
  const possibleLocks = [
    path.join(vaultPath, '.obsidian', 'workspace.json.tmp'),
    path.join(vaultPath, '.obsidian', 'workspace-mobile.json.tmp')
  ];
  const found = possibleLocks.filter(fs.existsSync);
  if (found.length > 0) {
    throw new Error(`Obsidian may be active or writing temporary workspace files. Close Obsidian before recovery. Found: ${found.join(', ')}`);
  }
}

function walkFiles(root, options = {}) {
  const files = [];
  const skipNames = new Set(options.skipNames || []);
  function walk(current) {
    const entries = fs.readdirSync(current, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name));
    for (const entry of entries) {
      if (skipNames.has(entry.name)) continue;
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) {
        walk(full);
      } else if (entry.isFile()) {
        files.push(full);
      }
    }
  }
  walk(root);
  return files;
}

function hashTree(root) {
  const records = [];
  for (const file of walkFiles(root)) {
    const rel = path.relative(root, file).replace(/\\/g, '/');
    const buffer = fs.readFileSync(file);
    records.push({
      path: rel,
      size: buffer.length,
      sha256: sha256Buffer(buffer)
    });
  }
  const treeHash = sha256String(JSON.stringify(records));
  return { tree_hash: treeHash, file_count: records.length, files: records };
}

function copyTree(src, dest) {
  ensureDir(dest);
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    const from = path.join(src, entry.name);
    const to = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyTree(from, to);
    } else if (entry.isFile()) {
      ensureDir(path.dirname(to));
      fs.copyFileSync(from, to);
    }
  }
}

function removeDirectoryContents(dir) {
  if (!fs.existsSync(dir)) return;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    fs.rmSync(full, { recursive: true, force: true });
  }
}

function loadSnapshotManifest(snapshotDir) {
  const manifestPath = path.join(snapshotDir, 'recovery_snapshot_manifest.json');
  if (!fs.existsSync(manifestPath)) {
    throw new Error(`Snapshot manifest missing: ${manifestPath}`);
  }
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  if (!manifest || manifest.manifest_type !== 'manual_recovery_snapshot') {
    throw new Error('Invalid recovery snapshot manifest type.');
  }
  if (!manifest.tree_hash || !Array.isArray(manifest.files)) {
    throw new Error('Invalid recovery snapshot manifest shape.');
  }
  return { manifest, manifestPath };
}

function snapshotVault(vaultPathInput, labelInput) {
  assertOutOfBandLocation();
  ensureDir(SNAPSHOT_ROOT);
  const vaultPath = resolveExistingPath(vaultPathInput, 'Vault');
  assertVaultRoot(vaultPath);
  assertObsidianClosed(vaultPath);

  const label = sanitizeLabel(labelInput);
  const id = `${safeTimestamp()}_${label}`;
  const snapshotDir = path.join(SNAPSHOT_ROOT, id);
  const snapshotVaultDir = path.join(snapshotDir, 'Continuity_Architecture');

  if (fs.existsSync(snapshotDir)) throw new Error(`Snapshot already exists: ${snapshotDir}`);
  ensureDir(snapshotDir);
  copyTree(vaultPath, snapshotVaultDir);

  const tree = hashTree(snapshotVaultDir);
  const manifest = {
    manifest_type: 'manual_recovery_snapshot',
    tool_version: TOOL_VERSION,
    created_at: nowIso(),
    snapshot_id: id,
    source_vault_path: vaultPath,
    snapshot_vault_path: snapshotVaultDir,
    restore_requires_manual_signature: true,
    obsidian_must_be_closed: true,
    plugin_may_not_call_recovery: true,
    ...tree
  };
  writeJsonAtomic(path.join(snapshotDir, 'recovery_snapshot_manifest.json'), manifest);

  const report = `# Manual Recovery Snapshot Report\n\n- Snapshot ID: ${id}\n- Created At: ${manifest.created_at}\n- Source Vault: ${vaultPath}\n- Snapshot Path: ${snapshotVaultDir}\n- File Count: ${tree.file_count}\n- Tree Hash: ${tree.tree_hash}\n\n## Boundary\n\nThis snapshot was created by the external manual recovery tool. It is not callable by the Obsidian plugin runtime.\n`;
  writeFileAtomic(path.join(REPORT_ROOT, `snapshot_${id}.md`), report);

  console.log(`[SUCCESS] Snapshot created: ${snapshotDir}`);
  console.log(`[VERIFY] File count: ${tree.file_count}`);
  console.log(`[VERIFY] Tree hash: ${tree.tree_hash}`);
}

function verifySnapshot(snapshotDirInput) {
  assertOutOfBandLocation();
  const snapshotDir = resolveExistingPath(snapshotDirInput, 'Snapshot');
  const { manifest } = loadSnapshotManifest(snapshotDir);
  const snapshotVaultDir = path.join(snapshotDir, 'Continuity_Architecture');
  if (!fs.existsSync(snapshotVaultDir)) throw new Error(`Snapshot vault folder missing: ${snapshotVaultDir}`);
  const tree = hashTree(snapshotVaultDir);
  if (tree.tree_hash !== manifest.tree_hash || tree.file_count !== manifest.file_count) {
    throw new Error(`SNAPSHOT VERIFICATION FAILED: expected ${manifest.tree_hash}/${manifest.file_count}, got ${tree.tree_hash}/${tree.file_count}`);
  }
  console.log('[SUCCESS] Snapshot verification passed.');
  console.log(`[VERIFY] Snapshot ID: ${manifest.snapshot_id}`);
  console.log(`[VERIFY] File count: ${tree.file_count}`);
  console.log(`[VERIFY] Tree hash: ${tree.tree_hash}`);
}

function dryRunRestore(snapshotDirInput, targetVaultPathInput) {
  assertOutOfBandLocation();
  const snapshotDir = resolveExistingPath(snapshotDirInput, 'Snapshot');
  const targetVaultPath = resolveExistingPath(targetVaultPathInput, 'Target vault');
  assertVaultRoot(targetVaultPath);
  assertObsidianClosed(targetVaultPath);
  const { manifest } = loadSnapshotManifest(snapshotDir);
  verifySnapshot(snapshotDir);
  console.log('[DRY RUN] Restore would proceed with:');
  console.log(`- Snapshot: ${snapshotDir}`);
  console.log(`- Snapshot ID: ${manifest.snapshot_id}`);
  console.log(`- Target vault: ${targetVaultPath}`);
  console.log(`- Current target would be quarantined before restore.`);
  console.log('[DRY RUN] No files changed.');
}

function restoreSnapshot(snapshotDirInput, targetVaultPathInput, signature) {
  assertOutOfBandLocation();
  if (!signature || String(signature).trim().length < 4) {
    throw new Error('RESTORE DENIED: manual developer signature is required.');
  }
  const snapshotDir = resolveExistingPath(snapshotDirInput, 'Snapshot');
  const targetVaultPath = resolveExistingPath(targetVaultPathInput, 'Target vault');
  assertVaultRoot(targetVaultPath);
  assertObsidianClosed(targetVaultPath);
  const { manifest } = loadSnapshotManifest(snapshotDir);
  verifySnapshot(snapshotDir);

  ensureDir(QUARANTINE_ROOT);
  ensureDir(REPORT_ROOT);
  const restoreId = `${safeTimestamp()}_restore_${sanitizeLabel(signature)}`;
  const quarantineDir = path.join(QUARANTINE_ROOT, `${restoreId}_pre_restore_quarantine`);
  const quarantineVaultDir = path.join(quarantineDir, 'Continuity_Architecture');

  copyTree(targetVaultPath, quarantineVaultDir);
  const quarantineTree = hashTree(quarantineVaultDir);
  writeJsonAtomic(path.join(quarantineDir, 'quarantine_manifest.json'), {
    manifest_type: 'manual_recovery_quarantine',
    tool_version: TOOL_VERSION,
    created_at: nowIso(),
    restore_id: restoreId,
    target_vault_path: targetVaultPath,
    source_snapshot_id: manifest.snapshot_id,
    developer_signature: String(signature).trim(),
    ...quarantineTree
  });

  const snapshotVaultDir = path.join(snapshotDir, 'Continuity_Architecture');
  removeDirectoryContents(targetVaultPath);
  copyTree(snapshotVaultDir, targetVaultPath);
  const restoredTree = hashTree(targetVaultPath);
  if (restoredTree.tree_hash !== manifest.tree_hash) {
    throw new Error('RESTORE INTEGRITY FAILURE: restored vault hash does not match snapshot. Quarantine has been preserved for manual review.');
  }

  const report = `# Manual Recovery Restore Report\n\n- Restore ID: ${restoreId}\n- Restored At: ${nowIso()}\n- Developer Signature: ${String(signature).trim()}\n- Source Snapshot ID: ${manifest.snapshot_id}\n- Source Snapshot: ${snapshotDir}\n- Target Vault: ${targetVaultPath}\n- Quarantine Path: ${quarantineVaultDir}\n- Restored File Count: ${restoredTree.file_count}\n- Restored Tree Hash: ${restoredTree.tree_hash}\n\n## Boundary\n\nThis recovery was executed manually from admin-tools/recovery with Obsidian closed. The Obsidian plugin runtime does not call this tool and has no recovery authority.\n`;
  writeFileAtomic(path.join(REPORT_ROOT, `restore_${restoreId}.md`), report);

  console.log('[SUCCESS] Restore completed and verified.');
  console.log(`[RESTORE] Target vault: ${targetVaultPath}`);
  console.log(`[RESTORE] Quarantine copy: ${quarantineVaultDir}`);
  console.log(`[VERIFY] Restored tree hash: ${restoredTree.tree_hash}`);
}

function printHelp() {
  console.log(`Manual Recovery Manager - External Manual Recovery Tool\n\nUsage:\n  node manual-recovery-manager.js --snapshot <path_to_Continuity_Architecture> [label]\n  node manual-recovery-manager.js --verify-snapshot <path_to_snapshot_folder>\n  node manual-recovery-manager.js --dry-run-restore <path_to_snapshot_folder> <path_to_Continuity_Architecture>\n  node manual-recovery-manager.js --restore <path_to_snapshot_folder> <path_to_Continuity_Architecture> "<Developer Signature>"\n\nRules:\n  - Run manually from terminal only.\n  - Close Obsidian before snapshot or restore.\n  - The plugin runtime must never call this tool.\n  - Restore quarantines the current target before replacing it.\n`);
}

function main() {
  ensureDir(SNAPSHOT_ROOT);
  ensureDir(QUARANTINE_ROOT);
  ensureDir(REPORT_ROOT);
  const args = process.argv.slice(2);
  const cmd = args[0];
  try {
    if (cmd === '--snapshot') return snapshotVault(args[1], args[2]);
    if (cmd === '--verify-snapshot') return verifySnapshot(args[1]);
    if (cmd === '--dry-run-restore') return dryRunRestore(args[1], args[2]);
    if (cmd === '--restore') return restoreSnapshot(args[1], args[2], args[3]);
    printHelp();
  } catch (err) {
    console.error(`[ERROR] ${err.message}`);
    process.exitCode = 1;
  }
}

main();
