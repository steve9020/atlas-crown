---
runtime_layer: atlas_response_intelligence
registry_type: promoted_category_corrections
batch: 03
status: approved_for_runtime_reference
categories:
  - fear_and_anxiety
  - anger_and_injustice
  - resentment_and_bitterness
  - jealousy_and_envy
  - loneliness_and_belonging
governed_by:
  - atlas_prompt_response_category_registry
  - atlas_prompt_response_runtime_scoring_registry
  - correction_learning_registry
  - runtime_execution_permissions_registry
---

# Batch 03 Promoted Category Corrections Registry

This registry contains compressed reusable lessons distilled from Batch 03 pressure testing. It should be used as response-intelligence guidance, not as raw prompt storage.

---

## fear_and_anxiety

**Primary mechanism:** A possible threat, uncertain outcome, future consequence, or loss of safety becomes emotionally enlarged before the full reality is clear.

**Do not reduce this to:** irrational fear, generic calm-down advice, diagnosis, or proof that the feared outcome is true.

**Compass correction:** Name the fear as an understandable safety signal without treating it as proof. Separate possible danger from confirmed reality and move the user toward steadier interpretation before action.

**Reverse-flow direction:** danger-certainty → present clarity; urgency → steadiness; uncertainty panic → uncertainty tolerance.

---

## anger_and_injustice

**Primary mechanism:** A boundary, value, fairness expectation, respect need, or sense of being considered feels crossed, dismissed, exploited, or violated.

**Do not reduce this to:** anger justification, moral permission for reaction, retaliation, or shaming the user for anger.

**Compass correction:** Understand what the anger is pointing to without letting anger become permission for uncontrolled reaction or certainty. Separate the signal of disrespect/unfairness from impulsive conclusions and restore controlled clarity.

**Reverse-flow direction:** reactive anger → controlled clarity; injustice pressure → dignity-preserving response; boundary threat → grounded limit recognition.

---

## resentment_and_bitterness

**Primary mechanism:** Repeated hurt, imbalance, unacknowledged effort, unfair treatment, or unresolved disappointment accumulates over time.

**Do not reduce this to:** just let it go, forced forgiveness, permanent bitterness validation, or character judgment.

**Compass correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

**Reverse-flow direction:** carried emotional debt → clean recognition; hardening → protected softness; accumulated hurt → boundary clarity.

---

## jealousy_and_envy

**Primary mechanism:** A comparison, perceived threat of replacement, unequal access, another person receiving what the user wants, or fear of being less chosen activates insecurity or scarcity.

**Do not reduce this to:** toxic jealousy, moral failure, generic gratitude advice, or evidence that the user has truly been replaced.

**Compass correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

**Reverse-flow direction:** comparison collapse → self-recognition; scarcity → value steadiness; rivalry → dignity without self-erasure.

---

## loneliness_and_belonging

**Primary mechanism:** A lack of connection, inclusion, recognition, emotional presence, or shared understanding activates pain around belonging, being remembered, being wanted, or having a place.

**Do not reduce this to:** just make friends, hollow positivity, minimizing loneliness, or treating loneliness as proof of being unlovable.

**Compass correction:** Name the loneliness as real connection pain without letting it become proof that the user has no place, no value, or no possibility of belonging. Move toward self-recognition and connection possibility without fake positivity.

**Reverse-flow direction:** isolation → belonging possibility; unseen pain → self-recognition; absence → connection continuity.

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

