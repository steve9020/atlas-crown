# Identity Reverse Flows

## Core Identity Reverse Flow

Identity Threat
→ Awareness
→ Reflection
→ Separation of Event from Identity
→ Recalibration
→ Behavioral Alignment
→ Identity Stabilization

---

## Defensive Identity Reverse Flow

Perceived Invalidation
→ Pause
→ Emotional Regulation
→ Clarification
→ Reduced Defensiveness
→ Identity Stability

---

## Identity Fragmentation Reverse Flow

Contradiction
→ Contradiction Tolerance
→ Reflection
→ Integration
→ Reduced Fragmentation
→ Identity Reintegration

---

## Identity Rigidity Reverse Flow

Rigid Self-Protection
→ Awareness
→ Perspective Flexibility
→ Reassessment
→ Adaptive Adjustment
→ Increased Continuity Stability

---

## Core Principle

Identity reverse flows describe how destabilized or threatened identity systems can shift toward reflection, recalibration, integration, and adaptive continuity stabilization.

## Connected Nodes

- [[Identity]]
- [[Shame]]
- [[Self-Worth]]
- [[Authenticity|Authenticity]]
- [[Grounded Confidence]]
- [[Healthy Autonomy]]
- [[Identity Calcification]]