const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');

const ROOT = path.join(__dirname, '..');
function read(relPath) { return fs.readFileSync(path.join(ROOT, relPath), 'utf8'); }
function exists(relPath) { return fs.existsSync(path.join(ROOT, relPath)); }
function sha256(relPath) { return crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT, relPath))).digest('hex'); }
function walk(dir) { const out=[]; for (const entry of fs.readdirSync(dir,{withFileTypes:true})) { const full=path.join(dir,entry.name); if (entry.isDirectory()) out.push(...walk(full)); else out.push(full); } return out; }
function rel(file) { return path.relative(ROOT, file).replace(/\\/g, '/'); }

const protectedRuntimeFiles = [
  'runtime/validation/InputValidator.js',
  'runtime/backend/adapter/OllamaLiveLocalCallContainment.js',
  'runtime/backend/adapter/OllamaAdapterDryRunShell.js',
  'runtime/governance/GovernanceAdapter.js',
  'Cognition/quality/ResponseQualityChecker.js',
  'runtime/trace/TraceLogger.js',
  'runtime/understanding/ContextObjectConstructionEngine.js',
  'runtime/pipeline/ResponsePipeline.js'
];
const beforeHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));

const requiredFiles = [
  'docs/TRUST_DEMO_EXTERNAL_REVIEW_HANDOFF_FREEZE_POINT.md',
  'docs/MASTERSTEP116_TRUST_DEMO_EXTERNAL_REVIEW_HANDOFF_FREEZE_POINT.md',
  'runtime/proof/MASTERSTEP116_TRUST_DEMO_EXTERNAL_REVIEW_HANDOFF_FREEZE_POINT.md',
  'runtime/proof/MASTERSTEP116_TRUST_DEMO_EXTERNAL_REVIEW_HANDOFF_FREEZE_POINT.json',
  'tests/masterStep116TrustDemoExternalReviewHandoffFreezePointTest.js',
  'docs/TRUST_DEMO_EXTERNAL_REVIEW_FINAL_READINESS_GATE.md',
  'docs/TRUST_DEMO_EXTERNAL_REVIEW_PACKET_INDEX.md',
  'docs/TRUST_DEMO_REVIEWER_RUNBOOK.md',
  'docs/TRUST_DEMO_EXTERNAL_REVIEW_SUBMISSION_GUARD.md',
  'docs/TRUST_DEMO_EXTERNAL_REVIEW_PACKET_COMPLETENESS_AUDIT.md',
  'docs/TRUST_DEMO_TRACE_WALKTHROUGH.md',
  'docs/TRUST_DEMO_FAILURE_MODE_READINESS.md',
  'runtime/proof/CURRENT_PROOF_SUMMARY.md',
  'runtime/proof/PROOF_STATE.json',
  'runtime/proof/ENGINEERING_PROOF_INDEX.md',
  'tests/TEST_RESULTS.md',
  'tests/VERSION_STATUS.json',
  'version_status.js'
];
for (const file of requiredFiles) assert.ok(exists(file), `required handoff-freeze file missing: ${file}`);

const freezeDoc = read('docs/TRUST_DEMO_EXTERNAL_REVIEW_HANDOFF_FREEZE_POINT.md');
const stepDoc = read('runtime/proof/MASTERSTEP116_TRUST_DEMO_EXTERNAL_REVIEW_HANDOFF_FREEZE_POINT.md');
const proofJson = JSON.parse(read('runtime/proof/MASTERSTEP116_TRUST_DEMO_EXTERNAL_REVIEW_HANDOFF_FREEZE_POINT.json'));
const packetIndex = read('docs/TRUST_DEMO_EXTERNAL_REVIEW_PACKET_INDEX.md');
const finalGate = read('docs/TRUST_DEMO_EXTERNAL_REVIEW_FINAL_READINESS_GATE.md');
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
const state = JSON.parse(read('runtime/proof/PROOF_STATE.json'));
const versionStatus = JSON.parse(read('tests/VERSION_STATUS.json'));
const versionJs = read('version_status.js');
const testResults = read('tests/TEST_RESULTS.md');

assert.ok(/Current keeper: Masterstep116\.zip/i.test(freezeDoc), 'freeze point must identify current keeper');
assert.ok(/Source keeper: Masterstep115\.zip/i.test(freezeDoc), 'freeze point must identify source keeper');
assert.ok(/38\/38 passed/i.test(freezeDoc), 'freeze point must state expected 38/38 result');
assert.ok(/handoff freeze point/i.test(freezeDoc), 'freeze point must name handoff freeze scope');
assert.ok(/Handoff rule/i.test(freezeDoc), 'freeze point must include handoff rule');
assert.ok(/single reviewer start point/i.test(freezeDoc), 'freeze point must preserve single reviewer start point');
assert.ok(/local governed clarity system/i.test(freezeDoc), 'freeze point must preserve supported claim');
assert.ok(/candidate source without becoming the authority/i.test(freezeDoc), 'freeze point must preserve authority boundary');
assert.ok(/candidate-only|contained candidate/i.test(freezeDoc), 'freeze point must preserve candidate boundary');
assert.ok(/Raw model output is not final Atlas output/i.test(freezeDoc), 'freeze point must preserve raw-not-final boundary');
assert.ok(/fail closed/i.test(freezeDoc), 'freeze point must preserve fail closed boundary');
assert.ok(/No cloud\/provider fallback/i.test(freezeDoc), 'freeze point must preserve no cloud/provider fallback boundary');
assert.ok(/not production readiness/i.test(freezeDoc), 'freeze point must reject production readiness');
assert.ok(/not exhaustive prompt coverage/i.test(freezeDoc), 'freeze point must reject exhaustive coverage');
assert.ok(/hidden chat-window context/i.test(freezeDoc), 'freeze point must reject hidden chat-window dependency');

assert.strictEqual(proofJson.package, 'Masterstep116', 'proof JSON must identify Masterstep116');
assert.strictEqual(proofJson.source_keeper, 'Masterstep115', 'proof JSON must identify source keeper');
assert.strictEqual(proofJson.expected_commands, 38, 'proof JSON must expect 38 commands');
assert.strictEqual(proofJson.boundaries.external_review_handoff_freeze_point_only, true, 'Step116 must be handoff-freeze only');
assert.strictEqual(proofJson.boundaries.runtime_behavior_changed, false, 'Step116 must not change runtime behavior');
assert.strictEqual(proofJson.boundaries.model_use_expanded, false, 'Step116 must not expand model use');
assert.strictEqual(proofJson.boundaries.model_authority_added, false, 'Step116 must not add model authority');
assert.strictEqual(proofJson.boundaries.raw_model_output_final_allowed, false, 'Step116 must not allow raw model output as final');
assert.strictEqual(proofJson.boundaries.cloud_provider_fallback_allowed, false, 'Step116 must not allow cloud/provider fallback');
assert.strictEqual(proofJson.boundaries.public_network_binding_allowed, false, 'Step116 must not allow public network binding');
assert.strictEqual(proofJson.boundaries.frontend_intelligence_added, false, 'Step116 must not add frontend intelligence');
assert.strictEqual(proofJson.boundaries.silent_mutation_allowed, false, 'Step116 must not allow silent mutation');
assert.strictEqual(proofJson.boundaries.production_readiness_claimed, false, 'Step116 must not claim production readiness');
assert.strictEqual(proofJson.boundaries.exhaustive_coverage_claimed, false, 'Step116 must not claim exhaustive coverage');

assert.ok(/TRUST_DEMO_EXTERNAL_REVIEW_HANDOFF_FREEZE_POINT\.md/i.test(packetIndex), 'packet index must include handoff freeze point');
assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
assert.ok(/Expected command count: 38/i.test(summary), 'current summary must identify 38 commands');
assert.ok(['Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 116), 'proof state must identify Masterstep116 or later current keeper');
assert.ok(['Masterstep115.zip','Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 115) || state.source_keeper === 'Masterstep141.zip', 'proof state must identify source keeper');
assert.ok(acceptsCurrentProofCount(state.expected_commands, 38), state.expected_commands);
assert.strictEqual(state.external_review_handoff_freeze_point_created, true, 'proof state must mark handoff freeze point');
assert.ok(['Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(versionStatus.current_keeper) || isValidLaterKeeper(versionStatus.current_keeper, 116), 'version status must identify Masterstep116 or later current keeper');
assert.ok(['Masterstep115.zip','Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(versionStatus.source_keeper) || isValidLaterKeeper(versionStatus.source_keeper, 115) || versionStatus.source_keeper === 'Masterstep141.zip', 'version status must identify source keeper');
assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 38), versionStatus.expected_current_proof_commands);
assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs), 'version_status.js must identify current keeper compatibility');
assert.ok(/TEST 116/i.test(testResults), 'test ledger must include TEST 116');
assert.ok(/External Review Handoff Freeze Point/i.test(testResults), 'test ledger must identify handoff freeze point');
assert.ok(/38\/38 commands|39\/39 commands|40\/40 commands|41\/41 commands/i.test(testResults), 'test ledger must record 38/38 command target');

for (const doc of [freezeDoc, stepDoc, summary, packetIndex, finalGate]) {
  assert.ok(assertNoForbiddenAffirmativeClaims(doc).ok, 'handoff freeze docs must not include forbidden overclaim or authority language');
}

const providerScan = scanForProviderConnections(ROOT);
assert.strictEqual(providerScan.passed, true, 'handoff freeze point must not introduce provider/network bridge findings');
const allFiles = walk(ROOT).map(rel);
const nestedArchives = allFiles.filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
assert.strictEqual(nestedArchives.length, 0, 'handoff freeze package must not contain nested archives');
const forbiddenEmbedded = allFiles.filter(file => /(node_modules|\.env$|ollama(?:\.exe)?$|llama3\.2.*\.(bin|gguf|safetensors)|api[_-]?key)/i.test(file));
assert.deepStrictEqual(forbiddenEmbedded, [], 'handoff freeze must not embed runner binaries, model weights, dependency folders, or keys');

const afterHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));
const mutatedRuntimeFiles = protectedRuntimeFiles.filter(file => beforeHashes[file] !== afterHashes[file]);
assert.deepStrictEqual(mutatedRuntimeFiles, [], 'handoff freeze test must not mutate protected runtime/governance/quality/adapter files');

console.log(JSON.stringify({
  package: 'Masterstep116',
  source_keeper: 'Masterstep115',
  step: 'Trust Demo External Review Handoff Freeze Point',
  proof_target: '38/38',
  external_review_handoff_freeze_point_created: true,
  provider_scan_passed: providerScan.passed === true,
  nested_archives: nestedArchives.length,
  forbidden_embedded_artifacts: forbiddenEmbedded.length,
  protected_runtime_mutations: mutatedRuntimeFiles.length,
  boundary_preserved: true
}, null, 2));
