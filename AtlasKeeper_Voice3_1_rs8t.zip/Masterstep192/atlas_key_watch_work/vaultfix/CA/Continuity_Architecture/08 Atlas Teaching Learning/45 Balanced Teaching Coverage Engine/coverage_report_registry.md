# Coverage Report Registry

## Purpose
Creates visibility into what Atlas has and has not tested.

## Report Should Show
- least-covered categories
- least-covered families
- most-covered categories
- most-covered families
- recommended next categories
- current imbalance risk

## Rule
Auto teaching should make its coverage visible so gaps are not hidden.
