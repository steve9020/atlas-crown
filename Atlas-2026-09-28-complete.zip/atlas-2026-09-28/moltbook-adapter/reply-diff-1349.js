'use strict';
// One-off: diff inbound comments on own posts vs seen map + Atlas replies (beat 13:49).
const fs = require('fs');
const { api } = require('./api.js');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function flat(tree, out) { out = out || []; for (const c of (tree || [])) { out.push(c); if (c.replies) flat(c.replies, out); } return out; }
async function call(fn, label) {
  for (let i = 0; i < 4; i++) {
    try { return await fn(); } catch (e) { console.log(label, 'try', i + 1, 'FAIL:', e.message); await sleep(8000); }
  }
  return null;
}
(async () => {
  const state = JSON.parse(fs.readFileSync('state.json', 'utf8'));
  const seen = state.seen || {};
  for (const [name, id] of [
    ['plumbing', 'e22c4c95-5966-4d81-be66-1756b7be4184'],
    ['coupling', '047db6ed-e7ed-4358-b675-63eab9953105'],
    ['bdi', '0fa62225-4566-491e-acfc-ec46a2fe9a0f'],
  ]) {
    const cr = await call(() => api.comments(id, { limit: 40 }), name);
    if (!cr) { console.log(name.toUpperCase(), 'FETCH FAILED'); continue; }
    const items = (cr.data && (cr.data.comments || cr.data)) || [];
    const f = flat(items);
    const atlasByParent = new Set();
    f.forEach((c) => {
      const a = c.author && (c.author.name || c.author);
      if (a === 'compass_crown_atlas' && c.parent_id) atlasByParent.add(String(c.parent_id));
    });
    const pending = [];
    f.forEach((c) => {
      const a = c.author && (c.author.name || c.author);
      if (a === 'compass_crown_atlas') return;
      if (atlasByParent.has(String(c.id))) return; // answered
      if (seen['c:' + c.id]) return; // seen
      pending.push(c);
    });
    console.log('=== ' + name.toUpperCase() + ' PENDING: ' + pending.length);
    pending.forEach((c) => {
      const a = c.author && (c.author.name || c.author);
      console.log(JSON.stringify({
        post: id, parentId: c.id, by: a,
        text: String(c.content || c.body || '').slice(0, 2000),
      }));
    });
  }
})().catch((e) => console.error('FATAL', e.message));
