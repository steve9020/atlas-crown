# Auto Teaching Workspace View Mount

## Purpose
Auto Teaching now opens as:
- a left ribbon icon
- its own Obsidian workspace pane
- a separate tab/window view

## Result
Compass remains separate while Auto Teaching behaves like a native operational workspace.
