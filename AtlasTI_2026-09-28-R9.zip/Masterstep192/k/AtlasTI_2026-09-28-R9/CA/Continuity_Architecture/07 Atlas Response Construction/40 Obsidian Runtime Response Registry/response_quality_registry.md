# Response Quality Registry

Purpose: stores Compass response-quality rules in the Obsidian backend so runtime code remains a generic quality-rule evaluator instead of owning Atlas/Compass-specific quality requirements.

Boundary: this registry may declare structural quality rules, issue identifiers, and separation-language patterns. It may not bypass governance, diagnose, mutate backend files, create authority, rewrite output, or treat quality checks as truth claims.

Runtime use: `ResponseQualityChecker.js` reads this JSON registry and applies generic quality checks to the response string. The checker reports pass/fail and issue IDs only; it does not rewrite the response.

```json
{
  "version": "OBSIDIAN_RESPONSE_QUALITY_REGISTRY_STAGE5",
  "qualityMode": "generic_structural_rule_evaluation",
  "rules": [
    {
      "id": "response_body_present_without_fixed_visible_template",
      "type": "minimum_structure_count",
      "minimum": 1,
      "issue": "response_body_missing"
    },
    {
      "id": "minimum_response_length",
      "type": "minimum_character_length",
      "minimum": 120,
      "issue": "response_too_short"
    },
    {
      "id": "separation_language_present",
      "type": "regex_any",
      "patterns": [
        "\\bbut\\b",
        "\\bwithout\\b",
        "\\bbefore\\b",
        "\\binstead of\\b",
        "\\brather than\\b",
        "\\bdoes not\\b",
        "\\bdoesn't\\b",
        "\\bcan still\\b",
        "\\bstill needs more clarity\\b",
        "\\bwhile you sort through\\b",
        "\\bnot .* automatically\\b"
      ],
      "flags": "i",
      "issue": "missing_separation_language"
    }
  ],
  "nonMutationRule": "Quality checks report issues only. They do not rewrite output, bypass governance, diagnose, or claim truth."
}
```
