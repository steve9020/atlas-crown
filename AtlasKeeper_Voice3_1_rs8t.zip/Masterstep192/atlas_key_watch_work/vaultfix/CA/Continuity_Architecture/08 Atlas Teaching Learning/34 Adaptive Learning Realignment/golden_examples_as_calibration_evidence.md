# Golden Examples as Calibration Evidence

Golden examples are not hard-coded response scripts. They are evidence of the desired Compass movement.

They may teach:
- how the response sees the emotional input;
- how it separates active attachments from possible attachments;
- how it restores through reverse-flow;
- how it keeps human voice without robotic wording.

They may not:
- override routing;
- override depth;
- become fixed templates;
- become authority;
- integrate without approval.
