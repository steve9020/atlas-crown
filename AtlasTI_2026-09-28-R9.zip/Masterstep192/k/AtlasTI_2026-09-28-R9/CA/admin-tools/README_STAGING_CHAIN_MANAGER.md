# Staging Chain Manager

This folder is intentionally outside the active Obsidian vault folder.

Hard boundary:

- Do not move `staging-chain-manager.js` into `.obsidian/plugins/continuity-interface/`.
- Do not call this script from `main.js`.
- Do not let Atlas/Compass sign, approve, or commit ledger blocks.
- Run this manually from a terminal only.

## Commands

Verify ledger integrity:

```bash
node staging-chain-manager.js --verify
```

Commit a staged JSON draft after manual approval:

```bash
node staging-chain-manager.js --commit ./draft_sample.json "Steven_Wagner"
```

Run a non-destructive tamper simulation:

```bash
node staging-chain-manager.js --simulate-breach
```

## Draft JSON shape

Minimum example:

```json
{
  "proposal_id": "PR-2026-001",
  "source_module": "realism_fuzz_unit",
  "title": "Nuanced Trailing Punctuation Matrix Shifts",
  "body": "This text updates linguistic trailing weights from static 0.5 to uncertainty-preserving 0.72."
}
```

The approved ledger is stored in `admin-tools/ledger-history/` and remains outside the active runtime path.
