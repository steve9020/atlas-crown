# Growth Percentage Metric Registry

## Metric
Growth %

## Formula
approved + integrated backend updates ÷ reviewed teaching proposals

## Meaning
Growth % measures how much reviewed teaching has moved into approved backend expansion.

## What changes it
- reviewing teaching proposals increases the denominator
- approving and integrating backend updates increases the numerator

## What it must not mean
It must not mean Atlas is a certain percentage intelligent.
