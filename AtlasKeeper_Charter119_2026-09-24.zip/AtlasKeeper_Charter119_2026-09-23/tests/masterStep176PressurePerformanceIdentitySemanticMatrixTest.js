"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const matrix = require("../runtime/understanding/PressurePerformanceIdentityMatrix");
const { buildContextObject } = require("../runtime/understanding/ContextObjectConstructionEngine");
const mixed = require("../runtime/understanding/MixedContextEvidenceSeparationMatrix");
const translation = require("../runtime/understanding/TranslationPreservationMatrix");
const weaver = require("../runtime/compass/CompassOntologyLanguageWeaver");
const registry = require("../runtime/understanding/MatrixMaturityRegistry");

// implementation + fresh paraphrases without the former route phrases
const naturalTargetPrompts = [
  "I keep feeling like I'm not doing enough, even when I finish everything I set out to do.",
  "I got everything done, but I still feel like I failed.",
  "No matter what I do, it never feels like enough.",
  "I put everything into this and somehow it still does not feel like enough.",
  "I give everything I have, but I still feel behind.",
  "I keep pushing and the bar keeps moving.",
  "I checked everything off my list, yet nothing feels finished.",
  "I accomplished what I planned and still cannot feel satisfied.",
  "I did all the work, but it never feels complete.",
  "Even after I meet every goal, I feel like I am falling short.",
  "I keep going no matter how tired I am, and it is still never enough.",
  "I put in so much effort, yet the standard keeps rising.",
  "I reached the goal, but the finish line seems to move again.",
  "I completed everything and still feel like a failure.",
  "I try my best, but I never feel satisfied with what I do.",
  "I poured everything into it and still feel like I did not do enough.",
  "I cleared every box, but nothing ever feels done.",
  "No matter how much I accomplish, I still feel like I am not measuring up."
]
for (const prompt of naturalTargetPrompts) {
  const result = matrix.evaluatePressurePerformanceIdentity({ prompt });
  assert.strictEqual(result.matched, true, prompt);
  assert.strictEqual(result.evidence.effort_or_completion_present, true, prompt);
  assert.strictEqual(result.evidence.felt_insufficiency_after_effort, true, prompt);
  assert.strictEqual(result.evidence.performance_or_output_context_present, true, prompt);
  assert.strictEqual(buildContextObject(prompt).domain, "performance_worth_pressure", prompt);
}

const fresh = [
  "I cleared every item I committed to, yet the finish line moved the moment I reached it.",
  "The work is complete, but my internal measure keeps marking the result as insufficient.",
  "I gave this my best effort and met the goal; somehow that achievement is becoming evidence that I still fall short as a person."
];
for (const prompt of fresh) {
  const result = matrix.evaluatePressurePerformanceIdentity({ prompt });
  assert.strictEqual(result.matched, true, prompt);
  assert.strictEqual(result.evidence.performance_or_output_context_present, true);
  assert.strictEqual(result.evidence.effort_or_completion_present, true);
  assert.strictEqual(result.evidence.felt_insufficiency_after_effort, true);
  assert(result.confidence >= 0.72);
  assert.strictEqual(buildContextObject(prompt).domain, "performance_worth_pressure");
  assert(mixed.inferContextsFromPrompt(prompt).some(x => x.id === "performance_worth_pressure_context"));
}

// adversarial overlap and practical exclusions
const negatives = [
  "They rejected me and now I feel like I am not good enough.",
  "Everyone else is ahead of me and I feel behind them.",
  "Show me the command to finish the package and run the test.",
  "I made a mistake and feel ashamed.",
  "I finished dinner and it was enough."
];
for (const prompt of negatives) assert.strictEqual(matrix.evaluatePressurePerformanceIdentity({ prompt }).matched, false, prompt);

// worth attachment is evidence-sensitive, not automatically asserted
const noWorth = matrix.evaluatePressurePerformanceIdentity({ prompt: fresh[0] });
assert.strictEqual(noWorth.evidence.worth_or_identity_attachment_present, false);
assert(noWorth.unresolved.some(x => /worth or identity/.test(x)));
const explicitWorth = matrix.evaluatePressurePerformanceIdentity({ prompt: fresh[2] });
assert.strictEqual(explicitWorth.evidence.worth_or_identity_attachment_present, true);

// output preservation and narrow profile mapping
const units = translation.evaluateTranslationPreservationMatrix({ prompt: fresh[1], finalCompassOutput: "Your effort and completed output are real. The internal threshold moved after the work was complete. The moving threshold is not the same thing as the work disappearing." });
assert.strictEqual(units.ok, true);
assert.notStrictEqual(weaver.chooseProfileName({ active_relation: "self_worth_value_threat" }, {}), "performance_worth_pressure");
assert.strictEqual(weaver.chooseProfileName({ active_relation: "performance_worth_pressure" }, {}), "performance_worth_pressure");

// freeze audit: one authoritative decision module; no duplicated old route regexes
for (const file of ["ContextObjectConstructionEngine.js", "MixedContextEvidenceSeparationMatrix.js", "TranslationPreservationMatrix.js"]) {
  const text = fs.readFileSync(path.join(__dirname, "../runtime/understanding", file), "utf8");
  assert(text.includes("PressurePerformanceIdentityMatrix"));
  assert(!/not doing enough\|never doing enough\|never good enough/.test(text));
}
const family = registry.findFamilyById("pressure_performance_identity_matrix");
assert.strictEqual(family.status, "frozen");
assert.deepStrictEqual(family.stagesCompleted, ["select", "implement", "fresh_regression", "output_preservation", "freeze_audit"]);
const boundaries = registry.getMatrixMaturityRegistry().boundaries;
assert.strictEqual(boundaries.newMatrixCapabilityAdded, true);
assert.strictEqual(boundaries.runtimeClassificationChangedForNewDomain, true);
assert.strictEqual(boundaries.compassOutputBehaviorAddedForNewDomain, true);
console.log("MASTERSTEP176 PRESSURE / PERFORMANCE / IDENTITY SEMANTIC MATRIX TEST PASSED");
