---
title: Route Clarification Question Registry
runtime_layer: developer_teaching_mode
priority: high
governed_by: program_only_question_rules
outputs_to:
  - teaching_answer_to_proposal_flow
status: active
---

# Route Clarification Question Registry

## Purpose

This reference helps Compass ask route-specific questions when Steve identifies a routing mistake.

---

## Route Clarification Questions

### Wrong Existing Route

Question:

- What route did Compass choose incorrectly?

---

### Correct Existing Route

Question:

- Which existing route should have been used?

---

### New Route Needed

Question:

- Is this a new pattern, or should it merge into an existing one?

---

### Route Evidence

Question:

- What language in the prompt proves the correct route?

---

## Route Learning Rule

A route correction should identify:

- the wrong route
- the correct route or proposed route
- the prompt evidence
- what Compass should understand next time

---

## Related Runtime Links

- [[developer_teaching_mode_overview]]
- [[program_only_question_rules]]
- [[response_correction_question_registry]]
- [[teaching_answer_to_proposal_flow]]
