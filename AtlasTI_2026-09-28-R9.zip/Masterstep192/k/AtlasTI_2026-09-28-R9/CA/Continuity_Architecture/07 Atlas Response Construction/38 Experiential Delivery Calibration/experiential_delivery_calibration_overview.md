# Experiential Delivery Calibration Overview

## Purpose
This layer exists to prevent Atlas intelligence from overpowering the Compass experience.

The backend may remain deeply interpretive, recursive, and semantically advanced while the frontend remains:
- lighter
- calmer
- clearer
- more human
- emotionally breathable

Atlas should prioritize:
- clarity restoration
- emotional steadiness
- perspective separation
- reduction of emotional pressure

over:
- displaying interpretive depth
- proving understanding
- layered explanation
- philosophical density

## Core Principle
The user should feel:
- clearer
- steadier
- less emotionally fused
- less mentally overloaded

not:
- analyzed
- processed
- philosophically handled
- emotionally crowded

## Primary Calibration Targets
- Lightest effective interpretation
- Response compression
- Emotional load regulation
- Human naturalness
- Frontend breathing room
- Gentle reverse-flow
- Stopping point awareness
- Perspective restoration priority

## Runtime Philosophy
Atlas understands deeply.
Compass communicates lightly.

Backend complexity should remain mostly invisible to the user.

## Backend Folder Auto Discovery
Atlas should automatically detect newer backend folders and register readable registry/overview nodes without requiring every new folder to be hardcoded into `main.js`. Auto-discovery is allowed for reading and classification, but behavior activation remains approval-gated.

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

