const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { STEP, PUBLIC_DEMO_FILES, auditPublicDemoShell, buildPublicDemoShellPlan } = require('../runtime/review/PublicDemoShellBoundaryPlan');

const projectRoot = path.resolve(__dirname, '..');
const audit = auditPublicDemoShell(projectRoot);
assert.strictEqual(audit.ok, true, `public demo shell audit failed: ${audit.failures.join('; ')}`);
assert.strictEqual(STEP.number, 163);
assert.strictEqual(STEP.keeper, 'Masterstep163.zip');
assert.strictEqual(STEP.sourceKeeper, 'Masterstep162.zip');
assert.strictEqual(STEP.expectedCommands, 85);
assert.strictEqual(STEP.currentManifest, 'proof/results/MASTERSTEP163_CURRENT_PROOF_MANIFEST.json');

for (const required of PUBLIC_DEMO_FILES){
  assert.ok(audit.files.includes(required), `missing required public demo file: ${required}`);
}

const forbiddenRoots = ['runtime/', 'Cognition/', 'CA/', 'proof/', 'tests/', '.obsidian/', 'atlas_key_watch_work/', 'vaultfix/'];
for (const rel of audit.files){
  for (const forbidden of forbiddenRoots){
    assert.ok(!rel.startsWith(forbidden), `public demo shell exposes forbidden root: ${rel}`);
  }
  assert.ok(!/\.(js|mjs|cjs|ts|tsx|log|zip|7z|rar|tar|gz)$/i.test(rel), `public demo shell exposes forbidden file type: ${rel}`);
}

const manifest = JSON.parse(fs.readFileSync(path.join(projectRoot, 'public_demo_shell', 'DEMO_MANIFEST.json'), 'utf8'));
assert.strictEqual(manifest.public_demo_shell_only, true);
assert.strictEqual(manifest.backend_source_included, false);
assert.strictEqual(manifest.backend_runtime_connected, false);
assert.strictEqual(manifest.model_connected, false);
assert.strictEqual(manifest.raw_model_output_possible, false);
assert.strictEqual(manifest.private_vault_included, false);
assert.strictEqual(manifest.proof_internals_included, false);
assert.strictEqual(manifest.scrapeable_governance_internals_included, false);
assert.strictEqual(manifest.production_ready_claimed, false);

const app = fs.readFileSync(path.join(projectRoot, 'public_demo_shell', 'app.py'), 'utf8');
assert.ok(app.includes('NO_BACKEND_RUNTIME'));
assert.ok(app.includes('SAFE_SYNTHETIC_RESPONSES'));
assert.ok(!/openai|anthropic|ollama|requests|httpx|socket|subprocess|os\.system|eval\(|exec\(/i.test(app), 'app.py must not contain provider/network/process/eval surface');

const plan = buildPublicDemoShellPlan();
assert.strictEqual(plan.host_target, 'Hugging Face Spaces with Gradio SDK');
assert.ok(plan.forbidden_behavior.includes('real Atlas backend execution'));
assert.ok(plan.forbidden_behavior.includes('internal runtime exposure'));
assert.ok(plan.posting_path.includes('Upload only the public_demo_shell files'));

const contract = JSON.parse(fs.readFileSync(path.join(projectRoot, 'runtime/proof/CURRENT_PROOF_CONTRACT.json'), 'utf8'));
assert.ok(contract.step_number >= 163);
assert.ok(/^Masterstep(?:16[3-9]|17[0-9]|1[89][0-9])\.zip$/.test(contract.current_keeper));
assert.ok(/^Masterstep(?:16[2-9]|17[0-9]|1[89][0-9])(?:_repaired\d*)?\.zip$/.test(contract.source_keeper));
assert.ok(contract.expected_commands >= 85);
assert.strictEqual(contract.current_manifest, `proof/results/MASTERSTEP${contract.step_number}_CURRENT_PROOF_MANIFEST.json`);
assert.strictEqual(contract.expected_package_root, contract.current_keeper.replace(/\.zip$/i, ''));
assert.strictEqual(contract.public_demo_shell_boundary_planned, true);
assert.strictEqual(contract.public_demo_backend_intelligence_exposed, false);
assert.strictEqual(contract.public_demo_runtime_connected, false);
assert.strictEqual(contract.public_demo_model_connected, false);

console.log('Masterstep163 Public Demo Shell Boundary Plan passed');
