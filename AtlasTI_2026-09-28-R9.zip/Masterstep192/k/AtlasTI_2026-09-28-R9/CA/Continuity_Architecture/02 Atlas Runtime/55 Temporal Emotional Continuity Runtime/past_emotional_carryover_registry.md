# Past Emotional Carryover Registry

## Purpose
Detects when old emotional meaning is still active in present interpretation.

## Signals
- from my past
- old pain
- old wound
- still carry this
- from childhood
- back then
- years ago
- brought this with me

## Rule
Past carry-over should be treated as active meaning, not just memory.
