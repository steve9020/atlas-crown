const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const version = require('../version_status');

const root = path.resolve(__dirname, '..');
const required = [
  'runtime/backend/model/LocalMockModelAdapter.js',
  'runtime/backend/model/LocalMockModelAdapterProof.js',
  'runtime/proof/MASTERSTEP69_LOCAL_MOCK_MODEL_ADAPTER.json',
  'runtime/proof/MASTERSTEP69_LOCAL_MOCK_MODEL_ADAPTER.md',
  'docs/MASTERSTEP69_LOCAL_MOCK_MODEL_ADAPTER_MAP.md',
  'tests/masterStep69LocalMockModelAdapterTest.js'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(root, rel)), 'missing Step69 artifact: ' + rel);

const proof = JSON.parse(fs.readFileSync(path.join(root, 'runtime/proof/MASTERSTEP69_LOCAL_MOCK_MODEL_ADAPTER.json'), 'utf8'));
assert.strictEqual(proof.passed, true, 'proof JSON must record Step69 pass');
assert.strictEqual(proof.provider_connected, false, 'provider must remain disconnected');
assert.strictEqual(proof.model_connected, false, 'real model must remain disconnected');
assert.strictEqual(proof.local_mock_model_adapter_added, true, 'local mock adapter must be added');
assert.strictEqual(proof.real_model_connected, false, 'real model must not connect');
assert.strictEqual(proof.api_keys_added, false, 'no API keys');
assert.strictEqual(proof.endpoints_added, false, 'no endpoints');
assert.strictEqual(proof.network_bridge_added, false, 'no network bridge');
assert.strictEqual(proof.frontend_intelligence_added, false, 'no frontend intelligence');
assert.strictEqual(proof.required_chain_evidence.atlas_validation_decides_candidate_existence, true, 'Atlas must decide candidate existence');
assert.strictEqual(proof.required_chain_evidence.bad_candidates_blocked, true, 'bad mock candidates must be blocked');
assert.strictEqual(proof.decision, 'CLOSE_STEP_69_AND_MOVE_TO_STEP_70');

assert.strictEqual(version.currentKeeper, 'Masterstep69', 'version_status currentKeeper must be Masterstep69');
assert.strictEqual(version.previousKeeper, 'Masterstep68', 'version_status previousKeeper must be Masterstep68');
assert.strictEqual(version.step, 'Local Mock Model Adapter', 'version_status step must be Step69 title');
assert.strictEqual(version.aiConnected, false, 'AI must remain disconnected');
assert.strictEqual(version.providerConfigured, false, 'provider must remain unconfigured');
assert.strictEqual(version.providerWrapperExecutionEnabled, false, 'provider wrapper execution must remain disabled');
assert.strictEqual(version.networkBridgeEnabled, false, 'network bridge must remain disabled');
assert.strictEqual(version.frontendIntelligenceAllowed, false, 'frontend intelligence must remain blocked');
assert.strictEqual(version.backendOwnsIntelligence, true, 'backend ownership must remain true');
assert.strictEqual(version.localMockModelAdapterAdded, true, 'Step69 must add local mock model adapter');
assert.strictEqual(version.modelAdapterAdded, true, 'Step69 must mark model adapter slot added');
assert.strictEqual(version.realModelConnected, false, 'Step69 must not connect a real model');
assert.strictEqual(version.localOfflineModelConnected, false, 'Step69 must not connect local offline model');
assert.strictEqual(version.cloudProviderEvaluationStarted, false, 'Step69 must not start cloud provider evaluation');
assert.strictEqual(version.nextTarget, 'Masterstep70 — Local Offline Model Sandbox', 'next target must be Step70');

console.log('masterStep69FullClosureKeeperReadinessTest PASSED');
