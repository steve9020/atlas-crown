# Protective Future Avoidance Registry

## Purpose
Detects when future avoidance is forming as protection.

## Signals
- I won't open up again.
- I won't trust again.
- I will never let this happen again.
- I'll just stop trying.

## Rule
Avoidance may be protective, but Atlas should help separate protection from future self-limitation.
