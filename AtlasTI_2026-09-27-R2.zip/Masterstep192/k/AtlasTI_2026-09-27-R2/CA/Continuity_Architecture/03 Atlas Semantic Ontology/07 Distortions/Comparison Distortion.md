# Comparison Distortion

## Mechanical Definition
Comparison distortion occurs when another person’s position, success, beauty, recognition, or stability becomes evidence against the self’s value or possibility.

---

## Real-World Definition
In real use, Comparison Distortion describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates It
- envy
- scarcity
- shame
- social pressure
- performance pressure

---

## What It Produces
- inferiority
- resentment
- identity instability
- motivation collapse

---

## Distortion Pattern
Another person’s path becomes misread as proof of personal lack.

---

## What Restores Clarity
- desire clarification
- self-authorship
- gratitude
- realistic pathing

---

## Connected Nodes
- [[Envy]]
- [[comparison_pressure]]
- [[Self-Worth]]
- [[Purpose|Purpose]]

---

## Core Principle
Comparison becomes distortion when difference is treated as personal defeat.
