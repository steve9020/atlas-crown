'use strict';
// idea-sweep-2026-09-26-1455-quar.js — read-only: check the ummon_core quarantine trigger.
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
(async () => {
  const r = await api.post('33306125-3e1a-4f38-8a2a-1a40e0f37cf5'.replace('3e1a','0e1a')).catch(e => null);
  console.log('probe');
})();
