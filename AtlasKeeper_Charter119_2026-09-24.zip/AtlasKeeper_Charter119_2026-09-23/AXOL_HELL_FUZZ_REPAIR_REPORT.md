# AXOL Hell-Fuzz Repair Report

## Scope
Backend AXOL detection/evidence only. Frontend, Crown/governance authority, routing authority, and commercial packaging were not changed.

## Baseline preserved
Original hell-fuzz baseline: 72/97 expected detections (74.2%), 13/18 attribution checks, 7/12 neutral lexical traps false-positive.

## Systemic repair
- Added rule-local `excludePatterns` support to AxisEngine so registry rules can suppress known lexical homonyms without creating new axes.
- Expanded registry-owned evidence families for observation/evidence, interpretation, intention, expectation, responsibility, boundary, trust, respect, fairness, comparison, causation, effort, outcome, sufficiency, ownership.
- Added subject-bearing evidence patterns where attribution needs a structurally explicit actor.
- Kept actor/reference resolution conservative; unresolved pronouns are not force-bound to named actors.

## Same 90-case corpus after repair
- Expected axis detection: 97/97
- Neutral lexical false-positive cases: 0/12
- Attribution checks: 14/18
- Remaining attribution misses: 4, all involving pronoun/name continuity where the current conservative resolver does not have enough structural evidence to safely force a named antecedent.

## Blind corpus
- 27 new cases
- Expected axis instances: 28/28
- Neutral false-positive cases: 0

## Regression
All existing AXOL test files pass, including attribution, cross-binding, collision, discrimination, reference-resolution, neutral/adversarial, and semantic fuzz tests.

## Canonical proof
100/100 PASS using `node proof/runCurrentProof.js`.

## Maturity boundary
This candidate materially improves detection breadth and lexical discrimination, but it is not promoted as a keeper because the hell-fuzz attribution layer remains 14/18. The correct next target is conservative discourse/reference continuity, not additional axis vocabulary.
