---
runtime_layer: response_weakness_detection
priority: high
owned_by: atlas_teaching_learning
runs_after:
  - compass_response_generation
runs_before:
  - teaching_gap_detection
feeds_into:
  - teaching_gap_detection_runtime_overview
---

# Response Weakness Detection Runtime Overview

## Purpose
Reviews a generated Compass response for likely failure points before or during Auto Teach review.

This runtime does not rewrite Compass directly. It identifies where the response may be weak so Atlas can create a specific, approval-gated teaching path.

## Core rule
A response weakness is not just that the answer sounded bad. A weakness must name what likely failed in the route, card, wording, specificity, softness, or application of backend understanding.

## Weakness examples
- wrong primary route
- wrong callout card
- generic response
- backend language leaked into frontend Compass wording
- prompt-specific details were missed
- self-worth restoration was used before clarification
- clarification routing was under-applied
- protective reactions were missed
- temporal pressure was missed
- relational uncertainty was missed
- response sounded clinical, diagnostic, cold, or overly structural

## Boundary
This runtime flags likely weakness. It does not silently update backend knowledge.
