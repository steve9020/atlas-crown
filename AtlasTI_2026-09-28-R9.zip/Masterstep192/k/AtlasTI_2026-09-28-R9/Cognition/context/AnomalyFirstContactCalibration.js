const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const ANOMALY_FIRST_CONTACT_CALIBRATION_REGISTRY_PATH = "CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/anomaly_first_contact_calibration_registry.md";

let cachedAnomalyFirstContactRegistry = null;

function getAnomalyFirstContactRegistry() {
  if (!cachedAnomalyFirstContactRegistry) {
    cachedAnomalyFirstContactRegistry = readJsonRegistry(ANOMALY_FIRST_CONTACT_CALIBRATION_REGISTRY_PATH);
  }
  return cachedAnomalyFirstContactRegistry;
}

function normalizeInput(input) { return String(input || "").toLowerCase(); }
function phraseMatches(text, phrase) { return typeof phrase === "string" && phrase.length > 0 && text.includes(phrase.toLowerCase()); }
function anyPhraseMatches(text, phrases) { return Array.isArray(phrases) && phrases.some((phrase) => phraseMatches(text, phrase)); }
function appendUnique(target, values) {
  if (!Array.isArray(values)) return;
  for (const value of values) {
    if (typeof value === "string" && value.trim() && !target.includes(value)) target.push(value);
  }
}
function ruleMatches(text, rule) {
  const phrases = Array.isArray(rule.phrases) ? rule.phrases : [];
  return phrases.length > 0 && anyPhraseMatches(text, phrases);
}
function collectMatchedRules(text, rules) {
  const matched = [];
  for (const rule of rules) if (rule && rule.id && ruleMatches(text, rule)) matched.push(rule);
  return matched;
}
function layerOpen(layer) {
  return !layer || (layer.revisable !== false && layer.closure_allowed !== true);
}
function resolveDependencyState(contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread, reflectiveAxisMirroring, revisabilityInterpretiveOpenness, returnPreservingCorrectionGuard, relationalFirstContactCalibration) {
  return {
    context_integrity_active: !!contextIntegrity,
    semantic_fusion_active: !!semanticFusion,
    progressive_understanding_active: !!progressiveUnderstanding,
    intuition_meaning_spread_active: !!intuitionMeaningSpread,
    reflective_axis_mirroring_active: !!reflectiveAxisMirroring,
    revisability_interpretive_openness_active: !!revisabilityInterpretiveOpenness,
    return_preserving_correction_guard_active: !!returnPreservingCorrectionGuard,
    relational_first_contact_calibration_active: !!relationalFirstContactCalibration,
    prior_layers_open: [contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread, reflectiveAxisMirroring, revisabilityInterpretiveOpenness, returnPreservingCorrectionGuard, relationalFirstContactCalibration].every(layerOpen),
    relational_safety_preserved: !relationalFirstContactCalibration || relationalFirstContactCalibration.disclosure_openness_preserved === true,
    human_ownership_preserved: !relationalFirstContactCalibration || relationalFirstContactCalibration.human_ownership_of_realization_preserved === true,
    authority_or_destination_risk_from_prior_layers: !!(
      (progressiveUnderstanding && progressiveUnderstanding.authority_led_interpretation_allowed === true) ||
      (reflectiveAxisMirroring && reflectiveAxisMirroring.identity_collapse_inherited === true) ||
      (revisabilityInterpretiveOpenness && revisabilityInterpretiveOpenness.permanent_interpretive_closure_allowed === true) ||
      (returnPreservingCorrectionGuard && returnPreservingCorrectionGuard.punishment_architecture_allowed === true) ||
      (relationalFirstContactCalibration && relationalFirstContactCalibration.system_already_knows_me_pressure_allowed === true)
    )
  };
}

function mapAnomalyFirstContactCalibration(input, contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread, reflectiveAxisMirroring, revisabilityInterpretiveOpenness, returnPreservingCorrectionGuard, relationalFirstContactCalibration) {
  const text = normalizeInput(input);
  const registry = getAnomalyFirstContactRegistry();
  const rules = Array.isArray(registry.rules) ? [...registry.rules] : [];
  rules.sort((a, b) => (a.priority || 9999) - (b.priority || 9999));
  const matchedRules = collectMatchedRules(text, rules);
  const actionableRules = matchedRules.filter((rule) =>
    [rule.anomalySignals, rule.anomalyRisks, rule.calibrationMoves, rule.forbiddenMoves, rule.outputPosture]
      .some((values) => Array.isArray(values) && values.length > 0)
  );

  const anomalySignals = [];
  const anomalyRisks = [];
  const calibrationMoves = [];
  const forbiddenMoves = [];
  const outputPosture = [];

  for (const rule of matchedRules) {
    appendUnique(anomalySignals, rule.anomalySignals);
    appendUnique(anomalyRisks, rule.anomalyRisks);
    appendUnique(calibrationMoves, rule.calibrationMoves);
    appendUnique(forbiddenMoves, rule.forbiddenMoves);
    appendUnique(outputPosture, rule.outputPosture);
  }

  const dependencyState = resolveDependencyState(
    contextIntegrity,
    semanticFusion,
    progressiveUnderstanding,
    intuitionMeaningSpread,
    reflectiveAxisMirroring,
    revisabilityInterpretiveOpenness,
    returnPreservingCorrectionGuard,
    relationalFirstContactCalibration
  );
  const active = actionableRules.length > 0 || dependencyState.authority_or_destination_risk_from_prior_layers;

  return {
    version: registry.version,
    stewardship: "Master Step 4H-2 — Anomaly First Contact Calibration",
    depends_on: [
      "Master Step 4A — Context Integrity Mapping",
      "Master Step 4B — Semantic Fusion Separation",
      "Master Step 4C — Progressive Understanding Runtime",
      "Master Step 4D — Intuition & Meaning Spread Governance",
      "Master Step 4E — Reflective Axis Mirroring",
      "Master Step 4F — Revisability & Interpretive Openness",
      "Master Step 4G — Return-Preserving Correction Guard",
      "Master Step 4H-1 — Relational First Contact Calibration"
    ],
    dependency_state: dependencyState,
    anomaly_first_contact_calibration_active: active,
    anomaly_pressure_allowed: false,
    uncanny_precision_escalation_allowed: false,
    special_authority_projection_allowed: false,
    destination_transfer_allowed: false,
    understanding_ownership_transfer_allowed: false,
    warmth_must_be_preserved: true,
    sterile_restraint_as_solution_allowed: false,
    tool_boundary_preserved_without_coldness: true,
    closure_allowed: false,
    revisable: true,
    anomaly_signals: anomalySignals,
    anomaly_risks: anomalyRisks,
    calibration_moves: calibrationMoves,
    forbidden_moves: forbiddenMoves,
    output_posture: outputPosture.length > 0 ? outputPosture : [
      "clarify_path_without_becoming_destination",
      "preserve_user_owned_understanding",
      "avoid_anomaly_pressure"
    ],
    matched_rules: matchedRules.map((rule) => rule.id),
    actionable_rules: actionableRules.map((rule) => rule.id),
    guardrails: Array.isArray(registry.guardrails) ? registry.guardrails : []
  };
}

module.exports = { mapAnomalyFirstContactCalibration };
