#!/usr/bin/env python3
"""
Atlas carry-forward updater.

Purpose:
- Treat CARRY_FORWARD_MANIFEST.json as the machine-readable source of truth.
- Regenerate/check the carried-forward proof index from the manifest.
- Confirm VERSION_STATUS.json and SNAPSHOT_VAULT_POLICY.json agree with the manifest.
- Write CARRY_FORWARD_AUDIT.md.

This script does not mutate Compass runtime, governance behavior, frontend UI, or ontology routing.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Tuple


PROOF_DIR = Path("CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work")
TESTS_DIR = Path("tests")


def find_project_root(start: Path) -> Path:
    for candidate in [start, *start.parents]:
        if (candidate / "tests").is_dir() and (candidate / "CA" / "Continuity_Architecture").is_dir():
            return candidate
    for candidate in [start, *start.parents]:
        matches = list(candidate.rglob("CARRY_FORWARD_MANIFEST.json"))
        for match in matches:
            possible = match.parents[3] if len(match.parents) > 3 else match.parent
            if (possible / "tests").is_dir() and (possible / "CA" / "Continuity_Architecture").is_dir():
                return possible
    raise FileNotFoundError("Could not locate project root containing tests/ and CA/Continuity_Architecture/")


def read_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, data: Dict[str, Any]) -> None:
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def normalize_snapshot_policy(policy: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "working_package_embeds_snapshots": policy.get("working_package_embeds_snapshots"),
        "external_vault_preferred": policy.get("external_vault_preferred"),
        "embedded_fallback_allowed": policy.get("embedded_fallback_allowed"),
        "current_embedded_snapshot": policy.get("current_embedded_snapshot"),
        "required_snapshot_metadata_reference": policy.get("required_snapshot_metadata_reference"),
        "metadata_reference_only_no_embedded_zip": policy.get("metadata_reference_only_no_embedded_zip"),
    }


def generate_index(manifest: Dict[str, Any]) -> str:
    carried = "\n".join(f"- `{item}`" for item in manifest.get("carried_forward_packages", []))
    markers = "\n".join(f"- {item}" for item in manifest.get("required_current_markers", []))
    proofs = "\n".join(f"- `{item}`" for item in manifest.get("required_proof_files", []))
    boundaries = "\n".join(f"- {item}" for item in manifest.get("proof_boundaries", []))

    return f"""# CURRENT PROOF POINTER — {manifest['current_package_folder'].upper()}

Current package: `{manifest['current_package']}`  
Current checkpoint: `{manifest['current_checkpoint']}`  
Current status: `{manifest['current_status']}`  
Previous patch: `{manifest['previous_patch']}`  
Previous patch status: `{manifest['previous_patch_status']}`

## Source-of-truth rule

{manifest['source_of_truth_rule']}

## Required current markers

{markers}

## Carried-forward package lineage

{carried}

## Required proof files

{proofs}

## Snapshot policy

- Mode: `{manifest['snapshot_policy']['mode']}`
- Working package embeds snapshots: `{manifest['snapshot_policy']['working_package_embeds_snapshots']}`
- External vault preferred: `{manifest['snapshot_policy']['external_vault_preferred']}`
- Embedded fallback allowed: `{manifest['snapshot_policy']['embedded_fallback_allowed']}`
- Current embedded snapshot: `{manifest['snapshot_policy']['current_embedded_snapshot']}`
- Required metadata reference: `{manifest['snapshot_policy']['required_snapshot_metadata_reference']}`

## Proof boundaries

{boundaries}

## Patch07 failure carry-forward

`Masterstep12_patch07.zip` remains a failed hygiene-gate evidence package. It is not embedded in the clean distribution package. Its failure is preserved in `MASTER_STEP_12_PATCH07_HYGIENE_GATE_FAILURE_RECORD.md`.

## Generated-document rule

This index is generated/derived documentation from `CARRY_FORWARD_MANIFEST.json`. The manifest is the machine-readable source of truth.
"""


def main() -> int:
    root = find_project_root(Path.cwd())
    proof_dir = root / PROOF_DIR
    tests_dir = root / TESTS_DIR
    manifest_path = proof_dir / "CARRY_FORWARD_MANIFEST.json"
    audit_path = proof_dir / "CARRY_FORWARD_AUDIT.md"
    index_path = proof_dir / "PROOF_OF_WORK_CARRIED_FORWARD_INDEX.md"

    manifest = read_json(manifest_path)
    version = read_json(tests_dir / "VERSION_STATUS.json")
    snapshot = read_json(tests_dir / "SNAPSHOT_VAULT_POLICY.json")

    failures: List[str] = []

    if version.get("checkpoint") != manifest.get("current_checkpoint"):
        failures.append("VERSION_STATUS checkpoint does not match manifest current_checkpoint")
    if version.get("snapshot") != manifest.get("current_package"):
        failures.append("VERSION_STATUS snapshot does not match manifest current_package")
    if version.get("status") != manifest.get("current_status"):
        failures.append("VERSION_STATUS status does not match manifest current_status")

    expected_snapshot = normalize_snapshot_policy(manifest.get("snapshot_policy", {}))
    actual_snapshot = normalize_snapshot_policy(snapshot)
    for key, expected in expected_snapshot.items():
        if actual_snapshot.get(key) != expected:
            failures.append(f"SNAPSHOT_VAULT_POLICY {key} does not match manifest: expected {expected!r}, got {actual_snapshot.get(key)!r}")

    for proof_file in manifest.get("required_proof_files", []):
        # This script writes CARRY_FORWARD_AUDIT.md during the current run.
        if proof_file == "CARRY_FORWARD_AUDIT.md":
            continue
        if not (proof_dir / proof_file).is_file():
            failures.append(f"Missing required proof file: {proof_file}")

    for test_file in manifest.get("required_test_files", []):
        if not (tests_dir / test_file).is_file():
            failures.append(f"Missing required test file: {test_file}")

    index_path.write_text(generate_index(manifest), encoding="utf-8")

    audit_status = "FAILED" if failures else "PASSED"
    audit_lines = [
        "# Carry-Forward Audit",
        "",
        f"Timestamp: {datetime.now().isoformat(timespec='seconds')}",
        f"Status: {audit_status}",
        f"Current package: `{manifest.get('current_package')}`",
        f"Current checkpoint: `{manifest.get('current_checkpoint')}`",
        "",
        "## Checks",
        "- Manifest loaded.",
        "- Carry-forward index regenerated from manifest.",
        "- VERSION_STATUS compared against manifest.",
        "- SNAPSHOT_VAULT_POLICY compared against manifest.",
        "- Required proof/test files checked.",
        "",
    ]
    if failures:
        audit_lines.extend(["## Failures", *[f"- {failure}" for failure in failures], ""])
    else:
        audit_lines.extend([
            "## Result",
            "- Automated carry-forward alignment PASSED.",
            "- Manifest-driven proof validation is active.",
            "- Metadata-only snapshot policy accepted.",
            "- Patch07 hygiene gate failure preserved as proof record.",
            "",
        ])
    audit_path.write_text("\n".join(audit_lines), encoding="utf-8")

    if failures:
        print("CARRY-FORWARD AUDIT FAILED")
        print("\n".join(failures))
        return 1

    print("CARRY-FORWARD AUDIT PASSED")
    print(f"Audit: {audit_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
