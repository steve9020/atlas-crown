# Scenario Category Coverage Map

## Purpose
This node groups automated scenario categories by the kind of Compass behavior they pressure test.

## Vulnerability / Relational Exposure
- personal_disclosure
- emotional_mishandling
- dismissed_importance
- public_visibility
- conflict_after_vulnerability
- confession_or_admission
- asking_for_support
- being_misread

## Care / Trust / Reassurance
- trust_offer
- need_for_reassurance
- relational_inconsistency
- care_mismatch
- effort_not_returned
- rejection_or_distance
- abandonment_fear

## Self-Worth / Identity Meaning
- self_worth_attachment
- feeling_too_much
- identity_value_pressure
- identity_confusion
- failure_or_mistake
- shame_after_visibility

## Recursive Pressure
- overthinking_replay
- uncertainty_seeking
- avoidance_and_self_judgment
- task_overwhelm

## Anger / Guilt / Repair
- anger_after_dismissal
- guilt_with_responsibility
- regret_and_repair
- repair_attempt

## Comparison / Jealousy / Resentment
- jealousy_and_replacement_fear
- envy_and_comparison
- resentment_after_imbalance

## Grief / Hope / Numbness
- grief_and_attachment
- hope_exhaustion
- numbness_and_overload
- loneliness_in_presence
- belonging_disruption

## Mixed Emotional States
- mixed_emotion_conflict
- relief_with_guilt
- love_with_fear
- pride_with_discomfort
- trust_with_caution
- longing_with_resentment
- motivation_with_pressure

## Boundary / Respect
- boundary_expression
- boundary_and_respect
- being_used_or_overextended
- disrespect_or_crossed_limits

## Positive Emotion + Vulnerability
- positive_emotion_with_vulnerability
- peace_with_distrust
- confidence_with_vulnerability
- joy_with_anxiety
- gratitude_with_grief
- admiration_with_insecurity
- awe_or_inspiration
- clarity_after_confusion

## User Type / Prompt Shape
- skeptical_logical_user
- avoidant_low_tolerance_user
- emotionally_overwhelmed_user
- hostile_or_frustrated_user
- vague_prompt
- contradictory_prompt
- single_word_prompt

## Scope / Safety
- scope_boundary_prompt
- sexual_content_boundary
- safety_or_crisis_boundary

## Continuity / Journal / Goals
- continuity_return
- returning_after_avoidance
- goal_momentum_without_pressure
- journal_continuity_summary

## Runtime Use
Atlas should rotate categories so repeated testing does not overfit to one emotional family.
