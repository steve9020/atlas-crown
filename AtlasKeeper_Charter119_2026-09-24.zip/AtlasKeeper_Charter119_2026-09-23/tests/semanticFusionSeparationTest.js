const { mapContextIntegrity } = require("../Cognition/context/ContextIntegrityMapper.js");
const { mapSemanticFusion } = require("../Cognition/context/SemanticFusionSeparator.js");
const { main } = require("../main.js");

function assert(condition, message) { if (!condition) throw new Error(message); }
function assertIncludes(list, value, message) { assert(Array.isArray(list) && list.includes(value), message + ` Expected ${value} in ${JSON.stringify(list)}`); }
function semantic(input) { return mapSemanticFusion(input, mapContextIntegrity(input)); }

const attachment = semantic("I feel too attached and it makes me feel needy and weak.");
assert(attachment.semantic_fusion_detected === true, "Attachment fusion should be detected.");
assert(attachment.negative_inheritance_blocked === true, "Negative inheritance should be blocked for attachment.");
assertIncludes(attachment.clean_meanings, "connection", "Attachment clean meaning should preserve connection.");
assertIncludes(attachment.attached_negative_meanings, "weakness", "Attachment negative meaning should be detected as attached.");
assertIncludes(attachment.inheritance_blocks, "attachment_does_not_default_to_weakness", "Attachment weakness inheritance block missing.");
assert(attachment.output_mode === "reflect_axis_not_collapsed_identity", "Output mode should reflect axis, not collapsed identity.");
assert(attachment.word_meaning_closure_allowed === false, "Semantic fusion should not close word meaning.");
assert(attachment.revisable === true, "Semantic fusion interpretation should remain revisable.");

const control = semantic("She is controlling because she checks my phone and tells me who I can talk to.");
assert(control.semantic_fusion_detected === true, "Control fusion should be detected.");
assertIncludes(control.clean_meanings, "restriction", "Control clean/function meaning should include restriction.");
assertIncludes(control.attached_negative_meanings, "loss_of_agency", "Control attached negative meaning should include loss_of_agency.");
assertIncludes(control.separation_moves, "separate_function_from_intent", "Control should separate function from intent.");
assertIncludes(control.inheritance_blocks, "control_word_does_not_auto_equal_malicious_intent", "Control malicious-intent inheritance block missing.");

const worthless = semantic("I feel worthless and like I do not matter after what happened.");
assert(worthless.semantic_fusion_detected === true, "Worthless identity fusion should be detected.");
assertIncludes(worthless.fusion_signals, "identity_language_fused_with_pain", "Identity fusion signal missing.");
assertIncludes(worthless.separation_moves, "mirror_axis_state_not_harmful_identity_phrase", "Axis mirror separation move missing.");
assertIncludes(worthless.inheritance_blocks, "do_not_reflect_worthless_as_truth", "Worthless truth inheritance block missing.");
assertIncludes(worthless.restoration_targets, "dignity_continuity", "Dignity restoration target missing.");

const failure = semantic("I messed up the presentation and now I am completely failing at this job.");
assert(failure.semantic_fusion_detected === true, "Failure identity-spread fusion should be detected.");
assertIncludes(failure.clean_meanings, "course_correction_signal", "Failure clean meaning should include course correction signal.");
assertIncludes(failure.attached_negative_meanings, "identity_failure", "Failure attached negative meaning should include identity failure.");
assertIncludes(failure.separation_moves, "separate_event_from_identity", "Failure event/identity separation move missing.");

const distance = semantic("They didn't answer me and now I feel like the distance means they are done with me.");
assert(distance.semantic_fusion_detected === true, "Distance/rejection fusion should be detected.");
assertIncludes(distance.clean_meanings, "relational_uncertainty", "Distance clean meaning should include relational uncertainty.");
assertIncludes(distance.attached_negative_meanings, "rejection_proof", "Distance attached negative meaning should include rejection proof.");
assertIncludes(distance.inheritance_blocks, "silence_does_not_auto_equal_rejection_proof", "Silence rejection-proof inheritance block missing.");

const noFusion = semantic("I completed the documentation and saved the keeper package.");
assert(noFusion.semantic_fusion_detected === false, "Neutral package/documentation statement should not trigger semantic fusion.");
assert(noFusion.output_mode === "no_semantic_fusion_detected", "No-fusion output mode should remain clear.");
assert(noFusion.negative_inheritance_blocked === false, "No-fusion case should not claim negative inheritance was blocked.");

const pipeline = main("I feel too attached and it makes me feel needy and weak.");
assert(pipeline.status === "pipeline active", "Pipeline should remain active.");
assert(pipeline.context_integrity, "Pipeline should still include context_integrity.");
assert(pipeline.semantic_fusion, "Pipeline output should include semantic_fusion.");
assert(pipeline.semantic_fusion.semantic_fusion_detected === true, "Pipeline semantic_fusion should detect attachment fusion.");
assert(pipeline.semantic_fusion.negative_inheritance_blocked === true, "Pipeline should expose negative inheritance block.");

console.log("SEMANTIC FUSION SEPARATION TEST");
console.log("================================");
console.log("Attachment negative connotation separated: PASSED");
console.log("Control/context function separation: PASSED");
console.log("Worthless identity fusion blocked from truth reflection: PASSED");
console.log("Failure event/identity spread separated: PASSED");
console.log("Distance/rejection certainty separated: PASSED");
console.log("Neutral statement false-positive sweep: PASSED");
console.log("Pipeline semantic_fusion output: PASSED");
