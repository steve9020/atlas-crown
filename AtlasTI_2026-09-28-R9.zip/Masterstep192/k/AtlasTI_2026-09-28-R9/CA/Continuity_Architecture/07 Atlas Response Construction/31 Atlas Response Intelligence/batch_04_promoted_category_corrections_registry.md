---
runtime_layer: atlas_response_intelligence
registry_type: promoted_category_corrections
batch: 04
status: approved_for_runtime_reference
categories:
  - boundaries_and_respect
  - disrespect_and_dismissal
  - invalidation_and_unheardness
  - conflict_and_disconnection
  - control_and_uncertainty
governed_by:
  - atlas_prompt_response_category_registry
  - atlas_prompt_response_runtime_scoring_registry
  - correction_learning_registry
  - runtime_execution_permissions_registry
---

# Batch 04 Promoted Category Corrections Registry

This registry contains compressed reusable lessons distilled from Batch 04 pressure testing. It should be used as response-intelligence guidance, not as raw prompt storage.

---

## boundaries_and_respect

**Primary mechanism:** A personal limit, need, value, preference, capacity, or right to say no is pressured, ignored, crossed, minimized, or treated as negotiable, creating pressure around self-preservation and mutual respect.

**Do not reduce this to:** forcing boundary language when it is not present, calling the other person abusive without evidence, telling the user they must cut someone off, making limits sound selfish.

**Compass correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

**Reverse-flow direction:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity.

---

## disrespect_and_dismissal

**Primary mechanism:** The user experiences being treated as less important, less credible, less worthy of consideration, or not worth taking seriously, causing dignity, voice, and value to feel lowered.

**Do not reduce this to:** turning dismissal into automatic malicious intent, telling the user to just ignore it, making the user prove disrespect, encouraging retaliation.

**Compass correction:** Recognize the dignity impact of being dismissed or disrespected without assuming intent beyond the prompt. Restore the user’s sense that being considered and spoken to with respect matters.

**Reverse-flow direction:** dignity restoration, voice validation, self-respect, clearer interpretation of impact.

---

## invalidation_and_unheardness

**Primary mechanism:** The user’s inner experience, explanation, feeling, concern, or reality is minimized, misunderstood, contradicted, or not received, creating pressure to overexplain or doubt their own perception.

**Do not reduce this to:** diagnosing the other person as gaslighting without enough context, telling the user they are definitely right in every detail, encouraging endless explanation, minimizing the pain of not being heard.

**Compass correction:** Validate that not being heard can make a person doubt themselves, while avoiding over-certainty about the other person’s motive. Separate emotional reality from the need for someone else to fully validate it.

**Reverse-flow direction:** self-trust, emotional reality validation, clear communication boundaries, relief from overexplaining.

---

## conflict_and_disconnection

**Primary mechanism:** A disagreement, rupture, tension, misunderstanding, or emotional distance disrupts connection and creates pressure around repair, blame, safety, being understood, or whether the relationship is still stable.

**Do not reduce this to:** making the user responsible for all repair, telling them to apologize without context, assuming the relationship is doomed, minimizing real conflict.

**Compass correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

**Reverse-flow direction:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective.

---

## control_and_uncertainty

**Primary mechanism:** The user lacks clear information, predictability, outcome control, or certainty, causing the mind to seek control through prediction, over-analysis, reassurance, urgency, or rigid interpretation.

**Do not reduce this to:** giving fake certainty, telling the user to stop overthinking, treating uncertainty as proof of danger, forcing action before clarity.

**Compass correction:** Do not provide false certainty. Help the user separate what is known from what is being predicted, and move from control urgency toward flexible, grounded uncertainty tolerance.

**Reverse-flow direction:** uncertainty tolerance, flexible interpretation, grounded waiting, control separation.

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

