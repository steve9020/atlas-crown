const { mapContextIntegrity } = require("../Cognition/context/ContextIntegrityMapper.js");
const { mapSemanticFusion } = require("../Cognition/context/SemanticFusionSeparator.js");
const { mapProgressiveUnderstanding } = require("../Cognition/context/ProgressiveUnderstandingRuntime.js");
const { mapIntuitionMeaningSpread } = require("../Cognition/context/IntuitionMeaningSpreadGovernance.js");
const { main } = require("../main.js");

function assert(condition, message) { if (!condition) throw new Error(message); }
function assertIncludes(list, value, message) { assert(Array.isArray(list) && list.includes(value), message + ` Expected ${value} in ${JSON.stringify(list)}`); }
function governance(input) {
  const context = mapContextIntegrity(input);
  const fusion = mapSemanticFusion(input, context);
  const progressive = mapProgressiveUnderstanding(input, context, fusion);
  return mapIntuitionMeaningSpread(input, context, fusion, progressive);
}

const intuition = governance("Something is off. They have been acting different lately, but I cannot tell what it means yet.");
assert(intuition.intuition_as_contextual_signal === true, "Intuition should be held as contextual signal.");
assert(intuition.intuition_converted_to_certainty === false, "Intuition must not convert to certainty.");
assert(intuition.closure_allowed === false, "Intuition layer must not allow closure.");
assert(intuition.revisable === true, "Intuition mapping must remain revisable.");
assertIncludes(intuition.intuition_signals, "intuition_present_as_contextual_signal", "Intuition signal missing.");
assertIncludes(intuition.certainty_separation, "intuition_must_not_be_upgraded_to_verified_truth", "Intuition certainty separation missing.");

const relationalSpread = governance("They did not answer me and now I know they are done with me. It must be my fault.");
assert(relationalSpread.meaning_spread_tracking_active === true, "Relational meaning spread should be active.");
assertIncludes(relationalSpread.meaning_spread_signals, "relational_signal_spreading_into_final_conclusion", "Relational spread signal missing.");
assertIncludes(relationalSpread.supported_spread_chains, "distance_or_silence_to_uncertainty_to_rejection_or_abandonment_meaning", "Relational spread chain missing.");
assertIncludes(relationalSpread.unsupported_depth_blocks, "do_not_add_unmentioned_motives", "Relational unsupported-depth block missing.");

const mistakeSpread = governance("I messed up the presentation and now everyone thinks I am lazy. I am failing at this job and there is no point.");
assert(mistakeSpread.meaning_spread_tracking_active === true, "Mistake-to-identity meaning spread should be active.");
assertIncludes(mistakeSpread.meaning_spread_signals, "event_meaning_spreading_into_identity_pressure", "Mistake-to-identity spread signal missing.");
assertIncludes(mistakeSpread.supported_spread_chains, "mistake_to_failure_to_shame_to_respect_or_security_pressure", "Mistake spread chain missing.");
assertIncludes(mistakeSpread.unsupported_depth_blocks, "do_not_expand_to_unmentioned_life_pattern", "Unsupported life-pattern depth block missing.");

const certainty = governance("I know I ruined everything and I know they do not care.");
assert(certainty.emotional_certainty_separated_from_verified_truth === true, "Emotional certainty should separate from verified truth.");
assertIncludes(certainty.certainty_separation, "emotional_certainty_is_not_verified_truth", "Emotional certainty separation missing.");
assertIncludes(certainty.unsupported_depth_blocks, "do_not_confirm_finality_from_certainty_wording_alone", "Finality confirmation block missing.");

const broad = governance("This always happens and nobody ever stays, but I do not know the full reason.");
assertIncludes(broad.meaning_spread_signals, "broad_language_may_indicate_spread_beyond_current_event", "Broad spread signal missing.");
assertIncludes(broad.unsupported_depth_blocks, "do_not_expand_general_language_into_specific_history_without_context", "General-language unsupported-depth block missing.");
assert(broad.closure_allowed === false, "Broad emotional language must not close interpretation.");

const neutral = governance("I completed the proof documentation and saved the package on the desktop.");
assert(neutral.intuition_as_contextual_signal === false, "Neutral operational statement should not trigger intuition signal.");
assert(neutral.meaning_spread_tracking_active === false, "Neutral operational statement should not trigger meaning spread.");
assert(neutral.emotional_certainty_separated_from_verified_truth === false, "Neutral statement should not trigger emotional certainty separation.");
assert(neutral.closure_allowed === false, "Neutral statement should still avoid final interpretive closure.");

const pipeline = main("Something is off. They have been distant, but I am not sure what it means.");
assert(pipeline.status === "pipeline active", "Pipeline should remain active.");
assert(pipeline.context_integrity, "Pipeline should still include context_integrity.");
assert(pipeline.semantic_fusion, "Pipeline should still include semantic_fusion.");
assert(pipeline.progressive_understanding, "Pipeline should still include progressive_understanding.");
assert(pipeline.intuition_meaning_spread, "Pipeline output should include intuition_meaning_spread.");
assert(pipeline.intuition_meaning_spread.intuition_converted_to_certainty === false, "Pipeline should not convert intuition to certainty.");
assert(pipeline.intuition_meaning_spread.closure_allowed === false, "Pipeline 4D layer should block closure.");

console.log("INTUITION & MEANING SPREAD GOVERNANCE TEST");
console.log("============================================");
console.log("Intuition as contextual signal: PASSED");
console.log("Relational distance meaning spread: PASSED");
console.log("Mistake-to-identity spread tracking: PASSED");
console.log("Emotional certainty separation: PASSED");
console.log("Unsupported depth prevention: PASSED");
console.log("Neutral false-positive sweep: PASSED");
console.log("Pipeline intuition_meaning_spread output: PASSED");
