# Node Selection Guide

Use this to translate simple human answers into framework nodes.

---

## What felt affected?

### Feeling unheard / misunderstood
Suggested nodes:
- [[Relational Continuity]]
- [[Trust|Trust]]
- [[Self-Worth]]

### Feeling rejected / unwanted
Suggested nodes:
- [[Self-Worth]]
- [[Attachment]]
- [[Loneliness|Loneliness]]

### Feeling unsafe / unstable
Suggested nodes:
- [[Stability]]
- [[Fear]]
- [[Emotional Regulation]]

### Feeling controlled / restricted
Suggested nodes:
- [[Boundaries]]
- [[Authority]]
- [[Continuity Resistance]]

### Feeling ashamed / not enough
Suggested nodes:
- [[Shame]]
- [[Self-Worth]]
- [[Validation Dependency]]

### Feeling betrayed
Suggested nodes:
- [[Betrayal]]
- [[Trust|Trust]]
- [[Relational Continuity]]

---

## How did I respond?

### Defended / explained harder
Suggested nodes:
- [[Behavior]]
- [[Fear]]
- [[Identity]]
- [[Reinforcement Flows]]

### Withdrew / shut down
Suggested nodes:
- [[Fragmentation Flows]]
- [[Loneliness|Loneliness]]
- [[Emotional Regulation]]

### Escalated emotionally
Suggested nodes:
- [[Emotional Regulation]]
- [[Fragmentation Flows]]
- [[Relational Flows]]

### Avoided it
Suggested nodes:
- [[Fear]]
- [[Continuity Resistance]]
- [[Behavioral Reinforcement]]

---

## What did it reinforce?

### More distance
Suggested nodes:
- [[Relational Continuity]]
- [[Loneliness|Loneliness]]
- [[Fragmentation Flows]]

### More distrust
Suggested nodes:
- [[Trust|Trust]]
- [[Betrayal]]
- [[Relational Flows]]

### More fear
Suggested nodes:
- [[Fear]]
- [[Reinforcement Flows]]
- [[Emotional Weighting]]

### More clarity
Suggested nodes:
- [[Awareness]]
- [[00-Core/01 Primitives/Reflection|Reflection]]
- [[Truthful Recalibration]]

### More stability
Suggested nodes:
- [[Stabilization Flows]]
- [[Emotional Regulation]]
- [[Adaptive Continuity]]

---

## Core Rule

Pick only 3–5 linked nodes per scenario.

Too many links reduce signal quality.