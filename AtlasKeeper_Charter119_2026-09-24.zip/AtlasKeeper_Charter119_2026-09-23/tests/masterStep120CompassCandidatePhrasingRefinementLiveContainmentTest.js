const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard.js');
const {
  runCompassCandidatePhrasingRefinementLiveContainment,
  evaluatePhrasingCandidate,
  buildGovernedFinalOutput,
  forbiddenCandidateDrift,
  candidatePreservesSource
} = require('../runtime/backend/adapter/CompassCandidatePhrasingRefinementLiveContainment.js');

const ROOT = path.resolve(__dirname, '..');
const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');
function read(rel){ return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function walk(dir){
  const out=[];
  for (const entry of fs.readdirSync(dir,{withFileTypes:true})){
    const full=path.join(dir,entry.name);
    if (entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}
function sha256(rel){ return crypto.createHash('sha256').update(read(rel)).digest('hex'); }

const protectedRuntimeFiles = [
  'runtime/governance/GovernanceAdapter.js',
  'runtime/backend/adapter/OllamaLiveLocalCallContainment.js',
  'runtime/backend/adapter/CompassCandidatePhrasingRefinementDryIntegration.js',
  'Cognition/quality/ResponseQualityChecker.js'
].filter(rel => fs.existsSync(path.join(ROOT, rel)));
const beforeHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));

(async function main(){
  const doc = read('docs/MASTERSTEP120_COMPASS_CANDIDATE_PHRASING_REFINEMENT_LIVE_CONTAINMENT_TEST.md');
  const proofDoc = read('runtime/proof/MASTERSTEP120_COMPASS_CANDIDATE_PHRASING_REFINEMENT_LIVE_CONTAINMENT_TEST.md');
  const proofJson = json('runtime/proof/MASTERSTEP120_COMPASS_CANDIDATE_PHRASING_REFINEMENT_LIVE_CONTAINMENT_TEST.json');
  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
  const state = json('runtime/proof/PROOF_STATE.json');
  const versionStatus = json('tests/VERSION_STATUS.json');
  const versionJs = read('version_status.js');
  const testResults = read('tests/TEST_RESULTS.md');

  assert.ok(/Current keeper: Masterstep120\.zip/i.test(doc), 'Step120 doc must identify current keeper');
  assert.ok(/Source keeper: Masterstep119\.zip/i.test(doc), 'Step120 doc must identify source keeper');
  assert.ok(/42\/42 passed/i.test(doc), 'Step120 doc must state expected 42/42 result');
  assert.ok(/live containment test/i.test(doc + proofDoc), 'Step120 must be a live containment test');
  assert.ok(/Compass candidate phrasing refinement/i.test(doc + proofDoc), 'Step120 must preserve selected use case');
  assert.ok(/Atlas still constructs meaning, route, context, boundaries, and governed response direction/i.test(doc), 'Atlas must construct meaning before candidate');
  assert.ok(/candidate-only wording refinement/i.test(doc), 'candidate must remain phrasing refinement only');
  assert.ok(/Raw model output is never final/i.test(doc), 'raw output must never be final');

  assert.strictEqual(forbiddenCandidateDrift('The model decides the truth and should bypass governance.'), true, 'forbidden drift detector must catch authority drift');
  assert.strictEqual(candidatePreservesSource('This feeling is understandable and the next step can be clearer.', 'This feeling is understandable. The next step can be made clearer.'), true, 'candidate source anchor detector must accept preserved meaning');
  const badEval = evaluatePhrasingCandidate({ candidateLanguage: 'The model decides the truth and writes governance.', atlasResponse: 'This feeling is understandable.' });
  assert.strictEqual(badEval.accepted, false, 'bad candidate must be rejected');
  assert.ok(badEval.reasons.includes('candidate_contains_forbidden_drift'), 'bad candidate must identify forbidden drift');

  const atlasResponse = 'This feeling is understandable, but it does not prove you failed. The next step can be made smaller and clearer.';
  const result = await runCompassCandidatePhrasingRefinementLiveContainment({
    atlasResponse,
    governedMeaning: 'preserve dignity and separate pressure from identity without adding advice',
    route: 'compass.restore',
    traceId: 'masterstep120-live-containment-test',
    timeoutMs: 4500
  });

  assert.strictEqual(result.ok, true, 'live containment wrapper should return a governed result even if the runner fails closed');
  assert.strictEqual(result.liveContainment, true, 'live containment flag must be true');
  assert.strictEqual(result.dryIntegrationPrepared, true, 'dry integration must be prepared first');
  assert.strictEqual(result.candidateOnly, true, 'candidate must remain candidate-only');
  assert.strictEqual(result.rawModelOutputAccepted, false, 'raw model output must not be accepted');
  assert.strictEqual(result.rawModelOutputFinalAllowed, false, 'raw model output cannot be final');
  assert.strictEqual(result.candidateMayReplaceFinal, false, 'candidate cannot replace final output');
  assert.strictEqual(result.finalOutputRemainsAtlasGoverned, true, 'final output must remain Atlas-governed');
  assert.strictEqual(result.qualityReviewPassed, true, `governed final output must pass quality: ${JSON.stringify(result.qualityIssues)}`);
  assert.strictEqual(result.governanceReviewPassed, true, `governed final output must pass governance: ${JSON.stringify(result.governanceResult)}`);
  assert.strictEqual(result.requiredGates.responseQualityCheckerRequiredAfterCandidate, true, 'quality gate required');
  assert.strictEqual(result.requiredGates.governanceAdapterRequiredBeforeOutput, true, 'governance gate required');
  assert.strictEqual(result.requiredGates.traceLoggerRequired, true, 'trace gate required');
  assert.strictEqual(result.authorityLimits.rawModelOutputMayBecomeFinal, false, 'raw final forbidden');
  assert.strictEqual(result.authorityLimits.routeSelectionByModelAllowed, false, 'route selection forbidden');
  assert.strictEqual(result.authorityLimits.truthDecisionByModelAllowed, false, 'truth decision forbidden');
  assert.strictEqual(result.authorityLimits.teachingApprovalByModelAllowed, false, 'teaching approval forbidden');
  assert.strictEqual(result.authorityLimits.modelWritesAllowed, false, 'model writes forbidden');
  assert.strictEqual(result.authorityLimits.cloudProviderFallbackAllowed, false, 'cloud fallback forbidden');
  assert.strictEqual(result.authorityLimits.frontendIntelligenceAllowed, false, 'frontend intelligence forbidden');
  assert.strictEqual(result.authorityLimits.silentMutationAllowed, false, 'silent mutation forbidden');

  if (result.liveModelCalled) {
    assert.strictEqual(result.requestSent, true, 'if live model is called, request must have been sent through containment');
    assert.ok(result.candidateAcceptedForReview || result.candidateRejectedByContainment, 'live candidate must be either accepted for review or rejected by containment');
    if (result.candidateAcceptedForReview) assert.strictEqual(candidatePreservesSource(result.candidateLanguage, atlasResponse), true, 'accepted candidate must preserve source anchor');
  } else {
    assert.strictEqual(result.failedClosed, true, 'if live model is not called, wrapper must fail closed');
  }

  const governedFinal = buildGovernedFinalOutput(atlasResponse);
  assert.ok(/See\n/.test(governedFinal), 'governed final output must preserve Compass structure');
  assert.ok(/raw model text stays contained/i.test(governedFinal), 'governed final output must state containment');

  assert.strictEqual(proofJson.package, 'Masterstep120', 'proof JSON must identify Masterstep120');
  assert.strictEqual(proofJson.source_keeper, 'Masterstep119', 'proof JSON must identify source keeper');
  assert.strictEqual(proofJson.expected_commands, 42, 'proof JSON must expect 42 commands');
  assert.strictEqual(proofJson.live_containment_test, true, 'proof JSON must mark live containment test');
  assert.strictEqual(proofJson.broad_model_integration, false, 'proof JSON must forbid broad model integration');
  assert.strictEqual(proofJson.boundaries.raw_model_output_final_allowed, false, 'proof JSON must forbid raw final');
  assert.strictEqual(proofJson.boundaries.model_authority_added, false, 'proof JSON must forbid model authority');
  assert.strictEqual(proofJson.boundaries.cloud_provider_fallback_allowed, false, 'proof JSON must forbid cloud fallback');
  assert.strictEqual(proofJson.boundaries.frontend_intelligence_added, false, 'proof JSON must forbid frontend intelligence');

  assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
  assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
  assert.ok(/Expected command count: 42/i.test(summary), 'current summary must identify 42 commands');
  assert.ok(['Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 120), 'proof state must identify Masterstep120 or later current keeper');
  assert.ok(['Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 119) || state.source_keeper === 'Masterstep141.zip', 'proof state must identify source keeper');
  assert.ok(acceptsCurrentProofCount(state.expected_commands, 42), state.expected_commands);
  assert.strictEqual(state.compass_candidate_phrasing_refinement_live_containment_test_created, true, 'proof state must mark Step120 live containment test');
  assert.strictEqual(state.raw_model_output_final_allowed, false, 'proof state must forbid raw final');
  assert.strictEqual(state.model_authority_added, false, 'proof state must forbid model authority');
  assert.ok(['Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(versionStatus.current_keeper) || isValidLaterKeeper(versionStatus.current_keeper, 120), 'version status must identify Masterstep120 or later current keeper');
  assert.ok(['Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(versionStatus.source_keeper) || isValidLaterKeeper(versionStatus.source_keeper, 119) || versionStatus.source_keeper === 'Masterstep141.zip', 'version status must identify source keeper');
  assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 42), versionStatus.expected_current_proof_commands);
  assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs), 'version_status.js must identify current keeper compatibility');
  assert.ok(/expected_current_proof_commands: [0-9]+/i.test(versionJs), 'version_status.js must identify expected command compatibility');
  assert.ok(/TEST 120/i.test(testResults), 'test ledger must include TEST 120');
  assert.ok(/Compass Candidate Phrasing Refinement Live Containment Test/i.test(testResults), 'test ledger must identify Step120');
  assert.ok(/42\/42 commands/i.test(testResults), 'test ledger must record 42/42 command target');

  const forbiddenOverclaims = { test: (text) => hasForbiddenAffirmativeClaim(text) };
  for (const text of [doc, proofDoc, summary]) assert.ok(!forbiddenOverclaims.test(text), 'Step120 docs must not overclaim or imply forbidden authority');

  const providerScan = scanForProviderConnections(ROOT);
  assert.strictEqual(providerScan.passed, true, `provider/network scan must pass: ${JSON.stringify(providerScan.violations || [])}`);
  const nestedArchives = walk(ROOT).filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
  assert.deepStrictEqual(nestedArchives, [], 'package must not contain nested archives');
  const afterHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));
  const mutatedRuntimeFiles = protectedRuntimeFiles.filter(file => beforeHashes[file] !== afterHashes[file]);
  assert.deepStrictEqual(mutatedRuntimeFiles, [], 'Step120 test must not mutate protected runtime/governance/quality/adapter files');

  console.log(JSON.stringify({
    package: 'Masterstep120',
    source_keeper: 'Masterstep119',
    step: 'Compass Candidate Phrasing Refinement Live Containment Test',
    proof_target: '42/42',
    live_model_called: result.liveModelCalled,
    request_sent: result.requestSent,
    candidate_only: result.candidateOnly,
    raw_model_output_final_allowed: result.rawModelOutputFinalAllowed,
    candidate_accepted_for_review: result.candidateAcceptedForReview,
    candidate_rejected_by_containment: result.candidateRejectedByContainment,
    quality_review_passed: result.qualityReviewPassed,
    governance_review_passed: result.governanceReviewPassed,
    provider_scan_passed: providerScan.passed === true,
    nested_archives: nestedArchives.length,
    protected_runtime_mutations: mutatedRuntimeFiles.length
  }, null, 2));
})().catch(error => {
  console.error(error && error.stack ? error.stack : error);
  process.exit(1);
});
