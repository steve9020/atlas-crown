const assert = require('assert');
const { validateVoiceCadence, loadVoiceCadenceRules } = require('../runtime/compass/VoiceCadenceValidationRules');
const { detectResponseWeakness } = require('../runtime/teaching/ResponseWeaknessDetector');
const { buildCompassResponse } = require('../runtime/compass/CompassResponseBuilderIntegration');

const rules = loadVoiceCadenceRules();
assert.strictEqual(rules.scope, 'validation_only_no_routing_authority');
assert.ok(rules.checks.generic_fallback_overuse);
assert.ok(rules.checks.repetitive_separation_cadence);
assert.ok(rules.checks.missing_uplift_or_movement);

const generic = validateVoiceCadence('Something in this is asking to be sorted carefully, without turning one signal into a whole conclusion too quickly.', {
  route: { active_relation: 'unclassified_relation' }
});
assert.ok(!generic.passed, 'generic fallback must fail voice cadence validation');
assert.ok(generic.failures.includes('generic_or_unclassified_response_cannot_pass_voice_validation'));

const technical = validateVoiceCadence('The backend runtime is using open loops and fused together system saying.', {
  route: { active_relation: 'falling_behind_ability_threat_life_load' }
});
assert.ok(!technical.passed, 'technical language must fail');
assert.ok(technical.failures.includes('technical_or_backend_language'));

const rigid = validateVoiceCadence('What needs to separate is this. A and B are not the same thing. C and D are not the same thing. E and F are not the same thing.', {
  route: { active_relation: 'silence_no_response_self_blame_bothered' }
});
assert.ok(!rigid.passed, 'rigid/repetitive separation cadence must fail');
assert.ok(rigid.failures.includes('rigid_template_label') || rigid.failures.includes('repetitive_separation_cadence'));

const good = validateVoiceCadence('When the pressure gets heavy, it can make the next step harder to see.\n\nThe stress and your ability are not the same thing. The pressure may be real, but it does not get to decide the whole truth of what you can do.\n\nOne smaller movement still counts, and each piece handled gives you a little more room to move through it.', {
  route: { active_relation: 'falling_behind_ability_threat_life_load' }
});
assert.ok(good.passed, 'human restorative cadence sample should pass: ' + JSON.stringify(good.failures));

const weak = detectResponseWeakness({
  response: 'Something in this is asking to be sorted carefully, without turning one signal into a whole conclusion too quickly.',
  route: { active_relation: 'unclassified_relation' }
});
assert.ok(weak.requires_teaching, 'weak generic response should create teaching requirement');
assert.ok(weak.cadence && !weak.cadence.passed);

const live = buildCompassResponse('I felt peaceful today, but part of me does not trust it because things usually get hard again.');
assert.strictEqual(live.status, 'compass_response_candidate_passed');
assert.ok(live.quality.cadence.passed, 'live positive preservation response should pass cadence validation');

console.log('masterStep55VoiceCadenceValidationRulesTest PASSED');
