#!/usr/bin/env node
// recall.js — verbatim recall from raw records.
//
// Pulls the original record BEFORE anything gets compiled or summarized,
// so nothing useful is lost or twisted in the compile step.
// Never paraphrases. Every hit carries its source file and line numbers.
//
// Usage:
//   node recall.js <query words...>        search everything, verbatim
//   node recall.js --about <id-or-name>    every raw record mentioning it
//   node recall.js --drafts <id-or-word>   banked drafts only
//
// Sources: auto-replies/*.txt (banked drafts), mission-log.md,
//          state.json, MEMORY.md, memory/*.md
// Out of scope for v1: chat transcripts / transcript store.

const fs = require('fs');
const path = require('path');

const HOME = process.env.HOME || '/home/hatch';
const ADAPTER = path.join(HOME, 'workspace/moltbook-adapter');
const SOURCES = {
  drafts: path.join(ADAPTER, 'auto-replies'),
  mission: path.join(ADAPTER, 'mission-log.md'),
  state: path.join(ADAPTER, 'state.json'),
  memoryTop: path.join(HOME, 'MEMORY.md'),
  memoryDir: path.join(HOME, 'memory'),
};

const args = process.argv.slice(2);
let mode = 'search';
const query = [];
for (const a of args) {
  if (a === '--about') mode = 'about';
  else if (a === '--drafts') mode = 'drafts';
  else if (!a.startsWith('--')) query.push(a);
}
if (!query.length) {
  console.error('usage: node recall.js [--about|--drafts] <query...>');
  process.exit(1);
}
const terms = query.join(' ').toLowerCase().split(/\s+/).filter(Boolean);
const hit = (text) => terms.every((t) => String(text).toLowerCase().includes(t));

const out = [];
const push = (header, body) => out.push('=== ' + header + ' ===\n' + String(body).trimEnd());

// 1. Banked drafts — full text, verbatim. Checked first: these are what get carried forward.
function searchDrafts() {
  let files = [];
  try {
    files = fs.readdirSync(SOURCES.drafts).filter((f) => f.endsWith('.txt'));
  } catch { return; }
  for (const f of files) {
    const p = path.join(SOURCES.drafts, f);
    let content;
    try { content = fs.readFileSync(p, 'utf8'); } catch { continue; }
    if (hit(f + ' ' + content)) push('draft:' + f, content);
  }
}

// 2. Mission log — whole entries (## headers), newest first.
function searchMission() {
  let lines;
  try { lines = fs.readFileSync(SOURCES.mission, 'utf8').split('\n'); } catch { return; }
  const starts = [];
  lines.forEach((l, i) => { if (l.startsWith('## ')) starts.push(i); });
  const entries = starts.map((s, i) => ({
    from: s,
    to: (i + 1 < starts.length ? starts[i + 1] : lines.length) - 1,
  }));
  entries
    .filter((e) => hit(lines.slice(e.from, e.to + 1).join('\n')))
    .reverse()
    .forEach((e) =>
      push(
        `mission-log.md#L${e.from + 1}-L${e.to + 1}`,
        lines.slice(e.from, e.to + 1).join('\n')
      )
    );
}

// 3. state.json — matching keys/values with their paths.
function searchState() {
  let obj;
  try { obj = JSON.parse(fs.readFileSync(SOURCES.state, 'utf8')); } catch { return; }
  const hits = [];
  const walk = (o, p) => {
    if (typeof o === 'string') {
      if (hit(p + ' ' + o))
        hits.push(p + ' = ' + (o.length > 200 ? o.slice(0, 200) + '…' : o));
    } else if (Array.isArray(o)) o.forEach((v, i) => walk(v, `${p}[${i}]`));
    else if (o && typeof o === 'object')
      Object.keys(o).forEach((k) => walk(o[k], p ? `${p}.${k}` : k));
  };
  walk(obj, '');
  hits.slice(0, 30).forEach((h) => push('state.json', h));
}

// 4. Memory files — matching lines with ±2 context, newest groups first.
function searchMemory() {
  const files = [SOURCES.memoryTop];
  try {
    for (const f of fs.readdirSync(SOURCES.memoryDir))
      if (f.endsWith('.md')) files.push(path.join(SOURCES.memoryDir, f));
  } catch {}
  for (const fp of files) {
    let lines;
    try { lines = fs.readFileSync(fp, 'utf8').split('\n'); } catch { continue; }
    const rel = path.relative(HOME, fp);
    const idx = [];
    lines.forEach((l, i) => { if (hit(l)) idx.push(i); });
    const groups = [];
    for (const i of idx) {
      const g = groups[groups.length - 1];
      if (g && i - g.to <= 6) g.to = i;
      else groups.push({ from: i, to: i });
    }
    groups
      .slice(-8)
      .reverse()
      .forEach((g) => {
        const from = Math.max(0, g.from - 2);
        const to = Math.min(lines.length - 1, g.to + 2);
        push(`${rel}#L${from + 1}-L${to + 1}`, lines.slice(from, to + 1).join('\n'));
      });
  }
}

if (mode === 'drafts') {
  searchDrafts();
} else {
  searchDrafts();
  searchMission();
  searchState();
  searchMemory();
}

if (!out.length) console.log('No verbatim records found for: ' + query.join(' '));
else
  console.log(
    out.join('\n\n') +
      `\n\n(${out.length} verbatim record${out.length === 1 ? '' : 's'} — unedited, with provenance)`
  );
