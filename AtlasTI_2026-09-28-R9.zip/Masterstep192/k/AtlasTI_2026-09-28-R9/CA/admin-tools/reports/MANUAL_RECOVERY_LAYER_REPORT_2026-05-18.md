# Manual Recovery Layer Report — 2026-05-18

## Status

Manual Recovery Layer added as an external admin tool.

## Added Files

- `admin-tools/recovery/manual-recovery-manager.js`
- `admin-tools/recovery/README_MANUAL_RECOVERY_MANAGER.md`
- `admin-tools/recovery/snapshots/`
- `admin-tools/recovery/quarantine/`
- `admin-tools/recovery/reports/`

## Purpose

Provide a manual, out-of-band recovery path if the active vault becomes damaged, corrupted, or misconfigured during testing.

## Hard Boundary

The recovery tool is not connected to the Obsidian plugin runtime.

```txt
main.js cannot call recovery.
Atlas cannot trigger recovery.
Recovery cannot run automatically.
Obsidian must be closed before recovery.
```

## Supported Commands

```cmd
node manual-recovery-manager.js --snapshot <path_to_Continuity_Architecture> [label]
node manual-recovery-manager.js --verify-snapshot <path_to_snapshot_folder>
node manual-recovery-manager.js --dry-run-restore <path_to_snapshot_folder> <path_to_Continuity_Architecture>
node manual-recovery-manager.js --restore <path_to_snapshot_folder> <path_to_Continuity_Architecture> "<Developer Signature>"
```

## Restore Safety

Before restore, the current target vault is copied into:

```txt
admin-tools/recovery/quarantine/
```

The restored vault is hash-verified against the selected snapshot manifest.

## Verification Expectations

- `main.js` must have zero references to `manual-recovery-manager.js`.
- `main.js` must have zero recovery-tool references.
- Recovery remains external/manual only.
