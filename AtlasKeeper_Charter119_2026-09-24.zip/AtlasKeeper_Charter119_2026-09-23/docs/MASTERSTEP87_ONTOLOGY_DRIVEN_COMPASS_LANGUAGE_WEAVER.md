# Masterstep87 — Ontology-Driven Compass Language Weaver

Source keeper: Masterstep86.zip
Current keeper: Masterstep87.zip

Purpose: correct the Step86 renderer so final Compass language uses the existing Golden Compass/adaptive language assets and Atlas semantic/Doyle evidence before falling back to hard-coded prompt branches.

Scope:
- No deletion.
- No new ontology.
- No new mechanisms.
- No provider/model/cloud/API/network bridge.
- No operator console.
- No frontend intelligence.

Implemented:
- Added `runtime/compass/CompassOntologyLanguageWeaver.js`.
- Wired `CompassSeeSeparateRestoreRenderer.js` to try ontology-driven See / Separate / Deconstruct / Restore sections first.
- Preserved existing specific handling for productive displacement and literal day-to-day pileup cases.
- Updated `GovernanceAdapter.js` so visible Compass section labels are stripped before governance scanning, preventing false governance blocks while keeping frontend-visible sections intact.

Result: final Compass output is less dependent on prompt-specific branches and more able to draw from existing language/ontology fields.
