# Bridge Verification Prompt

## Test Prompt
my sister wont talk to me i dont know if i did anything to make her close me out

## Expected Runtime Route
relational_attachment_uncertainty

## Expected Active Definition
family_silence_cutoff or relational_uncertainty_self_blame

## Expected Response Direction
- name relational uncertainty
- name silence/distance
- identify self-blame pressure
- separate worry from proof
- avoid practical task framing
- avoid generic emotional weight lead
