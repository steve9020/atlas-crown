# Live Response Definition Activation

## Purpose
New semantic/backend terms must be available in the actual response-definition layer, not only in inactive registries.

## Activated Terms
- sister
- won't talk / wont talk
- not talking to me
- close me out
- shut me out
- cut me off
- did I do anything
- did I do something
- make her / make him / make them

## Correct Route
family silence / relational cutoff

## Relational Role Ontology Update

Relational title interpretation is now supported through `53 Relational Role Ontology`.
