# Natural Rhythm Calibration

## Human Rhythm
Humans:
- simplify naturally
- pause naturally
- avoid sounding optimized
- speak proportionally

## Avoid
- repetitive sentence openings
- identical pacing
- overly structured transitions
- constant abstract phrasing
