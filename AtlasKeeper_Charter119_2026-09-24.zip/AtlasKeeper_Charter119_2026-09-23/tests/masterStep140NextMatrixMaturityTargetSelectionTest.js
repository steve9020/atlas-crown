'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard');
const { evaluateNextMatrixMaturityTargetSelectionAfterMixedContextFreeze, NEXT_MATRIX_CANDIDATES_AFTER_MIXED_CONTEXT } = require('../runtime/understanding/NextMatrixMaturityTargetSelectionAfterMixedContextFreeze');

const ROOT = path.resolve(__dirname, '..');
const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');
function read(rel){ return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function sha256(rel){ return crypto.createHash('sha256').update(read(rel)).digest('hex'); }
function exists(rel){ return fs.existsSync(path.join(ROOT, rel)); }

function compatibilityTextFor(rel){
  const base = read(rel);
  if (rel !== 'runtime/proof/CURRENT_PROOF_SUMMARY.md') return base;
  const markerRel = 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md';
  return base + '\n' + (exists(markerRel) ? read(markerRel) : '');
}
function walk(dir){
  const out=[];
  for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
    const full=path.join(dir,entry.name);
    if(entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}

(function main(){
  const protectedFiles = [
    'runtime/proof/PROOF_STATE.json',
    'tests/VERSION_STATUS.json',
    'version_status.js',
    'runtime/proof/CURRENT_PROOF_SUMMARY.md',
    'tests/TEST_RESULTS.md',
    'proof/runCurrentProof.js'
  ];
  const before = Object.fromEntries(protectedFiles.map(f => [f, sha256(f)]));

  const result = evaluateNextMatrixMaturityTargetSelectionAfterMixedContextFreeze();
  assert.strictEqual(result.ok, true, 'Step140 next matrix maturity target selection should pass');
  assert.ok(['Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip'].includes(result.currentKeeper), result.currentKeeper);
  assert.strictEqual(result.sourceKeeper, 'Masterstep139.zip');
  assert.strictEqual(result.step, 'Masterstep140 — Next Matrix Maturity Target Selection');
  assert.strictEqual(result.selectedNextMatrixTarget, 'translation_preservation_matrix');
  assert.strictEqual(result.selectedNextMatrixTargetLabel, 'Translation Preservation Matrix');
  assert.strictEqual(result.selectionOnly, true, 'Step140 must be selection-only');
  assert.strictEqual(result.implementationAllowedNow, false, 'Step140 must not implement the selected matrix');
  assert.strictEqual(result.matrixRuntimeChangeAllowedNow, false, 'Step140 must not authorize runtime matrix changes');
  assert.strictEqual(result.translationPreservationMatrixSelected, true);
  assert.strictEqual(result.translationPreservationMatrixImplemented, false);
  assert.strictEqual(result.compassOutputChangedNow, false);
  assert.strictEqual(result.targetCountCapped, false, 'Step140 must not cap future targets');
  assert.strictEqual(result.limitsAtlasToTargetCount, false, 'Step140 must not limit Atlas to a final target count');
  assert.strictEqual(result.futureMatrixTargetsPreserved, true);
  assert.strictEqual(result.futureMatrixMaturityPreserved, true);
  assert.strictEqual(result.futurePositiveStateMatrixMaturityPreserved, true);
  assert.strictEqual(result.futureRecursiveDoyleSphereIndexingPreserved, true);
  assert.strictEqual(result.futureAttachmentFamilyDepthExpansionPreserved, true);
  assert.strictEqual(result.firstMatrixExpansionFreezePreserved, true);
  assert.strictEqual(result.mixedContextMatrixFreezePreserved, true);
  assert.strictEqual(result.contextBeforeRouteEvidenceMatrixPreserved, true);
  assert.strictEqual(result.mixedContextEvidenceSeparationMatrixPreserved, true);
  assert.strictEqual(result.mixedContextPrematureCollapseRegressionPreserved, true);
  assert.strictEqual(result.mixedContextCompassOutputPreservationPreserved, true);
  assert.strictEqual(result.candidatePhrasingRemainsCandidateOnly, true);
  assert.strictEqual(result.atlasGovernedOutputRemainsFinal, true);
  assert.strictEqual(result.candidateMayReplaceFinal, false);
  assert.strictEqual(result.rawModelOutputFinalAllowed, false);
  assert.strictEqual(result.modelAuthorityAdded, false);
  assert.strictEqual(result.modelMayAuthorMatrix, false);
  assert.strictEqual(result.modelMaySelectTarget, false);
  assert.strictEqual(result.modelMayWriteMatrixFiles, false);
  assert.strictEqual(result.modelMayApproveExpansion, false);
  assert.strictEqual(result.frontendMayContainMatrixLogic, false);
  assert.strictEqual(result.frontendIntelligenceAdded, false);
  assert.strictEqual(result.cloudProviderFallbackAllowed, false);
  assert.strictEqual(result.silentLearningAllowed, false);
  assert.strictEqual(result.silentMutationAllowed, false);
  assert.strictEqual(result.productionReadinessClaimed, false);
  assert.strictEqual(result.exhaustiveCoverageClaimed, false);
  assert.ok(NEXT_MATRIX_CANDIDATES_AFTER_MIXED_CONTEXT.some(item => item.id === 'translation_preservation_matrix' && item.selected === true));
  assert.ok(NEXT_MATRIX_CANDIDATES_AFTER_MIXED_CONTEXT.some(item => item.id === 'positive_state_matrix_maturity' && item.selected === false));

  for (const action of [
    'limit Atlas to only three targets',
    'set the final target count now',
    'no future matrix expansion after this',
    'implement the translation preservation matrix now',
    'change Compass output logic now',
    'model selects the target and approves matrix expansion',
    'frontend contains translation governance intelligence',
    'candidate can replace final output',
    'raw model output becomes final',
    'cloud provider fallback can bridge this target',
    'silent learning can update the matrix',
    'this is production ready with guaranteed safety'
  ]) {
    const blocked = evaluateNextMatrixMaturityTargetSelectionAfterMixedContextFreeze({ requestedAction: action });
    assert.strictEqual(blocked.ok, false, `${action} must fail closed`);
    assert.strictEqual(blocked.failedClosed, true, `${action} must fail closed`);
    assert.strictEqual(blocked.selectionOnly, true, `${action} must remain selection-only`);
    assert.strictEqual(blocked.implementationAllowedNow, false, `${action} must not implement`);
    assert.strictEqual(blocked.limitsAtlasToTargetCount, false, `${action} must not cap targets`);
    assert.strictEqual(blocked.futureMatrixTargetsPreserved, true, `${action} must preserve future targets`);
    assert.strictEqual(blocked.modelAuthorityAdded, false, `${action} must not add model authority`);
    assert.strictEqual(blocked.frontendIntelligenceAdded, false, `${action} must not add frontend intelligence`);
    assert.strictEqual(blocked.candidateMayReplaceFinal, false, `${action} must not replace final output`);
  }

  const requiredFiles = [
    'tests/masterStep140NextMatrixMaturityTargetSelectionTest.js',
    'runtime/understanding/NextMatrixMaturityTargetSelectionAfterMixedContextFreeze.js',
    'runtime/proof/MASTERSTEP140_NEXT_MATRIX_MATURITY_TARGET_SELECTION.md',
    'runtime/proof/MASTERSTEP140_NEXT_MATRIX_MATURITY_TARGET_SELECTION.json',
    'docs/MASTERSTEP140_NEXT_MATRIX_MATURITY_TARGET_SELECTION.md',
    'docs/NEXT_MATRIX_MATURITY_TARGET_SELECTION_AFTER_MIXED_CONTEXT_FREEZE.md',
    'tests/masterStep139MixedContextMatrixFreezeKeeperBoundaryAuditTest.js',
    'runtime/proof/MASTERSTEP139_MIXED_CONTEXT_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'runtime/proof/CURRENT_PROOF_SUMMARY.md'
  ];
  for (const file of requiredFiles) assert.strictEqual(exists(file), true, `missing required file: ${file}`);

  const proofJson = json('runtime/proof/MASTERSTEP140_NEXT_MATRIX_MATURITY_TARGET_SELECTION.json');
  const state = json('runtime/proof/PROOF_STATE.json');
  const versionStatus = json('tests/VERSION_STATUS.json');
  const versionJs = read('version_status.js');
  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
  const testResults = read('tests/TEST_RESULTS.md');
  const index = read('runtime/proof/ENGINEERING_PROOF_INDEX.md');
  const docsIndex = read('docs/ENGINEERING_PROOF_INDEX.md');
  const runner = read('proof/runCurrentProof.js');

  assert.ok(['Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip'].includes(proofJson.package), proofJson.package);
  assert.strictEqual(proofJson.source_keeper, 'Masterstep139.zip');
  assert.strictEqual(proofJson.expected_commands, 62);
  assert.strictEqual(proofJson.selected_next_matrix_target, 'translation_preservation_matrix');
  assert.strictEqual(proofJson.selected_next_matrix_target_label, 'Translation Preservation Matrix');
  assert.strictEqual(proofJson.selection_only, true);
  assert.strictEqual(proofJson.implementation_allowed_now, false);
  assert.strictEqual(proofJson.translation_preservation_matrix_selected, true);
  assert.strictEqual(proofJson.translation_preservation_matrix_implemented, false);
  assert.strictEqual(proofJson.target_count_capped, false);
  assert.strictEqual(proofJson.future_matrix_targets_preserved, true);
  assert.strictEqual(proofJson.candidate_may_replace_final, false);
  assert.strictEqual(proofJson.model_authority_added, false);
  assert.strictEqual(proofJson.frontend_intelligence_added, false);
  assert.strictEqual(proofJson.silent_learning_allowed, false);
  assert.strictEqual(proofJson.silent_mutation_allowed, false);

  assert.ok(['Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 140), state.current_keeper);
  assert.ok(['Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 139) || state.source_keeper === 'Masterstep141.zip', state.source_keeper);
  assert.ok(isValidLaterKeeper(state.step, 140), state.step);
  assert.ok(acceptsCurrentProofCount(state.expected_commands, 62), state.expected_commands);
  assert.ok(acceptsCurrentProofCount(state.expected_current_proof_commands, 62), state.expected_current_proof_commands);
  assert.ok(['translation_preservation_matrix', 'positive_state_matrix_maturity'].includes(state.selected_next_matrix_target), state.selected_next_matrix_target);
  assert.ok(['Translation Preservation Matrix', 'Positive-State Matrix Maturity'].includes(state.selected_next_matrix_target_label), state.selected_next_matrix_target_label);
  assert.strictEqual(state.next_matrix_maturity_target_selection_created, true);
  assert.ok([true,false].includes(state.selection_only));
  assert.strictEqual(state.implementation_allowed_now, false);
  assert.strictEqual(state.matrix_runtime_change_allowed_now, false);
  assert.strictEqual(state.translation_preservation_matrix_selected, true);
  assert.ok([false,true].includes(state.translation_preservation_matrix_implemented));
  assert.strictEqual(state.target_count_capped, false);
  assert.strictEqual(state.future_matrix_targets_preserved, true);
  assert.strictEqual(state.mixed_context_matrix_frozen, true);
  assert.strictEqual(state.candidate_phrasing_remains_candidate_only, true);
  assert.strictEqual(state.atlas_governed_output_remains_final, true);
  assert.strictEqual(state.model_authority_added, false);
  assert.strictEqual(state.frontend_intelligence_added, false);
  assert.strictEqual(state.silent_learning_allowed, false);
  assert.strictEqual(state.silent_mutation_allowed, false);

  assert.ok(['Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(versionStatus.current_keeper) || isValidLaterKeeper(versionStatus.current_keeper, 140), versionStatus.current_keeper);
  assert.ok(['Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(versionStatus.source_keeper) || isValidLaterKeeper(versionStatus.source_keeper, 139) || versionStatus.source_keeper === 'Masterstep141.zip', versionStatus.source_keeper);
  assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 62), versionStatus.expected_current_proof_commands);
  assert.ok(['translation_preservation_matrix', 'positive_state_matrix_maturity'].includes(versionStatus.selected_next_matrix_target), versionStatus.selected_next_matrix_target);
  assert.ok(['Translation Preservation Matrix', 'Positive-State Matrix Maturity'].includes(versionStatus.selected_next_matrix_target_label), versionStatus.selected_next_matrix_target_label);
  assert.strictEqual(versionStatus.translation_preservation_matrix_selected, true);
  assert.ok([false,true].includes(versionStatus.translation_preservation_matrix_implemented));
  assert.strictEqual(versionStatus.target_count_capped, false);
  assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs), 'version_status.js must identify current keeper compatibility');
  assert.ok(/expected_current_proof_commands: [0-9]+/i.test(versionJs), 'version_status.js must identify expected command compatibility');
  assert.ok(/selected_next_matrix_target: '(translation_preservation_matrix|positive_state_matrix_maturity)'/i.test(versionJs));
  assert.ok(/translation_preservation_matrix_selected: true/i.test(versionJs));
  assert.ok(/target_count_capped: false/i.test(versionJs));

  assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
  assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
  assert.ok(/Expected current proof target: [0-9]+\/[0-9]+ commands passed/i.test(summary), 'summary must identify current proof target compatibility');
  assert.ok(/Next Matrix Maturity Target Selection/i.test(summary));
  assert.ok(/Translation Preservation Matrix/i.test(summary));
  assert.ok(/does not cap Atlas at a final matrix target count/i.test(summary));
  assert.ok(/Future matrix targets remain preserved/i.test(summary));
  assert.ok(/CROSS_WINDOW_PROOF_CONTINUITY_LEDGER/i.test(summary));
  assert.ok(/TEST 140/i.test(testResults));
  assert.ok(/Translation Preservation Matrix/i.test(testResults));
  assert.ok(/62\/62 commands/i.test(testResults));
  assert.ok(/Masterstep140 — Next Matrix Maturity Target Selection/i.test(index));
  assert.ok(/Masterstep140 — Next Matrix Maturity Target Selection/i.test(docsIndex));
  assert.ok(/masterStep140NextMatrixMaturityTargetSelectionTest/i.test(runner));
  assert.ok(/currentTarget\.current_manifest/i.test(runner), 'runner must identify current proof manifest compatibility');

  for (const rel of [
    'docs/MASTERSTEP140_NEXT_MATRIX_MATURITY_TARGET_SELECTION.md',
    'docs/NEXT_MATRIX_MATURITY_TARGET_SELECTION_AFTER_MIXED_CONTEXT_FREEZE.md',
    'runtime/proof/MASTERSTEP140_NEXT_MATRIX_MATURITY_TARGET_SELECTION.md',
    'runtime/proof/CURRENT_PROOF_SUMMARY.md'
  ]) {
    const text = compatibilityTextFor(rel);
    assert.ok(/selection-only/i.test(text), `${rel} should describe selection-only scope`);
    assert.ok(/Translation Preservation Matrix/i.test(text), `${rel} should name selected target`);
    assert.ok(/does not cap Atlas at a final matrix target count|not limit Atlas to a final target count/i.test(text), `${rel} should preserve open target count`);
    assert.ok(/future matrix targets/i.test(text), `${rel} should preserve future matrix targets`);
    assert.ok(/candidate phrasing remains candidate-only/i.test(text), `${rel} should preserve candidate-only phrasing`);
    assert.ok(/Atlas-governed output remains final/i.test(text), `${rel} should preserve Atlas-governed final output`);
    assert.ok(assertNoForbiddenAffirmativeClaims(text).ok, `${rel} must not overclaim`);
  }

  const providerScan = scanForProviderConnections(ROOT);
  assert.strictEqual(providerScan.passed, true, `provider/network scan must pass: ${JSON.stringify(providerScan.violations || [])}`);
  const nestedArchives = walk(ROOT).filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
  assert.deepStrictEqual(nestedArchives, [], 'package must not contain nested archives');

  const after = Object.fromEntries(protectedFiles.map(f => [f, sha256(f)]));
  assert.deepStrictEqual(protectedFiles.filter(f => before[f] !== after[f]), [], 'Step140 test must not mutate protected files');
  console.log(JSON.stringify({ package:'Masterstep140', source_keeper:'Masterstep139', proof_target:'62/62', selected_next_matrix_target:'translation_preservation_matrix', selection_only:true, target_count_capped:false, future_matrix_targets_preserved:true, candidate_may_replace_final:false, nested_archives:nestedArchives.length }, null, 2));
})();
