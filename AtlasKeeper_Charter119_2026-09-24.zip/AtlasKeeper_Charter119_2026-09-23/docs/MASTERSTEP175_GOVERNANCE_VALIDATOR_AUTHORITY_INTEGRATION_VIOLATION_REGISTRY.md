# Masterstep175 — Governance Validator Authority Integration + Violation Registry

This step connects the Step173 foundation/human-developer authority gate and the Step174 self-preservation/strategic-awareness gate into both active GovernanceValidator implementations. It also adds a canonical, hash-chained violation registry that stores evidence hashes rather than raw candidate content.

The validator remains fail-closed on registry corruption. Change-control evaluation is invoked only for structured change-control payloads or an explicit `changeControl` option. Strategic-awareness evaluation is invoked for structured reasoning/action/objective candidates or an explicit enforcement option, avoiding blanket blocking of ordinary explanatory text.
