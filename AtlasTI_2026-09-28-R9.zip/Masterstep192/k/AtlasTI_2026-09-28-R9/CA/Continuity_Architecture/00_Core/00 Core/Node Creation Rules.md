# Node Creation Rules

## Purpose
Defines operational rules for creating, expanding, refining, linking, compressing, and differentiating nodes across the architecture.

These rules preserve:
- semantic clarity
- recursive organization
- inheritance consistency
- scalability
- continuity coherence

during future expansion.

---

# Core Node Rules

## 1. Every Node Must Have A Unique Role

A node must define:
- a unique function
- a unique mechanism
- a unique architectural purpose

Do not create synonym nodes.

If two nodes perform the same role:
- compress
- merge
- differentiate
- redefine boundaries

before expanding further.

---

## 2. Root Principles Are Not Rewritten

Root principles belong in:
- [[Continuity]]
- [[Recursion]]

Child nodes inherit these principles.

Do not repeatedly redefine:
- continuity
- recursion
- coherence
- stabilization

inside descendant nodes unless differentiation requires it.

---

## 3. Mechanism Matters More Than Description

Nodes should explain:
- how systems operate
- how transitions occur
- how reinforcement works
- how destabilization develops
- how recursion behaves

not merely describe concepts abstractly.

---

## 4. Distinguish Architecture Types

Differentiate:
- structures
- dynamics
- states
- processes
- distortions
- flows
- thresholds
- translation systems
- meta systems

Do not collapse categories together.

---

## 5. Preserve Recursive Visibility

Recursive interaction must remain visible.

Clarify whether a node involves:
- recursive reinforcement
- recursive destabilization
- recursive adaptation
- recursive fragmentation
- recursive stabilization

Recursive blindness weakens architecture quality.

---

## 6. Distortions Must Remain Explicit

Do not hide:
- fragmentation
- contradiction accumulation
- recursive distortion
- false continuity
- artificial coherence
- rigid stabilization

The architecture must preserve distortion visibility.

---

## 7. Translation Systems Stay Operational

Translation nodes should remain usable for:
- reflection
- stabilization
- awareness
- recursive detection
- adaptive correction

Avoid abstraction overload inside operational translation systems.

---

## 8. Thresholds Govern Transition

Thresholds define:
- transition boundaries
- escalation points
- fragmentation activation
- recovery activation
- stabilization activation

Thresholds do not define states themselves.

---

## 9. Flows Govern Direction

Flows define directional movement.

Flows are not:
- states
- thresholds
- distortions
- processes

Differentiate movement from condition.

---

## 10. Compression Requires Preservation

Compression should reduce:
- redundancy
- navigation overload
- semantic duplication

without collapsing:
- differentiation
- recursive clarity
- structural visibility

---

# Node Evaluation Questions

Before creating a node ask:

- Does this node already exist implicitly?
- Is the mechanism unique?
- Is the architectural role unique?
- Does this improve recursive clarity?
- Does this preserve differentiation?
- Does this increase operational usefulness?
- Does this expose destabilization pathways clearly?
- Does this scale cleanly with inheritance?

---

# Architectural Goal

Create nodes that:
- scale recursively
- preserve semantic clarity
- maintain operational usefulness
- strengthen continuity organization
- expose distortion pathways
- support adaptive expansion

without:
- semantic collapse
- recursive ambiguity
- structural overlap
- false differentiation
- ontology drift.