#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const root = process.cwd();
function p(rel){ return path.join(root, rel); }
function read(rel){ return fs.readFileSync(p(rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function assert(c,m){ if(!c){ console.error(`FAIL: ${m}`); process.exit(1); } }
function includesAll(text, markers, label){ for (const marker of markers) assert(text.includes(marker), `${label} missing marker: ${marker}`); }
const required = ['runtime/governance/FULL_INVARIANT_COVERAGE.json','runtime/governance/OUTER_GOVERNANCE_ORDER_INVARIANT.json','runtime/proof/CURRENT_PROOF_SUMMARY.md','tests/SNAPSHOT_VAULT_POLICY.json','CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_12D_PASS1_IMPLEMENTATION_STAGED.md'];
for (const rel of required) assert(fs.existsSync(p(rel)), `required pass1 implementation proof missing: ${rel}`);
const full = json('runtime/governance/FULL_INVARIANT_COVERAGE.json');
includesAll(full.proof_of_work_completeness_required_items.join('\n'), ['step_patch_proof','carry_forward_proof','fuzz_proof','hygiene_proof','version_status_proof','snapshot_metadata_proof','missing_dependency_halt_proof','governance_order_halt_proof','invariant_conflict_proof','recovery_before_expansion_proof','historical_integrity_proof','human_halt_authority_proof','scan_safe_package_proof'], 'proof completeness required items');
const stagedProof = read('CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_12D_PASS1_IMPLEMENTATION_STAGED.md');
includesAll(stagedProof, ['IMPLEMENTATION STAGED','This pass is not a closure','Pass 2 must prove, fuzz, check hygiene, and package scan-clean before keeper promotion'], 'pass1 staging proof');
const currentSummary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md');
includesAll(currentSummary, ['Current keeper: `Masterstep12_patch03.zip`','Proof State Consistency Repair','final/current only'], 'current proof summary');
assert(!currentSummary.includes('IMPLEMENTATION STAGED'), 'current proof summary must not carry Pass 1 staging markers after closure');
console.log('MASTER STEP 12 PATCH 02 — PROOF COMPLETENESS STAGING TEST');
console.log('Result: PASSED');
