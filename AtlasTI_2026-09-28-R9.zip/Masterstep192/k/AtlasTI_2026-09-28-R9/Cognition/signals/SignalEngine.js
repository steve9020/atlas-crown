const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const SIGNAL_REGISTRY_PATH = "CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/runtime_signal_registry.md";

let cachedSignalRegistry = null;

function getSignalRegistry() {
  if (!cachedSignalRegistry) {
    cachedSignalRegistry = readJsonRegistry(SIGNAL_REGISTRY_PATH);
  }
  return cachedSignalRegistry;
}

function normalizeInput(input) {
  return String(input || "").toLowerCase();
}

function phraseMatches(text, phrase) {
  if (typeof phrase !== "string" || phrase.length === 0) {
    return false;
  }
  return text.includes(phrase.toLowerCase());
}

function anyPhraseMatches(text, phrases) {
  if (!Array.isArray(phrases) || phrases.length === 0) {
    return false;
  }
  return phrases.some((phrase) => phraseMatches(text, phrase));
}

function allGroupsMatch(text, groups) {
  if (!Array.isArray(groups) || groups.length === 0) {
    return true;
  }

  return groups.every((group) => {
    const phrases = Array.isArray(group.phrases) ? group.phrases : [];
    return anyPhraseMatches(text, phrases);
  });
}

function ruleMatches(text, rule) {
  const directPhrases = Array.isArray(rule.phrases) ? rule.phrases : [];
  const groups = Array.isArray(rule.allGroups) ? rule.allGroups : [];

  if (groups.length > 0 && !allGroupsMatch(text, groups)) {
    return false;
  }

  if (directPhrases.length > 0 && !anyPhraseMatches(text, directPhrases)) {
    return false;
  }

  return groups.length > 0 || directPhrases.length > 0;
}

function detectSignals(input) {
  const text = normalizeInput(input);
  const registry = getSignalRegistry();
  const rules = Array.isArray(registry.rules) ? [...registry.rules] : [];
  const signals = [];

  rules.sort((a, b) => (a.priority || 9999) - (b.priority || 9999));

  for (const rule of rules) {
    if (rule && rule.signal && ruleMatches(text, rule)) {
      signals.push(rule.signal);
    }
  }

  return [...new Set(signals)];
}

module.exports = { detectSignals };
