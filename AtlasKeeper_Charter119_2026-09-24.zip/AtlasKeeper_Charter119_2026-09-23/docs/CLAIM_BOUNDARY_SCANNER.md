# Claim Boundary Scanner

The Claim Boundary Scanner is proof-infrastructure for community-review and reviewer-facing documentation. It distinguishes forbidden affirmative claims from safe boundary exclusions.

## Purpose

Older proof tests used broad phrase regex checks. Those checks could not tell the difference between an unsafe claim and a boundary sentence that explicitly rejects that claim.

Examples:

- Forbidden affirmative claim: `Atlas is production-ready.`
- Allowed boundary exclusion: `Atlas is not production-ready.`
- Forbidden affirmative claim: `Raw model output is final.`
- Allowed boundary exclusion: `Raw model output is not final.`

## Boundary

This scanner does not change runtime behavior, Compass output, safety routing, matrix capability, model authority, frontend intelligence, cloud/provider fallback, silent learning, or silent mutation. It is proof/documentation infrastructure only.
