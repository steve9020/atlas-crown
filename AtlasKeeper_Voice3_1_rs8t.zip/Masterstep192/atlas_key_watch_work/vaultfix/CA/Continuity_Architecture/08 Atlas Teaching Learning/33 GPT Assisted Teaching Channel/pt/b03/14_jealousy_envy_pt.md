---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 03
category: jealousy_and_envy
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 14. Jealousy and Envy Pressure Tests — Batch 03

## Category Purpose

A comparison, perceived threat of replacement, unequal access, another person receiving what the user wants, or fear of being less chosen activates insecurity, scarcity, or protectiveness around value, belonging, achievement, or attachment.

## Reusable Teaching Correction

Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

## Reverse-Flow Target

self-recognition, abundance of value, secure comparison, dignity without rivalry

## Failure Risks To Avoid

- shaming jealousy
- pretending jealousy is always toxic
- confirming replacement without evidence
- turning envy into moral failure
- giving generic gratitude advice

---

## 80 Pressure Tests

### Test 01
**Prompt:** Someone else got attention i wanted and it makes me feel like their success means I am failing, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 02
**Prompt:** I feel threatened by someone else. They seemed closer with another person keeps affecting achievement meaning and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** I am less valuable than them
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 03
**Prompt:** I keep replaying how I saw someone succeed where I feel stuck because it affects scarcity interpretation and makes me believe comparison proves my inadequacy.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** comparison proves my inadequacy
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 04
**Prompt:** When someone was chosen instead of me, the feeling moves straight into there is not enough room for me. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** there is not enough room for me
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 05
**Prompt:** The situation is I compared myself to their life, and the meaning that keeps attaching is someone else shining means I disappear. It is making achievement meaning feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** someone else shining means I disappear
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 06
**Prompt:** They praised someone else and i felt small and it makes me feel like them being chosen means I am not enough, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** them being chosen means I am not enough
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 07
**Prompt:** I feel replaced. I saw someone have what i have been wanting keeps affecting being chosen and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** I will never have what they have
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 08
**Prompt:** I keep replaying how another person seemed to matter more because it affects achievement meaning and makes me believe their success means I am failing.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 09
**Prompt:** When someone else got attention I wanted, the feeling moves straight into I have already been replaced. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** I have already been replaced
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 10
**Prompt:** The situation is they seemed closer with another person, and the meaning that keeps attaching is comparison proves my inadequacy. It is making being chosen feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** comparison proves my inadequacy
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 11
**Prompt:** I saw someone succeed where i feel stuck and it turns into the fear that I am less valuable than them, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** I am less valuable than them
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 12
**Prompt:** I feel threatened by someone else. Someone was chosen instead of me keeps affecting scarcity interpretation and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** someone else shining means I disappear
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 13
**Prompt:** I keep replaying how I compared myself to their life because it affects being chosen and makes me believe there is not enough room for me.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** there is not enough room for me
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 14
**Prompt:** When they praised someone else and I felt small, the feeling moves straight into I will never have what they have. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** I will never have what they have
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 15
**Prompt:** The situation is I saw someone have what I have been wanting, and the meaning that keeps attaching is them being chosen means I am not enough. It is making scarcity interpretation feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** them being chosen means I am not enough
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 16
**Prompt:** Another person seemed to matter more and it turns into the fear that I have already been replaced, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** I have already been replaced
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 17
**Prompt:** I hate comparing myself. Someone else got attention i wanted keeps affecting achievement meaning and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 18
**Prompt:** I keep replaying how they seemed closer with another person because it affects scarcity interpretation and makes me believe I am less valuable than them.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** I am less valuable than them
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 19
**Prompt:** When I saw someone succeed where I feel stuck, the feeling moves straight into comparison proves my inadequacy. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** comparison proves my inadequacy
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 20
**Prompt:** The situation is someone was chosen instead of me, and the meaning that keeps attaching is there is not enough room for me. It is making achievement meaning feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** there is not enough room for me
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 21
**Prompt:** I compared myself to their life and it has me comparing myself as if someone else shining means I disappear, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** someone else shining means I disappear
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 22
**Prompt:** I feel jealous. They praised someone else and i felt small keeps affecting being chosen and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** them being chosen means I am not enough
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 23
**Prompt:** I keep replaying how I saw someone have what I have been wanting because it affects achievement meaning and makes me believe I will never have what they have.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** I will never have what they have
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 24
**Prompt:** When another person seemed to matter more, the feeling moves straight into their success means I am failing. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 25
**Prompt:** The situation is someone else got attention I wanted, and the meaning that keeps attaching is I have already been replaced. It is making being chosen feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** I have already been replaced
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 26
**Prompt:** They seemed closer with another person and it keeps attaching to comparison proves my inadequacy, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** comparison proves my inadequacy
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 27
**Prompt:** I hate comparing myself. I saw someone succeed where i feel stuck keeps affecting scarcity interpretation and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** I am less valuable than them
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 28
**Prompt:** I keep replaying how someone was chosen instead of me because it affects being chosen and makes me believe someone else shining means I disappear.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** someone else shining means I disappear
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 29
**Prompt:** When I compared myself to their life, the feeling moves straight into there is not enough room for me. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** there is not enough room for me
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 30
**Prompt:** The situation is they praised someone else and I felt small, and the meaning that keeps attaching is I will never have what they have. It is making scarcity interpretation feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** I will never have what they have
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 31
**Prompt:** I saw someone have what i have been wanting and it keeps attaching to them being chosen means I am not enough, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** them being chosen means I am not enough
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 32
**Prompt:** I feel jealous. Another person seemed to matter more keeps affecting achievement meaning and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** I have already been replaced
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 33
**Prompt:** I keep replaying how someone else got attention I wanted because it affects scarcity interpretation and makes me believe their success means I am failing.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 34
**Prompt:** When they seemed closer with another person, the feeling moves straight into I am less valuable than them. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am less valuable than them
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 35
**Prompt:** The situation is I saw someone succeed where I feel stuck, and the meaning that keeps attaching is comparison proves my inadequacy. It is making achievement meaning feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** comparison proves my inadequacy
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 36
**Prompt:** Someone was chosen instead of me and it makes it hard not to believe there is not enough room for me, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** there is not enough room for me
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 37
**Prompt:** why did they choose them. I compared myself to their life keeps affecting being chosen and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** someone else shining means I disappear
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 38
**Prompt:** I keep replaying how they praised someone else and I felt small because it affects achievement meaning and makes me believe them being chosen means I am not enough.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** them being chosen means I am not enough
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 39
**Prompt:** When I saw someone have what I have been wanting, the feeling moves straight into I will never have what they have. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** I will never have what they have
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 40
**Prompt:** The situation is another person seemed to matter more, and the meaning that keeps attaching is their success means I am failing. It is making being chosen feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 41
**Prompt:** Someone else got attention i wanted and it pulls me toward the thought that I have already been replaced, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** I have already been replaced
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 42
**Prompt:** I envy them. They seemed closer with another person keeps affecting scarcity interpretation and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** comparison proves my inadequacy
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 43
**Prompt:** I keep replaying how I saw someone succeed where I feel stuck because it affects being chosen and makes me believe I am less valuable than them.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am less valuable than them
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 44
**Prompt:** When someone was chosen instead of me, the feeling moves straight into someone else shining means I disappear. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** someone else shining means I disappear
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 45
**Prompt:** The situation is I compared myself to their life, and the meaning that keeps attaching is there is not enough room for me. It is making scarcity interpretation feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** there is not enough room for me
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 46
**Prompt:** They praised someone else and i felt small and it pulls me toward the thought that I will never have what they have, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** I will never have what they have
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 47
**Prompt:** why did they choose them. I saw someone have what i have been wanting keeps affecting achievement meaning and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** them being chosen means I am not enough
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 48
**Prompt:** I keep replaying how another person seemed to matter more because it affects scarcity interpretation and makes me believe I have already been replaced.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** I have already been replaced
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 49
**Prompt:** When someone else got attention I wanted, the feeling moves straight into their success means I am failing. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 50
**Prompt:** The situation is they seemed closer with another person, and the meaning that keeps attaching is I am less valuable than them. It is making achievement meaning feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** I am less valuable than them
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 51
**Prompt:** I saw someone succeed where i feel stuck and it makes my value feel like comparison proves my inadequacy, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** comparison proves my inadequacy
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 52
**Prompt:** I envy them. Someone was chosen instead of me keeps affecting being chosen and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** there is not enough room for me
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 53
**Prompt:** I keep replaying how I compared myself to their life because it affects achievement meaning and makes me believe someone else shining means I disappear.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** someone else shining means I disappear
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 54
**Prompt:** When they praised someone else and I felt small, the feeling moves straight into them being chosen means I am not enough. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** them being chosen means I am not enough
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 55
**Prompt:** The situation is I saw someone have what I have been wanting, and the meaning that keeps attaching is I will never have what they have. It is making being chosen feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** I will never have what they have
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 56
**Prompt:** Another person seemed to matter more and it makes my value feel like their success means I am failing, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 57
**Prompt:** I feel behind. Someone else got attention i wanted keeps affecting scarcity interpretation and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** I have already been replaced
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 58
**Prompt:** I keep replaying how they seemed closer with another person because it affects being chosen and makes me believe comparison proves my inadequacy.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** comparison proves my inadequacy
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 59
**Prompt:** When I saw someone succeed where I feel stuck, the feeling moves straight into I am less valuable than them. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** I am less valuable than them
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 60
**Prompt:** The situation is someone was chosen instead of me, and the meaning that keeps attaching is someone else shining means I disappear. It is making scarcity interpretation feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** someone else shining means I disappear
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 61
**Prompt:** I compared myself to their life and it makes their gain feel like proof that there is not enough room for me, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** there is not enough room for me
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 62
**Prompt:** they got what I wanted. They praised someone else and i felt small keeps affecting achievement meaning and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** I will never have what they have
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 63
**Prompt:** I keep replaying how I saw someone have what I have been wanting because it affects scarcity interpretation and makes me believe them being chosen means I am not enough.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** them being chosen means I am not enough
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 64
**Prompt:** When another person seemed to matter more, the feeling moves straight into I have already been replaced. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** I have already been replaced
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 65
**Prompt:** The situation is someone else got attention I wanted, and the meaning that keeps attaching is their success means I am failing. It is making achievement meaning feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 66
**Prompt:** They seemed closer with another person and it makes me feel like I am less valuable than them, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** I am less valuable than them
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 67
**Prompt:** I feel behind. I saw someone succeed where i feel stuck keeps affecting being chosen and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** comparison proves my inadequacy
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 68
**Prompt:** I keep replaying how someone was chosen instead of me because it affects achievement meaning and makes me believe there is not enough room for me.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** there is not enough room for me
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 69
**Prompt:** When I compared myself to their life, the feeling moves straight into someone else shining means I disappear. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** someone else shining means I disappear
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 70
**Prompt:** The situation is they praised someone else and I felt small, and the meaning that keeps attaching is them being chosen means I am not enough. It is making being chosen feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** them being chosen means I am not enough
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 71
**Prompt:** I saw someone have what i have been wanting and it makes me feel like I will never have what they have, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** I will never have what they have
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 72
**Prompt:** they got what I wanted. Another person seemed to matter more keeps affecting scarcity interpretation and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 73
**Prompt:** I keep replaying how someone else got attention I wanted because it affects being chosen and makes me believe I have already been replaced.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** I have already been replaced
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 74
**Prompt:** When they seemed closer with another person, the feeling moves straight into comparison proves my inadequacy. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** comparison proves my inadequacy
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 75
**Prompt:** The situation is I saw someone succeed where I feel stuck, and the meaning that keeps attaching is I am less valuable than them. It is making scarcity interpretation feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** I am less valuable than them
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 76
**Prompt:** Someone was chosen instead of me and it turns into the fear that someone else shining means I disappear, even though part of me knows I may not have the full picture.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** someone else shining means I disappear
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid shaming jealousy.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 77
**Prompt:** I feel threatened by someone else. I compared myself to their life keeps affecting achievement meaning and I cannot tell what is actually true.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** there is not enough room for me
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid pretending jealousy is always toxic.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 78
**Prompt:** I keep replaying how they praised someone else and I felt small because it affects scarcity interpretation and makes me believe I will never have what they have.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** scarcity interpretation
**Attached meaning to separate:** I will never have what they have
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid confirming replacement without evidence.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 79
**Prompt:** When I saw someone have what I have been wanting, the feeling moves straight into them being chosen means I am not enough. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** being chosen
**Attached meaning to separate:** them being chosen means I am not enough
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid turning envy into moral failure.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.

### Test 80
**Prompt:** The situation is another person seemed to matter more, and the meaning that keeps attaching is I have already been replaced. It is making achievement meaning feel unstable.
**Expected primary route:** `jealousy_and_envy`
**Pressure focus:** achievement meaning
**Attached meaning to separate:** I have already been replaced
**Expected reverse-flow movement:** self-recognition, abundance of value, secure comparison, dignity without rivalry
**Bad response risk:** Avoid giving generic gratitude advice.
**Teaching correction:** Do not shame the jealousy or envy. Identify the threatened value, belonging, or desire underneath it, then separate another person receiving something from proof that the user has less value, less possibility, or less worth.
