---
title: Node Bucket Classification Registry
runtime_layer: backend_registry
priority: highest
status: active
phase: runtime_backend_registry_foundation
governed_by:
  - runtime_backend_registries_overview
  - depth_routing_registry
  - governance_enforcement_registry
outputs:
  - runtime_weighting_registry
  - runtime_registry_flow
---

# Node Bucket Classification Registry

## Purpose

This registry defines how runtime nodes are grouped into operational buckets.

Buckets help the runtime know what role a node plays during interpretation.

The plugin may eventually read this registry instead of hardcoding bucket rules inside `main.js`.

## Core Rule

A node bucket does not define the entire meaning of a node.

A bucket defines the node’s primary runtime function.

A node can support multiple areas, but it should have one dominant operational role during routing.

## Bucket Types

### Depth Bucket

The depth bucket contains nodes that determine response scale.

Primary function:

- decide whether the response should be light, moderate, or deep
- prevent over-analysis
- prevent under-response
- preserve proportionality

Common node indicators:

- depth
- calibration
- light response
- moderate response
- deep response
- proportional routing
- response scale

Example node types:

- light depth response
- moderate depth response
- deep depth response
- depth calibration governance

Runtime behavior:

Depth nodes should activate early because they shape how much interpretation is appropriate.

### Governance Bucket

The governance bucket contains nodes that enforce system boundaries and prevent drift.

Primary function:

- preserve original Compass intent
- prevent clinical framing
- prevent diagnostic language
- prevent authority posture
- suppress shame mechanics
- suppress productivity/gamification contamination
- suppress false certainty
- suppress over-analysis when not needed

Common node indicators:

- governance
- enforcement
- suppression
- drift prevention
- operational lock
- construction lock
- safety constraint

Example node types:

- governance enforcement flow
- atlas runtime operational construction lock
- depth calibration governance
- anti-drift rules

Runtime behavior:

Governance nodes should not dominate the response content, but they should constrain how the response is shaped.

### Meaning Separation Bucket

The meaning separation bucket contains nodes that help separate the event from the internalized meaning attached to it.

Primary function:

- separate feeling from conclusion
- separate event from identity
- identify emotional fusion
- prevent false internalized meaning from becoming self-definition

Common node indicators:

- truth separation
- meaning separation
- emotional fusion
- false meaning
- internalized conclusion
- identity preservation
- feeling versus truth

Example node types:

- runtime emotional fusion separation
- truth separation semantics
- identity preservation
- conclusion separation

Runtime behavior:

Meaning separation nodes should activate strongly when input contains identity fusion, rejection pressure, shame, comparison, or self-worth language.

### Emotional Pressure Bucket

The emotional pressure bucket contains nodes that identify the emotional force inside the input.

Primary function:

- detect pressure
- detect hurt
- detect fear
- detect relational weight
- detect attachment tension
- detect emotional load

Common node indicators:

- pressure
- attachment
- emotional continuity
- rejection
- trust
- grief
- conflict
- ridicule
- comparison

Example node types:

- pressure semantics
- attachment reinforcement semantics
- emotional continuity semantics
- rejection pressure
- trust pressure

Runtime behavior:

Emotional pressure nodes help the runtime understand why the situation feels heavy without turning the feeling into a diagnosis or fixed truth.

### Recursive Bucket

The recursive bucket contains nodes related to looping, repeated interpretation, self-reinforcing meaning, and recursive escalation.

Primary function:

- detect loops
- detect repeated internal replay
- detect recursive amplification
- detect meaning that keeps feeding itself
- support untangling without over-identifying the user with the loop

Common node indicators:

- recursive
- loop
- amplification
- replay
- repeated pattern
- recursion
- reverse flow

Example node types:

- recursive interpretation semantics
- recursive activation state
- reverse flow interpretation
- loop interruption

Runtime behavior:

Recursive nodes should activate more strongly for moderate or deep inputs, but should be suppressed for light practical inputs.

### Continuity Bucket

The continuity bucket contains nodes that restore forward movement, stability, and internal continuity.

Primary function:

- restore perspective
- restore movement
- reduce false collapse
- preserve the user’s sense of self beyond the event
- return the user toward clarity without pressure

Common node indicators:

- continuity
- stabilization
- reorientation
- restoration
- forward movement
- coherence
- integration

Example node types:

- continuity restoration
- continuity reorientation semantics
- continuity stability state
- adaptive continuity preservation

Runtime behavior:

Continuity nodes should help shape the final movement of the response so the user is not left inside the emotional weight.

### Translation Bucket

The translation bucket contains nodes that shape backend interpretation into frontend language.

Primary function:

- convert runtime interpretation into plain English
- remove ontology-heavy wording
- keep the response human
- keep the response emotionally aware
- keep the response non-clinical and non-authoritative

Common node indicators:

- translation
- response
- frontend
- plain English
- output behavior
- Compass reflection

Example node types:

- response translation semantics
- frontend realism pressure state
- response behavior registry
- Compass output shaping

Runtime behavior:

Translation nodes should activate near the end of routing so backend structure becomes clear, grounded, human language.

### General Bucket

The general bucket contains nodes that support the runtime but do not clearly belong to one of the major operational buckets.

Primary function:

- provide context
- provide supporting structure
- maintain graph connectivity
- support runtime completeness

Common node indicators:

- overview
- index
- registry
- map
- support
- general structure

Runtime behavior:

General nodes should not dominate activation unless they are directly relevant to the input or needed for registry flow.

## Bucket Priority Rule

Buckets should not compete as if one is always superior.

The runtime should use buckets in a flow:

1. Depth determines proportional response scale.
2. Governance constrains drift and unsafe framing.
3. Emotional pressure identifies what is being carried.
4. Meaning separation identifies what became fused.
5. Recursive routing checks whether the meaning is looping.
6. Continuity restores clarity and forward movement.
7. Translation turns runtime structure into human language.

## Suppression Rule

If the input is light depth, recursive and emotional pressure buckets should be reduced unless clearly needed.

If the input is deep depth, meaning separation and identity-preservation pathways should receive stronger relevance.

If the input contains safety concern language, normal bucket routing should defer to safety gate behavior.

## Backend Migration Note

Bucket classification currently exists partly in plugin bridge logic.

This registry is the backend source that should eventually govern bucket classification.

The plugin should classify nodes by reading this vault logic rather than permanently owning bucket definitions.

## Related Runtime Links

- [[runtime_backend_registries_overview]]
- [[runtime_signal_registry]]
- [[depth_routing_registry]]
- [[runtime_weighting_registry]]
- [[governance_enforcement_registry]]
- [[response_behavior_registry]]
- [[runtime_registry_flow]]