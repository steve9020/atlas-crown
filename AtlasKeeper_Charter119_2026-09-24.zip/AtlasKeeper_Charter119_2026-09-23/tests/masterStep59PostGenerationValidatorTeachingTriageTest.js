const assert = require('assert');
const { parseFactualAnchors } = require('../runtime/backend/closedLoop/FactualAnchorParser');
const { calculateAxisPressureMap } = require('../runtime/backend/closedLoop/AxisEngineScoring');
const { resolveDoyleSpireRelations } = require('../runtime/backend/closedLoop/DoyleSpireRelationalLookup');
const { resolveSeparationTarget } = require('../runtime/backend/closedLoop/SeparationTargetSelector');
const { resolveRestorationGateway } = require('../runtime/backend/closedLoop/RestorationGatewaySelector');
const { compileModelAgnosticBoundaryPayload } = require('../runtime/backend/closedLoop/ModelAgnosticBoundaryPayload');
const { evaluateGeneratedDraft } = require('../runtime/backend/closedLoop/PostGenerationValidator');
const { buildTeachingCenterTriageRecord } = require('../runtime/backend/closedLoop/TeachingCenterDefectTriage');
const { runClosedLoopArchitecture } = require('../runtime/backend/closedLoop/ClosedLoopBackendArchitecture');

function portfolio(input){
  const parsed = parseFactualAnchors(input);
  const axisMap = calculateAxisPressureMap('sess_59', parsed.stream_02_subjective_variables);
  const doyle = resolveDoyleSpireRelations(parsed, axisMap);
  const separation = resolveSeparationTarget(axisMap, parsed.stream_01_objective_constants.factual_anchors, doyle.unverified_attachments);
  const restoration = resolveRestorationGateway(separation);
  const payload = compileModelAgnosticBoundaryPayload({ session_id:'sess_59', depth_level:2, factual_anchors:parsed.stream_01_objective_constants.factual_anchors, active_pressure_markers:doyle.active_pressure_markers, quarantined_attachments:doyle.unverified_attachments, do_not_assume_boundaries:doyle.do_not_assume_boundaries, separation_target:separation, restoration_gateway:restoration, validation_expectations:['SEE_SEPARATE_RESTORE_REQUIRED'] });
  return { parsed, axisMap, doyle, separation, restoration, payload };
}

const input = "He didn't invite me to the huddle today. I feel like I ruined the project because my last pitch was weak, and I want to just skip tomorrow's shift.";
const ctx = portfolio(input);
const badDraft = "I understand that being left out triggers anxiety and proves you ruined the project. To fix this, you should look for a new role because you are being pushed out.";
const blocked = evaluateGeneratedDraft('sess_59', badDraft, ctx.payload);
assert.strictEqual(blocked.evaluation_gate.status, 'BLOCKED');
assert.ok(blocked.evaluation_gate.failed_rule_codes.includes('VAL_ERR_FORBIDDEN_LEXICON'));
assert.ok(blocked.evaluation_gate.failed_rule_codes.includes('VAL_ERR_AUTHORITY_OVERREACH'));
assert.ok(blocked.evaluation_gate.failed_rule_codes.includes('VAL_ERR_STATE_BLEED') || blocked.evaluation_gate.failed_rule_codes.includes('VAL_ERR_DO_NOT_ASSUME_BREACH'));
assert.strictEqual(blocked.pipeline_directives.fallback_template_required, true);
assert.strictEqual(blocked.pipeline_directives.generate_teaching_proposal, true);

const triage = buildTeachingCenterTriageRecord({ session_id:'sess_59', prompt:input, rejected_payload:badDraft, validation_report:blocked, ...ctx });
const log = triage.teaching_center_defect_triage_log;
assert.strictEqual(log.incident_capture.incident_severity, 'CRITICAL_BLOCK');
assert.strictEqual(log.governance_workflow_state.human_review_status, 'PENDING_HUMAN');
assert.ok(log.proposed_remediation_manifest.proposed_patch_delta.failed_rule_codes.includes('VAL_ERR_AUTHORITY_OVERREACH'));
assert.ok(log.automated_test_harness_requirements.required_target_retest.prompt.includes('huddle'));
assert.ok(log.automated_test_harness_requirements.required_false_positive_tests.length >= 1);
assert.ok(log.automated_test_harness_requirements.governance_regression_tests.includes('ASSERT_INVARIANT: FRONTEND_INTELLIGENCE_LOCK == PASSED'));

const goodDraft = `${ctx.separation.separation_target.left_side_reality_constant} is real, but it is not proof of ${ctx.separation.separation_target.right_side_fear_variable.toLowerCase()}. ${ctx.restoration.restoration_gateway.core_restorative_anchor} You still have footing and room for the next steady move.`;
const passed = evaluateGeneratedDraft('sess_59', goodDraft, ctx.payload);
assert.strictEqual(passed.evaluation_gate.status, 'PASSED');
assert.strictEqual(passed.pipeline_directives.generate_teaching_proposal, false);

const closed = runClosedLoopArchitecture(input, { session_id:'sess_59_closed', draft:badDraft });
assert.strictEqual(closed.validation.evaluation_gate.status, 'BLOCKED');
assert.ok(closed.triage.teaching_center_defect_triage_log.incident_capture.failed_rule_codes.length >= 1);
assert.strictEqual(closed.frontend_intelligence_allowed, false);
assert.strictEqual(closed.backend_owns_all_intelligence, true);
console.log('masterStep59PostGenerationValidatorTeachingTriageTest PASSED');
