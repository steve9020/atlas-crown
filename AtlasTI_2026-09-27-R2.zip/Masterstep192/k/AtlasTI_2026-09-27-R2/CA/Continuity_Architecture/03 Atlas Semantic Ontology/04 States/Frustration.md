# Frustration

## Mechanical Definition
Frustration is blocked-movement pressure created when effort, intention, or need cannot reach completion.

---

## Real-World Definition
In real use, Frustration describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates Frustration
- obstacles
- repeated failure
- unclear pathways
- powerlessness
- delays
- misunderstanding

---

## What Frustration Produces
- irritation
- urgency
- narrowed patience
- problem-solving pressure
- escalation impulse

---

## What Distorts Frustration
- anger displacement
- helplessness
- over-control
- self-judgment
- relational spillover

---

## What Resolves Frustration Constructively
- path clarification
- pacing
- practical action
- expectation adjustment
- support

---

## What Happens Without Integration
- burnout
- resentment
- impulsive reaction
- avoidance
- collapse pressure

---

## Connected Nodes
- [[Anger]]
- [[powerlessness_pressure]]
- [[overwhelm_pressure]]
- [[Discipline]]
- [[Recovery]]

---

## Core Principle
Frustration often means movement is blocked, not that the self is failing.
