---
runtime_layer: route_assumption_check
priority: high
owned_by: atlas_teaching_learning
feeds_into:
  - final_route_selection
---

# Default Route Suppression Registry

## Purpose
Suppresses broad fallback routes when more precise context is present.

## Suppression examples
- suppress self-worth-first routing when read-no-response and missing context are primary.
- suppress practical-first routing when task language is fused with shame, identity collapse, perfection pressure, or job-continuity fear.
- suppress generic emotional reassurance when the prompt contains a specific human act, relational expectation, failed response, or protective reaction.

## Rule
Fallback routes may support the final response, but they should not lead when a more precise route explains the prompt better.
