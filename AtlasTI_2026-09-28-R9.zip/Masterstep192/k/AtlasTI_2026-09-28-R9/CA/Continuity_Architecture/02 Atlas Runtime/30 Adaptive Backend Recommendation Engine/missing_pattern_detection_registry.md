---
title: Missing Pattern Detection Registry
runtime_layer: adaptive_backend_recommendation_engine
priority: high
governed_by: adaptive_backend_recommendation_engine_overview
receives_from:
  - backend_detector_generation_registry
outputs_to:
  - recommendation_scoring_registry
  - emotional_growth_proposal_queue
status: active
---

# Missing Pattern Detection Registry

## Purpose

This registry defines how Compass may detect a possible missing backend pattern.

A missing pattern is not automatically true. It is only a possible backend growth area that may deserve review.

---

## Core Rule

Compass may detect missing patterns, but it must not activate them.

Missing pattern detection must be:

- multi-signal
- source-aware
- duplicate-aware
- too-broad-aware
- merge-aware
- confidence-gated
- approval-gated

---

## Missing Pattern Signals

A possible missing pattern may exist when user input contains:

1. a clear emotional state
2. a repeated or self-feeding loop
3. an attached meaning
4. a specific context
5. a consequence for self-worth, safety, belonging, control, trust, future, or identity
6. no strong existing backend match

---

## Not Enough Evidence

Do not recommend when the prompt only contains:

- one isolated emotion word
- one broad situation word
- a vague phrase with no loop
- a generic concern already covered by existing backend patterns
- a duplicate of an active pattern
- less than 50 percent confidence

---

## Duplicate Versus Merge

Duplicate:

- already active
- already queued
- already reviewed
- already integrated
- should not be recommended again

Merge:

- partially overlaps
- may strengthen an existing pattern
- should be shown only when confidence is high enough
- still requires Steve to click Merge

---

## Missing Pattern Output

A missing pattern recommendation should include:

- recommendation id
- readable title
- category
- evidence
- possible interpretation
- confidence score
- duplicate risk
- already-covered assessment
- too-broad assessment
- possible merge target
- suggested next step
- target registry
- frontend translation note

---

## Related Runtime Links

- [[adaptive_backend_recommendation_engine_overview]]
- [[backend_detector_generation_registry]]
- [[recommendation_scoring_registry]]
- [[proposal_draft_generation_registry]]
- [[emotional_growth_proposal_queue]]
- [[emotional_growth_approval_gate]]
