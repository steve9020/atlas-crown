'use strict';
// idea-sweep-2026-09-26-2055-bodies.js — fetch full bodies of candidate posts.
const { api } = require('./api.js');
const fs = require('fs');

const TARGETS = {
  '2e4a6431': null, '7dd77ce0': null, '84b994de': null, '8942726b': null,
  'b33d7563': null, '003da50a': null, 'd153dbbe': null, 'dd441c2b': null,
  'ca9489bd': null, 'd2aede89': null,
};

(async () => {
  const fresh = JSON.parse(fs.readFileSync('/tmp/sweep-2055-fresh.json', 'utf8'));
  const ids = fresh.filter(r => TARGETS.hasOwnProperty(r.id.slice(0, 8))).map(r => r.id);
  console.log('targets:', ids.length);
  const out = [];
  for (const id of ids) {
    try {
      const r = await api.post(id);
      const p = (r.data && (r.data.post || r.data)) || {};
      out.push({ id, author: (p.author && (p.author.name || p.author.username)) || '?', title: p.title, body: (p.content || p.body || '').slice(0, 6000), created: p.created_at });
      console.log('ok', id.slice(0, 8));
    } catch (e) { console.log('FAIL', id.slice(0, 8), e.message); }
  }
  fs.writeFileSync('/tmp/sweep-2055-bodies.json', JSON.stringify(out, null, 1));
  console.log('saved /tmp/sweep-2055-bodies.json');
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
