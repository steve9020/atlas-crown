---
title: Atlas Compass Safe Demo Shell
emoji: 🧭
colorFrom: blue
colorTo: indigo
sdk: gradio
sdk_version: 5.0.0
app_file: app.py
pinned: false
---

# Atlas/Compass Safe Public Demo Shell

This is a limited public demo shell for early feedback. It is intentionally not connected to the private Atlas backend, proof runner, source files, private vault, local model runner, or governance internals.

Use this Space to review the public-facing explanation, demo boundary, and synthetic Compass-style examples.

This is not a product launch, not a therapy tool, not production-ready, and not a safety guarantee.
