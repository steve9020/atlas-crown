# Masterstep183 — Context Ownership / Attribution

## Attack
A fresh pronoun/reference attack crossed speaker, evaluator, target, performance
judgment, silence, and self-causation inside the same statements.

The first draft witness was rejected because it asked the relational
silence/self-causation matrix to treat `she was right` as self-causation.
The corrected engine-level attack stayed inside the existing matrix contract.

Corrected pre-repair result: **7/12 PASS, 5/12 FAIL**.

## Root failures
1. Performance language quoted from or owned by another person could qualify as
   the user's performance-pressure context.
2. Explicit rejection of another person's performance judgment was not preserved.
3. Natural silence forms (`goes quiet`, `his/her silence`) were under-covered.

## Repair
Backend only. No new matrix/domain.
- Added explicit performance evidence ownership/adoption metadata to the shared
  attribution object.
- Explicit self-adoption wins when present.
- Explicit external rejection prevents that external performance judgment from
  qualifying as the user's performance-pressure evidence.
- Explicit other-subject performance evidence is not inherited by the user.
- Null ownership preserves legacy behavior when ownership is not established.
- Added the demonstrated silence constructions.

## Proof
- Corrected ownership attack: **12/12 PASS**
- Step179 breadth regression: PASS
- Step180 mixed-context non-collapse: PASS
- Step181 downstream transport: PASS
- Step182 false-mixing + attribution regressions: PASS
- Atlas canonical proof: **100/100 PASS**
- Crown P1-P8: **8/8 PASS**
- Frontend changes: **0**

## Boundary
This is lexical/proximity ownership evidence, not full coreference resolution.
