# Crown Phase 8 — Keeper Hardening / Artifact Authority

## Source
Phase 8 began from the delivered Phase 7 ZIP itself.

Phase 7 source SHA-256:
`0a192b14bc775cb0b964b34c3e0b40a9b578ae062c6987f551b1c2ff2d0963df`

## Failure found and repaired
Clean replay initially exposed one real package-contract failure:
`proof/results/CROWN_PHASE7_CLOSURE_MANIFEST.json` violated the existing Atlas rule
that packaged deliverables exclude generated proof results.

The Crown closure manifest was preserved, not deleted, and relocated to:
`proof/contracts/crown/CROWN_PHASE7_CLOSURE_MANIFEST.json`

This keeps durable Crown evidence in the package without contaminating the
generated `proof/results/` surface.

## Clean delivered-artifact replay
- Atlas canonical proof: 100/100 PASS
- Crown Phase 1–7 witnesses: 7/7 PASS
- Phase 8 artifact-authority witness: PASS
- Frontend/public/public_demo_shell/CA edits: 0

## Phase 8 invariant
Working-tree PASS does not imply delivered-artifact PASS.

Keeper eligibility belongs only to an exact delivered artifact whose contents,
identity, and reproduced proof state agree.

## Markdown placement
Crown human-readable evidence is packaged under:
`proof/reports/crown/`

Machine-readable durable Crown contracts/manifests are packaged under:
`proof/contracts/crown/`

Generated execution output remains under `proof/results/` only when produced by
the proof runner and permitted by the existing Atlas proof contract.
