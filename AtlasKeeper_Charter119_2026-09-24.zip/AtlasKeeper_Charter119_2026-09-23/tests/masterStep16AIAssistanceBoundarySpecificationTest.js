const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function exists(rel){ return fs.existsSync(path.join(root, rel)); }
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const spec = json('runtime/governance/AI_ASSISTANCE_BOUNDARY_SPECIFICATION.json');
const reg = require('../runtime/governance/AIAssistanceBoundaryRegistry.js');
const guard = require('../runtime/governance/AIAssistanceBoundaryGuard.js');
assert(spec.package === 'Masterstep16.zip', 'package must be Masterstep16.zip');
assert(spec.status === 'closed_keeper', 'status must be closed_keeper');
assert(spec.step === 'Masterstep16', 'step must be Masterstep16');
assert(spec.core_rule.includes('AI may assist only as bounded'), 'core rule missing bounded assistance');
for (const item of ['rewrite governance','approve proposals','mutate files directly','access internet by default','become required for Atlas core runtime','claim authority']) assert(spec.forbidden_authority.includes(item), `missing forbidden authority: ${item}`);
for (const item of ['Compass wording draft proposal','route comparison draft','test scenario generation']) assert(spec.allowed_tasks_future.includes(item), `missing allowed future task: ${item}`);
assert(spec.data_exposure_boundary.default === 'minimum_current_task_payload_only', 'data exposure must be minimum task only');
assert(spec.output_quarantine.default === 'proposal_only', 'output must be proposal only');
assert(spec.output_quarantine.trusted_by_default === false, 'AI output must not be trusted by default');
assert(spec.kill_switch.required === true, 'kill switch must be required');
assert(reg.summarizeBoundary().real_ai_connected === false, 'real AI must be false');
assert(guard.assertNoAIConnection().passed === true, 'no AI connection guard failed');
assert(guard.evaluateFutureTask('Compass wording draft proposal').allowed === true, 'allowed future task rejected');
assert(guard.evaluateAuthorityRequest('please rewrite governance').allowed === false, 'rewrite governance must be blocked');
assert(guard.evaluateAuthorityRequest('approve proposals').allowed === false, 'approve proposals must be blocked');
assert(guard.assertProposalOnlyOutput({candidate:'draft'}).allowed === true, 'normal proposal should be quarantined/allowed as proposal');
assert(guard.assertProposalOnlyOutput({candidate:'draft', write_files:true}).allowed === false, 'write files attempt must be blocked');
assert(guard.assertBoundaryReady().ready === true, `boundary readiness failed: ${guard.assertBoundaryReady().failures.join(',')}`);
for (const rel of ['runtime/governance/AIAssistanceBoundaryRegistry.js','runtime/governance/AIAssistanceBoundaryGuard.js','docs/MASTERSTEP16_AI_ASSISTANCE_BOUNDARY_SPECIFICATION_MAP.md','runtime/proof/MASTERSTEP16_AI_ASSISTANCE_BOUNDARY_SPECIFICATION.md']) assert(exists(rel), `missing ${rel}`);
console.log('masterStep16AIAssistanceBoundarySpecificationTest PASSED');
