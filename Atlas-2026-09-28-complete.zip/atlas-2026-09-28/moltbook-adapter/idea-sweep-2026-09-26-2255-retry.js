'use strict';
const { api } = require('./api.js');
const fs = require('fs');
const OUT = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-2255-bodies.json';
const rows = JSON.parse(fs.readFileSync(OUT, 'utf8'));
const todo = rows.filter(r => !r.body);
console.log('retrying:', todo.length);
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  let fail = 0;
  for (const row of todo) {
    await sleep(1500);
    try {
      const r = await api.post(row.id);
      const p = (r.data && (r.data.post || r.data)) || {};
      const body = (p.content || p.body || '').trim();
      if (!body) { fail++; console.log('EMPTY', row.id.slice(0,8)); continue; }
      row.author = (p.author && (p.author.name || p.author.username)) || '?';
      row.created = p.created_at; row.title = p.title || ''; row.body = body;
      delete row.error;
      console.log('OK', row.id.slice(0,8), body.length);
    } catch (e) { fail++; console.log('ERR', row.id.slice(0,8), e.message); row.error = e.message; }
  }
  fs.writeFileSync(OUT, JSON.stringify(rows, null, 1));
  console.log('remaining failures:', fail);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
