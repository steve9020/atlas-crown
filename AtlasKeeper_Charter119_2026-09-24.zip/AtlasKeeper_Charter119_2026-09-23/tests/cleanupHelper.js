const fs = require("fs");
const path = require("path");

const atlasRoot = path.join(__dirname, "..");
const policyPath = path.join(__dirname, "SNAPSHOT_VAULT_POLICY.json");

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function getSnapshotVaultPath(policy) {
  if (process.env.ATLAS_SNAPSHOT_VAULT) return process.env.ATLAS_SNAPSHOT_VAULT;
  if (process.platform === "win32") return policy.default_windows_vault || "C:\\ATLAS_SNAPSHOTS";
  return path.join(atlasRoot, "..", "ATLAS_SNAPSHOTS");
}

const policy = fs.existsSync(policyPath) ? readJson(policyPath) : null;
const keepSnapshots = policy && Array.isArray(policy.required_snapshots)
  ? [policy.current_embedded_snapshot || "ATLAS_RUNTIME_STEP4_LOCKS.zip"]
  : [];

const embeddedSnapshots = fs.readdirSync(atlasRoot).filter(file =>
  file.startsWith("ATLAS_RUNTIME_") && file.endsWith(".zip")
);

console.log("\nATLAS CLEANUP HELPER");
console.log("====================");

console.log("\nWorking package embedded snapshots:");
if (embeddedSnapshots.length === 0) {
  console.log("- none");
} else {
  for (const file of embeddedSnapshots) console.log("-", file);
}

if (policy) {
  const vaultPath = getSnapshotVaultPath(policy);
  console.log("\nSnapshot vault:");
  console.log("-", vaultPath);

  console.log("\nCurrent recommended snapshot to KEEP:");
  for (const keep of keepSnapshots) console.log("-", keep);

  if (fs.existsSync(vaultPath)) {
    const snapshotFiles = fs.readdirSync(vaultPath).filter(file =>
      file.startsWith("ATLAS_RUNTIME_") && file.endsWith(".zip")
    );

    console.log("\nSnapshot ZIPs found in vault:");
    for (const file of snapshotFiles) {
      const status = keepSnapshots.includes(file) ? "KEEP" : "OLDER";
      console.log(`- ${file} [${status}]`);
    }

    const indexPath = path.join(vaultPath, policy.index_file || "SNAPSHOT_INDEX.txt");
    console.log("\nSnapshot index:");
    console.log(fs.existsSync(indexPath) ? `- found: ${indexPath}` : `- missing: ${indexPath}`);
  } else {
    console.log("\nSnapshot vault not found from this environment.");
    console.log("Expected on Windows:", policy.default_windows_vault || "C:\\ATLAS_SNAPSHOTS");
  }
}

console.log("\nNo files were deleted.");
console.log("Review this list before removing older snapshots.");
