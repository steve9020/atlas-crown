# Proposal Review Priority Registry

## Purpose
Prioritizes which proposals should be reviewed first.

## Priority Factors
- high confidence
- repeated failure evidence
- safety/scope relevance
- affects many categories
- low duplication risk
- clear backend target
- strong integration draft

## Lower Priority
- vague proposals
- one-off preferences
- repeated duplicates
- unclear target files
- low-confidence corrections

## Rule
Review should stay usable and focused.
