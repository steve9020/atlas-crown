const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const version = require('../version_status');
const root = path.resolve(__dirname, '..');
const required = [
  'runtime/backend/closedLoop/LivedMechanismAnchoringLayer.js',
  'runtime/backend/closedLoop/LivedMechanismAnchoringProof.js',
  'runtime/proof/MASTERSTEP79_LIVED_MECHANISM_ANCHORING_LAYER.json',
  'runtime/proof/MASTERSTEP79_LIVED_MECHANISM_ANCHORING_LAYER.md',
  'docs/MASTERSTEP79_LIVED_MECHANISM_ANCHORING_LAYER_MAP.md',
  'tests/masterStep79LivedMechanismAnchoringLayerTest.js'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(root, rel)), 'missing Step79 artifact: ' + rel);
const proof = JSON.parse(fs.readFileSync(path.join(root, 'runtime/proof/MASTERSTEP79_LIVED_MECHANISM_ANCHORING_LAYER.json'), 'utf8'));
assert.strictEqual(proof.passed, true, 'proof JSON must record Step79 pass');
assert.strictEqual(proof.source_keeper, 'Masterstep78');
assert.strictEqual(proof.mechanism_fail_count, 0);
assert.strictEqual(proof.required_chain_evidence.participant_substring_hotfix_verified, true);
assert.strictEqual(proof.required_chain_evidence.lived_mechanism_layer_intercepts_unknown_variable, true);
assert.strictEqual(proof.required_chain_evidence.mechanism_preservation_validator_blocks_generic_output, true);
assert.strictEqual(proof.required_chain_evidence.doyle_baseline_uncertainty_bypassed, true);
assert.strictEqual(proof.required_chain_evidence.task_vs_attached_weight_wedge_selected, true);
assert.strictEqual(proof.required_chain_evidence.provider_model_cloud_still_disconnected, true);
assert.strictEqual(proof.required_chain_evidence.frontend_shell_still_dumb, true);
assert.ok(['Masterstep79', 'Masterstep80'].includes(version.currentKeeper));
assert.ok(['Masterstep78', 'Masterstep79'].includes(version.previousKeeper));
assert.ok(isValidLaterKeeper(version.step, 79));
assert.strictEqual(version.livedMechanismAnchoringLayerComplete, true);
assert.strictEqual(version.participantSubstringHotfixComplete, true);
assert.strictEqual(version.mechanismPreservationValidatorComplete, true);
assert.strictEqual(version.cloudProviderEvaluationStarted, false);
assert.strictEqual(version.cloudWorkDeferredByUser, true);
assert.ok(['Choose governed operator console or lived mechanism expansion — cloud/provider remains deferred', 'Hold for next governed local step — cloud/provider remains deferred'].includes(version.nextTarget));
console.log('masterStep79FullClosureKeeperReadinessTest PASSED');
