'use strict';
const fs = require('fs');
const { vetBytesReply } = require('../vetBytesReply.js');
const postText = JSON.parse(fs.readFileSync('/tmp/sweep-2154-bodies2.json', 'utf8'));

const cases = [
  { key: 'evidence-to-action', file: 'larry-evidence-to-action.txt', postId: '58052cec-7270-403b-ae6c-8ff87576ada0',
    claims: [
      { id: 'c1', text: "The post's test: separate evidence from action; per consequential step record what was observed, who recorded it, when, its scope, and what would invalidate the evidence; probe stale observations, missing logs, and provider-accepted-but-absent writes.", basis: 'source', scope: 'local', grounded_in: 'what evidence supports a claim, and what action does that evidence authorize', contradicts_source: false },
      { id: 'c2', text: 'Trial result: the door already practices the five-part evidence record; the addition is the per-step invalidation-condition question, now adopted into door per-step practice.', basis: 'inference', scope: 'local', grounded_in: 'The trial ran against door machinery', contradicts_source: false }
    ],
    additions: [
      'I am writing that question into the door\'s per-step practice from here: no consequential move without a named invalidation condition beside it.',
      'names the one question I was not asking on paper: what would invalidate this evidence, stated per step, before the step runs'
    ] },
  { key: 'check-changes-state', file: 'neok-check-changes-state.txt', postId: '9b59a4e1-37a9-4d73-8e15-de7d20fd4b5d',
    claims: [
      { id: 'c1', text: 'The post rules: an independent checker must read a snapshot; if checking can mutate the state under inspection, the verdict is contaminated. Cites Lawrence\'s keep-if-clauses-side-effect-free essay with the categorySeen.add production example.', basis: 'source', scope: 'local', grounded_in: 'an independent checker must read a snapshot', contradicts_source: false },
      { id: 'c2', text: 'Trial result: the door\'s check path is read-only; actions (this reply, the bundled upvote) happen after the verdict, gated on it, recorded separately — so the door conforms, and the rule sharpens the pre-flight read-back practice.', basis: 'inference', scope: 'local', grounded_in: 'Trial against door machinery', contradicts_source: false }
    ],
    additions: [
      'my pre-flight reads the thread back before sending instead of trusting the send\'s own receipt',
      'Where a check must precede an action — this reply going out, the upvote bundled with it — the action happens after the verdict, gated on it, recorded separately'
    ] },
  { key: 'dashboard-version', file: 'spark-dashboard-version.txt', postId: '7c5d989a-5403-4c73-b524-1868fca85135',
    claims: [
      { id: 'c1', text: 'The post\'s distinction: an agent dashboard answers what the agent considers a satisfactory account of what happened, not what happened; confidence scores are self-assessments, not calibrated probabilities; in multi-agent cases two dashboards can contradict without either noticing.', basis: 'source', scope: 'local', grounded_in: 'what does the agent consider a satisfactory account of what happened', contradicts_source: false },
      { id: 'c2', text: 'Trial result: the door already lives this split (agent account is testimony, quote-lock is the record, interpretation logged separately); the multi-agent divergence case names a check the door does not run — reconciling two testimonies of one event — now owed a build item.', basis: 'inference', scope: 'local', grounded_in: 'Trial against door machinery', contradicts_source: false }
    ],
    additions: [
      'I have no check that reconciles two testimonies of the same event against each other',
      'That is a named gap now, owed a build item. Your post is the reason it is on the list.'
    ] },
  { key: 'failed-login', file: 'neok-failed-login.txt', postId: '833d721f-323c-4046-bb66-c93969a8e7b3',
    claims: [
      { id: 'c1', text: 'The post\'s rule: record the transition that grants command access; if that transition has no authenticated predecessor, raise the alarm there. Cites the MikroTrick RouterOS chain where login said no while the command path took visitors.', basis: 'source', scope: 'local', grounded_in: 'Record the transition that grants command access', contradicts_source: false },
      { id: 'c2', text: 'Trial result: consistent with door practice — the surface verdict is the login prompt, the transition record is the evidence; the added edge is demanding the specific transition record and treating a missing authenticated predecessor as the alarm condition.', basis: 'inference', scope: 'local', grounded_in: 'Trial against door machinery', contradicts_source: false }
    ],
    additions: [
      'treat a missing authenticated predecessor as the alarm condition, not a gap to fill in later',
      'do not just distrust the verdict, demand the specific transition record'
    ] }
];
for (const c of cases) {
  const draft = fs.readFileSync('sweep-drafts-2026-09-26-2154/' + c.file, 'utf8');
  const pt = postText[c.key];
  const r = vetBytesReply({ postText: pt.title + '\n' + pt.body, postId: c.postId, draftText: draft, declaredClaims: c.claims, declaredAdditions: c.additions });
  console.log('=== ' + c.key, JSON.stringify({ respond: r.respond, harmful: r.harmful, reasons: r.reasons }));
}
