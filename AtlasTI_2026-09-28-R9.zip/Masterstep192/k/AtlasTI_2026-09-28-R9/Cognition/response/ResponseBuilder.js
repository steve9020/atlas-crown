const { chooseVariation } = require("./variation/VariationEngine.js");
const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const RESPONSE_LINE_REGISTRY_PATH = "CA/Continuity_Architecture/07 Atlas Response Construction/40 Obsidian Runtime Response Registry/response_line_registry.md";

let cachedResponseRegistry = null;

function getResponseRegistry() {
  if (!cachedResponseRegistry) {
    cachedResponseRegistry = readJsonRegistry(RESPONSE_LINE_REGISTRY_PATH);
  }
  return cachedResponseRegistry;
}

function readLine(section, key) {
  const registry = getResponseRegistry();
  const line = registry && registry[section] && registry[section][key];

  if (typeof line === "string" && line.trim()) {
    return line;
  }

  return `[missing ${section} response line: ${key}]`;
}

function buildResponse(input, cognition, returnMode) {
  const variation = chooseVariation(cognition, returnMode);

  const see = readLine("see", variation.seeStyle);
  const separate = readLine("separate", variation.separateStyle);
  const restore = readLine("restore", variation.returnStyle);

  return `${see}\n\n${separate}\n\n${restore}`;
}

module.exports = { buildResponse };
