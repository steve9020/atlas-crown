# Self-Compassion

## Mechanical Definition
Self-compassion is supportive self-contact during difficulty, failure, pain, or uncertainty without abandoning accountability or growth.

---

## Real-World Definition
In real use, Self Compassion describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## Core Function
Self-compassion preserves continuity when shame would collapse identity around a mistake or wound.

---

## What Strengthens Self-Compassion
- humility
- truth
- patience
- repair
- emotional honesty
- accountability

---

## What Weakens Self-Compassion
- shame
- perfectionism
- self-punishment
- worth contingency
- harsh judgment

---

## Adaptive Functions
- recovery
- learning
- self-trust
- repair
- resilience

---

## Connected Nodes
- [[Compassion]]
- [[Shame]]
- [[Recovery]]
- [[Integrity]]
- [[Self-Worth]]

---

## Core Principle
Self-compassion lets the self remain reachable while still allowing responsibility.
