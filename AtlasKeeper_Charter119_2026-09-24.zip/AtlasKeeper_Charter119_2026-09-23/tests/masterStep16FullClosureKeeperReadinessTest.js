const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const proof = json('runtime/proof/PROOF_STATE.json');
const active = json('runtime/workflow/ACTIVE_STEP.json');
const version = json('tests/VERSION_STATUS.json');
assert(proof.current_keeper === 'Masterstep16.zip', 'proof current keeper must be Masterstep16.zip');
assert(proof.status === 'closed_keeper', 'proof status must be closed_keeper');
assert(active.current_step === 'Masterstep16', 'active step must be Masterstep16');
assert(active.package === 'Masterstep16.zip', 'active package must be Masterstep16.zip');
assert(version.current_keeper === 'Masterstep16.zip', 'version status current keeper must be Masterstep16.zip');
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md');
assert(summary.includes('Masterstep16.zip'), 'summary must mention Masterstep16.zip');
assert(summary.includes('No AI adapter added'), 'summary must preserve no AI adapter');
assert(summary.includes('AI assistance is boundary-only'), 'summary must state boundary-only');
console.log('masterStep16FullClosureKeeperReadinessTest PASSED');
