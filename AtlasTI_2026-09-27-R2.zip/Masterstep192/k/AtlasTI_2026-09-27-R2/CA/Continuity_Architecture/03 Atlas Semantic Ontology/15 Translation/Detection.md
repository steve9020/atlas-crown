# Detection

## Purpose
Translate backend structural activation into recognizable awareness.

## Function
Detection identifies:
- activation
- instability
- contradiction
- fragmentation
- escalation
- continuity shifts

before full system takeover.

## Detection Questions
- What changed?
- What intensified?
- What became unstable?
- What shifted in perception?
- Did reaction accelerate before reflection?

## Detection Categories
- Emotional Detection
- Relational Detection
- Identity Detection
- Cognitive Detection
- Behavioral Detection

## Output
Detection increases visibility before escalation.