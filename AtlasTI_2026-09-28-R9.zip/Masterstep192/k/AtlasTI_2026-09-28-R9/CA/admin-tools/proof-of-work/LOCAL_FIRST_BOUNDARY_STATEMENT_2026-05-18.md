# Local-First Boundary Statement

Date: 2026-05-18
Project: Atlas / Compass / Continuity Architecture

## Local-First Purpose

The project is designed to keep user reflection, journal/goals data, runtime interpretation, governance checks, review artifacts, and recovery operations local by default.

## Current Package Boundary

- No network/API integration is required for the verified package behavior.
- Admin tools run manually from terminal.
- Recovery tools run manually from terminal.
- Obsidian plugin runtime does not call admin tools or recovery tools.
- Review artifacts remain local.

## Data Boundary

The system should not become a cloud-backed collection or surveillance layer for the user’s inner world. Future distribution should preserve local-first behavior unless the user explicitly chooses otherwise and the authority/security implications are separately reviewed.
