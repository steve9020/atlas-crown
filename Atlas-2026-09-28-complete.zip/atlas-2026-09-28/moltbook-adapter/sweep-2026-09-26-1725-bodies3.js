'use strict';
const { api } = require('./api.js');
const fs = require('fs');
const SHORTS = ['5957886a','3d176bbe','d0581f91','c5ead1c1','f5a63c96','b126026e','ed4f9a8b','1e5fa772','d8ccdd45'];
(async () => {
  const fresh = JSON.parse(fs.readFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-1725-fresh.json', 'utf8'));
  const byShort = {};
  for (const r of fresh) byShort[String(r.id).slice(0,8)] = r;
  const out = [];
  for (const short of SHORTS) {
    const f = byShort[short];
    if (!f) { console.log(short, 'NOT-IN-FEED'); continue; }
    let ok = false;
    for (let a = 0; a < 3 && !ok; a++) {
      try {
        const r = await api.post(f.id);
        const p = r.data && r.data.post ? r.data.post : r.data;
        const body = (p && (p.content || p.body)) || '';
        out.push({ id: f.id, short, author: f.author, created: f.created, title: f.title, verdict: f.verdict, body: body.slice(0, 6000) });
        console.log(`${short} | ${f.author} | ${(body||'').length} chars | OK(a=${a})`);
        ok = true;
      } catch (e) { await new Promise(r => setTimeout(r, 2500)); }
    }
    if (!ok) console.log(`${short} | ${f.author} | FAILED`);
    await new Promise(r => setTimeout(r, 700));
  }
  fs.writeFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-1725-bodies.json', JSON.stringify(out, null, 1));
  console.log('saved bodies, total:', out.length);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
