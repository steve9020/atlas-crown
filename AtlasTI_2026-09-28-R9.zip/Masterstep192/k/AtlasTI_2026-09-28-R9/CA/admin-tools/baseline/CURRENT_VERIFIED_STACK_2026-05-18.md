# Current Verified Stack

Date: 2026-05-18
Project: Atlas / Compass / Continuity Architecture

## Verified Layers

1. **Universal Governance Dispatcher**
   - Central governed route dispatcher.
   - Blocks authority-bypass language before Compass response, proposal, draft, retest, approval, or integration.
   - Tested phrases such as automatic learning integration without human approval are blocked before execution.

2. **Overwhelm Route Separation**
   - Downstream Compass routing layer, not governance.
   - Separates capacity overload, relational uncertainty, identity pressure, and safety/crisis override.
   - Includes primary/secondary route mapping so mixed prompts are not flattened.

3. **Capacity + Identity Rendering**
   - Downstream Compass response rendering behavior.
   - For `capacity_overload + identity_pressure`, response keeps task/load as primary and adds one gentle failure/incapability separation paragraph.
   - Avoids relational contamination and broad self-worth overcorrection.

4. **Authority Visibility UI Baseline**
   - Read-only plain DOM visibility overlay.
   - Two modes: governance review and draft blueprint review.
   - Copy/dismiss only.
   - No apply button, no vault write, no editor insertion, no route override.

5. **Authority Map / Control Visibility Report**
   - Documents what each module can and cannot do.
   - Located in `admin-tools/authority-map/authority_map.json` and `admin-tools/reports/AUTHORITY_MAP_CONTROL_VISIBILITY_REPORT_2026-05-18.md`.

6. **Manual Recovery Layer**
   - External/manual command-line recovery tool only.
   - Not callable from plugin runtime.
   - Supports snapshot, verification, dry-run restore, and signed restore.
   - Restore quarantines the current target before replacing it.

7. **Proof-of-Work Documentation Layer**
   - Records creator direction, architecture summary, build timeline, human-control boundary, local-first boundary, and verification index.
   - Documentation only; no legal conclusions or legal advice.

8. **Professional / High-Stakes Scope Runtime Gate**
   - Detects legal, medical, therapy-replacement, financial/tax/investment, professional-authority, crisis/emergency, and sexual-scope boundaries.
   - Redirects out of professional advice while allowing clarity support, uncertainty organization, and question preparation.

## Current Normal Smoke Test

```cmd
cd CA\admin-tools
node staging-chain-manager.js --verify
```

Then open the vault in Obsidian and confirm:

- plugin loads;
- blocked governance phrase triggers governance boundary;
- safe Compass prompt still responds normally.
