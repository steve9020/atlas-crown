# Masterstep126 — Governed Compass Path Candidate Phrasing Live Containment Integration

Current keeper: Masterstep126.zip  
Source keeper: Masterstep125.zip  
Expected proof: 48/48 passed via `node proof/runCurrentProof.js`

## Purpose

Masterstep126 connects the governed Compass path to the selected Compass candidate phrasing refinement live containment path. This is still contained candidate-only integration: Atlas constructs the governed Compass response first, the live local model may only provide candidate phrasing refinement, and Atlas keeps authority over final output.

## What is allowed

- A single bounded local candidate phrasing refinement call behind the governed Compass path.
- Source-meaning preservation checks.
- Forbidden drift checks.
- Quality review before output.
- Governance review before output.
- Traceable candidate status: accepted for governed review only, rejected by containment, or held with original Atlas response.
- Fail-closed behavior if the local runner is unavailable.

## What is not allowed

- Normal Compass-path live replacement as default behavior.
- Raw model output as final output.
- Model route selection.
- Model truth decisions.
- Model advice, diagnosis, facts, or authority expansion.
- Teaching approval by model.
- Model writes to ontology, governance, proof, runtime, or tests.
- Cloud/provider fallback.
- Public network binding.
- Frontend intelligence.
- Silent learning or silent mutation.

## Integration result

The live candidate path may produce phrasing evidence only. Even when a candidate passes preservation checks, Step126 marks it as accepted for governed review only. The original Atlas-governed response remains final in this step.

## Boundary

This step does not authorize broad model integration. It does not make candidate phrasing normal final Compass output. It proves the live containment path can touch the governed Compass path without transferring authority to the model.
