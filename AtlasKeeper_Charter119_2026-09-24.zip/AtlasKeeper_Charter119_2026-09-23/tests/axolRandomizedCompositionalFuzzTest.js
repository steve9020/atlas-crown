const assert = require('assert');
const { detectAxes } = require(process.cwd() + '/Cognition/engine/AxisEngine');
let seed=19120260919; function rnd(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;} function pick(a){return a[Math.floor(rnd()*a.length)]} function shuffle(a){return [...a].sort(()=>rnd()-.5)};
const actors=['Marcus','Jennifer','Daniel','Priya','Owen','Maya','Elena','Victor','Noah','Iris','Ravi','Lena'];
const specs={
 intention:a=>`${a} meant to leave early`, expectation:a=>`${a} anticipated a reply`, responsibility:a=>`${a} took responsibility for the delay`, choice:a=>`${a} chose the second route`, control:a=>`${a} controlled the schedule`, boundary:a=>`${a} crossed the boundary`, trust:a=>`${a} trusted the other person`, respect:a=>`${a} respected the decision`, fairness:a=>`${a} thought the split was unfair`, comparison:a=>`${a} compared the two outcomes`, causation:a=>`${a} caused the delay`, change:a=>`${a} changed the approach`, connection:a=>`${a} felt disconnected from the group`, effort:a=>`${a} tried hard`, outcome:a=>`${a} reached the final result`, sufficiency:a=>`${a} said the work was sufficient`, ownership:a=>`${a} owns the mistake`, acceptance_rejection:a=>`${a} rejected the offer`, interpretation:a=>`${a} took that as a warning`, observation_evidence:a=>`${a} watched it happen`
};
const axes=Object.keys(specs); const joins=[', but ',', while ',', and ',', yet ','; then ']; const neutral=['the control panel blinked','the trust account was audited','the boundary line was blue','the connection timed out','the change machine returned coins','the comparison chart had four rows'];
let total=0, hit=0, exactCases=0, actorTotal=0, actorHit=0, falsePos=0; const failures=[];
for(let i=0;i<500;i++){
 const n=2+Math.floor(rnd()*5); const chosen=shuffle(axes).slice(0,n); const usedActors=shuffle(actors).slice(0,n); let parts=[]; const expected=[];
 for(let j=0;j<n;j++){parts.push(specs[chosen[j]](usedActors[j])); expected.push([chosen[j],usedActors[j].toLowerCase()]);}
 if(rnd()<.35) parts.splice(Math.floor(rnd()*(parts.length+1)),0,pick(neutral));
 const text=parts.join(pick(joins))+'.'; const r=detectAxes(text); let ok=true;
 for(const [axis,actor] of expected){total++; if(r.axes.includes(axis)) hit++; else {ok=false;failures.push({type:'miss',axis,text,got:r.axes});} actorTotal++; const row=r.axis_evidence.find(x=>x.axis===axis); if(row&&row.attributions.some(x=>x.actor===actor)) actorHit++; else {ok=false;failures.push({type:'actor',axis,actor,text,attrs:row?.attributions||[]});}}
 if(ok) exactCases++;
}
for(let i=0;i<200;i++){const text=shuffle(neutral).slice(0,1+Math.floor(rnd()*3)).join('. ')+'.'; const r=detectAxes(text); if(r.axes.length){falsePos++; failures.push({type:'neutral',text,got:r.axes});}}
const summary={seed:19120260919,composition_cases:500,expected_axis_instances:total,axis_hits:hit,axis_rate:hit/total,actor_instances:actorTotal,actor_hits:actorHit,actor_rate:actorHit/actorTotal,fully_correct_cases:exactCases,neutral_cases:200,neutral_false_positive_cases:falsePos,failures:failures.length};
console.log(JSON.stringify(summary,null,2)); for(const f of failures.slice(0,40)) console.log('FAIL',JSON.stringify(f));
if(hit!==total||actorHit!==actorTotal||falsePos!==0){process.exitCode=1;}
