---
runtime_layer: route_assumption_check
priority: highest
owned_by: atlas_teaching_learning
feeds_into:
  - route_blend_selection_registry
---

# Route Meaning Comparison Registry

## Purpose
Compares what each candidate route would mean against what the prompt actually says.

## Comparison questions
- If this route is true, what should be present in the prompt?
- Did the user actually say that, imply that, or only make it possible?
- Does this route explain the most specific details?
- Does this route require less assumption than the default route?
- Does another route need to lead while this route stays secondary?

## Rule
The route that explains the most specific prompt details with the least assumption should lead.
