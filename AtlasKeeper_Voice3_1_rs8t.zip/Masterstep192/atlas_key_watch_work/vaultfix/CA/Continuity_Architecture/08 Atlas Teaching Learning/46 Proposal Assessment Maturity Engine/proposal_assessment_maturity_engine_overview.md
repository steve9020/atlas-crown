# Proposal Assessment Maturity Engine Overview

## Purpose
This engine matures proposal review by scoring proposal quality before approval, detecting merge risk, assigning confidence, and preparing before/after retests.

## Core Flow
Proposal generated → required fields validated → quality scored → merge/duplicate risk checked → confidence assigned → review recommendation created → retest plan prepared → proposal review panel.

## Core Rule
A proposal should not be reviewed only because it exists. It should be assessed for quality first.
