# AXOL Hell Fuzz Report

Status: FAILED AS A MATURITY GATE (baseline preserved; no detector repair in this package)

## New adversarial corpus
- 90 cases
- 97 expected axis instances
- 72/97 detected (74.2%)
- 25 expected axis misses
- 18 actor/state attribution checks
- 13/18 correct (72.2%)
- 12 neutral lexical-trap cases
- 7/12 produced false-positive axes

## Failure classes
1. Natural paraphrase gaps: intention, expectation, responsibility, boundary, trust, respect, fairness, comparison, causation, effort, outcome, sufficiency, ownership, interpretation, observation/evidence.
2. Lexical false positives: control panel, choice menu, trust account, boundary line, outcome variable, connection timeout, change machine.
3. Attribution/reference continuity errors: actor leakage/misbinding across dense and multi-sentence constructions.
4. Existing proof contract remains green, demonstrating that the canonical suite does not cover these new adversarial cases.

## Existing regression state
- Existing AXOL test suite: passes.
- Canonical current proof: 100/100 PASS.

## Decision
Do not promote this candidate to keeper on the basis of the existing green proof. Repair should target structural/context discrimination and bounded reference continuity, not simply add the failing phrases as exact-match entries.
