# Jealousy

## Mechanical Definition
Jealousy is attachment-threat pressure formed when connection, belonging, importance, or relational security feels at risk of being displaced.

---

## Real-World Definition
In real use, Jealousy describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates Jealousy
- comparison
- relational uncertainty
- replacement fear
- insecurity
- past loss
- unclear commitment

---

## What Jealousy Produces
- guarding
- suspicion
- urgency
- hurt
- control impulse
- comparison scanning

---

## What Distorts Jealousy
- possessiveness
- accusation
- projection
- validation dependency
- emotional certainty fusion

---

## What Resolves Jealousy Constructively
- truth checking
- attachment clarity
- self-worth grounding
- direct communication
- trust repair

---

## What Happens Without Integration
- resentment
- control patterns
- relational instability
- distrust
- comparison loops

---

## Connected Nodes
- [[attachment_pressure]]
- [[replacement_pressure]]
- [[Trust|Trust]]
- [[Self-Worth]]
- [[relational_instability]]

---

## Core Principle
Jealousy signals perceived attachment threat; it does not automatically prove replacement.
