# Worth Contingency Distortion

## Mechanical Definition
Worth contingency distortion occurs when self-worth becomes tied to performance, approval, usefulness, desirability, success, or relational selection.

---

## Real-World Definition
In real use, Worth Contingency Distortion describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates It
- conditional acceptance
- comparison
- performance pressure
- rejection
- shame

---

## What It Produces
- instability
- people-pleasing
- overwork
- fear
- identity pressure

---

## Distortion Pattern
Value becomes conditional on outcomes or external response.

---

## What Restores Clarity
- self-worth grounding
- authenticity
- integrity
- continuity preservation

---

## Connected Nodes
- [[Self-Worth]]
- [[Validation Dependency]]
- [[performance_conditioned_worth]]
- [[Authenticity|Authenticity]]

---

## Core Principle
Worth becomes unstable when it is treated as something that must be constantly earned.
