# Crown Phase 1 — Backend-Only Integration Report

## Boundary
Phase 1 was performed against the repaired Masterstep178 100/100 baseline.

No frontend, public shell, or `CA/` interface file was edited.
A full baseline-vs-Phase1 hash comparison found **0 frontend changes**.

## New backend primitives

### `runtime/governance/crown/ProvenanceDerivationLedger.js`
Introduces:
- source provenance identity
- SHA-256 source digest
- explicit source vs. derived classification
- mandatory parent identity for derived records
- derived records receive `authority: NONE`
- route/output authority remain false

This establishes the first executable form of:

`derived interpretation != source authority`

### `runtime/governance/crown/CrownTransitionEnvelope.js`
Introduces an immutable Phase-1 transition envelope carrying:
- transition identity
- source digest
- provenance reference
- target identity/version
- context identity/version
- predicate result container
- scope
- authorization reference
- applicability
- validation/execution/recovery/lineage references
- proof references
- PASS / FAIL / UNKNOWN / CONFLICT / FROZEN state vocabulary

Invalid/unrecognized status defaults to `UNKNOWN`, never PASS.

## Existing backend integration

`runtime/understanding/SemanticEvidenceObject.js` now creates:
- a source provenance record from the preserved source text
- a Crown transition envelope bound to the same source digest and provenance ID

Existing semantic fields and existing `route_authority:false` /
`output_authority:false` behavior are preserved.

No Crown object is allowed to promote itself to route or final-output authority.

## New deterministic witness

`tests/crownPhase1ProvenanceTransitionIdentityTest.js`

The witness proves:
- source text remains unchanged
- identical source text produces identical source digest
- transition source digest equals provenance source digest
- transition references the correct provenance identity
- default/invalid status is UNKNOWN
- route/output authority remain false
- a derived interpretation receives a distinct identity and no authority
- orphan derivations are rejected
- transition envelope is frozen/immutable at the top level

Result:

`CROWN_PHASE1_PROVENANCE_TRANSITION_IDENTITY_PASS`

## Existing Atlas regression proof

Canonical command:

`node proof/runCurrentProof.js`

Result:
- total: 100
- passed: 100
- failed: 0
- exit: 0
- current manifest generated successfully

## Frontend zero-diff gate

Baseline-vs-Phase1 file hash comparison:
- frontend/public/CA changes: **0**

Proof execution itself refreshed backend proof logs/results/readiness artifacts and the governance violation ledger. Those are execution evidence/state surfaces, not frontend modifications.

## Phase 1 status

**PASS**

This phase adds provenance and common transition identity only.
It does not yet grant the envelope authorization, execution authority,
cross-version equivalence, canonical supersession, root authority,
oracle authority, or evidence-qualification authority.

## Next controlled phase

Phase 2 should add executable predicate identity/version semantics:
`PASS | FAIL | UNKNOWN`, with input-digest binding and a strict rule that
one predicate's PASS cannot satisfy another predicate.
