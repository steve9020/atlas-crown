# Crown Phase 6 — Proof / Oracle / Qualification
Backend-only implementation. Adds independent-oracle qualification, disagreement freeze, evidence qualification, and deterministic mutation-adequacy checks. Deterministic witness: `tests/crownPhase6ProofOracleQualificationTest.js`.
