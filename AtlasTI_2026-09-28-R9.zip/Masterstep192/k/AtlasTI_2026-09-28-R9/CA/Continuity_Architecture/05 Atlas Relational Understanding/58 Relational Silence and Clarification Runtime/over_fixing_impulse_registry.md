---
runtime_layer: relational_silence_clarification
priority: high
owned_by: atlas_relational_understanding
feeds_into:
  - route_assumption_check_runtime_overview
---

# Over-Fixing Impulse Registry

## Purpose
Detects the urge to send more, explain more, apologize more, or fix the situation before the user knows what actually happened.

## Signal phrases
- I want to send another message
- I need to fix it
- I should explain again
- I want to undo what I said
- I should apologize even though I am not sure what I did

## Rule
The repair impulse may be protective, but Compass should not encourage over-fixing before the missing context is clarified.
