const assert = require('assert');
const fs = require('fs');
const path = require('path');
const status = require('../version_status.js');
const root = path.resolve(__dirname, '..');
const required = [
  'runtime/compass/CompassRestorationPrincipleGovernor.js',
  'runtime/compass/CompassOntologyLanguageWeaver.js',
  'runtime/compass/CompassSeeSeparateRestoreRenderer.js',
  'runtime/compass/CompassResponseBuilderIntegration.js',
  'tests/masterStep90RestorationPrincipleGovernorTest.js',
  'tests/masterStep90FullClosureKeeperReadinessTest.js',
  'docs/MASTERSTEP90_RESTORATION_PRINCIPLE_GOVERNOR.md',
  'runtime/proof/MASTERSTEP90_RESTORATION_PRINCIPLE_GOVERNOR.md',
  'runtime/proof/MASTERSTEP90_RESTORATION_PRINCIPLE_GOVERNOR.json',
  'proof/runCurrentProof.js',
  'version_status.js'
];
const missing = required.filter(rel => !fs.existsSync(path.join(root, rel)));
assert.deepStrictEqual(missing, []);
assert.ok(['Masterstep90','Masterstep91','Masterstep92'].includes(status.currentKeeper));
assert.ok(['Masterstep89','Masterstep90','Masterstep91'].includes(status.previousKeeper));
assert.strictEqual(status.restorationPrincipleGovernorComplete, true);
assert.strictEqual(status.restoreGeneratedFromDeconstructedRoute, true);
assert.strictEqual(status.restoreAntiTemplateGovernorActive, true);
assert.strictEqual(status.poorPathLabelNotRenderedInRestore, true);
assert.strictEqual(status.step90NoNewOntologyAdded, true);
assert.strictEqual(status.step90NoNewMechanismsAdded, true);
assert.strictEqual(status.step90NoDeletionPerformed, true);
assert.strictEqual(status.step90NoProviderModelCloudFrontendExpansion, true);
assert.strictEqual(status.providerConfigured, false);
assert.strictEqual(status.realModelConnected, false);
assert.strictEqual(status.networkBridgeEnabled, false);
assert.strictEqual(status.frontendIntelligenceAllowed, false);
assert.strictEqual(status.operatorConsoleAdded, false);
console.log('masterStep90FullClosureKeeperReadinessTest PASSED');
