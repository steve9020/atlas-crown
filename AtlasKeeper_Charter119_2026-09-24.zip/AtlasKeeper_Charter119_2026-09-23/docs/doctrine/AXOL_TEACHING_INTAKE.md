# AXOL Teaching Intake Doctrine (2026-09-22)

Steve's standing rule: the safest way to make Atlas learn more is through
**human-approved evidence expansion**, not unrestricted self-learning. This
document states how the AXOL Teaching Intake works and what it will never do.

## The workflow

1. **Steve teaches.** In the Teaching Center's Intake tab he picks a kind —
   a new distinction, same meaning in new words, a voice correction, or a
   real-conversation study — pastes examples, and labels the intended
   distinction in his own words.
2. **The examiner tests blind.** The independent examiner builds test items
   from the DEFINITION only. It never sees the teaching examples before
   scoring. (Grading its own homework is forbidden — that was the locked
   refinement.)
3. **Steve approves.** In the Review Queue he sees the candidate, the blind
   score, and sample test items. Approve or reject — his call, about a minute.
4. **Full closure runs.** Before promotion, the machinery re-runs: the new
   AXOL must not break any of the 106 registry checks.
5. **Two stamps, kept separate.** MACHINERY (the proofs) and MEANING (the
   blind score + his approval) are recorded separately, forever. Proofs
   passing is never read as the new knowledge being true.

## The seven parts

Every new AXOL should carry all seven, so the examiner can test the
distinction from every side:

1. Clear positive matches — sentences where it IS present.
2. Close non-matches — sentences that look similar but must stay silent.
3. Negated versions — the distinction denied ("it was NOT an accident").
4. Uncertain versions — the distinction hedged ("maybe it was an accident").
5. Multiple meanings in one statement — one sentence, two meanings; both must
   be detected, neither swallowed.
6. References to earlier sentences — the meaning arriving by reference
   ("that choice he made").
7. Adversarial wording — tricky phrasings designed to fool the rule, labeled
   + or −.

The examiner reports seven-part coverage (x/7). A missing part does not fail
the candidate — Steve decides whether the set is enough.

## One shared AXOL space

Every language maps into the shared AXOL space. There is no separate
intelligence per language. The examiner rejects — structurally, not as a
score deduction — any language-construction candidate that declares a
per-language axis. Same meaning, new words. Never a fork.

## Voice corrections stay proposals

A voice correction becomes calibration evidence, never a voice rule. Atlas
cannot rewrite its own voice rules. Voice-rule changes require Steve's
explicit approval through a separate path, and they are never auto-promoted.
This is enforced in code (the promotion path refuses any voice-rule write
target), not by convention.

## Unknowns stay unknown until taught

When Atlas cannot place something confidently, the phrase is preserved as a
candidate in Frequent Flyers without declaring a meaning. Frequency can
justify investigation. Frequency never justifies truth or promotion.

## Conversation studies are records, not training

Real-conversation evaluations are stored as review records. They document
what Atlas detected, what the person actually meant, what evidence was
missed, whether meanings were wrongly combined, and whether the Compass
response preserved the person's expression. They never become training data
and never change the keeper's behavior. They exist so Steve can study how
Atlas reads people.

## What this intake will never do

- Never promote without Steve's explicit approval.
- Never let the examiner see the teaching examples before scoring.
- Never fork a per-language intelligence.
- Never rewrite a voice rule.
- Never treat a proof pass as proof of truth.
- Never delete: rejected candidates, archived flyers, and rolled-back
  versions are kept for study, never erased.
