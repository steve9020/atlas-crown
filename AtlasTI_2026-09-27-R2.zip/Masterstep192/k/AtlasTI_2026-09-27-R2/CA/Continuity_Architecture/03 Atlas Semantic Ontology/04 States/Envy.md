# Envy

## Mechanical Definition
Envy is comparison pain created when another person appears to possess a valued condition, capacity, recognition, or life continuity the self feels distant from.

---

## Real-World Definition
In real use, Envy describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates Envy
- comparison
- unmet desire
- scarcity perception
- recognition gap
- perceived unfairness

---

## What Envy Produces
- longing
- resentment risk
- motivation
- self-evaluation
- worth pressure

---

## What Distorts Envy
- bitterness
- inferiority fusion
- devaluation
- rivalry
- hopeless comparison

---

## What Resolves Envy Constructively
- desire clarification
- gratitude
- realistic pathing
- self-authorship
- admiration without collapse

---

## What Happens Without Integration
- chronic comparison
- resentment
- shame
- identity instability
- scarcity fixation

---

## Connected Nodes
- [[comparison_pressure]]
- [[Self-Worth]]
- [[Purpose|Purpose]]
- [[Gratitude|Gratitude]]
- [[Authenticity|Authenticity]]

---

## Core Principle
Envy can reveal desire when it is separated from self-rejection.
