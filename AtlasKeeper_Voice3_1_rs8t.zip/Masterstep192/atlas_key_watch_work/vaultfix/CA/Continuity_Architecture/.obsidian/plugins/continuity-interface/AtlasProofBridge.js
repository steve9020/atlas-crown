const path=require('path');
function loadProofService(projectRoot){const p=path.join(projectRoot,'runtime/backend/LocalProofOrchestratorService.js');return require(p).LocalProofOrchestratorService;}
module.exports={loadProofService};
