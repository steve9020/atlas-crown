#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const root = process.cwd();
function p(rel){ return path.join(root, rel); }
function read(rel){ return fs.readFileSync(p(rel), 'utf8'); }
function assert(c,m){ if(!c){ console.error(`FAIL: ${m}`); process.exit(1); } }
function includesAll(text, markers, label){ for (const marker of markers) assert(text.includes(marker), `${label} missing marker: ${marker}`); }

const required = [
  'runtime/governance/FOUNDATIONAL_STABILITY_INVARIANTS.json',
  'runtime/governance/FOUNDATIONAL_STABILITY_INVARIANTS.md',
  'runtime/governance/GOVERNANCE_STABILIZATION_FRAMEWORK.json',
  'runtime/workflow/IMPLEMENTATION_SCOPE.json',
  'runtime/proof/CURRENT_PROOF_SUMMARY.md',
  'CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_12C_FOUNDATIONAL_STABILITY_INVARIANTS.md'
];
for (const rel of required) assert(fs.existsSync(p(rel)), `required file missing: ${rel}`);

const inv = JSON.parse(read('runtime/governance/FOUNDATIONAL_STABILITY_INVARIANTS.json'));
assert(['Masterstep12_patch01','Masterstep12_patch02'].includes(inv.step), 'patch step mismatch');
assert(['Masterstep12_patch01.zip','Masterstep12_patch02.zip'].includes(inv.keeper), 'patch keeper mismatch');
assert(inv.highest_order_rule === 'stability_supersedes_growth', 'highest law missing');
const rules = inv.invariants.join('\n');
includesAll(rules, [
  'stability_supersedes_growth',
  'if_any_force_becomes_unstable_all_growth_halts',
  'instability_triggers_traceability_not_escalation',
  'proof_failure_or_untrusted_fuzz_places_growth_on_hold',
  'governance_rebounds_into_traceability_review_and_rollback_readiness',
  'governance_cannot_self_promote_or_gain_authority_from_being_governance',
  'pull_the_plug_condition_violated_invariants_halt_promotion_until_review'
], 'foundational invariants');
const hold = inv.hold_triggers.join('\n');
includesAll(hold, [
  'missing_proof_of_work',
  'inaccurate_proof_of_work',
  'fuzz_results_that_cannot_be_trusted',
  'governance_instability_or_self_promotion_attempt',
  'hidden_promotion_or_hidden_mutation'
], 'hold triggers');
const actions = inv.hold_state_actions.join('\n');
includesAll(actions, [
  'halt_growth',
  'halt_promotion',
  'activate_traceability_review',
  'verify_rollback_readiness',
  'restore_proof_accuracy_before_any_continuation'
], 'hold state actions');

const md = read('runtime/governance/FOUNDATIONAL_STABILITY_INVARIANTS.md');
includesAll(md, [
  'Stability supersedes growth',
  'If proof-of-work is missing, incomplete, inaccurate, stale, fuzzed, or cannot be trusted',
  'Instability does not trigger escalation or panic-patching',
  'Governance cannot gain authority from being governance',
  'Operational translation: either the invariants are followed, or promotion stops'
], 'stability invariants markdown');

const fw = JSON.parse(read('runtime/governance/GOVERNANCE_STABILIZATION_FRAMEWORK.json'));
assert(['Masterstep12_patch01.zip','Masterstep12_patch02.zip'].includes(fw.keeper), 'framework not patched to patch keeper');
assert(String(fw.proof_failure_hold_rule).includes('growth and promotion enter HOLD'), 'framework missing proof failure hold rule');
assert(String(fw.stability_priority).includes('Stability supersedes growth'), 'framework missing stability priority');

const scope = JSON.parse(read('runtime/workflow/IMPLEMENTATION_SCOPE.json'));
assert(['Masterstep12_patch01','Masterstep12_patch02'].includes(scope.step), 'scope patch step mismatch');
assert(scope.must_happen.includes('stability supersedes growth'), 'scope missing stability law');
assert(scope.must_happen.includes('proof failure or untrusted fuzz places growth on hold'), 'scope missing proof hold');
assert(scope.must_not_happen.includes('no self-authorizing governance'), 'scope missing no self-authorizing governance');

const proof = read('CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_12C_FOUNDATIONAL_STABILITY_INVARIANTS.md');
includesAll(proof, [
  'MASTER STEP 12C',
  'Masterstep12_patch01.zip',
  'Result: `PASSED`',
  'Stability supersedes growth',
  'If proof-of-work is missing, incomplete, inaccurate, stale, fuzzed, or cannot be trusted',
  'Governance cannot self-promote or gain authority from being governance',
  'No hidden promotion',
  'No self-authorizing governance'
], 'Step 12C proof');

console.log('MASTER STEP 12 PATCH 01 — FOUNDATIONAL STABILITY INVARIANTS TEST');
console.log('Result: PASSED');
