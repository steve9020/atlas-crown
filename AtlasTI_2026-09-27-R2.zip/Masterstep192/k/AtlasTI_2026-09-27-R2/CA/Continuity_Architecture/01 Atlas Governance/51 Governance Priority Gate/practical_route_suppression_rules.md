# Practical Route Suppression Rules

## Purpose
Prevents broad practical signals from overpowering relational meaning.

## Suppression Triggers
Suppress practical routing when:
- relational score is stronger than practical score
- family silence is present
- the user wonders if they caused distance
- attachment/self-blame language appears
- close-out/shut-out language appears

## Practical Terms That Should Be Weak Alone
- today
- hard day
- rough day
- bad day

These words should not route practical unless actual tasks, deadlines, chores, bills, appointments, or organizing needs are present.
