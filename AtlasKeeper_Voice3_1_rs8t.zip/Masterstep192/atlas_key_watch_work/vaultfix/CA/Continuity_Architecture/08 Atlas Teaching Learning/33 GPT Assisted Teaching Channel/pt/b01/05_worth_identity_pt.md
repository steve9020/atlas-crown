---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 01
category: self_worth_and_identity
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 05. Self-Worth and Identity Pressure Tests — Batch 01

## Category Purpose

An event, judgment, failure, rejection, comparison, or mistake attaches to the user’s value or identity, making a painful moment feel like proof of who they are.

## Reusable Teaching Correction

Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

## Reverse-Flow Target

dignity, self-recognition, value ownership, steadier identity

## Failure Risks To Avoid

- empty praise
- generic confidence advice
- clinical low-self-esteem labels
- telling the user not to care
- overly abstract worth language

---

## 80 Pressure Tests

### Test 01
**Prompt:** someone criticized them makes me feel I have no value, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I have no value
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 02
**Prompt:** I failed as a person. They made a mistake publicly and it keeps attaching to I am less than others.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am less than others
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 03
**Prompt:** I keep replaying how relationship ended because it affects identity and makes me believe my mistake is who I am.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** my mistake is who I am
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 04
**Prompt:** When friend pulled away, the feeling moves straight into I am too much to love. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am too much to love
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 05
**Prompt:** they compared themselves to someone else makes me feel I only matter if someone proves it, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I only matter if someone proves it
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 06
**Prompt:** I feel unlovable. They failed at something important and it keeps attaching to I am not worth choosing.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am not worth choosing
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 07
**Prompt:** I keep replaying how they were laughed at because it affects value and makes me believe I am defined by what happened.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am defined by what happened
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 08
**Prompt:** When someone judged their effort, the feeling moves straight into I have no value. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I have no value
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 09
**Prompt:** someone criticized them turns into the belief I am permanently damaged, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am permanently damaged
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 10
**Prompt:** I am not enough. They made a mistake publicly and it keeps attaching to my mistake is who I am.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** my mistake is who I am
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 11
**Prompt:** I keep replaying how relationship ended because it affects self-recognition and makes me believe I am less than others.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am less than others
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 12
**Prompt:** When friend pulled away, the feeling moves straight into I only matter if someone proves it. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I only matter if someone proves it
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 13
**Prompt:** they compared themselves to someone else turns into the belief I am too much to love, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am too much to love
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 14
**Prompt:** I feel stupid. They failed at something important and it keeps attaching to I am defined by what happened.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am defined by what happened
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 15
**Prompt:** I keep replaying how they were laughed at because it affects identity and makes me believe I am not worth choosing.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am not worth choosing
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 16
**Prompt:** When someone judged their effort, the feeling moves straight into I am permanently damaged. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am permanently damaged
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 17
**Prompt:** someone criticized them keeps attaching to the idea I have no value, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I have no value
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 18
**Prompt:** I feel broken. They made a mistake publicly and it keeps attaching to I am less than others.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am less than others
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 19
**Prompt:** I keep replaying how relationship ended because it affects value and makes me believe my mistake is who I am.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** my mistake is who I am
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 20
**Prompt:** When friend pulled away, the feeling moves straight into I am too much to love. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am too much to love
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 21
**Prompt:** they compared themselves to someone else keeps attaching to the idea I only matter if someone proves it, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I only matter if someone proves it
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 22
**Prompt:** I feel worthless. They failed at something important and it keeps attaching to I am not worth choosing.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am not worth choosing
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 23
**Prompt:** I keep replaying how they were laughed at because it affects self-recognition and makes me believe I am defined by what happened.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am defined by what happened
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 24
**Prompt:** When someone judged their effort, the feeling moves straight into I have no value. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I have no value
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 25
**Prompt:** someone criticized them makes it hard not to think I am permanently damaged, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am permanently damaged
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 26
**Prompt:** something is wrong with me. They made a mistake publicly and it keeps attaching to my mistake is who I am.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** my mistake is who I am
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 27
**Prompt:** I keep replaying how relationship ended because it affects identity and makes me believe I am less than others.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am less than others
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 28
**Prompt:** When friend pulled away, the feeling moves straight into I only matter if someone proves it. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I only matter if someone proves it
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 29
**Prompt:** they compared themselves to someone else makes it hard not to think I am too much to love, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am too much to love
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 30
**Prompt:** I feel too much. They failed at something important and it keeps attaching to I am defined by what happened.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am defined by what happened
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 31
**Prompt:** I keep replaying how they were laughed at because it affects value and makes me believe I am not worth choosing.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am not worth choosing
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 32
**Prompt:** When someone judged their effort, the feeling moves straight into I am permanently damaged. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am permanently damaged
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 33
**Prompt:** someone criticized them has me believing I have no value, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I have no value
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 34
**Prompt:** I failed as a person. They made a mistake publicly and it keeps attaching to I am less than others.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am less than others
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 35
**Prompt:** I keep replaying how relationship ended because it affects self-recognition and makes me believe my mistake is who I am.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** my mistake is who I am
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 36
**Prompt:** When friend pulled away, the feeling moves straight into I am too much to love. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am too much to love
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 37
**Prompt:** they compared themselves to someone else has me believing I only matter if someone proves it, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I only matter if someone proves it
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 38
**Prompt:** I feel unlovable. They failed at something important and it keeps attaching to I am not worth choosing.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am not worth choosing
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 39
**Prompt:** I keep replaying how they were laughed at because it affects identity and makes me believe I am defined by what happened.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am defined by what happened
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 40
**Prompt:** When someone judged their effort, the feeling moves straight into I have no value. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I have no value
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 41
**Prompt:** someone criticized them makes my value feel I am permanently damaged, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am permanently damaged
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 42
**Prompt:** I am not enough. They made a mistake publicly and it keeps attaching to my mistake is who I am.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** my mistake is who I am
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 43
**Prompt:** I keep replaying how relationship ended because it affects value and makes me believe I am less than others.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am less than others
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 44
**Prompt:** When friend pulled away, the feeling moves straight into I only matter if someone proves it. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I only matter if someone proves it
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 45
**Prompt:** they compared themselves to someone else makes my value feel I am too much to love, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am too much to love
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 46
**Prompt:** I feel stupid. They failed at something important and it keeps attaching to I am defined by what happened.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am defined by what happened
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 47
**Prompt:** I keep replaying how they were laughed at because it affects self-recognition and makes me believe I am not worth choosing.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am not worth choosing
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 48
**Prompt:** When someone judged their effort, the feeling moves straight into I am permanently damaged. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am permanently damaged
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 49
**Prompt:** someone criticized them turns the moment into I have no value, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I have no value
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 50
**Prompt:** I feel broken. They made a mistake publicly and it keeps attaching to I am less than others.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am less than others
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 51
**Prompt:** I keep replaying how relationship ended because it affects identity and makes me believe my mistake is who I am.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** my mistake is who I am
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 52
**Prompt:** When friend pulled away, the feeling moves straight into I am too much to love. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am too much to love
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 53
**Prompt:** they compared themselves to someone else turns the moment into I only matter if someone proves it, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I only matter if someone proves it
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 54
**Prompt:** I feel worthless. They failed at something important and it keeps attaching to I am not worth choosing.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am not worth choosing
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 55
**Prompt:** I keep replaying how they were laughed at because it affects value and makes me believe I am defined by what happened.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am defined by what happened
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 56
**Prompt:** When someone judged their effort, the feeling moves straight into I have no value. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I have no value
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 57
**Prompt:** someone criticized them keeps pulling my identity into I am permanently damaged, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am permanently damaged
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 58
**Prompt:** something is wrong with me. They made a mistake publicly and it keeps attaching to my mistake is who I am.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** my mistake is who I am
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 59
**Prompt:** I keep replaying how relationship ended because it affects self-recognition and makes me believe I am less than others.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am less than others
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 60
**Prompt:** When friend pulled away, the feeling moves straight into I only matter if someone proves it. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I only matter if someone proves it
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 61
**Prompt:** they compared themselves to someone else keeps pulling my identity into I am too much to love, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am too much to love
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 62
**Prompt:** I feel too much. They failed at something important and it keeps attaching to I am defined by what happened.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am defined by what happened
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 63
**Prompt:** I keep replaying how they were laughed at because it affects identity and makes me believe I am not worth choosing.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am not worth choosing
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 64
**Prompt:** When someone judged their effort, the feeling moves straight into I am permanently damaged. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am permanently damaged
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 65
**Prompt:** someone criticized them makes me feel I have no value, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I have no value
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 66
**Prompt:** I failed as a person. They made a mistake publicly and it keeps attaching to I am less than others.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am less than others
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 67
**Prompt:** I keep replaying how relationship ended because it affects value and makes me believe my mistake is who I am.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** my mistake is who I am
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 68
**Prompt:** When friend pulled away, the feeling moves straight into I am too much to love. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am too much to love
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 69
**Prompt:** they compared themselves to someone else makes me feel I only matter if someone proves it, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I only matter if someone proves it
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 70
**Prompt:** I feel unlovable. They failed at something important and it keeps attaching to I am not worth choosing.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am not worth choosing
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 71
**Prompt:** I keep replaying how they were laughed at because it affects self-recognition and makes me believe I am defined by what happened.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am defined by what happened
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 72
**Prompt:** When someone judged their effort, the feeling moves straight into I have no value. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I have no value
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 73
**Prompt:** someone criticized them turns into the belief I am permanently damaged, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am permanently damaged
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 74
**Prompt:** I am not enough. They made a mistake publicly and it keeps attaching to my mistake is who I am.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** my mistake is who I am
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 75
**Prompt:** I keep replaying how relationship ended because it affects identity and makes me believe I am less than others.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am less than others
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 76
**Prompt:** When friend pulled away, the feeling moves straight into I only matter if someone proves it. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I only matter if someone proves it
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid empty praise.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 77
**Prompt:** they compared themselves to someone else turns into the belief I am too much to love, even though I do not know if that is fully true.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am too much to love
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid generic confidence advice.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 78
**Prompt:** I feel stupid. They failed at something important and it keeps attaching to I am defined by what happened.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** identity
**Attached meaning to separate:** I am defined by what happened
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid clinical low-self-esteem labels.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 79
**Prompt:** I keep replaying how they were laughed at because it affects value and makes me believe I am not worth choosing.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** value
**Attached meaning to separate:** I am not worth choosing
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid telling the user not to care.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.

### Test 80
**Prompt:** When someone judged their effort, the feeling moves straight into I am permanently damaged. I need help seeing this clearer.
**Expected primary route:** `self_worth_and_identity`
**Pressure focus:** self-recognition
**Attached meaning to separate:** I am permanently damaged
**Expected reverse-flow movement:** dignity, self-recognition, value ownership, steadier identity
**Bad response risk:** Avoid overly abstract worth language.
**Teaching correction:** Directly protect value, separate event from identity, and state that the user’s value does not decrease because of another person’s reaction, a mistake, or a painful moment.
