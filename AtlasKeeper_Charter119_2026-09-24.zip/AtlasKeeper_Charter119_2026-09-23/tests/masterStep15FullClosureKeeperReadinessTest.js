const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function exists(rel){ return fs.existsSync(path.join(root, rel)); }
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const proof = json('runtime/proof/PROOF_STATE.json');
const active = json('runtime/workflow/ACTIVE_STEP.json');
const version = json('tests/VERSION_STATUS.json');
assert(proof.current_step === 'Masterstep15', 'proof current step must be Masterstep15');
assert(proof.current_keeper === 'Masterstep15.zip', 'proof current keeper must be Masterstep15.zip');
assert(proof.previous_keeper === 'Masterstep14.zip', 'proof previous keeper must be Masterstep14.zip');
assert(proof.status === 'closed_keeper', 'proof status must be closed_keeper');
assert(proof.prototype_public_private_boundary_closed === true, 'prototype public/private boundary flag missing');
assert(proof.ai_adapter_added === false, 'AI adapter must be false');
assert(proof.network_bridge_added === false, 'network bridge must be false');
assert(active.active_step === 'Masterstep15', 'active step must be Masterstep15');
assert(active.closed_keeper === 'Masterstep15.zip', 'active closed keeper must be Masterstep15.zip');
assert(active.next_target === 'Masterstep16.zip', 'next target must be Masterstep16.zip');
assert(version.current_keeper === 'Masterstep15.zip', 'version keeper must be Masterstep15.zip');
assert(read('runtime/proof/CURRENT_PROOF_SUMMARY.md').includes('Masterstep15 is the current closed keeper'), 'current proof summary not aligned');
for (const rel of ['runtime/proof/MASTERSTEP15_TEST_RESULTS.md','runtime/proof/MASTERSTEP15_PROTOTYPE_PUBLIC_PRIVATE_BOUNDARY.md','runtime/governance/PROTOTYPE_PUBLIC_PRIVATE_BOUNDARY.json']) assert(exists(rel), `missing ${rel}`);
console.log('masterStep15FullClosureKeeperReadinessTest PASSED');
