# Gap Completion Draft Registry

## Purpose
Defines how Atlas drafts the missing rule after identifying a weak point.

## Draft Structure
- weak point type
- missing gap
- correction rule
- frontend delivery guidance
- target backend file

## Rule
The draft must explain what Atlas should recognize next time, not only what it did wrong.
