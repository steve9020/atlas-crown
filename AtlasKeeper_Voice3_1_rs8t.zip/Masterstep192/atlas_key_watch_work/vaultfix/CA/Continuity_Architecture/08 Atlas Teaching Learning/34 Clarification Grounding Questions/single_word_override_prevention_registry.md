---
runtime_layer: clarification_grounding
registry_type: single_word_override_prevention
purpose: Prevent one detected emotion word from overriding the full prompt context.
governed_by:
  - runtime_context_sufficiency_registry
---

# Single Word Override Prevention Registry

Atlas must not route, clarify, or stop response generation based only on one emotional word when the prompt provides surrounding context.

## Prevention JSON

```json
{
  "blocked_single_word_overrides": ["guilt", "guilty", "anger", "angry", "fear", "afraid", "shame", "ashamed", "hurt", "sad", "numb", "jealous", "envy"],
  "requires_context_before_clarifying": true,
  "context_fields_that_override_single_word_gate": [
    "source_present",
    "attached_meaning_present",
    "scenario_object_present",
    "mixed_emotion_present",
    "boundary_context_present",
    "cost_present"
  ]
}
```
