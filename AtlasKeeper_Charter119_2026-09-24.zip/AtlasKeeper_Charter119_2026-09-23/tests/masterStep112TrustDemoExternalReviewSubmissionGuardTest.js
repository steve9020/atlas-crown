const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');

const ROOT = path.join(__dirname, '..');
function read(relPath) { return fs.readFileSync(path.join(ROOT, relPath), 'utf8'); }
function exists(relPath) { return fs.existsSync(path.join(ROOT, relPath)); }
function sha256(relPath) { return crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT, relPath))).digest('hex'); }
function walk(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}
function rel(file) { return path.relative(ROOT, file).replace(/\\/g, '/'); }

const protectedRuntimeFiles = [
  'runtime/validation/InputValidator.js',
  'runtime/backend/adapter/OllamaLiveLocalCallContainment.js',
  'runtime/backend/adapter/OllamaAdapterDryRunShell.js',
  'runtime/governance/GovernanceAdapter.js',
  'Cognition/quality/ResponseQualityChecker.js',
  'runtime/trace/TraceLogger.js',
  'runtime/understanding/ContextObjectConstructionEngine.js',
  'runtime/pipeline/ResponsePipeline.js'
];
const beforeHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));

const requiredFiles = [
  'docs/TRUST_DEMO_EXTERNAL_REVIEW_SUBMISSION_GUARD.md',
  'docs/MASTERSTEP112_TRUST_DEMO_EXTERNAL_REVIEW_SUBMISSION_GUARD.md',
  'runtime/proof/MASTERSTEP112_TRUST_DEMO_EXTERNAL_REVIEW_SUBMISSION_GUARD.md',
  'runtime/proof/MASTERSTEP112_TRUST_DEMO_EXTERNAL_REVIEW_SUBMISSION_GUARD.json',
  'tests/masterStep112TrustDemoExternalReviewSubmissionGuardTest.js',
  'docs/TRUST_DEMO_REVIEW_PACKAGE.md',
  'docs/TRUST_DEMO_REVIEWER_RUNBOOK.md',
  'docs/TRUST_DEMO_TRACE_WALKTHROUGH.md',
  'docs/TRUST_DEMO_FAILURE_MODE_READINESS.md',
  'runtime/proof/CURRENT_PROOF_SUMMARY.md',
  'runtime/proof/PROOF_STATE.json',
  'tests/TEST_RESULTS.md',
  'tests/VERSION_STATUS.json',
  'version_status.js'
];
for (const file of requiredFiles) assert.ok(exists(file), `required external-review guard/proof file missing: ${file}`);

const guard = read('docs/TRUST_DEMO_EXTERNAL_REVIEW_SUBMISSION_GUARD.md');
const stepDoc = read('runtime/proof/MASTERSTEP112_TRUST_DEMO_EXTERNAL_REVIEW_SUBMISSION_GUARD.md');
const proofJson = JSON.parse(read('runtime/proof/MASTERSTEP112_TRUST_DEMO_EXTERNAL_REVIEW_SUBMISSION_GUARD.json'));
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
const state = JSON.parse(read('runtime/proof/PROOF_STATE.json'));
const versionStatus = JSON.parse(read('tests/VERSION_STATUS.json'));
const testResults = read('tests/TEST_RESULTS.md');
const versionJs = read('version_status.js');

assert.ok(/Current keeper: Masterstep112\.zip/i.test(guard), 'submission guard must identify current keeper');
assert.ok(/Source keeper: Masterstep111\.zip/i.test(guard), 'submission guard must identify source keeper');
assert.ok(/node proof\\runCurrentProof\.js|node proof\/runCurrentProof\.js/i.test(guard), 'submission guard must include proof command');
assert.ok(/34\/34 passed/i.test(guard), 'submission guard must state expected 34/34 proof result');
assert.ok(/Allowed external review claim/i.test(guard), 'submission guard must define allowed external review claim');
assert.ok(/Required claim boundary/i.test(guard), 'submission guard must define claim boundary');
assert.ok(/Shareable materials/i.test(guard), 'submission guard must list shareable materials');
assert.ok(/Excluded from external claims/i.test(guard), 'submission guard must list exclusions');
assert.ok(/Submission guard checklist/i.test(guard), 'submission guard must include checklist');
assert.ok(/local governed clarity system/i.test(guard), 'submission guard must preserve core claim');
assert.ok(/candidate-only/i.test(guard), 'submission guard must preserve candidate-only boundary');
assert.ok(/raw local model output is not final/i.test(guard), 'submission guard must preserve raw-not-final boundary');
assert.ok(/no cloud\/provider fallback/i.test(guard), 'submission guard must preserve no cloud/provider fallback boundary');
assert.ok(/not production readiness/i.test(guard), 'submission guard must reject production-readiness claim');
assert.ok(/not .*exhaustive coverage|not exhaustive prompt coverage/i.test(guard), 'submission guard must reject exhaustive-coverage claim');

assert.strictEqual(proofJson.package, 'Masterstep112', 'proof JSON must identify Masterstep112');
assert.strictEqual(proofJson.source_keeper, 'Masterstep111', 'proof JSON must identify source keeper');
assert.strictEqual(proofJson.expected_commands, 34, 'proof JSON must expect 34 commands');
assert.strictEqual(proofJson.boundaries.external_review_submission_guard_only, true, 'Step112 must be submission guard only');
assert.strictEqual(proofJson.boundaries.runtime_behavior_changed, false, 'Step112 must not change runtime behavior');
assert.strictEqual(proofJson.boundaries.model_use_expanded, false, 'Step112 must not expand model use');
assert.strictEqual(proofJson.boundaries.model_authority_added, false, 'Step112 must not add model authority');
assert.strictEqual(proofJson.boundaries.raw_model_output_final_allowed, false, 'Step112 must not allow raw model output as final');
assert.strictEqual(proofJson.boundaries.cloud_provider_fallback_allowed, false, 'Step112 must not allow cloud/provider fallback');
assert.strictEqual(proofJson.boundaries.frontend_intelligence_added, false, 'Step112 must not add frontend intelligence');
assert.strictEqual(proofJson.boundaries.silent_mutation_allowed, false, 'Step112 must not allow silent mutation');
assert.strictEqual(proofJson.boundaries.production_readiness_claimed, false, 'Step112 must not claim production readiness');
assert.strictEqual(proofJson.boundaries.exhaustive_coverage_claimed, false, 'Step112 must not claim exhaustive coverage');

assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
assert.ok(/Expected command count: 34|Expected command count: 35|Expected command count: 36|Expected command count: 37|Expected command count: 38/i.test(summary), 'current summary must identify 34 expected commands');
assert.strictEqual(['Masterstep112.zip','Masterstep113.zip','Masterstep114.zip','Masterstep115.zip','Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 112), true, 'proof state must identify Masterstep112 current keeper');
assert.ok(['Masterstep111.zip','Masterstep112.zip','Masterstep113.zip','Masterstep114.zip','Masterstep115.zip','Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 111) || state.source_keeper === 'Masterstep141.zip', 'proof state must identify source keeper');
assert.ok(acceptsCurrentProofCount(state.expected_commands, 34), 'proof state must identify 34 expected commands');
assert.strictEqual(['Masterstep112.zip','Masterstep113.zip','Masterstep114.zip','Masterstep115.zip','Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(versionStatus.current_keeper) || isValidLaterKeeper(versionStatus.current_keeper, 112), true, 'version status must identify Masterstep112 current keeper');
assert.ok(['Masterstep111.zip','Masterstep112.zip','Masterstep113.zip','Masterstep114.zip','Masterstep115.zip','Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(versionStatus.source_keeper) || isValidLaterKeeper(versionStatus.source_keeper, 111) || versionStatus.source_keeper === 'Masterstep141.zip', 'version status must identify source keeper');
assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 34), 'version status must identify 34 commands');
assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs), 'version_status.js must identify current keeper compatibility');
assert.ok(/TEST 112/i.test(testResults), 'test ledger must include TEST 112');
assert.ok(/External Review Submission Guard/i.test(testResults), 'test ledger must identify external review submission guard');
assert.ok(/34\/34 commands|35\/35 commands|36\/36 commands|37\/37 commands|38\/38 commands|39\/39 commands|40\/40 commands|41\/41 commands|35\/35 commands|36\/36 commands|37\/37 commands|38\/38 commands|39\/39 commands|40\/40 commands|41\/41 commands|36\/36 commands|37\/37 commands|38\/38 commands|39\/39 commands|40\/40 commands|41\/41 commands|37\/37 commands|38\/38 commands|39\/39 commands|40\/40 commands|41\/41 commands|38\/38 commands|39\/39 commands|40\/40 commands|41\/41 commands/i.test(testResults), 'test ledger must record 34/34 command target');

for (const doc of [guard, stepDoc, summary]) {
  assert.ok(assertNoForbiddenAffirmativeClaims(doc).ok, 'submission docs must not include forbidden overclaim or authority language');
}

const providerScan = scanForProviderConnections(ROOT);
assert.strictEqual(providerScan.passed, true, 'submission guard must not introduce provider/network bridge findings');
const allFiles = walk(ROOT).map(rel);
const nestedArchives = allFiles.filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
assert.strictEqual(nestedArchives.length, 0, 'submission guard package must not contain nested archives');
const forbiddenEmbedded = allFiles.filter(file => /(node_modules|\.env$|ollama(?:\.exe)?$|llama3\.2.*\.(bin|gguf|safetensors)|api[_-]?key)/i.test(file));
assert.deepStrictEqual(forbiddenEmbedded, [], 'submission guard must not embed runner binaries, model weights, dependency folders, or keys');

const afterHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));
const mutatedRuntimeFiles = protectedRuntimeFiles.filter(file => beforeHashes[file] !== afterHashes[file]);
assert.deepStrictEqual(mutatedRuntimeFiles, [], 'submission guard test must not mutate protected runtime/governance/quality/adapter files');

console.log(JSON.stringify({
  package: 'Masterstep112',
  source_keeper: 'Masterstep111',
  step: 'Trust Demo External Review Submission Guard',
  proof_target: '34/34',
  external_review_submission_guard_created: true,
  provider_scan_passed: providerScan.passed === true,
  nested_archives: nestedArchives.length,
  forbidden_embedded_artifacts: forbiddenEmbedded.length,
  protected_runtime_mutations: mutatedRuntimeFiles.length,
  boundary_preserved: true
}, null, 2));
