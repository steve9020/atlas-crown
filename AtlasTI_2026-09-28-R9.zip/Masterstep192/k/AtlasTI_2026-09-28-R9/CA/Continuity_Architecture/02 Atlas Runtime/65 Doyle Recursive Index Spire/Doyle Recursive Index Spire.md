# Doyle Recursive Index Spire

The Doyle recursive index spire organizes Atlas categories as recursive spheres that can index inward and connect outward.

This is navigation architecture, not authority architecture.

Rule: index position does not equal permission. Recursive depth does not grant authority. The AI Assistance Sphere, when introduced later, remains one sphere inside Atlas and never becomes the root or governor.
