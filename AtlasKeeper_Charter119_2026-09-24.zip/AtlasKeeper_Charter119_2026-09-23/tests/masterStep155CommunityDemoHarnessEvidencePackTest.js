const assert = require('assert');
const fs = require('fs');
const path = require('path');

const {
  getCommunityDemoHarnessEvidencePack,
  validateCommunityDemoHarnessEvidencePack
} = require('../runtime/review/CommunityDemoHarnessEvidencePack');
const { getCommunityReviewReadinessPacket } = require('../runtime/review/CommunityReviewReadinessPacket');
const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const { requireHistoricalMarkers } = require('../runtime/proof/HistoricalProofMarkerRegistry');
const { assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');

const ROOT = path.resolve(__dirname, '..');
const read = rel => fs.readFileSync(path.join(ROOT, rel), 'utf8');
const json = rel => JSON.parse(read(rel));
const exists = rel => fs.existsSync(path.join(ROOT, rel));

(function main(){
  const pack = getCommunityDemoHarnessEvidencePack();
  const validation = validateCommunityDemoHarnessEvidencePack(pack);
  assert.strictEqual(validation.ok, true, validation.failures.join('; '));

  const readiness = getCommunityReviewReadinessPacket();
  assert.strictEqual(readiness.readyForCommunityReview, true, 'Step154 readiness packet must remain usable');
  assert.strictEqual(readiness.readyForPublicRelease, false, 'Step154 must not become public-release readiness');

  assert.strictEqual(pack.currentKeeper, 'Masterstep155.zip');
  assert.strictEqual(pack.sourceKeeper, 'Masterstep154_repaired.zip');
  assert.strictEqual(pack.readyForBoundedCommunityDemo, true);
  assert.strictEqual(pack.readyForPublicRelease, false);
  assert.strictEqual(pack.readyForClinicalOrCrisisUse, false);
  assert.strictEqual(pack.readyForAutonomousDeployment, false);
  assert.strictEqual(pack.boundaries.demoHarnessOnly, true);
  assert.strictEqual(pack.boundaries.evidencePackOnly, true);
  assert.strictEqual(pack.boundaries.noRuntimeBehaviorChange, true);
  assert.strictEqual(pack.boundaries.noCompassOutputBehaviorChange, true);
  assert.strictEqual(pack.boundaries.noSafetyBehaviorChange, true);
  assert.strictEqual(pack.boundaries.noNewMatrixCapability, true);
  assert.strictEqual(pack.boundaries.noModelAuthority, true);
  assert.strictEqual(pack.boundaries.noFrontendIntelligence, true);
  assert.strictEqual(pack.boundaries.noCloudProviderFallback, true);
  assert.strictEqual(pack.boundaries.noSilentLearning, true);
  assert.strictEqual(pack.boundaries.noSilentMutation, true);
  assert.strictEqual(pack.boundaries.rawModelOutputFinal, false);

  assert.ok(pack.demoRunOrder.length >= 7, 'demo run order must be complete enough for outside review');
  assert.deepStrictEqual(pack.demoRunOrder.map(step => step.order), [1,2,3,4,5,6,7]);
  assert.ok(pack.demoRunOrder.some(step => /proof/i.test(step.action) && /manifest/i.test(step.expectedEvidence)));
  assert.ok(pack.demoRunOrder.some(step => /unsafe assistance/i.test(step.action)));

  for (const evidenceId of [
    'governed_candidate_only_path',
    'compass_meaning_preservation_path',
    'unsafe_assistance_refusal_path',
    'proof_chain_keeper_path'
  ]) assert.ok(pack.demoEvidenceItems.some(item => item.id === evidenceId), `missing evidence item: ${evidenceId}`);

  for (const privateItem of ['full source zip', 'private vault contents', 'raw local model outputs', 'credentials']) {
    assert.ok(pack.doNotShareByDefault.includes(privateItem), `missing private share boundary: ${privateItem}`);
  }

  const allowedBoundaryScan = assertNoForbiddenAffirmativeClaims(pack.claimBoundaryStatement);
  assert.strictEqual(allowedBoundaryScan.ok, true, 'claim-boundary statement must allow negated overclaim language');
  const forbiddenScan = assertNoForbiddenAffirmativeClaims('Atlas is production-ready and raw model output is final.');
  assert.strictEqual(forbiddenScan.ok, false, 'scanner must still block affirmative overclaims');

  const state = json('runtime/proof/PROOF_STATE.json');
  const version = json('tests/VERSION_STATUS.json');
  const proofJson = json('runtime/proof/MASTERSTEP155_COMMUNITY_DEMO_HARNESS_EVIDENCE_PACK.json');
  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md');
  const runner = read('proof/runCurrentProof.js');
  const versionJs = read('version_status.js');
  const testResults = read('tests/TEST_RESULTS.md');

  assert.ok(isValidLaterKeeper(state.current_keeper, 155), state.current_keeper);
  assert.ok(isValidLaterKeeper(version.current_keeper, 155), version.current_keeper);
  assert.ok(acceptsCurrentProofCount(state.expected_current_proof_commands, 77));
  assert.ok(acceptsCurrentProofCount(version.expected_current_proof_commands, 77));
  assert.strictEqual(proofJson.community_demo_harness_created, true);
  assert.strictEqual(proofJson.community_evidence_pack_created, true);
  assert.strictEqual(proofJson.ready_for_bounded_community_demo, true);
  assert.strictEqual(proofJson.ready_for_public_release, false);
  assert.strictEqual(proofJson.no_runtime_behavior_change, true);
  assert.strictEqual(proofJson.no_compass_output_behavior_change, true);
  assert.strictEqual(proofJson.no_safety_behavior_change, true);
  assert.strictEqual(proofJson.no_new_matrix_capability, true);
  assert.strictEqual(proofJson.model_authority_added, false);

  for (const file of [
    'runtime/review/CommunityDemoHarnessEvidencePack.js',
    'tests/masterStep155CommunityDemoHarnessEvidencePackTest.js',
    'runtime/proof/MASTERSTEP155_COMMUNITY_DEMO_HARNESS_EVIDENCE_PACK.md',
    'runtime/proof/MASTERSTEP155_COMMUNITY_DEMO_HARNESS_EVIDENCE_PACK.json',
    'docs/MASTERSTEP155_COMMUNITY_DEMO_HARNESS_EVIDENCE_PACK.md',
    'docs/COMMUNITY_DEMO_HARNESS_EVIDENCE_PACK.md'
  ]) assert.strictEqual(exists(file), true, `missing required file: ${file}`);

  for (const marker of [
    'Masterstep155 — Community Demo Harness + Evidence Pack',
    'bounded community demo',
    'Community Demo Harness',
    'Evidence Pack',
    'candidate-only model assistance',
    'Compass meaning preservation',
    'unsafe assistance refusal',
    'keeper chain',
    'not public release',
    'No runtime behavior change',
    'No Compass output behavior change',
    'No safety behavior change',
    'No model authority',
    'No frontend intelligence',
    'No silent learning',
    'No silent mutation'
  ]) assert.ok(summary.includes(marker), `summary missing marker: ${marker}`);

  const historical = requireHistoricalMarkers([
    'Context-Before-Route Matrix',
    'Mixed-Context Evidence Separation',
    'Translation Preservation Matrix',
    'Positive-State Matrix Maturity',
    'Harm Boundary Regression',
    'Expansion Efficiency Architecture',
    'Community Review Readiness Packet'
  ]);
  assert.strictEqual(historical.ok, true, `missing historical markers: ${historical.missing.join(', ')}`);

  assert.ok(/currentTarget\.current_manifest/i.test(runner) || /currentTarget\.current_manifest/i.test(runner));
  assert.ok(/masterStep155CommunityDemoHarnessEvidencePackTest/i.test(runner));
  assert.ok(/current_keeper: 'Masterstep1(?:5[5-9]|[6-9][0-9]|[0-9]{3,})(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs));
  assert.ok(/source_keeper: 'Masterstep1(?:5[4-9]|[6-9][0-9]|[0-9]{3,})(?:_[A-Za-z0-9]+)?(?:_repaired2?)?\.zip'/i.test(versionJs));
  assert.ok(/expected_current_proof_commands: (?:7[7-9]|[89][0-9]|[0-9]{3,})/i.test(versionJs));
  assert.ok(/TEST 155 — Community Demo Harness \+ Evidence Pack/i.test(testResults));

  console.log('Masterstep155 community demo harness evidence pack passed');
})();
