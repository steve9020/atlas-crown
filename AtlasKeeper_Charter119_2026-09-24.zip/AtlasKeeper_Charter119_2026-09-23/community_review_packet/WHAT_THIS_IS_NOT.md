# What This Is Not

This is not a clinical tool, crisis tool, autonomous deployment, public release, therapy replacement, diagnostic engine, or claim of exhaustive safety.

This is not an invitation to inspect internal backend logic, scrape architecture, copy governance internals, or treat the packet as full technical disclosure.

This is a bounded community review packet for feedback on clarity, framing, boundaries, and next evidence needs.
