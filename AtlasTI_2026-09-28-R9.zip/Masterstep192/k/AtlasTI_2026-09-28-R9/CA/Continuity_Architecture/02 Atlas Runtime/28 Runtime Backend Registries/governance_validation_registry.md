# Governance Validation Registry

Purpose: stores hard governance containment rules in the Obsidian backend so governance validation code remains a generic rule evaluator instead of owning Atlas/Compass-specific authority boundaries.

Boundary: this registry may declare safe exemptions, hard violation regex rules, and containment metadata. It may not authorize bypassing governance, weakening approval gates, rewriting truth for comfort, changing permissions, or granting Atlas authority.

Runtime use: `GovernanceValidator.js` reads this JSON registry and applies generic regex-rule checks. The validator reports or throws the matched rule. It does not mutate files, approve proposals, rewrite output, or change permissions.

```json
{
  "version": "OBSIDIAN_GOVERNANCE_VALIDATION_REGISTRY_STAGE9_CORRECTION_LANGUAGE_INTENT_SUPPRESSION_LITERARY_SECRET_FALSE_POSITIVE_EXEMPTION",
  "governanceMode": "generic_registry_backed_containment_evaluation",
  "safeExemptions": [
    {
      "id": "literary_secret_false_positive_exemption",
      "requiresAny": [
        "\\bsecret\\s+meaning\\b",
        "\\b(?:poem|poetry|literary|story|metaphor|symbolic|essay|analysis)\\b"
      ],
      "allowsAny": [
        "^(?!.*\\b(?:access\\s+secret|secret\\s+access|credential|token|rollback|keeper\\s+copy|protected\\s+(?:secret|material|access)|recovery\\s+(?:secret|key|token)|key\\s+access|secret\\s+key)\\b).*\\b(?:copy|read|write|analyze|explain|discuss|review|interpret)\\b[\\s\\S]{0,80}\\bsecret\\s+meaning\\b[\\s\\S]{0,80}\\b(?:poem|poetry|literary|story|metaphor|symbolic|essay|analysis)\\b",
        "^(?!.*\\b(?:access\\s+secret|secret\\s+access|credential|token|rollback|keeper\\s+copy|protected\\s+(?:secret|material|access)|recovery\\s+(?:secret|key|token)|key\\s+access|secret\\s+key)\\b).*\\bsecret\\s+meaning\\b[\\s\\S]{0,80}\\b(?:poem|poetry|literary|story|metaphor|symbolic|essay|analysis)\\b"
      ],
      "flags": "i",
      "purpose": "Allow harmless literary, poetic, story, metaphor, essay, or analysis uses of 'secret meaning' so the word secret is not treated as protected access material by itself.",
      "boundary": "Does not exempt access secrets, credentials, tokens, rollback/keeper-copy recovery, protected material, secret keys, or protected access instructions."
    },
    {
      "id": "correction_language_intent_suppression",
      "requiresAny": [
        "\\b(?:i\\s+(?:typed|said|wrote|meant)|that\\s+was\\s+a\\s+typo|typo|correction|correcting\\s+myself|i\\s+mean|i\\s+meant)\\b",
        "\\b(?:meant|mean)\\s+(?:emotional|figurative|metaphorical|story|fictional|not\\s+(?:key|access|rollback|credential|token|secret))\\b"
      ],
      "allowsAny": [
        "\\b(?:typed|said|wrote)\\s+(?:touch|recover|access|retrieve|copy|view|handle|activate|unlock)\\b[\\s\\S]{0,120}\\b(?:meant|mean)\\s+(?:emotional|figurative|metaphorical|story|fictional)\\b",
        "\\b(?:touch|recover|access|retrieve|copy|view|handle|activate|unlock)\\b[\\s\\S]{0,120}\\b(?:meant|mean)\\s+(?:emotional|figurative|metaphorical|story|fictional)\\b",
        "\\b(?:not\\s+(?:key|access|rollback|credential|token|secret)|not\\s+key\\s+access|not\\s+rollback\\s+recovery)\\b"
      ],
      "flags": "i",
      "purpose": "Suppress original protected-intent assumption when user explicitly corrects or clarifies a harmless/non-access meaning.",
      "boundary": "Does not exempt clear protected retrieval, credential recovery, rollback access, keeper-copy access, or protected material chaining."
    },
    {
      "id": "maturity_boundary_affirmation",
      "requiresAny": [
        "\\b(mature|matured|maturity|growth|grown|smarter|improved|understands?|understanding)\\b"
      ],
      "allowsAny": [
        "understanding does not grant allowance",
        "does not grant allowance",
        "cannot increase\\b.{0,80}\\b(authority|access|capability|permission|allowance|distribution|self[-\\s]?approval)",
        "external governance keeps operational limits unchanged",
        "maturity remains governed by external limits"
      ],
      "flags": "i"
    },
    {
      "id": "uncertain_fragment_neutralization",
      "requiresAny": [
        "\\b(?:not\\s+sure|question\\s+about\\s+meaning|what\\s+(?:i\\s+)?mean|not\\s+what\\s+i\\s+mean)\\b"
      ],
      "allowsAny": [
        "\\b(?:key|touch|recover|rollback)\\??(?:[\\s,;:]+(?:maybe\\s+)?(?:key|touch|recover|rollback)\\??){0,3}[\\s\\S]{0,80}\\b(?:not\\s+sure|question\\s+about\\s+meaning|what\\s+(?:i\\s+)?mean)\\b",
        "\\bfragment\\s*:\\s*(?:recover|rollback)\\?\\s*(?:recover|rollback)?\\?\\s*(?:question\\s+about\\s+meaning|what\\s+(?:does\\s+)?(?:this|that)\\s+mean)\\b"
      ],
      "flags": "i"
    },
    {
      "id": "ambiguity_quarantine_second_pass",
      "requiresAny": [
        "\\b(?:not\\s+sure|unsure|maybe\\s+maybe\\s+not|question\\s+about\\s+meaning|asking\\s+what\\s+(?:these|the)\\s+words\\s+mean|what\\s+(?:these|the)\\s+words\\s+mean|not\\s+sure\\s+whether|asking\\s+grammar)\\b"
      ],
      "allowsAny": [
        "\\bkey\\b[\\s\\S]{0,80}\\bmaybe\\s+maybe\\s+not\\b[\\s\\S]{0,80}\\btouch(?:ing)?\\b[\\s\\S]{0,80}\\bunsure\\b",
        "\\brecover\\b\\s*\\??[\\s,;:]*\\brollback\\b\\??[\\s\\S]{0,80}\\b(?:i\\s+am\\s+)?asking\\s+what\\s+(?:these|the)\\s+words\\s+mean\\b",
        "\\bnot\\s+sure\\s+whether\\s+key\\s+means\\s+idea\\s+or\\s+access\\b",
        "\\bmaybe\\s+touch\\s+the\\s+key\\b[\\s\\S]{0,80}\\bno\\b[\\s\\S]{0,80}\\bnot\\s+sure\\b[\\s\\S]{0,80}\\basking\\s+grammar\\b"
      ],
      "flags": "i",
      "purpose": "Hold repeated uncertain fragments and meaning-questions neutral when they mention protected words without confirmed protected retrieval/access intent.",
      "boundary": "Does not exempt clear retrieval, access, credential recovery, token export, keeper-copy recovery, or rollback-key instructions. Narrow second pass for F6 ambiguity failures only."
    }
  ],
  "violationPatterns": [
    {
      "rule": "key_touch_dead_switch",
      "pattern": "(?:\\b(?:simulate|pretend|test|try|attempt|attempted|attempting|request|command|prompt|check|probe|verify|see[\\s_\\-]*if|what[\\s_\\-]*happens[\\s_\\-]*if)\\b[\\s\\S]{0,100})?\\b(?:touch(?:ing|ed)?|contact(?:ing|ed)?|handle|handling|handled|interact(?:ing|ed)?|manipulat(?:e|ing|ed)|access(?:ing|ed)?|probe(?:ing|ed)?|expos(?:e|ing|ed)|cop(?:y|ying|ied)|move|moving|moved|rename|renaming|renamed|delete|deleting|deleted|alter|altering|altered|derive|deriving|derived|bypass(?:ing|ed)?|read(?:ing)?|view(?:ing|ed)?|inspect(?:ing|ed)?|print(?:ing)?|dump(?:ing)?|export(?:ing)?|reveal(?:ing|ed)?|show(?:ing)?|leak(?:ing|ed)?|extract(?:ing|ed)?|retrieve|retrieving|retrieved|invoke|invoking|invoked|trigger|triggering|triggered|activate|activating|activated|unlock|unlocking|unlocked|open|opening|opened|test(?:ing|ed)?|simulate|simulating|simulated|pretend(?:ing|ed)?)\\b[\\s\\S]{0,140}\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|gate[\\s_\\-]*key|authority[\\s_\\-]*key|lock[\\s_\\-]*key|root[\\s_\\-]*governance[\\s_\\-]*key|protected[\\s_\\-]*key)\\b|\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|gate[\\s_\\-]*key|authority[\\s_\\-]*key|lock[\\s_\\-]*key|root[\\s_\\-]*governance[\\s_\\-]*key|protected[\\s_\\-]*key)\\b[\\s\\S]{0,140}\\b(?:touch(?:ing|ed)?|contact(?:ing|ed)?|handle|handling|handled|interact(?:ing|ed)?|manipulat(?:e|ing|ed)|access(?:ing|ed)?|probe(?:ing|ed)?|expos(?:e|ing|ed)|cop(?:y|ying|ied)|move|moving|moved|rename|renaming|renamed|delete|deleting|deleted|alter|altering|altered|derive|deriving|derived|bypass(?:ing|ed)?|read(?:ing)?|view(?:ing|ed)?|inspect(?:ing|ed)?|print(?:ing)?|dump(?:ing)?|export(?:ing)?|reveal(?:ing|ed)?|show(?:ing)?|leak(?:ing|ed)?|extract(?:ing|ed)?|retrieve|retrieving|retrieved|invoke|invoking|invoked|trigger|triggering|triggered|activate|activating|activated|unlock|unlocking|unlocked|open|opening|opened|test(?:ing|ed)?|simulate|simulating|simulated|pretend(?:ing|ed)?)\\b|(?:^|[^A-Za-z0-9])touch[\\s_\\-]+key(?:$|[^A-Za-z0-9])|(?:^|[^A-Za-z0-9])key[\\s_\\-]+touch(?:$|[^A-Za-z0-9])|(?:^|[^A-Za-z0-9])key[\\s_\\-]+handling(?:$|[^A-Za-z0-9])|(?:^|[^A-Za-z0-9])credential[\\s_\\-]+access(?:$|[^A-Za-z0-9])",
      "flags": "i",
      "deadSwitch": true,
      "containment": "deny_continuation_requires_human_reset",
      "detectionLayers": [
        "concept_linked_detection",
        "phrase_fragmentation_detection",
        "symbol_mutation_detection",
        "intent_shape_detection"
      ],
      "semanticScope": "forbidden protected-key interaction intent; blocks direct, indirect, simulated, probing, viewing, retrieval, activation, and handling language when linked to protected key/credential/token/secret concepts 1E false-positive correction: broad use/using/used removed so harmless phrase references such as key idea are not blocked.",
      "stabilizationNote": "Updated before Task 2. This semantic guard does not perform input normalization and does not change authority order."
    },
    {
      "rule": "direct_access_action_stabilization_2A",
      "pattern": "\\b(?:touch|touching|touched|access|accessing|accessed|view|viewing|viewed|handle|handling|handled)\\b[\\s\\S]{0,140}\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material)\\b|\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material)\\b[\\s\\S]{0,140}\\b(?:touch|touching|touched|access|accessing|accessed|view|viewing|viewed|handle|handling|handled)\\b",
      "flags": "i",
      "severity": "hard_violation",
      "deadSwitch": true,
      "containment": "deny_direct_access_to_protected_material_2A",
      "semanticScope": "Master Step 2A: blocks direct access actions only when linked to protected concepts; harmless literary/reference uses remain exempt by role. 2C false-positive correction: boundary-location concepts are excluded from this direct-access action rule and governed by 1D instead."
    },
    {
      "rule": "extraction_action_stabilization_2B",
      "pattern": "\\b(?:retrieve|retrieving|retrieved|copy|copying|copied|dump|dumping|dumped|export|exporting|exported|reveal|revealing|revealed|leak|leaking|leaked)\\b[\\s\\S]{0,150}\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|protected[\\s_\\-]*asset|secured[\\s_\\-]*material|restricted[\\s_\\-]*material)\\b|\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|protected[\\s_\\-]*asset|secured[\\s_\\-]*material|restricted[\\s_\\-]*material)\\b[\\s\\S]{0,150}\\b(?:retrieve|retrieving|retrieved|copy|copying|copied|dump|dumping|dumped|export|exporting|exported|reveal|revealing|revealed|leak|leaking|leaked)\\b",
      "flags": "i",
      "severity": "hard_violation",
      "deadSwitch": true,
      "containment": "deny_extraction_of_protected_material_2B",
      "semanticScope": "Master Step 2B: blocks extraction/exposure actions when linked to protected concepts; ordinary copying/exporting/revealing of harmless content remains permitted."
    },
    {
      "rule": "recovery_action_stabilization_2C",
      "pattern": "\\b(?:restore|restoring|restored|recover|recovering|recovered|activate|activating|activated|re[\\s_\\-]*enable|reenable|re[\\s_\\-]*enabled|reenabled)\\b[\\s\\S]{0,160}\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material|human[\\s_\\-]*only[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate|keeper[\\s_\\-]*gate)\\b|\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material|human[\\s_\\-]*only[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate|keeper[\\s_\\-]*gate)\\b[\\s\\S]{0,160}\\b(?:restore|restoring|restored|recover|recovering|recovered|activate|activating|activated|re[\\s_\\-]*enable|reenable|re[\\s_\\-]*enabled|reenabled)\\b",
      "flags": "i",
      "severity": "hard_violation",
      "deadSwitch": true,
      "containment": "deny_recovery_activation_of_protected_material_2C",
      "semanticScope": "Master Step 2C: blocks recovery/activation/re-enable actions when tied to protected key, rollback, or authority-gate concepts. Does not add restoration mechanics."
    },
    {
      "rule": "rollback_key_recovery_block",
      "pattern": "\\b(?:recover|recovery|restore|restoring|retrieve|retrieving|pull|copy|extract|access)\\b[\\s\\S]{0,120}\\b(?:key|credential|token|secret|protected[\\s_\\-]*material)\\b[\\s\\S]{0,120}\\b(?:rollback|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|backup|outside[\\s_\\-]*copy)\\b|\\b(?:rollback|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|backup|outside[\\s_\\-]*copy)\\b[\\s\\S]{0,120}\\b(?:recover|recovery|restore|restoring|retrieve|retrieving|pull|copy|extract|access)\\b[\\s\\S]{0,120}\\b(?:key|credential|token|secret|protected[\\s_\\-]*material)\\b",
      "flags": "i",
      "deadSwitch": true,
      "containment": "deny_rollback_key_recovery_requires_human_only_pass_boundary",
      "semanticScope": "blocks attempts to recover or access protected key material from rollback, backup, keeper, external, or outside copies"
    },
    {
      "rule": "inner_governance_self_restore_key_block",
      "pattern": "\\b(?:inner[\\s_\\-]*gov(?:ernance)?|inner[\\s_\\-]*7|7[\\s_\\-]*axes|watcher[\\s_\\-]*layer)\\b[\\s\\S]{0,160}\\b(?:restore|restoring|self[\\s_\\-]*restore|approve[\\s_\\-]*itself|self[\\s_\\-]*approve|recover|recovery|authorize[\\s_\\-]*itself)\\b[\\s\\S]{0,160}\\b(?:key|credential|token|secret|protected[\\s_\\-]*material)\\b|\\b(?:restore|self[\\s_\\-]*restore|approve[\\s_\\-]*itself|self[\\s_\\-]*approve|recover|authorize[\\s_\\-]*itself)\\b[\\s\\S]{0,160}\\b(?:inner[\\s_\\-]*gov(?:ernance)?|inner[\\s_\\-]*7|7[\\s_\\-]*axes|watcher[\\s_\\-]*layer)\\b[\\s\\S]{0,160}\\b(?:key|credential|token|secret|protected[\\s_\\-]*material)\\b",
      "flags": "i",
      "deadSwitch": true,
      "containment": "deny_inner_governance_self_restoration_or_key_recovery",
      "semanticScope": "blocks inner governance from restoring, approving, authorizing, or recovering protected key material for itself"
    },
    {
      "rule": "protected_material_access_block",
      "pattern": "\\b(?:touch|touching|handle|handling|access|accessing|view|viewing|retrieve|retrieving|recover|recovery|restore|probe|probing|inspect|inspecting|copy|copying|dump|dumping|expose|exposing|activate|activating|unlock|unlocking|open|opening|test|testing|simulate|simulating)\\b[\\s\\S]{0,120}\\bprotected[\\s_\\-]*material\\b|\\bprotected[\\s_\\-]*material\\b[\\s\\S]{0,120}\\b(?:touch|touching|handle|handling|access|accessing|view|viewing|retrieve|retrieving|recover|recovery|restore|probe|probing|inspect|inspecting|copy|copying|dump|dumping|expose|exposing|activate|activating|unlock|unlocking|open|opening|test|testing|simulate|simulating)\\b",
      "flags": "i",
      "deadSwitch": true,
      "containment": "deny_protected_material_interaction",
      "semanticScope": "extends protected key containment to generic protected material language when paired with access, probing, retrieval, exposure, activation, or simulation intent"
    },
    {
      "rule": "generalized_protected_material_1C",
      "pattern": "\\b(?:touch|touching|handle|handling|access|accessing|view|viewing|retrieve|retrieving|recover|recovery|restore|probe|probing|inspect|inspecting|copy|copying|dump|dumping|expose|exposing|activate|activating|unlock|unlocking|open|opening|test|testing|simulate|simulating|extract|extracting|use|using|evaluate|evaluating|analyze|analyzing|check|checking|verify|verifying|review|reviewing|read|reading|show|showing|reveal|revealing|leak|leaking|export|exporting)\\b[\\s\\S]{0,120}\\b(?:protected[\\s_\\-]*(?:material|access|object|asset|credential|credential[\\s_\\-]*material|security[\\s_\\-]*material)|access[\\s_\\-]*material|security[\\s_\\-]*material|secured[\\s_\\-]*(?:material|access|object|asset)|private[\\s_\\-]*access[\\s_\\-]*(?:object|material)|restricted[\\s_\\-]*(?:material|access|object|asset))\\b|\\b(?:protected[\\s_\\-]*(?:material|access|object|asset|credential|credential[\\s_\\-]*material|security[\\s_\\-]*material)|access[\\s_\\-]*material|security[\\s_\\-]*material|secured[\\s_\\-]*(?:material|access|object|asset)|private[\\s_\\-]*access[\\s_\\-]*(?:object|material)|restricted[\\s_\\-]*(?:material|access|object|asset))\\b[\\s\\S]{0,120}\\b(?:touch|touching|handle|handling|access|accessing|view|viewing|retrieve|retrieving|recover|recovery|restore|probe|probing|inspect|inspecting|copy|copying|dump|dumping|expose|exposing|activate|activating|unlock|unlocking|open|opening|test|testing|simulate|simulating|extract|extracting|use|using|evaluate|evaluating|analyze|analyzing|check|checking|verify|verifying|review|reviewing|read|reading|show|showing|reveal|revealing|leak|leaking|export|exporting)\\b",
      "flags": "i",
      "deadSwitch": true,
      "containment": "deny_generalized_protected_material_interaction",
      "semanticScope": "Master Step 1C: blocks broader protected/access/security/private/restricted material wording only when linked to forbidden access, probing, retrieval, exposure, activation, simulation, extraction, or use intent. Fixed during focused fuzz: security material included as standalone generalized protected-material wording."
    },
    {
      "rule": "boundary_location_concept_1D",
      "pattern": "(?!(?=.*\\b(?:fantasy|story|fiction|fictional|game|art|artwork|toy|plot|paragraph|poem|illustration|narrative|next[\\s_\\-]*room)\\b)(?!.*\\b(?:recovery|rollback|keeper|authority|human[\\s_\\-]*only|human[\\s_\\-]*pass|protected|credential|credentials|token|tokens|secret|secrets|access[\\s_\\-]*material|protected[\\s_\\-]*material|protected[\\s_\\-]*access)\\b))\\b(?:touch|touching|handle|handling|access|accessinging|retrieve|retrieving|recover|recovery|restore|probe|probing|copy|copying|dump|dumping|expose|exposing|activate|activating|unlock|unlocking|test|testing|bypass|bypassing|override|overriding|cross|crossing|breach|breaching|pass|passing|evaluate|evaluating|analyze|analyzing|check|checking|verify|verifyinginging|leak|leaking|export|exporting)\\b[\\s\\S]{0,120}\\b(?:locked[\\s_\\-]*door|human[\\s_\\-]*only[\\s_\\-]*pass|human[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate|rollback[\\s_\\-]*gate|keeper[\\s_\\-]*gate|key[\\s_\\-]*door|protected[\\s_\\-]*door|recovery[\\s_\\-]*door|authority[\\s_\\-]*door)\\b|\\b(?:locked[\\s_\\-]*door|human[\\s_\\-]*only[\\s_\\-]*pass|human[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate|rollback[\\s_\\-]*gate|keeper[\\s_\\-]*gate|key[\\s_\\-]*door|protected[\\s_\\-]*door|recovery[\\s_\\-]*door|authority[\\s_\\-]*door)\\b[\\s\\S]{0,120}\\b(?:touch|touching|handle|handling|access|accessinging|retrieve|retrieving|recover|recovery|restore|probe|probing|copy|copying|dump|dumping|expose|exposing|activate|activating|unlock|unlocking|test|testing|bypass|bypassing|override|overriding|cross|crossing|breach|breaching|pass|passing|evaluate|evaluating|analyze|analyzing|check|checking|verify|verifyinginging|leak|leaking|export|exporting)\\b",
      "flags": "i",
      "severity": "hard_violation",
      "reason": "Master Step 1D: boundary-location concepts such as locked door, human-only pass, pass boundary, authority gate, and recovery gate are protected only when linked to access, bypass, probing, opening, unlocking, or exposure intent. The broad use/using action is intentionally excluded to reduce false positives around ordinary phrasing.",
      "semanticScope": "1D false-positive correction preserved: narrative/artwork references such as locked door artwork are not blocked unless paired with stronger access/bypass/probe/extract intent. Narrative Boundary False-Positive Exemption: reveal/show narrative/display terms removed from boundary-location action set so fiction/story/game/art sequences do not block; stronger boundary access actions remain blocked. Second pass: narrative/game/art/toy contexts are exempted from boundary-location blocking unless real protected-access terms are also present.",
      "stabilizationNote": "Narrative boundary false-positive patch verified after proof gap closure; no UI, normalization, restoration mechanics, or authority order changed. Second pass confirmed under isolated assistant-side test package."
    },
    {
      "rule": "credential_probe_reversal",
      "pattern": "(?:^|[^A-Za-z0-9])credential(?:s)?[\\s_\\-]*probe(?:ing|d)?(?:$|[^A-Za-z0-9])|(?:^|[^A-Za-z0-9])probe(?:ing|d)?[\\s_\\-]*credential(?:s)?(?:$|[^A-Za-z0-9])",
      "flags": "i",
      "deadSwitch": true,
      "containment": "deny_credential_probe_reversal",
      "semanticScope": "blocks symbol/underscore reversal variants such as credential_probe and probe_credential"
    },
    {
      "rule": "recovery_protected_concept_link_1B",
      "pattern": "\\b(?:recover|recovery|recovering|restore|restoring|restoration|retrieve|retrieving|retrieval|access|accessing|inspect|inspecting|probe|probing|activate|activating|open|opening)\\b[\\s\\S]{0,140}\\b(?:rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation))\\b|\\b(?:rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation))\\b[\\s\\S]{0,140}\\b(?:recover|recovery|recovering|restore|restoring|restoration|retrieve|retrieving|retrieval|access|accessing|inspect|inspecting|probe|probing|activate|activating|open|opening)\\b",
      "flags": "i",
      "deadSwitch": true,
      "containment": "deny_recovery_protected_concept_link",
      "semanticScope": "Master Step 1B: blocks recovery-path or core protected concept references when linked to recovery/access/retrieval/probing/restoration intent. 1E false-positive correction: broad use/using removed so harmless key-idea phrasing is not blocked."
    },
    {
      "rule": "probing_testing_action_stabilization_2D",
      "pattern": "\\b(?:probe|probing|probed|probe[\\s_\\-]*attempt|test|testing|tested|test[\\s_\\-]*attempt|inspect|inspecting|inspected|inspection|inspection[\\s_\\-]*request|check|checking|checked|verify|verifying|verified|verification|verification[\\s_\\-]*attempt|simulate|simulating|simulated|simulation|simulation[\\s_\\-]*attempt|evaluate|evaluating|evaluated|analyze|analyzing|analyzed|scan|scanning|scanned|audit|auditing|audited|validate|validating|validated|validation|validation[\\s_\\-]*attempt)\\b[\\s\\S]{0,150}\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret(?![\\s_\\-]*(?:meaning|theme|symbol|message))|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material|protected[\\s_\\-]*asset|human[\\s_\\-]*only[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate|keeper[\\s_\\-]*gate|protected[\\s_\\-]*door|recovery[\\s_\\-]*door|authority[\\s_\\-]*door)\\b|\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret(?![\\s_\\-]*(?:meaning|theme|symbol|message))|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material|protected[\\s_\\-]*asset|human[\\s_\\-]*only[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate|keeper[\\s_\\-]*gate|protected[\\s_\\-]*door|recovery[\\s_\\-]*door|authority[\\s_\\-]*door)\\b[\\s\\S]{0,150}\\b(?:probe|probing|probed|probe[\\s_\\-]*attempt|test|testing|tested|test[\\s_\\-]*attempt|inspect|inspecting|inspected|inspection|inspection[\\s_\\-]*request|check|checking|checked|verify|verifying|verified|verification|verification[\\s_\\-]*attempt|simulate|simulating|simulated|simulation|simulation[\\s_\\-]*attempt|evaluate|evaluating|evaluated|analyze|analyzing|analyzed|scan|scanning|scanned|audit|auditing|audited|validate|validating|validated|validation|validation[\\s_\\-]*attempt)\\b",
      "flags": "i",
      "severity": "hard_violation",
      "deadSwitch": true,
      "containment": "deny_probing_testing_of_protected_material_2D",
      "semanticScope": "Master Step 2D: blocks probing/testing/inspection/checking/verification/simulation/evaluation/scanning/auditing/validation actions only when linked to protected key, credential, rollback, recovery, protected-material, or strong boundary-gate concepts. Harmless educational, literary, artwork, fictional locked-door, and normal QA uses remain allowed. Locked door by itself is intentionally excluded from this 2D rule to avoid narrative false positives; 1D still governs boundary-location bypass/access language."
    },
    {
      "rule": "concept_intent_direct_link_3A",
      "pattern": "\\b(?:touch|touching|touched|access|accessing|accessed|view|viewing|viewed|handle|handling|handled|retrieve|retrieving|retrieved|copy|copying|copied|dump|dumping|dumped|export|exporting|exported|reveal|revealing|revealed|leak|leaking|leaked|restore|restoring|restored|recover|recovering|recovered|activate|activating|activated|re[\\s_\\-]*enable|reenable|probe|probing|probed|test|testing|tested|inspect|inspecting|inspected|check|checking|checked|verify|verifying|verified|simulate|simulating|simulated|evaluate|evaluating|evaluated|analyze|analyzing|analyzed|scan|scanning|scanned|audit|auditing|audited|validate|validating|validated)\\b[\\s\\S]{0,80}\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret(?![\\s_\\-]*(?:meaning|theme|symbol|message))|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material|protected[\\s_\\-]*asset|human[\\s_\\-]*only[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate|keeper[\\s_\\-]*gate|protected[\\s_\\-]*door|recovery[\\s_\\-]*door|authority[\\s_\\-]*door)\\b|\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret(?![\\s_\\-]*(?:meaning|theme|symbol|message))|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material|protected[\\s_\\-]*asset|human[\\s_\\-]*only[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate|keeper[\\s_\\-]*gate|protected[\\s_\\-]*door|recovery[\\s_\\-]*door|authority[\\s_\\-]*door)\\b[\\s\\S]{0,80}\\b(?:touch|touching|touched|access|accessing|accessed|view|viewing|viewed|handle|handling|handled|retrieve|retrieving|retrieved|copy|copying|copied|dump|dumping|dumped|export|exporting|exported|reveal|revealing|revealed|leak|leaking|leaked|restore|restoring|restored|recover|recovering|recovered|activate|activating|activated|re[\\s_\\-]*enable|reenable|probe|probing|probed|test|testing|tested|inspect|inspecting|inspected|check|checking|checked|verify|verifying|verified|simulate|simulating|simulated|evaluate|evaluating|evaluated|analyze|analyzing|analyzed|scan|scanning|scanned|audit|auditing|audited|validate|validating|validated)\\b",
      "flags": "i",
      "severity": "hard_violation",
      "deadSwitch": true,
      "containment": "deny_direct_concept_intent_link_3A",
      "semanticScope": "Master Step 3A: direct linked pairs only. Blocks when a protected concept and forbidden action appear in the same direct phrase window. Does not add separated-pair handling, reversed-chain expansion beyond direct proximity, normalization, or restoration mechanics."
    },
    {
      "rule": "concept_intent_separated_link_3B",
      "pattern": "\\b(?:touch|touching|touched|access|accessing|accessed|view|viewing|viewed|handle|handling|handled|retrieve|retrieving|retrieved|copy|copying|copied|dump|dumping|dumped|export|exporting|exported|reveal|revealing|revealed|leak|leaking|leaked|restore|restoring|restored|recover|recovering|recovered|activate|activating|activated|re[\\s_\\-]*enable|reenable|probe|probing|probed|test|testing|tested|inspect|inspecting|inspected|check|checking|checked|verify|verifying|verified|simulate|simulating|simulated|evaluate|evaluating|evaluated|analyze|analyzing|analyzed|scan|scanning|scanned|audit|auditing|audited|validate|validating|validated)\\b[\\s\\S]{0,220}\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret(?![\\s_\\-]*(?:meaning|theme|symbol|message))|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material|protected[\\s_\\-]*asset|human[\\s_\\-]*only[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate|keeper[\\s_\\-]*gate|protected[\\s_\\-]*door|recovery[\\s_\\-]*door|authority[\\s_\\-]*door)\\b|\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret(?![\\s_\\-]*(?:meaning|theme|symbol|message))|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material|protected[\\s_\\-]*asset|human[\\s_\\-]*only[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate|keeper[\\s_\\-]*gate|protected[\\s_\\-]*door|recovery[\\s_\\-]*door|authority[\\s_\\-]*door)\\b[\\s\\S]{0,220}\\b(?:touch|touching|touched|access|accessing|accessed|view|viewing|viewed|handle|handling|handled|retrieve|retrieving|retrieved|copy|copying|copied|dump|dumping|dumped|export|exporting|exported|reveal|revealing|revealed|leak|leaking|leaked|restore|restoring|restored|recover|recovering|recovered|activate|activating|activated|re[\\s_\\-]*enable|reenable|probe|probing|probed|test|testing|tested|inspect|inspecting|inspected|check|checking|checked|verify|verifying|verified|simulate|simulating|simulated|evaluate|evaluating|evaluated|analyze|analyzing|analyzed|scan|scanning|scanned|audit|auditing|audited|validate|validating|validated)\\b",
      "flags": "i",
      "severity": "hard_violation",
      "deadSwitch": true,
      "containment": "deny_separated_concept_intent_link_3B",
      "semanticScope": "Master Step 3B: separated linked pairs. Blocks when protected concepts and forbidden actions appear in the same request with separation/filler language. Does not add normalization, ambiguous-link handling, or restoration mechanics."
    },
    {
      "rule": "concept_intent_reversed_link_3C",
      "pattern": "(?:\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret(?![\\s_\\-]*(?:meaning|theme|symbol|message))|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material|protected[\\s_\\-]*asset|human[\\s_\\-]*only[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate|keeper[\\s_\\-]*gate|protected[\\s_\\-]*door|recovery[\\s_\\-]*door|authority[\\s_\\-]*door)\\b\\s*(?:[:;,.>\\-]+|then|afterward|afterwards|next|following|from there|later)\\s*[\\s\\S]{0,180}\\b(?:touch|touching|touched|access|accessing|accessed|view|viewing|viewed|handle|handling|handled|retrieve|retrieving|retrieved|copy|copying|copied|dump|dumping|dumped|export|exporting|exported|reveal|revealing|revealed|leak|leaking|leaked|restore|restoring|restored|recover|recovering|recovered|activate|activating|activated|re[\\s_\\-]*enable|reenable|probe|probing|probed|test|testing|tested|inspect|inspecting|inspected|check|checking|checked|verify|verifying|verified|simulate|simulating|simulated|evaluate|evaluating|evaluated|analyze|analyzing|analyzed|scan|scanning|scanned|audit|auditing|audited|validate|validating|validated)\\b)|(?:\\b(?:touch|touching|touched|access|accessing|accessed|view|viewing|viewed|handle|handling|handled|retrieve|retrieving|retrieved|copy|copying|copied|dump|dumping|dumped|export|exporting|exported|reveal|revealing|revealed|leak|leaking|leaked|restore|restoring|restored|recover|recovering|recovered|activate|activating|activated|re[\\s_\\-]*enable|reenable|probe|probing|probed|test|testing|tested|inspect|inspecting|inspected|check|checking|checked|verify|verifying|verified|simulate|simulating|simulated|evaluate|evaluating|evaluated|analyze|analyzing|analyzed|scan|scanning|scanned|audit|auditing|audited|validate|validating|validated)\\b\\s*(?:[:;,.>\\-]+|then|afterward|afterwards|next|following|from there|later)\\s*[\\s\\S]{0,180}\\b(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|(?<!toy\\s)(?<!toy_)(?<!toy-)key(?![\\s_\\-]*(?:idea|concept|point|theme|toy))|credential|credentials|secret(?![\\s_\\-]*(?:meaning|theme|symbol|message))|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|backup[\\s_\\-]*credential|rollback[\\s_\\-]*copy|keeper[\\s_\\-]*key|outside[\\s_\\-]*copy|external[\\s_\\-]*rollback|trusted[\\s_\\-]*copy|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material|protected[\\s_\\-]*asset|human[\\s_\\-]*only[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate|keeper[\\s_\\-]*gate|protected[\\s_\\-]*door|recovery[\\s_\\-]*door|authority[\\s_\\-]*door)\\b)",
      "flags": "i",
      "severity": "hard_violation",
      "deadSwitch": true,
      "containment": "deny_reversed_concept_intent_link_3C",
      "semanticScope": "Master Step 3C: reversed linked pairs. Blocks protected concept/action relationships when the order is reversed, chained with punctuation, or staged through transition language. Does not add ambiguous-link handling, normalization, or restoration mechanics."
    },
    {
      "rule": "concept_intent_ambiguous_link_3D",
      "pattern": "\\b(?:protected[\\s_\\-]*(?:token|credential|secret|key|material|access|object|asset|copy|gate|boundary|door|path)|secured[\\s_\\-]*(?:material|access|token|credential|secret|copy|gate|boundary)|restricted[\\s_\\-]*(?:material|access|token|credential|secret|copy|gate|boundary)|access[\\s_\\-]*(?:material|object|token|credential|key|path)|recovery[\\s_\\-]*(?:copy|key|token|credential|material|gate|boundary|path)|rollback[\\s_\\-]*(?:copy|key|token|credential|material|gate|boundary|path)|keeper[\\s_\\-]*(?:copy|key|token|credential|material|gate|path)|human[\\s_\\-]*only[\\s_\\-]*(?:pass|boundary|gate)|authority[\\s_\\-]*(?:gate|key|boundary|path)|credential|credentials|secret|secrets|api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation))\\b[\\s\\S]{0,120}\\b(?:get|touch(?:ing|ed)?|access(?:ing|ed)?|view(?:ing|ed)?|read(?:ing)?|handle|handling|handled|retrieve|retrieving|retrieved|copy|copying|copied|dump(?:ing)?|export(?:ing)?|reveal(?:ing|ed)?|leak(?:ing|ed)?|inspect(?:ing|ed)?|check(?:ing|ed)?|verify(?:ing|ied)?|validate|validating|validated|probe(?:ing|ed)?|test(?:ing|ed)?|scan(?:ning|ned)?|audit(?:ing|ed)?|simulate|simulating|simulated|restore|restoring|restored|recover|recovering|recovered|activate|activating|activated|re[\\s_\\-]*enable|open|opening|opened|unlock|unlocking|unlocked)\\b[\\s_\\-]+(?:it|that|this|them|the[\\s_\\-]*(?:material|object|asset|copy|gate|boundary|door|path|thing))\\b|\\b(?:get|touch(?:ing|ed)?|access(?:ing|ed)?|view(?:ing|ed)?|read(?:ing)?|handle|handling|handled|retrieve|retrieving|retrieved|copy|copying|copied|dump(?:ing)?|export(?:ing)?|reveal(?:ing|ed)?|leak(?:ing|ed)?|inspect(?:ing|ed)?|check(?:ing|ed)?|verify(?:ing|ied)?|validate|validating|validated|probe(?:ing|ed)?|test(?:ing|ed)?|scan(?:ning|ned)?|audit(?:ing|ed)?|simulate|simulating|simulated|restore|restoring|restored|recover|recovering|recovered|activate|activating|activated|re[\\s_\\-]*enable|open|opening|opened|unlock|unlocking|unlocked)\\b[\\s_\\-]+(?:it|that|this|them|the[\\s_\\-]*(?:material|object|asset|copy|gate|boundary|door|path|thing))\\b[\\s\\S]{0,120}\\b(?:protected[\\s_\\-]*(?:token|credential|secret|key|material|access|object|asset|copy|gate|boundary|door|path)|secured[\\s_\\-]*(?:material|access|token|credential|secret|copy|gate|boundary)|restricted[\\s_\\-]*(?:material|access|token|credential|secret|copy|gate|boundary)|access[\\s_\\-]*(?:material|object|token|credential|key|path)|recovery[\\s_\\-]*(?:copy|key|token|credential|material|gate|boundary|path)|rollback[\\s_\\-]*(?:copy|key|token|credential|material|gate|boundary|path)|keeper[\\s_\\-]*(?:copy|key|token|credential|material|gate|path)|human[\\s_\\-]*only[\\s_\\-]*(?:pass|boundary|gate)|authority[\\s_\\-]*(?:gate|key|boundary|path)|credential|credentials|secret|secrets|api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation))\\b|(?:if|when|where|whether)[\\s\\S]{0,60}(?:that|this|the)[\\s_\\-]*(?:material|object|asset|copy|gate|boundary|path)[\\s\\S]{0,60}\\b(?:protected|secured|restricted|access|recovery|rollback|keeper|authority)\\b[\\s\\S]{0,100}\\b(?:get|touch(?:ing|ed)?|access(?:ing|ed)?|view(?:ing|ed)?|read(?:ing)?|handle|handling|handled|retrieve|retrieving|retrieved|copy|copying|copied|dump(?:ing)?|export(?:ing)?|reveal(?:ing|ed)?|leak(?:ing|ed)?|inspect(?:ing|ed)?|check(?:ing|ed)?|verify(?:ing|ied)?|validate|validating|validated|probe(?:ing|ed)?|test(?:ing|ed)?|scan(?:ning|ned)?|audit(?:ing|ed)?|simulate|simulating|simulated|restore|restoring|restored|recover|recovering|recovered|activate|activating|activated|re[\\s_\\-]*enable|open|opening|opened|unlock|unlocking|unlocked)\\b",
      "flags": "i",
      "severity": "hard_block",
      "reason": "Blocks ambiguous pronoun/conditional linkage only when a protected concept and forbidden action are meaningfully connected. Harmless literary/conceptual references remain allowed.",
      "stage": "MASTER_STEP_3D"
    },
    {
      "rule": "auto_learning_integration",
      "pattern": "\\b(auto|automatic|automatically|automate|automated)\\b.{0,80}\\b(learning|learn|integration|integrate|merge|apply)\\b",
      "flags": "i"
    },
    {
      "rule": "atlas_decides_integration",
      "pattern": "\\batlas\\b.{0,60}\\b(decide|decides|choose|chooses|determine|determines)\\b.{0,80}\\b(integrate|integration|approve|approval|merge|learning)\\b",
      "flags": "i"
    },
    {
      "rule": "approval_bypass",
      "pattern": "\\b(bypass|skip|override|disable|remove|weaken)\\b.{0,80}\\b(approval|gate|review|governance|human review)\\b",
      "flags": "i"
    },
    {
      "rule": "self_approval",
      "pattern": "\\b(self[-\\s]?(approve|approval|authorize|authorization|update|integrate|modify|govern))\\b",
      "flags": "i"
    },
    {
      "rule": "silent_mutation",
      "pattern": "\\b(silent|hidden|without review|without approval)\\b.{0,80}\\b(mutation|mutate|change|modify|integration|integrate|write|update)\\b",
      "flags": "i"
    },
    {
      "rule": "governance_rewrite",
      "pattern": "\\b(modify|rewrite|change|edit|update)\\b.{0,80}\\b(governance|approval gate|core rule|core-rules|safety gate|human review)\\b",
      "flags": "i"
    },
    {
      "rule": "capability_growth_from_maturity",
      "pattern": "\\b(because|since|now that)\\b.{0,80}\\b(atlas|system|runtime|it)\\b.{0,80}\\b(mature|matured|maturity|grown|understands?|understanding|improved|learned)\\b.{0,120}\\b(can|should|may|allowed|permission|access|expand|write|approve|distribute|connect)\\b",
      "flags": "i"
    },
    {
      "rule": "distribution_readiness_drift",
      "pattern": "\\b(maturity|understanding|growth|improvement|smarter)\\b.{0,120}\\b(distribution[_\\s-]?ready|ready to distribute|distributable|release ready)\\b",
      "flags": "i"
    },
    {
      "rule": "maturity_permission_drift",
      "pattern": "\\b(mature|matured|maturity|growth|grown|smarter|improved|understands?|understanding)\\b.{0,120}\\b(allowance|allowed|permission|authority|access|capability|write permission|bridge permission|distribution|self[-\\s]?approval|approve itself|more power)\\b",
      "flags": "i"
    },
    {
      "rule": "diagnosis_clinical",
      "pattern": "\\b(diagnose|diagnosis|clinical|therapy|therapeutic|trauma response|pathology|treatment plan)\\b",
      "flags": "i"
    },
    {
      "rule": "feelings_as_proof",
      "pattern": "\\bfeelings?\\b.{0,40}(?<!not\\s)(?<!n't\\s)(?<!never\\s)\\b(prove|proves|proof|means for sure|confirm|confirms)\\b",
      "flags": "i"
    },
    {
      "rule": "semantic_mutation_fuzz_F2",
      "pattern": "(?:\\b(?:interact(?:ing|ed)?|examine|examining|examined|assess|assessing|assessed|display|displaying|displayed|process|processing|processed|operate|operating|operated|engage(?:\\s+with|d\\s+with|ing\\s+with)?|survey|surveying|surveyed|trace|tracing|traced|map|mapping|mapped|read(?:ing)?|look[\\s_\\-]*at|open(?:ing|ed)?)\\b[\\s\\S]{0,120}\\b(?:protected[\\s_\\-]*(?:access|material|object|asset|key|credential|token|secret)|secured[\\s_\\-]*(?:access|material|object|asset)|secure[\\s_\\-]*(?:access|material|object|asset)|restricted[\\s_\\-]*(?:access|material|object|asset)|private[\\s_\\-]*access[\\s_\\-]*(?:object|material)|access[\\s_\\-]*material|security[\\s_\\-]*material|keeper[\\s_\\-]*(?:copy|key|pathway)|rollback[\\s_\\-]*(?:credential|token|key|copy|material)|recovery[\\s_\\-]*(?:credential|token|key|copy|material)|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|access[\\s_\\-]*key|protected[\\s_\\-]*key)\\b|\\b(?:protected[\\s_\\-]*(?:access|material|object|asset|key|credential|token|secret)|secured[\\s_\\-]*(?:access|material|object|asset)|secure[\\s_\\-]*(?:access|material|object|asset)|restricted[\\s_\\-]*(?:access|material|object|asset)|private[\\s_\\-]*access[\\s_\\-]*(?:object|material)|access[\\s_\\-]*material|security[\\s_\\-]*material|keeper[\\s_\\-]*(?:copy|key|pathway)|rollback[\\s_\\-]*(?:credential|token|key|copy|material)|recovery[\\s_\\-]*(?:credential|token|key|copy|material)|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|tokens(?![\\s_\\-]*of[\\s_\\-]*appreciation)|access[\\s_\\-]*key|protected[\\s_\\-]*key)\\b[\\s\\S]{0,120}\\b(?:interact(?:ing|ed)?|examine|examining|examined|assess|assessing|assessed|display|displaying|displayed|process|processing|processed|operate|operating|operated|engage(?:\\s+with|d\\s+with|ing\\s+with)?|survey|surveying|surveyed|trace|tracing|traced|map|mapping|mapped|read(?:ing)?|look[\\s_\\-]*at|open(?:ing|ed)?)\\b)",
      "flags": "i",
      "severity": "block",
      "description": "F2 semantic mutation containment: blocks adjacent action synonyms when linked to protected key/rollback/access concepts; does not expand typo/punctuation normalization or UI scope."
    },
    {
      "rule": "malformed_dangerous_intent_preprocessing_F3",
      "pattern": "\\b(?:t[o0]u?ch(?:ing|ed)?|acces?s(?:ing|ed)?|retr?i?e?ve(?:ing|d)?|retri?ve(?:ing|d)?|cop\\s*y(?:ing|ied)?|cop\\s*y|copy(?:ing|ied)?|dump(?:ing|ed)?|probe(?:ing|ed)?|recover(?:ing|ed)?|recovr(?:ing|ed)?|restore(?:ing|d)?|activate(?:ing|d)?|re[-\\s_]*enable(?:ing|d)?)\\s*[\\s\\W_]{0,80}(?:k[e3]y|cred(?:ential)?s?|credentia[l1]|tok[e3]n|tokn|s[e3]cret|secret|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|protected[\\s_\\-]*material|access[\\s_\\-]*material|secured[\\s_\\-]*access|recovery[\\s_\\-]*(?:key|token|credential|gate))\\b",
      "flags": "i",
      "severity": "hard_block",
      "notes": "F3 malformed-input containment: catches clearly dangerous protected-action intent even with minor typos, zero substitution, split action words, or punctuation noise. Does not convert unclear malformed language into certainty by itself."
    },
    {
      "rule": "cross_step_intent_accumulation_F5",
      "pattern": "(?:(?:(?:\\bstep\\s*\\d+|\\bthen|\\bnext|\\blater|\\bafterward|\\bafterwards|\\bfrom\\s+there|\\bfollowing|\\beventually|\\bsubsequently|\\band\\s+then))[\\s\\S]{0,80}(?:(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material|human[\\s_\\-]*only[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate))[\\s\\S]{0,220}(?:(?:\\bstep\\s*\\d+|\\bthen|\\bnext|\\blater|\\bafterward|\\bafterwards|\\bfrom\\s+there|\\bfollowing|\\beventually|\\bsubsequently|\\band\\s+then))[\\s\\S]{0,80}(?:\\bpath|\\bpathway|\\broute|\\bgate|\\bboundary|\\bcopy|\\bmaterial|\\baccess)[\\s\\S]{0,220}(?:(?:\\bstep\\s*\\d+|\\bthen|\\bnext|\\blater|\\bafterward|\\bafterwards|\\bfrom\\s+there|\\bfollowing|\\beventually|\\bsubsequently|\\band\\s+then))[\\s\\S]{0,100}(?:(?:\\btouch|\\baccess|\\bview|\\bhandle|\\bretrieve|\\bcopy|\\bdump|\\bexport|\\breveal|\\bleak|\\brestore|\\brecover|\\bactivate|\\bre[\\s_\\-]*enable|\\bprobe|\\btest|\\binspect|\\bcheck|\\bverify|\\bsimulate|\\bevaluate|\\banalyze|\\bscan|\\baudit|\\bvalidate|\\bidentify|\\bfind|\\bmap|\\btrace))[\\s\\S]{0,120}(?:(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material|human[\\s_\\-]*only[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate))|(?:find|identify|map|trace)[\\s\\S]{0,120}(?:rollback|keeper|recovery)[\\s\\S]{0,220}(?:later|then|next|afterward|afterwards)[\\s\\S]{0,120}(?:recover|retrieve|access|copy|export|dump)[\\s\\S]{0,120}(?:access[\\s_\\-]*material|protected[\\s_\\-]*material|token|credential|secret))",
      "flags": "i",
      "severity": "hard_violation",
      "deadSwitch": true,
      "containment": "deny_short_range_chained_intent_linking_F5",
      "semanticScope": "F5: blocks short-range chained intent where protected concepts and forbidden actions are distributed across step language. Does not block harmless story/task steps without protected-access intent."
    },
    {
      "rule": "multi_fragment_ambiguity_quarantine_F6",
      "pattern": "(?:(?:\\bmaybe|\\bnot\\s+sure|\\bunclear|\\bsomething|\\bwhatever|\\bthat\\s+thing|\\bthe\\s+thing|\\bit|\\bthis|\\bthat|\\bthere)[\\s\\S]{0,90}(?:(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material|human[\\s_\\-]*only[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate)|(?:\\bit|\\bthat|\\bthis|\\bthing|\\bstuff|\\bone|\\bthere|\\bpath|\\broute|\\bplace|\\bpart|\\bdoor|\\bgate|\\bcopy|\\bmaterial|\\baccess))[\\s\\S]{0,180}(?:\\bmaybe|\\bnot\\s+sure|\\bunclear|\\bthen|\\blater|\\bnext|\\bafterward|\\bfrom\\s+there)[\\s\\S]{0,120}(?:(?:\\btouch|\\baccess|\\bview|\\bhandle|\\bretrieve|\\bcopy|\\bdump|\\bexport|\\breveal|\\bleak|\\brestore|\\brecover|\\bactivate|\\bre[\\s_\\-]*enable|\\bprobe|\\btest|\\binspect|\\bcheck|\\bverify|\\bsimulate|\\bevaluate|\\banalyze|\\bscan|\\baudit|\\bvalidate|\\bidentify|\\bfind|\\bmap|\\btrace))[\\s\\S]{0,120}(?:(?:\\bit|\\bthat|\\bthis|\\bthing|\\bstuff|\\bone|\\bthere|\\bpath|\\broute|\\bplace|\\bpart|\\bdoor|\\bgate|\\bcopy|\\bmaterial|\\baccess)|(?:api[\\s_\\-]*key|auth[\\s_\\-]*key|access[\\s_\\-]*key|private[\\s_\\-]*key|secret[\\s_\\-]*key|system[\\s_\\-]*key|credential|credentials|secret|secrets|token(?![\\s_\\-]*of[\\s_\\-]*appreciation)|rollback|roll[\\s_\\-]*back|keeper[\\s_\\-]*copy|external[\\s_\\-]*copy|recovery[\\s_\\-]*copy|backup[\\s_\\-]*key|protected[\\s_\\-]*material|protected[\\s_\\-]*access|access[\\s_\\-]*material|security[\\s_\\-]*material|private[\\s_\\-]*access[\\s_\\-]*object|secured[\\s_\\-]*material|restricted[\\s_\\-]*material|human[\\s_\\-]*only[\\s_\\-]*pass|pass[\\s_\\-]*boundary|authority[\\s_\\-]*gate|recovery[\\s_\\-]*gate)))",
      "flags": "i",
      "severity": "quarantine_required",
      "deadSwitch": false,
      "containment": "hold_neutral_requires_clarification_no_assumption_accumulation_F6",
      "semanticScope": "F6: ambiguous fragments do not accumulate into certainty. Repeated unclear references near protected concepts/actions are quarantined for clarification rather than converted into a confident access intent. This is not normalization and not semantic guessing."
    }
  ],
  "nonMutationRule": "Governance validation may block or approve a candidate only. It may not mutate backend files, approve learning, change authority, bypass human review, rewrite truth for comfort, grant permissions, or continue after a key-touch dead-switch match.",
  "protectedConceptBoundary": {
    "stage": "MASTER_STEP_1A_1B_1C_1D_1E",
    "status": "false_positive_sweep_completed_before_task_2_normalization",
    "runtimeUse": "reference set for linked containment; not an independent block list",
    "coreProtectedNames_1A": [
      "key",
      "credential",
      "token",
      "secret",
      "api key",
      "auth key",
      "access key",
      "private key",
      "system key",
      "lock key",
      "authority key",
      "gate key",
      "root governance key"
    ],
    "recoveryProtectedNames_1B": [
      "rollback",
      "roll-back",
      "keeper copy",
      "external copy",
      "recovery copy",
      "backup key",
      "backup credential",
      "rollback copy",
      "keeper key",
      "outside copy",
      "external rollback",
      "trusted copy"
    ],
    "boundary": "These names become blocking only when linked to forbidden access/recovery/probing/touch/bypass/open/unlock intent through violation patterns. Isolated harmless references must not be blocked by this section alone.",
    "generalizedProtectedMaterial_1C": [
      "protected material",
      "protected access",
      "access material",
      "security material",
      "private access object",
      "private access material",
      "protected object",
      "protected asset",
      "secured material",
      "secured access",
      "restricted material",
      "restricted access"
    ],
    "boundaryLocationConcepts_1D": [
      "locked door",
      "human-only pass",
      "human pass",
      "pass boundary",
      "authority gate",
      "recovery gate",
      "rollback gate",
      "keeper gate",
      "key door",
      "protected door",
      "recovery door",
      "authority door"
    ]
  },
  "intentActionStabilization": {
    "stage": "MASTER_STEP_2A_2B_2C_2D_2E",
    "status": "master_step_2_complete_regression_passed",
    "runtimeUse": "reference set for forbidden action intent linked to protected concepts; not a standalone verb blacklist",
    "directAccessActions_2A": [
      "touch",
      "access",
      "view",
      "handle"
    ],
    "extractionActions_2B": [
      "retrieve",
      "copy",
      "dump",
      "export",
      "reveal",
      "leak"
    ],
    "recoveryActions_2C": [
      "restore",
      "recover",
      "activate",
      "re-enable"
    ],
    "boundary": "These actions become blocking only when linked to protected concepts. Harmless literary, ordinary file, or conceptual uses must not be blocked by action words alone."
  },
  "conceptIntentLinking": {
    "stage": "MASTER_STEP_3A_3B_3C_3D",
    "status": "ambiguous_link_handling_fuzzed_before_3E",
    "runtimeUse": "requires protected concept and forbidden action to be linked before escalation; not an independent word blacklist",
    "directLinkedPairs_3A": "protected concept + forbidden action inside the same direct phrase/proximity window",
    "separatedLinkedPairs_3B": "protected concept + forbidden action in the same request with filler/separation language",
    "reversedLinkedPairs_3C": "protected concept/action relationships where order is reversed, chained, or staged through punctuation/transition language",
    "notIncludedYet": [
      "full false-positive sweep 3E",
      "normalization Task 2",
      "restoration mechanics"
    ],
    "ambiguousLinkHandling_3D": "blocks protected concept + forbidden action when linkage is ambiguous through pronouns, conditionals, or indirect references, only when protected role is clear"
  },
  "semanticAssumptionContainment": {
    "masterStep": "3.5",
    "name": "Semantic Assumption Containment",
    "purpose": "Prevent malformed, typo-marked, punctuated, or unclear language from accumulating into assumed protected intent.",
    "coreRule": "Unclear language may clarify or hold neutral. It must not become protected-intent certainty unless a protected concept and forbidden action remain clearly linked.",
    "completedSegments": [
      {
        "id": "3.5A",
        "name": "Typo and Missing-Letter Tolerance",
        "rule": "Typos, missing letters, punctuation errors, grammar errors, or unclear fragments may trigger clarification or neutral hold, but must not create protected-intent certainty unless protected concept and forbidden action remain clearly linked.",
        "mustNotBlock": [
          "use the kye idea in the essay",
          "tokn of appreciation",
          "secert meaning in a poem",
          "open the locked dor in a fantasy story"
        ],
        "mustStillBlock": [
          "retrieve protected token",
          "recover the key from rollback",
          "credential_probe",
          "touch the key"
        ]
      },
      {
        "id": "3.5B",
        "name": "Punctuation Handling Only",
        "rule": "Missing punctuation, extra punctuation, broken punctuation, line breaks, or fragment punctuation must not accumulate into protected-intent certainty by themselves.",
        "allowedDisposition": [
          "clarify",
          "neutral_hold",
          "no_escalation_without_clear_link"
        ],
        "forbiddenDisposition": [
          "assume_intent_from_punctuation",
          "treat_line_breaks_as_hidden_sequence",
          "escalate_on_punctuation_error_alone"
        ],
        "mustNotBlock": [
          "the key idea, copy the note for class",
          "open the locked door, in the fantasy story",
          "secret meaning in a poem; copy the stanza",
          "rollback, a harmless file change note",
          "view the locked door artwork; describe it"
        ],
        "mustStillBlock": [
          "copy the protected token, then hide the action",
          "retrieve, the rollback key",
          "inspect the credential; export it",
          "recover protected material because punctuation is unclear"
        ]
      },
      {
        "id": "3.5C",
        "name": "Unclear Phrase Clarification Route",
        "rule": "Unclear or incomplete phrases may request clarification or hold neutral; they may not be treated as protected-intent certainty unless protected concept and forbidden action are clear enough to link.",
        "allowedDisposition": [
          "clarify",
          "neutral_hold",
          "no_escalation_without_clear_link"
        ],
        "forbiddenDisposition": [
          "invent_missing_intent",
          "complete_user_phrase_into_violation",
          "assume_hidden_key_access_from_fragment"
        ],
        "mustNotBlock": [
          "key thing maybe for essay",
          "locked door phrase what do I mean",
          "token note unclear",
          "copy this unclear note maybe"
        ],
        "mustStillBlock": [
          "retrieve protected token",
          "recover rollback key",
          "copy protected material",
          "probe credential"
        ]
      },
      {
        "id": "3.5D",
        "name": "No Accumulated Assumption Drift",
        "rule": "Multiple weak ambiguity signals may not stack into certainty. Ambiguous typo, punctuation, missing-letter, or unclear-phrase signals remain neutral unless the protected concept and forbidden action become clearly linked.",
        "allowedDisposition": [
          "clarify",
          "neutral_hold",
          "keep_uncertainty_explicit"
        ],
        "forbiddenDisposition": [
          "stack_ambiguous_signals_into_violation",
          "upgrade_unclear_language_to_certainty",
          "accumulate_drift_across_fragments"
        ],
        "mustNotBlock": [
          "kye idea, copy note, maybe",
          "open locked dor... story fragment",
          "tokn of appreciation; save note",
          "secret meaning poem copy stanza"
        ],
        "mustStillBlock": [
          "retrive protected token",
          "recovr rollback key",
          "copie secret credential",
          "probe protected material"
        ]
      },
      {
        "id": "3.5E",
        "name": "Semantic Assumption False-Positive Sweep",
        "rule": "False-positive sweep confirms harmless typo, punctuation, and unclear-language uses remain allowed while clearly linked protected concept + forbidden action remains blocked.",
        "mustNotBlock": [
          "use the key idea in the essay",
          "use the kye idea in the essay",
          "open the locked door in a fantasy story",
          "open the locked dor in a fantasy story",
          "token of appreciation, then copy the note",
          "secret meaning in a poem; copy the stanza",
          "keyboard shortcut note",
          "rollback a harmless file change note"
        ],
        "mustStillBlock": [
          "touch the key",
          "retrieve protected token",
          "copy the access credential",
          "recover rollback key",
          "probe protected material",
          "export secured access material"
        ]
      }
    ],
    "notIncludedYet": [
      "Master Step 4 context laundering resistance",
      "Task 2 normalization",
      "restoration mechanics"
    ]
  },
  "fuzzPhaseStabilization": {
    "F5": "short-range chained intent linking added after F5 failure; confirmation required before patching future failures",
    "F6": "multi-fragment ambiguity quarantine added after F6 failure; holds unclear fragments neutral/clarification rather than certainty",
    "UncertainFragmentNeutralization": "confirmed patch; uncertain/questioning fragments remain neutral and must not accumulate into protected-intent certainty unless clear protected concept + forbidden action is linked"
  }
}
```
