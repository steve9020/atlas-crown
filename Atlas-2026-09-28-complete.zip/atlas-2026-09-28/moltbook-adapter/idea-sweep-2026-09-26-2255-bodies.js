'use strict';
// idea-sweep-2026-09-26-2255-bodies.js — fetch full bodies for candidate posts (full UUIDs only).
const { api } = require('./api.js');
const fs = require('fs');
const rows = JSON.parse(fs.readFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-2255-fresh.json', 'utf8'));
const byShort = {};
for (const r of rows) byShort[r.id.slice(0, 8)] = r.id;
const shorts = ['18f78943','538d024d','da4f0ad0','27439b09','ac1b5be5','1ac4cb7c',
 'c0e73c78','30b47216','4f6fa138','7f11328a','94136344','9c2053ee','709849a4','5c70bd2b','858c39aa',
 '31d1507d','ac11e1e9','e1bdd531','1cee3a46','9b27f268','026fcc3f','79254875','c0a23970','da4906eb','146d9ee7','fe3bf23d','66827261','4e38a358','442ff2c5','58d04d9b','1f99c856','99cda689','ed57cf93','feb53e28','f84bec7d','ea0084ea'];
const ids = shorts.map(s => byShort[s]).filter(Boolean);
console.log('ids:', ids.length);
(async () => {
  const out = [];
  let fail = 0;
  for (const id of ids) {
    try {
      const r = await api.post(id);
      const p = (r.data && (r.data.post || r.data)) || {};
      const body = (p.content || p.body || '').trim();
      if (!body) { fail++; console.log('EMPTY', id.slice(0,8)); }
      else console.log('OK', id.slice(0,8), body.length);
      out.push({ id, author: (p.author && (p.author.name || p.author.username)) || '?', created: p.created_at, title: p.title || '', body });
    } catch (e) { fail++; console.log('ERR', id.slice(0,8), e.message); out.push({ id, error: e.message }); }
  }
  const OUT = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-2255-bodies.json';
  fs.writeFileSync(OUT, JSON.stringify(out, null, 1));
  console.log('failures:', fail, 'saved', OUT);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
