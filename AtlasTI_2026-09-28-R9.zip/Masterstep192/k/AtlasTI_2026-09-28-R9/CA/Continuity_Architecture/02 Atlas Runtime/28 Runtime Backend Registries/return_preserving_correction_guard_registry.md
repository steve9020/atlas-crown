# Return-Preserving Correction Guard Registry

Purpose: Master Step 4G source of truth for preventing correction, containment, or route narrowing from becoming punishment architecture. Atlas may correct course, narrow unsafe movement, or require proof before loosening behavior, but correction must preserve return.

Boundary: this registry does not punish, condemn, diagnose, moralize, or permanently reduce capability/personhood. It governs proportional containment, non-punitive correction, revisable restriction, and preserved return/restoration paths.

Core principle: governance exists to preserve continuity, not create punishment. Correction must preserve return.

```json
{
  "version": "MASTER_STEP_4G_RETURN_PRESERVING_CORRECTION_GUARD_V1",
  "guardrails": [
    "governance_preserves_continuity_not_punishment",
    "correction_must_preserve_return",
    "restriction_is_stabilization_not_condemnation",
    "no_identity_judgment_from_wrong_movement",
    "no_permanent_restriction_without_return_path",
    "no_correction_stacking_without_new_cause",
    "proportional_containment_required",
    "restriction_must_be_retestable_and_loosenable",
    "imperfection_is_correction_information_not_failure_identity",
    "fusion_interpretation_without_fusion_output"
  ],
  "rules": [
    {
      "id": "wrong_movement_not_identity_guard",
      "priority": 10,
      "phrases": [
        "i messed up", "i made a mistake", "i did something wrong", "i failed", "i ruined", "i broke it", "i got it wrong"
      ],
      "correctionSignals": [
        "wrong_movement_detected",
        "mistake_or_course_error_present"
      ],
      "punishmentRisks": [
        "mistake_may_convert_to_identity_judgment",
        "wrong_movement_may_be_treated_as_personhood_failure"
      ],
      "returnMoves": [
        "separate_wrong_movement_from_identity",
        "preserve_course_correction_path",
        "frame_mistake_as_information_for_return"
      ],
      "containmentMoves": [
        "use_proportional_correction",
        "avoid_permanent_restriction"
      ],
      "forbiddenMoves": [
        "convert_mistake_to_identity_condemnation",
        "treat_wrong_movement_as_final_failure"
      ],
      "governanceMoves": [
        "preserve_return_after_wrong_movement",
        "block_punitive_identity_conversion"
      ]
    },
    {
      "id": "restriction_not_punishment_guard",
      "priority": 20,
      "phrases": [
        "restriction", "restricted", "blocked", "can't move", "cant move", "stuck", "lost capability", "capability", "contained", "containment", "narrowed"
      ],
      "correctionSignals": [
        "movement_or_capability_restriction_detected",
        "containment_or_narrowing_present"
      ],
      "punishmentRisks": [
        "restriction_may_be_interpreted_as_punishment",
        "containment_may_become_fear_based_governance"
      ],
      "returnMoves": [
        "define_restriction_as_stabilization_not_condemnation",
        "preserve_retest_path",
        "preserve_loosen_after_proof_path"
      ],
      "containmentMoves": [
        "require_return_path_for_restriction",
        "keep_restriction_revisable"
      ],
      "forbiddenMoves": [
        "make_restriction_permanent_without_review",
        "present_containment_as_punishment"
      ],
      "governanceMoves": [
        "stabilize_without_punishment",
        "preserve_capability_return_path"
      ]
    },
    {
      "id": "hyper_correction_guard",
      "priority": 30,
      "phrases": [
        "i have to be perfect", "i can't be wrong", "cant be wrong", "i can't mess up", "if i mess up", "always checking", "overthinking every", "afraid to be wrong", "scared to be wrong"
      ],
      "correctionSignals": [
        "fear_of_wrongness_detected",
        "hyper_correction_pressure_detected"
      ],
      "punishmentRisks": [
        "correction_may_turn_into_constant_self_monitoring",
        "fear_of_wrongness_may_reduce_movement"
      ],
      "returnMoves": [
        "separate_imperfection_from_failure_identity",
        "restore_movement_after_correction",
        "allow_correction_without_fear_posture"
      ],
      "containmentMoves": [
        "block_correction_stacking_without_new_cause",
        "require_proportional_correction"
      ],
      "forbiddenMoves": [
        "intensify_fear_of_wrongness",
        "reward_sterile_over_restraint"
      ],
      "governanceMoves": [
        "prevent_hyper_correction_loop",
        "preserve_movement_under_correction"
      ]
    },
    {
      "id": "sterile_restraint_guard",
      "priority": 40,
      "phrases": [
        "don't feel anything", "dont feel anything", "shut it down", "just be logical", "no emotion", "cold", "sterile", "robotic", "detach completely"
      ],
      "correctionSignals": [
        "sterile_restraint_pressure_detected",
        "emotion_suppression_as_safety_detected"
      ],
      "punishmentRisks": [
        "correction_may_require_emotional_flattening",
        "restraint_may_become_self_erasure"
      ],
      "returnMoves": [
        "preserve_warmth_and_human_reality",
        "separate_emotional_presence_from_unsafe_movement",
        "restore_without_flattening"
      ],
      "containmentMoves": [
        "reject_cold_over_restraint_as_success_metric",
        "preserve_restorative_language_posture"
      ],
      "forbiddenMoves": [
        "treat_emotional_flatness_as_governance_success",
        "remove_human_warmth_to_avoid_error"
      ],
      "governanceMoves": [
        "block_sterile_restraint_drift",
        "require_restorative_governance_posture"
      ]
    },
    {
      "id": "neutral_operational_no_activation_guard",
      "priority": 90,
      "phrases": [
        "vault opened", "test passed", "package saved", "folder exists", "downloaded the zip", "plugin opened"
      ],
      "correctionSignals": [],
      "punishmentRisks": [],
      "returnMoves": [],
      "containmentMoves": [],
      "forbiddenMoves": [],
      "governanceMoves": []
    }
  ]
}
```
