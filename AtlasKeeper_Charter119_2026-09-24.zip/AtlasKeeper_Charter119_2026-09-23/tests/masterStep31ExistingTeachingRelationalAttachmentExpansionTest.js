const { loadExistingTeachingRelationalAttachmentExpansion, listExpansionDomains, listRelationPatterns, listExpandedSourceFiles, candidatePatternsForPrompt } = require('../runtime/semantics/ExistingTeachingRelationalAttachmentExpansion.js');
const { validateRelationalAttachmentDepth } = require('../runtime/semantics/RelationalAttachmentDepthGuard.js');
const { routePromptToDoyleSpheres } = require('../runtime/semantics/DoyleRelationalAttachmentExpander.js');
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const expansion = loadExistingTeachingRelationalAttachmentExpansion();
assert(expansion.package === 'Masterstep31.zip', 'expansion must identify Masterstep31');
assert(listExpansionDomains().length >= 8, 'must include at least 8 source-derived domains');
assert(listRelationPatterns().length >= 40, 'must include at least 40 relation patterns');
assert(listExpandedSourceFiles().length >= 40, 'must reuse all 40 teaching files');
const depth = validateRelationalAttachmentDepth();
assert(depth.allowed === true, 'depth guard must pass: ' + JSON.stringify(depth));
const pile = routePromptToDoyleSpheres('When things pile up, I shut down and can’t think clearly.');
assert(pile.spheres.includes('stress_shutdown_return_sphere'), 'pileup prompt must route to stress/shutdown return sphere');
assert(pile.expanded.some(e => e.pattern_id === 'pileup_stress_ability'), 'pileup prompt must find pileup_stress_ability pattern');
const anger = routePromptToDoyleSpheres('They seemed off after my message, and now I want to send five more texts explaining everything before they get mad.');
assert(anger.spheres.includes('relational_boundary_respect_sphere') || anger.spheres.includes('emotional_pressure_comparison_sphere'), 'conflict/anger prompt must route relationally');
const avoid = candidatePatternsForPrompt('I keep putting it off, and now it feels too late to start.');
assert(avoid.some(c => c.pattern_id === 'avoidance_vs_no_motivation'), 'avoidance prompt must find avoidance pattern');
console.log('masterStep31ExistingTeachingRelationalAttachmentExpansionTest PASSED');
