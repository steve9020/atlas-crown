---
title: Compass Response Behavior Governance
runtime_layer: governance
priority: highest
status: active
phase: runtime_link_cleanup
governed_by:
  - governance_enforcement_registry
  - runtime_backend_registries_overview
outputs:
  - response_behavior_registry
  - runtime_registry_flow
---

# Compass Response Behavior Governance

## Purpose

Ensures Compass responses remain plain-English, human, grounded, non-clinical, non-authoritative, and continuity-restoring.

This node exists because multiple backend nodes already reference this governance target.

It is a resolution node, not a new conceptual expansion.

## Runtime Rule

This governance target should constrain routing and response behavior without becoming visible as technical language in the user-facing Compass reflection.

## Related Runtime Links

- [[governance_enforcement_registry]]
- [[response_behavior_registry]]
- [[runtime_registry_flow]]
- [[runtime_backend_registries_overview]]
