# Relational Role Response Guidance

## Purpose
Guides Compass language when relational titles appear.

## Response Direction
- name the role context lightly
- do not assume the relationship is safe or close
- explain why the emotional weight may be stronger
- identify silence/cutoff/self-blame pressure when present
- separate worry from proof
- avoid generic emotional weight language as the lead

## Example
"Because this involves your sister, the silence can feel more personal. When someone close will not talk, the mind can start searching for whether you caused the distance. That worry is understandable, but it does not prove you did something wrong."
