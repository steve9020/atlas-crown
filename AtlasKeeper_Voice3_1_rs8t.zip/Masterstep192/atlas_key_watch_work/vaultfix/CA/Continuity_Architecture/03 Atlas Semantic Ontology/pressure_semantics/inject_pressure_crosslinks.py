from pathlib import Path

folder = Path.cwd()

crosslinks = """

## Related Activations
- contradiction_semantics/contradiction_detection
- recursive_semantics/recursive_looping
- destabilization_semantics/destabilization_detection

## Stabilization Routes
- stabilization_semantics/pause_stabilization
- stabilization_semantics/grounding_stabilization
- stabilization_semantics/containment_stabilization

## Recovery Dependencies
- recovery_semantics/emotional_recovery
- recovery_semantics/self_return_recovery

## Fragmentation Risks
- fragmentation_semantics/fragmentation_risk
- coherence_semantics/coherence_instability

## Escalation Risks
- escalation_semantics/escalation_detection
- threshold_semantics/escalation_thresholds

## Adaptive Reroutes
- adaptive_semantics/adaptive_flexibility
- adaptive_semantics/adaptive_response

## Continuity Preservation Links
- continuity_semantics/continuity_preservation
- preservation_semantics/continuity_preservation
"""

for file in folder.glob("*.md"):
    content = file.read_text(encoding="utf-8")

    if "## Related Activations" in content:
        continue

    content += crosslinks

    file.write_text(content, encoding="utf-8")

print("Pressure semantic crosslinks injected.")