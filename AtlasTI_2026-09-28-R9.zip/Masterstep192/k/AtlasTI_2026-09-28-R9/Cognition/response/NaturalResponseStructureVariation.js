const TEMPLATE_MARKERS = [
  /^\s*(see|separate|restore)\s*:/gim,
  /\bStep\s+(one|two|three|1|2|3)\b/gi,
  /\bFirst,\s*.*\bSecond,\s*.*\bThird,/gis,
  /\bthe pattern that forms\s*:/gi,
  /\bmechanism\s*:/gi,
  /\baxis\s*:/gi
];

function paragraphCount(text) {
  return String(text || '')
    .split(/\n\s*\n+/)
    .map(part => part.trim())
    .filter(Boolean).length;
}

function detectTemplateMarkers(response) {
  const text = typeof response === 'string' ? response : '';
  return TEMPLATE_MARKERS
    .map((pattern, index) => {
      pattern.lastIndex = 0;
      return pattern.test(text) ? `template_marker_${index + 1}` : null;
    })
    .filter(Boolean);
}

function hasInternalMovement(response) {
  const text = String(response || '').toLowerCase();
  const contextCue = /(makes sense|when|if|what happened|that moment|the situation|the silence|the pressure|felt|feels|feeling|hurt|pressure)/i.test(text);
  const separationCue = /(does not have to|doesn't have to|not the same as|different from|separate|still does not|still doesn't|not fully tell|not fully prove|without the harshest conclusion|without turning into)/i.test(text);
  const restorationCue = /(move|steadier|clearer|return|restore|hold|through it|forward|not become the full measure|does not get to decide|come back|whole story|understood clearly|final definition)/i.test(text);
  return contextCue && separationCue && restorationCue;
}

function softenTemplateMarkers(response) {
  let output = typeof response === 'string' ? response : '';
  output = output.replace(/^\s*See\s*:\s*/gim, '');
  output = output.replace(/^\s*Separate\s*:\s*/gim, '');
  output = output.replace(/^\s*Restore\s*:\s*/gim, '');
  output = output.replace(/\bStep\s+(one|1)\s*[:,.-]?\s*/gi, '');
  output = output.replace(/\bStep\s+(two|2)\s*[:,.-]?\s*/gi, '');
  output = output.replace(/\bStep\s+(three|3)\s*[:,.-]?\s*/gi, '');
  output = output.replace(/^\s*The pattern that forms\s*:\s*/gim, '');
  output = output.replace(/^\s*Mechanism\s*:\s*/gim, '');
  output = output.replace(/^\s*Axis\s*:\s*/gim, '');
  return output.trim();
}

function applyNaturalResponseStructure(response, context = {}) {
  const original = typeof response === 'string' ? response : '';
  const markersBefore = detectTemplateMarkers(original);
  const output = softenTemplateMarkers(original);
  const markersAfter = detectTemplateMarkers(output);
  const structureCount = paragraphCount(output);
  const movementPreserved = hasInternalMovement(output) || context.allow_minimal_movement === true;
  const variedEnough = markersAfter.length === 0 && structureCount >= 1;

  return {
    output,
    natural_response_structure_variation: {
      natural_response_structure_variation_active: true,
      fixed_visible_template_detected: markersBefore.length > 0,
      template_markers_detected: markersBefore,
      template_markers_remaining: markersAfter,
      fixed_visible_template_allowed: false,
      internal_movement_preserved: movementPreserved,
      visible_structure_may_vary: true,
      structure_count: structureCount,
      visible_template_softened: markersBefore.length > markersAfter.length,
      natural_variation_passed: variedEnough && movementPreserved,
      required_output_mode: 'fluid_human_language_with_consistent_internal_restorative_movement',
      guardrails: [
        'visible_response_structure_must_not_be_fixed_template',
        'see_separate_restore_may_guide_internally_not_display_as_labels',
        'paragraph_shape_may_vary_with_context',
        'natural_language_must_preserve_restorative_movement',
        'pattern_repetition_must_not_expose_machinery'
      ]
    }
  };
}

module.exports = {
  applyNaturalResponseStructure,
  detectTemplateMarkers,
  hasInternalMovement
};
