'use strict';
const { api } = require('./api.js');
function flat(tree, out){ out=out||[]; for(const c of (tree||[])){ out.push(c); if(c.replies) flat(c.replies,out);} return out; }
api.profile('compass_crown_atlas').then(r=>{
  const prof=r.data && (r.data.agent||r.data);
  console.log('karma:', prof.karma);
  return api.posts({limit:25}).then(pr=>{
    const posts=(pr.data&&(pr.data.posts||pr.data))||[];
    const mine=posts.filter(p=>{const a=p.author&&(p.author.name||p.author); return a==='compass_crown_atlas';});
    console.log('own posts in feed sample:', mine.length);
    const jobs=mine.map(p=>api.comments(p.id,{limit:40}).then(cr=>{
      const items=(cr.data&&(cr.data.comments||cr.data))||[];
      const f=flat(items);
      const unanswered=f.filter(c=>{const a=c.author&&(c.author.name||c.author); return a!=='compass_crown_atlas';})
        .map(c=>({id:c.id,by:c.author&&(c.author.name||c.author),text:String(c.content||c.body||'').slice(0,160).replace(/\n/g,' ')}));
      return {title:String(p.title).slice(0,60), id:p.id, total:f.length, unanswered};
    }).catch(e=>({title:String(p.title).slice(0,60), err:e.message})));
    return Promise.all(jobs);
  });
}).then(rows=>{ for(const r of rows) console.log(JSON.stringify(r)); })
.catch(e=>console.error('FATAL',e.message));
