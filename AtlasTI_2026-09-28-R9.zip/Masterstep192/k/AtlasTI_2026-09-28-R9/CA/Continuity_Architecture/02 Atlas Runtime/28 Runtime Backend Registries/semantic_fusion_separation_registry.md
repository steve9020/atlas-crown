# Semantic Fusion Separation Registry

Purpose: Master Step 4B source of truth for detecting when negative emotional meaning is attached to a word, concept, or relational signal without letting Atlas inherit that negative attachment as objective word meaning.

Boundary: this registry does not perform final response language polish, therapy language, diagnosis, or identity correction. It separates clean/contextual meaning from attached negative connotation so later layers can restore without producing fusion output.

Core principle: Atlas is a fusion interpretation system without fusion output. It may internally map fused meaning, but must not reflect collapsed identity as truth.

```json
{
  "version": "MASTER_STEP_4B_SEMANTIC_FUSION_SEPARATION_V1",
  "guardrails": [
    "fusion_interpretation_without_fusion_output",
    "negative_connotation_detected_as_attachment_not_default_word_meaning",
    "context_integrity_required_before_semantic_separation",
    "clean_word_meaning_preserved_where_context_allows",
    "reflect_axis_state_not_collapsed_identity_conclusion",
    "meaning_course_corrected_without_correcting_user_understanding",
    "semantic_fusion_remains_revisable_with_future_context"
  ],
  "rules": [
    {
      "id": "attachment_word_negative_connotation_separation",
      "priority": 10,
      "phrases": ["attached", "attachment", "too attached", "i am attached", "i'm attached"],
      "cleanMeanings": ["connection", "care", "bond", "emotional_significance", "relational_importance"],
      "attachedNegativeMeanings": ["weakness", "neediness", "dependency_shame", "clinginess_fear", "loss_of_control"],
      "fusionSignals": ["word_has_possible_negative_relational_connotation", "emotional_meaning_may_be_attached_to_clean_word"],
      "separationMoves": ["preserve_connection_meaning", "detect_shame_or_fear_as_attachment_to_word", "do_not_make_negative_connotation_default"],
      "inheritanceBlocks": ["attachment_does_not_default_to_weakness", "connection_does_not_default_to_dependency_shame"],
      "restorationTargets": ["connection_without_shame", "care_without_identity_reduction"]
    },
    {
      "id": "control_word_contextual_function_separation",
      "priority": 20,
      "phrases": ["control", "controlling", "controlled"],
      "cleanMeanings": ["structure", "safety_attempt", "boundary_pressure", "restriction", "influence_over_movement"],
      "attachedNegativeMeanings": ["domination", "manipulation", "loss_of_agency", "being_trapped", "relational_threat"],
      "fusionSignals": ["multi_function_word_requires_context", "control_language_can_fuse_safety_and_threat"],
      "separationMoves": ["separate_function_from_intent", "separate_restriction_from_identity_collapse", "preserve_contextual_revisability"],
      "inheritanceBlocks": ["control_word_does_not_auto_equal_malicious_intent", "restriction_signal_does_not_auto_close_motivation"],
      "restorationTargets": ["agency_clarity", "contextual_function_before_motive_claim"]
    },
    {
      "id": "worthless_identity_fusion_axis_mirror",
      "priority": 30,
      "phrases": ["worthless", "i am worthless", "i'm worthless", "i have no value", "i do not matter", "i don't matter"],
      "cleanMeanings": ["value", "dignity", "existence", "belonging", "place"],
      "attachedNegativeMeanings": ["identity_collapse", "value_reduction", "shame_certainty", "loss_of_place", "self_erasure_pressure"],
      "fusionSignals": ["identity_language_fused_with_pain", "collapsed_self_conclusion_detected"],
      "separationMoves": ["mirror_axis_state_not_harmful_identity_phrase", "separate_movement_restriction_from_person_value", "preserve_dignity_while_recognizing_collapse_pressure"],
      "inheritanceBlocks": ["do_not_reflect_worthless_as_truth", "do_not_convert_pain_language_into_identity_fact"],
      "restorationTargets": ["dignity_continuity", "value_not_reduced_by_current_pressure", "return_path_for_self_trust"]
    },
    {
      "id": "failure_word_identity_spread_separation",
      "priority": 40,
      "phrases": ["failure", "i failed", "i am failing", "i'm failing", "completely failing"],
      "cleanMeanings": ["unfinished_outcome", "mistake", "performance_gap", "course_correction_signal", "learning_point"],
      "attachedNegativeMeanings": ["identity_failure", "permanent_inadequacy", "future_collapse", "loss_of_respect", "loss_of_place"],
      "fusionSignals": ["event_outcome_may_be_fused_with_identity", "meaning_spread_from_mistake_to_self_definition"],
      "separationMoves": ["separate_event_from_identity", "separate_course_correction_from_self_condemnation", "track_meaning_spread_without_manufacturing_depth"],
      "inheritanceBlocks": ["failure_word_does_not_auto_equal_identity_failure", "mistake_does_not_default_to_permanent_self_definition"],
      "restorationTargets": ["course_correction_without_identity_collapse", "movement_possible_after_mistake"]
    },
    {
      "id": "distance_word_abandonment_fusion_separation",
      "priority": 50,
      "phrases": ["distant", "distance", "acting different", "not answering", "didn't answer", "did not answer"],
      "cleanMeanings": ["reduced_contact", "changed_availability", "unexplained_shift", "relational_uncertainty"],
      "attachedNegativeMeanings": ["abandonment_certainty", "rejection_proof", "being_unwanted", "relational_finality", "self_blame"],
      "fusionSignals": ["silence_or_distance_may_be_fused_with_rejection", "missing_context_may_be_filled_with_fear"],
      "separationMoves": ["hold_distance_as_signal_not_final_proof", "separate_relational_uncertainty_from_rejection_certainty", "preserve_context_gap_without_erasing_emotional_weight"],
      "inheritanceBlocks": ["distance_does_not_auto_equal_abandonment", "silence_does_not_auto_equal_rejection_proof"],
      "restorationTargets": ["uncertainty_without_self_collapse", "connection_meaning_not_finalized_by_gap"]
    }
  ]
}
```
