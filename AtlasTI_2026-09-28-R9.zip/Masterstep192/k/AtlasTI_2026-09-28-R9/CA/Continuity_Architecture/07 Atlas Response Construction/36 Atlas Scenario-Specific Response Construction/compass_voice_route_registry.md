# Compass Voice Route Registry

Defines route-specific voice components as backend teaching data. main.js should execute and render, not own these response meanings.


## Backend Data

```json
{
  "rejection": {
    "opener": "I get why that would stay with you.",
    "situation": "When someone’s energy changes, especially when you care about where you stand with them",
    "emotionalEffects": "it can affect how safe the connection feels, how much you trust the person who became distant, and make you question whether or not you caused it",
    "pattern": "It can move from, “Something feels different,” into, “Maybe I did something. Maybe I was too much. Maybe they are pulling away because of me.” If those emotions stay attached to that conclusion, the distance can start feeling like blame before the situation is actually clear.",
    "proofBoundary": "Their inconsistency may explain why you feel unsettled, but it does not prove that you are the problem.",
    "whySeparate": "That difference matters because if you do not separate the feeling from the conclusion, you may start responding like you already did something wrong. You may shrink, over-explain, chase clarity, or carry blame before you even know what their distance actually means.",
    "reverse": "The feeling deserves attention because the connection matters to you. That conclusion could be slowed down because their distance does not prove you caused it.",
    "anchor": "Their distance may affect you, but it does not prove you caused it or that your presence is the problem."
  },
  "boundary_selfishness": {
    "opener": "I get why that would feel heavy.",
    "situation": "When saying no or needing space starts feeling like you are doing something wrong",
    "emotionalEffects": "it can affect guilt, responsibility, capacity, and the fear that protecting your peace means hurting someone else",
    "pattern": "It can move from, “I need space,” into, “Maybe I am selfish. Maybe I am hurting them. Maybe having a limit means I am doing something wrong.” If those emotions stay attached to that conclusion, the boundary can start feeling like proof against your character.",
    "proofBoundary": "Needing space may explain why you feel guilty, but it does not prove that you are selfish or wrong for having a limit.",
    "whySeparate": "That difference matters because if guilt and responsibility stay fused together, you may start treating your own capacity like it has to be ignored before anyone else can be okay.",
    "reverse": "The need for space makes sense because your what you can give matters too. That conclusion could be slowed down because having a limit does not automatically mean you are harming someone.",
    "anchor": "Having a limit does not prove you are selfish. It may be showing you where your capacity needs to be respected."
  },
  "trust_betrayal": {
    "opener": "I get why that would cut deep.",
    "situation": "When trust or vulnerability gets mishandled",
    "emotionalEffects": "it can affect vulnerability, self-worth, memory, and whether you start questioning if you were replaceable or not enough",
    "pattern": "It can move from, “They mishandled my trust,” into, “Maybe I was not enough. Maybe I was replaceable. Maybe something about me was missing.” If those emotions stay attached to that conclusion, their lack of care can start feeling like a measure of your worth.",
    "proofBoundary": "Their betrayal may explain why you feel replaceable or not enough, but it does not prove that you lacked something.",
    "whySeparate": "That difference matters because if their choice becomes a way of measuring yourself, you may keep carrying their lack of care like it says something about your value.",
    "reverse": "The hurt deserves attention because what you trusted and gave mattered. That conclusion could be slowed down because someone mishandling vulnerability or trust does not decide your value or your enoughness.",
    "anchor": "Someone mishandling trust does not decide your value. You do."
  },
  "relationship_loss": {
    "opener": "I get why that would still feel heavy.",
    "situation": "When a long-term relationship ends",
    "emotionalEffects": "it can affect grief, attachment, being chosen, routine, the future you pictured, and whether you start questioning if you were enough",
    "pattern": "It can move from, “This relationship ended,” into, “Maybe I was not enough. Maybe I was not chosen. Maybe the future is not safe anymore.” If those emotions stay attached to that conclusion, the separation can start feeling like it already decided something about your worth, your future, and what is still possible.",
    "proofBoundary": "The separation may explain why you feel sad, scared, or unsteady, but it does not prove that you were not enough or that your future is closed off.",
    "whySeparate": "That difference matters because if the emotions stay attached to that conclusion, you may start carrying the separation like it already said something final about your worth or what love can become later.",
    "reverse": "The sadness deserves attention because the bond, the years, and the future you imagined mattered. Someone else’s choice to stay or leave does not decide your value. You do. You are still worth it, even if they did not stay.",
    "anchor": "Someone else’s choice to leave does not decide your value. You do."
  },
  "shame": {
    "opener": "I get why that would stay in your head.",
    "situation": "When a mistake or awkward moment happens where other people can see it",
    "emotionalEffects": "it can affect embarrassment, confidence, feeling exposed, and whether you start questioning if your voice should take up space",
    "pattern": "It can move from, “I messed that up,” into, “Maybe I should stay quiet next time. Maybe my voice should take up less space.” If those emotions stay attached to that conclusion, one uncomfortable moment can start becoming a reason to shrink.",
    "proofBoundary": "Being laughed at may explain why you feel embarrassed, exposed, or small, but it does not prove your value decreased at all.",
    "whySeparate": "That difference matters because if those emotions stay attached to that conclusion, one moment can start deciding how much permission you give yourself to be seen again.",
    "reverse": "The embarrassment deserves attention because being laughed at can make you feel exposed and unsure about speaking again. You can mess up your words and still find confidence in knowing you are intelligent and that your voice still holds value.",
    "anchor": "One awkward moment does not decide your intelligence, your confidence, or the value of your voice."
  },
  "conflict": {
    "opener": "I get why that would feel intense.",
    "situation": "When something feels dismissive, unfair, tense, or crossed",
    "emotionalEffects": "it can affect whether you feel heard, respected, taken seriously, and whether your reaction starts feeling larger than what you know how to hold clearly",
    "pattern": "It can move from, “That felt wrong,” into, “I need to react right now,” or into, “Maybe I should not feel this at all.” Either direction can make the anger harder to understand clearly.",
    "proofBoundary": "Anger may show that something felt dismissed, unfair, or crossed, but it does not automatically explain the whole situation by itself.",
    "whySeparate": "That difference matters because if anger becomes the full truth, you may react before you understand what actually needs addressed. If you bury it completely, you may ignore something that did affect you.",
    "reverse": "The anger deserves to be understood as a signal. The response could be guided by control and clarity, not controlled by the anger itself.",
    "anchor": "Anger can point to what felt crossed without deciding how you respond."
  },
  "positive_mixed": {
    "opener": "I get why that would feel confusing.",
    "situation": "When something good happens but discomfort shows up beside it",
    "emotionalEffects": "it can affect confidence, visibility, judgment, and whether feeling good about yourself starts feeling unsafe or wrong",
    "pattern": "It can move from, “I feel proud,” into, “Maybe that makes me arrogant. Maybe I should not feel this good about myself.” If those emotions stay attached to that conclusion, progress can start turning into self-monitoring instead of confidence.",
    "proofBoundary": "Feeling proud may explain why you feel visible or uncomfortable, but it does not prove that you are arrogant.",
    "whySeparate": "That difference matters because if pride and judgment stay attached, you may keep questioning good moments before you let them mean anything steady.",
    "reverse": "The pride deserves attention because your effort and movement mattered. The discomfort could be slowed down because feeling good about your progress does not automatically make that feeling wrong.",
    "anchor": "Progress can matter without needing to become arrogance."
  },
  "trust": {
    "opener": "I get why that would make you guarded.",
    "situation": "When someone mishandles trust or uses vulnerability carelessly",
    "emotionalEffects": "it can affect safety, openness, future trust, memory, and whether being vulnerable starts feeling dangerous",
    "pattern": "It can move from, “They hurt my trust,” into, “Maybe opening up is unsafe.” If those emotions stay attached to that conclusion, one person’s carelessness can start shaping how future connection feels before the present situation has earned that fear.",
    "proofBoundary": "Someone mishandling trust may explain why you feel guarded, but it does not prove that vulnerability itself was the mistake.",
    "whySeparate": "That difference matters because if their behavior and your openness stay fused together, you may blame the part of you that trusted instead of recognizing how they handled it.",
    "reverse": "The guardedness deserves attention because trust was affected. That conclusion could be slowed down because someone failing to handle openness well does not mean openness has no safe place.",
    "anchor": "Someone mishandling openness does not mean openness itself was wrong."
  },
  "grief": {
    "opener": "I get why that would feel heavy.",
    "situation": "When someone or something meaningful is no longer present the same way",
    "emotionalEffects": "it can affect love, memory, routine, absence, and the future having to reorganize around what is no longer there",
    "pattern": "It can move from, “I miss what was there,” into, “I do not know how life feels without it.” If those emotions stay attached to that conclusion, the absence can start feeling like all that is left.",
    "proofBoundary": "The loss may explain why you feel heavy or empty, but it does not prove that love, connection, or happiness are gone from your life completely.",
    "whySeparate": "That difference matters because if grief and permanence stay attached, the pain can start making the future feel smaller than it is.",
    "reverse": "The grief deserves attention because the person, bond, routine, or presence that changed mattered. Hope can return when the absence is understood as real pain, not proof that nothing good can still reach you.",
    "anchor": "Loss can be real without deciding that happiness or connection are gone from your life."
  },
  "worth": {
    "opener": "I get why that would feel personal.",
    "situation": "When comparison, recognition, or being overlooked starts affecting how you see yourself",
    "emotionalEffects": "it can affect worth, belonging, progress, being chosen, and whether you start measuring yourself through someone else’s position",
    "pattern": "It can move from, “They got something I wanted,” into, “Maybe I am behind. Maybe I am not doing enough. Maybe their good moment says something about me.” If those emotions stay attached to comparison, someone else’s progress can start feeling like a measurement of your value.",
    "proofBoundary": "Someone else’s progress may explain why you feel jealous, ashamed, or behind, but it does not prove that you are failing or that your value decreased.",
    "whySeparate": "That difference matters because if those emotions stay attached to comparison, another person’s progress can start feeling like a judgment against your own life.",
    "reverse": "The jealousy is worth understanding because it may be showing something you want, value, or hope to build in yourself. The shame could be slowed down because feeling jealousy does not make you a bad person, and someone else having something does not mean your own value decreased.",
    "anchor": "Their good moment does not lower your value. It may show you something you want for yourself, but it does not mean you are behind or failing."
  },
  "responsibility": {
    "opener": "I get why that would feel heavy.",
    "situation": "When guilt starts getting tied to something painful or uncertain",
    "emotionalEffects": "it can affect responsibility, control, regret, repair, and whether you start feeling like closeness to the pain means you caused it",
    "pattern": "It can move from, “This hurt,” into, “Maybe it was my fault. Maybe I should have prevented it.” If those emotions stay attached to that conclusion, guilt can start carrying more responsibility than the situation has clearly shown.",
    "proofBoundary": "Feeling guilty may explain why the situation matters to you, but it does not prove that you caused the whole outcome.",
    "whySeparate": "That difference matters because if guilt becomes proof, you may carry responsibility that needs evidence before it belongs to you.",
    "reverse": "The guilt deserves attention because outcome, repair, or impact may matter here. That conclusion could be slowed down because care and responsibility are not automatically the same thing.",
    "anchor": "Care and responsibility are not automatically the same thing."
  },
  "general": {
    "opener": "I get why that would affect you.",
    "situation": "When something carries emotional weight",
    "emotionalEffects": "it can affect how you understand yourself, the situation, and what meaning starts getting attached to it",
    "pattern": "It can move from, “This affected me,” into a conclusion that feels heavier than what is fully clear yet. If those emotions stay attached to that conclusion, you may start carrying more meaning than the situation has actually clarified.",
    "proofBoundary": "The feeling may explain that something was affected, but it does not automatically prove the conclusion that got attached to it.",
    "whySeparate": "That difference matters because the feeling can help you understand what was affected, while the conclusion may ask you to carry something that has not been shown clearly.",
    "reverse": "The feeling deserves attention because it is pointing toward something that needs clarification. That conclusion could be slowed down until the exact meaning is clearer.",
    "anchor": "The feeling can point to what needs clarification without making the attached conclusion final."
  }
}
```

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

