const assert = require('assert');
const fs = require('fs');
const path = require('path');
const status = require('../version_status.js');

const root = path.resolve(__dirname, '..');
const required = [
  'runtime/compass/CompassOntologyLanguageWeaver.js',
  'runtime/compass/CompassSeeSeparateRestoreRenderer.js',
  'tests/masterStep88SurfaceActionDeeperUnderstandingRepairTest.js',
  'tests/masterStep88FullClosureKeeperReadinessTest.js',
  'docs/MASTERSTEP88_SURFACE_ACTION_DEEPER_UNDERSTANDING_REPAIR.md',
  'runtime/proof/MASTERSTEP88_SURFACE_ACTION_DEEPER_UNDERSTANDING_REPAIR.md',
  'runtime/proof/MASTERSTEP88_SURFACE_ACTION_DEEPER_UNDERSTANDING_REPAIR.json',
  'proof/runCurrentProof.js',
  'version_status.js'
];
const missing = required.filter(rel => !fs.existsSync(path.join(root, rel)));
assert.deepStrictEqual(missing, []);
assert.ok(['Masterstep88','Masterstep89','Masterstep90','Masterstep91','Masterstep92'].includes(status.currentKeeper));
assert.ok(['Masterstep87','Masterstep88','Masterstep89','Masterstep90','Masterstep91'].includes(status.previousKeeper));
assert.strictEqual(status.surfaceActionDeeperUnderstandingRepairComplete, true);
assert.strictEqual(status.groundedPartUsesDeeperUnderstandingNotSurfaceAction, true);
assert.strictEqual(status.fearedPossibilityPreparationRendered, true);
assert.strictEqual(status.restoreStartsFromTruthNotSurfaceAction, true);
assert.strictEqual(status.step88NoNewOntologyAdded, true);
assert.strictEqual(status.step88NoNewMechanismsAdded, true);
assert.strictEqual(status.step88NoDeletionPerformed, true);
assert.strictEqual(status.step88NoProviderModelCloudFrontendExpansion, true);
assert.strictEqual(status.providerConfigured, false);
assert.strictEqual(status.realModelConnected, false);
assert.strictEqual(status.networkBridgeEnabled, false);
assert.strictEqual(status.frontendIntelligenceAllowed, false);
assert.strictEqual(status.operatorConsoleAdded, false);
console.log('masterStep88FullClosureKeeperReadinessTest PASSED');
