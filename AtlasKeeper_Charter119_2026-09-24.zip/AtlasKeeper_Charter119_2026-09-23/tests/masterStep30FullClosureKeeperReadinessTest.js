const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function assert(cond,msg){ if(!cond) throw new Error(msg); }
function exists(rel){ return fs.existsSync(path.join(root, rel)); }
function read(rel){ return fs.readFileSync(path.join(root, rel),'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
const expected = 'Masterstep30.zip';
for (const rel of ['runtime/proof/PROOF_STATE.json','runtime/workflow/ACTIVE_STEP.json','runtime/workflow/WORKFLOW_STATE.json','runtime/workflow/IMPLEMENTATION_SCOPE.json']) {
  assert(exists(rel), rel + ' must exist');
  const obj = json(rel);
  assert(obj.current_keeper === expected || obj.active_keeper_preserved === expected, rel + ' must point to Masterstep30');
  assert(obj.status === 'closed_keeper', rel + ' must be closed keeper');
  assert(obj.current_step === 'Masterstep30' || obj.step === 'Masterstep30', rel + ' must identify Masterstep30');
  assert(obj.real_ai_connected === false || obj.must_not_happen, rel + ' must not connect real AI');
  assert(obj.local_model_connected === false || obj.must_not_happen, rel + ' must not connect local model');
  assert(obj.network_bridge_added === false || obj.must_not_happen, rel + ' must not add network bridge');
}
assert(exists('runtime/semantics/EXISTING_ATTACHMENT_DOYLE_CROSSWALK.json'), 'existing attachment crosswalk must exist');
assert(exists('runtime/semantics/ExistingAttachmentDoyleCrosswalk.js'), 'crosswalk loader must exist');
assert(exists('runtime/semantics/ExistingAttachmentCoverageGuard.js'), 'coverage guard must exist');
const version = read('version_status.js');
assert(version.includes("current_keeper: 'Masterstep30.zip'"), 'version status must point to Masterstep30');
assert(version.includes('existing_attachment_crosswalk_added: true'), 'version status must include crosswalk flag');
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md');
assert(summary.includes('Current keeper: Masterstep30.zip'), 'summary must name current keeper');
assert(summary.includes('Existing Attachment Crosswalk + Doyle Sphere Consolidation'), 'summary must name step');
assert(summary.includes('No real AI connected'), 'summary must preserve AI boundary');
console.log('masterStep30FullClosureKeeperReadinessTest PASSED');
