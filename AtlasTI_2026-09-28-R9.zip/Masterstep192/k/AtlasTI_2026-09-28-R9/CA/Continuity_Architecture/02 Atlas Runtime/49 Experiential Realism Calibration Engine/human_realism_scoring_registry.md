# Human Realism Scoring Registry

## Score Areas
- natural phrasing
- lived-feeling language
- emotional presence
- grounded pacing
- conversational rhythm
- realism continuity

## Detection
Reduce:
- robotic structure
- overformal phrasing
- emotionally absent delivery
- overprocessed transitions
