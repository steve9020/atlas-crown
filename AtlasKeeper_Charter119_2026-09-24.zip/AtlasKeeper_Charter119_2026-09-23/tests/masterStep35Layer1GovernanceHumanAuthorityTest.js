
const assert = require('assert');
const layer1 = require('../runtime/indexing/DoyleLayer1GovernanceMap');
const guard = require('../runtime/indexing/DoyleLayer1PlacementGuard');
const spire = require('../runtime/indexing/DoyleSpireLayerSphereMap');

const result = layer1.validateLayer();
assert.strictEqual(result.passed, true, `Layer 1 validation failed: ${result.errors.join(',')}`);
assert.strictEqual(layer1.countSpheres(), 12, 'Layer 1 must have 12 spheres');
const required = ['Human Authority','Approval / Rejection','Permission Boundary','Mutation Control','Audit / Trace','Rollback / Recovery','Public / Private Boundary','AI Containment','Prototype Readiness','Safety Claim Boundary','Origin / Local Containment','No-Influence / No-Control'];
for (const name of required) assert.ok(layer1.getSphereByName(name), `missing ${name}`);
const noPower = guard.validateNoPlacementAuthority();
assert.strictEqual(noPower.passed, true, `Layer 1 placement granted power: ${noPower.failures.join(',')}`);
const placed = guard.placeGovernanceRelation({ layer:'L1', sphere:'AI Containment', action:'place_ai_containment_record' });
assert.strictEqual(placed.accepted, true);
assert.strictEqual(placed.authority_granted, false);
assert.strictEqual(placed.mutation_allowed, false);
assert.strictEqual(placed.ai_enabled, false);
assert.strictEqual(spire.getLayer('L1').spheres.length, 12, 'main spire L1 remains 12 spheres');
console.log('masterStep35Layer1GovernanceHumanAuthorityTest PASSED');
