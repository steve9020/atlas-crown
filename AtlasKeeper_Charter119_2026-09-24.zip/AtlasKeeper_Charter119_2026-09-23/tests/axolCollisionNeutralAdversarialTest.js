const {detectAxes}=require('../Cognition/engine/AxisEngine.js');
const neutral=['The blue folder is on the desk beside the lamp.','We met at three and ordered coffee.','The file contains twelve pages and two tables.','A train arrived while the doors were open.'];
let falseHits=[];for(const t of neutral){const r=detectAxes(t);if(r.axes.length)falseHits.push({t,axes:r.axes});}
const neg=[['authority','He absolutely has the authority to decide this matter.'],['trust','I do not trust him to keep his word.'],['change','Nothing about the arrangement has changed.'],['connection','I do not feel close to them anymore.']];
let structuralMiss=[];for(const [a,t] of neg){const r=detectAxes(t);if(!r.axes.includes(a))structuralMiss.push({a,t,got:r.axes});}
console.log(JSON.stringify({neutral:falseHits.length===0,falseHits,negationStructural:neg.length-structuralMiss.length,totalNegation:neg.length,structuralMiss},null,2));if(falseHits.length||structuralMiss.length)process.exitCode=1;
