# Reintegration Reverse Flows

## Definition
Reintegration reverse flows are pathways where reintegration weakens, fails, reverses, or becomes blocked under destabilization, fragmentation, overload, or distortion.

## Function
They show how systems move away from coherent reconnection and toward renewed fragmentation or recursive destabilization.

## Relationships
- [[Reintegration]]
- [[Adaptive Reintegration Flows]]
- [[Fragmentation Reverse Flows]]
- [[Recovery Reverse Flows]]
- [[Destabilization]]
