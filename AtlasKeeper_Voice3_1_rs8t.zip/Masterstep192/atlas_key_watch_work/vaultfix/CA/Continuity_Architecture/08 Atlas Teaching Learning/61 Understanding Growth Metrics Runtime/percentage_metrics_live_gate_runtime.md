# Percentage Metrics Live Gate Runtime

## Purpose

Atlas may display percentages only when each percentage has a defined numerator, denominator, source data, and action meaning.

## Required percentages

- Growth % = approved and integrated backend updates ÷ reviewed teaching proposals.
- Understanding % = passed route/card retests ÷ total route/card retests.
- Mistake Recovery % = corrected failures that passed retest ÷ corrected failures retested.
- Duplicate / Merge Readiness % = proposals that passed duplicate, merge, conflict, and scope checks ÷ proposals reviewed for those gates.
- Route Verification % = Route Assumption Checks that confirmed or corrected the best route ÷ total Route Assumption Checks.
- Card Accuracy % = correct callout card retests ÷ total card retests.
- Repeated Weakness Reduction % = repeated weakness categories reduced after correction ÷ repeated weakness categories tracked.

## Action rule

Each percentage must produce a suggested action. Low values must route toward review, retesting, merge checking, or weakness detection instead of pretending Atlas has improved.

## Approval rule

A proposal is not final when accepted. Approval moves it toward draft review. Duplicate, merge, conflict, scope, integration, runtime reload, and retest gates must be resolved before a proposal counts as implemented.

## Retest rule

Every proposal that changes routing, card selection, frontend wording, or teaching behavior must include a retest prompt, expected route, expected callout card, blocked behavior, and pass/fail result.
