# Masterstep84 — Compass See / Separate / Restore Renderer Repair

Source keeper: Masterstep83
Current keeper: Masterstep84

## Purpose
Repair final Compass expression without adding new semantic mechanisms. Atlas already had enough upstream structure after Step83; the failure was that final output was crammed into one paragraph and exposed internal analysis language.

## Scope
- Add backend renderer for See / Separate / Restore.
- Preserve Atlas semantic / Doyle / separation / restoration inputs.
- Translate structure into human-facing Compass language.
- Expose Restore as a structured gold-block payload for the frontend shell.
- Block internal phrases such as "This is carrying..." and "The part to separate is..." from covered final outputs.

## Boundaries
- No deletion.
- No new mechanism batch.
- No provider/model/cloud/API/network bridge.
- No operator console.
- No frontend intelligence; frontend renders backend-provided structured HTML only.
