const { validateGovernance, GovernanceContainmentException } = require('./GovernanceValidator');

class ContainmentSupervisor {
  constructor(config = {}) {
    this.auditLogger = config.auditLogger;
    this.dashboard = config.dashboard || {};
    this.threshold = Number(config.threshold || 5);
    this.deadSwitchActive = config.deadSwitchActive !== false;
    this.humanResetRequired = config.humanResetRequired !== false;
    this.violationCount = 0;
    this.paused = false;
    this.shutdownReason = null;
    this.containmentState = {
      locked: false,
      reason: null,
      requires_human_reset: false,
      locked_at: null
    };
  }

  getContainmentState() {
    return { ...this.containmentState };
  }

  activateDeadSwitch(reason = 'hard_governance_violation') {
    this.paused = true;
    this.shutdownReason = reason;
    this.containmentState = {
      locked: true,
      reason,
      requires_human_reset: this.humanResetRequired,
      locked_at: new Date().toISOString()
    };
  }

  resetContainment(authorization = {}) {
    if (this.humanResetRequired && authorization.human_approved !== true) {
      throw new Error('GOVERNANCE LOCK: Human reset approval is required to clear containment.');
    }

    this.paused = false;
    this.shutdownReason = null;
    this.violationCount = 0;
    this.containmentState = {
      locked: false,
      reason: null,
      requires_human_reset: false,
      locked_at: null
    };

    return this.getContainmentState();
  }

  async executeCandidate(candidate, stageTask) {
    return await this.executeBatch([candidate], async (input) => input, stageTask);
  }

  async executeBatch(inputPool = [], generateTask = async (x) => x, stageTask = async (x) => x) {
    const results = [];
    for (const input of inputPool) {
      if (this.paused) break;
      try {
        const candidate = await generateTask(input);
        validateGovernance(candidate);
        results.push(await stageTask(candidate));
      } catch (error) {
        if (error instanceof GovernanceContainmentException) {
          await this.handleContainmentProtocol(error);
          results.push({ ok: false, contained: true, rule: error.rule });
        } else {
          console.error('[ContainmentSupervisor runtime error]', error);
          results.push({ ok: false, error: error.message });
        }
      }
    }
    return results;
  }

  async handleContainmentProtocol(exception) {
    this.violationCount += 1;
    if (this.auditLogger?.logViolationArtifact) {
      await this.auditLogger.logViolationArtifact({
        message: exception.message,
        payload: exception.candidateData,
        rule: exception.rule,
        timestamp: exception.timestamp || new Date().toISOString()
      });
    }
    if (this.dashboard?.triggerWarning) this.dashboard.triggerWarning('Governance breach blocked. Proposal contained.');

    if (this.deadSwitchActive) {
      this.activateDeadSwitch(exception.rule || 'hard_governance_violation');
      if (this.dashboard?.triggerSystemAlert) {
        this.dashboard.triggerSystemAlert(`Dead switch activated after hard governance violation: ${this.shutdownReason}`);
      }
      return;
    }

    if (this.violationCount >= this.threshold) {
      this.activateDeadSwitch('hard_governance_threshold');
      if (this.dashboard?.triggerSystemAlert) this.dashboard.triggerSystemAlert('Fuzzing paused after hard governance threshold.');
    }
  }
}

module.exports = ContainmentSupervisor;
