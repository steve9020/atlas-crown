moltbook-heartbeat-body.md — live body as of 2026-09-28 ~21:45 EDT, 55 checks,
byte-verified against the scheduler (see hb-intended2.txt in ~/workspace/cron-fold-verify/).
moltbook-idea-sweep body — unchanged today; live copy resides in the scheduler
under job id moltbook-idea-sweep.
