'use strict';
/**
 * TeachingIntakeBridge — plugin-side bridge to the backend Teaching Intake.
 *
 * Loaded by the plugin via absolute path (path.join(pluginDir, ...)).
 * Every method is backend-owned: the frontend shell requests and displays,
 * it never interprets. All intake state lives in the backend store.
 *
 * Usage from main.js:
 *   const bridge = require(path.join(pluginDir, 'TeachingIntakeBridge.js'));
 *   this.teachingIntake = bridge.create({ vaultBasePath, pluginDir });
 */

const path = require('path');

function create(ctx = {}) {
  const vaultBasePath = ctx.vaultBasePath || '';
  const pluginDir = ctx.pluginDir || '';
  const packageRoot = path.resolve(vaultBasePath, '..', '..');

  let examiner = null;
  let store = null;
  let audits = null;
  let scanner = null;

  function backend() {
    if (!store) {
      const teachingDir = path.join(packageRoot, 'runtime', 'teaching');
      examiner = require(path.join(teachingDir, 'IndependentExaminer.js'));
      store = require(path.join(teachingDir, 'TeachingIntakeStore.js'));
      audits = require(path.join(teachingDir, 'TeachingAudits.js'));
      scanner = require(path.join(packageRoot, 'runtime', 'safety', 'InputInjectionScanner.js'));
    }
    return { examiner, store, audits, scanner };
  }

  return {
    packageRoot,
    pluginDir,

    stats() { return backend().store.stats(); },

    // -- candidates -------------------------------------------------------
    createCandidate(data) { return backend().store.createCandidate(data); },
    getCandidate(id) { return backend().store.getCandidate(id); },
    listCandidates(filter) { return backend().store.listCandidates(filter || {}); },

    examineCandidate(id) {
      const { examiner: ex, store: st } = backend();
      const candidate = st.getCandidate(id);
      if (!candidate) throw new Error('candidate not found: ' + id);
      const report = ex.examineCandidate(candidate);
      st.saveExamReport(id, report);
      return report;
    },

    reviewCandidate(id, approved, note) {
      return backend().store.reviewCandidate(id, approved, note);
    },

    promoteCandidate(id) {
      const { store: st } = backend();
      return st.promoteCandidate(id, backend().examiner);
    },

    // -- frequent flyers ---------------------------------------------------
    listFlyers(options) { return backend().store.listFlyers(options || {}); },
    listQuarantined() { return backend().store.listQuarantined(); },
    promoteFlyerToCandidate(flyerId) { return backend().store.promoteFlyerToCandidate(flyerId); },
    archiveFlyer(flyerId) { return backend().store.archiveFlyer(flyerId); },

    // -- versions ----------------------------------------------------------
    listVersions() { return backend().store.listVersions(); },
    rollbackTo(version) { return backend().store.rollbackTo(version); },

    // -- audits ------------------------------------------------------------
    runAudit(sampleSize) { return backend().audits.runRandomAudit({ sampleSize }); },
    listAudits() { return backend().store.listAudits(); },

    // -- examiner info (for honest UI labels) ------------------------------
    examinerInfo() {
      return {
        nature: backend().examiner.EXAMINER_NATURE,
        scoreBar: backend().examiner.SCORE_BAR,
      };
    },
  };
}

module.exports = { create };
