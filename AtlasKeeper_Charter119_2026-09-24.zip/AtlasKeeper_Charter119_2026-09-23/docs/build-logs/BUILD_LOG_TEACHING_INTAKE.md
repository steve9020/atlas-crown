# Build Log — AXOL Teaching Intake + Teaching Center UI Revamp

Target: AtlasKeeper Voice3.2 (Teaching Intake build). Started 2026-09-22.

## Locked spec (Steve-approved 2026-09-22)
1. Independent examiner: scripted, builds blind tests from the rule DEFINITION, never sees candidate examples. Steve may add hand-written held-out cases (welcome, never required).
2. Two stamps per promotion, both required, labeled separately: MACHINERY (proof suite re-run) + MEANING (examiner blind score + Steve approval).
3. Frequent-flyer log: every unplaced phrase logged permanently (phrase, count, first/last seen), sorted highest-count first. Cap ~500 active. Repeats group. 30-day archive (not delete). Injection scan BEFORE pool entry. Triage surfaces substantial ones only; frequency is the main signal.
4. Rollback: versioned promotions (keeper N→N+1) with changelog + both stamps. One-step revert. Bad versions quarantined for study, not deleted.
5. Rubber-stamp protection: cheap reviews (candidate + score + samples, approve/reject in a minute). Random audits re-examine past approvals with fresh blind tests; failures return to Steve with evidence.

## Honest-limits notes (public-claims standard)
- Examiner is a SCRIPTED held-out judge, not a model. A passing score means the rule behaves as defined, not that the distinction is true.
- Injection scanner is heuristic pattern matching, not a security proof.
- Machinery stamp = AXOL regression suite + proof-orchestrator cache status; full closure still runs via the existing orchestrator.

## Changes
### Backend (Node, vaultfix/)
- `Cognition/engine/AxisEngine.js`: ADDITIVE export `detectAxesWithExtraRules(input, extraRules)` + `clearAxisRegistryCache()`. No existing behavior changed.
- `runtime/safety/InputInjectionScanner.js` (NEW): heuristic input-side scan. No scanner existed in tree; built per spec.
- `runtime/teaching/IndependentExaminer.js` (NEW): examiner for 3 candidate types.
- `runtime/teaching/TeachingIntakeStore.js` (NEW): candidates, flyer log, versions, audits. JSON file `runtime/teaching/teaching-intake-store.json`.
- `runtime/teaching/voice-teaching-pairs.json` (NEW): approved voice-pair registry (calibration evidence, NOT voice rules).
- `runtime/pipeline/ResponsePipeline.js`: frequent-flyer capture hook after detectAxes (try/catch, never breaks pipeline).

### Plugin (continuity-interface/)
- `TeachingIntakeBridge.js` (NEW): loads backend modules via absolute path, exposes intake API to UI.
- `main.js`: onload wires `this.teachingIntake`; `renderAutoTeachingTab` revamped to 5 tabs; new `bindTeachingIntakeUI`.
- `styles.css`: new component styles.

## Tests
- Node: examiner, store, scanner, AxisEngine export.
- Headless Obsidian rig: plugin load, teaching view render, intake submit → examine → review queue.

## Delivery
- One zip, unique outer folder, in ~/workspace/your_files/.

## Build completed 2026-09-22 ~16:00 EDT — all verified

### What was built (final file list)
Backend (Node):
- `Cognition/engine/AxisEngine.js`: + `detectAxesWithExtraRules(input, extraRules)` (in-memory staging, live registry untouched), + `clearAxisRegistryCache()`. Additive only; all 106 existing proofs unaffected (registry md5 verified byte-identical after full test cycle).
- `runtime/safety/InputInjectionScanner.js` (NEW): heuristic scan — instruction override, exfiltration, role delimiters, imperative-to-system, zero-width/encoding tricks. Labeled heuristic-pattern-scan-v1, not a proof.
- `runtime/teaching/IndependentExaminer.js` (NEW): scripted held-out judge for 3 candidate types. Substance check added after testing (empty candidate scored 100 → now 50, below bar). Blind items from Steve's held-out + automatic negation/hedge/paraphrase/distractor transforms + Steve's non-matches + 14-item regression set. Deterministic.
- `runtime/teaching/TeachingIntakeStore.js` (NEW): candidates, flyer log (cap 500, 30-day archive, grouped counts), quarantine, versioned promotions with BOTH stamps, one-step rollback with backups, audits.
- `runtime/teaching/TeachingAudits.js` (NEW): random re-examination of past approvals (examiner re-run vs original score + live-rule fire check).
- `runtime/pipeline/ResponsePipeline.js`: frequent-flyer capture hook after detectAxes — injection scan BEFORE pool entry; quarantined on flags; try/catch, never breaks pipeline.

Plugin (continuity-interface/):
- `TeachingIntakeBridge.js` (NEW): absolute-path backend loading, intake API.
- `TeachingIntakeUI.js` (NEW): UI mixin — bindTeachingIntakeUI + 4 renderers.
- `main.js`: onload wires bridge + UI mixin; 5 tabs (intake, review-queue, frequent-flyers, versions, audits) replace old 7; call sites remapped; new panels; bindTeachingIntakeUI called from bindAutoTeachingFunctionalUI.
- `styles.css`: intake component styles.
- FIXED PRE-EXISTING BUG: top-level `require("./AtlasChatGovernanceBridge.js")` killed the entire plugin under Obsidian's eval loader. Moved to lazy absolute-path load in onload() with null-guards at call sites.

### Verification (all green)
- Node: examiner (92→100 on good candidate, 50 on empty), store CRUD, scanner flags, pipeline capture, full lifecycle create→examine→approve→promote(v1,v2)→rollback(v1) with live rule fire checks, audit runner, below-bar override path.
- Registry restored byte-identical (md5 9d3646adcbe78b1b8a07ca4eedc65afa) after test cycle; test store/pairs/backups removed.
- Headless real Obsidian 1.13.7 (xvfb, CDP): plugin loads (bridge+mixin attached), all 5 tabs render with 0 old tabs, view opens, tab switching works, review queue shows staged candidate card, all 3 intake forms present, E2E stage→examine(100)→approve inside Obsidian.

### Delivery
- Zip: ~/workspace/your_files/<unique-name>.zip (one complete zip, unique outer folder, zero file surgery for Steve).
