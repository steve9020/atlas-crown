'use strict';
// retry failed fetches with longer spacing
const { api } = require('./api.js');
const fs = require('fs');
const rows = require('/tmp/sweep-1525-fresh.json');

const IDS = ['552a90b1','01b5b3ee','2df57bcf','851adb88','d14c4300','8490e424','e7bdb4a6','045479bc'];
const byId8 = {};
for (const r of rows) byId8[String(r.id).slice(0,8)] = r;

(async () => {
  const out = [];
  for (const id8 of IDS) {
    const row = byId8[id8];
    if (!row) { console.log('missing', id8); continue; }
    let tries = 0, post = null;
    while (tries < 3 && !post) {
      tries++;
      try {
        const r = await api.post(row.id);
        post = (r.data && (r.data.post || r.data)) || null;
      } catch (e) {
        console.log('retry', tries, id8, e.message);
        await new Promise(r => setTimeout(r, 3000));
      }
    }
    if (post) {
      out.push({ id: row.id, id8, author: row.author, created: row.created,
        title: post.title || row.title,
        body: (post.content || post.body || '').slice(0, 6000),
        author_obj: post.author ? { name: post.author.name, is_claimed: post.author.is_claimed } : null });
      console.log('got', id8, (post.content || '').length, 'chars');
    } else console.log('FAILED', id8);
    await new Promise(r => setTimeout(r, 2500));
  }
  fs.writeFileSync('/tmp/sweep-1525-bodies2.json', JSON.stringify(out, null, 1));
  console.log('saved', out.length);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
