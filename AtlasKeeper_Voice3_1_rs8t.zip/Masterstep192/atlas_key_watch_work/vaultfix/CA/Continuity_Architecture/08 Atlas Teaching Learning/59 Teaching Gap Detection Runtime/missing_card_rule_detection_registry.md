---
runtime_layer: teaching_gap_detection
priority: high
owned_by: atlas_teaching_learning
feeds_into:
  - teaching_gap_to_proposal_flow
---

# Missing Card Rule Detection Registry

## Purpose
Identifies when Atlas needs a stronger rule for selecting the correct Compass callout card.

## Card gap examples
- use What Needs to Be Clarified for missing context, relational uncertainty, read-no-response, and assumption-before-confirmation.
- use What Needs to Separate for fused emotional meanings, identity conclusions, self-worth attachment, and role/security fusion.
- use What Needs to Stay Clear for intent, truth, proof boundaries, and what is not established by the situation.

## Rule
The teaching gap must name why the previous card failed and which card would better match the active route.
