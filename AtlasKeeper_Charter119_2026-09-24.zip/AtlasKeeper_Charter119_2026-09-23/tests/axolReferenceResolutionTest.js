const assert = require('assert');
const { detectAxes } = require('../Cognition/engine/AxisEngine');

const cases = [
  { text: 'Marcus said he intended to leave.', axis: 'intention', actor: 'marcus' },
  { text: 'Jennifer said she expected an answer.', axis: 'expectation', actor: 'jennifer' },
  { text: 'Marcus made the choice, and he accepted the consequence.', axis: 'acceptance_rejection', actor: 'marcus' },
  { text: 'Jennifer owns the mistake, but she does not accept the blame.', axis: 'acceptance_rejection', actor: 'jennifer', state: 'negated' },
  { text: 'Marcus told Jennifer that she had the choice.', axis: 'choice', actor: 'jennifer' },
  { text: 'Jennifer told Marcus that he was responsible.', axis: 'responsibility', actor: 'marcus' },
  { text: 'Marcus expected Jennifer to decide, but she refused the choice.', axis: 'choice', actor: 'jennifer' },
  { text: 'Jennifer trusted Marcus, and he respected her boundary.', axis: 'respect', actor: 'marcus' },
];

function attrs(result, axis) {
  const row = result.axis_evidence.find(x => x.axis === axis);
  return row ? row.attributions : [];
}
let passed=0;
for (const c of cases) {
  const r=detectAxes(c.text);
  const a=attrs(r,c.axis);
  const ok=a.some(x => x.actor===c.actor && (!c.state || x.state===c.state));
  if (ok) passed++;
  else console.error('MISS', c, a, r.axes);
}
console.log(`AXOL reference resolution: ${passed}/${cases.length}`);
assert.strictEqual(passed,cases.length);
