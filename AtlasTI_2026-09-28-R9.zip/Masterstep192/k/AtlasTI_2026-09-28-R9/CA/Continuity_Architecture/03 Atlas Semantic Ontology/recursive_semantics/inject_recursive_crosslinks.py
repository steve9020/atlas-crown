from pathlib import Path

folder = Path.cwd()

crosslinks = """

## Related Activations
- pressure_semantics/recursive_loop_pressure
- escalation_semantics/recursive_escalation
- contradiction_semantics/recursive_contradiction

## Destabilization Links
- destabilization_semantics/recursive_destabilization
- fragmentation_semantics/recursive_fragmentation

## Stabilization Interruptions
- stabilization_semantics/recursive_interrupt_stabilization
- regulation_semantics/recursive_regulation

## Threshold Monitoring
- threshold_semantics/recursive_thresholds
- threshold_semantics/overload_thresholds

## Recovery Routes
- recovery_semantics/post_escalation_recovery
- reintegration_semantics/post_fragmentation_reintegration

## Adaptive Reroutes
- adaptive_semantics/adaptive_recursive
- adaptive_semantics/adaptive_flexibility

## Continuity Preservation Links
- continuity_semantics/recursive_continuity
- preservation_semantics/recursive_preservation
"""

for file in folder.glob("*.md"):
    content = file.read_text(encoding="utf-8")

    if "## Related Activations" in content:
        continue

    content += crosslinks

    file.write_text(content, encoding="utf-8")

print("Recursive semantic crosslinks injected.")