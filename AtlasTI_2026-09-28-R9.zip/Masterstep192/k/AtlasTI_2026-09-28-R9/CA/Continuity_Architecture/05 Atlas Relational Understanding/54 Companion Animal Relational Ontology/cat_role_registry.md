# Cat Role Registry

## Roles
- cat
- kitty
- kitten

## Emotional Weight
Very high.

## Common Meaning Pressure
- comfort
- emotional safety
- attachment
- companionship
- grief
- calmness
- continuity

## Runtime Rule
Cat-related distress should not be treated as minor or disposable attachment.
