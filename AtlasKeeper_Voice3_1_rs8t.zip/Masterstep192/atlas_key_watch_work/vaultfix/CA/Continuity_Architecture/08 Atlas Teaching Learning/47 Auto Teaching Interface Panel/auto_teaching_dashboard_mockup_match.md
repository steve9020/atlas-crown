# Auto Teaching Dashboard Mockup Match

## Purpose
This node records the implementation direction for matching the generated Auto Teaching dashboard reference.

## Required Visual Identity
- dark navy/charcoal dashboard shell
- left navigation rail
- active Auto Teaching row with book icon
- top system-status bar
- right engine controls panel
- central Auto Teaching title with large book logo
- metric cards
- overview tabs
- engine status card
- recent activity card
- category coverage donut/card
- teaching plan card
- smart rotation card
- rules-at-a-glance row

## Icon Requirement
Auto Teaching must use a book icon in:
- navigation item
- main page title area

## Debug Requirement
Console should suppress alias/report clutter and only show true runtime issues.
