'use strict';
const assert=require('assert');
const {detectAxes}=require('../Cognition/engine/AxisEngine.js');
// Natural paraphrases deliberately absent from the original multilingual cue registry.
const cases=[
['es','Pensaba ayudar desde el principio.','intention'],['es','Dependía de que él llegara.','expectation'],['es','Me corresponde responder por esto.','responsibility'],
['fr','Mon projet était de l’aider.','intention'],['fr','Je pensais qu’il viendrait.','expectation'],['fr','Je dois répondre de ce résultat.','responsibility'],
['de','Mein Plan war, ihm zu helfen.','intention'],['de','Ich ging davon aus, dass er kommt.','expectation'],['de','Dafür trage ich die Verantwortung.','responsibility'],
['pt','Meu plano era ajudar.','intention'],['pt','Eu achava que ele viria.','expectation'],['pt','Cabe a mim responder por isso.','responsibility'],
['it','Il mio piano era aiutarlo.','intention'],['it','Pensavo che sarebbe venuto.','expectation'],['it','Me ne assumo la responsabilità.','responsibility'],
['nl','Mijn plan was om te helpen.','intention'],['nl','Ik ging ervan uit dat hij zou komen.','expectation'],['nl','Ik draag hiervoor de verantwoordelijkheid.','responsibility'],
['pl','Miałem plan, żeby pomóc.','intention'],['pl','Zakładałem, że przyjdzie.','expectation'],['pl','Biorę za to odpowiedzialność.','responsibility'],
['tr','Planım yardım etmekti.','intention'],['tr','Onun geleceğini varsaydım.','expectation'],['tr','Bunun sorumluluğunu üstleniyorum.','responsibility'],
['ru','Я планировал помочь.','intention'],['ru','Я рассчитывал, что он придёт.','expectation'],['ru','Я беру за это ответственность.','responsibility'],
['ar','كانت خطتي أن أساعد.','intention'],['ar','كنت أتوقع أن يأتي.','expectation'],['ar','أتحمل مسؤولية ذلك.','responsibility'],
['hi','मेरी योजना मदद करने की थी।','intention'],['hi','मुझे उम्मीद थी कि वह आएगा।','expectation'],['hi','मैं इसकी जिम्मेदारी लेता हूँ।','responsibility'],
['ja','助けるつもりだった。','intention'],['ja','彼が来ると思っていた。','expectation'],['ja','その責任は私が負う。','responsibility'],
['ko','도울 생각이었다.','intention'],['ko','그가 올 거라고 생각했다.','expectation'],['ko','그 책임은 내가 진다.','responsibility'],
['zh','我本来打算帮忙。','intention'],['zh','我原以为他会来。','expectation'],['zh','这件事由我负责。','responsibility']
];
let passed=0; const misses=[];
for(const [lang,text,axis] of cases){ const r=detectAxes(text); if(r.axes.includes(axis)) passed++; else misses.push({lang,text,axis,axes:r.axes}); }
console.log(JSON.stringify({total:cases.length,passed,failed:misses.length,misses},null,2));
if(misses.length) process.exitCode=1;
