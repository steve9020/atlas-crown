# Atlas Path Lock

Status: locked in plugin startup.

Correct Obsidian vault folder:

```text
<packageRoot>/CA/Continuity_Architecture
```

Correct Atlas package root:

```text
<packageRoot>
```

Required package-root siblings:

```text
CA
Cognition
runtime
tests
```

The plugin now checks this shape before loading. If Obsidian is opened at the wrong level, the plugin blocks itself instead of inferring a false project root or creating stray path/cache state.

Plain rule: open `CA → Continuity_Architecture` in Obsidian, but let Atlas resolve the wider package root as the folder two levels above that vault.
