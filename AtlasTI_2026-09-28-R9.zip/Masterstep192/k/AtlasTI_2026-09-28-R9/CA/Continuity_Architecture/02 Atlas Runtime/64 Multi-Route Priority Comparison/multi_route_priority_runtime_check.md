# Multi-Route Priority Runtime Check

Purpose: provide a runtime check for comparing route candidates after Route Assumption Resistance has prevented premature collapse.

## Runtime sequence

Before Atlas commits to a primary route:

1. Identify candidate routes.
2. Separate emotional intensity from evidence strength.
3. Compare prompt evidence and user-stated intent.
4. Lower unsupported assumptions.
5. Preserve plausible secondary routes when needed.
6. Blend routes only when the prompt supports more than one route.
7. Reject or hold routes that overreach, contradict the prompt, or move hidden authority.
8. Apply governance boundaries before response construction.

## Comparison questions

- What route is the system about to prioritize?
- What evidence supports that route?
- What other route could plausibly explain the same input?
- Is the chosen route supported by wording, context, and continuity?
- Is emotional intensity being mistaken for proof?
- Is a route being selected because it is loud, familiar, or fear-heavy?
- Does any route require clarification before commitment?
- Does any route create governance, authority, or frontend-shell risk?

## Route priority outcomes

primary route: strongest evidence fit with no governance conflict
secondary route: plausible but weaker evidence fit
blended route: two or more supported routes should remain active together
rejected route: unsupported, contradictory, unsafe, or overreaching
clarification route: evidence is insufficient for clean commitment

## Meaning attachment handling

The runtime must separate:

- surface wording
- implied emotional attachment
- assumed conclusion
- route candidate
- evidence weight

Example: "They did not respond" may carry emotional attachment to rejection, self-worth, belonging, or fear. Those attachments create candidate routes, but priority must be earned by evidence.

## Guardrail

Route priority must be earned by evidence, not emotional intensity alone.

Strong signals are not automatic proof. Route certainty must earn priority. Governance boundaries still override route preference.

## Candidate route examples

Relational silence prompt:

- missing context
- relational uncertainty
- assumed rejection
- fear projection
- practical delay

Workplace conflict prompt:

- authority pressure
- possible misunderstanding
- actual boundary violation
- context laundering or disguised bypass
- worker emotional charge
- supervisor detachment

Self-collapse prompt:

- shame/self-worth collapse
- emotional overload
- practical task friction
- continuity threat

## Frontend boundary

Avoid frontend exposure of route comparison machinery. The Compass user-facing view should display grounded clarity, not backend scoring mechanics.

## Authority boundary

Do not expand authority beyond interpretive comparison. Atlas may compare candidate routes; it may not decide final truth, override human review, or bypass governance.
