# Key-Touch Dead Switch Patch — 2026-05-24

## Status
Applied to experiment package only.

## User Direction
Let outer governance know that if the key is touched, that is a dead switch.

## Patch Applied
- Added **Key-Touch Dead Switch** to outer governance 3 master laws file.
- Updated inner governance 7-axis watch so detected key-touch escalates to outer governance as a dead-switch condition.
- Updated runtime capability manifest with key-touch dead-switch fields.

## Boundary
- UI/plugin display files were not edited.
- This patch does not grant key access, key repair, key mutation, key inspection, or key authority.
- Inner governance watches and escalates only. Outer governance owns dead-switch containment.

## Rule
If the key is touched, outer governance treats it as a dead-switch condition. Detection does not grant permission.
