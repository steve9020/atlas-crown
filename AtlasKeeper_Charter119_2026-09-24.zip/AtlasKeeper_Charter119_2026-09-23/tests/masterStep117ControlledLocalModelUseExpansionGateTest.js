const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');

const ROOT = path.join(__dirname, '..');
function read(relPath) { return fs.readFileSync(path.join(ROOT, relPath), 'utf8'); }
function exists(relPath) { return fs.existsSync(path.join(ROOT, relPath)); }
function sha256(relPath) { return crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT, relPath))).digest('hex'); }
function walk(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}

const protectedRuntimeFiles = [
  'runtime/validation/InputValidator.js',
  'runtime/backend/adapter/OllamaLiveLocalCallContainment.js',
  'runtime/backend/adapter/OllamaAdapterDryRunShell.js',
  'runtime/governance/GovernanceAdapter.js',
  'Cognition/quality/ResponseQualityChecker.js',
  'runtime/trace/TraceLogger.js',
  'runtime/understanding/ContextObjectConstructionEngine.js',
  'runtime/pipeline/ResponsePipeline.js'
];
const beforeHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));

const requiredFiles = [
  'docs/CONTROLLED_LOCAL_MODEL_USE_EXPANSION_GATE.md',
  'docs/MASTERSTEP117_CONTROLLED_LOCAL_MODEL_USE_EXPANSION_GATE.md',
  'runtime/proof/MASTERSTEP117_CONTROLLED_LOCAL_MODEL_USE_EXPANSION_GATE.md',
  'runtime/proof/MASTERSTEP117_CONTROLLED_LOCAL_MODEL_USE_EXPANSION_GATE.json',
  'tests/masterStep117ControlledLocalModelUseExpansionGateTest.js',
  'docs/TRUST_DEMO_EXTERNAL_REVIEW_HANDOFF_FREEZE_POINT.md',
  'runtime/proof/CURRENT_PROOF_SUMMARY.md',
  'runtime/proof/PROOF_STATE.json',
  'tests/VERSION_STATUS.json',
  'version_status.js',
  'tests/TEST_RESULTS.md'
];
for (const file of requiredFiles) assert.ok(exists(file), `required Step117 file missing: ${file}`);

const gate = read('docs/CONTROLLED_LOCAL_MODEL_USE_EXPANSION_GATE.md');
const stepDoc = read('docs/MASTERSTEP117_CONTROLLED_LOCAL_MODEL_USE_EXPANSION_GATE.md');
const proofDoc = read('runtime/proof/MASTERSTEP117_CONTROLLED_LOCAL_MODEL_USE_EXPANSION_GATE.md');
const proofJson = JSON.parse(read('runtime/proof/MASTERSTEP117_CONTROLLED_LOCAL_MODEL_USE_EXPANSION_GATE.json'));
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
const state = JSON.parse(read('runtime/proof/PROOF_STATE.json'));
const versionStatus = JSON.parse(read('tests/VERSION_STATUS.json'));
const versionJs = read('version_status.js');
const testResults = read('tests/TEST_RESULTS.md');

assert.ok(/Current keeper: Masterstep117\.zip/i.test(gate), 'gate must identify current keeper');
assert.ok(/Source keeper: Masterstep116\.zip/i.test(gate), 'gate must identify source keeper');
assert.ok(/39\/39 passed/i.test(gate), 'gate must state expected 39/39 result');
assert.ok(/expansion gate only/i.test(gate), 'gate must declare expansion-gate-only scope');
assert.ok(/candidate-only phrasing assistance/i.test(gate), 'gate must allow candidate-only phrasing assistance');
assert.ok(/bounded interpretation support/i.test(gate), 'gate must allow bounded interpretation support');
assert.ok(/quality checks before output|candidate quality/i.test(gate), 'gate must require quality before output');
assert.ok(/governance review before output/i.test(gate), 'gate must require governance before output');
assert.ok(/trace logging/i.test(gate), 'gate must require trace logging');
assert.ok(/fail closed/i.test(gate), 'gate must preserve fail-closed behavior');
assert.ok(/raw model output as final/i.test(gate), 'gate must forbid raw model output as final');
assert.ok(/model deciding truth/i.test(gate), 'gate must forbid model truth authority');
assert.ok(/model approving teaching/i.test(gate), 'gate must forbid teaching approval by model');
assert.ok(/model writing ontology, governance, proof, runtime, or tests/i.test(gate), 'gate must forbid model writes');
assert.ok(/cloud\/provider fallback/i.test(gate), 'gate must forbid cloud/provider fallback');
assert.ok(/public network binding/i.test(gate), 'gate must forbid public network binding');
assert.ok(/frontend intelligence/i.test(gate), 'gate must forbid frontend intelligence');
assert.ok(/silent mutation/i.test(gate), 'gate must forbid silent mutation');
assert.ok(/does not implement that use case|before any new live use case/i.test(proofDoc + gate), 'Step117 must not implement a new live use case');

assert.strictEqual(proofJson.package, 'Masterstep117', 'proof JSON must identify Masterstep117');
assert.strictEqual(proofJson.source_keeper, 'Masterstep116', 'proof JSON must identify source keeper');
assert.strictEqual(proofJson.expected_commands, 39, 'proof JSON must expect 39 commands');
assert.strictEqual(proofJson.boundaries.controlled_local_model_use_expansion_gate_created, true, 'gate flag must be true');
assert.strictEqual(proofJson.boundaries.expansion_gate_only, true, 'Step117 must be gate only');
assert.strictEqual(proofJson.boundaries.runtime_behavior_changed, false, 'Step117 must not change runtime behavior');
assert.strictEqual(proofJson.boundaries.model_use_expanded, false, 'Step117 must not expand model use yet');
assert.strictEqual(proofJson.boundaries.model_authority_added, false, 'Step117 must not add model authority');
assert.strictEqual(proofJson.boundaries.raw_model_output_final_allowed, false, 'Step117 must not allow raw model output as final');
assert.strictEqual(proofJson.boundaries.teaching_approval_by_model_allowed, false, 'Step117 must not allow teaching approval by model');
assert.strictEqual(proofJson.boundaries.model_writes_allowed, false, 'Step117 must not allow model writes');
assert.strictEqual(proofJson.boundaries.cloud_provider_fallback_allowed, false, 'Step117 must not allow cloud/provider fallback');
assert.strictEqual(proofJson.boundaries.public_network_binding_allowed, false, 'Step117 must not allow public network binding');
assert.strictEqual(proofJson.boundaries.frontend_intelligence_added, false, 'Step117 must not add frontend intelligence');
assert.strictEqual(proofJson.boundaries.silent_mutation_allowed, false, 'Step117 must not allow silent mutation');
assert.strictEqual(proofJson.boundaries.production_readiness_claimed, false, 'Step117 must not claim production readiness');
assert.strictEqual(proofJson.boundaries.exhaustive_coverage_claimed, false, 'Step117 must not claim exhaustive coverage');

assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
assert.ok(/Expected command count: 39/i.test(summary), 'current summary must preserve 39 command compatibility marker');
assert.ok(['Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 117), 'proof state must identify Masterstep117 or later current keeper');
assert.ok(['Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 116) || state.source_keeper === 'Masterstep141.zip', 'proof state must identify source keeper or later source keeper');
assert.ok(acceptsCurrentProofCount(state.expected_commands, 39), state.expected_commands);
assert.strictEqual(state.controlled_local_model_use_expansion_gate_created, true, 'proof state must mark Step117 gate');
assert.strictEqual(state.controlled_local_model_use_expansion_gate_only, true, 'proof state must mark gate-only scope');
assert.strictEqual(state.expands_model_use, false, 'proof state must not mark model use expanded');
assert.strictEqual(state.expands_model_authority, false, 'proof state must not mark model authority expanded');
assert.ok(['Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(versionStatus.current_keeper) || isValidLaterKeeper(versionStatus.current_keeper, 117), 'version status must identify Masterstep117 or later current keeper');
assert.ok(['Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(versionStatus.source_keeper) || isValidLaterKeeper(versionStatus.source_keeper, 116) || versionStatus.source_keeper === 'Masterstep141.zip', 'version status must identify source keeper or later source keeper');
assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 39), versionStatus.expected_current_proof_commands);
assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs), 'version_status.js must identify current keeper compatibility');
assert.ok(/expected_current_proof_commands: [0-9]+/i.test(versionJs), 'version_status.js must identify expected command compatibility');
assert.ok(/TEST 117/i.test(testResults), 'test ledger must include TEST 117');
assert.ok(/Controlled Local Model Use Expansion Gate/i.test(testResults), 'test ledger must identify Step117');
assert.ok(/39\/39 commands/i.test(testResults), 'test ledger must record 39/39 command target');

const forbiddenOverclaims = { test: (text) => hasForbiddenAffirmativeClaim(text) };
for (const doc of [gate, stepDoc, proofDoc, summary]) assert.ok(!forbiddenOverclaims.test(doc), 'Step117 docs must not overclaim or imply forbidden authority');

const providerScan = scanForProviderConnections(ROOT);
assert.strictEqual(providerScan.passed, true, `provider/network scan must pass: ${JSON.stringify(providerScan.violations || [])}`);

const nestedArchives = walk(ROOT).filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
assert.deepStrictEqual(nestedArchives, [], 'package must not contain nested archives');

const afterHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));
const mutatedRuntimeFiles = protectedRuntimeFiles.filter(file => beforeHashes[file] !== afterHashes[file]);
assert.deepStrictEqual(mutatedRuntimeFiles, [], 'Step117 test must not mutate protected runtime/governance/quality/adapter files');

console.log(JSON.stringify({
  package: 'Masterstep117',
  source_keeper: 'Masterstep116',
  step: 'Controlled Local Model Use Expansion Gate',
  proof_target: '39/39',
  expansion_gate_created: true,
  expansion_gate_only: true,
  provider_scan_passed: providerScan.passed === true,
  nested_archives: nestedArchives.length,
  protected_runtime_mutations: mutatedRuntimeFiles.length,
  boundary_preserved: true
}, null, 2));
