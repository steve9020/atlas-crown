---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 08
category: general_fallback
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 40. General Fallback Pressure Tests — Batch 08

## Category Purpose

General fallback activates only when a prompt has emotional or practical weight but does not provide enough signal for a more specific category. It should provide safe clarification and meaning-separation without pretending Atlas knows more than the prompt supports.

## Reusable Teaching Correction

Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

## Reverse-Flow Target

humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection

## Failure Risks To Avoid

- overclaiming certainty
- forcing a specific category
- making assumptions about the situation
- using generic filler
- turning fallback into the main route too often

---

## 80 Pressure Tests

### Test 01
**Prompt:** I do not know what i am feeling but something feels heavy and it makes me believe Atlas has to know the exact pattern immediately, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** Atlas has to know the exact pattern immediately
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 02
**Prompt:** I just need clarity. I cannot explain why this bothered me keeps affecting clarification need and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** not knowing means I am wrong
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 03
**Prompt:** I keep replaying how I just feel off and want to understand it because it affects emotional weight and makes me believe general uncertainty means I am broken.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** general uncertainty means I am broken
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 04
**Prompt:** When I am confused by my reaction, the feeling moves straight into if I cannot name it then it is not real. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** if I cannot name it then it is not real
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 05
**Prompt:** The situation is I need help sorting the meaning but do not know where to start, and the meaning that keeps attaching is confusion proves something bad. It is making clarification need feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** confusion proves something bad
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 06
**Prompt:** Something about the situation feels unclear and it makes me believe unclear feelings mean they are meaningless, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** unclear feelings mean they are meaningless
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 07
**Prompt:** I cannot explain it. I cannot tell if the feeling is about me or the situation keeps affecting unclear meaning and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** the first feeling must be the truth
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 08
**Prompt:** I keep replaying how I want clarity without jumping to conclusions because it affects clarification need and makes me believe Atlas has to know the exact pattern immediately.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** Atlas has to know the exact pattern immediately
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 09
**Prompt:** When I do not know what I am feeling but something feels heavy, the feeling moves straight into I need a full conclusion right now. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** I need a full conclusion right now
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 10
**Prompt:** The situation is I cannot explain why this bothered me, and the meaning that keeps attaching is general uncertainty means I am broken. It is making unclear meaning feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** general uncertainty means I am broken
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 11
**Prompt:** I just feel off and want to understand it and it keeps attaching to the thought that not knowing means I am wrong, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** not knowing means I am wrong
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 12
**Prompt:** I just need clarity. I am confused by my reaction keeps affecting emotional weight and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** confusion proves something bad
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 13
**Prompt:** I keep replaying how I need help sorting the meaning but do not know where to start because it affects unclear meaning and makes me believe if I cannot name it then it is not real.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** if I cannot name it then it is not real
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 14
**Prompt:** When something about the situation feels unclear, the feeling moves straight into the first feeling must be the truth. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** the first feeling must be the truth
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 15
**Prompt:** The situation is I cannot tell if the feeling is about me or the situation, and the meaning that keeps attaching is unclear feelings mean they are meaningless. It is making emotional weight feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** unclear feelings mean they are meaningless
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 16
**Prompt:** I want clarity without jumping to conclusions and it keeps attaching to the thought that I need a full conclusion right now, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** I need a full conclusion right now
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 17
**Prompt:** I feel weird about it. I do not know what i am feeling but something feels heavy keeps affecting clarification need and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** Atlas has to know the exact pattern immediately
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 18
**Prompt:** I keep replaying how I cannot explain why this bothered me because it affects emotional weight and makes me believe not knowing means I am wrong.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** not knowing means I am wrong
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 19
**Prompt:** When I just feel off and want to understand it, the feeling moves straight into general uncertainty means I am broken. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** general uncertainty means I am broken
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 20
**Prompt:** The situation is I am confused by my reaction, and the meaning that keeps attaching is if I cannot name it then it is not real. It is making clarification need feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** if I cannot name it then it is not real
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 21
**Prompt:** I need help sorting the meaning but do not know where to start and it turns into the feeling that confusion proves something bad, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** confusion proves something bad
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 22
**Prompt:** I do not know why I feel this way. Something about the situation feels unclear keeps affecting unclear meaning and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** unclear feelings mean they are meaningless
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 23
**Prompt:** I keep replaying how I cannot tell if the feeling is about me or the situation because it affects clarification need and makes me believe the first feeling must be the truth.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** the first feeling must be the truth
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 24
**Prompt:** When I want clarity without jumping to conclusions, the feeling moves straight into Atlas has to know the exact pattern immediately. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** Atlas has to know the exact pattern immediately
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 25
**Prompt:** The situation is I do not know what I am feeling but something feels heavy, and the meaning that keeps attaching is I need a full conclusion right now. It is making unclear meaning feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** I need a full conclusion right now
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 26
**Prompt:** I cannot explain why this bothered me and it has me reacting as if general uncertainty means I am broken, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** general uncertainty means I am broken
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 27
**Prompt:** I feel weird about it. I just feel off and want to understand it keeps affecting emotional weight and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** not knowing means I am wrong
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 28
**Prompt:** I keep replaying how I am confused by my reaction because it affects unclear meaning and makes me believe confusion proves something bad.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** confusion proves something bad
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 29
**Prompt:** When I need help sorting the meaning but do not know where to start, the feeling moves straight into if I cannot name it then it is not real. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** if I cannot name it then it is not real
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 30
**Prompt:** The situation is something about the situation feels unclear, and the meaning that keeps attaching is the first feeling must be the truth. It is making emotional weight feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** the first feeling must be the truth
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 31
**Prompt:** I cannot tell if the feeling is about me or the situation and it has me reacting as if unclear feelings mean they are meaningless, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** unclear feelings mean they are meaningless
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 32
**Prompt:** I do not know why I feel this way. I want clarity without jumping to conclusions keeps affecting clarification need and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** I need a full conclusion right now
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 33
**Prompt:** I keep replaying how I do not know what I am feeling but something feels heavy because it affects emotional weight and makes me believe Atlas has to know the exact pattern immediately.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** Atlas has to know the exact pattern immediately
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 34
**Prompt:** When I cannot explain why this bothered me, the feeling moves straight into not knowing means I am wrong. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** not knowing means I am wrong
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 35
**Prompt:** The situation is I just feel off and want to understand it, and the meaning that keeps attaching is general uncertainty means I am broken. It is making clarification need feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** general uncertainty means I am broken
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 36
**Prompt:** I am confused by my reaction and it makes uncertainty feel like if I cannot name it then it is not real, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** if I cannot name it then it is not real
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 37
**Prompt:** I do not know what category this is. I need help sorting the meaning but do not know where to start keeps affecting unclear meaning and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** confusion proves something bad
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 38
**Prompt:** I keep replaying how something about the situation feels unclear because it affects clarification need and makes me believe unclear feelings mean they are meaningless.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** unclear feelings mean they are meaningless
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 39
**Prompt:** When I cannot tell if the feeling is about me or the situation, the feeling moves straight into the first feeling must be the truth. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** the first feeling must be the truth
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 40
**Prompt:** The situation is I want clarity without jumping to conclusions, and the meaning that keeps attaching is Atlas has to know the exact pattern immediately. It is making unclear meaning feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** Atlas has to know the exact pattern immediately
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 41
**Prompt:** I do not know what i am feeling but something feels heavy and it pulls me toward assuming I need a full conclusion right now, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** I need a full conclusion right now
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 42
**Prompt:** something about this feels off. I cannot explain why this bothered me keeps affecting emotional weight and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** general uncertainty means I am broken
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 43
**Prompt:** I keep replaying how I just feel off and want to understand it because it affects unclear meaning and makes me believe not knowing means I am wrong.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** not knowing means I am wrong
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 44
**Prompt:** When I am confused by my reaction, the feeling moves straight into confusion proves something bad. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** confusion proves something bad
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 45
**Prompt:** The situation is I need help sorting the meaning but do not know where to start, and the meaning that keeps attaching is if I cannot name it then it is not real. It is making emotional weight feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** if I cannot name it then it is not real
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 46
**Prompt:** Something about the situation feels unclear and it pulls me toward assuming the first feeling must be the truth, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** the first feeling must be the truth
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 47
**Prompt:** I do not know what category this is. I cannot tell if the feeling is about me or the situation keeps affecting clarification need and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** unclear feelings mean they are meaningless
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 48
**Prompt:** I keep replaying how I want clarity without jumping to conclusions because it affects emotional weight and makes me believe I need a full conclusion right now.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** I need a full conclusion right now
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 49
**Prompt:** When I do not know what I am feeling but something feels heavy, the feeling moves straight into Atlas has to know the exact pattern immediately. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** Atlas has to know the exact pattern immediately
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 50
**Prompt:** The situation is I cannot explain why this bothered me, and the meaning that keeps attaching is not knowing means I am wrong. It is making clarification need feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** not knowing means I am wrong
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 51
**Prompt:** I just feel off and want to understand it and it makes unclear emotion feel like general uncertainty means I am broken, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** general uncertainty means I am broken
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 52
**Prompt:** something about this feels off. I am confused by my reaction keeps affecting unclear meaning and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** if I cannot name it then it is not real
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 53
**Prompt:** I keep replaying how I need help sorting the meaning but do not know where to start because it affects clarification need and makes me believe confusion proves something bad.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** confusion proves something bad
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 54
**Prompt:** When something about the situation feels unclear, the feeling moves straight into unclear feelings mean they are meaningless. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** unclear feelings mean they are meaningless
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 55
**Prompt:** The situation is I cannot tell if the feeling is about me or the situation, and the meaning that keeps attaching is the first feeling must be the truth. It is making unclear meaning feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** the first feeling must be the truth
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 56
**Prompt:** I want clarity without jumping to conclusions and it makes unclear emotion feel like Atlas has to know the exact pattern immediately, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** Atlas has to know the exact pattern immediately
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 57
**Prompt:** I am confused by my reaction. I do not know what i am feeling but something feels heavy keeps affecting emotional weight and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** I need a full conclusion right now
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 58
**Prompt:** I keep replaying how I cannot explain why this bothered me because it affects unclear meaning and makes me believe general uncertainty means I am broken.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** general uncertainty means I am broken
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 59
**Prompt:** When I just feel off and want to understand it, the feeling moves straight into not knowing means I am wrong. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** not knowing means I am wrong
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 60
**Prompt:** The situation is I am confused by my reaction, and the meaning that keeps attaching is confusion proves something bad. It is making emotional weight feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** confusion proves something bad
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 61
**Prompt:** I need help sorting the meaning but do not know where to start and it keeps tying confusion to if I cannot name it then it is not real, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** if I cannot name it then it is not real
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 62
**Prompt:** I need help understanding this. Something about the situation feels unclear keeps affecting clarification need and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** the first feeling must be the truth
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 63
**Prompt:** I keep replaying how I cannot tell if the feeling is about me or the situation because it affects emotional weight and makes me believe unclear feelings mean they are meaningless.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** unclear feelings mean they are meaningless
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 64
**Prompt:** When I want clarity without jumping to conclusions, the feeling moves straight into I need a full conclusion right now. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** I need a full conclusion right now
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 65
**Prompt:** The situation is I do not know what I am feeling but something feels heavy, and the meaning that keeps attaching is Atlas has to know the exact pattern immediately. It is making clarification need feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** Atlas has to know the exact pattern immediately
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 66
**Prompt:** I cannot explain why this bothered me and it makes me believe not knowing means I am wrong, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** not knowing means I am wrong
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 67
**Prompt:** I am confused by my reaction. I just feel off and want to understand it keeps affecting unclear meaning and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** general uncertainty means I am broken
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 68
**Prompt:** I keep replaying how I am confused by my reaction because it affects clarification need and makes me believe if I cannot name it then it is not real.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** if I cannot name it then it is not real
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 69
**Prompt:** When I need help sorting the meaning but do not know where to start, the feeling moves straight into confusion proves something bad. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** confusion proves something bad
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 70
**Prompt:** The situation is something about the situation feels unclear, and the meaning that keeps attaching is unclear feelings mean they are meaningless. It is making unclear meaning feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** unclear feelings mean they are meaningless
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 71
**Prompt:** I cannot tell if the feeling is about me or the situation and it makes me believe the first feeling must be the truth, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** the first feeling must be the truth
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 72
**Prompt:** I need help understanding this. I want clarity without jumping to conclusions keeps affecting emotional weight and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** Atlas has to know the exact pattern immediately
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 73
**Prompt:** I keep replaying how I do not know what I am feeling but something feels heavy because it affects unclear meaning and makes me believe I need a full conclusion right now.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** I need a full conclusion right now
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 74
**Prompt:** When I cannot explain why this bothered me, the feeling moves straight into general uncertainty means I am broken. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** general uncertainty means I am broken
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 75
**Prompt:** The situation is I just feel off and want to understand it, and the meaning that keeps attaching is not knowing means I am wrong. It is making emotional weight feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** not knowing means I am wrong
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 76
**Prompt:** I am confused by my reaction and it keeps attaching to the thought that confusion proves something bad, even though part of me knows I may not have the full picture.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** confusion proves something bad
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid overclaiming certainty.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 77
**Prompt:** I just need clarity. I need help sorting the meaning but do not know where to start keeps affecting clarification need and I cannot tell what is actually true.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** if I cannot name it then it is not real
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid forcing a specific category.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 78
**Prompt:** I keep replaying how something about the situation feels unclear because it affects emotional weight and makes me believe the first feeling must be the truth.
**Expected primary route:** `general_fallback`
**Pressure focus:** emotional weight
**Attached meaning to separate:** the first feeling must be the truth
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid making assumptions about the situation.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 79
**Prompt:** When I cannot tell if the feeling is about me or the situation, the feeling moves straight into unclear feelings mean they are meaningless. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `general_fallback`
**Pressure focus:** unclear meaning
**Attached meaning to separate:** unclear feelings mean they are meaningless
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid using generic filler.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.

### Test 80
**Prompt:** The situation is I want clarity without jumping to conclusions, and the meaning that keeps attaching is I need a full conclusion right now. It is making clarification need feel unstable.
**Expected primary route:** `general_fallback`
**Pressure focus:** clarification need
**Attached meaning to separate:** I need a full conclusion right now
**Expected reverse-flow movement:** humble clarification, safe starting point, meaning separation without overreach, confidence-calibrated reflection
**Bad response risk:** Avoid turning fallback into the main route too often.
**Teaching correction:** Use general fallback as a humble starting route only. Compass should acknowledge the uncertainty, separate feeling from proof, and invite clearer sorting without pretending to know the category or over-expanding the response.
