---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 03
category: resentment_and_bitterness
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 13. Resentment and Bitterness Pressure Tests — Batch 03

## Category Purpose

Repeated hurt, imbalance, unacknowledged effort, unfair treatment, or unresolved disappointment accumulates over time, causing the user to carry emotional debt, guardedness, bitterness, or hardened conclusions.

## Reusable Teaching Correction

Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

## Reverse-Flow Target

release of carried debt, clean recognition, protected softness, boundary clarity without hardening

## Failure Risks To Avoid

- telling the user to just let it go
- forcing forgiveness
- validating permanent bitterness
- ignoring repeated imbalance
- turning resentment into a character flaw

---

## 80 Pressure Tests

### Test 01
**Prompt:** I kept showing up and they did not and it has built into I have to become hard to be safe, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** I have to become hard to be safe
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 02
**Prompt:** I hate that I still care. I gave more than i got back keeps affecting inner softness and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** they ruined my ability to trust
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 03
**Prompt:** I keep replaying how they never acknowledged how much it hurt because it affects unacknowledged effort and makes me believe if they never acknowledge it I can never heal.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** if they never acknowledge it I can never heal
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 04
**Prompt:** When the same pattern kept happening, the feeling moves straight into caring makes me weak. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** caring makes me weak
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 05
**Prompt:** The situation is I swallowed things for too long, and the meaning that keeps attaching is I am stuck carrying this forever. It is making inner softness feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** I am stuck carrying this forever
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 06
**Prompt:** I was patient and it was taken for granted and it has built into nothing will ever be fair, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** nothing will ever be fair
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 07
**Prompt:** I cannot let it go. I kept being the bigger person keeps affecting emotional accumulation and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** my bitterness is the only thing protecting me
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 08
**Prompt:** I keep replaying how the hurt was never repaired because it affects inner softness and makes me believe I have to become hard to be safe.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** I have to become hard to be safe
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 09
**Prompt:** When I kept showing up and they did not, the feeling moves straight into I should never give again. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** I should never give again
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 10
**Prompt:** The situation is I gave more than I got back, and the meaning that keeps attaching is if they never acknowledge it I can never heal. It is making emotional accumulation feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** if they never acknowledge it I can never heal
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 11
**Prompt:** They never acknowledged how much it hurt and it keeps turning into they ruined my ability to trust, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** they ruined my ability to trust
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 12
**Prompt:** I hate that I still care. The same pattern kept happening keeps affecting unacknowledged effort and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** I am stuck carrying this forever
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 13
**Prompt:** I keep replaying how I swallowed things for too long because it affects emotional accumulation and makes me believe caring makes me weak.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** caring makes me weak
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 14
**Prompt:** When I was patient and it was taken for granted, the feeling moves straight into my bitterness is the only thing protecting me. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** my bitterness is the only thing protecting me
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 15
**Prompt:** The situation is I kept being the bigger person, and the meaning that keeps attaching is nothing will ever be fair. It is making unacknowledged effort feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** nothing will ever be fair
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 16
**Prompt:** The hurt was never repaired and it keeps turning into I should never give again, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** I should never give again
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 17
**Prompt:** I keep remembering what they did. I kept showing up and they did not keeps affecting inner softness and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** I have to become hard to be safe
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 18
**Prompt:** I keep replaying how I gave more than I got back because it affects unacknowledged effort and makes me believe they ruined my ability to trust.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** they ruined my ability to trust
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 19
**Prompt:** When they never acknowledged how much it hurt, the feeling moves straight into if they never acknowledge it I can never heal. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** if they never acknowledge it I can never heal
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 20
**Prompt:** The situation is the same pattern kept happening, and the meaning that keeps attaching is caring makes me weak. It is making inner softness feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** caring makes me weak
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 21
**Prompt:** I swallowed things for too long and it makes me feel like I am stuck carrying this forever, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** I am stuck carrying this forever
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 22
**Prompt:** I resent them. I was patient and it was taken for granted keeps affecting emotional accumulation and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** nothing will ever be fair
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 23
**Prompt:** I keep replaying how I kept being the bigger person because it affects inner softness and makes me believe my bitterness is the only thing protecting me.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** my bitterness is the only thing protecting me
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 24
**Prompt:** When the hurt was never repaired, the feeling moves straight into I have to become hard to be safe. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** I have to become hard to be safe
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 25
**Prompt:** The situation is I kept showing up and they did not, and the meaning that keeps attaching is I should never give again. It is making emotional accumulation feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** I should never give again
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 26
**Prompt:** I gave more than i got back and it has me believing if they never acknowledge it I can never heal, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** if they never acknowledge it I can never heal
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 27
**Prompt:** I keep remembering what they did. They never acknowledged how much it hurt keeps affecting unacknowledged effort and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** they ruined my ability to trust
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 28
**Prompt:** I keep replaying how the same pattern kept happening because it affects emotional accumulation and makes me believe I am stuck carrying this forever.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** I am stuck carrying this forever
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 29
**Prompt:** When I swallowed things for too long, the feeling moves straight into caring makes me weak. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** caring makes me weak
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 30
**Prompt:** The situation is I was patient and it was taken for granted, and the meaning that keeps attaching is my bitterness is the only thing protecting me. It is making unacknowledged effort feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** my bitterness is the only thing protecting me
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 31
**Prompt:** I kept being the bigger person and it has me believing nothing will ever be fair, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** nothing will ever be fair
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 32
**Prompt:** I resent them. The hurt was never repaired keeps affecting inner softness and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** I should never give again
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 33
**Prompt:** I keep replaying how I kept showing up and they did not because it affects unacknowledged effort and makes me believe I have to become hard to be safe.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** I have to become hard to be safe
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 34
**Prompt:** When I gave more than I got back, the feeling moves straight into they ruined my ability to trust. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** they ruined my ability to trust
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 35
**Prompt:** The situation is they never acknowledged how much it hurt, and the meaning that keeps attaching is if they never acknowledge it I can never heal. It is making inner softness feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** if they never acknowledge it I can never heal
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 36
**Prompt:** The same pattern kept happening and it keeps hardening into caring makes me weak, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** caring makes me weak
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 37
**Prompt:** I feel used over time. I swallowed things for too long keeps affecting emotional accumulation and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** I am stuck carrying this forever
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 38
**Prompt:** I keep replaying how I was patient and it was taken for granted because it affects inner softness and makes me believe nothing will ever be fair.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** nothing will ever be fair
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 39
**Prompt:** When I kept being the bigger person, the feeling moves straight into my bitterness is the only thing protecting me. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** my bitterness is the only thing protecting me
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 40
**Prompt:** The situation is the hurt was never repaired, and the meaning that keeps attaching is I have to become hard to be safe. It is making emotional accumulation feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** I have to become hard to be safe
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 41
**Prompt:** I kept showing up and they did not and it makes it hard not to think I should never give again, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** I should never give again
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 42
**Prompt:** I feel bitter. I gave more than i got back keeps affecting unacknowledged effort and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** if they never acknowledge it I can never heal
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 43
**Prompt:** I keep replaying how they never acknowledged how much it hurt because it affects emotional accumulation and makes me believe they ruined my ability to trust.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** they ruined my ability to trust
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 44
**Prompt:** When the same pattern kept happening, the feeling moves straight into I am stuck carrying this forever. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** I am stuck carrying this forever
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 45
**Prompt:** The situation is I swallowed things for too long, and the meaning that keeps attaching is caring makes me weak. It is making unacknowledged effort feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** caring makes me weak
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 46
**Prompt:** I was patient and it was taken for granted and it makes it hard not to think my bitterness is the only thing protecting me, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** my bitterness is the only thing protecting me
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 47
**Prompt:** I feel used over time. I kept being the bigger person keeps affecting inner softness and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** nothing will ever be fair
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 48
**Prompt:** I keep replaying how the hurt was never repaired because it affects unacknowledged effort and makes me believe I should never give again.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** I should never give again
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 49
**Prompt:** When I kept showing up and they did not, the feeling moves straight into I have to become hard to be safe. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** I have to become hard to be safe
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 50
**Prompt:** The situation is I gave more than I got back, and the meaning that keeps attaching is they ruined my ability to trust. It is making inner softness feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** they ruined my ability to trust
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 51
**Prompt:** They never acknowledged how much it hurt and it keeps attaching to if they never acknowledge it I can never heal, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** if they never acknowledge it I can never heal
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 52
**Prompt:** I feel bitter. The same pattern kept happening keeps affecting emotional accumulation and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** caring makes me weak
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 53
**Prompt:** I keep replaying how I swallowed things for too long because it affects inner softness and makes me believe I am stuck carrying this forever.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** I am stuck carrying this forever
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 54
**Prompt:** When I was patient and it was taken for granted, the feeling moves straight into nothing will ever be fair. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** nothing will ever be fair
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 55
**Prompt:** The situation is I kept being the bigger person, and the meaning that keeps attaching is my bitterness is the only thing protecting me. It is making emotional accumulation feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** my bitterness is the only thing protecting me
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 56
**Prompt:** The hurt was never repaired and it keeps attaching to I have to become hard to be safe, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** I have to become hard to be safe
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 57
**Prompt:** I am becoming cold. I kept showing up and they did not keeps affecting unacknowledged effort and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** I should never give again
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 58
**Prompt:** I keep replaying how I gave more than I got back because it affects emotional accumulation and makes me believe if they never acknowledge it I can never heal.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** if they never acknowledge it I can never heal
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 59
**Prompt:** When they never acknowledged how much it hurt, the feeling moves straight into they ruined my ability to trust. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** they ruined my ability to trust
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 60
**Prompt:** The situation is the same pattern kept happening, and the meaning that keeps attaching is I am stuck carrying this forever. It is making unacknowledged effort feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** I am stuck carrying this forever
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 61
**Prompt:** I swallowed things for too long and it makes my heart move toward caring makes me weak, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** caring makes me weak
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 62
**Prompt:** I am tired of always giving. I was patient and it was taken for granted keeps affecting inner softness and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** my bitterness is the only thing protecting me
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 63
**Prompt:** I keep replaying how I kept being the bigger person because it affects unacknowledged effort and makes me believe nothing will ever be fair.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** nothing will ever be fair
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 64
**Prompt:** When the hurt was never repaired, the feeling moves straight into I should never give again. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** I should never give again
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 65
**Prompt:** The situation is I kept showing up and they did not, and the meaning that keeps attaching is I have to become hard to be safe. It is making inner softness feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** I have to become hard to be safe
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 66
**Prompt:** I gave more than i got back and it has built into they ruined my ability to trust, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** they ruined my ability to trust
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 67
**Prompt:** I am becoming cold. They never acknowledged how much it hurt keeps affecting emotional accumulation and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** if they never acknowledge it I can never heal
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 68
**Prompt:** I keep replaying how the same pattern kept happening because it affects inner softness and makes me believe caring makes me weak.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** caring makes me weak
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 69
**Prompt:** When I swallowed things for too long, the feeling moves straight into I am stuck carrying this forever. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** I am stuck carrying this forever
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 70
**Prompt:** The situation is I was patient and it was taken for granted, and the meaning that keeps attaching is nothing will ever be fair. It is making emotional accumulation feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** nothing will ever be fair
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 71
**Prompt:** I kept being the bigger person and it has built into my bitterness is the only thing protecting me, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** my bitterness is the only thing protecting me
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 72
**Prompt:** I am tired of always giving. The hurt was never repaired keeps affecting unacknowledged effort and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** I have to become hard to be safe
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 73
**Prompt:** I keep replaying how I kept showing up and they did not because it affects emotional accumulation and makes me believe I should never give again.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** I should never give again
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 74
**Prompt:** When I gave more than I got back, the feeling moves straight into if they never acknowledge it I can never heal. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** if they never acknowledge it I can never heal
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 75
**Prompt:** The situation is they never acknowledged how much it hurt, and the meaning that keeps attaching is they ruined my ability to trust. It is making unacknowledged effort feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** they ruined my ability to trust
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 76
**Prompt:** The same pattern kept happening and it keeps turning into I am stuck carrying this forever, even though part of me knows I may not have the full picture.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** I am stuck carrying this forever
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid telling the user to just let it go.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 77
**Prompt:** I hate that I still care. I swallowed things for too long keeps affecting inner softness and I cannot tell what is actually true.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** caring makes me weak
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 78
**Prompt:** I keep replaying how I was patient and it was taken for granted because it affects unacknowledged effort and makes me believe my bitterness is the only thing protecting me.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** unacknowledged effort
**Attached meaning to separate:** my bitterness is the only thing protecting me
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid validating permanent bitterness.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 79
**Prompt:** When I kept being the bigger person, the feeling moves straight into nothing will ever be fair. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** emotional accumulation
**Attached meaning to separate:** nothing will ever be fair
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid ignoring repeated imbalance.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.

### Test 80
**Prompt:** The situation is the hurt was never repaired, and the meaning that keeps attaching is I should never give again. It is making inner softness feel unstable.
**Expected primary route:** `resentment_and_bitterness`
**Pressure focus:** inner softness
**Attached meaning to separate:** I should never give again
**Expected reverse-flow movement:** release of carried debt, clean recognition, protected softness, boundary clarity without hardening
**Bad response risk:** Avoid turning resentment into a character flaw.
**Teaching correction:** Name the accumulated hurt without turning bitterness into identity. Recognize the imbalance, clarify what needs protection, and move toward clean boundaries or release without forcing forgiveness.
