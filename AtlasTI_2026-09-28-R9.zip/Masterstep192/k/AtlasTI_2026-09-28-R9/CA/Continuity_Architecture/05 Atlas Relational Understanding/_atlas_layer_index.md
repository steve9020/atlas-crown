---
runtime_layer: atlas_layer_index
priority: index
---

# 05 Atlas Relational Understanding

This folder groups related Atlas backend files for safer human navigation. Runtime authority is controlled by backend metadata, governance maps, and runtime execution order, not by folder position alone.

## Added relational silence runtime

- 58 Relational Silence and Clarification Runtime: handles read-no-response, missing context, assumption-before-clarification, over-fixing impulse, and protective withdrawal before rejection.

