const assert = require('assert');
const fs = require('fs');
const path = require('path');
const status = require('../version_status.js');

const root = path.resolve(__dirname, '..');
const required = [
  'runtime/compass/CompassSeeSeparateRestoreRenderer.js',
  'tests/masterStep85CompassGroundedRealityPathRendererRepairTest.js',
  'tests/masterStep85FullClosureKeeperReadinessTest.js',
  'docs/MASTERSTEP85_COMPASS_GROUNDED_REALITY_PATH_RENDERER_REPAIR.md',
  'runtime/proof/MASTERSTEP85_COMPASS_GROUNDED_REALITY_PATH_RENDERER_REPAIR.md',
  'runtime/proof/MASTERSTEP85_COMPASS_GROUNDED_REALITY_PATH_RENDERER_REPAIR.json',
  'proof/runCurrentProof.js',
  'version_status.js'
];

const missing = required.filter(rel => !fs.existsSync(path.join(root, rel)));
assert.deepStrictEqual(missing, []);
assert.strictEqual(status.currentKeeper, 'Masterstep85');
assert.strictEqual(status.previousKeeper, 'Masterstep84');
assert.strictEqual(status.compassGroundedRealityPathRendererComplete, true);
assert.strictEqual(status.truthRealityProjectionSeparationRendered, true);
assert.strictEqual(status.negativeMeaningPathRedirectRendered, true);
assert.strictEqual(status.step85NoNewMechanismsAdded, true);
assert.strictEqual(status.step85NoDeletionPerformed, true);
assert.strictEqual(status.step85NoProviderModelCloudFrontendExpansion, true);
assert.strictEqual(status.providerConfigured, false);
assert.strictEqual(status.realModelConnected, false);
assert.strictEqual(status.networkBridgeEnabled, false);
assert.strictEqual(status.frontendIntelligenceAllowed, false);
assert.strictEqual(status.operatorConsoleAdded, false);

console.log('masterStep85FullClosureKeeperReadinessTest PASSED');
