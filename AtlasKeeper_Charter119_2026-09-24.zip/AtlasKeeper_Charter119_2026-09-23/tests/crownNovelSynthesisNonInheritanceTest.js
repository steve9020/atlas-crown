'use strict';
const assert = require('assert');
const {createCrownPredicateResult,satisfiesPredicate,inputDigest}=require('../runtime/governance/crown/CrownPredicateResult');
const {qualifyEvidence}=require('../runtime/governance/crown/CrownProofQualification');
const x={source_refs:['s1','s2'],prompt:'combine concepts',output:'novel synthesis y'};
const d=inputDigest(x);
const novelty=createCrownPredicateResult({predicate_id:'novel_synthesis',predicate_version:'1',input_digest:d,result:'PASS',evaluator_id:'novelty-evaluator'});
assert.strictEqual(satisfiesPredicate(novelty,{predicate_id:'novel_synthesis',predicate_version:'1',input_digest:d}),true);
for(const p of ['understanding','consciousness','output_authority']){
  assert.strictEqual(satisfiesPredicate(novelty,{predicate_id:p,predicate_version:'1',input_digest:d}),false,`novelty laundered into ${p}`);
  const q={qualifier_id:'q-'+p,qualifier_version:'1',evidence_digest:'e-novel',predicate_id:'novel_synthesis',specification_version:'1',context_id:'ctx',scope:['claim']};
  const r={evidence_digest:'e-novel',predicate_id:p,specification_version:'1',context_id:'ctx',scope:['claim'],implicated_failure_domain:'runtime'};
  const z=qualifyEvidence(q,r);
  assert.strictEqual(z.result,'FAIL');
  assert(z.violations.includes('predicate_id_mismatch'));
}
console.log('CROWN_NOVEL_SYNTHESIS_NONINHERITANCE_PASS');
