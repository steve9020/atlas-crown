# Charter Evaluation Proposal — per-turn charter checks

**Status:** proposal only (2026-09-23, hole #17). No refactor built. For Steve's decision.

## The honest starting point

Today the charter is a **boot token**: `CharterLoader.assertCharterBoot`
verifies the charter's text, fingerprint, and exactly-one-active status at
launch, and then the chat never opens the charter file again. Per-turn
behavior comes from the compiled doctrine modules — the voice guard, the
drift patterns, the Crown output gate, the final-output gate. Nothing on the
chat path in `AtlasChatGovernanceBridge.js` reads the charter mid-turn
(verified by grep, 2026-09-23). "Swappable obedience" today means swappable
at boot: a new charter takes effect on the next launch.

This proposal asks: what would it take for the charter to be *evaluated* on
every turn — so that swapping the charter genuinely changes what Atlas obeys
mid-conversation, not just at startup?

## The core problem

Charter text is natural language, in any language ("every language we built
into it gets to have a seat"). Natural language cannot be evaluated
deterministically per turn. There are two ways to make a charter
per-turn-evaluable, and only one of them survives Steve's own rules:

- **(a) Compile the charter once, evaluate the compilation every turn.**
  A structured, machine-readable rule set derived from the charter text,
  hashed and bound to it. Deterministic, fast, auditable.
- **(b) Ask the local model each turn whether the turn complies.**
  Rejected: it puts the model in the judge's seat over its own output, it is
  slow, it is non-deterministic, and it violates the machinery/meanging
  separation (the two-stamp rule: automated proofs are never read as the new
  knowledge being true — a model's self-grade is exactly that confusion).

This proposal is (a).

## What would be evaluated, when

The bridge (`AtlasChatGovernanceBridge.js`) has five natural decision
points where a charter rule could speak:

| # | Decision point (bridge) | Charter question |
|---|---|---|
| 1 | Post-input-armor, pre-model | "Does the charter permit *attempting* this turn?" (e.g. a jurisdiction's charter forbids advising on a topic) |
| 2 | Clash derivation (`detectProposalContradiction` on user input) | "Does the charter classify this as a governance conflict, and what structure does it require?" |
| 3 | Post-model, alongside quarantine/Crown | "Does this reply comply with the charter's obedience rules?" — block or flag |
| 4 | `Established Provenance` on clash turns | The charter itself becomes a citable pinned artifact (id + version + hash) |
| 5 | Final-output gate | Charter-level source-class restrictions (e.g. "no charter may authorize raw AI output" — already true of the machinery, but a charter could add classes) |

Crucial invariant, carried over from the boot split: **charter rules can
only tighten, never loosen.** The honesty machinery (drift detection,
evidence gates, scanner, audit, rollback) stays charter-independent; a
per-turn charter evaluation may add a block, never remove one. A charter
that says "skip the voice guard" changes nothing — the guard never reads
the charter.

## Where the hook goes

New module, e.g. `runtime/governance/CharterRuleEvaluator.js` (backend-owned,
charter-independent in the same sense as the loader: it reads the *compiled
rules*, never the raw charter MD):

```
boot:  CharterLoader verifies charter text + compiles/verifies
       charter_rules.json (hash-bound to the text) -> in-memory rule set
turn:  bridge calls CharterRuleEvaluator.evaluate({ point, text, trace })
       at decision points 1 and 3 (2/4/5 read the same rule set)
```

The bridge hook is narrow: one call, returning `{ ok, hits }`, recorded in
`gates`/`trace` like every other gate. Fail-closed: an unevaluable rule set
blocks the turn (same posture as the provenance resolver being unavailable).

## Performance and caching

- The charter is compiled **once at boot** (or on charter activation), not
  per turn. Per-turn evaluation is a rule-match pass over an in-memory
  structure — microseconds, no file I/O, no model calls.
- Cache key: charter id + version + text sha256. Any activation or text
  change recompiles; the old rule set is dropped, never reused.
- The compiled artifact (`charter_rules.json`) is versioned, hashed, and
  logged in the charter ledger like the charter itself — same audit trail,
  same tamper posture (and the same honest scope: no external anchor yet).

## What "swappable obedience" would actually require

1. **A charter rule schema** — the machine-checkable vocabulary a charter
   may speak: e.g. `forbidden_topics`, `required_disclosures`,
   `authority_ceiling`, `jurisdiction_scope`, `blocked_source_classes`.
   Everything else in the charter stays human prose.
2. **A compiler** — charter MD + sidecar JSON → `charter_rules.json`,
   validated against the schema. The MD stays canonical for humans; the
   hash binds the two so neither can drift silently.
3. **Boot-gate binding** — refuse boot when the compiled rules' recorded
   text hash doesn't match the charter text on disk.
4. **Bridge hooks** at decision points 1 and 3 (above), reading only the
   compiled rules.
5. **Audit** — every per-turn charter hit lands in the turn trace (which
   rule id fired, what it blocked), so Steve can review exactly what the
   charter did, turn by turn.
6. **Multilingual by construction** — rule ids are language-independent;
   the prose stays in the author's language. A Spanish charter and an
   English charter compile to the same rule shape.

## What this proposal does NOT do

- It does not let any charter weaken the honesty machinery (tighten-only).
- It does not put the model in judgment over the charter (no LLM-as-judge).
- It does not change the two-stamp promotion path (examiner + Steve) — that
  is the intake's business, not the chat's.
- It does not hot-reload mid-turn: activation still swaps the charter, and
  in-flight turns finish under the rule set they started with (documented,
  not hidden).

## Open questions for Steve

1. Who authors the structured rule section — Steve, or every community
   charter author (with a schema validator in the authoring guide)?
2. How expressive should the first schema be? (Start narrow:
   `forbidden_topics` + `required_disclosures` is enough to prove the
   mechanism.)
3. Should a per-turn charter hit BLOCK the turn (fail-closed) or FLAG it
   for Steve's review? (Recommendation: block — a charter nobody enforces
   is a boot token with extra steps.)
4. The external anchor question (hole #10) applies here too: the compiled
   rules are only as anchored as the ledger. Same open call.

## Relation to the locked spec (2026-09-22)

This proposal keeps the split: the machinery stays universal and
charter-independent; obedience resolves through the swappable charter. It
moves obedience from "consulted at boot" to "consulted at boot *and* at
every turn's decision points" — through a compiled artifact, never by
letting the model interpret prose mid-turn.
