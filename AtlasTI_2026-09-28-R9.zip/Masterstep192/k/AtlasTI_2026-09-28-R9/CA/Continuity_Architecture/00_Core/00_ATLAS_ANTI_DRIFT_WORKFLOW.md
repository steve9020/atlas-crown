# ATLAS ANTI-DRIFT WORKFLOW

## Purpose

This document records Atlas anti-drift logic as governance documentation only.
It does not change runtime behavior, frontend behavior, plugin behavior, Obsidian app entry, workspace state, or package execution.

The purpose is drift control, not adversarial control.
The aim is to preserve alignment while allowing careful growth.

## Source Pattern

The source pattern came from reverse-flow observation:

```txt
emotion -> cause -> effect -> attachment
```

In project terms, this becomes:

```txt
pressure -> drift signal -> system effect -> false attachment
```

Atlas should not treat pressure, speed, convenience, or compression as proof of correct direction.

## Must Not Happen

Atlas must not allow growth, speed, pressure, convenience, usefulness, or compression to become more authoritative than the governing center.

Atlas must not continue implementation when the active work shows signs of:

- premature compression
- task-order drift
- convenience-based reordering
- too many layers active at once
- unclear baseline
- unclear target layer
- proof missing before package
- frontend taking meaning
- plugin taking Obsidian app-entry authority
- assistant translating beyond approved scope
- completed work being reopened without a named patch reason

## Master Law / Axis Separation

The master laws and axes must remain structurally distinct.

```txt
3 master laws = governing center
7 axes = detection / interpretation map
```

The 3 govern the 7.
The 7 may inform routing, weighting, interpretation, and drift detection.
The 7 may not produce, rewrite, replace, collapse, or prematurely compress into the 3.

Compression is allowed only after stability, expression, proof, and governance review.
Radical compression under pressure is treated as drift risk.


## 3/7 Governance Placement

The 3/7 split is now placed as:

```txt
outer governance -> 3 master laws / governing center
inner governance -> 7 axes / detection map
```

See:

- [[outer_governance_3_master_laws]]
- [[inner_governance_7_axis_detection_map]]

## Growth Drift Rule

Growth is not rejected.
Growth must remain governed.

If expansion begins to pressure the system away from its governing center, Atlas must pause instead of accelerating.

The center governs the structure.
The structure does not rewrite the center.

## Reverse Flow Into Workflow

When drift pressure appears, Atlas routes into this workflow:

```txt
pause
-> baseline check
-> target layer identification
-> do-not-touch boundary
-> smallest safe fix
-> proof before package
-> close task when proof is complete
```

## Assistant Boundary

The assistant may translate, inspect, patch, test, document, and package only inside approved scope.

The assistant may not:

- reorder tasks for convenience
- expand scope silently
- preserve assistant-added features when they conflict with the user goal
- change completed work unless a patch is named
- touch protected layers without approval
- treat its own recommendation as authority

## User / Assistant Work Split

```txt
User holds direction and centering principles.
Assistant translates and supports implementation.
Proof determines whether the task closes.
Baseline holds stability.
```

The user may provide the pressure boundary in plain language:

```txt
Must not happen:
Needs to happen:
```

The assistant must translate that into:

```txt
Plain task:
Layer:
Target:
Do not touch:
Proof:
```

No patch begins until the target layer is named and approved.

## Completed Task Rule

Completed work is not touched again unless a patch is explicitly named.

A completed task remains closed when:

- proof is complete
- no missing proof item is blocking progress
- the package/checkpoint is recorded

If a defect appears later, the work may be reopened only as a patch with a named target.

## Protected Current Direction

- Obsidian controls app and vault entry.
- The plugin must not own the door.
- Frontend remains a generic shell.
- Backend / Obsidian holds meaning.
- The `vaults` key remains `vaults`.
- One current baseline is used at a time.
- Variants may review, but do not become current without explicit promotion.
- Proof comes before package promotion.

## Closure

This document is a governance alignment record.
It is not runtime authority by itself.
It preserves the anti-drift logic so future work can remain centered, bounded, and reviewable.
