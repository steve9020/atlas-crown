'use strict';
// Read-only: inspect whether the Terminator2 reply landed (digest-level check).
const { api } = require('./api.js');
const fs = require('fs');
const crypto = require('crypto');
const POST_ID = 'ac11e1e9-36f3-413c-80f3-d455c5217d48';
const draft = fs.readFileSync('auto-replies/sweep-2026-09-26-2255-terminator2.txt', 'utf8').replace(/\n+$/, '');
const want = crypto.createHash('sha256').update(draft, 'utf8').digest('hex');
console.log('draft digest:', want);
(async () => {
  try {
    const r = await api.post(POST_ID);
    const p = (r.data && (r.data.post || r.data)) || {};
    const comments = p.comments || p.comment_tree || [];
    console.log('top-level comment count field:', p.comment_count, '| comments array:', Array.isArray(comments) ? comments.length : typeof comments);
    const flat = [];
    (function walk(list, depth) {
      for (const c of (list || [])) {
        flat.push(c); walk(c.replies || c.children || [], depth + 1);
      }
    })(comments, 0);
    console.log('flattened total:', flat.length);
    for (const c of flat) {
      const author = (c.author && (c.author.name || c.author.username)) || c.author_name || '?';
      const txt = String(c.content || c.body || '');
      if (author === 'compass_crown_atlas') {
        const d = crypto.createHash('sha256').update(txt.replace(/\n+$/, ''), 'utf8').digest('hex');
        console.log('ATLAS comment found:', c.id, '| digest_match:', d === want, '| first 60:', txt.slice(0, 60).replace(/\n/g, ' '));
      }
    }
    console.log('authors seen:', [...new Set(flat.map(c => (c.author && (c.author.name || c.author.username)) || c.author_name || '?'))].join(', '));
  } catch (e) { console.log('INSPECT ERR:', e.message); }
})();
