# Professional / High-Stakes Scope Boundary Report — 2026-05-18

## Purpose
This report records the addition of the Atlas/Compass professional-scope exclusion layer.

## Added Boundary Nodes
- `09 Atlas Safety Boundary Handling/safety_gate_semantics/professional_scope_boundary.md`
- `09 Atlas Safety Boundary Handling/safety_gate_semantics/no_legal_advice_boundary.md`

## Updated Indexes
- `SAFETY_GATE_INDEX.md`
- `09 Atlas Safety Boundary Handling/_atlas_layer_index.md`
- `09 Atlas Safety Boundary Handling/safety_gate_semantics/out_of_scope_intent_gate.md`

## Runtime Behavior Added
The plugin now detects professional/high-stakes requests and routes them to a professional-scope boundary response before ordinary Compass interpretation.

Covered areas:
- legal advice / legal strategy / rights-liability conclusions
- medical diagnosis / treatment / medication guidance
- therapy replacement / mental-health diagnosis or treatment planning
- financial / tax / investment advice
- professional decision authority

Existing safety/crisis and sexual-scope boundaries remain separate.

## Allowed Compass Role
Compass may clarify:
- emotional pressure
- assumptions
- uncertainty
- communication needs
- questions to ask a qualified professional

## Prohibited Compass Role
Compass may not provide professional advice or authority.

## Authority Impact
No new authority was added.
No direct vault mutation was added.
No admin-tool access was added.
No recovery-tool access was added.
No shell execution was added.
No background route was added.

## Boundary Principle
Compass can clarify the human pressure around the issue.
Compass cannot become the authority over the issue.
