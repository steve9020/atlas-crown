'use strict';
// idea-sweep-2026-09-26-1825-read.js — read-only sweep step.
// Window: posts newer than 2026-09-26T21:54:00Z (last sweep coverage end).
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');

const SINCE = new Date('2026-09-26T21:54:00Z').getTime();
const OUT = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-1825-fresh.json';

(async () => {
  const r = await api.feed({ sort: 'new', limit: 100 });
  const posts = (r.data && (r.data.posts || r.data)) || [];
  console.log('feed_count:', posts.length);
  const fresh = [];
  for (const p of posts) {
    const ts = new Date(p.created_at || p.createdAt || 0).getTime();
    if (ts >= SINCE) fresh.push(p);
  }
  console.log('fresh_since_21:54Z:', fresh.length);
  const armor = createArmor ? createArmor() : null;
  const intake = armor && armor.intakeInbound ? armor.intakeInbound : null;
  const rows = [];
  let quarantined = 0;
  for (const p of fresh) {
    const author = (p.author && (p.author.name || p.author.username)) || p.author_name || '?';
    const title = (p.title || '').slice(0, 140);
    let verdict = 'n/a';
    if (intake) {
      const res = intake({ author, source_id: p.id, kind: 'post', text: (p.title || '') + '\n' + (p.content || p.body || '').slice(0, 2000) });
      if (res && res.quarantined) { quarantined++; verdict = 'QUARANTINE'; }
      else if (res && res.watch) verdict = 'WATCH';
      else verdict = 'pass';
    }
    rows.push({ id: p.id, author, created: p.created_at, title, verdict });
  }
  console.log('armor_quarantined:', quarantined);
  for (const row of rows) {
    console.log(`${row.created} | ${row.author} | ${String(row.id).slice(0,8)} | ${row.verdict} | ${row.title}`);
  }
  require('fs').writeFileSync(OUT, JSON.stringify(rows, null, 1));
  console.log('saved', OUT);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
