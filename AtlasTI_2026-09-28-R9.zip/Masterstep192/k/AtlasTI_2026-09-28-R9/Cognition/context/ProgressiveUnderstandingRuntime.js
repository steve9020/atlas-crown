const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const PROGRESSIVE_UNDERSTANDING_REGISTRY_PATH = "CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/progressive_understanding_runtime_registry.md";

let cachedProgressiveUnderstandingRegistry = null;

function getProgressiveUnderstandingRegistry() {
  if (!cachedProgressiveUnderstandingRegistry) {
    cachedProgressiveUnderstandingRegistry = readJsonRegistry(PROGRESSIVE_UNDERSTANDING_REGISTRY_PATH);
  }
  return cachedProgressiveUnderstandingRegistry;
}

function normalizeInput(input) { return String(input || "").toLowerCase(); }
function phraseMatches(text, phrase) { return typeof phrase === "string" && phrase.length > 0 && text.includes(phrase.toLowerCase()); }
function anyPhraseMatches(text, phrases) { return Array.isArray(phrases) && phrases.some((phrase) => phraseMatches(text, phrase)); }
function ruleMatches(text, rule) {
  const phrases = Array.isArray(rule.phrases) ? rule.phrases : [];
  return phrases.length > 0 && anyPhraseMatches(text, phrases);
}
function appendUnique(target, values) {
  if (!Array.isArray(values)) return;
  for (const value of values) {
    if (typeof value === "string" && value.trim() && !target.includes(value)) target.push(value);
  }
}
function collectMatchedRules(text, rules) {
  const matched = [];
  for (const rule of rules) if (rule && rule.id && ruleMatches(text, rule)) matched.push(rule);
  return matched;
}
function resolveDependencyState(contextIntegrity, semanticFusion) {
  return {
    context_integrity_active: !!contextIntegrity,
    context_revisable: !contextIntegrity || contextIntegrity.revisable !== false,
    context_closure_allowed: !!contextIntegrity && contextIntegrity.closure_allowed === true,
    semantic_fusion_active: !!semanticFusion,
    semantic_fusion_revisable: !semanticFusion || semanticFusion.revisable !== false,
    semantic_word_closure_allowed: !!semanticFusion && semanticFusion.word_meaning_closure_allowed === true
  };
}

function mapProgressiveUnderstanding(input, contextIntegrity, semanticFusion) {
  const text = normalizeInput(input);
  const registry = getProgressiveUnderstandingRegistry();
  const rules = Array.isArray(registry.rules) ? [...registry.rules] : [];
  rules.sort((a, b) => (a.priority || 9999) - (b.priority || 9999));
  const matchedRules = collectMatchedRules(text, rules);

  const progressiveSignals = [];
  const closureBlocks = [];
  const responsePosture = [];

  for (const rule of matchedRules) {
    appendUnique(progressiveSignals, rule.progressiveSignals);
    appendUnique(closureBlocks, rule.closureBlocks);
    appendUnique(responsePosture, rule.responsePosture);
  }

  const dependencyState = resolveDependencyState(contextIntegrity, semanticFusion);
  const hasProgressiveSignals = progressiveSignals.length > 0;
  const dependencyClosureRisk = dependencyState.context_closure_allowed || dependencyState.semantic_word_closure_allowed;
  const preserveDisclosureOpenness = hasProgressiveSignals || dependencyState.context_revisable || dependencyState.semantic_fusion_revisable;

  return {
    version: registry.version,
    stewardship: "Master Step 4C — Progressive Understanding Runtime",
    depends_on: [
      "Master Step 4A — Context Integrity Mapping",
      "Master Step 4B — Semantic Fusion Separation"
    ],
    dependency_state: dependencyState,
    progressive_understanding_active: true,
    user_led_realization_preserved: true,
    authority_led_interpretation_blocked: hasProgressiveSignals || dependencyClosureRisk,
    disclosure_openness_preserved: preserveDisclosureOpenness,
    closure_allowed: false,
    revisable: true,
    understanding_mode: hasProgressiveSignals ? "progressive_refinement" : "open_revisable_context",
    output_posture: responsePosture.length > 0 ? responsePosture : ["hold_interpretation_open", "preserve_user_authority_over_meaning"],
    progressive_signals: progressiveSignals,
    closure_blocks: closureBlocks,
    matched_rules: matchedRules.map((rule) => rule.id),
    guardrails: Array.isArray(registry.guardrails) ? registry.guardrails : []
  };
}

module.exports = { mapProgressiveUnderstanding };
