---
title: Conditional Teaching Question Registry
runtime_layer: developer_teaching_mode
priority: high
governed_by: developer_teaching_mode_overview
supports:
  - response_correction_question_reference
  - route_clarification_question_reference
  - teaching_answer_to_proposal_flow
  - response_self_review_reference
outputs_to:
  - emotional_growth_proposal_queue
  - emotional_growth_approval_gate
status: active
---

# Conditional Teaching Question Registry

## Purpose

The **Conditional Teaching Question Registry** defines when Compass is allowed to ask Steve a program-teaching question.

Atlas should not ask teaching questions after every response. It should only ask when it detects that its own response may have defaulted, stayed too vague, routed weakly, missed the loop, or failed to produce a specific enough meaning construction.

This keeps teaching focused, program-only, and useful.

---

## Core Rule

Compass may ask Steve a teaching question only when a response-quality weakness is detected.

The question must be about improving Compass behavior, not about exploring Steve personally.

Allowed question purpose:

- clarify a wrong route
- identify what the response missed
- improve emotional context
- improve attached-meaning detection
- improve pattern explanation
- improve clearer-way-forward language
- clarify merge/duplicate decisions
- reduce vague or mechanical wording

Not allowed question purpose:

- ask Steve to process the situation personally
- ask therapy-style follow-up questions
- ask for more personal history unless Steve voluntarily provides it as program context
- ask open-ended emotional dependency questions
- bypass the proposal queue or approval gate

---

## Teaching Question Triggers

Compass may ask a teaching question when one or more of these conditions appears:

1. **Fallback Route Used**
   - primary route is `general`
   - pressure label is generic emotional pressure
   - response uses fallback wording such as “what happened” or “what it started to feel like it meant”

2. **Low Response Quality Score**
   - response self-review score falls below the teaching threshold
   - default threshold: below 76%

3. **Weak Route Confidence**
   - route score is low for an emotional prompt
   - multiple emotions are named but no specific loop family is identified

4. **Generic Loop Explanation**
   - loop card uses broad language such as “a real feeling attaches to a painful meaning” without naming the actual loop

5. **Generic Emotional Contact**
   - contact summary does not identify what the feeling touches
   - examples: safety, belonging, self-worth, control, memory, trust, attachment, future expectation

6. **Generic Clearer Way Forward**
   - final understanding is true but not specific enough to the prompt
   - response tells the user to notice meaning attachment without saying what meaning is active

7. **No Recommendation After Default**
   - Compass defaults to a broad route but does not recommend a missing pattern

8. **Route Conflict**
   - two or more possible routes appear close in strength
   - Atlas should ask which route better fits instead of guessing silently

---

## Teaching Question Suppression

Atlas should not ask Steve a teaching question when:

- a specific route is detected with strong confidence
- emotional contact is specific
- pattern explanation is specific
- clearer way forward is specific
- focal cards carry clear meaning
- response quality score is strong
- the issue is already covered by a pending, approved, merged, or integrated pattern
- the prompt is practical and the response appropriately stays light

---

## Question Forms

### Fallback Route Question

Use when Compass defaulted to a broad route.

Frontend wording:

> Compass may have defaulted to a broad explanation. What specific emotional route, loop, or meaning should it have recognized?

---

### Missing Emotional Context Question

Use when Compass named the feeling but missed what the feeling touched.

Frontend wording:

> The emotional context may be too broad. What did the feeling actually touch in this situation?

---

### Missing Loop Question

Use when the pattern explanation is generic.

Frontend wording:

> The pattern explanation may be too general. What emotional pattern should Compass explain instead?

---

### Missing Forward Understanding Question

Use when the final understanding is too vague.

Frontend wording:

> The clearer way forward may be too vague. What understanding should the user carry forward instead?

---

### Route Conflict Question

Use when more than one route appears possible.

Frontend wording:

> Compass detected more than one possible route. Which route better fits this prompt?

---

## Teaching Answer Handling

When Steve answers a teaching question:

1. Treat the answer as program correction input.
2. Convert the answer into a structured teaching proposal.
3. Send the proposal to `emotional_growth_proposal_queue.md`.
4. Mark it as `pending_review`.
5. Do not activate it.
6. Require approval gate review.
7. Require integration draft review before active system change.

---

## Frontend Rule

The teaching question panel should appear only when Compass detects a weakness.

It should not be a permanent open chat.

Frontend label:

> Atlas Teaching Question

The panel should explain:

> Compass only asks here when it detects its own response may have defaulted, stayed vague, used a weak route, or missed a specific loop. This is program-only teaching, not a personal follow-up.

---

## Related Runtime Links

- [[developer_teaching_mode_overview]]
- [[program_only_question_rules]]
- [[response_correction_question_registry]]
- [[route_clarification_question_registry]]
- [[merge_decision_question_registry]]
- [[teaching_answer_to_proposal_flow]]
- [[teaching_mode_safety_boundaries]]
- [[response_self_review_registry]]
- [[response_quality_scoring_registry]]
- [[emotional_growth_proposal_queue]]
- [[emotional_growth_approval_gate]]
