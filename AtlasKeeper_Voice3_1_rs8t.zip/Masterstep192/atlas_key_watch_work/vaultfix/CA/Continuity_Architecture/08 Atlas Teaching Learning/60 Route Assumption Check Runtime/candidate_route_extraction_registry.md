---
runtime_layer: route_assumption_check
priority: high
owned_by: atlas_teaching_learning
feeds_into:
  - route_meaning_comparison_registry
---

# Candidate Route Extraction Registry

## Purpose
Collects every meaningful route candidate before final route selection.

## Candidate examples
- self-worth restoration
- relational uncertainty clarification
- rejection assumption separation
- over-repair impulse
- protective withdrawal
- identity fusion
- perfection pressure
- future redemption pressure
- role-continuity threat
- temporal emotional continuity

## Rule
A candidate route should not be ignored merely because another route was detected first.
