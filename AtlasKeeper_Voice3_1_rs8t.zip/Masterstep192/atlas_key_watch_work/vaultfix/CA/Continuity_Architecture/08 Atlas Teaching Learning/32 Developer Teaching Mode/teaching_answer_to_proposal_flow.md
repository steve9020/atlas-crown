---
title: Teaching Answer To Proposal Flow
runtime_layer: developer_teaching_mode
priority: high
governed_by: developer_teaching_mode_overview
receives_from:
  - response_correction_question_reference
  - route_clarification_question_reference
  - merge_decision_question_reference
outputs_to:
  - emotional_growth_proposal_queue
  - emotional_growth_approval_gate
status: active
---

# Teaching Answer To Proposal Flow

## Purpose

This node defines how Steve's teaching answers become system learning proposals without becoming active knowledge automatically.

---

## Core Rule

A teaching answer may create a proposal.

A teaching answer may not directly modify active system understanding.

---

## Proposal Conversion Flow

1. Steve identifies a program issue.
2. Steve explains what Compass should have understood.
3. The runtime creates a structured teaching proposal.
4. The proposal is written to [[emotional_growth_proposal_queue]].
5. The proposal status is `pending_review`.
6. The approval gate decides approve, merge, defer, or reject.
7. Only approved proposals may create integration drafts.
8. Only integrated drafts become active system understanding.

---

## Teaching Proposal Fields

A teaching proposal should include:

- source prompt
- correction type
- Steve's correction
- likely affected route
- what Compass missed
- what the future behavior should change
- duplicate or merge risk
- approval path

---

## Related Runtime Links

- [[developer_teaching_mode_overview]]
- [[program_only_question_rules]]
- [[response_correction_question_registry]]
- [[route_clarification_question_registry]]
- [[merge_decision_question_registry]]
- [[teaching_mode_safety_boundaries]]
- [[emotional_growth_proposal_queue]]
- [[emotional_growth_approval_gate]]
