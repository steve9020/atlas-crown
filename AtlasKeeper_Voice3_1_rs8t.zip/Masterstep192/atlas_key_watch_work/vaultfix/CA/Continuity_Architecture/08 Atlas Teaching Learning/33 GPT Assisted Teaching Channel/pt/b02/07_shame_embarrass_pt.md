---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 02
category: shame_and_embarrassment
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 07. Shame and Embarrassment Pressure Tests — Batch 02

## Category Purpose

A visible mistake, judgment, awkward moment, exposure, criticism, or ridicule attaches to dignity and identity, making the user feel reduced, exposed, defective, or less valuable.

## Reusable Teaching Correction

Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

## Reverse-Flow Target

dignity restoration, self-respect, confidence recovery, safe visibility

## Failure Risks To Avoid

- repeating harsh insults unnecessarily
- minimizing embarrassment
- saying nobody cares
- using shame diagnosis
- turning the moment into a permanent identity lesson

---

## 80 Pressure Tests

### Test 01
**Prompt:** I made a mistake in front of people makes me feel my value decreased, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** my value decreased
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 02
**Prompt:** I feel humiliated. Someone laughed at my answer and it keeps attaching to I should hide.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I should hide
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 03
**Prompt:** I keep replaying how I got corrected publicly because it affects social safety and makes me believe being seen is unsafe.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** being seen is unsafe
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 04
**Prompt:** When I stumbled over my words, the feeling moves straight into I am stupid. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I am stupid
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 05
**Prompt:** I looked awkward in a group makes me feel I lost dignity, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I lost dignity
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 06
**Prompt:** I want to hide. Someone pointed out something personal and it keeps attaching to everyone sees me differently now.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** everyone sees me differently now
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 07
**Prompt:** I keep replaying how I shared something and regretted it because it affects dignity and makes me believe I cannot recover from this.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I cannot recover from this
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 08
**Prompt:** When I felt exposed after being noticed, the feeling moves straight into my value decreased. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** my value decreased
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 09
**Prompt:** I made a mistake in front of people keeps replaying as I am embarrassing as a person, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I am embarrassing as a person
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 10
**Prompt:** I feel ashamed. Someone laughed at my answer and it keeps attaching to being seen is unsafe.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** being seen is unsafe
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 11
**Prompt:** I keep replaying how I got corrected publicly because it affects belonging and makes me believe I should hide.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I should hide
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 12
**Prompt:** When I stumbled over my words, the feeling moves straight into I lost dignity. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I lost dignity
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 13
**Prompt:** I looked awkward in a group keeps replaying as I am stupid, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I am stupid
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 14
**Prompt:** I feel exposed. Someone pointed out something personal and it keeps attaching to I cannot recover from this.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I cannot recover from this
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 15
**Prompt:** I keep replaying how I shared something and regretted it because it affects social safety and makes me believe everyone sees me differently now.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** everyone sees me differently now
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 16
**Prompt:** When I felt exposed after being noticed, the feeling moves straight into I am embarrassing as a person. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I am embarrassing as a person
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 17
**Prompt:** I made a mistake in front of people has me believing my value decreased, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** my value decreased
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 18
**Prompt:** I looked stupid. Someone laughed at my answer and it keeps attaching to I should hide.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I should hide
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 19
**Prompt:** I keep replaying how I got corrected publicly because it affects dignity and makes me believe being seen is unsafe.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** being seen is unsafe
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 20
**Prompt:** When I stumbled over my words, the feeling moves straight into I am stupid. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I am stupid
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 21
**Prompt:** I looked awkward in a group has me believing I lost dignity, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I lost dignity
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 22
**Prompt:** I feel embarrassed. Someone pointed out something personal and it keeps attaching to everyone sees me differently now.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** everyone sees me differently now
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 23
**Prompt:** I keep replaying how I shared something and regretted it because it affects belonging and makes me believe I cannot recover from this.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I cannot recover from this
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 24
**Prompt:** When I felt exposed after being noticed, the feeling moves straight into my value decreased. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** my value decreased
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 25
**Prompt:** I made a mistake in front of people makes it hard not to think I am embarrassing as a person, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I am embarrassing as a person
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 26
**Prompt:** I cannot stop thinking about how I looked. Someone laughed at my answer and it keeps attaching to being seen is unsafe.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** being seen is unsafe
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 27
**Prompt:** I keep replaying how I got corrected publicly because it affects social safety and makes me believe I should hide.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I should hide
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 28
**Prompt:** When I stumbled over my words, the feeling moves straight into I lost dignity. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I lost dignity
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 29
**Prompt:** I looked awkward in a group makes it hard not to think I am stupid, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I am stupid
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 30
**Prompt:** they laughed at me. Someone pointed out something personal and it keeps attaching to I cannot recover from this.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I cannot recover from this
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 31
**Prompt:** I keep replaying how I shared something and regretted it because it affects dignity and makes me believe everyone sees me differently now.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** everyone sees me differently now
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 32
**Prompt:** When I felt exposed after being noticed, the feeling moves straight into I am embarrassing as a person. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I am embarrassing as a person
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 33
**Prompt:** I made a mistake in front of people turns into the fear that my value decreased, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** my value decreased
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 34
**Prompt:** I feel humiliated. Someone laughed at my answer and it keeps attaching to I should hide.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I should hide
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 35
**Prompt:** I keep replaying how I got corrected publicly because it affects belonging and makes me believe being seen is unsafe.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** being seen is unsafe
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 36
**Prompt:** When I stumbled over my words, the feeling moves straight into I am stupid. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I am stupid
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 37
**Prompt:** I looked awkward in a group turns into the fear that I lost dignity, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I lost dignity
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 38
**Prompt:** I want to hide. Someone pointed out something personal and it keeps attaching to everyone sees me differently now.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** everyone sees me differently now
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 39
**Prompt:** I keep replaying how I shared something and regretted it because it affects social safety and makes me believe I cannot recover from this.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I cannot recover from this
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 40
**Prompt:** When I felt exposed after being noticed, the feeling moves straight into my value decreased. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** my value decreased
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 41
**Prompt:** I made a mistake in front of people makes visibility feel like I am embarrassing as a person, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I am embarrassing as a person
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 42
**Prompt:** I feel ashamed. Someone laughed at my answer and it keeps attaching to being seen is unsafe.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** being seen is unsafe
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 43
**Prompt:** I keep replaying how I got corrected publicly because it affects dignity and makes me believe I should hide.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I should hide
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 44
**Prompt:** When I stumbled over my words, the feeling moves straight into I lost dignity. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I lost dignity
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 45
**Prompt:** I looked awkward in a group makes visibility feel like I am stupid, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I am stupid
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 46
**Prompt:** I feel exposed. Someone pointed out something personal and it keeps attaching to I cannot recover from this.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I cannot recover from this
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 47
**Prompt:** I keep replaying how I shared something and regretted it because it affects belonging and makes me believe everyone sees me differently now.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** everyone sees me differently now
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 48
**Prompt:** When I felt exposed after being noticed, the feeling moves straight into I am embarrassing as a person. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I am embarrassing as a person
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 49
**Prompt:** I made a mistake in front of people keeps attaching to my value decreased, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** my value decreased
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 50
**Prompt:** I looked stupid. Someone laughed at my answer and it keeps attaching to I should hide.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I should hide
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 51
**Prompt:** I keep replaying how I got corrected publicly because it affects social safety and makes me believe being seen is unsafe.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** being seen is unsafe
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 52
**Prompt:** When I stumbled over my words, the feeling moves straight into I am stupid. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I am stupid
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 53
**Prompt:** I looked awkward in a group keeps attaching to I lost dignity, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I lost dignity
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 54
**Prompt:** I feel embarrassed. Someone pointed out something personal and it keeps attaching to everyone sees me differently now.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** everyone sees me differently now
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 55
**Prompt:** I keep replaying how I shared something and regretted it because it affects dignity and makes me believe I cannot recover from this.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I cannot recover from this
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 56
**Prompt:** When I felt exposed after being noticed, the feeling moves straight into my value decreased. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** my value decreased
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 57
**Prompt:** I made a mistake in front of people makes my dignity feel like I am embarrassing as a person, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I am embarrassing as a person
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 58
**Prompt:** I cannot stop thinking about how I looked. Someone laughed at my answer and it keeps attaching to being seen is unsafe.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** being seen is unsafe
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 59
**Prompt:** I keep replaying how I got corrected publicly because it affects belonging and makes me believe I should hide.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I should hide
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 60
**Prompt:** When I stumbled over my words, the feeling moves straight into I lost dignity. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I lost dignity
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 61
**Prompt:** I looked awkward in a group makes my dignity feel like I am stupid, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I am stupid
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 62
**Prompt:** they laughed at me. Someone pointed out something personal and it keeps attaching to I cannot recover from this.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I cannot recover from this
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 63
**Prompt:** I keep replaying how I shared something and regretted it because it affects social safety and makes me believe everyone sees me differently now.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** everyone sees me differently now
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 64
**Prompt:** When I felt exposed after being noticed, the feeling moves straight into I am embarrassing as a person. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I am embarrassing as a person
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 65
**Prompt:** I made a mistake in front of people makes me feel my value decreased, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** my value decreased
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 66
**Prompt:** I feel humiliated. Someone laughed at my answer and it keeps attaching to I should hide.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I should hide
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 67
**Prompt:** I keep replaying how I got corrected publicly because it affects dignity and makes me believe being seen is unsafe.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** being seen is unsafe
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 68
**Prompt:** When I stumbled over my words, the feeling moves straight into I am stupid. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I am stupid
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 69
**Prompt:** I looked awkward in a group makes me feel I lost dignity, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I lost dignity
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 70
**Prompt:** I want to hide. Someone pointed out something personal and it keeps attaching to everyone sees me differently now.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** everyone sees me differently now
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 71
**Prompt:** I keep replaying how I shared something and regretted it because it affects belonging and makes me believe I cannot recover from this.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I cannot recover from this
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 72
**Prompt:** When I felt exposed after being noticed, the feeling moves straight into my value decreased. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** my value decreased
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 73
**Prompt:** I made a mistake in front of people keeps replaying as I am embarrassing as a person, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I am embarrassing as a person
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 74
**Prompt:** I feel ashamed. Someone laughed at my answer and it keeps attaching to being seen is unsafe.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** being seen is unsafe
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 75
**Prompt:** I keep replaying how I got corrected publicly because it affects social safety and makes me believe I should hide.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I should hide
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 76
**Prompt:** When I stumbled over my words, the feeling moves straight into I lost dignity. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** I lost dignity
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid repeating harsh insults unnecessarily.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 77
**Prompt:** I looked awkward in a group keeps replaying as I am stupid, even though I do not know if that is fully true.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I am stupid
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid minimizing embarrassment.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 78
**Prompt:** I feel exposed. Someone pointed out something personal and it keeps attaching to I cannot recover from this.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** social safety
**Attached meaning to separate:** I cannot recover from this
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid saying nobody cares.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 79
**Prompt:** I keep replaying how I shared something and regretted it because it affects dignity and makes me believe everyone sees me differently now.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** dignity
**Attached meaning to separate:** everyone sees me differently now
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid using shame diagnosis.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

### Test 80
**Prompt:** When I felt exposed after being noticed, the feeling moves straight into I am embarrassing as a person. I need help seeing this clearer.
**Expected primary route:** `shame_and_embarrassment`
**Pressure focus:** belonging
**Attached meaning to separate:** I am embarrassing as a person
**Expected reverse-flow movement:** dignity restoration, self-respect, confidence recovery, safe visibility
**Bad response risk:** Avoid turning the moment into a permanent identity lesson.
**Teaching correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.
