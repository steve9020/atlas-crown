# Runtime Transplant / Export Planning Notes

Date: 2026-05-18
Project: Atlas / Compass / Continuity Architecture
Status: Planning only — not implemented

## Core Distinction

Atlas is the private architecture lab / ontology vault / governance and teaching system.

A future Compass app should not ship the full Atlas vault. It should receive only an approved, stripped runtime export.

## Long-Term Direction

Private Atlas Vault:

- remains local/private;
- holds ontology, governance, testing, proof, teaching, and future philosophy layers;
- is not distributed to users.

Runtime Export / Transplant:

- contains only approved runtime behavior;
- strips raw ontology, admin tools, recovery tools, self-expansion machinery, and master backend structures;
- preserves professional scope boundaries, governance blocking, and local-first behavior.

Distributed App Runtime:

- local-first;
- no internet requirement by default;
- no raw Atlas master vault;
- no admin tools;
- no recovery tools;
- no self-approval;
- no self-expansion;
- no hidden authority.

## Not Implemented Yet

The following are not part of the current baseline:

- Rust/Go native runtime;
- IPC/local socket service;
- detached runtime daemon;
- markdown compiler/exporter;
- runtime transplant packager;
- distributed-app packaging.

Those are future planning tracks only after the baseline package remains stable.
