# Approval Gate Runtime

## Purpose
The approval gate protects Atlas from drift, duplication, overfitting, and unsafe expansion.

## Approval Actions
- Approve: move toward integration draft
- Merge: keep the correction but connect it to existing structure
- Defer: hold for more examples
- Reject: prevent backend activation

## Required Checks
- non-clinical
- non-diagnostic
- non-authoritative
- no identity claim
- no silent mutation
- no duplicate pattern
- continuity preserving
- frontend-light expression possible
