---
title: External Teacher Input Format
runtime_layer: external_teaching_channel
priority: high
governed_by: gpt_assisted_teaching_channel_overview
supports:
  - gpt_response_review_template
  - external_teaching_to_proposal_flow
status: active
---

# External Teacher Input Format

## Purpose

The **External Teacher Input Format** defines how Steven should package Compass outputs for GPT-assisted review.

The goal is to make outside teaching clean, repeatable, and useful without allowing uncontrolled learning.

---

## Standard Review Packet

When sending Compass material for review, include as many of these as possible:

- Original user prompt
- Compass response output
- Screenshot if relevant
- Recommendation cards shown
- Approval gate suggestion if relevant
- What felt wrong or too vague
- What Steven thinks Compass should have understood
- Whether the issue is routing, wording, meaning, pattern explanation, or user-facing clarity

---

## Preferred Input Template

### Original Prompt

[Paste the exact prompt used in Compass.]

### Compass Output

[Paste the Compass output or send screenshot.]

### What Felt Off

[Explain what felt wrong, vague, overbroad, mechanical, or misrouted.]

### Desired Direction

[Explain what Compass should have understood or said instead.]

### Requested Teaching Output

Choose one:

- response correction
- routing correction
- sentence construction improvement
- meaning construction improvement
- merge assessment help
- system proposal draft
- approved training example

---

## Input Safety Rule

External teaching input should focus on program behavior, not personal processing.

The review question should be framed as:

> What should Compass have understood or constructed differently?

Not:

> Help me process this personally.

---

## Related Runtime Links

- [[gpt_assisted_teaching_channel_overview]]
- [[gpt_response_review_template]]
- [[external_teaching_to_proposal_flow]]
- [[external_teacher_boundaries]]
