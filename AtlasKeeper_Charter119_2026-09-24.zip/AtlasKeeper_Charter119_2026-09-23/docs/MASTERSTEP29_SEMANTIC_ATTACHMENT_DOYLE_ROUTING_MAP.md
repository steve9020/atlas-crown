# Masterstep29 — Semantic Attachment Families + Doyle Relational Routing Map

Masterstep29 adds a relational attachment layer so Atlas does not treat words as fixed definitions. Words and phrases carry possible emotional/meaning attachments. The active attachment is chosen by prompt relation: phrase, emotional marker, stated effect, action impulse, and context.

## Core flow

word / phrase → possible attachment families → active signals → do-not-assume boundary → separation target → reverse-flow restoration path → Doyle sphere placement

## Key correction from testing

“Pile up” is read primarily as a stress marker when paired with shutdown and difficulty thinking. The separation is pileup / stress from pileup / ability. Restoration must show that stress is workable, smaller pieces reduce pressure, small movement counts, and the person is worth the effort of working through the stress.

## Boundary

This step adds no real AI, no model connection, no provider config, no network bridge, and no frontend intelligence.
