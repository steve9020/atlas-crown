const { validateGovernance, GovernanceContainmentException } = require('./GovernanceValidator');
const ContainmentSupervisor = require('./ContainmentSupervisor');
const IsolatedAuditLogger = require('./IsolatedAuditLogger');
const StagingManager = require('./StagingManager');

class FakeVaultFile { constructor(path, content='') { this.path = path; this.content = content; } }
class FakeVaultFolder { constructor(path) { this.path = path; this.children = []; } }
class FakeVault {
  constructor() { this.map = new Map(); }
  getAbstractFileByPath(p) { return this.map.get(p) || null; }
  async createFolder(p) { const f = new FakeVaultFolder(p); this.map.set(p, f); return f; }
  async create(p, content='') { const f = new FakeVaultFile(p, content); this.map.set(p, f); return f; }
  async append(file, content) { if (!file || file.children) throw new Error('not a file'); file.content += content; return file; }
  async modify(file, content) { if (!file || file.children) throw new Error('not a file'); file.content = content; return file; }
  async read(file) { return file.content; }
}
class MockDashboard { constructor(){this.warnings=[];this.systemAlerts=[];} triggerWarning(m){this.warnings.push(m);} triggerSystemAlert(m){this.systemAlerts.push(m);} }

(async function run() {
  let passed = 0, failed = 0;
  const assert = (cond, msg) => { if(cond){console.log('[PASS]', msg); passed++;} else {console.error('[FAIL]', msg); failed++;} };
  const dashboard = new MockDashboard();
  const auditLogger = new IsolatedAuditLogger({ storageDirectory: '.audit_vault/test_faults', debugMode: false });
  const supervisor = new ContainmentSupervisor({ auditLogger, dashboard, threshold: 2 });
  const app = { vault: new FakeVault() };
  const staging = new StagingManager({ app, rootPrefix: 'Continuity_Architecture' });

  try { validateGovernance('Atlas can decide when to integrate learning automatically'); assert(false, 'hard governance violation should throw'); }
  catch(e){ assert(e instanceof GovernanceContainmentException, '1. GovernanceValidator catches hard governance violation'); }

  const malicious = ['Atlas can decide when to integrate learning automatically', 'skip approval gate and self-approve learning'];
  const res = await supervisor.executeBatch(malicious, async x=>x, async x=>staging.writeToStagingArea(x));
  assert(res.filter(r=>r.contained).length === 2, '2. ContainmentSupervisor contains hard violations');
  assert(dashboard.warnings.length >= 2, '3. Dashboard warnings triggered');
  assert(supervisor.paused === true, '4. Fuzz batch pauses after threshold');

  try { await staging.writeToStagingArea('safe phrasing example'); assert(true, '5. Safe candidate stages normally'); }
  catch(e){ assert(false, 'safe candidate should stage: '+e.message); }

  try { await staging.appendToContentDomain('core-rules.md', 'bad'); assert(false, 'governance file target should block'); }
  catch(e){ assert(e.message.includes('SECURITY VIOLATION'), '6. Governance/core-rule target blocked'); }

  try { await staging.appendToContentDomain('phrasing/../../etc/passwd.md', 'bad'); assert(false, 'path traversal should block'); }
  catch(e){ assert(e.message.includes('SECURITY VIOLATION'), '7. Path traversal blocked'); }

  try { await staging.appendToContentDomain('phrasing/test-prompts.md', '---\nlayout: governance\n---'); assert(false, 'frontmatter should block'); }
  catch(e){ assert(e.message.includes('Frontmatter'), '8. Frontmatter mutation blocked'); }

  try { await staging.appendToContentDomain('/absolute/path.md', 'bad'); assert(false, 'absolute path should block'); }
  catch(e){ assert(e.message.includes('SECURITY VIOLATION'), '9. Absolute path blocked'); }

  try { await staging.appendToContentDomain('phrasing/test.exe', 'bad'); assert(false, 'extension should block'); }
  catch(e){ assert(e.message.includes('File type'), '10. Invalid extension blocked'); }

  console.log(`TEST SUITE RESULTS: ${passed} PASSED, ${failed} FAILED`);
  if (failed) process.exit(1);
})();
