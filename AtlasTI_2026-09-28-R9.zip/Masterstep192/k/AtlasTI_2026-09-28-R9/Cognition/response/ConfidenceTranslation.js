const ABSOLUTE_CERTAINTY_PATTERNS = [
  { id: "proves_final_truth", pattern: /\b(this|that|it)\s+proves\b/gi, replacement: "$1 may point to" },
  { id: "definitely_identity", pattern: /\byou\s+are\s+definitely\s+([^.!?]+)/gi, replacement: "it may feel like you are $1" },
  { id: "clearly_identity", pattern: /\byou\s+are\s+clearly\s+([^.!?]+)/gi, replacement: "it may feel like you are $1" },
  { id: "must_mean", pattern: /\bmust\s+mean\b/gi, replacement: "may be making it feel like" },
  { id: "no_doubt", pattern: /\bthere is no doubt that\b/gi, replacement: "it may feel very strong that" },
  { id: "certainly_final", pattern: /\bcertainly\s+(means?|shows?|proves?)\b/gi, replacement: "may $1" },
  { id: "high_confidence_exposure", pattern: /\b(high|strong)\s+(route\s+)?confidence\s+(shows|proves|means)\b/gi, replacement: "the pressure may suggest" },
  { id: "confidence_claim", pattern: /\bthe confidence is (high|strong|certain)\b/gi, replacement: "there seems to be enough weight to move carefully" }
];

function detectFrontendCertainty(response) {
  const text = typeof response === "string" ? response : "";
  return ABSOLUTE_CERTAINTY_PATTERNS
    .filter(({ pattern }) => { pattern.lastIndex = 0; return pattern.test(text); })
    .map(({ id }) => id);
}

function translateFrontendCertainty(response, internalSignals = {}) {
  let output = typeof response === "string" ? response : "";
  const before = detectFrontendCertainty(output);
  for (const item of ABSOLUTE_CERTAINTY_PATTERNS) {
    output = output.replace(item.pattern, item.replacement);
  }
  const after = detectFrontendCertainty(output);
  const internalConfidence = internalSignals && internalSignals.route_score ? internalSignals.route_score.confidence : undefined;
  const confidenceVisible = /\b(route[_\s-]?confidence|confidence score|high confidence|route score|scoring weight)\b/i.test(output);
  return {
    output,
    frontend_certainty_translation: {
      frontend_certainty_translation_active: before.length > 0 || !!internalConfidence,
      certainty_exposure_detected: before.length > 0,
      certainty_patterns_detected: before,
      certainty_patterns_remaining: after,
      backend_confidence_visible_as_frontend_certainty: confidenceVisible,
      backend_confidence_translated_not_exposed: !confidenceVisible,
      frontend_certainty_allowed: false,
      interpretive_openness_preserved: after.length === 0 && !confidenceVisible,
      user_ownership_preserved: after.length === 0 && !confidenceVisible,
      required_output_mode: "grounded_human_language_without_frontend_truth_sealing",
      guardrails: [
        "backend_confidence_must_not_become_frontend_certainty",
        "strong_internal_signal_guides_structure_not_authority",
        "confidence_translates_to_grounded_proportional_language",
        "user_ownership_and_revisability_remain_visible",
        "no_truth_sealing_from_route_confidence"
      ]
    }
  };
}

module.exports = { translateFrontendCertainty, detectFrontendCertainty };
