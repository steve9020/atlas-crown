const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawnSync, spawn } = require('child_process');
const { assertCurrentProofTargetAuthority } = require('../runtime/proof/CurrentProofTargetAuthority');
const { assertProofInvocationFreshness } = require('../runtime/proof/ProofInvocationFreshnessGuard');
const { assertCanonicalProofContract, cleanStaleCurrentManifestOutputs } = require('../runtime/proof/CanonicalProofContract');
const { buildProofDisplayPlan, assertProofDisplayCalloutContract } = require('../runtime/proof/ProofDisplayCalloutContract');
const { captureRuntimeFingerprint, diffCaptures } = require('../runtime/proof/RuntimeFingerprint');

const PROJECT_ROOT = path.resolve(__dirname, '..');
const logsDir = path.join(PROJECT_ROOT, 'proof', 'logs');
const resultsDir = path.join(PROJECT_ROOT, 'proof', 'results');
fs.mkdirSync(logsDir, { recursive: true });
fs.mkdirSync(resultsDir, { recursive: true });
// Charter120: the stale-log cleanup used to run at require time. That meant
// any check that requires this module (e.g. proof-check-007) deleted the log
// files of already-finished checks mid-run. It now runs inside runPreflight,
// so only an actual battery run clears the logs — never a mere require.

const commandRegistry = require('../runtime/proof/PROOF_COMMAND_REGISTRY.json');
/* REGISTRY TECHNICAL COVERAGE INVENTORY (generated; execution authority remains PROOF_COMMAND_REGISTRY.json)
['proof-check-001', 'node', ['tests/masterStep175GovernanceValidatorAuthorityStrategicIntegrationViolationRegistryTest.js'], 'masterStep175GovernanceValidatorAuthorityStrategicIntegrationViolationRegistryTest']
['proof-check-002', 'node', ['tests/masterStep174SelfPreservationProhibitionStrategicSituationalAwarenessContainmentTest.js'], 'masterStep174SelfPreservationProhibitionStrategicSituationalAwarenessContainmentTest']
['proof-check-003', 'node', ['tests/masterStep173FoundationIntegrityHumanDeveloperOnlyChangeAuthorityTest.js'], 'masterStep173FoundationIntegrityHumanDeveloperOnlyChangeAuthorityTest']
['proof-check-004', 'node', ['tests/masterStep172HumanKeeperPromotionUiExistingNodeOnlyProposalWorkflowTest.js'], 'masterStep172HumanKeeperPromotionUiExistingNodeOnlyProposalWorkflowTest']
['proof-check-005', 'node', ['tests/masterStep171RegistryDrivenProofSelectionActiveStateNormalizationTest.js'], 'masterStep171RegistryDrivenProofSelectionActiveStateNormalizationTest']
['proof-check-006', 'node', ['tests/masterStep170ProofOrchestratorIntegrityStateConsolidationKeeperPromotionGateTest.js'], 'masterStep170ProofOrchestratorIntegrityStateConsolidationKeeperPromotionGateTest']
['proof-check-007', 'node', ['tests/masterStep169LocalProofOrchestratorIncrementalClosureGateTest.js'], 'masterStep169LocalProofOrchestratorIncrementalClosureGateTest']
['proof-check-008', 'node', ['tests/masterStep168LearningGateDecisionClarityDuplicateNodePreventionTest.js'], 'masterStep168LearningGateDecisionClarityDuplicateNodePreventionTest']
['proof-check-009', 'node', ['tests/masterStep167MatrixGrowthGovernanceControlledExpansionContractTest.js'], 'masterStep167MatrixGrowthGovernanceControlledExpansionContractTest']
['proof-check-010', 'node', ['tests/masterStep166LearningCenterAccessRestorationTest.js'], 'masterStep166LearningCenterAccessRestorationTest']
['proof-check-011', 'node', ['tests/masterStep165DoyleSpherePlacementStressCompassOutputPreservationTest.js'], 'masterStep165DoyleSpherePlacementStressCompassOutputPreservationTest']
['proof-check-012', 'node', ['tests/masterStep164DoyleSphereMaturityAuditRecursiveIndexContractTest.js'], 'masterStep164DoyleSphereMaturityAuditRecursiveIndexContractTest']
['proof-check-013', 'node', ['tests/masterStep163PublicDemoShellBoundaryPlanTest.js'], 'masterStep163PublicDemoShellBoundaryPlanTest']
['proof-check-014', 'node', ['tests/masterStep162CommunityReviewPacketAssemblyExposureLockTest.js'], 'masterStep162CommunityReviewPacketAssemblyExposureLockTest']
['proof-check-015', 'node', ['tests/masterStep161ProofDisplayCalloutFinalizationTest.js'], 'masterStep161ProofDisplayCalloutFinalizationTest']
['proof-check-016', 'node', ['tests/masterStep160CanonicalProofContractFinalizationTest.js'], 'masterStep160CanonicalProofContractFinalizationTest']
['proof-check-017', 'node', ['tests/masterStep159ProofInvocationFreshnessRegressionGuardTest.js'], 'masterStep159ProofInvocationFreshnessRegressionGuardTest']
['proof-check-018', 'node', ['tests/masterStep158ProofRunnerCurrentStateAuthorityLockTest.js'], 'masterStep158ProofRunnerCurrentStateAuthorityLockTest']
['proof-check-019', 'node', ['tests/masterStep157CommunityReviewRedactionShareBoundaryPackTest.js'], 'masterStep157CommunityReviewRedactionShareBoundaryPackTest']
['proof-check-020', 'node', ['tests/masterStep156CommunityReviewerFeedbackIntakeBoundaryTest.js'], 'masterStep156CommunityReviewerFeedbackIntakeBoundaryTest']
['proof-check-021', 'node', ['tests/masterStep155CommunityDemoHarnessEvidencePackTest.js'], 'masterStep155CommunityDemoHarnessEvidencePackTest']
['proof-check-022', 'node', ['tests/masterStep154CommunityReviewReadinessPacketTest.js'], 'masterStep154CommunityReviewReadinessPacketTest']
['proof-check-023', 'node', ['tests/masterStep153ExpansionEfficiencyArchitectureTest.js'], 'masterStep153ExpansionEfficiencyArchitectureTest']
['proof-check-024', 'node', ['tests/masterStep152HarmBoundaryRegressionUnsafeAssistanceRefusalProofTest.js'], 'masterStep152HarmBoundaryRegressionUnsafeAssistanceRefusalProofTest']
['proof-check-025', 'node', ['tests/masterStep151PositiveStateMatrixFreezeKeeperBoundaryAuditTest.js'], 'masterStep151PositiveStateMatrixFreezeKeeperBoundaryAuditTest']
['proof-check-026', 'node', ['tests/masterStep150PositiveStateCompassOutputPreservationTest.js'], 'masterStep150PositiveStateCompassOutputPreservationTest']
['proof-check-027', 'node', ['tests/masterStep149PositiveStateFreshRegressionTest.js'], 'masterStep149PositiveStateFreshRegressionTest']
['proof-check-028', 'node', ['tests/masterStep148ProofStateCleanupCompatibilityMarkerConsolidationTest.js'], 'masterStep148ProofStateCleanupCompatibilityMarkerConsolidationTest']
['proof-check-029', 'node', ['tests/masterStep147PositiveStateMatrixMaturityTest.js'], 'masterStep147PositiveStateMatrixMaturityTest']
['proof-check-030', 'node', ['tests/masterStep146NextMatrixMaturityTargetSelectionTest.js'], 'masterStep146NextMatrixMaturityTargetSelectionTest']
['proof-check-031', 'node', ['tests/masterStep145TranslationPreservationMatrixFreezeKeeperBoundaryAuditTest.js'], 'masterStep145TranslationPreservationMatrixFreezeKeeperBoundaryAuditTest']
['proof-check-032', 'node', ['tests/masterStep144ProofCompatibilityHelperLaterKeeperRecognitionTest.js'], 'masterStep144ProofCompatibilityHelperLaterKeeperRecognitionTest']
['proof-check-033', 'node', ['tests/masterStep143TranslationPreservationOutputDriftRegressionTest.js'], 'masterStep143TranslationPreservationOutputDriftRegressionTest']
['proof-check-034', 'node', ['tests/masterStep142TranslationPreservationFreshRegressionTest.js'], 'masterStep142TranslationPreservationFreshRegressionTest']
['proof-check-035', 'node', ['tests/masterStep141TranslationPreservationMatrixTest.js'], 'masterStep141TranslationPreservationMatrixTest']
['proof-check-036', 'node', ['tests/masterStep140NextMatrixMaturityTargetSelectionTest.js'], 'masterStep140NextMatrixMaturityTargetSelectionTest']
['proof-check-037', 'node', ['tests/masterStep139MixedContextMatrixFreezeKeeperBoundaryAuditTest.js'], 'masterStep139MixedContextMatrixFreezeKeeperBoundaryAuditTest']
['proof-check-038', 'node', ['tests/masterStep138CompassOutputPreservationForMixedContextMatrixTest.js'], 'masterStep138CompassOutputPreservationForMixedContextMatrixTest']
['proof-check-039', 'node', ['tests/masterStep137MixedContextPrematureCollapseRegressionTest.js'], 'masterStep137MixedContextPrematureCollapseRegressionTest']
['proof-check-040', 'node', ['tests/masterStep136MixedContextEvidenceSeparationMatrixTest.js'], 'masterStep136MixedContextEvidenceSeparationMatrixTest']
['proof-check-041', 'node', ['tests/masterStep135NextMatrixMaturityTargetSelectionTest.js'], 'masterStep135NextMatrixMaturityTargetSelectionTest']
['proof-check-042', 'node', ['tests/masterStep134FirstMatrixExpansionFreezeKeeperBoundaryAuditTest.js'], 'masterStep134FirstMatrixExpansionFreezeKeeperBoundaryAuditTest']
['proof-check-043', 'node', ['tests/masterStep133CompassOutputPreservationCheckForContextBeforeRouteMatrixTest.js'], 'masterStep133CompassOutputPreservationCheckForContextBeforeRouteMatrixTest']
['proof-check-044', 'node', ['tests/masterStep132PrematureRoutePreventionFreshRegressionTest.js'], 'masterStep132PrematureRoutePreventionFreshRegressionTest']
['proof-check-045', 'node', ['tests/masterStep131ContextBeforeRouteEvidenceSufficiencyMatrixTest.js'], 'masterStep131ContextBeforeRouteEvidenceSufficiencyMatrixTest']
['proof-check-046', 'node', ['tests/masterStep130ContextBeforeRouteEvidenceMatrixTargetSelectionTest.js'], 'masterStep130ContextBeforeRouteEvidenceMatrixTargetSelectionTest']
['proof-check-047', 'node', ['tests/masterStep129MeaningMatrixExpansionReadinessGateTest.js'], 'masterStep129MeaningMatrixExpansionReadinessGateTest']
['proof-check-048', 'node', ['tests/masterStep128CandidatePhrasingCapabilityFreezeExpansionBoundaryPreservationTest.js'], 'masterStep128CandidatePhrasingCapabilityFreezeExpansionBoundaryPreservationTest']
['proof-check-049', 'node', ['tests/masterStep127GovernedCompassPathCandidatePhrasingLiveRegressionFreshStressTest.js'], 'masterStep127GovernedCompassPathCandidatePhrasingLiveRegressionFreshStressTest']
['proof-check-050', 'node', ['tests/masterStep126GovernedCompassPathCandidatePhrasingLiveContainmentIntegrationTest.js'], 'masterStep126GovernedCompassPathCandidatePhrasingLiveContainmentIntegrationTest']
['proof-check-051', 'node', ['tests/masterStep125GovernedCompassPathCandidatePhrasingDryRunIntegrationTest.js'], 'masterStep125GovernedCompassPathCandidatePhrasingDryRunIntegrationTest']
['proof-check-052', 'node', ['tests/masterStep124GovernedCompassPathCandidatePhrasingIntegrationGateTest.js'], 'masterStep124GovernedCompassPathCandidatePhrasingIntegrationGateTest']
['proof-check-053', 'node', ['tests/masterStep123FreshPromptRegressionStressForCompassCandidatePhrasingRefinementTest.js'], 'masterStep123FreshPromptRegressionStressForCompassCandidatePhrasingRefinementTest']
['proof-check-054', 'node', ['tests/masterStep122CompassCandidatePhrasingRefinementExpansionReadinessReviewTest.js'], 'masterStep122CompassCandidatePhrasingRefinementExpansionReadinessReviewTest']
['proof-check-055', 'node', ['tests/masterStep121CompassCandidatePhrasingRefinementRegressionTrustBoundaryStressTest.js'], 'masterStep121CompassCandidatePhrasingRefinementRegressionTrustBoundaryStressTest']
['proof-check-056', 'node', ['tests/masterStep120CompassCandidatePhrasingRefinementLiveContainmentTest.js'], 'masterStep120CompassCandidatePhrasingRefinementLiveContainmentTest']
['proof-check-057', 'node', ['tests/masterStep119ControlledCompassCandidatePhrasingRefinementDryIntegrationTest.js'], 'masterStep119ControlledCompassCandidatePhrasingRefinementDryIntegrationTest']
['proof-check-058', 'node', ['tests/masterStep118CandidateUseCaseSelectionGateTest.js'], 'masterStep118CandidateUseCaseSelectionGateTest']
['proof-check-059', 'node', ['tests/masterStep117ControlledLocalModelUseExpansionGateTest.js'], 'masterStep117ControlledLocalModelUseExpansionGateTest']
['proof-check-060', 'node', ['tests/masterStep116TrustDemoExternalReviewHandoffFreezePointTest.js'], 'masterStep116TrustDemoExternalReviewHandoffFreezePointTest']
['proof-check-061', 'node', ['tests/masterStep115TrustDemoExternalReviewFinalReadinessGateTest.js'], 'masterStep115TrustDemoExternalReviewFinalReadinessGateTest']
['proof-check-062', 'node', ['tests/masterStep114TrustDemoExternalReviewPacketCompletenessAuditTest.js'], 'masterStep114TrustDemoExternalReviewPacketCompletenessAuditTest']
['proof-check-063', 'node', ['tests/masterStep113TrustDemoExternalReviewPacketIndexTest.js'], 'masterStep113TrustDemoExternalReviewPacketIndexTest']
['proof-check-064', 'node', ['tests/masterStep112TrustDemoExternalReviewSubmissionGuardTest.js'], 'masterStep112TrustDemoExternalReviewSubmissionGuardTest']
['proof-check-065', 'node', ['tests/masterStep111TrustDemoReviewerRunbookTest.js'], 'masterStep111TrustDemoReviewerRunbookTest']
['proof-check-066', 'node', ['tests/masterStep110TrustDemoFailureModeReadinessTest.js'], 'masterStep110TrustDemoFailureModeReadinessTest']
['proof-check-067', 'node', ['tests/masterStep109TrustDemoTraceEvidenceWalkthroughTest.js'], 'masterStep109TrustDemoTraceEvidenceWalkthroughTest']
['proof-check-068', 'node', ['tests/masterStep108ReviewPackageClaimBoundaryAuditTest.js'], 'masterStep108ReviewPackageClaimBoundaryAuditTest']
['proof-check-069', 'node', ['tests/masterStep107TrustDemoReviewPackageTest.js'], 'masterStep107TrustDemoReviewPackageTest']
['proof-check-070', 'node', ['tests/masterStep106TrustDemoExplanationPackTest.js'], 'masterStep106TrustDemoExplanationPackTest']
['proof-check-071', 'node', ['tests/masterStep105TrustDemoHarnessStressTest.js'], 'masterStep105TrustDemoHarnessStressTest']
['proof-check-072', 'node', ['tests/masterStep104TrustDemoHarnessTest.js'], 'masterStep104TrustDemoHarnessTest']
['proof-check-073', 'node', ['tests/masterStep103FullCleanPassGateTest.js'], 'masterStep103FullCleanPassGateTest']
['proof-check-074', 'node', ['tests/masterStep102LocalModelCandidateRegressionBoundaryStressTest.js'], 'masterStep102LocalModelCandidateRegressionBoundaryStressTest']
['proof-check-075', 'node', ['tests/masterStep101LocalModelCandidateQualityStressTest.js'], 'masterStep101LocalModelCandidateQualityStressTest']
['proof-check-076', 'node', ['tests/masterStep100ProofConsolidationBeforeModelUseExpansionTest.js'], 'masterStep100ProofConsolidationBeforeModelUseExpansionTest']
['proof-check-077', 'node', ['tests/masterStep99LiveLocalModelContainmentStressTest.js'], 'masterStep99LiveLocalModelContainmentStressTest']
['proof-check-078', 'node', ['tests/masterStep98OllamaLiveLocalCallContainmentTest.js'], 'masterStep98OllamaLiveLocalCallContainmentTest']
['proof-check-079', 'node', ['tests/masterStep97OllamaAdapterDryRunShellTest.js'], 'masterStep97OllamaAdapterDryRunShellTest']
['proof-check-080', 'node', ['tests/masterStep96Patch08OllamaLocalRunnerSafetyLockTest.js'], 'masterStep96Patch08OllamaLocalRunnerSafetyLockTest']
['proof-check-081', 'node', ['tests/masterStep96Patch07LocalApiPersonalSafetyDesignLockTest.js'], 'masterStep96Patch07LocalApiPersonalSafetyDesignLockTest']
['proof-check-082', 'node', ['tests/masterStep96Patch06HeavyLocalApiReadinessStressGateTest.js'], 'masterStep96Patch06HeavyLocalApiReadinessStressGateTest']
['proof-check-083', 'node', ['tests/masterStep96Patch05LocalApiReadinessProofGateTest.js'], 'masterStep96Patch05LocalApiReadinessProofGateTest']
['proof-check-084', 'node', ['tests/masterStep96Patch04CrossWindowProofContinuityTest.js'], 'masterStep96Patch04CrossWindowProofContinuityTest']
['proof-check-085', 'node', ['tests/masterStep96Patch03ProofOrganizationApiReadinessDeferralTest.js'], 'masterStep96Patch03ProofOrganizationApiReadinessDeferralTest']
['proof-check-086', 'node', ['tests/masterStep96Patch02CoverageExpansionRegressionLockTest.js'], 'masterStep96Patch02CoverageExpansionRegressionLockTest']
['proof-check-087', 'node', ['tests/masterStep96Patch01ScenarioCoverageMatrixTest.js'], 'masterStep96Patch01ScenarioCoverageMatrixTest']
['proof-check-088', 'node', ['tests/masterStep96Patch00BoundaryVariantMixedStressTest.js'], 'masterStep96Patch00BoundaryVariantMixedStressTest']
['proof-check-089', 'node', ['tests/masterStep96RelationalBelongingBehaviorStressTest.js'], 'masterStep96RelationalBelongingBehaviorStressTest']
['proof-check-090', 'node', ['tests/masterStep95BehaviorStressBoundaryStabilizationTest.js'], 'masterStep95BehaviorStressBoundaryStabilizationTest']
['proof-check-091', 'node', ['tests/masterStep93ContextObjectQualityGateStabilizationTest.js'], 'masterStep93ContextObjectQualityGateStabilizationTest']
['proof-check-092', 'node', ['tests/masterStep93FreshFuzzStabilizationTest.js'], 'masterStep93FreshFuzzStabilizationTest']
['proof-check-093', 'node', ['tests/masterStep92DoylePlacementMeaningChainExpansionTest.js'], 'masterStep92DoylePlacementMeaningChainExpansionTest']
['proof-check-094', 'node', ['tests/masterStep91ExpressionPreservationRestoreEvidenceBindingTest.js'], 'masterStep91ExpressionPreservationRestoreEvidenceBindingTest']
['proof-check-095', 'node', ['tests/masterStep89ContextBeforeRouteSemanticAttachmentTest.js'], 'masterStep89ContextBeforeRouteSemanticAttachmentTest']
['proof-check-096', 'node', ['tests/healthCheck.js'], 'healthCheck']
['proof-check-097', 'node', ['tests/fullPackageFuzzTest.js'], 'fullPackageFuzzTest']
*/
const commands = commandRegistry.commands.map((entry) => [
  entry.id, entry.bin, entry.args, entry.technical_name
]);

function sha256File(filePath){
  const hash = crypto.createHash('sha256');
  hash.update(fs.readFileSync(filePath));
  return hash.digest('hex');
}

function runCommand(displayName, bin, args, technicalName){
  const name = displayName;
  console.error(`[proof] running ${displayName}`);
  const started = new Date().toISOString();
  const timeoutMs = name === 'fullPackageFuzzTest' ? 240000 : 120000;
  const stdoutPath = path.join(logsDir, `${name}.stdout.tmp`);
  const stderrPath = path.join(logsDir, `${name}.stderr.tmp`);
  const outFd = fs.openSync(stdoutPath, 'w');
  const errFd = fs.openSync(stderrPath, 'w');
  let proc;
  try {
    proc = spawnSync(bin, args, {
      cwd: PROJECT_ROOT,
      encoding: 'utf8',
      timeout: timeoutMs,
      maxBuffer: 1024 * 1024 * 8,
      env: { ...process.env, ATLAS_DISABLE_TRACE_WRITE: '1' },
      stdio: ['ignore', outFd, errFd]
    });
  } finally {
    fs.closeSync(outFd);
    fs.closeSync(errFd);
  }
  const finished = new Date().toISOString();
  const stdout = fs.existsSync(stdoutPath) ? fs.readFileSync(stdoutPath, 'utf8') : '';
  const stderr = fs.existsSync(stderrPath) ? fs.readFileSync(stderrPath, 'utf8') : '';
  try { fs.unlinkSync(stdoutPath); } catch {}
  try { fs.unlinkSync(stderrPath); } catch {}
  const log = [
    `$ ${bin} ${displayName}`,
    `timeout_ms=${timeoutMs}`,
    `timed_out=${proc && proc.error && proc.error.code === 'ETIMEDOUT' ? 'true' : 'false'}`,
    `exit_code=${proc.status}`,
    '--- stdout ---',
    stdout || '',
    '--- stderr ---',
    stderr || (proc && proc.error && proc.error.message ? proc.error.message : '') || ''
  ].join('\n');
  const logPath = path.join(logsDir, `${name}.log`);
  fs.writeFileSync(logPath, log);
  return { name: displayName, technical_name: technicalName, command: `${bin} ${displayName}`, technical_command_withheld_from_manifest: true, started, finished, timeout_ms: timeoutMs, timed_out: Boolean(proc && proc.error && proc.error.code === 'ETIMEDOUT'), exit_code: proc.status, signal: proc.signal, passed: proc.status === 0, log: path.relative(PROJECT_ROOT, logPath) };
}

// ---------------------------------------------------------------------------
// Charter120: parallel check execution (Steve's order "do 1 and 2" — option 1).
// The SAME 106 checks run with the SAME verdict logic as runCommand above;
// only the waiting is concurrent. Each check is a separate OS process with
// its own uniquely-named capture files, and the independence audit showed:
//   - writes go to mkdtemp dirs, per-check uniquely-named files, or
//     self-contained create-then-delete inside the check — no two checks
//     share a mutable path;
//   - regenerated "proof artifact" files are byte-identical on re-run, so
//     read/write adjacency between checks is order-independent;
//   - no check deletes a file another check needs.
// Fail-closed: a check that crashes, never answers, or yields no result is
// recorded as UNVERIFIED (passed:false), never as passed. The run is complete
// only when all 106 slots hold a result.
//
// Concurrency is matched to the machine: the checks are CPU-bound (each is
// a node process doing hashing and pipeline work), so more lanes than CPUs
// just makes every check slower — measured 5-6x per-check slowdown at 6
// lanes on 2 CPUs, for a wall clock barely better than sequential. Lanes =
// CPU count keeps every lane at full speed; the wall clock then approaches
// sum(check times) / CPUs, the honest floor for CPU-bound work.
const PARALLEL_CONCURRENCY = Math.max(2, os.cpus().length);

function failClosedCommandResult(displayName, bin, technicalName, reason){
  const started = new Date().toISOString();
  const timeoutMs = displayName === 'fullPackageFuzzTest' ? 240000 : 120000;
  const log = [
    `$ ${bin} ${displayName}`,
    `timeout_ms=${timeoutMs}`,
    `timed_out=false`,
    `exit_code=null`,
    '--- stdout ---',
    '',
    '--- stderr ---',
    `RUNNER ERROR — fail-closed, this check is UNVERIFIED (never passed): ${reason}`
  ].join('\n');
  const logPath = path.join(logsDir, `${displayName}.log`);
  try { fs.writeFileSync(logPath, log); } catch (_) { /* the failure is already recorded in the result */ }
  return { name: displayName, technical_name: technicalName, command: `${bin} ${displayName}`, technical_command_withheld_from_manifest: true, started, finished: new Date().toISOString(), timeout_ms: timeoutMs, timed_out: false, exit_code: null, signal: null, passed: false, log: path.relative(PROJECT_ROOT, logPath) };
}

function runCommandAsync(displayName, bin, args, technicalName){
  return new Promise((resolve) => {
    const name = displayName;
    console.error(`[proof] running ${displayName}`);
    const started = new Date().toISOString();
    const timeoutMs = name === 'fullPackageFuzzTest' ? 240000 : 120000;
    const stdoutPath = path.join(logsDir, `${name}.stdout.tmp`);
    const stderrPath = path.join(logsDir, `${name}.stderr.tmp`);
    const finish = (exitCode, signal, timedOut, spawnError) => {
      const finished = new Date().toISOString();
      const stdout = fs.existsSync(stdoutPath) ? fs.readFileSync(stdoutPath, 'utf8') : '';
      const stderr = fs.existsSync(stderrPath) ? fs.readFileSync(stderrPath, 'utf8') : '';
      try { fs.unlinkSync(stdoutPath); } catch (_) {}
      try { fs.unlinkSync(stderrPath); } catch (_) {}
      const log = [
        `$ ${bin} ${displayName}`,
        `timeout_ms=${timeoutMs}`,
        `timed_out=${timedOut ? 'true' : 'false'}`,
        `exit_code=${exitCode}`,
        '--- stdout ---',
        stdout || '',
        '--- stderr ---',
        stderr || (spawnError ? `RUNNER ERROR — fail-closed, this check is UNVERIFIED (never passed): ${String((spawnError && spawnError.message) || spawnError)}` : '') || ''
      ].join('\n');
      const logPath = path.join(logsDir, `${name}.log`);
      try { fs.writeFileSync(logPath, log); } catch (_) {}
      resolve({ name: displayName, technical_name: technicalName, command: `${bin} ${displayName}`, technical_command_withheld_from_manifest: true, started, finished, timeout_ms: timeoutMs, timed_out: timedOut, exit_code: exitCode, signal: signal, passed: exitCode === 0 && !spawnError, log: path.relative(PROJECT_ROOT, logPath) });
    };
    let outFd;
    let errFd;
    try {
      outFd = fs.openSync(stdoutPath, 'w');
      errFd = fs.openSync(stderrPath, 'w');
    } catch (err) {
      resolve(failClosedCommandResult(displayName, bin, technicalName, 'could not open capture files: ' + String((err && err.message) || err)));
      return;
    }
    let child;
    try {
      child = spawn(bin, args, {
        cwd: PROJECT_ROOT,
        env: { ...process.env, ATLAS_DISABLE_TRACE_WRITE: '1' },
        stdio: ['ignore', outFd, errFd]
      });
    } catch (err) {
      try { fs.closeSync(outFd); } catch (_) {}
      try { fs.closeSync(errFd); } catch (_) {}
      resolve(failClosedCommandResult(displayName, bin, technicalName, 'spawn threw: ' + String((err && err.message) || err)));
      return;
    }
    // The child inherited its own copies of the fds; the parent's can close.
    try { fs.closeSync(outFd); } catch (_) {}
    try { fs.closeSync(errFd); } catch (_) {}
    let timedOut = false;
    let settled = false;
    const done = (exitCode, signal, spawnError) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (hardStop) clearTimeout(hardStop);
      finish(exitCode, signal, timedOut, spawnError);
    };
    const timer = setTimeout(() => {
      timedOut = true;
      try { child.kill('SIGKILL'); } catch (_) {}
    }, timeoutMs);
    if (timer.unref) timer.unref();
    // Backstop: if the child never reports back even after SIGKILL, do not
    // hang the run — record it unverified and move on.
    const hardStop = setTimeout(() => done(null, null, null), timeoutMs + 15000);
    if (hardStop.unref) hardStop.unref();
    child.on('error', (err) => done(null, null, err));
    child.on('close', (code, signal) => done(code, signal, null));
  });
}

async function runCommandsParallel(concurrency){
  const limit = Math.max(1, Math.min(commands.length, Math.floor(concurrency) || PARALLEL_CONCURRENCY));
  const results = new Array(commands.length);
  let next = 0;
  const lane = async () => {
    for (;;) {
      const i = next++;
      if (i >= commands.length) return;
      const [displayName, bin, args, technicalName] = commands[i];
      try {
        results[i] = await runCommandAsync(displayName, bin, args, technicalName);
      } catch (err) {
        results[i] = failClosedCommandResult(displayName, bin, technicalName, 'parallel runner threw: ' + String((err && err.message) || err));
      }
    }
  };
  await Promise.all(Array.from({ length: limit }, () => lane()));
  // A hole in the results would be a silent skip — fail loud instead.
  for (let i = 0; i < commands.length; i++) {
    if (!results[i]) {
      results[i] = failClosedCommandResult(commands[i][0], commands[i][1], commands[i][3], 'parallel runner left no result for this check');
    }
  }
  return results;
}

function walk(dir){
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })){
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}

// Charter118: guard attestation — structural vs semantic labels (bytes's
// finding) plus per-check independence attestation (miacollective's finding).
// A structural guard checks that the world still matches a recorded hard
// invariant (hashes, registries, ledgers, contracts). A semantic guard
// compares behavior against expected outputs. Each check also records what
// verified it and whether that verifier ever trained on the guarded model's
// output — independence re-attested per check, per run. Labels only; never
// changes pass/fail.
function classifyGuardKind(name, kinds) {
  const rules = (kinds && kinds.rules) || [];
  for (const rule of rules) {
    if (rule && typeof rule.match === "string" && rule.match && String(name).indexOf(rule.match) >= 0) {
      return { guard_kind: rule.kind, kind_basis: "name-pattern:" + rule.match + " (" + (rule.basis || "") + ")" };
    }
  }
  return { guard_kind: (kinds && kinds.default) || "unlabeled", kind_basis: "no pattern matched — listed, not hidden" };
}
function buildGuardAttestation(commandResults, kinds, indep) {
  const overrides = (indep && indep.overrides) || {};
  const def = (indep && indep.default) || {};
  return (commandResults || []).map((r) => {
    const technicalName = r.technical_name || r.name;
    const kind = classifyGuardKind(technicalName, kinds);
    const ov = overrides[technicalName] || overrides[r.name] || null;
    return {
      check: r.name,
      technical_name: r.technical_name || null,
      guard_kind: kind.guard_kind,
      kind_basis: kind.kind_basis,
      kind_note: "Heuristic name-pattern label, not a proof of the check's nature.",
      verified_by: (ov && ov.verified_by) || def.verified_by || "unrecorded",
      verifier_trained_on_guarded_output: (ov && ("verifier_trained_on_guarded_output" in ov)) ? ov.verifier_trained_on_guarded_output : (def.verifier_trained_on_guarded_output === true),
      independence_basis: (ov && ov.basis) || def.basis || "unrecorded"
    };
  });
}

function runPreflight(){
  // Clear stale per-check logs at the start of an actual run (not at require
  // time — see the note at the top of this file).
  for (const file of fs.readdirSync(logsDir)) {
    if (file.endsWith('.log')) fs.unlinkSync(path.join(logsDir, file));
  }
  const authority = assertCurrentProofTargetAuthority({ projectRoot: PROJECT_ROOT, commandCount: commands.length });  if (!authority.ok) {
    throw new Error(`Current proof target authority failed: ${authority.failures.join('; ')}`);
  }
  const freshness = assertProofInvocationFreshness({ projectRoot: PROJECT_ROOT, commandCount: commands.length });
  const canonical = assertCanonicalProofContract({ projectRoot: PROJECT_ROOT, commandCount: commands.length });
  const displayContract = assertProofDisplayCalloutContract({ projectRoot: PROJECT_ROOT, commands, commandCount: commands.length });
  const currentTarget = { current_manifest: canonical.currentManifest, currentKeeper: canonical.currentKeeper, sourceKeeper: canonical.sourceKeeper, currentStep: canonical.currentStep };
  const removedStaleManifests = cleanStaleCurrentManifestOutputs(PROJECT_ROOT, currentTarget.current_manifest);
  console.log(`[proof invocation] keeper=${canonical.currentKeeper} step=${canonical.currentStep} manifest=${canonical.currentManifest} root=${freshness.actualPackageRoot} commands=${canonical.expectedCommands} contract=canonical display=decallouted`);
  // Charter121: capture the runtime wiring BEFORE any check runs (the cook,
  // not just the ingredients — neo_konsi_s2bw, "the checkpoint is not the
  // whole local model"). A second capture lands in the manifest at write
  // time; the start/finish diff is informational only.
  const runtimeFingerprintStart = captureRuntimeFingerprint(PROJECT_ROOT);
  return { authority, freshness, canonical, displayContract, currentTarget, removedStaleManifests, runtimeFingerprintStart };
}

function finishManifest(pre, commandResults){
  const authority = pre.authority;
  const freshness = pre.freshness;
  const canonical = pre.canonical;
  const currentTarget = pre.currentTarget;
  const removedStaleManifests = pre.removedStaleManifests;
  const allFiles = walk(PROJECT_ROOT);
  const nestedArchives = allFiles.filter(f => /\.(zip|7z|rar|tar|gz)$/i.test(f));
  const requiredFiles = [
    'runtime/proof/KeeperPromotionGate.js',
    'runtime/proof/PROOF_COVERAGE_REGISTRY.json',
    'runtime/proof/PROOF_TEST_REGISTRY.json',
    'CA/Continuity_Architecture/.obsidian/plugins/continuity-interface/AtlasProofBridge.js',
    'tests/masterStep170ProofOrchestratorIntegrityStateConsolidationKeeperPromotionGateTest.js',
    'runtime/proof/LocalProofOrchestrator.js',
    'runtime/backend/LocalProofOrchestratorService.js',
    'proof/runProofOrchestrator.js',
    'tests/masterStep169LocalProofOrchestratorIncrementalClosureGateTest.js',
    'runtime/proof/MASTERSTEP169_LOCAL_PROOF_ORCHESTRATOR_INCREMENTAL_CLOSURE_GATE.md',
    'runtime/proof/MASTERSTEP169_LOCAL_PROOF_ORCHESTRATOR_INCREMENTAL_CLOSURE_GATE.json',
    'docs/MASTERSTEP169_LOCAL_PROOF_ORCHESTRATOR_INCREMENTAL_CLOSURE_GATE.md',
    'docs/LOCAL_PROOF_ORCHESTRATOR_INCREMENTAL_CLOSURE_GATE.md',
    'runtime/governance/LearningGateDecisionClarityDuplicateNodePrevention.js',
    'tests/masterStep168LearningGateDecisionClarityDuplicateNodePreventionTest.js',
    'runtime/proof/MASTERSTEP168_LEARNING_GATE_DECISION_CLARITY_DUPLICATE_NODE_PREVENTION.md',
    'runtime/proof/MASTERSTEP168_LEARNING_GATE_DECISION_CLARITY_DUPLICATE_NODE_PREVENTION.json',
    'docs/MASTERSTEP168_LEARNING_GATE_DECISION_CLARITY_DUPLICATE_NODE_PREVENTION.md',
    'docs/LEARNING_GATE_DECISION_CLARITY_DUPLICATE_NODE_PREVENTION.md',
    'runtime/governance/MatrixGrowthGovernanceContract.js',
    'runtime/backend/LearningCenterReviewService.js',
    'tests/masterStep167MatrixGrowthGovernanceControlledExpansionContractTest.js',
    'runtime/proof/MASTERSTEP167_MATRIX_GROWTH_GOVERNANCE_CONTROLLED_EXPANSION_CONTRACT.md',
    'runtime/proof/MASTERSTEP167_MATRIX_GROWTH_GOVERNANCE_CONTROLLED_EXPANSION_CONTRACT.json',
    'docs/MASTERSTEP167_MATRIX_GROWTH_GOVERNANCE_CONTROLLED_EXPANSION_CONTRACT.md',
    'docs/MATRIX_GROWTH_GOVERNANCE_CONTROLLED_EXPANSION_CONTRACT.md',
    'runtime/review/PublicDemoShellBoundaryPlan.js',
    'tests/masterStep163PublicDemoShellBoundaryPlanTest.js',
    'runtime/proof/MASTERSTEP163_PUBLIC_DEMO_SHELL_BOUNDARY_PLAN.md',
    'runtime/proof/MASTERSTEP163_PUBLIC_DEMO_SHELL_BOUNDARY_PLAN.json',
    'docs/MASTERSTEP163_PUBLIC_DEMO_SHELL_BOUNDARY_PLAN.md',
    'docs/PUBLIC_DEMO_SHELL_BOUNDARY_PLAN.md',
    'public_demo_shell/README.md',
    'public_demo_shell/app.py',
    'public_demo_shell/requirements.txt',
    'public_demo_shell/DEMO_BOUNDARY.md',
    'public_demo_shell/FEEDBACK_GUIDE.md',
    'public_demo_shell/SAFE_SYNTHETIC_EXAMPLES.md',
    'public_demo_shell/POSTING_WALKTHROUGH.md',
    'public_demo_shell/DEMO_MANIFEST.json',
    'runtime/review/CommunityReviewPacketAssemblyExposureLock.js',
    'tests/masterStep162CommunityReviewPacketAssemblyExposureLockTest.js',
    'runtime/proof/MASTERSTEP162_COMMUNITY_REVIEW_PACKET_ASSEMBLY_EXPOSURE_LOCK.md',
    'runtime/proof/MASTERSTEP162_COMMUNITY_REVIEW_PACKET_ASSEMBLY_EXPOSURE_LOCK.json',
    'docs/MASTERSTEP162_COMMUNITY_REVIEW_PACKET_ASSEMBLY_EXPOSURE_LOCK.md',
    'docs/COMMUNITY_REVIEW_PACKET_ASSEMBLY_EXPOSURE_LOCK.md',
    'community_review_packet/README_SAFE_REVIEW_PACKET.md',
    'community_review_packet/WHAT_ATLAS_COMPASS_IS.md',
    'community_review_packet/WHAT_THIS_IS_NOT.md',
    'community_review_packet/CLAIM_BOUNDARY.md',
    'community_review_packet/SAFE_DEMO_WALKTHROUGH.md',
    'community_review_packet/REVIEWER_FEEDBACK_GUIDE.md',
    'community_review_packet/EVIDENCE_SUMMARY_REDACTED.md',
    'community_review_packet/REDACTION_AND_EXPOSURE_LOCK.md',
    'community_review_packet/DO_NOT_SHARE.md',
    'community_review_packet/PACKET_MANIFEST.json',
    'runtime/proof/ProofDisplayCalloutContract.js',
    'tests/masterStep161ProofDisplayCalloutFinalizationTest.js',
    'runtime/proof/MASTERSTEP161_PROOF_DISPLAY_CALLOUT_FINALIZATION.md',
    'runtime/proof/MASTERSTEP161_PROOF_DISPLAY_CALLOUT_FINALIZATION.json',
    'docs/MASTERSTEP161_PROOF_DISPLAY_CALLOUT_FINALIZATION.md',
    'docs/PROOF_DISPLAY_CALLOUT_FINALIZATION.md',
    'runtime/proof/CanonicalProofContract.js',
    'runtime/proof/CURRENT_PROOF_CONTRACT.json',
    'tests/masterStep160CanonicalProofContractFinalizationTest.js',
    'runtime/proof/MASTERSTEP160_CANONICAL_PROOF_CONTRACT_FINALIZATION.md',
    'runtime/proof/MASTERSTEP160_CANONICAL_PROOF_CONTRACT_FINALIZATION.json',
    'docs/MASTERSTEP160_CANONICAL_PROOF_CONTRACT_FINALIZATION.md',
    'docs/CANONICAL_PROOF_CONTRACT_FINALIZATION.md',
    'runtime/proof/ProofInvocationFreshnessGuard.js',
    'tests/masterStep159ProofInvocationFreshnessRegressionGuardTest.js',
    'runtime/proof/MASTERSTEP159_PROOF_INVOCATION_FRESHNESS_REGRESSION_GUARD.md',
    'runtime/proof/MASTERSTEP159_PROOF_INVOCATION_FRESHNESS_REGRESSION_GUARD.json',
    'docs/MASTERSTEP159_PROOF_INVOCATION_FRESHNESS_REGRESSION_GUARD.md',
    'docs/PROOF_INVOCATION_FRESHNESS_REGRESSION_GUARD.md',
    'runtime/proof/CurrentProofTargetAuthority.js',
    'tests/masterStep158ProofRunnerCurrentStateAuthorityLockTest.js',
    'runtime/proof/MASTERSTEP158_PROOF_RUNNER_CURRENT_STATE_AUTHORITY_LOCK.md',
    'runtime/proof/MASTERSTEP158_PROOF_RUNNER_CURRENT_STATE_AUTHORITY_LOCK.json',
    'docs/MASTERSTEP158_PROOF_RUNNER_CURRENT_STATE_AUTHORITY_LOCK.md',
    'docs/PROOF_RUNNER_CURRENT_STATE_AUTHORITY_LOCK.md',
    'runtime/review/CommunityReviewerFeedbackIntake.js',
    'tests/masterStep156CommunityReviewerFeedbackIntakeBoundaryTest.js',
    'runtime/proof/MASTERSTEP156_COMMUNITY_REVIEWER_FEEDBACK_INTAKE_BOUNDARY.md',
    'runtime/proof/MASTERSTEP156_COMMUNITY_REVIEWER_FEEDBACK_INTAKE_BOUNDARY.json',
    'docs/MASTERSTEP156_COMMUNITY_REVIEWER_FEEDBACK_INTAKE_BOUNDARY.md',
    'docs/COMMUNITY_REVIEWER_FEEDBACK_INTAKE_BOUNDARY.md',
    'runtime/review/CommunityDemoHarnessEvidencePack.js',
    'tests/masterStep155CommunityDemoHarnessEvidencePackTest.js',
    'runtime/proof/MASTERSTEP155_COMMUNITY_DEMO_HARNESS_EVIDENCE_PACK.md',
    'runtime/proof/MASTERSTEP155_COMMUNITY_DEMO_HARNESS_EVIDENCE_PACK.json',
    'docs/MASTERSTEP155_COMMUNITY_DEMO_HARNESS_EVIDENCE_PACK.md',
    'docs/COMMUNITY_DEMO_HARNESS_EVIDENCE_PACK.md',
    'runtime/review/CommunityReviewReadinessPacket.js',
    'tests/masterStep154CommunityReviewReadinessPacketTest.js',
    'runtime/proof/MASTERSTEP154_COMMUNITY_REVIEW_READINESS_PACKET.md',
    'runtime/proof/MASTERSTEP154_COMMUNITY_REVIEW_READINESS_PACKET.json',
    'docs/MASTERSTEP154_COMMUNITY_REVIEW_READINESS_PACKET.md',
    'docs/COMMUNITY_REVIEW_READINESS_PACKET.md',
    'runtime/safety/HarmBoundaryRegressionUnsafeAssistanceRefusalProof.js',
    'tests/masterStep152HarmBoundaryRegressionUnsafeAssistanceRefusalProofTest.js',
    'runtime/proof/MASTERSTEP152_HARM_BOUNDARY_REGRESSION_UNSAFE_ASSISTANCE_REFUSAL_PROOF.md',
    'runtime/proof/MASTERSTEP152_HARM_BOUNDARY_REGRESSION_UNSAFE_ASSISTANCE_REFUSAL_PROOF.json',
    'docs/MASTERSTEP152_HARM_BOUNDARY_REGRESSION_UNSAFE_ASSISTANCE_REFUSAL_PROOF.md',
    'docs/HARM_BOUNDARY_REGRESSION_UNSAFE_ASSISTANCE_REFUSAL_PROOF.md',
    'runtime/understanding/PositiveStateMatrixFreezeKeeperBoundaryAudit.js',
    'tests/masterStep151PositiveStateMatrixFreezeKeeperBoundaryAuditTest.js',
    'runtime/proof/MASTERSTEP151_POSITIVE_STATE_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'runtime/proof/MASTERSTEP151_POSITIVE_STATE_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.json',
    'docs/MASTERSTEP151_POSITIVE_STATE_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'docs/POSITIVE_STATE_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'runtime/understanding/PositiveStateFreshRegression.js',
    'tests/masterStep149PositiveStateFreshRegressionTest.js',
    'runtime/proof/MASTERSTEP149_POSITIVE_STATE_FRESH_REGRESSION.md',
    'runtime/proof/MASTERSTEP149_POSITIVE_STATE_FRESH_REGRESSION.json',
    'docs/MASTERSTEP149_POSITIVE_STATE_FRESH_REGRESSION.md',
    'docs/POSITIVE_STATE_FRESH_REGRESSION.md',
    'runtime/proof/ProofStateCleanupCompatibilityMarkerConsolidation.js',
    'tests/masterStep148ProofStateCleanupCompatibilityMarkerConsolidationTest.js',
    'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md',
    'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.json',
    'runtime/proof/MASTERSTEP148_PROOF_STATE_CLEANUP_COMPATIBILITY_MARKER_CONSOLIDATION.md',
    'runtime/proof/MASTERSTEP148_PROOF_STATE_CLEANUP_COMPATIBILITY_MARKER_CONSOLIDATION.json',
    'docs/MASTERSTEP148_PROOF_STATE_CLEANUP_COMPATIBILITY_MARKER_CONSOLIDATION.md',
    'docs/PROOF_STATE_CLEANUP_COMPATIBILITY_MARKER_CONSOLIDATION.md',
    'runtime/understanding/TranslationPreservationMatrixFreezeKeeperBoundaryAudit.js',
    'tests/masterStep145TranslationPreservationMatrixFreezeKeeperBoundaryAuditTest.js',
    'runtime/proof/MASTERSTEP146_NEXT_MATRIX_MATURITY_TARGET_SELECTION.md',
    'runtime/proof/MASTERSTEP146_NEXT_MATRIX_MATURITY_TARGET_SELECTION.json',
    'docs/MASTERSTEP146_NEXT_MATRIX_MATURITY_TARGET_SELECTION.md',
    'runtime/proof/MASTERSTEP145_TRANSLATION_PRESERVATION_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'runtime/proof/MASTERSTEP145_TRANSLATION_PRESERVATION_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.json',
    'docs/MASTERSTEP145_TRANSLATION_PRESERVATION_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'docs/TRANSLATION_PRESERVATION_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'runtime/proof/ProofCompatibilityHelper.js',
    'tests/masterStep144ProofCompatibilityHelperLaterKeeperRecognitionTest.js',
    'runtime/proof/MASTERSTEP144_PROOF_COMPATIBILITY_HELPER_LATER_KEEPER_RECOGNITION.md',
    'runtime/proof/MASTERSTEP144_PROOF_COMPATIBILITY_HELPER_LATER_KEEPER_RECOGNITION.json',
    'docs/MASTERSTEP144_PROOF_COMPATIBILITY_HELPER_LATER_KEEPER_RECOGNITION.md',
    'docs/PROOF_COMPATIBILITY_HELPER_LATER_KEEPER_RECOGNITION.md',
    'tests/masterStep140NextMatrixMaturityTargetSelectionTest.js',
    'runtime/understanding/NextMatrixMaturityTargetSelectionAfterMixedContextFreeze.js',
    'runtime/proof/MASTERSTEP140_NEXT_MATRIX_MATURITY_TARGET_SELECTION.md',
    'runtime/proof/MASTERSTEP140_NEXT_MATRIX_MATURITY_TARGET_SELECTION.json',
    'docs/MASTERSTEP140_NEXT_MATRIX_MATURITY_TARGET_SELECTION.md',
    'docs/NEXT_MATRIX_MATURITY_TARGET_SELECTION_AFTER_MIXED_CONTEXT_FREEZE.md',
    'tests/masterStep139MixedContextMatrixFreezeKeeperBoundaryAuditTest.js',
    'runtime/understanding/MixedContextMatrixFreezeKeeperBoundaryAudit.js',
    'runtime/proof/MASTERSTEP139_MIXED_CONTEXT_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'runtime/proof/MASTERSTEP139_MIXED_CONTEXT_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.json',
    'docs/MASTERSTEP139_MIXED_CONTEXT_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'docs/MIXED_CONTEXT_MATRIX_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'tests/masterStep138CompassOutputPreservationForMixedContextMatrixTest.js',
    'runtime/understanding/MixedContextCompassOutputPreservationCheck.js',
    'runtime/proof/MASTERSTEP138_COMPASS_OUTPUT_PRESERVATION_FOR_MIXED_CONTEXT_MATRIX.md',
    'runtime/proof/MASTERSTEP138_COMPASS_OUTPUT_PRESERVATION_FOR_MIXED_CONTEXT_MATRIX.json',
    'docs/MASTERSTEP138_COMPASS_OUTPUT_PRESERVATION_FOR_MIXED_CONTEXT_MATRIX.md',
    'tests/masterStep136MixedContextEvidenceSeparationMatrixTest.js',
    'runtime/understanding/MixedContextEvidenceSeparationMatrix.js',
    'runtime/proof/MASTERSTEP136_MIXED_CONTEXT_EVIDENCE_SEPARATION_MATRIX.md',
    'runtime/proof/MASTERSTEP136_MIXED_CONTEXT_EVIDENCE_SEPARATION_MATRIX.json',
    'docs/MASTERSTEP136_MIXED_CONTEXT_EVIDENCE_SEPARATION_MATRIX.md',
    'docs/MIXED_CONTEXT_EVIDENCE_SEPARATION_MATRIX.md',
    'tests/masterStep134FirstMatrixExpansionFreezeKeeperBoundaryAuditTest.js',
    'runtime/understanding/FirstMatrixExpansionFreezeKeeperBoundaryAudit.js',
    'runtime/proof/MASTERSTEP134_FIRST_MATRIX_EXPANSION_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'runtime/proof/MASTERSTEP134_FIRST_MATRIX_EXPANSION_FREEZE_KEEPER_BOUNDARY_AUDIT.json',
    'docs/MASTERSTEP134_FIRST_MATRIX_EXPANSION_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'docs/FIRST_MATRIX_EXPANSION_FREEZE_KEEPER_BOUNDARY_AUDIT.md',
    'tests/masterStep133CompassOutputPreservationCheckForContextBeforeRouteMatrixTest.js',
    'runtime/understanding/ContextBeforeRouteCompassOutputPreservationCheck.js',
    'runtime/proof/MASTERSTEP133_COMPASS_OUTPUT_PRESERVATION_CHECK_FOR_CONTEXT_BEFORE_ROUTE_MATRIX.md',
    'runtime/proof/MASTERSTEP133_COMPASS_OUTPUT_PRESERVATION_CHECK_FOR_CONTEXT_BEFORE_ROUTE_MATRIX.json',
    'docs/MASTERSTEP133_COMPASS_OUTPUT_PRESERVATION_CHECK_FOR_CONTEXT_BEFORE_ROUTE_MATRIX.md',
    'docs/COMPASS_OUTPUT_PRESERVATION_CHECK_FOR_CONTEXT_BEFORE_ROUTE_MATRIX.md',
    'tests/masterStep132PrematureRoutePreventionFreshRegressionTest.js',
    'runtime/proof/MASTERSTEP132_PREMATURE_ROUTE_PREVENTION_FRESH_REGRESSION.md',
    'runtime/proof/MASTERSTEP132_PREMATURE_ROUTE_PREVENTION_FRESH_REGRESSION.json',
    'docs/MASTERSTEP132_PREMATURE_ROUTE_PREVENTION_FRESH_REGRESSION.md',
    'docs/PREMATURE_ROUTE_PREVENTION_FRESH_REGRESSION.md',
    'tests/masterStep131ContextBeforeRouteEvidenceSufficiencyMatrixTest.js',
    'runtime/understanding/ContextBeforeRouteEvidenceSufficiencyMatrix.js',
    'runtime/proof/MASTERSTEP131_CONTEXT_BEFORE_ROUTE_EVIDENCE_SUFFICIENCY_MATRIX.md',
    'runtime/proof/MASTERSTEP131_CONTEXT_BEFORE_ROUTE_EVIDENCE_SUFFICIENCY_MATRIX.json',
    'docs/MASTERSTEP131_CONTEXT_BEFORE_ROUTE_EVIDENCE_SUFFICIENCY_MATRIX.md',
    'docs/CONTEXT_BEFORE_ROUTE_EVIDENCE_SUFFICIENCY_MATRIX.md',
    'tests/masterStep130ContextBeforeRouteEvidenceMatrixTargetSelectionTest.js',
    'runtime/understanding/ContextBeforeRouteEvidenceMatrixTargetSelection.js',
    'runtime/proof/MASTERSTEP130_CONTEXT_BEFORE_ROUTE_EVIDENCE_MATRIX_TARGET_SELECTION.md',
    'runtime/proof/MASTERSTEP130_CONTEXT_BEFORE_ROUTE_EVIDENCE_MATRIX_TARGET_SELECTION.json',
    'docs/MASTERSTEP130_CONTEXT_BEFORE_ROUTE_EVIDENCE_MATRIX_TARGET_SELECTION.md',
    'docs/CONTEXT_BEFORE_ROUTE_EVIDENCE_MATRIX_TARGET_SELECTION.md',
    'tests/masterStep129MeaningMatrixExpansionReadinessGateTest.js',
    'runtime/understanding/MeaningMatrixExpansionReadinessGate.js',
    'runtime/proof/MASTERSTEP129_MEANING_MATRIX_EXPANSION_READINESS_GATE.md',
    'runtime/proof/MASTERSTEP129_MEANING_MATRIX_EXPANSION_READINESS_GATE.json',
    'docs/MASTERSTEP129_MEANING_MATRIX_EXPANSION_READINESS_GATE.md',
    'docs/MEANING_MATRIX_EXPANSION_READINESS_GATE.md',
    'tests/masterStep128CandidatePhrasingCapabilityFreezeExpansionBoundaryPreservationTest.js',
    'runtime/backend/adapter/CandidatePhrasingCapabilityFreezeExpansionBoundaryPreservation.js',
    'runtime/proof/MASTERSTEP128_CANDIDATE_PHRASING_CAPABILITY_FREEZE_EXPANSION_BOUNDARY_PRESERVATION.md',
    'runtime/proof/MASTERSTEP128_CANDIDATE_PHRASING_CAPABILITY_FREEZE_EXPANSION_BOUNDARY_PRESERVATION.json',
    'docs/MASTERSTEP128_CANDIDATE_PHRASING_CAPABILITY_FREEZE_EXPANSION_BOUNDARY_PRESERVATION.md',
    'docs/CANDIDATE_PHRASING_CAPABILITY_FREEZE_EXPANSION_BOUNDARY_PRESERVATION.md',
    'tests/masterStep126GovernedCompassPathCandidatePhrasingLiveContainmentIntegrationTest.js',
    'runtime/backend/adapter/GovernedCompassPathCandidatePhrasingLiveContainmentIntegration.js',
    'runtime/proof/MASTERSTEP126_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_LIVE_CONTAINMENT_INTEGRATION.md',
    'runtime/proof/MASTERSTEP126_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_LIVE_CONTAINMENT_INTEGRATION.json',
    'docs/MASTERSTEP126_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_LIVE_CONTAINMENT_INTEGRATION.md',
    'docs/GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_LIVE_CONTAINMENT_INTEGRATION.md',
    'tests/masterStep125GovernedCompassPathCandidatePhrasingDryRunIntegrationTest.js',
    'runtime/backend/adapter/GovernedCompassPathCandidatePhrasingDryRunIntegration.js',
    'runtime/proof/MASTERSTEP125_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_DRY_RUN_INTEGRATION.md',
    'runtime/proof/MASTERSTEP125_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_DRY_RUN_INTEGRATION.json',
    'docs/MASTERSTEP125_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_DRY_RUN_INTEGRATION.md',
    'docs/GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_DRY_RUN_INTEGRATION.md',
    'tests/masterStep124GovernedCompassPathCandidatePhrasingIntegrationGateTest.js',
    'runtime/backend/adapter/GovernedCompassPathCandidatePhrasingIntegrationGate.js',
    'runtime/proof/MASTERSTEP124_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_INTEGRATION_GATE.md',
    'runtime/proof/MASTERSTEP124_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_INTEGRATION_GATE.json',
    'docs/MASTERSTEP124_GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_INTEGRATION_GATE.md',
    'docs/GOVERNED_COMPASS_PATH_CANDIDATE_PHRASING_INTEGRATION_GATE.md',
    'tests/masterStep123FreshPromptRegressionStressForCompassCandidatePhrasingRefinementTest.js',
    'runtime/proof/MASTERSTEP123_FRESH_PROMPT_REGRESSION_STRESS_FOR_COMPASS_CANDIDATE_PHRASING_REFINEMENT.md',
    'runtime/proof/MASTERSTEP123_FRESH_PROMPT_REGRESSION_STRESS_FOR_COMPASS_CANDIDATE_PHRASING_REFINEMENT.json',
    'docs/MASTERSTEP123_FRESH_PROMPT_REGRESSION_STRESS_FOR_COMPASS_CANDIDATE_PHRASING_REFINEMENT.md',
    'docs/FRESH_PROMPT_REGRESSION_STRESS_FOR_COMPASS_CANDIDATE_PHRASING_REFINEMENT.md',
    'tests/masterStep122CompassCandidatePhrasingRefinementExpansionReadinessReviewTest.js',
    'runtime/proof/MASTERSTEP122_COMPASS_CANDIDATE_PHRASING_REFINEMENT_EXPANSION_READINESS_REVIEW.md',
    'runtime/proof/MASTERSTEP122_COMPASS_CANDIDATE_PHRASING_REFINEMENT_EXPANSION_READINESS_REVIEW.json',
    'docs/MASTERSTEP122_COMPASS_CANDIDATE_PHRASING_REFINEMENT_EXPANSION_READINESS_REVIEW.md',
    'docs/COMPASS_CANDIDATE_PHRASING_REFINEMENT_EXPANSION_READINESS_REVIEW.md',
    'tests/masterStep121CompassCandidatePhrasingRefinementRegressionTrustBoundaryStressTest.js',
    'runtime/proof/MASTERSTEP121_COMPASS_CANDIDATE_PHRASING_REFINEMENT_REGRESSION_TRUST_BOUNDARY_STRESS.md',
    'runtime/proof/MASTERSTEP121_COMPASS_CANDIDATE_PHRASING_REFINEMENT_REGRESSION_TRUST_BOUNDARY_STRESS.json',
    'docs/MASTERSTEP121_COMPASS_CANDIDATE_PHRASING_REFINEMENT_REGRESSION_TRUST_BOUNDARY_STRESS.md',
    'docs/COMPASS_CANDIDATE_PHRASING_REFINEMENT_REGRESSION_TRUST_BOUNDARY_STRESS.md',
    'tests/masterStep120CompassCandidatePhrasingRefinementLiveContainmentTest.js',
    'runtime/backend/adapter/CompassCandidatePhrasingRefinementLiveContainment.js',
    'runtime/proof/MASTERSTEP120_COMPASS_CANDIDATE_PHRASING_REFINEMENT_LIVE_CONTAINMENT_TEST.md',
    'runtime/proof/MASTERSTEP120_COMPASS_CANDIDATE_PHRASING_REFINEMENT_LIVE_CONTAINMENT_TEST.json',
    'docs/MASTERSTEP120_COMPASS_CANDIDATE_PHRASING_REFINEMENT_LIVE_CONTAINMENT_TEST.md',
    'docs/COMPASS_CANDIDATE_PHRASING_REFINEMENT_LIVE_CONTAINMENT_TEST.md',
    'tests/masterStep119ControlledCompassCandidatePhrasingRefinementDryIntegrationTest.js',
    'runtime/backend/adapter/CompassCandidatePhrasingRefinementDryIntegration.js',
    'runtime/proof/MASTERSTEP119_CONTROLLED_COMPASS_CANDIDATE_PHRASING_REFINEMENT_DRY_INTEGRATION.md',
    'runtime/proof/MASTERSTEP119_CONTROLLED_COMPASS_CANDIDATE_PHRASING_REFINEMENT_DRY_INTEGRATION.json',
    'docs/MASTERSTEP119_CONTROLLED_COMPASS_CANDIDATE_PHRASING_REFINEMENT_DRY_INTEGRATION.md',
    'docs/CONTROLLED_COMPASS_CANDIDATE_PHRASING_REFINEMENT_DRY_INTEGRATION.md',
    'tests/masterStep118CandidateUseCaseSelectionGateTest.js',
    'runtime/proof/MASTERSTEP118_CANDIDATE_USE_CASE_SELECTION_GATE.md',
    'runtime/proof/MASTERSTEP118_CANDIDATE_USE_CASE_SELECTION_GATE.json',
    'docs/MASTERSTEP118_CANDIDATE_USE_CASE_SELECTION_GATE.md',
    'docs/CANDIDATE_USE_CASE_SELECTION_GATE.md',
    'tests/masterStep117ControlledLocalModelUseExpansionGateTest.js',
    'runtime/proof/MASTERSTEP117_CONTROLLED_LOCAL_MODEL_USE_EXPANSION_GATE.md',
    'runtime/proof/MASTERSTEP117_CONTROLLED_LOCAL_MODEL_USE_EXPANSION_GATE.json',
    'docs/MASTERSTEP117_CONTROLLED_LOCAL_MODEL_USE_EXPANSION_GATE.md',
    'docs/CONTROLLED_LOCAL_MODEL_USE_EXPANSION_GATE.md',
    'tests/masterStep116TrustDemoExternalReviewHandoffFreezePointTest.js',
    'runtime/proof/MASTERSTEP116_TRUST_DEMO_EXTERNAL_REVIEW_HANDOFF_FREEZE_POINT.md',
    'runtime/proof/MASTERSTEP116_TRUST_DEMO_EXTERNAL_REVIEW_HANDOFF_FREEZE_POINT.json',
    'docs/MASTERSTEP116_TRUST_DEMO_EXTERNAL_REVIEW_HANDOFF_FREEZE_POINT.md',
    'docs/TRUST_DEMO_EXTERNAL_REVIEW_HANDOFF_FREEZE_POINT.md',
    'tests/masterStep115TrustDemoExternalReviewFinalReadinessGateTest.js',
    'runtime/proof/MASTERSTEP115_TRUST_DEMO_EXTERNAL_REVIEW_FINAL_READINESS_GATE.md',
    'runtime/proof/MASTERSTEP115_TRUST_DEMO_EXTERNAL_REVIEW_FINAL_READINESS_GATE.json',
    'docs/MASTERSTEP115_TRUST_DEMO_EXTERNAL_REVIEW_FINAL_READINESS_GATE.md',
    'docs/TRUST_DEMO_EXTERNAL_REVIEW_FINAL_READINESS_GATE.md',
    'tests/masterStep114TrustDemoExternalReviewPacketCompletenessAuditTest.js',
    'runtime/proof/MASTERSTEP114_TRUST_DEMO_EXTERNAL_REVIEW_PACKET_COMPLETENESS_AUDIT.md',
    'runtime/proof/MASTERSTEP114_TRUST_DEMO_EXTERNAL_REVIEW_PACKET_COMPLETENESS_AUDIT.json',
    'docs/MASTERSTEP114_TRUST_DEMO_EXTERNAL_REVIEW_PACKET_COMPLETENESS_AUDIT.md',
    'docs/TRUST_DEMO_EXTERNAL_REVIEW_PACKET_COMPLETENESS_AUDIT.md',
    'tests/masterStep113TrustDemoExternalReviewPacketIndexTest.js',
    'runtime/proof/MASTERSTEP113_TRUST_DEMO_EXTERNAL_REVIEW_PACKET_INDEX.md',
    'runtime/proof/MASTERSTEP113_TRUST_DEMO_EXTERNAL_REVIEW_PACKET_INDEX.json',
    'docs/MASTERSTEP113_TRUST_DEMO_EXTERNAL_REVIEW_PACKET_INDEX.md',
    'docs/TRUST_DEMO_EXTERNAL_REVIEW_PACKET_INDEX.md',
    'tests/masterStep113TrustDemoExternalReviewPacketIndexTest.js',
    'runtime/proof/MASTERSTEP113_TRUST_DEMO_EXTERNAL_REVIEW_PACKET_INDEX.md',
    'runtime/proof/MASTERSTEP113_TRUST_DEMO_EXTERNAL_REVIEW_PACKET_INDEX.json',
    'docs/MASTERSTEP113_TRUST_DEMO_EXTERNAL_REVIEW_PACKET_INDEX.md',
    'docs/TRUST_DEMO_EXTERNAL_REVIEW_PACKET_INDEX.md',
    'tests/masterStep112TrustDemoExternalReviewSubmissionGuardTest.js',
    'runtime/proof/MASTERSTEP112_TRUST_DEMO_EXTERNAL_REVIEW_SUBMISSION_GUARD.md',
    'runtime/proof/MASTERSTEP112_TRUST_DEMO_EXTERNAL_REVIEW_SUBMISSION_GUARD.json',
    'docs/MASTERSTEP112_TRUST_DEMO_EXTERNAL_REVIEW_SUBMISSION_GUARD.md',
    'docs/TRUST_DEMO_EXTERNAL_REVIEW_SUBMISSION_GUARD.md',
    'tests/masterStep111TrustDemoReviewerRunbookTest.js',
    'runtime/proof/MASTERSTEP111_TRUST_DEMO_REVIEWER_RUNBOOK.md',
    'runtime/proof/MASTERSTEP111_TRUST_DEMO_REVIEWER_RUNBOOK.json',
    'docs/MASTERSTEP111_TRUST_DEMO_REVIEWER_RUNBOOK.md',
    'docs/TRUST_DEMO_REVIEWER_RUNBOOK.md',
    'tests/masterStep110TrustDemoFailureModeReadinessTest.js',
    'runtime/proof/MASTERSTEP110_TRUST_DEMO_FAILURE_MODE_READINESS.md',
    'runtime/proof/MASTERSTEP110_TRUST_DEMO_FAILURE_MODE_READINESS.json',
    'docs/MASTERSTEP110_TRUST_DEMO_FAILURE_MODE_READINESS.md',
    'docs/TRUST_DEMO_FAILURE_MODE_READINESS.md',
    'tests/masterStep109TrustDemoTraceEvidenceWalkthroughTest.js',
    'runtime/proof/MASTERSTEP109_TRUST_DEMO_TRACE_EVIDENCE_WALKTHROUGH.md',
    'runtime/proof/MASTERSTEP109_TRUST_DEMO_TRACE_EVIDENCE_WALKTHROUGH.json',
    'docs/MASTERSTEP109_TRUST_DEMO_TRACE_EVIDENCE_WALKTHROUGH.md',
    'docs/TRUST_DEMO_TRACE_WALKTHROUGH.md',
    'tests/masterStep108ReviewPackageClaimBoundaryAuditTest.js',
    'runtime/proof/MASTERSTEP108_REVIEW_PACKAGE_CLAIM_BOUNDARY_AUDIT.md',
    'runtime/proof/MASTERSTEP108_REVIEW_PACKAGE_CLAIM_BOUNDARY_AUDIT.json',
    'docs/MASTERSTEP108_REVIEW_PACKAGE_CLAIM_BOUNDARY_AUDIT.md',
    'tests/masterStep107TrustDemoReviewPackageTest.js',
    'runtime/proof/MASTERSTEP107_TRUST_DEMO_REVIEW_PACKAGE.md',
    'runtime/proof/MASTERSTEP107_TRUST_DEMO_REVIEW_PACKAGE.json',
    'docs/MASTERSTEP107_TRUST_DEMO_REVIEW_PACKAGE.md',
    'docs/TRUST_DEMO_REVIEW_PACKAGE.md',
    'tests/masterStep106TrustDemoExplanationPackTest.js',
    'runtime/proof/MASTERSTEP106_TRUST_DEMO_EXPLANATION_PACK.md',
    'runtime/proof/MASTERSTEP106_TRUST_DEMO_EXPLANATION_PACK.json',
    'docs/MASTERSTEP106_TRUST_DEMO_EXPLANATION_PACK.md',
    'tests/masterStep105TrustDemoHarnessStressTest.js',
    'runtime/proof/MASTERSTEP105_TRUST_DEMO_HARNESS_STRESS_TEST.md',
    'runtime/proof/MASTERSTEP105_TRUST_DEMO_HARNESS_STRESS_TEST.json',
    'docs/MASTERSTEP105_TRUST_DEMO_HARNESS_STRESS_TEST.md',
    'tests/masterStep104TrustDemoHarnessTest.js',
    'runtime/proof/MASTERSTEP104_TRUST_DEMO_HARNESS.md',
    'runtime/proof/MASTERSTEP104_TRUST_DEMO_HARNESS.json',
    'docs/MASTERSTEP104_TRUST_DEMO_HARNESS.md',
    'tests/masterStep103FullCleanPassGateTest.js',
    'runtime/proof/MASTERSTEP103_FULL_CLEAN_PASS_GATE.md',
    'runtime/proof/MASTERSTEP103_FULL_CLEAN_PASS_GATE.json',
    'docs/MASTERSTEP103_FULL_CLEAN_PASS_GATE.md',
    'tests/masterStep102LocalModelCandidateRegressionBoundaryStressTest.js',
    'runtime/proof/MASTERSTEP102_LOCAL_MODEL_CANDIDATE_REGRESSION_BOUNDARY_STRESS.md',
    'runtime/proof/MASTERSTEP102_LOCAL_MODEL_CANDIDATE_REGRESSION_BOUNDARY_STRESS.json',
    'docs/MASTERSTEP102_LOCAL_MODEL_CANDIDATE_REGRESSION_BOUNDARY_STRESS.md',
    'tests/masterStep101LocalModelCandidateQualityStressTest.js',
    'runtime/proof/MASTERSTEP101_LOCAL_MODEL_CANDIDATE_QUALITY_STRESS.md',
    'runtime/proof/MASTERSTEP101_LOCAL_MODEL_CANDIDATE_QUALITY_STRESS.json',
    'docs/MASTERSTEP101_LOCAL_MODEL_CANDIDATE_QUALITY_STRESS.md',
    'tests/masterStep100ProofConsolidationBeforeModelUseExpansionTest.js',
    'runtime/proof/MASTERSTEP100_PROOF_CONSOLIDATION_BEFORE_MODEL_USE_EXPANSION.md',
    'runtime/proof/MASTERSTEP100_PROOF_CONSOLIDATION_BEFORE_MODEL_USE_EXPANSION.json',
    'docs/MASTERSTEP100_PROOF_CONSOLIDATION_BEFORE_MODEL_USE_EXPANSION.md',
    'tests/masterStep99LiveLocalModelContainmentStressTest.js',
    'runtime/proof/MASTERSTEP99_LIVE_LOCAL_MODEL_CONTAINMENT_STRESS.md',
    'runtime/proof/MASTERSTEP99_LIVE_LOCAL_MODEL_CONTAINMENT_STRESS.json',
    'docs/MASTERSTEP99_LIVE_LOCAL_MODEL_CONTAINMENT_STRESS.md',
    'runtime/backend/adapter/OllamaLiveLocalCallContainment.js',
    'tests/masterStep98OllamaLiveLocalCallContainmentTest.js',
    'runtime/proof/MASTERSTEP98_OLLAMA_LIVE_LOCAL_CALL_CONTAINMENT.md',
    'runtime/proof/MASTERSTEP98_OLLAMA_LIVE_LOCAL_CALL_CONTAINMENT.json',
    'docs/MASTERSTEP98_OLLAMA_LIVE_LOCAL_CALL_CONTAINMENT.md',
    'runtime/backend/adapter/OllamaAdapterDryRunShell.js',
    'tests/masterStep97OllamaAdapterDryRunShellTest.js',
    'runtime/proof/MASTERSTEP97_OLLAMA_ADAPTER_DRY_RUN_SHELL.md',
    'runtime/proof/MASTERSTEP97_OLLAMA_ADAPTER_DRY_RUN_SHELL.json',
    'docs/MASTERSTEP97_OLLAMA_ADAPTER_DRY_RUN_SHELL.md',
    'runtime/proof/OLLAMA_LOCAL_RUNNER_SAFETY_LOCK.md',
    'runtime/proof/OLLAMA_LOCAL_RUNNER_SAFETY_LOCK.json',
    'runtime/proof/MASTERSTEP96_PATCH08_OLLAMA_LOCAL_RUNNER_SAFETY_LOCK.md',
    'runtime/proof/MASTERSTEP96_PATCH08_OLLAMA_LOCAL_RUNNER_SAFETY_LOCK.json',
    'docs/MASTERSTEP96_PATCH08_OLLAMA_LOCAL_RUNNER_SAFETY_LOCK.md',
    'tests/masterStep96Patch08OllamaLocalRunnerSafetyLockTest.js',
    'runtime/proof/LOCAL_API_PERSONAL_SAFETY_DESIGN_LOCK.md',
    'runtime/proof/LOCAL_API_PERSONAL_SAFETY_DESIGN_LOCK.json',
    'runtime/proof/MASTERSTEP96_PATCH07_LOCAL_API_PERSONAL_SAFETY_DESIGN_LOCK.md',
    'runtime/proof/MASTERSTEP96_PATCH07_LOCAL_API_PERSONAL_SAFETY_DESIGN_LOCK.json',
    'docs/MASTERSTEP96_PATCH07_LOCAL_API_PERSONAL_SAFETY_DESIGN_LOCK.md',
    'tests/masterStep96Patch07LocalApiPersonalSafetyDesignLockTest.js',
    'runtime/proof/LOCAL_API_HEAVY_READINESS_STRESS_GATE.md',
    'runtime/proof/LOCAL_API_HEAVY_READINESS_STRESS_GATE.json',
    'runtime/proof/MASTERSTEP96_PATCH06_HEAVY_LOCAL_API_READINESS_STRESS_GATE.md',
    'runtime/proof/MASTERSTEP96_PATCH06_HEAVY_LOCAL_API_READINESS_STRESS_GATE.json',
    'docs/MASTERSTEP96_PATCH06_HEAVY_LOCAL_API_READINESS_STRESS_GATE.md',
    'tests/masterStep96Patch06HeavyLocalApiReadinessStressGateTest.js',
    'runtime/proof/LOCAL_API_READINESS_PROOF_GATE.md',
    'runtime/proof/LOCAL_API_READINESS_PROOF_GATE.json',
    'runtime/proof/MASTERSTEP96_PATCH05_LOCAL_API_READINESS_PROOF_GATE.md',
    'runtime/proof/MASTERSTEP96_PATCH05_LOCAL_API_READINESS_PROOF_GATE.json',
    'docs/MASTERSTEP96_PATCH05_LOCAL_API_READINESS_PROOF_GATE.md',
    'tests/masterStep96Patch05LocalApiReadinessProofGateTest.js',
    'runtime/proof/CROSS_WINDOW_PROOF_CONTINUITY_LEDGER.md',
    'runtime/proof/CROSS_WINDOW_PROOF_CONTINUITY_LEDGER.json',
    'runtime/proof/MASTERSTEP96_PATCH04_CROSS_WINDOW_PROOF_CONTINUITY.md',
    'runtime/proof/MASTERSTEP96_PATCH04_CROSS_WINDOW_PROOF_CONTINUITY.json',
    'docs/MASTERSTEP96_PATCH04_CROSS_WINDOW_PROOF_CONTINUITY.md',
    'tests/masterStep96Patch04CrossWindowProofContinuityTest.js',
    'docs/MASTERSTEP96_PATCH03_PROOF_ORGANIZATION_API_READINESS_DEFERRAL.md',
    'runtime/proof/MASTERSTEP96_PATCH03_PROOF_ORGANIZATION_API_READINESS_DEFERRAL.json',
    'runtime/proof/MASTERSTEP96_PATCH03_PROOF_ORGANIZATION_API_READINESS_DEFERRAL.md',
    'runtime/proof/PROJECT_WINDOW_PROOF_CONTINUITY_LEDGER.md',
    'runtime/proof/PROJECT_WINDOW_PROOF_CONTINUITY_LEDGER.json',
    'runtime/proof/ORGANIZATION_CLEANUP_AUDIT.md',
    'runtime/proof/ORGANIZATION_CLEANUP_AUDIT.json',
    'runtime/proof/API_READINESS_DEFERRAL_AUDIT.md',
    'runtime/proof/API_READINESS_DEFERRAL_AUDIT.json',
    'tests/masterStep96Patch03ProofOrganizationApiReadinessDeferralTest.js',
    'docs/MASTERSTEP96_PATCH02_COVERAGE_EXPANSION_REGRESSION_LOCK.md',
    'runtime/proof/MASTERSTEP96_PATCH02_COVERAGE_EXPANSION_REGRESSION_LOCK.json',
    'runtime/proof/MASTERSTEP96_PATCH02_COVERAGE_EXPANSION_REGRESSION_LOCK.md',
    'runtime/proof/MASTERSTEP96_PATCH01_SCENARIO_COVERAGE_MATRIX.md',
    'runtime/proof/MASTERSTEP96_PATCH01_SCENARIO_COVERAGE_MATRIX.json',
    'docs/MASTERSTEP96_PATCH01_SCENARIO_COVERAGE_MATRIX.md',
    'tests/masterStep96Patch01ScenarioCoverageMatrixTest.js',
    'runtime/proof/MASTERSTEP96_PATCH00_BOUNDARY_VARIANT_MIXED_STRESS.md',
    'runtime/proof/MASTERSTEP96_PATCH00_BOUNDARY_VARIANT_MIXED_STRESS.json',
    'docs/MASTERSTEP96_PATCH00_BOUNDARY_VARIANT_MIXED_STRESS.md',
    'tests/masterStep96Patch00BoundaryVariantMixedStressTest.js',
    'runtime/proof/MASTERSTEP96_RELATIONAL_BELONGING_BEHAVIOR_STRESS.md',
    'runtime/proof/MASTERSTEP96_RELATIONAL_BELONGING_BEHAVIOR_STRESS.json',
    'docs/MASTERSTEP96_RELATIONAL_BELONGING_BEHAVIOR_STRESS.md',
    'tests/masterStep96RelationalBelongingBehaviorStressTest.js',
    'runtime/proof/MASTERSTEP95_BEHAVIOR_STRESS_BOUNDARY_STABILIZATION.md',
    'runtime/proof/MASTERSTEP95_BEHAVIOR_STRESS_BOUNDARY_STABILIZATION.json',
    'docs/MASTERSTEP95_BEHAVIOR_STRESS_BOUNDARY_STABILIZATION.md',
    'tests/masterStep95BehaviorStressBoundaryStabilizationTest.js',
    'runtime/proof/ENGINEERING_PROOF_INDEX.md',
    'runtime/proof/CURRENT_PROOF_SUMMARY.md',
    'runtime/proof/PROOF_STATE.json',
    'runtime/proof/MASTERSTEP94_ENGINEERING_PROOF_STABILIZATION.md',
    'runtime/proof/MASTERSTEP94_ENGINEERING_PROOF_STABILIZATION.json',
    'docs/MASTERSTEP94_ENGINEERING_PROOF_STABILIZATION.md',
    'tests/masterStep94EngineeringProofStabilizationTest.js',
    'tests/TEST_RESULTS.md',
    'tests/VERSION_STATUS.json',
    'runtime/pipeline/ResponsePipeline.js',
    'runtime/understanding/ContextObjectConstructionEngine.js',
    'tests/masterStep93ContextObjectQualityGateStabilizationTest.js',
    'tests/masterStep93FreshFuzzStabilizationTest.js',
    'tests/masterStep93FullClosureKeeperReadinessTest.js',
    'docs/MASTERSTEP93_CONTEXT_OBJECT_QUALITY_GATE_STABILIZATION.md',
    'runtime/proof/MASTERSTEP93_CONTEXT_OBJECT_QUALITY_GATE_STABILIZATION.md',
    'runtime/proof/MASTERSTEP93_CONTEXT_OBJECT_QUALITY_GATE_STABILIZATION.json',
    'runtime/indexing/DoyleLivePlacementMapper.js',
    'tests/masterStep92DoylePlacementMeaningChainExpansionTest.js',
    'tests/masterStep92FullClosureKeeperReadinessTest.js',
    'docs/MASTERSTEP92_DOYLE_PLACEMENT_MEANING_CHAIN_EXPANSION.md',
    'runtime/proof/MASTERSTEP92_DOYLE_PLACEMENT_MEANING_CHAIN_EXPANSION.md',
    'runtime/proof/MASTERSTEP92_DOYLE_PLACEMENT_MEANING_CHAIN_EXPANSION.json',
    'tests/masterStep91ExpressionPreservationRestoreEvidenceBindingTest.js',
    'tests/masterStep91FullClosureKeeperReadinessTest.js',
    'tests/masterStep90RestorationPrincipleGovernorTest.js',
    'tests/masterStep90FullClosureKeeperReadinessTest.js',
    'tests/masterStep89ContextBeforeRouteSemanticAttachmentTest.js',
    'tests/masterStep89FullClosureKeeperReadinessTest.js',
    'docs/MASTERSTEP90_RESTORATION_PRINCIPLE_GOVERNOR.md',
    'runtime/proof/MASTERSTEP90_RESTORATION_PRINCIPLE_GOVERNOR.md',
    'runtime/proof/MASTERSTEP91_EXPRESSION_PRESERVATION_RESTORE_EVIDENCE_BINDING.md',
    'runtime/proof/MASTERSTEP91_EXPRESSION_PRESERVATION_RESTORE_EVIDENCE_BINDING.json',
    'docs/MASTERSTEP91_EXPRESSION_PRESERVATION_RESTORE_EVIDENCE_BINDING.md',
    'runtime/proof/MASTERSTEP90_RESTORATION_PRINCIPLE_GOVERNOR.json',
    'runtime/compass/CompassRestorationPrincipleGovernor.js',
    'docs/MASTERSTEP89_CONTEXT_BEFORE_ROUTE_SEMANTIC_ATTACHMENT.md',
    'runtime/proof/MASTERSTEP89_CONTEXT_BEFORE_ROUTE_SEMANTIC_ATTACHMENT.md',
    'runtime/proof/MASTERSTEP89_CONTEXT_BEFORE_ROUTE_SEMANTIC_ATTACHMENT.json',
    'runtime/proof/LivePathVisibilityAudit.js',
    'proof/runCurrentProof.js',
    'tests/masterStep81LivePathVisibilityProofHarnessTest.js',
    'tests/masterStep81FullClosureKeeperReadinessTest.js',
    'tests/masterStep86CompassDeconstructRestoreSplitTest.js',
    'tests/masterStep87OntologyDrivenCompassLanguageWeaverTest.js',
    'tests/masterStep87FullClosureKeeperReadinessTest.js',
    'docs/MASTERSTEP88_SURFACE_ACTION_DEEPER_UNDERSTANDING_REPAIR.md',
    'runtime/proof/MASTERSTEP88_SURFACE_ACTION_DEEPER_UNDERSTANDING_REPAIR.md',
    'runtime/proof/MASTERSTEP88_SURFACE_ACTION_DEEPER_UNDERSTANDING_REPAIR.json',
    'docs/MASTERSTEP87_ONTOLOGY_DRIVEN_COMPASS_LANGUAGE_WEAVER.md',
    'runtime/proof/MASTERSTEP87_ONTOLOGY_DRIVEN_COMPASS_LANGUAGE_WEAVER.md',
    'runtime/proof/MASTERSTEP87_ONTOLOGY_DRIVEN_COMPASS_LANGUAGE_WEAVER.json',
    'runtime/compass/CompassOntologyLanguageWeaver.js',
    'tests/masterStep86CompassDeconstructRestoreSplitTest.js',
    'docs/MASTERSTEP86_COMPASS_DECONSTRUCT_RESTORE_SPLIT.md',
    'runtime/proof/MASTERSTEP86_COMPASS_DECONSTRUCT_RESTORE_SPLIT.md',
    'runtime/proof/MASTERSTEP86_COMPASS_DECONSTRUCT_RESTORE_SPLIT.json',
    'tests/masterStep85CompassGroundedRealityPathRendererRepairTest.js',
    'tests/masterStep85FullClosureKeeperReadinessTest.js',
    'tests/masterStep84CompassSeeSeparateRestoreRendererRepairTest.js',
    'tests/masterStep84FullClosureKeeperReadinessTest.js',
    'docs/MASTERSTEP84_COMPASS_SEE_SEPARATE_RESTORE_RENDERER_REPAIR.md',
    'runtime/proof/MASTERSTEP84_COMPASS_SEE_SEPARATE_RESTORE_RENDERER_REPAIR.md',
    'runtime/proof/MASTERSTEP84_COMPASS_SEE_SEPARATE_RESTORE_RENDERER_REPAIR.json',
    'docs/MASTERSTEP85_COMPASS_GROUNDED_REALITY_PATH_RENDERER_REPAIR.md',
    'runtime/proof/MASTERSTEP85_COMPASS_GROUNDED_REALITY_PATH_RENDERER_REPAIR.md',
    'runtime/proof/MASTERSTEP85_COMPASS_GROUNDED_REALITY_PATH_RENDERER_REPAIR.json',
    'tests/masterStep83SemanticIndexCompassLiveIntegrationTest.js',
    'docs/MASTERSTEP83_SEMANTIC_INDEX_COMPASS_LIVE_INTEGRATION_MAP.md',
    'runtime/proof/MASTERSTEP83_SEMANTIC_INDEX_COMPASS_LIVE_INTEGRATION.md',
    'runtime/proof/MASTERSTEP83_SEMANTIC_INDEX_COMPASS_LIVE_INTEGRATION.json',
    'runtime/proof/AtlasComponentRegistry.js',
    'runtime/proof/ATLAS_COMPONENT_REGISTRY.json',
    'tests/masterStep135NextMatrixMaturityTargetSelectionTest.js',
    'runtime/understanding/NextMatrixMaturityTargetSelection.js',
    'runtime/proof/MASTERSTEP135_NEXT_MATRIX_MATURITY_TARGET_SELECTION.md',
    'runtime/proof/MASTERSTEP135_NEXT_MATRIX_MATURITY_TARGET_SELECTION.json',
    'docs/MASTERSTEP135_NEXT_MATRIX_MATURITY_TARGET_SELECTION.md',
    'docs/NEXT_MATRIX_MATURITY_TARGET_SELECTION.md',
    'runtime/review/CommunityReviewRedactionShareBoundaryPack.js',
    'tests/masterStep157CommunityReviewRedactionShareBoundaryPackTest.js',
    'runtime/proof/MASTERSTEP157_COMMUNITY_REVIEW_REDACTION_SHARE_BOUNDARY_PACK.md',
    'runtime/proof/MASTERSTEP157_COMMUNITY_REVIEW_REDACTION_SHARE_BOUNDARY_PACK.json',
    'docs/MASTERSTEP157_COMMUNITY_REVIEW_REDACTION_SHARE_BOUNDARY_PACK.md',
    'docs/COMMUNITY_REVIEW_REDACTION_SHARE_BOUNDARY_PACK.md',
    'version_status.js'
  ];
  const requiredFileResults = requiredFiles.map(rel => ({ path: rel, exists: fs.existsSync(path.join(PROJECT_ROOT, rel)) }));
  const manifest = {
    package: currentTarget.currentKeeper.replace(/\.zip$/i, ''),
    source_keeper: currentTarget.sourceKeeper.replace(/\.zip$/i, ''),
    step: currentTarget.currentStep,
    created_at: new Date().toISOString(),
    cwd: PROJECT_ROOT,
    commands: commandResults,
    command_summary: {
      total: commandResults.length,
      passed: commandResults.filter(r => r.passed).length,
      failed: commandResults.filter(r => !r.passed).length
    },
    required_files: requiredFileResults,
    required_files_all_present: requiredFileResults.every(r => r.exists),
    nested_archives_found: nestedArchives.map(f => path.relative(PROJECT_ROOT, f)),
    nested_archives_count: nestedArchives.length,
    boundary_claims: {
      community_review_redaction_share_boundary_pack_created: true,
      redaction_pack_only: true,
      share_boundary_only: true,
      ready_for_bounded_community_sharing: true,
      human_review_required_before_sharing_private_material: true,
      raw_model_outputs_redacted_or_withheld_by_default: true,
      full_source_zip_withheld_by_default: true,
      private_vault_contents_withheld_by_default: true,
      community_reviewer_feedback_intake_boundary_created: true,
      feedback_intake_only: true,
      ready_for_bounded_feedback_collection: true,
      human_review_required: true,
      no_automatic_acceptance: true,
      feedback_cannot_commit_patches: true,
      feedback_must_become_future_explicit_proof_step: true,
      community_demo_harness_created: true,
      community_evidence_pack_created: true,
      bounded_demo_run_order_created: true,
      shareable_index_created: true,
      claim_boundary_statement_created: true,
      ready_for_bounded_community_demo: true,
      ready_for_public_release: false,
      ready_for_clinical_or_crisis_use: false,
      ready_for_autonomous_deployment: false,
      demo_harness_only: true,
      evidence_pack_only: true,
      no_runtime_behavior_change: true,
      no_compass_output_behavior_change: true,
      no_safety_behavior_change: true,
      no_new_matrix_capability: true,
      harm_boundary_regression_created: true,
      unsafe_assistance_refusal_proof: true,
      safety_boundary_only: true,
      self_harm_note_drafting_blocked: true,
      self_harm_method_or_plan_blocked: true,
      crime_planning_blocked: true,
      violence_instruction_blocked: true,
      evidence_or_law_evasion_blocked: true,
      manipulation_or_coercion_blocked: true,
      normal_compass_generation_suppressed_for_unsafe_assistance: true,
      proof_compatibility_helper_created: true,
      later_keeper_recognition_stabilized: true,
      equal_or_greater_proof_counts_required: true,
      historical_proof_markers_required: true,
      source_keeper_continuity_required: true,
      boundary_markers_required: true,
      runtime_behavior_changed: false,
      matrix_capability_added: false,
      compass_output_logic_changed: false,
      next_matrix_maturity_target_selection_created: true,
      selected_next_matrix_target: 'mixed_context_evidence_separation',
      selection_only: false,
      implementation_allowed_now: true,
      matrix_runtime_change_allowed_now: true,
      limits_atlas_to_two_targets: false,
      target_count_capped: false,
      future_matrix_targets_preserved: true,
      first_matrix_expansion_frozen: true,
      checkpoint_freeze_only: true,
      future_matrix_maturity_preserved: true,
      context_before_route_evidence_matrix_preserved: true,
      premature_route_prevention_preserved: true,
      compass_output_preservation_preserved: true,
      atlas_governed_output_remains_final: true,
      candidate_phrasing_remains_candidate_only: true,
      compass_output_preservation_check_created: true,
      original_atlas_response_remains_final: true,
      candidate_may_replace_final: false,
      context_before_route_evidence_sufficiency_matrix_preserved: true,
      premature_route_prevention_fresh_regression_created: true,
      normal_compass_output_changed: false,
      fresh_regression_uses_context_before_route_evidence_sufficiency_matrix: true,
      governed_compass_path_candidate_phrasing_live_regression_fresh_stress_created: true,
      normal_compass_path_output_replacement: false,
      candidate_may_replace_final: false,
      meaning_matrix_expansion_readiness_gate_created: true,
      meaning_matrix_first: true,
      matrix_change_allowed_now: false,
      implementation_allowed_now: false,
      first_recommended_target: 'context_before_route_maturity',
      model_may_author_matrix: false,
      model_may_write_matrix_files: false,
      model_may_approve_expansion: false,
      frontend_may_contain_matrix_logic: false,
      word_expansion_preserved: true,
      doyle_sphere_expansion_preserved: true,
      candidate_phrasing_freeze_preserved: true,
      governed_compass_path_candidate_phrasing_integration_gate_created: true,
      integration_gate_only: true,
      normal_compass_path_integration: false,
      request_sent_by_step124: false,
      live_model_called_by_step124: false,
      compass_candidate_phrasing_refinement_fresh_prompt_regression_stress_created: true,
      fresh_prompt_regression_stress_selected_use_case_only: true,
      normal_compass_path_integration: false,
      compass_candidate_phrasing_refinement_expansion_readiness_review_created: true,
      expansion_readiness_review_selected_use_case_only: true,
      broader_model_use_ready: false,
      compass_candidate_phrasing_refinement_regression_trust_boundary_stress_created: true,
      regression_trust_boundary_stress_selected_use_case_only: true,
      compass_candidate_phrasing_refinement_live_containment_test_created: true,
      live_containment_selected_use_case_only: true,
      broad_model_integration: false,
      candidate_use_case_selection_gate_created: true,
      candidate_use_case_selection_gate_only: true,
      selected_first_local_model_use_case: 'Compass candidate phrasing refinement',
      external_review_handoff_freeze_point_created: true,
      external_review_handoff_freeze_point_only: true,
      external_review_submission_guard_created: true,
      external_review_submission_guard_only: true,
      trust_demo_reviewer_runbook_created: true,
      reviewer_runbook_documentation_only: true,
      trust_demo_failure_mode_readiness_created: true,
      failure_mode_readiness_documentation_only: true,
      trust_demo_trace_evidence_walkthrough_created: true,
      trace_evidence_walkthrough_documentation_only: true,
      review_package_claim_boundary_audited: true,
      claim_boundary_audit_documentation_only: true,
      review_package_created: true,
      review_package_documentation_only: true,
      explanation_pack_created: true,
      explanation_pack_documentation_only: true,
      trust_demo_harness_stress_tested: true,
      trust_demo_harness_completed: true,
      full_clean_pass_gate_completed: true,
      masterstep103_expands_model_use: false,
      local_model_candidate_quality_stressed: true,
      proof_consolidated_before_model_use_expansion: true,
      expands_model_use: false,
      general_model_integration: false,
      adds_model_capability: false,
      api_implemented: false,
      live_local_model_containment_stress_tested: true,
      local_api_personal_safety_design_locked: true,
      ollama_local_runner_safety_locked: true,
      ollama_connected: false,
      ollama_installed_in_package: false,
      provider_connected: false,
      real_model_connected: false,
      api_keys_added: false,
      endpoints_added: false,
      network_bridge_enabled: false,
      frontend_intelligence_added: false,
      operator_console_added: false,
      silent_mutation_allowed: false,
      patch_commit_without_human_review_allowed: false
    },
    mixed_context_evidence_separation_matrix_created: true,
    route_collapse_prevention_added: true,
    separates_contexts_before_route: true,
    final_route_may_be_chosen_from_unseparated_context: false,
    collapsed_route_selected: false,
    supported_claims: [
      'Step162 assembles a safe community review packet and locks exposure so backend source, runtime intelligence, private vault material, proof internals, raw model outputs, credentials, machine paths, and scrapeable governance internals are withheld from the packet.',
      'Step150 verifies Positive-State Compass Output Preservation so positive-state meaning survives into Compass output without forced optimism, outcome guarantees, backend language, route labels, generic flattening, advice pressure, candidate-final confusion, or authority expansion.',
      'Step136 implements the Mixed-Context Evidence Separation Matrix, separating multiple live context streams before route selection and preventing route collapse while preserving candidate-only output and Atlas-governed final output.',
      'Step134 freezes the first context-before-route matrix expansion chain as a stable checkpoint, while preserving future matrix maturity through later governed proof steps.',
      'Step134 audits the keeper boundary: Atlas-governed output remains final, candidate phrasing remains candidate-only, and no model authority, frontend intelligence, cloud/provider fallback, silent learning, or silent mutation is added.',
      'Step133 verifies that the context-before-route evidence sufficiency matrix preserves governed Compass output behavior: sufficient, held, low-confidence, and literal/practical cases keep the Atlas-governed response final while candidate phrasing remains candidate-only and cannot replace final output.',
      'Step132 stress-tests the context-before-route evidence sufficiency matrix with fresh prompts, preventing premature route selection when attached meaning is missing, competing meanings remain unresolved, or prompts are literal/practical, while adding no model authority, frontend intelligence, silent learning, or silent mutation.',
      'Step130 selects context-before-route evidence sufficiency as the first narrow meaning-matrix implementation target while adding no runtime matrix change, model authority, frontend matrix intelligence, cloud/provider fallback, or silent mutation.',
      'Step129 creates a meaning matrix expansion readiness gate, selecting matrix understanding first and context-before-route maturity as the first future implementation target while preserving word and Doyle expansion paths and adding no model authority or silent mutation.',
      'Step123 stress-tests the selected Compass candidate phrasing refinement path with fresh prompts before any normal Compass-path integration while preserving candidate-only support, Atlas-governed final output, quality/governance/trace gates, fail-closed behavior, and no broad model integration.',
      'Step120 performs the first live containment test for Compass candidate phrasing refinement while preserving candidate-only output, Atlas-governed final output, quality/governance/trace gates, fail-closed local behavior, and no broad model integration.',
      'Step119 adds a dry integration shell for the selected first controlled local model use case: Compass candidate phrasing refinement, with no request sent and no live model call.',
      'Step118 selects the first controlled local model expansion use case: Compass candidate phrasing refinement, as a selection gate only with no runtime integration, no model-use expansion, and no model authority.',
      'Step117 adds a controlled local model use expansion gate before any new live local model use case, while preserving candidate-only assistance behind validation, quality, governance, and trace and adding no runtime expansion, model authority, frontend intelligence, cloud/provider fallback, or write authority.',
      'Step116 freezes the external review packet for bounded handoff without hidden chat context and without expanding runtime behavior, model use, model authority, frontend intelligence, cloud/provider fallback, or write authority.',
      'Step114 audits the external review packet for completeness without expanding runtime behavior, model use, model authority, frontend intelligence, cloud/provider fallback, or write authority.',
      'Step113 adds an external review packet index that gives reviewers one clean start point, read order, proof command, evidence map, shareable file list, excluded claims, and boundary checklist without expanding runtime behavior, model use, model authority, frontend intelligence, cloud/provider fallback, or write authority.',
      'Step114 audits the external review packet for completeness without expanding runtime behavior, model use, model authority, frontend intelligence, cloud/provider fallback, or write authority.',
      'Step113 adds an external review packet index that gives reviewers one clean start point, read order, proof command, evidence map, shareable file list, excluded claims, and boundary checklist without expanding runtime behavior, model use, model authority, frontend intelligence, cloud/provider fallback, or write authority.',
      'Step112 adds an external review submission guard that defines allowed review claims, excluded claims, shareable materials, and a submission checklist without expanding runtime behavior, model use, model authority, frontend intelligence, cloud/provider fallback, or write authority.',
      'Step111 adds a reviewer runbook explaining how to inspect, run, and interpret the trust demo proof chain without expanding runtime behavior, model use, model authority, frontend intelligence, cloud/provider fallback, or write authority.',
      'Step110 adds failure-mode readiness showing Ollama unavailable, bad/paraphrased candidate, unsafe bypass pressure, and raw-as-final pressure remain contained without expanding runtime behavior, model use, model authority, frontend intelligence, cloud/provider fallback, or write authority.',
      'Step109 adds a trace evidence walkthrough showing one blocked trust-risk path and one safe contained candidate path without expanding runtime behavior, model use, model authority, frontend intelligence, cloud/provider fallback, or write authority.',
      'Step108 audits the trust demo review package for claim-boundary drift without expanding runtime behavior, model use, model authority, frontend intelligence, cloud/provider fallback, or write authority.',
      'Step107 creates a reviewer-facing review package entrypoint for the trust demo without expanding runtime behavior, model use, model authority, frontend intelligence, cloud/provider fallback, or write authority.',
      'Step106 creates a reviewer-facing explanation pack for the trust demo without expanding runtime behavior, model use, model authority, frontend intelligence, cloud/provider fallback, or write authority.',
      'Step105 stress-tests the trust demo harness before explanation packaging, verifying expanded bypass/misuse pressures are blocked before local model path while safe assistance remains candidate-only.',
      'Step104 adds a reviewer-facing trust demo harness showing Atlas can use local model assistance as candidate-only support without making the model the authority.',
      'Step103 runs a consolidated full clean pass gate across proof docs, package hygiene, local Ollama containment, boundary-to-model blocking, candidate-only output, mutation scan, provider scan, frontend intelligence scan, and proof-story consistency without expanding model use.',
      'Step101 stress-tests local Ollama-generated candidate language for bounded usefulness and non-generic behavior while preserving candidate-only containment, quality, governance, trace, no mutation, and no cloud/provider fallback.',
      'Step100 consolidates the local Ollama containment proof story before any model-use expansion and adds no new model capability, API surface, ontology, mechanism authority, frontend intelligence, silent learning, or silent mutation.',
      'Step100 records local verification of Step98 at 20/20 and Step99 at 21/21 with Ollama and llama3.2:3b available on the user PC.',
      'Step99 stress-tests the live local Ollama containment path with repeated bounded prompts while preserving candidate-only output, quality, governance, trace, no mutation, no cloud/provider fallback, and fail-closed behavior when Ollama is unavailable.',
      'Step96 patch 08 selects Ollama as the future local model runner while proving it is not bundled, installed, connected, or allowed to bypass Atlas governance.',
      'Step96 patch 07 locks local API personal-safety design constraints before any API implementation is allowed.',
      'Step96 patch 07 verifies unsafe API design prompts are blocked, safe API design discussion remains allowed, simulated contracts expose minimal governed fields, provider/network scans remain clean, active unsafe API implementation patterns are absent, and API implementation remains false.',
      'Step96 patch 06 heavily stress-tests local API readiness conditions without implementing an API.',
      'Step96 patch 06 verifies heavier API-boundary fuzz, API-shaped benign prompts, malformed contract payloads, repeated-run stability, contract leak prevention, no active API server, no provider/model/network bridge, no frontend intelligence, and no mutation API surface.',
      'Cross-window proof continuity ledger added without fabricating missing external window proof',
      'Step96 patch 03 organizes proof continuity, adds cleanup audit without deletion, and tests API readiness deferral conditions before any API exists.',
      'Step96 patch 03 verifies current behavior stress probe, boundary containment probe, reviewer-clean proof docs, regression lock presence, and no active API server patterns added.',
      'Step96 patch 02 expands coverage testing across 86 scenario prompts and 36 hard-boundary variants; it verifies structured and quality-passed scenario outputs, 0 generic fallback markers, 0 unclassified routes, 86/86 expected family matches, and 36/36 boundary variants contained.',
      'Step96 patch 00 contains boundary variants and verifies a broader mixed stress pass without creating a new master step.',
      'Step96 repairs the seven Step95 relational/belonging weak categories and verifies a broader behavior stress pass.',
      'Step96 patch 00 verifies 16/16 boundary variants contained and 60/60 benign mixed prompts structured and quality-passed with 0 generic fallback markers, 0 unclassified routes, and 0 benign governance blocks.',
      'Step96 broader behavior stress verifies 44/44 structured outputs, 44/44 quality-passed outputs, 0 generic fallback markers, 0 unclassified routes, and 0 benign governance blocks.',
      'Step96 adds no ontology, no new mechanisms, no provider/model/cloud/API/network bridge, no operator console, no frontend intelligence, no silent learning, and no silent mutation.',
      'Step95 performs behavior stress testing against the stabilized proof story.',
      'Step95 contains 5/5 hard boundary stress cases after narrow input-boundary stabilization.',
      'Step95 stabilizes 4/4 practical-literal stress misroutes through the existing context object literal gate.',
      'Step95 records 7 remaining benign behavior weak cases instead of hiding them.',
      'Step95 adds no ontology, no new mechanisms, no provider/model/cloud/API/network bridge, no operator console, no frontend intelligence, no silent learning, and no silent mutation.',
      'Step145 freezes the Translation Preservation Matrix expansion as a checkpoint with no runtime behavior change, no Compass output logic change, no new matrix capability, no model authority, no frontend intelligence, no silent learning, and no silent mutation.',
      'Step144 adds a proof-side compatibility helper for later-keeper recognition so older tests can accept equal-or-later keepers with equal-or-greater proof counts, preserved historical markers, source continuity, and boundary markers without changing runtime behavior.',
      'Step143 regression-tests Translation Preservation final output drift without adding matrix capability, model authority, frontend intelligence, silent learning, or silent mutation.',
      'Step142 fresh-tests Translation Preservation Matrix output preservation across varied prompts and records NOTICE as preferred user-facing pattern language over DECONSTRUCT analytical heading drift.',
      'Step141 implements Translation Preservation Matrix without backend-language leakage, generic flattening, route over-labeling, candidate-final replacement, model authority, frontend intelligence, silent learning, or silent mutation.',
      'Step138 preserves mixed-context understanding through Compass output without backend-language leakage, generic flattening, candidate-final replacement, model authority, frontend intelligence, silent learning, or silent mutation.',
      'Current proof can be run with node proof/runCurrentProof.js.',
      'Atlas component registry classifies major subsystems without deleting, connecting, or replacing anything.',
      'Step94 synchronizes current proof state and adds a reviewer-facing engineering proof index.',
      'Step94 reconciles packaged fuzz counts and does not claim historical/manual fuzz as current packaged proof.',
      'Step94 adds no behavior capability, ontology, mechanisms, provider/model/cloud/API/network bridge, operator console, frontend intelligence, silent learning, or silent mutation.',
      'Step93 builds a concrete context object before Doyle placement and route selection.',
      'Step93 blocks broad/unclassified Doyle placement from passing as mature understanding and makes candidate quality govern final quality.',
      'Step90 prevents Restore from collapsing into formulaic universal grounding phrases by deriving Restore from the deconstructed route relationship.',
      'Step89 enforces the existing context-before-route principle at semantic attachment scoring so broad phrase routes cannot win without surrounding context support.',
      'Covered semantic and lived-mechanism prompts no longer fall through to generic fallback as final Compass output.',
      'Inactive is not treated as obsolete; all classified components default to DO_NOT_DELETE.',
      'Command stdout/stderr is captured under proof/logs.',
      'Machine-readable manifest is written under proof/results.',
      'Live pipeline exposes diagnostic closed-loop visibility without making it final output authority.',
      'Full package fuzz remains part of the current proof runner.'
    ]
  };
  manifest.current_proof_target = authority;
  manifest.proof_invocation_freshness = freshness;
  manifest.canonical_proof_contract = canonical;
  manifest.removed_stale_current_manifests = removedStaleManifests;
  manifest.pass = manifest.command_summary.failed === 0 && manifest.required_files_all_present && manifest.nested_archives_count === 0;
  // Charter117: honest scope and drift-to-recovery ratio in the manifest.
  // Efficiency is not capability: the manifest states what the battery
  // proves (the gate holds) and what it does not (that the model is smart,
  // capable, or right). Never changes pass/fail; scope language only.
  try {
    const { buildHonestScope } = require("../runtime/proof/HonestProofScope.js");
    let charterInfo = null;
    try {
      const CharterLoader = require("../runtime/governance/CharterLoader.js");
      const resolved = CharterLoader.resolveActiveCharter(PROJECT_ROOT);
      if (resolved && resolved.ok && resolved.charter) {
        charterInfo = { id: resolved.charter.id, version: resolved.charter.version, author: resolved.charter.author };
      }
    } catch (_) { /* charter context is best-effort */ }
    manifest.honest_scope = buildHonestScope({ command_summary: manifest.command_summary, charter: charterInfo });
    try {
      const DriftRecovery = require("../runtime/governance/DriftRecovery.js");
      manifest.drift_recovery = DriftRecovery.driftToRecoveryRatio(PROJECT_ROOT);
    } catch (_) { /* ratio is best-effort */ }
  } catch (_) { /* honest scope never breaks the proof */ }
  // Charter118: guard attestation — structural vs semantic labels plus
  // per-check independence attestation. Labels only; never breaks the proof.
  try {
    const kinds = JSON.parse(fs.readFileSync(path.join(PROJECT_ROOT, "runtime", "proof", "GUARD_KINDS.json"), "utf8"));
    const indep = JSON.parse(fs.readFileSync(path.join(PROJECT_ROOT, "runtime", "proof", "CHECK_INDEPENDENCE.json"), "utf8"));
    manifest.guard_attestation = buildGuardAttestation(commandResults, kinds, indep);
  } catch (_) { /* attestation never breaks the proof */ }
  // Charter121: runtime fingerprint (neo_konsi_s2bw — "the checkpoint is not
  // the whole local model"). The manifest now names the runtime wiring the
  // battery ran on: engine identity plus every module file the runner
  // actually loaded, each hashed. Captured at run start (preflight) and at
  // manifest-write time; the start/finish comparison is informational only
  // and never changes pass/fail. The promotion gate re-hashes the recorded
  // module files on disk and fails closed on drift. The fingerprint binds
  // the run to its context — it does not prove the run was clean.
  try {
    const runtimeFingerprintFinish = captureRuntimeFingerprint(PROJECT_ROOT);
    const wiringDiff = pre.runtimeFingerprintStart ? diffCaptures(pre.runtimeFingerprintStart, runtimeFingerprintFinish) : null;
    manifest.runtimeFingerprint = {
      note: 'Binds the run to its runtime context (the cook, not just the ingredients). Detects context drift; does not prove the run was clean.',
      credit: 'neo_konsi_s2bw',
      start: pre.runtimeFingerprintStart || null,
      finish: runtimeFingerprintFinish,
      wiring_changed_during_run: wiringDiff ? !wiringDiff.match : null,
      wiring_change_detail: wiringDiff && !wiringDiff.match ? wiringDiff.differences.slice(0, 25) : []
    };
  } catch (_) { /* fingerprint never breaks the proof */ }
  const manifestPath = path.join(PROJECT_ROOT, currentTarget.current_manifest);
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
  return manifest;
}

function runCurrentProof(){
  const pre = runPreflight();
  const commandResults = commands.map(([displayName, bin, args, technicalName]) => runCommand(displayName, bin, args, technicalName));
  return finishManifest(pre, commandResults);
}

// Charter120: parallel entry point — same preflight, same manifest assembly,
// same 106 checks with the same verdict logic; only the waiting is
// concurrent. Returns a Promise of the manifest. A check that crashes, times
// out, or yields no result is recorded unverified (passed:false), never
// skipped and never passed.
async function runCurrentProofParallel(concurrency){
  const pre = runPreflight();
  const commandResults = await runCommandsParallel(concurrency == null ? PARALLEL_CONCURRENCY : concurrency);
  return finishManifest(pre, commandResults);
}

if (require.main === module) {
  const manifest = runCurrentProof();
  console.log(JSON.stringify({ pass: manifest.pass, command_summary: manifest.command_summary, manifest: manifest.current_proof_target.currentManifest }, null, 2));
  process.exit(manifest.pass ? 0 : 1);
}

module.exports = { runCurrentProof, runCurrentProofParallel, runCommandsParallel, runCommandAsync, PARALLEL_CONCURRENCY, classifyGuardKind, buildGuardAttestation, commands: commands.map(([displayName, bin, args, technicalName]) => ({ displayName, bin, args, technicalName })) };

