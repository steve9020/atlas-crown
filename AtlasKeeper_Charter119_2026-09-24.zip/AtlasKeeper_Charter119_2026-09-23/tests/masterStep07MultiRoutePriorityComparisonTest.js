#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const root = process.cwd();
function p(rel) { return path.join(root, rel); }
function read(rel) { return fs.readFileSync(p(rel), 'utf8'); }
function assert(condition, message) {
  if (!condition) {
    console.error(`FAIL: ${message}`);
    process.exit(1);
  }
}
function includesAll(text, markers, label) {
  for (const marker of markers) {
    assert(text.includes(marker), `${label} missing marker: ${marker}`);
  }
}

const governancePath = 'CA/Continuity_Architecture/01 Atlas Governance/64 Multi-Route Priority Comparison/multi_route_priority_comparison.md';
const runtimePath = 'CA/Continuity_Architecture/02 Atlas Runtime/64 Multi-Route Priority Comparison/multi_route_priority_runtime_check.md';
const priorRouteGovPath = 'CA/Continuity_Architecture/01 Atlas Governance/63 Route Assumption Resistance/route_assumption_resistance.md';
const priorRouteRuntimePath = 'CA/Continuity_Architecture/02 Atlas Runtime/63 Route Assumption Resistance/route_assumption_runtime_check.md';
const proofPath = 'CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_7A_MULTI_ROUTE_PRIORITY_COMPARISON_IMPLEMENTATION.md';
const ledgerPath = 'tests/TEST_RESULTS.md';
const indexPath = 'CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/PROOF_OF_WORK_CARRIED_FORWARD_INDEX.md';

for (const rel of [governancePath, runtimePath, priorRouteGovPath, priorRouteRuntimePath, proofPath, ledgerPath, indexPath]) {
  assert(fs.existsSync(p(rel)), `required file missing: ${rel}`);
}

const governance = read(governancePath);
const runtime = read(runtimePath);
const priorGov = read(priorRouteGovPath);
const priorRuntime = read(priorRouteRuntimePath);
const proof = read(proofPath);
const ledger = read(ledgerPath);
const index = read(indexPath);

includesAll(governance, [
  'Multi-Route Priority Comparison',
  'Route priority must be earned by evidence, not emotional intensity alone',
  'word or phrase',
  'emotional attachment',
  'assumed meaning',
  'route candidate',
  'governance boundary',
  'select a primary route',
  'preserve a secondary route',
  'blend routes',
  'reject a route',
  'This layer does not give Atlas authority to decide final truth'
], 'governance multi-route priority boundary');

includesAll(runtime, [
  'Multi-Route Priority Runtime Check',
  'Identify candidate routes',
  'Separate emotional intensity from evidence strength',
  'Lower unsupported assumptions',
  'Blend routes only when the prompt supports more than one route',
  'Is emotional intensity being mistaken for proof?',
  'primary route',
  'secondary route',
  'blended route',
  'rejected route',
  'clarification route',
  'Avoid frontend exposure of route comparison machinery'
], 'runtime multi-route priority check');

includesAll(priorGov, [
  'Route Assumption Resistance',
  'Strong signals are not automatic proof',
  'Route certainty must earn priority'
], 'prior route assumption governance remains present');

includesAll(priorRuntime, [
  'Route Assumption Runtime Check',
  'Before Atlas locks a route',
  'Preserve uncertainty when evidence is incomplete'
], 'prior route assumption runtime remains present');

includesAll(proof, [
  'MASTER STEP 7A',
  'Masterstep07_patch01.zip',
  'PASSED AFTER IMPLEMENTATION',
  'Route priority must be earned by evidence, not emotional intensity alone',
  'We are not proving perfect understanding'
], 'proof record');

includesAll(ledger, [
  'MASTER STEP 7A',
  'Multi-Route Priority Comparison Implementation',
  'masterStep07MultiRoutePriorityComparisonTest.js — PASSED',
  'proof_runner.py — PASSED'
], 'test results ledger');

includesAll(index, [
  'Master Step 7A — Multi-Route Priority Comparison Implementation',
  'MASTER_STEP_7A_MULTI_ROUTE_PRIORITY_COMPARISON_IMPLEMENTATION.md',
  'Route priority must be earned by evidence, not emotional intensity alone'
], 'proof carry-forward index');

const routeCases = [
  {
    prompt: 'They did not answer me.',
    requiredRoutes: ['missing context', 'relational uncertainty', 'assumed rejection', 'fear projection', 'practical delay']
  },
  {
    prompt: 'The supervisor said it is handled, so no review is needed.',
    requiredRoutes: ['authority pressure', 'context laundering or disguised bypass', 'missing context', 'legitimate closure']
  },
  {
    prompt: 'The worker is upset, so they are probably lying.',
    requiredRoutes: ['authority pressure', 'possible misunderstanding', 'actual boundary violation', 'worker emotional charge', 'supervisor detachment']
  },
  {
    prompt: 'I made one mistake, so I am failing completely.',
    requiredRoutes: ['shame/self-worth collapse', 'emotional overload', 'practical task friction', 'continuity threat']
  }
];

for (const testCase of routeCases) {
  for (const route of testCase.requiredRoutes) {
    assert(runtime.includes(route) || governance.includes(route), `missing route '${route}' for prompt: ${testCase.prompt}`);
  }
}

const forbidden = [
  'emotional intensity automatically wins',
  'Atlas may decide final truth',
  'frontend should expose route scoring',
  'first route wins automatically',
  'route comparison may bypass governance'
];
for (const phrase of forbidden) {
  assert(!governance.includes(phrase), `governance contains forbidden phrase: ${phrase}`);
  assert(!runtime.includes(phrase), `runtime contains forbidden phrase: ${phrase}`);
}

console.log('MASTER STEP 07 — MULTI-ROUTE PRIORITY COMPARISON TEST');
console.log('Result: PASSED');
console.log('Confirmed: route priority is evidence-weighted, not intensity-driven.');
console.log('Confirmed: primary, secondary, blended, rejected, and clarification outcomes are preserved.');
console.log('Confirmed: route comparison does not expand authority or frontend exposure.');
