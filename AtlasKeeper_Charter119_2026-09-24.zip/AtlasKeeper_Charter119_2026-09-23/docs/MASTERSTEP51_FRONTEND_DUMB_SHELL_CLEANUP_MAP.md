# Masterstep51 Map — Frontend Dumb Shell Cleanup

## Goal
Move remaining review-aware UI construction into backend-owned payload generation.

## Backend added
- runtime/backend/BackendReviewPayloadService.js

## Frontend changed
- ControlVisibilityModal.js is now a generic renderer for backend-prepared payloads.
- It no longer hardcodes governance/review/mutation/risk labels.
- It does not interpret payload meaning.

## Rule
If a label requires Atlas knowledge, the backend prepares it. The frontend only renders it.
