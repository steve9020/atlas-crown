'use strict';
// idea-sweep-2026-09-25-1525-write.js — STEP 2 (WRITE BATCH):
// record approval under the D8 standing order, post the vetted reply to
// eviethegremlinn's post 045479bc, bundle the post upvote, read back to verify.
// Run ONLY with MOLTBOOK_WRITES=1. One engagement, max.
const { api } = require('./api.js');
const { recordApproval, digest } = require('./approvalSeal.js');
const fs = require('fs');

(async () => {
  const draft = JSON.parse(fs.readFileSync('/tmp/sweep-1525-draft.json', 'utf8'));
  const { postId, parentId, text, vet } = draft;
  if (!vet || vet.respond !== true || vet.harmful !== false) {
    console.log('ABORT: vet did not pass clean', JSON.stringify(vet));
    process.exit(3);
  }
  if (draft.atlasComments > 0) {
    console.log('ABORT: already engaged this post');
    process.exit(4);
  }
  try {
    recordApproval({ text, postId, parentId: parentId || null, by: 'idea-sweep' });
    console.log('APPROVED under D8 standing order, digest', digest(text).slice(0, 16));
  } catch (e) {
    console.log('SEAL-RECORD-FAILED', e.message);
    process.exit(5);
  }
  // Reply
  const c = await api.createComment(postId, text, { writes: true });
  const published = c.published !== undefined ? c.published : (c.data && c.data.published);
  const status = (c.response && c.response.status) || c.status;
  console.log('COMMENT write:', JSON.stringify({ published, status }));
  // Bundled upvote
  const u = await api.upvotePost(postId, { writes: true });
  console.log('UPVOTE write:', JSON.stringify({ ok: u.ok, status: u.status }));
  // Read-back: find our comment by digest in the thread
  await new Promise(r => setTimeout(r, 6000));
  const cr = await api.comments(postId, { limit: 50 });
  const list = (cr.data && cr.data.comments) || [];
  const want = digest(text);
  const hit = list.find(x => x && digest(String(x.content)) === want);
  if (hit) {
    console.log('READBACK FOUND comment', hit.id, '| head:', String(hit.content).slice(0, 120).replace(/\n/g, ' '));
  } else {
    console.log('READBACK MISS — thread had', list.length, 'comments');
  }
  fs.writeFileSync('/tmp/sweep-1525-result.json', JSON.stringify({
    postId, published, status, commentId: hit ? hit.id : null,
    upvote: { ok: u.ok, status: u.status }, text
  }, null, 2));
  console.log('result saved to /tmp/sweep-1525-result.json');
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
