const MECHANISM_TRANSLATIONS = [
  {
    id: "identity_threat_escalation",
    pattern: /\bidentity[-\s]?threat\s+escalation\b/gi,
    replacement: "the pressure can start making the moment feel tied to who you are"
  },
  {
    id: "self_worth_attachment",
    pattern: /\bself[-\s]?worth\s+(is\s+)?(attached|tied|linked)\s+to\s+(the\s+)?(outcome|response|event)\b/gi,
    replacement: "your value can start feeling tied to how this turns out"
  },
  {
    id: "semantic_fusion",
    pattern: /\bsemantic\s+fusion\b/gi,
    replacement: "the meaning may be getting fused together with the feeling"
  },
  {
    id: "meaning_chain_detection",
    pattern: /\bmeaning[-\s]?chain\s+detection\b/gi,
    replacement: "one meaning may be starting to pull the next one behind it"
  },
  {
    id: "recursive_certainty_loop",
    pattern: /\brecursive\s+certainty\s+loop\b/gi,
    replacement: "the thought can start circling back on itself until it feels more final than it is"
  },
  {
    id: "attachment_weighting",
    pattern: /\battachment\s+weighting\b/gi,
    replacement: "the connection may be carrying more emotional weight here"
  },
  {
    id: "axis_activation",
    pattern: /\baxis\s+(activation|weighting|pressure)\b/gi,
    replacement: "something important in you may be getting pressed on"
  },
  {
    id: "route_scoring",
    pattern: /\broute[-\s]?(score|scoring|confidence|explanation)\b/gi,
    replacement: "the response can stay grounded without needing to turn that signal into certainty"
  },
  {
    id: "runtime_mechanism",
    pattern: /\b(runtime|pipeline|registry|backend)\s+(mechanism|signal|process|layer)\b/gi,
    replacement: "what is happening underneath can be held simply and clearly"
  },
  {
    id: "cognitive_distortion_label",
    pattern: /\bcognitive\s+distortion\b/gi,
    replacement: "the pressure may be pulling the meaning further than the situation has proven"
  }
];

const ANALYTICAL_MECHANISM_MARKERS = [
  /\bidentity[-\s]?threat\s+escalation\b/i,
  /\bself[-\s]?worth\s+(is\s+)?(attached|tied|linked)\s+to\s+(the\s+)?(outcome|response|event)\b/i,
  /\bsemantic\s+fusion\b/i,
  /\bmeaning[-\s]?chain\s+detection\b/i,
  /\brecursive\s+certainty\s+loop\b/i,
  /\battachment\s+weighting\b/i,
  /\baxis\s+(activation|weighting|pressure)\b/i,
  /\broute[-\s]?(score|scoring|confidence|explanation)\b/i,
  /\b(runtime|pipeline|registry|backend)\s+(mechanism|signal|process|layer)\b/i,
  /\bcognitive\s+distortion\b/i
];

const CONNECTIVE_LANGUAGE_MARKERS = [
  /\bcan\s+start\s+(making|feeling|circling|pulling)\b/i,
  /\bmay\s+be\s+(getting|carrying|starting|pulling|pressed)\b/i,
  /\bcan\s+feel\b/i,
  /\bfeels?\s+(tied|more|less|heavy|final)\b/i,
  /\bwithout\s+needing\s+to\b/i,
  /\bheld\s+simply\s+and\s+clearly\b/i,
  /\bthan\s+the\s+situation\s+has\s+proven\b/i
];

function detectAnalyticalMechanismLanguage(response) {
  const text = typeof response === "string" ? response : "";
  const detected = [];

  for (const translation of MECHANISM_TRANSLATIONS) {
    translation.pattern.lastIndex = 0;
    if (translation.pattern.test(text)) {
      detected.push(translation.id);
    }
  }

  return detected;
}

function hasConnectiveHumanLanguage(response) {
  const text = typeof response === "string" ? response : "";
  return CONNECTIVE_LANGUAGE_MARKERS.some((pattern) => pattern.test(text));
}

function translateMechanismToHumanLanguage(response) {
  let output = typeof response === "string" ? response : "";
  const detectedBefore = detectAnalyticalMechanismLanguage(output);

  for (const translation of MECHANISM_TRANSLATIONS) {
    translation.pattern.lastIndex = 0;
    output = output.replace(translation.pattern, translation.replacement);
  }

  const detectedAfter = detectAnalyticalMechanismLanguage(output);

  return {
    output,
    mechanism_to_human_language_translation: {
      mechanism_to_human_language_translation_active: true,
      analytical_mechanism_language_detected: detectedBefore,
      analytical_mechanism_language_remaining: detectedAfter,
      backend_mechanisms_translated_into_lived_language: detectedAfter.length === 0,
      connective_human_language_present: hasConnectiveHumanLanguage(output) || detectedBefore.length > 0,
      machinery_language_exposed: false,
      required_output_mode: "mechanism_translated_to_connective_human_language",
      guardrails: [
        "do_not_expose_backend_mechanism_framing",
        "translate_structure_into_lived_pressure_language",
        "preserve_depth_without_analytical_dissection",
        "maintain_human_connection_before_mechanism_explanation",
        "do_not_sound_clinical_structural_or_machine_interpreted"
      ]
    }
  };
}

module.exports = {
  translateMechanismToHumanLanguage,
  detectAnalyticalMechanismLanguage,
  hasConnectiveHumanLanguage
};
