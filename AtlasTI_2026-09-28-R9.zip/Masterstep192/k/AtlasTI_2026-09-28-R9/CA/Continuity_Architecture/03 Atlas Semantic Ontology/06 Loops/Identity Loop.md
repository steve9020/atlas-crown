# Identity Loop

## Structural Flow

[[Experience]]
→ shapes [[Identity]]

[[Identity]]
→ filters perception through emotional weighting

Filtered perception
→ influences [[Behavior]]

Repeated behavior
→ reinforces [[Continuity Recognition]]

Continuity
→ stabilizes or distorts identity over time

[[Awareness]]
can interrupt the loop through:
- reflection
- contradiction testing
- truthful recognition
- recalibration

Without interruption:
identity calcifies and unconscious continuity compounds.