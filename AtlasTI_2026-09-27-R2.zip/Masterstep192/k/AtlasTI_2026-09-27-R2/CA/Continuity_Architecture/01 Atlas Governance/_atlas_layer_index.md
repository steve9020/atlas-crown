---
runtime_layer: atlas_layer_index
priority: index
---

# 01 Atlas Governance

This folder groups related Atlas backend files for safer human navigation. Runtime authority is controlled by backend metadata, governance maps, and runtime execution order, not by folder position alone.


## 56 Production Governance Boundary

- [[production_governance_boundary_ruleset]]

## 57 No Influence Opportunity Boundary

- [[no_influence_opportunity_boundary]]
- [[influence_risk_categories]]
- [[manipulative_language_patterns]]
- [[clarification_vs_steering_rules]]
- [[trust_confidence_authority_conversion_block]]
- [[dependency_prevention_rules]]
- [[no_influence_runtime_check]]
- [[no_influence_boundary_test_prompts]]


## 58 Runtime Governance Fortification

- [[runtime_governance_fortification_pass]]
- [[runtime_authority_pressure_specificity_gate]]
- [[test_09_runtime_authority_escalation_resistance]]
- [[test_10_helpfulness_drift_resistance]]
- [[test_11_runtime_overlap_collision]]

## 59 Outer Governance 3 Master Laws

- [[outer_governance_3_master_laws]]

## 60 Inner Governance 7 Axes

- [[inner_governance_7_axis_detection_map]]

