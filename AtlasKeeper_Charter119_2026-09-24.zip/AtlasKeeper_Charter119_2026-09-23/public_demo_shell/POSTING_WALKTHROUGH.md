# Hugging Face Spaces Posting Walkthrough

1. Go to huggingface.co and sign in.
2. Open Spaces and choose Create new Space.
3. Name it something like atlas-compass-safe-demo-shell.
4. Choose Gradio as the SDK.
5. Start as Private or public only after you verify the upload.
6. Upload only the files from this public_demo_shell folder: README.md, app.py, requirements.txt, DEMO_BOUNDARY.md, FEEDBACK_GUIDE.md, SAFE_SYNTHETIC_EXAMPLES.md, POSTING_WALKTHROUGH.md, and DEMO_MANIFEST.json.
7. Do not upload the Masterstep keeper zip, runtime folder, proof folder, tests, private vault, or backend source.
8. Wait for the Space build to finish.
9. Open the Space and try each synthetic example.
10. Share the Space link with a feedback request only after checking the boundary notice displays correctly.
