# Masterstep176 — Pressure / Performance / Identity Semantic Matrix Repair

This step adds a new governed semantic matrix capability and changes runtime classification and Compass profile availability only for evidence-supported performance-sufficiency pressure.

The repair centralizes evidence construction in `PressurePerformanceIdentityMatrix.js`; phrase patterns are low-level signal extractors and cannot independently select the domain. The route requires performance/output evidence, real effort or completion, insufficiency after effort, and governed exclusions. Worth attachment remains explicit evidence or unresolved rather than an automatic assertion.

Previously frozen Mixed-Context Evidence Separation and Translation Preservation files received governed additive integration changes. Their prior behavior remains subject to the complete inherited proof chain.

The Step176 test covers implementation, fresh paraphrase regression, adversarial overlap, Compass output/profile preservation, and freeze audit.
