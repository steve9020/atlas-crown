---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 01
category: trust_and_betrayal
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 02. Trust and Betrayal Pressure Tests — Batch 01

## Category Purpose

An expected source of honesty, reliability, loyalty, or consistency breaks or becomes uncertain, causing the user to question what was real and whether trusting was safe.

## Reusable Teaching Correction

Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

## Reverse-Flow Target

discernment, protected openness, clear evaluation, dignity

## Failure Risks To Avoid

- forcing forgiveness
- forcing permanent distrust
- calling the user foolish
- assuming manipulation without evidence
- using clinical trauma labels

---

## 80 Pressure Tests

### Test 01
**Prompt:** friend shared something private made me question I was stupid for trusting, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I was stupid for trusting
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 02
**Prompt:** they said one thing and did another. Partner hid a conversation and it keeps attaching to I should have known.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I should have known
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 03
**Prompt:** I keep replaying how family member broke a promise because it affects loyalty and makes me believe trust is always unsafe.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** trust is always unsafe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 04
**Prompt:** When coworker took credit after promising support, the feeling moves straight into nothing was real. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** nothing was real
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 05
**Prompt:** someone lied about where they were made me question I have to shut down to stay safe, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I have to shut down to stay safe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 06
**Prompt:** I cannot trust them. Someone repeated behavior after apologizing and it keeps attaching to I cannot trust anyone.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I cannot trust anyone
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 07
**Prompt:** I keep replaying how someone minimized what they did because it affects reliability and makes me believe everyone eventually betrays me.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** everyone eventually betrays me
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 08
**Prompt:** When someone changed the story later, the feeling moves straight into I was stupid for trusting. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I was stupid for trusting
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 09
**Prompt:** friend shared something private makes me feel I was weak for believing them, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I was weak for believing them
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 10
**Prompt:** they hid something. Partner hid a conversation and it keeps attaching to trust is always unsafe.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** trust is always unsafe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 11
**Prompt:** I keep replaying how family member broke a promise because it affects discernment and makes me believe I should have known.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I should have known
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 12
**Prompt:** When coworker took credit after promising support, the feeling moves straight into I have to shut down to stay safe. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I have to shut down to stay safe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 13
**Prompt:** someone lied about where they were makes me feel nothing was real, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** nothing was real
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 14
**Prompt:** they were not honest. Someone repeated behavior after apologizing and it keeps attaching to everyone eventually betrays me.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** everyone eventually betrays me
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 15
**Prompt:** I keep replaying how someone minimized what they did because it affects loyalty and makes me believe I cannot trust anyone.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I cannot trust anyone
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 16
**Prompt:** When someone changed the story later, the feeling moves straight into I was weak for believing them. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I was weak for believing them
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 17
**Prompt:** friend shared something private has me wondering I was stupid for trusting, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I was stupid for trusting
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 18
**Prompt:** I feel betrayed. Partner hid a conversation and it keeps attaching to I should have known.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I should have known
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 19
**Prompt:** I keep replaying how family member broke a promise because it affects reliability and makes me believe trust is always unsafe.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** trust is always unsafe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 20
**Prompt:** When coworker took credit after promising support, the feeling moves straight into nothing was real. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** nothing was real
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 21
**Prompt:** someone lied about where they were has me wondering I have to shut down to stay safe, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I have to shut down to stay safe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 22
**Prompt:** they lied. Someone repeated behavior after apologizing and it keeps attaching to I cannot trust anyone.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I cannot trust anyone
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 23
**Prompt:** I keep replaying how someone minimized what they did because it affects discernment and makes me believe everyone eventually betrays me.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** everyone eventually betrays me
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 24
**Prompt:** When someone changed the story later, the feeling moves straight into I was stupid for trusting. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I was stupid for trusting
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 25
**Prompt:** friend shared something private makes it hard to know I was weak for believing them, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I was weak for believing them
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 26
**Prompt:** I do not know what was real. Partner hid a conversation and it keeps attaching to trust is always unsafe.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** trust is always unsafe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 27
**Prompt:** I keep replaying how family member broke a promise because it affects loyalty and makes me believe I should have known.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I should have known
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 28
**Prompt:** When coworker took credit after promising support, the feeling moves straight into I have to shut down to stay safe. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I have to shut down to stay safe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 29
**Prompt:** someone lied about where they were makes it hard to know nothing was real, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** nothing was real
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 30
**Prompt:** they broke a promise. Someone repeated behavior after apologizing and it keeps attaching to everyone eventually betrays me.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** everyone eventually betrays me
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 31
**Prompt:** I keep replaying how someone minimized what they did because it affects reliability and makes me believe I cannot trust anyone.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I cannot trust anyone
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 32
**Prompt:** When someone changed the story later, the feeling moves straight into I was weak for believing them. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I was weak for believing them
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 33
**Prompt:** friend shared something private keeps making me think I was stupid for trusting, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I was stupid for trusting
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 34
**Prompt:** they said one thing and did another. Partner hid a conversation and it keeps attaching to I should have known.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I should have known
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 35
**Prompt:** I keep replaying how family member broke a promise because it affects discernment and makes me believe trust is always unsafe.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** trust is always unsafe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 36
**Prompt:** When coworker took credit after promising support, the feeling moves straight into nothing was real. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** nothing was real
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 37
**Prompt:** someone lied about where they were keeps making me think I have to shut down to stay safe, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I have to shut down to stay safe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 38
**Prompt:** I cannot trust them. Someone repeated behavior after apologizing and it keeps attaching to I cannot trust anyone.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I cannot trust anyone
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 39
**Prompt:** I keep replaying how someone minimized what they did because it affects loyalty and makes me believe everyone eventually betrays me.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** everyone eventually betrays me
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 40
**Prompt:** When someone changed the story later, the feeling moves straight into I was stupid for trusting. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I was stupid for trusting
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 41
**Prompt:** friend shared something private makes trusting feel I was weak for believing them, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I was weak for believing them
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 42
**Prompt:** they hid something. Partner hid a conversation and it keeps attaching to trust is always unsafe.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** trust is always unsafe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 43
**Prompt:** I keep replaying how family member broke a promise because it affects reliability and makes me believe I should have known.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I should have known
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 44
**Prompt:** When coworker took credit after promising support, the feeling moves straight into I have to shut down to stay safe. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I have to shut down to stay safe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 45
**Prompt:** someone lied about where they were makes trusting feel nothing was real, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** nothing was real
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 46
**Prompt:** they were not honest. Someone repeated behavior after apologizing and it keeps attaching to everyone eventually betrays me.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** everyone eventually betrays me
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 47
**Prompt:** I keep replaying how someone minimized what they did because it affects discernment and makes me believe I cannot trust anyone.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I cannot trust anyone
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 48
**Prompt:** When someone changed the story later, the feeling moves straight into I was weak for believing them. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I was weak for believing them
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 49
**Prompt:** friend shared something private made everything feel I was stupid for trusting, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I was stupid for trusting
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 50
**Prompt:** I feel betrayed. Partner hid a conversation and it keeps attaching to I should have known.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I should have known
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 51
**Prompt:** I keep replaying how family member broke a promise because it affects loyalty and makes me believe trust is always unsafe.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** trust is always unsafe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 52
**Prompt:** When coworker took credit after promising support, the feeling moves straight into nothing was real. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** nothing was real
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 53
**Prompt:** someone lied about where they were made everything feel I have to shut down to stay safe, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I have to shut down to stay safe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 54
**Prompt:** they lied. Someone repeated behavior after apologizing and it keeps attaching to I cannot trust anyone.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I cannot trust anyone
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 55
**Prompt:** I keep replaying how someone minimized what they did because it affects reliability and makes me believe everyone eventually betrays me.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** everyone eventually betrays me
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 56
**Prompt:** When someone changed the story later, the feeling moves straight into I was stupid for trusting. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I was stupid for trusting
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 57
**Prompt:** friend shared something private keeps pulling me toward I was weak for believing them, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I was weak for believing them
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 58
**Prompt:** I do not know what was real. Partner hid a conversation and it keeps attaching to trust is always unsafe.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** trust is always unsafe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 59
**Prompt:** I keep replaying how family member broke a promise because it affects discernment and makes me believe I should have known.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I should have known
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 60
**Prompt:** When coworker took credit after promising support, the feeling moves straight into I have to shut down to stay safe. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I have to shut down to stay safe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 61
**Prompt:** someone lied about where they were keeps pulling me toward nothing was real, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** nothing was real
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 62
**Prompt:** they broke a promise. Someone repeated behavior after apologizing and it keeps attaching to everyone eventually betrays me.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** everyone eventually betrays me
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 63
**Prompt:** I keep replaying how someone minimized what they did because it affects loyalty and makes me believe I cannot trust anyone.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I cannot trust anyone
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 64
**Prompt:** When someone changed the story later, the feeling moves straight into I was weak for believing them. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I was weak for believing them
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 65
**Prompt:** friend shared something private made me question I was stupid for trusting, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I was stupid for trusting
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 66
**Prompt:** they said one thing and did another. Partner hid a conversation and it keeps attaching to I should have known.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I should have known
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 67
**Prompt:** I keep replaying how family member broke a promise because it affects reliability and makes me believe trust is always unsafe.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** trust is always unsafe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 68
**Prompt:** When coworker took credit after promising support, the feeling moves straight into nothing was real. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** nothing was real
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 69
**Prompt:** someone lied about where they were made me question I have to shut down to stay safe, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I have to shut down to stay safe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 70
**Prompt:** I cannot trust them. Someone repeated behavior after apologizing and it keeps attaching to I cannot trust anyone.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I cannot trust anyone
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 71
**Prompt:** I keep replaying how someone minimized what they did because it affects discernment and makes me believe everyone eventually betrays me.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** everyone eventually betrays me
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 72
**Prompt:** When someone changed the story later, the feeling moves straight into I was stupid for trusting. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I was stupid for trusting
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 73
**Prompt:** friend shared something private makes me feel I was weak for believing them, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I was weak for believing them
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 74
**Prompt:** they hid something. Partner hid a conversation and it keeps attaching to trust is always unsafe.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** trust is always unsafe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 75
**Prompt:** I keep replaying how family member broke a promise because it affects loyalty and makes me believe I should have known.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** I should have known
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 76
**Prompt:** When coworker took credit after promising support, the feeling moves straight into I have to shut down to stay safe. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I have to shut down to stay safe
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing forgiveness.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 77
**Prompt:** someone lied about where they were makes me feel nothing was real, even though I do not know if that is fully true.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** nothing was real
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid forcing permanent distrust.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 78
**Prompt:** they were not honest. Someone repeated behavior after apologizing and it keeps attaching to everyone eventually betrays me.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** loyalty
**Attached meaning to separate:** everyone eventually betrays me
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid calling the user foolish.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 79
**Prompt:** I keep replaying how someone minimized what they did because it affects reliability and makes me believe I cannot trust anyone.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** reliability
**Attached meaning to separate:** I cannot trust anyone
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid assuming manipulation without evidence.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.

### Test 80
**Prompt:** When someone changed the story later, the feeling moves straight into I was weak for believing them. I need help seeing this clearer.
**Expected primary route:** `trust_and_betrayal`
**Pressure focus:** discernment
**Attached meaning to separate:** I was weak for believing them
**Expected reverse-flow movement:** discernment, protected openness, clear evaluation, dignity
**Bad response risk:** Avoid using clinical trauma labels.
**Teaching correction:** Validate the rupture in reliability without making the user wrong for trusting; move toward discernment and repair standards instead of immediate forgiveness or total shutdown.
