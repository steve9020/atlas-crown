const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class IsolatedAuditLogger {
  constructor(config = {}) {
    this.vaultPath = config.storageDirectory || path.join(process.cwd(), '.audit_vault', 'system_faults');
    this.isDebugMode = !!config.debugMode;
    this.ensureVaultExists();
  }

  ensureVaultExists() {
    try {
      if (!fs.existsSync(this.vaultPath)) fs.mkdirSync(this.vaultPath, { recursive: true });
    } catch (error) {
      console.error(`CRITICAL FAILURE: Could not establish Audit Vault directory: ${error.message}`);
    }
  }

  stringify(payload) {
    if (typeof payload === 'string') return payload;
    try { return JSON.stringify(payload); } catch (_) { return String(payload); }
  }

  computePayloadHash(payload) {
    return crypto.createHash('sha256').update(this.stringify(payload)).digest('hex');
  }

  getPayloadSize(payload) {
    return Buffer.byteLength(this.stringify(payload), 'utf8');
  }

  async logViolationArtifact(violationData = {}) {
    try {
      const timestamp = violationData.timestamp || new Date().toISOString();
      const cleanTimestamp = timestamp.replace(/[:.]/g, '-');
      const uniqueId = Math.random().toString(36).substring(2, 9);
      const filename = `violation_${cleanTimestamp}_${uniqueId}.json`;
      const fullTargetFilePath = path.join(this.vaultPath, filename);
      const structuralArtifact = {
        auditRecordId: uniqueId,
        capturedAt: timestamp,
        incidentClassification: 'HARD_GOVERNANCE_VIOLATION',
        ruleBreachReport: violationData.message || 'Governance violation contained.',
        rule: violationData.rule || 'unknown',
        quarantinedPayload: violationData.payload
      };
      await fs.promises.writeFile(fullTargetFilePath, JSON.stringify(structuralArtifact, null, 2), 'utf8');
      console.warn('[AUDIT VAULT SECURED]: Contained payload safely written to disk vault.');
      return fullTargetFilePath;
    } catch (error) {
      const redactedSummary = {
        incidentClassification: 'HARD_GOVERNANCE_VIOLATION_DISK_FAILURE',
        failureReason: error.message,
        capturedAt: violationData.timestamp || new Date().toISOString(),
        ruleBreachReport: violationData.message || 'Governance violation contained.',
        payloadFingerprintSHA256: this.computePayloadHash(violationData.payload),
        payloadSizeBytes: this.getPayloadSize(violationData.payload)
      };
      console.error('FATAL CONTAINMENT ERROR: Failed to write audit artifact.');
      if (this.isDebugMode) console.error('DEBUG MODE RAW DUMP:', JSON.stringify(violationData));
      else console.error('PRIVACY-PRESERVED SUMMARY DUMP:', JSON.stringify(redactedSummary, null, 2));
      throw error;
    }
  }
}

module.exports = IsolatedAuditLogger;
