# Atlas Learning Workflow Operationalization

## Purpose
This folder defines Step 6: making Atlas learning operational instead of only conceptual.

Atlas may notice missing understanding, weak response behavior, unclear emotional routing, or a new pattern, but it must not silently mutate the backend.

## Operational Flow
1. Detect a possible learning need.
2. Create a proposed learning entry.
3. Send the proposal to review.
4. Require approval, merge, defer, or rejection.
5. Draft integration into the correct backend registry.
6. Write approved learning only after review.
7. Reload runtime graph/backend registries so approved learning becomes readable.

## Core Rule
Atlas can propose learning.
Steve approves learning.
The backend stores approved learning.
Compass expresses approved learning lightly.

## Safety Boundary
No automatic self-expansion is allowed without approval-gate review.
