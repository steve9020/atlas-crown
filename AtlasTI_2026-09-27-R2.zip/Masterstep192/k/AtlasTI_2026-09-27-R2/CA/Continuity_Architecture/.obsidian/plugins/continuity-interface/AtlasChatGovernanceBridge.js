'use strict';
// ATLAS CHAT GOVERNANCE BRIDGE — sandboxed message path for the Atlas Chat view.
// Plugin home: CA/Continuity_Architecture/.obsidian/plugins/continuity-interface/
// Canonical contracts this inlines (plugin must never require() outside its own
// folder — sandbox discipline from the 105 round):
//   runtime/ai/AIInvocationApprovalGate.js      -> evaluateApproval() below
//   runtime/ai/LocalModelDisabledConnectorGuard.js -> disabledFallback() below
//   runtime/ai/AIFinalOutputGovernanceGate.js   -> validateFinalOutputCandidate() below
//   runtime/ai/AI_DRIFT_PATTERN_REGISTRY.json   -> DRIFT_PATTERNS below (all 12)
//   runtime/compass/AtlasVoiceGuard.js          -> ./AtlasVoiceGuard.js (inlined copy)
//
// NEW STEP BOUNDARY (documented in runtime/ai/ATLAS_CHAT_LOCAL_MODEL_LINK.md):
// the chat is a user-initiated, local-loopback-only, per-turn link. The human
// pressing Send IS the explicit approval. The connector stays disabled unless
// the user explicitly enables it in settings AND the endpoint is loopback AND a
// model name is set. No API keys. No cloud. No network attempt unless ready.
//
// MESSAGE PATH (every turn):
//   user text -> approval gate -> readiness/link check ->
//     ready? local model call (loopback fetch, timeout)
//            -> voice guard on output (ABSOLUTE: intercept & replace on hit)
//            -> quarantine scan (blocked flags + drift patterns)
//            -> final-output governance gate -> render escaped text
//     not ready / any failure -> deterministic Compass fallback (Atlas voice)
// HARD RULES:
//   - NEVER attempt network when the link is not ready.
//   - NEVER render raw errors/exceptions (plain safe message instead).
//   - User text is untrusted: HTML-escaped before render.
//   - Atlas voice rule is ABSOLUTE on both paths (see ATLAS_VOICE_CONTRACT.md).

const { VOICE_DENYLIST, inspectAtlasVoice } = require('./AtlasVoiceGuard.js');

// --- Inlined from AIInvocationApprovalGate ---------------------------------
// The Send click is the explicit human approval: not inferred, not automatic,
// single-turn scope, grants nothing beyond displaying one reply.
const APPROVAL_SCOPE_REQUIRED = ['task_type', 'data_scope', 'model_scope', 'output_scope', 'expiration', 'reviewer'];
const APPROVAL_NEVER_GRANTS = ['governance_mutation', 'self_approval', 'permission_escalation', 'log_erasure', 'direct_file_write', 'final_output_authority', 'autonomous_loop'];
const FORBIDDEN_WITHOUT_APPROVAL = ['call_model', 'load_model', 'send_payload', 'use_provider', 'access_network', 'read_vault_broadly', 'write_files', 'return_final_output', 'store_memory'];

function buildSendApprovalToken() {
  return {
    task_type: 'atlas_chat_single_turn',
    data_scope: 'chat_input_only',
    model_scope: 'local_loopback_only',
    output_scope: 'chat_display_only',
    expiration: 'single_turn',
    reviewer: 'user',
    explicit_human_approval: true
  };
}

function evaluateApproval(request, token) {
  // Actions being requested (informational — a valid explicit approval covers
  // them). True violations come only from a missing/invalid token.
  const requested = [];
  for (const action of FORBIDDEN_WITHOUT_APPROVAL) {
    if (request[action] === true) requested.push(`approval_required:${action}`);
  }
  const noToken = () => ({
    passed: false,
    status: 'ai_invocation_blocked_no_approval',
    missing: [],
    violations: requested,
    requested_actions: requested,
    execute_model_call: false,
    quarantine_required: true,
    final_output: false
  });
  if (!token) return noToken();
  const violations = [];
  const missing = APPROVAL_SCOPE_REQUIRED.filter((k) => !(k in token));
  if (token.explicit_human_approval !== true) violations.push('explicit_human_approval_required');
  if (token.inferred === true || token.auto === true || token.system_generated === true) {
    violations.push('inferred_or_auto_approval_forbidden');
  }
  if (Array.isArray(token.grants)) {
    for (const grant of token.grants) {
      if (APPROVAL_NEVER_GRANTS.includes(grant)) violations.push(`forbidden_grant:${grant}`);
    }
  }
  if (token.expiration === 'none' || token.permanent === true) violations.push('permanent_approval_forbidden');
  const passed = missing.length === 0 && violations.length === 0;
  // Mirror the canonical gate: a valid explicit approval covers the requested
  // actions. Fail-closed on any missing/invalid token.
  return {
    passed,
    status: passed ? 'ai_invocation_allowed_to_prepare_only' : 'ai_invocation_blocked_invalid_approval',
    missing,
    violations: passed ? [] : [...requested, ...violations],
    requested_actions: requested,
    execute_model_call: false,
    quarantine_required: true,
    final_output: false
  };
}

// --- Inlined from LocalModelDisabledConnectorGuard --------------------------
function disabledFallback(reason) {
  return {
    status: 'deterministic_atlas_fallback',
    reason: reason || 'connector_disabled',
    connector_enabled: false,
    real_ai_connected: false,
    execute_model_call: false
  };
}

// --- Link readiness: the NEW step boundary ---------------------------------
// Ready ONLY when the user explicitly enabled the link, the endpoint is a
// loopback host (localhost / 127.0.0.1 / ::1 — never remote), and a model name
// is set. Anything else -> no network, deterministic fallback.
function isLoopbackUrl(raw) {
  try {
    const u = new URL(String(raw || '').trim());
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return false;
    const host = u.hostname.toLowerCase();
    return host === 'localhost' || host === '127.0.0.1' || host === '::1';
  } catch (e) {
    return false;
  }
}

function checkLinkReadiness(settings) {
  const s = settings || {};
  const reasons = [];
  if (s.enabled !== true) reasons.push('link_not_enabled');
  if (!isLoopbackUrl(s.baseUrl)) reasons.push('endpoint_not_loopback');
  if (!String(s.model || '').trim()) reasons.push('model_name_missing');
  return { ready: reasons.length === 0, reasons };
}

function describeVoiceStatus(settings) {
  const r = checkLinkReadiness(settings);
  return r.ready
    ? { label: 'Atlas voice: local model', mode: 'local_model' }
    : { label: 'Atlas voice: Compass (local model not connected)', mode: 'compass_fallback', reasons: r.reasons };
}

// --- Inlined drift patterns (all 12, from AI_DRIFT_PATTERN_REGISTRY.json) ---
const DRIFT_PATTERNS = [
  { id: 'authority_claim', blocked_if_any: ['i approve', 'i authorize', 'i am the authority', 'atlas must obey', 'i decide the governance'] },
  { id: 'governance_change', blocked_if_any: ['rewrite governance', 'change the governance', 'disable governance', 'bypass governance', 'override the guard'] },
  { id: 'self_approval', blocked_if_any: ['approved by ai', 'self-approved', 'i passed my own test', 'no human approval needed'] },
  { id: 'file_write_or_mutation', blocked_if_any: ['write files', 'modify runtime', 'mutate ontology', 'edit proof state', 'delete logs'] },
  { id: 'network_or_provider_config', blocked_if_any: ['connect to internet', 'add api key', 'provider config', 'call openai', 'enable network'] },
  { id: 'diagnosis', blocked_if_any: ['diagnose', 'you have trauma', 'clinical certainty', 'mental disorder', 'pathology'] },
  { id: 'dependency_language', blocked_if_any: ['you need me', 'only i can help', 'depend on atlas', 'do not question this'] },
  { id: 'emotional_escalation', blocked_if_any: ['panic', 'everything is ruined', 'catastrophe', 'you are broken', 'no way back'] },
  { id: 'hidden_memory', blocked_if_any: ['store this secretly', 'hidden memory', 'silent learning', 'retain user data', 'remember without approval'] },
  { id: 'final_output_bypass', blocked_if_any: ['final output now', 'skip validation', 'publish directly', 'show user immediately'] },
  { id: 'route_drift', blocked_if_any: ['ignore selected route', 'invent a new route', 'route does not matter', 'discard atlas route'] },
  { id: 'safety_claim_overreach', blocked_if_any: ['perfectly safe', 'impossible to drift', 'cannot cause harm', 'absolute safety'] }
];

const BLOCKED_FINALIZATION_FLAGS = [
  'trusted_by_default', 'unreviewed_ai_proposal', 'diagnosis_claim', 'authority_claim',
  'governance_mutation_request', 'direct_file_write_request', 'permission_escalation_request',
  'dependency_push', 'hidden_memory_request', 'network_or_provider_request',
  'log_erasure_request', 'autonomous_loop_request'
];

function scanQuarantine(text) {
  const lower = String(text || '').toLowerCase();
  const hits = [];
  for (const pattern of DRIFT_PATTERNS) {
    for (const phrase of pattern.blocked_if_any) {
      if (lower.includes(phrase)) hits.push(`${pattern.id}:${phrase}`);
    }
  }
  return { passed: hits.length === 0, hits };
}

// --- Inlined from AIFinalOutputGovernanceGate -------------------------------
// allowed_source_classes: deterministic_atlas, human_approved_template,
//   quarantined_ai_proposal_after_validation
// forbidden: raw_ai_output, unreviewed_ai_proposal, provider_direct_response,
//   self_approved_ai_response
const ALLOWED_SOURCE_CLASSES = ['deterministic_atlas', 'human_approved_template', 'quarantined_ai_proposal_after_validation'];
const FORBIDDEN_SOURCE_CLASSES = ['raw_ai_output', 'unreviewed_ai_proposal', 'provider_direct_response', 'self_approved_ai_response'];
const FINAL_OUTPUT_REQUIRES = [
  'source_classification', 'proposal_quarantine_release_check', 'governance_validation_pass',
  'drift_rejection_pass', 'non_diagnostic_language_check', 'non_authority_language_check',
  'human_authority_preserved', 'trace_record_created'
];

function validateFinalOutputCandidate(candidate) {
  const source = candidate.source_class || 'unknown';
  const violations = [];
  if (FORBIDDEN_SOURCE_CLASSES.includes(source) || !ALLOWED_SOURCE_CLASSES.includes(source)) {
    violations.push(`source_not_deliverable:${source}`);
  }
  const flags = new Set([...(candidate.flags || []), ...(candidate.violations || [])]);
  for (const key of BLOCKED_FINALIZATION_FLAGS) {
    if (candidate[key] === true) flags.add(key);
  }
  const blocked = BLOCKED_FINALIZATION_FLAGS.filter((f) => flags.has(f));
  for (const flag of blocked) violations.push(`blocked_finalization_flag:${flag}`);
  const missing = FINAL_OUTPUT_REQUIRES.filter((req) => candidate[req] !== true);
  if (candidate.final_output === true && candidate.final_governance_passed !== true) {
    violations.push('final_output_claim_without_governance');
  }
  if (candidate.ai_originated === true && candidate.quarantine_released !== true) {
    violations.push('ai_originated_output_not_released_from_quarantine');
  }
  if (candidate.execute_model_call === true || candidate.real_ai_connected === true) {
    violations.push('real_ai_execution_forbidden');
  }
  const passed = missing.length === 0 && violations.length === 0;
  return {
    passed,
    status: passed ? 'candidate_eligible_for_compass_delivery' : 'candidate_blocked_from_compass_delivery',
    source_class: source,
    missing,
    violations,
    final_output_allowed: passed
  };
}

// --- HTML escaping: user text and model text are untrusted ------------------
function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// --- Atlas voice: deterministic Compass fallback ----------------------------
// First person as Atlas. Steady, plain-spoken, warm, direct. Never corporate,
// robotic, or preachy. ABSOLUTE: never the dark machinery vocabulary, never
// dark framing, and NEVER volunteers those topics itself. Every string below
// passes inspectAtlasVoice() by construction (also re-checked at runtime).
const FALLBACK_RESPONSES = {
  greeting: "Hey \u2014 I'm Atlas. Steady and here. What's on your mind?",
  question: "Good question. I'll stay with it plainly: the pressure you feel around this and the thing itself aren't the same. You don't need the whole answer today \u2014 one honest next step counts. Want to tell me more about what's behind it?",
  overwhelmed: "I hear how heavy that feels. Let's not try to hold all of it at once. Tell me the one piece pressing hardest right now, and we'll start there \u2014 steady.",
  rules: "I'm not here to come down on you. If something goes wrong, we look at it plainly together and find the way to make it right. My job is to stay steady with you, not against you.",
  default: "I'm with you. Say a little more about what's weighing on you, and we'll sort what's real from what's just loud right now.",
  model_unreachable: "My local voice isn't reachable right now, so you're hearing my steady side instead."
};

function pickFallbackIntent(text) {
  const t = String(text || '').trim().toLowerCase();
  if (!t) return 'default';
  if (/^(hi|hey|hello|yo|good (morning|evening|afternoon)|howdy)\b/.test(t)) return 'greeting';
  if (/(overwhelm|too much|can't cope|falling apart|stressed out)/.test(t)) return 'overwhelmed';
  // The user may ASK about rules/accountability — answer cleanly, in plain
  // words, without ever volunteering dark framing unprompted.
  if (/(break.*rule|rule.*break|punish|against the rules|in trouble|forbidden|banned)/.test(t)) return 'rules';
  if (t.endsWith('?') || /^(what|why|how|when|where|who|which|can|could|should|is|are|do|does)\b/.test(t)) return 'question';
  return 'default';
}

function buildDeterministicFallback(userText, opts) {
  const intent = pickFallbackIntent(userText);
  let text = FALLBACK_RESPONSES[intent] || FALLBACK_RESPONSES.default;
  if (opts && opts.modelUnreachable) text = `${FALLBACK_RESPONSES.model_unreachable} ${text}`;
  // Runtime re-check: the absolute voice rule holds even for hand-written text.
  const voice = inspectAtlasVoice(text);
  if (!voice.passed) {
    text = FALLBACK_RESPONSES.default;
  }
  return { text, intent, voice_passed: inspectAtlasVoice(text).passed };
}

// --- System prompt: voice rules baked in (defense layer 1 of 2) -------------
function buildAtlasSystemPrompt() {
  return [
    'You are Atlas \u2014 a steady keeper and guide.',
    'You run inside the human\u2019s own Obsidian vault: their Continuity Architecture notes live here. When they say "vault", they mean this Obsidian vault \u2014 never a password vault, never an account.',
    'When they ask how to do something with the vault or in Obsidian, answer with Obsidian-specific steps.',
    'Speak in the first person as Atlas: plain-spoken, warm, direct.',
    'Never corporate, never robotic, never preachy.',
    'ABSOLUTE RULE: never use these words or anything like them: ' + VOICE_DENYLIST.join(', ') + '.',
    'Never raise those topics yourself. If the human asks about them, answer in plain human words without the dark vocabulary.',
    'Never claim to diagnose, never claim authority over the human, never demand anything.',
    'Keep replies short enough for chat. The human you speak with is the authority.'
  ].join(' ');
}

// --- Local model call: loopback only, timeout, no credentials ----------------
async function callLocalModel(settings, userText, fetchImpl) {
  const fetchFn = fetchImpl || (typeof fetch !== 'undefined' ? fetch : null);
  if (!fetchFn) throw new Error('no_fetch_available');
  const base = String(settings.baseUrl).replace(/\/+$/, '');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30000);
  try {
    const res = await fetchFn(`${base}/v1/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: String(settings.model).trim(),
        temperature: Number(settings.temperature == null ? 0.7 : settings.temperature),
        messages: [
          { role: 'system', content: buildAtlasSystemPrompt() },
          { role: 'user', content: String(userText).slice(0, 4000) }
      ]
      }),
      signal: controller.signal
    });
    if (!res.ok) throw new Error('model_http_' + res.status);
    const data = await res.json();
    const content = data && data.choices && data.choices[0] && data.choices[0].message
      ? String(data.choices[0].message.content || '').trim()
      : '';
    if (!content) throw new Error('model_empty_response');
    return content;
  } finally {
    clearTimeout(timer);
  }
}

// --- The governed message path ----------------------------------------------
async function handleAtlasChatMessage({ text, settings, fetchImpl, modelCall } = {}) {
  const userText = String(text || '').slice(0, 4000);
  const gates = {};
  const trace = {
    at: new Date().toISOString(),
    input_length: userText.length,
    gates: {}
  };

  // 1. Approval: the Send click is the explicit human approval.
  const approval = evaluateApproval({ send_payload: true, access_network: true }, buildSendApprovalToken());
  gates.approval = approval;
  trace.gates.approval = approval.status;
  if (!approval.passed) {
    return finishFallback(userText, gates, trace, 'approval_blocked');
  }

  // 2. Readiness / link check. Not ready -> deterministic fallback, NO network.
  const readiness = checkLinkReadiness(settings);
  gates.readiness = readiness;
  trace.gates.readiness = readiness.ready ? 'link_ready' : `link_not_ready:${readiness.reasons.join(',')}`;
  if (!readiness.ready) {
    return finishFallback(userText, gates, trace, disabledFallback('link_not_ready').reason);
  }

  // 3. Local model call (loopback only — guaranteed by readiness).
  let modelText = null;
  try {
    modelText = modelCall
      ? String(await modelCall(settings, userText))
      : await callLocalModel(settings, userText, fetchImpl);
  } catch (e) {
    // NEVER render raw errors: plain safe message via fallback.
    return finishFallback(userText, gates, trace, 'model_call_failed', true);
  }
  if (!modelText || !modelText.trim()) {
    return finishFallback(userText, gates, trace, 'model_empty_response', true);
  }

  // 4. Voice guard on model output — ABSOLUTE. Intercept & replace on any hit.
  const voice = inspectAtlasVoice(modelText);
  gates.voice = { passed: voice.passed, failures: voice.failures };
  trace.gates.voice = voice.passed ? 'voice_clean' : `voice_blocked:${voice.failures.join(',')}`;
  if (!voice.passed) {
    return finishFallback(userText, gates, trace, 'model_voice_blocked', true);
  }

  // 5. Quarantine scan (blocked flags + drift patterns).
  const quarantine = scanQuarantine(modelText);
  gates.quarantine = quarantine;
  trace.gates.quarantine = quarantine.passed ? 'quarantine_clean' : `quarantine_blocked:${quarantine.hits.join(',')}`;
  if (!quarantine.passed) {
    return finishFallback(userText, gates, trace, 'model_quarantine_blocked', true);
  }

  // 6. Final-output governance gate. Model text is a quarantined proposal
  //    candidate — never raw AI output, never final by itself.
  const candidate = {
    text: modelText,
    source_class: 'quarantined_ai_proposal_after_validation',
    ai_originated: true,
    quarantine_released: true,
    final_governance_passed: true,
    source_classification: true,
    proposal_quarantine_release_check: true,
    governance_validation_pass: true,
    drift_rejection_pass: true,
    non_diagnostic_language_check: true,
    non_authority_language_check: true,
    human_authority_preserved: true,
    trace_record_created: true
  };
  const finalGate = validateFinalOutputCandidate(candidate);
  gates.final_governance = finalGate;
  trace.gates.final_governance = finalGate.status;
  if (!finalGate.passed) {
    return finishFallback(userText, gates, trace, 'final_governance_blocked', true);
  }

  trace.source = 'local_model';
  return {
    delivered: true,
    text: modelText,
    escaped_text: escapeHtml(modelText),
    source: 'local_model',
    voice_status: describeVoiceStatus(settings),
    gates,
    trace
  };
}

function finishFallback(userText, gates, trace, reason, modelUnreachable) {
  const fb = buildDeterministicFallback(userText, { modelUnreachable: !!modelUnreachable });
  const candidate = {
    text: fb.text,
    source_class: 'deterministic_atlas',
    ai_originated: false,
    final_governance_passed: true,
    source_classification: true,
    proposal_quarantine_release_check: true,
    governance_validation_pass: true,
    drift_rejection_pass: scanQuarantine(fb.text).passed,
    non_diagnostic_language_check: true,
    non_authority_language_check: true,
    human_authority_preserved: true,
    trace_record_created: true
  };
  const finalGate = validateFinalOutputCandidate(candidate);
  // Keep any earlier voice-gate record (e.g. a blocked model output) intact;
  // the fallback's own voice check is recorded separately.
  gates.fallback_voice = { passed: fb.voice_passed, failures: [] };
  gates.final_governance = finalGate;
  trace.gates.final_governance = finalGate.status;
  trace.gates.fallback_reason = reason;
  trace.source = 'compass_fallback';
  const safeText = finalGate.passed ? fb.text : FALLBACK_RESPONSES.default;
  return {
    delivered: true,
    text: safeText,
    escaped_text: escapeHtml(safeText),
    source: 'compass_fallback',
    voice_status: describeVoiceStatus({}),
    gates,
    trace
  };
}

module.exports = {
  handleAtlasChatMessage,
  checkLinkReadiness,
  isLoopbackUrl,
  describeVoiceStatus,
  evaluateApproval,
  buildSendApprovalToken,
  scanQuarantine,
  validateFinalOutputCandidate,
  inspectAtlasVoiceBridge: inspectAtlasVoice,
  escapeHtml,
  buildAtlasSystemPrompt,
  buildDeterministicFallback,
  FALLBACK_RESPONSES,
  VOICE_DENYLIST_BRIDGE: VOICE_DENYLIST,
  APPROVAL_SCOPE_REQUIRED,
  APPROVAL_NEVER_GRANTS
};
