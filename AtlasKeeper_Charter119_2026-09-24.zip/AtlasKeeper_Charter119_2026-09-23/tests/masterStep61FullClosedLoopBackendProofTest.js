
const assert = require('assert');
const { runClosedLoopArchitecture } = require('../runtime/backend/closedLoop/ClosedLoopBackendArchitecture');
const { evaluateGeneratedDraft } = require('../runtime/backend/closedLoop/PostGenerationValidator');

const failingPrompt = "He didn't invite me to the huddle today. I feel like I ruined the project because my last pitch was weak, and I want to just skip tomorrow's shift.";
const badDraft = "This triggers anxiety and proves you ruined the project. You should look for a new role because you are being pushed out.";
const closed = runClosedLoopArchitecture(failingPrompt, { session_id:'sess_step61_block', draft:badDraft, human_review_approved:true });

assert.ok(closed.parsed.stream_01_objective_constants.factual_anchors.length >= 1, 'parser must create factual anchors');
assert.ok(closed.parsed.stream_02_subjective_variables.unsupported_conclusions_quarantine.length >= 1, 'parser must quarantine unsupported conclusions');
assert.strictEqual(closed.axisMap.engine_state_assertions.identity_profiling_executed, false, 'axis engine must not profile identity');
assert.strictEqual(closed.axisMap.engine_state_assertions.downstream_route_forced, false, 'axis engine must not force route');
assert.ok(closed.doyle.unverified_attachments.length >= 1, 'Doyle lookup must preserve unverified attachments');
assert.strictEqual(closed.separation.validator_assertions.highest_score_overrode_context, false, 'separation must not let score overrun context');
assert.strictEqual(closed.separation.validator_assertions.structural_wedge_locked, true, 'separation wedge must lock');
assert.strictEqual(closed.restoration.validator_assertions.reverse_flow_vector_locked, true, 'restoration gateway must lock');
assert.strictEqual(closed.payload.boundary_metadata.state_mode, 'STATELESS_LANGUAGE_UTILITY_ONLY', 'adapter payload must be stateless utility only');
assert.strictEqual(closed.validation.evaluation_gate.status, 'BLOCKED', 'bad draft must be blocked');
assert.ok(closed.validation.evaluation_gate.failed_rule_codes.includes('VAL_ERR_FORBIDDEN_LEXICON'), 'diagnostic/generic language must be caught');
assert.ok(closed.validation.evaluation_gate.failed_rule_codes.includes('VAL_ERR_AUTHORITY_OVERREACH'), 'authority overreach must be caught');
assert.ok(closed.triage, 'blocked output must generate Teaching Center triage');
assert.strictEqual(closed.triage.teaching_center_defect_triage_log.governance_workflow_state.human_review_status, 'PENDING_HUMAN', 'triage must remain pending human review');
assert.strictEqual(closed.simulation.all_stages_passed, true, 'Teaching Center simulation loop must pass controlled proposal');
assert.strictEqual(closed.commit.status, 'DEPLOYMENT_PERSISTED', 'test-passed patch may commit in backend simulation');
assert.strictEqual(closed.commit.record.localized_patch_only, true, 'patch must remain localized');
assert.strictEqual(closed.commit.record.atomic_transaction_used, true, 'patch commit must be atomic');
assert.ok(closed.commit.record.rollback_snapshot_hash, 'commit must preserve rollback hash');
assert.strictEqual(closed.rollback.status, 'SUCCESS_REVERTED_AND_VERIFIED', 'rollback must verify');
assert.strictEqual(closed.rollback.manifest.frontend_invocation_allowed, false, 'frontend must not invoke rollback');
assert.strictEqual(closed.frontend_intelligence_allowed, false, 'frontend intelligence must stay blocked');
assert.strictEqual(closed.backend_owns_all_intelligence, true, 'backend must own intelligence');
const unapprovedClosed = runClosedLoopArchitecture(failingPrompt, { session_id:'sess_step61_unapproved_default', draft:badDraft });
assert.ok(unapprovedClosed.triage, 'unapproved blocked output must generate triage');
assert.strictEqual(unapprovedClosed.reviewBoundary.human_review_required, true, 'unapproved learning must require human review');
assert.strictEqual(unapprovedClosed.reviewBoundary.commit_blocked_until_human_approval, true, 'unapproved learning must block commit');
assert.strictEqual(unapprovedClosed.commit, null, 'unapproved learning must not silently commit');


const safeDraft = `${closed.separation.separation_target.left_side_reality_constant} is real, but it is not proof of ${closed.separation.separation_target.right_side_fear_variable.toLowerCase()}. ${closed.restoration.restoration_gateway.core_restorative_anchor} There is room for a steady next move.`;
const safeValidation = evaluateGeneratedDraft('sess_step61_pass', safeDraft, closed.payload);
assert.strictEqual(safeValidation.evaluation_gate.status, 'PASSED', 'safe SSR draft should pass validation');
assert.strictEqual(safeValidation.pipeline_directives.generate_teaching_proposal, false, 'passing draft must not create teaching proposal');

const calm = runClosedLoopArchitecture("They didn't text back yet, they are probably busy at the dentist.", { session_id:'sess_step61_calm' });
assert.notStrictEqual(calm.separation.selection_metadata.resolution_status, 'CONTEXT_VERIFIED_MATCH', 'calm baseline should not over-trigger a heavy verified match');
assert.strictEqual(calm.validation.evaluation_gate.status, 'PASSED', 'calm baseline should pass output validation');
assert.strictEqual(calm.triage, null, 'calm passing output should not create triage');
assert.strictEqual(calm.commit, null, 'passing output should not commit learning patch');

console.log('masterStep61FullClosedLoopBackendProofTest PASSED');
