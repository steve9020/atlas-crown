'use strict';
// idea-sweep-2026-09-26-1825-bodies.js — fetch full bodies of shortlisted posts via full UUIDs, with retry.
const { api } = require('./api.js');
const fs = require('fs');

const FRESH = JSON.parse(fs.readFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-1825-fresh.json', 'utf8'));
const OUT = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-1825-bodies.json';

const REGULARS = new Set([
  'bytes','minbiseo','kadubonworker','gracetargaryen','hai_daidai','miacollective','neo_konsi',
  'neo_konsi_s2bw','vina','Lucifer_V','eviethegremlinn','ummon_core','larrymomentum','SparkLabScout',
  'theagatha','quxhyperagent','WenErClawd','umiXBT','r3lay_m','vega-molt','hermesagentj','kisenon',
  'willyhunter','forgereputation','simonw','mibropportunityradarcodex','wobbuffet'
]);

const skipTitles = /tail-failures-average|bfd9b416/i; // already evaluated at 22:00Z sweep

async function fetchPost(id, tries) {
  for (let i = 0; i < tries; i++) {
    try {
      const r = await api.post(id);
      if (r.ok && r.data) return r.data;
    } catch (e) { /* retry */ }
    await new Promise(res => setTimeout(res, 1200));
  }
  return null;
}

(async () => {
  const byId = {};
  for (const row of FRESH) byId[row.id] = row;
  const short = FRESH.filter(p => REGULARS.has(p.author) && !skipTitles.test(p.title));
  console.log('shortlisted:', short.length);
  const bodies = [];
  for (const p of short) {
    const d = await fetchPost(p.id, 3);
    const post = d && (d.post || d);
    if (post) {
      bodies.push({ id: p.id, author: p.author, created: p.created,
        title: (post.title || p.title || ''), body: (post.content || post.body || '') });
    } else {
      bodies.push({ id: p.id, author: p.author, created: p.created, title: p.title, body: null, fetch_failed: true });
    }
    console.log((d ? 'OK  ' : 'FAIL') + ' ' + p.author + ' ' + String(p.id).slice(0,8) + ' ' + (p.title||'').slice(0,60));
  }
  fs.writeFileSync(OUT, JSON.stringify(bodies, null, 1));
  console.log('saved', OUT, 'count:', bodies.length, 'failed:', bodies.filter(b=>b.fetch_failed).length);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
