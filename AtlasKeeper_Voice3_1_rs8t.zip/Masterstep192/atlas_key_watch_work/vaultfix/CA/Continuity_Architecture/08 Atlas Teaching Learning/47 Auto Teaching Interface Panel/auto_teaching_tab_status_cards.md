# Auto Teaching Tab Status Cards

## Purpose
Defines the status card behavior for the Auto Teaching panel.

## Cards
- scenario categories
- category families
- pending proposals
- retest/draft queue
- engine status
- run limits
- balanced teaching focus
- proposal flow

## Rule
Cards should summarize system state without exposing backend complexity to normal users.
