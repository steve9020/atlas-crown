# Auto Teaching History Tracking

## Purpose
Tracks what auto teaching has already tested so it does not repeat itself blindly.

## Track
- run index
- last-used categories
- last-used prompt seeds
- failure pattern counts
- proposals generated this run
- pending proposal count
- category family balance

## Runtime Use
History helps Atlas choose what to test next and what to avoid repeating too soon.

## Rule
Auto teaching should become more balanced over time.
