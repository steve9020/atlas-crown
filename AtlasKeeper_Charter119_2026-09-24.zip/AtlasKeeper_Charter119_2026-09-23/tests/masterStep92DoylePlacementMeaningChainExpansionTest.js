const assert = require('assert');
const { buildCompassResponse } = require('../runtime/compass/CompassResponseBuilderIntegration');
const { mapLiveDoylePlacement } = require('../runtime/indexing/DoyleLivePlacementMapper');

function section(response, name){
  const rx = new RegExp(`${name}\\n([\\s\\S]*?)(?:\\n\\n[A-Z][A-Za-z]+\\n|$)`, 'i');
  const m = response.match(rx);
  return m ? m[1].trim() : '';
}

const cases = [
  {
    name: 'message_feared_worsening_places_into_communication_safety_separation',
    prompt: 'I keep opening the message and closing it because I do not know how to answer without making it worse.',
    requiredPlacements: ['L2:Conflict / Repair', 'L3:Fear / Anxiety', 'L4:Communication / Texting', 'L5:Trust Break / Safety Doubt', 'L7:See-Separate-Restore Structure'],
    requiredResponse: [/message needs care/i, /one answer could make everything worse/i, /reality has not confirmed/i, /understanding shrink around the feared result|feared result/i],
    forbidden: [/falling behind|task backlog|can handle your life/i]
  },
  {
    name: 'silence_self_blame_exposes_middle_chain',
    prompt: 'They usually answer within a few hours. It has been two days now and I keep checking my phone even though I know that will not change anything.',
    requiredPlacements: ['L4:Silence / No Response', 'L6:Silence / Rejection Separation'],
    requiredResponse: [/no answer, the mind starts looking for a reason/i, /maybe something is wrong/i, /maybe you caused it/i, /silence feel like it already knows your place/i],
    forbidden: [/smaller movement|larger task|doorway back/i]
  },
  {
    name: 'public_mistake_places_into_exposure_identity_separation',
    prompt: 'I answered the question wrong in front of everyone. The meeting moved on, but I keep replaying it like it proved something about me.',
    requiredPlacements: ['L2:Self Relationship', 'L3:Shame / Embarrassment', 'L4:Public Exposure / Being Seen', 'L5:Worth / Value Threat', 'L6:Mistake / Identity Separation'],
    requiredResponse: [/one hard piece.*expand into a whole verdict/i, /maybe this says something about you/i, /moment.*carry more identity/i],
    forbidden: [/communication \/ texting/i]
  }
];

for (const c of cases){
  const response = buildCompassResponse(c.prompt);
  assert.strictEqual(response.quality.passed, true, `${c.name} quality failed`);
  assert(response.atlas_semantic_integration.doyle_placement.accepted, `${c.name} Doyle placement rejected`);
  const path = response.atlas_semantic_integration.doyle_placement.primary_layer_path || [];
  for (const required of c.requiredPlacements){
    assert(path.includes(required), `${c.name} missing Doyle placement ${required}; got ${JSON.stringify(path)}`);
  }
  const deconstruct = section(response.response, 'Deconstruct');
  for (const rx of c.requiredResponse){
    assert(rx.test(deconstruct) || rx.test(response.response), `${c.name} missing ${rx}; response was ${response.response}`);
  }
  for (const rx of c.forbidden){
    assert(!rx.test(response.response), `${c.name} forbidden ${rx}; response was ${response.response}`);
  }
}

const direct = mapLiveDoylePlacement('Nothing has actually gone wrong yet, but I have already played out every possible way this could fall apart.');
assert.strictEqual(direct.accepted, true, 'direct Doyle live placement should accept all layers');
assert(direct.primary_layer_path.includes('L6:Fear / Prediction Separation'), `future projection should place into fear/prediction separation: ${JSON.stringify(direct.primary_layer_path)}`);

console.log('masterStep92DoylePlacementMeaningChainExpansionTest PASSED');
