# Duplicate Merge Readiness Metric Registry

## Metric
Duplicate / Merge Readiness %

## Formula
proposals that passed duplicate, merge, conflict, and scope checks ÷ proposals reviewed for those gates

## Meaning
This metric measures whether proposals are safe to move toward integration draft review without duplicating or conflicting with existing backend rules.

## What changes it
- running duplicate/merge/scope/conflict review increases denominator
- completing that gate successfully increases numerator
