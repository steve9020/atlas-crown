# Scenario Uniqueness Duplicate Prevention Runtime

## Purpose

Scenario uniqueness protects testing quality by preventing the generator from repeatedly producing the same conceptual prompt with different wording.

## Duplicate Comparison

Similarity is checked across:

- prompt wording
- category
- expected route
- expected card
- event structure
- attached meaning
- protective/internal reaction
- prompt type

Conceptual duplicates should be caught even when exact wording changes.

## Operational Rule

If Duplicate Similarity is too high, the scenario is excluded from the test queue and marked:

- Too Similar — Regenerate

It should not be run as if it passed the quality gate.

## Allowed Variation

The same category may still generate multiple scenarios when the conceptual frame changes.

Example: relational silence may vary across friend, partner, family, coworker, group, apology, vulnerability, support request, or conflict contexts.

## History

Accepted scenarios are saved into scenario history so future generation can compare against prior prompts. Rejected scenarios are tracked in-session as excluded quality-gate results.

## Operational refinement checkpoint — conceptual uniqueness

Duplicate prevention must compare conceptual similarity, not only exact text overlap.

Current operational requirements:
- compare event type, relationship context, attached meaning, protective reaction, expected route, expected card, and prompt type
- reject or regenerate scenarios that repeat the same conceptual skeleton even when wording changes
- maintain generated-scenario history with concept fields so future generations can avoid repeating the same test shape
- report ready vs rejected scenarios honestly during generation

A same-category scenario may test the same capability, but it should not keep using the same event/meaning/reaction chain unless that repetition is intentional for retesting.

## Operational Refinement — Conceptual Duplicate Check

Duplicate prevention must compare conceptual structure, not only wording. A scenario should be considered too similar when it repeats the same event type, attached meaning type, protective reaction, expected route, and expected card even if the sentence wording changes. Near-duplicate read-no-response / over-fixing / assumed rejection prompts should score high similarity and be regenerated or excluded from the run.
