# Local Context Weighting Test Scan

## Purpose
This scan checks whether the new context-weighting layer catches the type of prompt that exposed the issue.

## Test Results

- `i have childhood trauma that caused abandonment issues` → context hits: childhood_trauma_abandonment, developmental_carryover
- `I opened up about something personal and they laughed` → context hits: general or other context
- `They keep pushing past my boundary and I feel guilty` → context hits: general or other context
- `I keep replaying conversations trying to find what I missed` → context hits: general or other context
- `I have too much to do today and don't know where to start` → context hits: general or other context

## Interpretation
The abandonment/childhood prompt is now explicitly routed toward scenario-specific context before generic emotional processing.

## Follow-Up
After installing the zip, test the same prompt in Obsidian:

`i have childhood trauma that caused abandonment issues`

Expected response should mention:
- childhood abandonment-related experiences
- distance/inconsistency/uncertainty
- safety or connection
- fear of being left again
- separation between real fear and automatic present proof
