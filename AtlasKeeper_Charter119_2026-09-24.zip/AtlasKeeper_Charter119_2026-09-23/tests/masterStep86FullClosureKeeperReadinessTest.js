const assert = require('assert');
const fs = require('fs');
const path = require('path');
const status = require('../version_status.js');

const root = path.resolve(__dirname, '..');
const required = [
  'runtime/compass/CompassSeeSeparateRestoreRenderer.js',
  'runtime/backend/FrontendCalloutService.js',
  'tests/masterStep86CompassDeconstructRestoreSplitTest.js',
  'tests/masterStep86FullClosureKeeperReadinessTest.js',
  'docs/MASTERSTEP86_COMPASS_DECONSTRUCT_RESTORE_SPLIT.md',
  'runtime/proof/MASTERSTEP86_COMPASS_DECONSTRUCT_RESTORE_SPLIT.md',
  'runtime/proof/MASTERSTEP86_COMPASS_DECONSTRUCT_RESTORE_SPLIT.json',
  'proof/runCurrentProof.js',
  'version_status.js'
];

const missing = required.filter(rel => !fs.existsSync(path.join(root, rel)));
assert.deepStrictEqual(missing, []);
assert.strictEqual(status.currentKeeper, 'Masterstep86');
assert.strictEqual(status.previousKeeper, 'Masterstep85');
assert.strictEqual(status.compassDeconstructRestoreSplitComplete, true);
assert.strictEqual(status.compassFourLaneRendererComplete, true);
assert.strictEqual(status.restoreNoLongerCarriesDeconstructionBurden, true);
assert.strictEqual(status.finalCompassAgencyWordBlocked, true);
assert.strictEqual(status.step86NoNewMechanismsAdded, true);
assert.strictEqual(status.step86NoDeletionPerformed, true);
assert.strictEqual(status.step86NoProviderModelCloudFrontendExpansion, true);
assert.strictEqual(status.providerConfigured, false);
assert.strictEqual(status.realModelConnected, false);
assert.strictEqual(status.networkBridgeEnabled, false);
assert.strictEqual(status.frontendIntelligenceAllowed, false);
assert.strictEqual(status.operatorConsoleAdded, false);

console.log('masterStep86FullClosureKeeperReadinessTest PASSED');
