'use strict';
// ============================================================================
// AtlasDoyleResponseComposer — Doyle-shaped fallback replies for Atlas Chat.
// ----------------------------------------------------------------------------
// THE SANCTIONED SANDBOX CROSSING: this is the one module in the plugin that
// may require() outside the plugin folder (absolute paths only, computed from
// __dirname — this file is a real Node module because the bridge loads it via
// an absolute path). Everything Doyle-facing is lazy and FAIL-CLOSED: any
// require/placement/composition failure returns null and the bridge keeps its
// existing hardwired behavior. Zero exceptions ever reach the user.
//
// What it does: when the deterministic fallback would fire, it runs the
// incoming text through the Doyle Recursive Index Spire (mapLiveDoylePlacement,
// L2–L6) and shapes the reply with the L7 Compass expression spheres'
// checks / forbidden / positive_expression_targets — composed from parts,
// never one canned string:
//   - 'self' intent (questions asked OF Atlas): placement-aware ack +
//     state-based content (the bridge's buildSelfAwareReply) + invitation.
//   - emotional intents ('overwhelmed', 'default', 'question'): ack variant +
//     content variant + invitation variant, from contract pools written in
//     the interface voice contract (declarative, no emotional filler — the
//     fallback reports its limit plainly instead of filling space).
// Variant selection is deterministic on (text hash + turn + attempt), so the
// same input on consecutive turns still differs — the parroting bug is dead.
// Greeting/rules intents keep their hardwired lines (trace-only Doyle read).
//
// Deliberately NOT wired (honest scope):
// - The runtime/understanding meaning matrices (PressurePerformanceIdentity,
//   TranslationPreservation, PositiveState, …) govern the Compass emotional
//   pipeline's read of the USER. Consulting them to answer "are you aware"
//   about Atlas itself would be decorative. Their core principle — no backend
//   vocabulary leaking into human-facing words — is honored through L7S09.
// - Greeting/rules intents keep their hardwired lines; Doyle placement still
//   runs for them and is recorded in trace, but never re-shapes their text.
// Voice: every composed string goes back through the bridge's existing
// inspectAtlasVoice re-check (absolute rule). This module never emits dark
// machinery vocabulary, and scans its own output against the L7 forbidden
// lists before returning.
// ============================================================================

const path = require('path');

const PLUGIN_DIR = __dirname;
// continuity-interface -> plugins -> .obsidian -> Continuity_Architecture -> CA -> package root
const PKG_ROOT = path.resolve(PLUGIN_DIR, '..', '..', '..', '..', '..');

// L7 spheres that shape an Atlas identity answer. Chosen by contract (each
// sphere's purpose maps to a real shaping decision below), because
// suggestExpressionSpheres() has a coverage gap for identity questions
// (returns [] for "are you aware") — keyword scoring the sphere catalog is
// the wrong selector here; the intent is.
const IDENTITY_SPHERE_IDS = ['L7S02', 'L7S04', 'L7S06', 'L7S07', 'L7S08', 'L7S09'];

// Emotional intents ('overwhelmed', 'default', 'question') are Doyle-shaped
// too. Same contract logic: suggestExpressionSpheres() has no reliable signal
// for these inputs (returns [] or 1-token spurious hits like L7S10 on
// "messing up"), so the spheres are chosen by contract — S02 interface voice
// (Steve-approved FINAL voice contract: declarative, no emotional filler),
// S03 non-clinical language, S04 anti-robotic wording, S05 assumption
// boundary (never invent emotional conclusions about the user), S06
// see-separate-restore structure, S07 no fake positivity, S08
// proportional depth, S09 no backend leakage. Placement + suggester output
// are still run and recorded in trace for honesty.
const EMOTIONAL_INTENTS = ['overwhelmed', 'default', 'question'];
const EMOTIONAL_SPHERE_IDS = ['L7S02', 'L7S03', 'L7S04', 'L7S05', 'L7S06', 'L7S07', 'L7S08', 'L7S09'];

// Acknowledgment seeds (L7S06 "see the actual input", L7S02 interface voice,
// L7S04 not robotic / not reassurance). Contract voice: active, declarative,
// no emotional filler. Deterministic pick by text hash: same question ->
// same answer (testable), varied across questions.
const ACK_VARIANTS = [
  "Question received.",
  "Direct question. Direct answer.",
  "Stated. Answering from recorded state."
];

// Invitation seeds (L7S07 no fake positivity; agency stays human).
const INVITE_VARIANTS = [
  "Test with another question if needed.",
  "State the next input.",
  "Further questions pass the same checks."
];

// S08 Proportional Depth: identity questions are light — keep it tight.
const MAX_COMPOSED_CHARS = 900;

// Emotional variant pools. Each pool is written in the interface voice
// contract: active voice, concise declarative sentences, zero emotional
// filler, zero performative empathy, zero reassurance or persuasion. S03:
// never clinical, never therapy-framed; S05: never invent conclusions about
// the user's feelings beyond what they stated. The fallback is the floor —
// where it cannot answer, it reports its limit plainly instead of filling
// space with comfort-text. Composed as ack + content + invite; S08 keeps
// them chat-short.
const EMOTIONAL_PARTS = {
  default: {
    ack: ["Input received.", "Noted.", "Recorded.", "Stated.", "Received."],
    content: [
      "The fallback voice holds no position on this.",
      "No inference is drawn from the fallback voice.",
      "This stays as stated input.",
      "The fallback voice does not interpret.",
      "Recorded as stated, without inference."
    ],
    invite: [
      "Restate it as a direct question if one is needed.",
      "State what you need from it.",
      "If there is a question in it, ask it directly.",
      "Direct questions get direct answers.",
      "Rephrase as a question to proceed."
    ]
  },
  overwhelmed: {
    ack: ["Stated.", "Input received.", "Noted.", "Recorded.", "Acknowledged."],
    content: [
      "The fallback voice cannot work through this with you.",
      "No further processing is available from the fallback voice.",
      "The local model is not connected.",
      "This exceeds the fallback voice.",
      "The fallback voice stops here."
    ],
    invite: [
      "State the one actionable item, if any.",
      "If there is a direct question, ask it.",
      "Restate as a single direct question.",
      "One direct question at a time.",
      "Ask the question directly."
    ]
  },
  question: {
    ack: ["Question received.", "Noted.", "Recorded.", "Stated.", "Direct question."],
    content: [
      "That needs the local model. It is not connected.",
      "The fallback voice cannot answer this.",
      "No answer is available from the fallback voice.",
      "Answering requires the local model. It is not connected.",
      "The fallback voice holds no answer."
    ],
    invite: [
      "Ask again when the local model is connected.",
      "Reconnect the local model and ask again.",
      "The question stands until the model is connected.",
      "State it again once the model is connected.",
      "It waits for the local model."
    ]
  }
};

// S08 Proportional Depth: support moments stay tight.
const MAX_EMOTIONAL_CHARS = 700;

let doyleCache = null;
function loadDoyle() {
  if (doyleCache) return doyleCache;
  try {
    const idx = path.join(PKG_ROOT, 'runtime', 'indexing');
    doyleCache = {
      ok: true,
      mapLiveDoylePlacement: require(path.join(idx, 'DoyleLivePlacementMapper.js')).mapLiveDoylePlacement,
      getSphereById: require(path.join(idx, 'DoyleLayer7CompassExpressionMap.js')).getSphereById,
      suggestExpressionSpheres: null
    };
    try {
      const fn = require(path.join(idx, 'DoyleLayer7CompassExpressionMap.js')).suggestExpressionSpheres;
      if (typeof fn === 'function') doyleCache.suggestExpressionSpheres = fn;
    } catch (_) { /* optional: suggester absence never blocks shaping */ }
    if (typeof doyleCache.mapLiveDoylePlacement !== 'function' ||
        typeof doyleCache.getSphereById !== 'function') {
      doyleCache = { ok: false, reason: 'missing_exports' };
    }
  } catch (err) {
    doyleCache = { ok: false, reason: 'load_failed', detail: String((err && err.message) || err) };
  }
  return doyleCache;
}

function hashText(t) {
  const s = String(t || '').trim().toLowerCase();
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  // Avalanche: a plain FNV-style prefix hash only diffuses through
  // multiplication, so trailing digits collapse modulo small pool sizes
  // (31 ≡ 1 mod 3 — attempt "0" and "3" hashed identically). The mixer below
  // spreads single-character differences across all bits, so (turn, attempt)
  // salts actually rotate variants instead of cycling with period 3.
  h ^= h >>> 16; h = Math.imul(h, 0x7feb352d);
  h ^= h >>> 15; h = Math.imul(h, 0x846ca68b);
  h ^= h >>> 16;
  return h >>> 0;
}

// Salted variant pick: deterministic on (text + part + turn + attempt), so
// the same input on the same turn and attempt always yields the same part
// (testable), while consecutive turns — or the bridge's anti-repeat
// re-picks — rotate through the pool. Each part salts independently so
// ack/content/invite don't rotate in lockstep.
function pickSalted(variants, text, turn, attempt, salt) {
  const key = String(text) + '|' + String(salt) + '|' + (turn | 0) + '|' + (attempt | 0);
  return variants[hashText(key) % variants.length];
}

function escRx(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// Scan text against every forbidden token of the given spheres.
// Returns the first hit or null. Fail-closed: any scan error -> treat as hit.
function scanForbidden(text, spheres) {
  try {
    const t = String(text || '');
    for (const s of spheres) {
      const bad = Array.isArray(s.forbidden) ? s.forbidden : [];
      for (const token of bad) {
        if (!token || typeof token !== 'string') continue;
        // Multi-word tokens: plain inclusion. Single words: word boundary.
        const rx = /\s/.test(token)
          ? new RegExp(escRx(token), 'i')
          : new RegExp('\\b' + escRx(token) + '\\b', 'i');
        if (rx.test(t)) return { sphere: s.sphere_id, token };
      }
    }
    return null;
  } catch (_) {
    return { sphere: '?', token: 'scan_error' };
  }
}

function summarizePlacements(placements) {
  return (placements || []).map((p) => ({
    layer: p.layer,
    sphere: p.sphere,
    reason: p.reason,
    accepted: p.accepted === true,
    fallback: /^fallback_/.test(String(p.reason || ''))
  }));
}

// Main entry. Returns { text, doyle } on a composed reply,
// { text: null, doyle } when placement ran but nothing was re-shaped,
// or null when Doyle is unavailable (bridge: keep hardwired behavior).
// input.turn / input.attempt feed the salted variant picker so consecutive
// turns (and the bridge's anti-repeat re-picks) rotate phrasing.
function composeFallbackReply(input) {
  try {
    const cfg = input || {};
    const userText = String(cfg.userText || '');
    const intent = cfg.intent || 'default';
    const fallbackText = typeof cfg.fallbackText === 'string' ? cfg.fallbackText : '';
    const turn = cfg.turn | 0;
    const attempt = cfg.attempt | 0;

    const D = loadDoyle();
    if (!D.ok) {
      return { text: null, doyle: { engaged: false, reason: D.reason || 'doyle_unavailable' } };
    }

    let placements = [];
    try {
      const res = D.mapLiveDoylePlacement(userText);
      placements = summarizePlacements(res && res.placements);
    } catch (_) {
      return { text: null, doyle: { engaged: false, reason: 'placement_failed' } };
    }

    // Suggester read: recorded in trace for honesty. For these inputs it
    // carries no reliable signal (often [] or 1-token spurious hits), which
    // is why shaping spheres are chosen by contract below.
    let suggested = [];
    try {
      if (typeof D.suggestExpressionSpheres === 'function') {
        suggested = D.suggestExpressionSpheres({ text: userText }).slice(0, 3)
          .map((s) => s && s.sphere_id).filter(Boolean);
      }
    } catch (_) { suggested = []; }

    const baseTrace = {
      engaged: true,
      placements,
      suggested_spheres: suggested,
      shaped: false
    };

    const isSelf = intent === 'self';
    const isEmotional = EMOTIONAL_INTENTS.indexOf(intent) !== -1;
    // Greeting/rules stay hardwired (no Doyle shaping); the Doyle read is
    // still recorded in trace.
    if ((!isSelf && !isEmotional) || !fallbackText) {
      baseTrace.reason = fallbackText ? 'intent_not_composed' : 'empty_fallback_text';
      return { text: null, doyle: baseTrace };
    }

    // Resolve the shaping spheres. Any miss -> fail closed (no shaping).
    const sphereIds = isSelf ? IDENTITY_SPHERE_IDS : EMOTIONAL_SPHERE_IDS;
    const spheres = [];
    for (const id of sphereIds) {
      let s = null;
      try { s = D.getSphereById(id); } catch (_) { s = null; }
      if (!s || !Array.isArray(s.checks) || !Array.isArray(s.forbidden)) {
        return { text: null, doyle: { engaged: true, placements, suggested_spheres: suggested, shaped: false, reason: 'sphere_missing_' + id } };
      }
      spheres.push(s);
    }

    let composed, shaping;
    if (isSelf) {
      // Compose from parts. The state-based content (fallbackText) is the
      // bridge's buildSelfAwareReply output — one source of truth, kept there.
      // Ack/invite rotate by (text + turn + attempt): the same question on
      // consecutive turns re-frames instead of parroting; the state-based
      // core stays identical because the facts didn't change.
      const ack = pickSalted(ACK_VARIANTS, userText, turn, attempt, 'ack');
      const invite = pickSalted(INVITE_VARIANTS, userText, turn, attempt, 'invite');
      composed = ack + ' ' + fallbackText + ' ' + invite;
      shaping = [
        'ack_variant:' + (hashText(userText + '|ack|' + turn + '|' + attempt) % ACK_VARIANTS.length),
        'invite_variant:' + (hashText(userText + '|invite|' + turn + '|' + attempt) % INVITE_VARIANTS.length),
        'turn:' + turn,
        'attempt:' + attempt,
        's09_s02_forbidden_scan:clean',
        's08_depth:' + composed.length + 'chars'
      ];
      // L7S08 Proportional Depth: light question, light answer.
      if (composed.length > MAX_COMPOSED_CHARS) {
        return { text: null, doyle: { engaged: true, placements, suggested_spheres: suggested, shaped: false, reason: 'over_depth_cap' } };
      }
    } else {
      // Emotional intent: ack + supportive content + invite, composed from
      // the contract variant pools — never one canned string.
      const parts = EMOTIONAL_PARTS[intent];
      if (!parts) {
        return { text: null, doyle: { engaged: true, placements, suggested_spheres: suggested, shaped: false, reason: 'no_parts_' + intent } };
      }
      const ack = pickSalted(parts.ack, userText, turn, attempt, 'ack');
      const content = pickSalted(parts.content, userText, turn, attempt, 'content');
      const invite = pickSalted(parts.invite, userText, turn, attempt, 'invite');
      composed = ack + ' ' + content + ' ' + invite;
      shaping = [
        'intent:' + intent,
        'turn:' + turn,
        'attempt:' + attempt,
        'spheres:' + sphereIds.join(','),
        's08_depth:' + composed.length + 'chars'
      ];
      // L7S08 Proportional Depth: support moments stay tight.
      if (composed.length > MAX_EMOTIONAL_CHARS) {
        return { text: null, doyle: { engaged: true, placements, suggested_spheres: suggested, shaped: false, reason: 'over_depth_cap' } };
      }
    }

    // Backend Leakage Block + Human Voice Guard: forbidden scan on the
    // shaping spheres before anything is returned.
    const hit = scanForbidden(composed, spheres);
    if (hit) {
      return { text: null, doyle: { engaged: true, placements, suggested_spheres: suggested, shaped: false, reason: 'forbidden_hit', hit } };
    }

    return {
      text: composed,
      doyle: {
        engaged: true,
        placements,
        suggested_spheres: suggested,
        shaped: true,
        spheres_used: sphereIds.slice(),
        shaping,
        positive_targets: spheres.reduce((acc, s) => acc.concat(s.positive_expression_targets || []), [])
      }
    };
  } catch (_) {
    // Absolute fail-closed: never throw into the chat path.
    return null;
  }
}

module.exports = { composeFallbackReply, hashText, IDENTITY_SPHERE_IDS, EMOTIONAL_INTENTS, EMOTIONAL_SPHERE_IDS, EMOTIONAL_PARTS, ACK_VARIANTS, INVITE_VARIANTS };
