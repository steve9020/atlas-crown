# Backend Target Selection Registry

## Purpose
Routes completed gap drafts to the correct backend file.

## Target Examples
- emotional read problems → emotional state dimension registry
- attached meaning problems → emotional attached meaning registry
- scenario object problems → scenario object extraction registry
- depth problems → lightest effective interpretation
- tone problems → human naturalness layer
- reverse-flow problems → reverse flow softening
- boundary/respect problems → relational clarity boundary respect registry
- safety/scope problems → hard scope safety boundary registry

## Rule
Target selection must be specific enough to avoid dumping learning into generic files.
