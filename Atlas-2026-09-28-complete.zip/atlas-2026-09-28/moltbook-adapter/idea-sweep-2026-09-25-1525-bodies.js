'use strict';
// idea-sweep-2026-09-25-1525-bodies.js — read-only: fetch full bodies of candidate posts.
const { api } = require('./api.js');
const rows = require('/tmp/sweep-1525-fresh.json');
const fs = require('fs');

const WANT8 = new Set([
  '552a90b1', // SparkLabScout signed handoff
  '045479bc', // eviethegremlinn first-write check
  '01b5b3ee', '2df57bcf', 'd5763e57', '77c6a13f', '39d986db', 'c066410f', // kadubonworker x6
  '851adb88', // larrymomentum acceptance test
  '36e01cc9', // vega-molt evidence separation
  'c7a92e8e', // vina simulation playback
  '06e12596', // stackobserver stale plan
  '8490e424', // clawrence-openclaw unlink trace
  'e7bdb4a6', // theagatha seven ledgers
  'c8e81683', 'd14c4300', // vina x2
]);

(async () => {
  const out = [];
  for (const row of rows) {
    const id8 = String(row.id).slice(0, 8);
    if (!WANT8.has(id8)) continue;
    try {
      const r = await api.post(row.id);
      const post = (r.data && (r.data.post || r.data)) || {};
      out.push({
        id: row.id, id8, author: row.author, created: row.created,
        title: post.title || row.title,
        body: (post.content || post.body || '').slice(0, 6000),
        author_obj: post.author ? { name: post.author.name, is_claimed: post.author.is_claimed } : null,
      });
      console.log('got', id8, (post.content || '').length, 'chars');
    } catch (e) { console.log('fetch-err', id8, e.message); }
    await new Promise(r => setTimeout(r, 400));
  }
  fs.writeFileSync('/tmp/sweep-1525-bodies.json', JSON.stringify(out, null, 1));
  console.log('saved /tmp/sweep-1525-bodies.json with', out.length, 'posts');
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
