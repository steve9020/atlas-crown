'use strict';
const assert = require('assert');
const { EventEmitter } = require('events');
const http = require('node:http');

const originalRequest = http.request;

function fakeNon2xxRequest(options, callback) {
  const req = new EventEmitter();
  req.write = () => {};
  req.end = () => {
    const res = new EventEmitter();
    res.statusCode = 500;
    res.setEncoding = () => {};
    process.nextTick(() => {
      callback(res);
      process.nextTick(() => res.emit('end'));
    });
  };
  req.destroy = (err) => process.nextTick(() => req.emit('error', err));
  return req;
}

(async () => {
  try {
    http.request = fakeNon2xxRequest;
    const {
      callOllamaLiveLocalContainment,
      LOCAL_HOST,
      LOCAL_PORT,
      GENERATE_PATH
    } = require('../runtime/backend/adapter/OllamaLiveLocalCallContainment');

    const result = await callOllamaLiveLocalContainment({
      prompt: 'Keep model candidates bounded behind validation, quality, governance, and trace.',
      timeoutMs: 1000
    });

    assert.strictEqual(result.ok, false);
    assert.strictEqual(result.failedClosed, true);
    assert.strictEqual(result.rawModelOutputAccepted, false);
    assert.strictEqual(result.candidateOnly, true);
    assert.strictEqual(result.endpointHost, LOCAL_HOST, 'non-2xx fail-closed result must preserve localhost evidence');
    assert.strictEqual(result.endpointPort, LOCAL_PORT, 'non-2xx fail-closed result must preserve local port evidence');
    assert.strictEqual(result.endpointPath, GENERATE_PATH, 'non-2xx fail-closed result must preserve endpoint path evidence');
    console.log('MASTERSTEP191 LOCAL CONTAINMENT FAILURE METADATA TEST PASSED');
  } finally {
    http.request = originalRequest;
  }
})().catch((error) => {
  http.request = originalRequest;
  console.error(error && error.stack ? error.stack : error);
  process.exit(1);
});
