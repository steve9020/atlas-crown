---
title: Learning Depth Growth Runtime
status: active
runtime_layer: learning_depth
priority: high
governed_by: [[understanding_growth_metrics_runtime_overview]]
---

# Learning Depth Growth Runtime

Atlas should measure whether learning improves depth, not just whether a proposal exists.

## Runtime rule
Learning depth requires source prompt, failure reason, proposed correction, retest result, and repeat-case stability.

## Depth dimensions
- repeated failure recognition
- route/card improvement
- response specificity improvement
- duplicate/bloat control
- approved integration only

## Related Runtime Links
- [[proposal_assessment_maturity_engine_overview]]
- [[before_after_retest_registry]]
- [[response_weakness_detection_runtime_overview]]
