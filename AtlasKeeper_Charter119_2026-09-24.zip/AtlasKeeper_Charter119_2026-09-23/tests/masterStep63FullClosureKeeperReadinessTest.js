const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');

const required = [
  'runtime/backend/adapter/ProviderSpecificWrapperShell.js',
  'runtime/backend/adapter/AdapterDryRunHarness.js',
  'runtime/proof/MASTERSTEP63_DISCONNECTED_PROVIDER_WRAPPER_SHELL.md',
  'runtime/proof/MASTERSTEP63_DISCONNECTED_PROVIDER_WRAPPER_SHELL.json',
  'runtime/proof/MASTERSTEP63_TEST_RESULTS.md',
  'docs/MASTERSTEP63_DISCONNECTED_PROVIDER_WRAPPER_SHELL_MAP.md',
  'tests/masterStep63DisconnectedProviderWrapperShellTest.js'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(root, rel)), `missing ${rel}`);

const plugin = path.join(root, 'CA/Continuity_Architecture/.obsidian/plugins/continuity-interface');
const forbidden = /provider wrapper|adapter shell|llm boundary|model adapter|axis engine|doyle spire|relational lookup|separation target|restoration gateway|post-generation validator|teaching center triage|simulation loop|patch application|rollback recovery|proof ledger|route score|semantic attachment/i;
function walk(dir){
  if (!fs.existsSync(dir)) return [];
  let out=[];
  for (const name of fs.readdirSync(dir)) {
    const p=path.join(dir,name); const st=fs.statSync(p);
    if (st.isDirectory()) out=out.concat(walk(p)); else out.push(p);
  }
  return out;
}
for (const file of walk(plugin).filter(f => /\.(js|ts|json|md)$/.test(f))) {
  const rel = path.relative(root, file);
  if (/ATLAS_PATH_LOCK_README\.md$/.test(rel)) continue;
  const text = fs.readFileSync(file,'utf8');
  assert.ok(!forbidden.test(text), `frontend intelligence residue in ${rel}`);
}

const version = require('../version_status');
assert.strictEqual(version.currentKeeper, 'Masterstep63');
assert.strictEqual(version.frontendIntelligenceAllowed, false);
assert.strictEqual(version.backendOwnsIntelligence, true);
assert.strictEqual(version.aiConnected, false);
assert.strictEqual(version.providerConfigured, false);
assert.strictEqual(version.providerSpecificAdapterConnected, false);
assert.strictEqual(version.providerWrapperShellReady, true);
assert.strictEqual(version.providerWrapperExecutionEnabled, false);

console.log('masterStep63FullClosureKeeperReadinessTest PASSED');
