# Masterstep164 — Doyle Sphere Maturity Audit + Recursive Index Contract

This step turns the Doyle sphere direction into an explicit backend contract without exposing it publicly or making it route authority.

Doyle is defined as a recursive categorical index that can hold:

- active sphere path
- possible attachment path
- context/surface pressure
- meaning-attachment risk
- separation target
- Compass expression contract

The step audits existing Doyle/matrix surfaces and proves the minimum maturity requirements for the next stage: literal/practical prompts remain held, mixed meanings separate before route, and translation preservation remains intact.

This is not a public demo expansion, not a model-authority expansion, and not a runtime output rewrite.
