# Doyle Spire Layer 3 — Emotional Attachment Families

Masterstep37 closed keeper layer buildout. Layer 3 identifies emotional attachment families and positive emotional relations as first-class relational carriers.

| ID | Sphere | Pressure attachments | Positive attachments |
|---|---|---|---|
| L3S01 | Stress / Pressure / Relief | stress building, pressure getting heavy, too much responsibility | relief, steadiness, room to breathe, manageable movement |
| L3S02 | Fear / Anxiety / Courage | fear, worry, panic | courage, grounded choice, safety, bravery |
| L3S03 | Shame / Embarrassment / Dignity | shame, embarrassment, humiliation | dignity, self-respect, human permission, confidence returning |
| L3S04 | Guilt / Obligation / Clean Responsibility | guilt, obligation, owing someone | clean responsibility, self-trust, boundaries, respectful limits |
| L3S05 | Sadness / Grief / Comfort | sadness, grief, missing someone | comfort, care, tenderness, continuity |
| L3S06 | Anger / Disrespect / Respect | anger, irritation, disrespect | respect, protection, clear boundary, controlled action |
| L3S07 | Hurt / Rejection / Connection | hurt, rejection fear, feeling unwanted | connection, care, worth, being valued |
| L3S08 | Loneliness / Absence / Belonging | loneliness, absence, left out | belonging, welcome, comfort, being remembered |
| L3S09 | Confusion / Uncertainty / Trust | confusion, uncertainty, not knowing | trust, patience, grounded checking, discernment |
| L3S10 | Overwhelm / Shutdown / Movement | overwhelm, shutdown, stuckness | small movement, agency, return-to-self, room to think |
| L3S11 | Resentment / Overextension / Boundaries | resentment, overextension, being used | boundaries, rest, respect, self-protection |
| L3S12 | Joy / Love / Hope / Fulfillment | fear joy will disappear, love vulnerability, hope risk | happiness, joy, love, comfort |

Layer rule: emotional attachments are candidates selected by prompt relation, not fixed word meanings. Positive emotions are active relations, not only endpoints.
