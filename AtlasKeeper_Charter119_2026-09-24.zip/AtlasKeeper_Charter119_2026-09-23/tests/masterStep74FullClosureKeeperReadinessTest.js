const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const version = require('../version_status');

const root = path.resolve(__dirname, '..');
const required = [
  'runtime/backend/closedLoop/AlgorithmicVoiceCadenceValidator.js',
  'runtime/proof/MASTERSTEP74_ALGORITHMIC_VOICE_CADENCE_VALIDATOR.json',
  'runtime/proof/MASTERSTEP74_ALGORITHMIC_VOICE_CADENCE_VALIDATOR.md',
  'docs/MASTERSTEP74_ALGORITHMIC_VOICE_CADENCE_VALIDATOR_MAP.md',
  'tests/masterStep74AlgorithmicVoiceCadenceValidatorTest.js'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(root, rel)), 'missing Step74 artifact: ' + rel);

const proof = JSON.parse(fs.readFileSync(path.join(root, 'runtime/proof/MASTERSTEP74_ALGORITHMIC_VOICE_CADENCE_VALIDATOR.json'), 'utf8'));
assert.strictEqual(proof.passed, true, 'proof JSON must record Step74 pass');
assert.strictEqual(proof.source_keeper, 'Masterstep73');
assert.strictEqual(proof.cloud_work_deferred, true);
assert.strictEqual(proof.provider_connected, false);
assert.strictEqual(proof.real_model_connected, false);
assert.strictEqual(proof.api_keys_added, false);
assert.strictEqual(proof.endpoints_added, false);
assert.strictEqual(proof.network_bridge_added, false);
assert.strictEqual(proof.frontend_intelligence_added, false);
assert.strictEqual(proof.real_model_execution_added, false);
assert.strictEqual(proof.validator_added, true);
assert.strictEqual(proof.validator_scope, 'backend_post_generation_voice_signal');
assert.strictEqual(proof.validator_is_final_authority, false);
assert.strictEqual(proof.cadence_validator_may_silently_mutate, false);
assert.strictEqual(proof.fail_count, 0);
assert.strictEqual(proof.required_chain_evidence.node_backend_only, true);
assert.strictEqual(proof.required_chain_evidence.no_external_dependencies, true);
assert.strictEqual(proof.required_chain_evidence.low_anchor_density_is_advisory_not_standalone_block, true);
assert.strictEqual(proof.required_chain_evidence.cadence_validator_not_final_authority, true);
assert.strictEqual(proof.required_chain_evidence.teaching_center_review_signal_only, true);
assert.strictEqual(proof.required_chain_evidence.no_silent_mutation_boundary_preserved, true);
assert.strictEqual(proof.required_chain_evidence.frontend_shell_still_dumb, true);
assert.strictEqual(proof.required_chain_evidence.provider_model_network_still_disconnected, true);
assert.strictEqual(proof.decision, 'CLOSE_STEP_74_AND_HOLD_FOR_NEXT_LOCAL_GOVERNED_STEP');

assert.strictEqual(version.currentKeeper, 'Masterstep74', 'version_status currentKeeper must be Masterstep74');
assert.strictEqual(version.previousKeeper, 'Masterstep73', 'version_status previousKeeper must be Masterstep73');
assert.strictEqual(version.step, 'Algorithmic Voice Cadence Validator', 'version_status step must be Step74 title');
assert.strictEqual(version.aiConnected, false, 'AI/cloud must remain disconnected');
assert.strictEqual(version.providerConfigured, false, 'provider must remain unconfigured');
assert.strictEqual(version.providerWrapperExecutionEnabled, false, 'provider wrapper execution must remain disabled');
assert.strictEqual(version.networkBridgeEnabled, false, 'network bridge must remain disabled');
assert.strictEqual(version.frontendIntelligenceAllowed, false, 'frontend intelligence must remain blocked');
assert.strictEqual(version.backendOwnsIntelligence, true, 'backend ownership must remain true');
assert.strictEqual(version.cloudProviderEvaluationStarted, false, 'cloud provider evaluation must remain deferred');
assert.strictEqual(version.algorithmicVoiceCadenceValidatorComplete, true, 'Step74 validator must be complete');
assert.strictEqual(version.algorithmicVoiceCadenceWeakCasesRemaining, 0, 'Step74 weak cases must be zero');
assert.strictEqual(version.cadenceValidatorFinalAuthority, false, 'Cadence validator must not become final authority');
assert.strictEqual(version.cadenceValidatorSilentMutationAllowed, false, 'Cadence validator must not silently mutate');
assert.strictEqual(version.nextTarget, 'HOLD — choose next local governed step', 'next target must not start cloud/provider work');

console.log('masterStep74FullClosureKeeperReadinessTest PASSED');
