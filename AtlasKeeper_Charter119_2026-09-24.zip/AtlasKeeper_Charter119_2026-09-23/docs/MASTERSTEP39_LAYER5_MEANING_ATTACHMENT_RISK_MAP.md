# Doyle Layer 5 — Meaning Attachment / False Conclusion Risk

Layer 5 maps meanings that may attach to a prompt, while blocking false positives and over-assumption. It is a risk/possibility layer, not a fact layer.

## L5S01 — Worth / Value Threat

Tracks when a situation may attach to personal value without assuming value threat unless stated or strongly supported.

Active when:
- user explicitly links event to value/worth
- stated conclusion uses worth/value language
- relational loss is paired with self-value claim

Do not assume:
- user feels worthless
- someone's action defines value
- worth is actually lost

Reverse-flow targets:
- worth
- dignity
- self-recognition
- continuity

## L5S02 — Ability / Capability Threat

Tracks when pressure or shutdown may start implying inability, while preserving difference between state, stress, and ability.

Active when:
- user states inability or capability doubt
- shutdown is tied to ability conclusion
- stress is paired with 'I can't handle' language

Do not assume:
- shutdown means incapability
- stress means weakness
- delay means inability

Reverse-flow targets:
- agency
- workable movement
- confidence
- self-trust

## L5S03 — Rejection / Not Chosen

Tracks when absence, silence, tone shift, or relational distance may attach to being rejected or not chosen.

Active when:
- user names rejection/not chosen
- silence is paired with rejected/ignored/unwanted meaning
- relational comparison supports not-chosen fear

Do not assume:
- silence equals rejection
- delay equals disinterest
- not chosen means no value

Reverse-flow targets:
- self-trust
- connection
- steadiness
- belonging

## L5S04 — Failure / Not Enough

Tracks when a mistake, delay, deadline, or struggle begins attaching to being a failure or not enough.

Active when:
- user explicitly says failing/not enough
- work/task pressure turns into identity conclusion
- delay is paired with too-late/failure language

Do not assume:
- unfinished means failure
- late means lazy
- mistake means final failure

Reverse-flow targets:
- dignity
- clean responsibility
- movement
- self-respect

## L5S05 — Burden / Too Much

Tracks when the user may feel like they are too much, asking too much, or becoming a burden.

Active when:
- user names burden/annoying/too much
- reassurance need is paired with burden fear
- relational request is tied to self-blame

Do not assume:
- needs are burdens
- care makes user too much
- asking equals harm

Reverse-flow targets:
- belonging
- care
- self-respect
- connection

## L5S06 — Unwanted / Replaceable

Tracks meanings of being unwanted, replaceable, forgotten, or easy to leave.

Active when:
- user states unwanted/replaceable
- loss/absence is linked to being forgotten or unwanted
- belonging threat is explicit

Do not assume:
- being absent means unwanted
- leaving means replaceable
- not included means no place

Reverse-flow targets:
- belonging
- worth
- connection
- continuity

## L5S07 — Loss of Control

Tracks panic movement, over-fixing, urgency, and control pressure without treating control as the same as care.

Active when:
- action impulse aims to prevent feared outcome
- user wants repeated explanation/checking
- urgency is driven by assumed reaction

Do not assume:
- action is required now
- more explaining equals repair
- fear prediction is confirmed

Reverse-flow targets:
- pause
- steadiness
- grounded choice
- self-trust

## L5S08 — Permanence / Always This Way

Tracks when current pain or pressure turns into an always/never/final conclusion.

Active when:
- user uses finality language
- current stress is stated as permanent
- repair/movement is framed as impossible

Do not assume:
- hard means permanent
- late means impossible
- pain means no path

Reverse-flow targets:
- hope
- continuity
- movement
- possibility

## L5S09 — Self-Blame / Responsibility Distortion

Tracks when the user takes too much responsibility for others' emotions, reactions, or uncertain outcomes.

Active when:
- user assigns cause to self without confirmed evidence
- other-person mood is treated as proof of user's fault
- repair impulse follows assumed blame

Do not assume:
- user caused other person's feeling
- responsibility equals blame
- repair requires self-punishment

Reverse-flow targets:
- clean responsibility
- self-compassion
- grounded repair
- dignity

## L5S10 — Trust Break / Safety Doubt

Tracks when inconsistency, disrespect, or uncertainty attaches to trust, safety, or not knowing where one stands.

Active when:
- user names trust/safety/standing
- inconsistency creates relational security question
- boundary violation affects safety

Do not assume:
- trust is broken forever
- person is unsafe without evidence
- uncertainty means betrayal

Reverse-flow targets:
- safety
- trust in self
- respect
- clear boundary

## L5S11 — Dignity / Humiliation Threat

Tracks public exposure, embarrassment, and being seen in a way that threatens dignity.

Active when:
- user names embarrassment/humiliation/stupidity
- public exposure is paired with dignity threat
- mistake becomes identity shame

Do not assume:
- dignity was lost
- everyone sees them differently
- one moment defines them

Reverse-flow targets:
- dignity
- self-respect
- human permission
- confidence

## L5S12 — Belonging / Exclusion Threat

Tracks when social absence, group dynamics, or relational distance may attach to not belonging or being excluded.

Active when:
- user states exclusion/belonging threat
- social situation is tied to place or inclusion
- absence becomes not-belonging meaning

Do not assume:
- not included means unwanted
- belonging is gone
- one event defines social place

Reverse-flow targets:
- belonging
- connection
- self-recognition
- steadiness

