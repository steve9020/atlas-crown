---
runtime_layer: teaching_gap_detection
priority: high
owned_by: atlas_teaching_learning
feeds_into:
  - teaching_gap_to_proposal_flow
---

# Missing Translation Rule Detection Registry

## Purpose
Identifies when Atlas understood the backend route but failed to translate it into human Compass language.

## Translation gap examples
- backend phrase: work-continuity signal → frontend phrase: it can start feeling like your place or security at work is on the line.
- backend phrase: blocked movement → frontend phrase: it is understandable why you would feel paralyzed or stuck.
- backend phrase: time-layer → frontend phrase: the past mistake is still active in the present and reaching into the future.
- backend phrase: larger conclusion → frontend phrase: loudest conclusion.

## Rule
A translation gap should preserve the backend meaning while removing backend-exposing language.
