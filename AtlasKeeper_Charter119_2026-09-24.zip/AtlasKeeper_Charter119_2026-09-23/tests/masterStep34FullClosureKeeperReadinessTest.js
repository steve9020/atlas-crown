const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function readJson(rel) { return JSON.parse(fs.readFileSync(path.join(root, rel), 'utf8')); }
const proof = readJson('runtime/proof/PROOF_STATE.json');
const active = readJson('runtime/workflow/ACTIVE_STEP.json');
const workflow = readJson('runtime/workflow/WORKFLOW_STATE.json');
const scope = readJson('runtime/workflow/IMPLEMENTATION_SCOPE.json');

for (const state of [proof, active, workflow, scope]) {
  assert.ok(['Masterstep34.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 34), state.current_keeper);
  assert.strictEqual(state.current_step, 'Masterstep34');
  assert.strictEqual(state.status, 'closed_keeper');
  assert.strictEqual(state.real_ai_connected, false);
  assert.strictEqual(state.local_model_connected, false);
  assert.strictEqual(state.model_loaded, false);
  assert.strictEqual(state.model_execution_enabled, false);
  assert.strictEqual(state.provider_config_added, false);
  assert.strictEqual(state.network_bridge_added, false);
  assert.strictEqual(state.frontend_intelligence_added, false);
  assert.strictEqual(state.doyle_spire_layer_sphere_map_added, true);
  assert.strictEqual(state.positive_attachment_families_first_class, true);
}
const required = [
  'runtime/indexing/DOYLE_SPIRE_LAYER_SPHERE_MAP.json',
  'runtime/indexing/DoyleSpireLayerSphereMap.js',
  'runtime/indexing/DoyleSpirePlacementGuard.js',
  'runtime/semantics/PositiveAttachmentIntegration.js',
  'runtime/proof/MASTERSTEP34_DOYLE_SPIRE_POSITIVE_ATTACHMENT_INTEGRATION.md'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(root, rel)), `missing ${rel}`);
console.log('masterStep34FullClosureKeeperReadinessTest PASSED');
