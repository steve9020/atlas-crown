# Axis Detection Registry

This registry owns Atlas axis-detection rules for the runtime.

Runtime code may read and evaluate this registry, but the axis phrases, combined pattern rules, and axis mappings belong to the Obsidian backend source of truth.

```json
{
  "registry": "axis_detection_registry",
  "stage": "OBSIDIAN_AXIS_REGISTRY_AXOL_ATTRIBUTION_CANDIDATE",
  "rule_model": "registry_owned_evidence_family_axis_detection_with_state_and_actor_attribution",
  "rules": [
    {
      "id": "mistake_progress_pressure",
      "priority": 10,
      "axes": [
        "worth",
        "permanence"
      ],
      "patterns": [
        "mistake_progress_pressure"
      ],
      "allGroups": [
        {
          "name": "mistake_language",
          "phrases": [
            "mistake",
            "messed up",
            "messing up",
            "small mistake"
          ]
        },
        {
          "name": "progress_pressure_language",
          "phrases": [
            "falling behind",
            "fell behind",
            "behind",
            "not keeping up",
            "can't keep up",
            "cannot keep up"
          ]
        }
      ],
      "regexPatterns": []
    },
    {
      "id": "worth_value_axis",
      "priority": 20,
      "axes": [
        "worth"
      ],
      "phrases": [
        "messing up",
        "messed up",
        "not good",
        "bad at",
        "not capable",
        "worthless",
        "not enough",
        "failing",
        "failure"
      ],
      "regexPatterns": [
        "\\b(no value|without value|less valuable|unworthy|worth less)\\b"
      ]
    },
    {
      "id": "emotional_validity_axis",
      "priority": 30,
      "axes": [
        "emotional_validity"
      ],
      "phrases": [
        "shouldn't feel",
        "should not feel",
        "overreacting",
        "stupid to feel",
        "wrong for feeling"
      ],
      "regexPatterns": [
        "\\b(no right to|not allowed to)\\b.{0,25}\\b(feel|be upset|be angry|be hurt)\\b"
      ]
    },
    {
      "id": "identity_axis",
      "priority": 40,
      "axes": [
        "identity"
      ],
      "phrases": [
        "who i am",
        "i'm just",
        "i am just",
        "something is wrong with me",
        "broken"
      ],
      "regexPatterns": [
        "\\b(defin|see|view|think of)\\w* myself\\b.{0,40}\\b(as|by)\\b"
      ]
    },
    {
      "id": "belonging_axis",
      "priority": 50,
      "axes": [
        "belonging"
      ],
      "phrases": [
        "they don't want me",
        "i don't belong",
        "too much",
        "burden",
        "left out",
        "rejected"
      ],
      "regexPatterns": [
        "\\b(everyone|everybody|others)\\b.{0,40}\\b(except me|but me)\\b",
        "\\b(no place for me|don.t fit)\\b",
        "\\b(fit|belong)\\b.{0,25}\\b(with|in|among)\\b",
        "\\b(any|a|no) place for me\\b.{0,30}\\b(with|among|there|here|in)\\b"
      ]
    },
    {
      "id": "perfection_axis",
      "priority": 60,
      "axes": [
        "perfection"
      ],
      "phrases": [
        "perfect",
        "flawless",
        "can't mess this up",
        "cannot mess this up",
        "have to fix",
        "need to fix"
      ],
      "regexPatterns": [
        "\\b(short of|less than|anything but)\\b.{0,20}\\b(perfect|flawless)\\b"
      ]
    },
    {
      "id": "detachment_axis",
      "priority": 70,
      "axes": [
        "detachment"
      ],
      "phrases": [
        "stop trying",
        "stop talking",
        "shut down",
        "stop caring",
        "give up",
        "disconnect"
      ],
      "regexPatterns": [
        "\\b(pulling|backing|withdrawing) away\\b",
        "\\b(disengag|withdraw)\\w*\\b"
      ]
    },
    {
      "id": "permanence_axis",
      "priority": 80,
      "axes": [
        "permanence"
      ],
      "phrases": [
        "always",
        "never",
        "eventually",
        "forever",
        "nothing will change",
        "falling behind"
      ],
      "regexPatterns": [
        "\\b(never going to|will always|won.t ever|for good)\\b"
      ]
    },
    {
      "id": "observation_evidence_axis",
      "priority": 100,
      "axes": [
        "observation_evidence"
      ],
      "patterns": [
        "observation_evidence"
      ],
      "phrases": [
        "i saw",
        "i heard",
        "i observed",
        "i noticed",
        "the message said",
        "the record shows",
        "the evidence shows"
      ],
      "regexPatterns": [
        "\\b(receipt|record|message|video|photo|log|data)\\b.{0,40}\\b(show|shows|showed|indicat|confirm|document|record)",
        "\\b(watch(?:ed|ing)?|witness(?:ed|ing)?|hear(?:d|ing)?|saw|seen|observ(?:ed|ing)?)\\b.{0,55}\\b(happen|occur|statement|event|it|that)\\b",
        "\\b(log|record|receipt|data|message)\\b.{0,30}\\b(confirm|corroborat|document|verify)\\w*\\b"
      ]
    },
    {
      "id": "interpretation_axis",
      "priority": 110,
      "axes": [
        "interpretation"
      ],
      "patterns": [
        "interpretation"
      ],
      "phrases": [
        "i think it means",
        "i took that as",
        "i interpreted",
        "it seems like",
        "i read that as",
        "my interpretation"
      ],
      "regexPatterns": [
        "\\b(came across|read it|took it|understood it|seemed to me)\\b",
        "\\b(reached|came to|formed) (that |a )?conclusion\\b",
        "\\bto me\\b.{0,45}\\b(sounded|looked|felt|appeared|came across)\\b",
        "\\b(took|read|saw|viewed|understood)\\b.{0,20}\\b(as|to mean)\\b",
        "\\bto [a-z][a-z\\'-]{1,30}\\b.{0,20}\\b(sounded|looked|felt|appeared|seemed|came across)\\b"
      ]
    },
    {
      "id": "assumption_axis",
      "priority": 120,
      "axes": [
        "assumption"
      ],
      "patterns": [
        "assumption"
      ],
      "phrases": [
        "i assume",
        "i assumed",
        "i am assuming",
        "must mean",
        "probably means",
        "i figured that"
      ],
      "regexPatterns": [
        "\\b(conclud|presum|assum|figured)\\w*\\b",
        "\\bwithout (asking|checking|confirming|knowing)\\b"
      ]
    },
    {
      "id": "intention_axis",
      "priority": 130,
      "axes": [
        "intention"
      ],
      "patterns": [
        "intention"
      ],
      "phrases": [
        "i meant to",
        "i intended",
        "my intention",
        "they meant to",
        "their intention",
        "on purpose",
        "his goal",
        "her goal",
        "their goal",
        "my goal"
      ],
      "regexPatterns": [
        "\\b(trying|intending|meaning|aiming|hoping) to\\b",
        "\\bmeant (for|to|as)\\b",
        "\\bmean(?:t|s)?\\s+(?:it|well|to)\\b",
        "\\b(his|her|their|my) (goal|aim|purpose)\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z\\'-]{1,30}) intend(?:ed|s)? to\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z\\'-]{1,30})\\s+(?:had )?(?:planned|plans|plan|aimed|aims|aim|intended|intends|meant|means) to\\b"
      ]
    },
    {
      "id": "impact_axis",
      "priority": 140,
      "axes": [
        "impact"
      ],
      "patterns": [
        "impact"
      ],
      "phrases": [
        "affected me",
        "effect on me",
        "impact on me",
        "hurt me",
        "changed how i",
        "resulted in",
        "it hurt",
        "that hurt",
        "hurt"
      ],
      "regexPatterns": [
        "\\b(after|since) (that|this)\\b.{0,80}\\b(started|became|stopped|changed|avoiding|affected)\\b",
        "\\b(left|made|caused)\\b.{0,45}\\b(me|him|her|them|us)\\b.{0,45}\\b(avoid|avoiding|withdraw|leave|change|stop|start)\\w*\\b",
        "\\b(changed|altered|shifted)\\b.{0,20}\\bhow\\b.{0,30}\\b(respond|acted|behaved|felt|reacted)\\w*\\b"
      ]
    },
    {
      "id": "responsibility_axis",
      "priority": 150,
      "axes": [
        "responsibility"
      ],
      "patterns": [
        "responsibility"
      ],
      "phrases": [
        "my responsibility",
        "their responsibility",
        "responsible for",
        "accountable for",
        "my fault",
        "their fault"
      ],
      "regexPatterns": [
        "\\b(on me|on him|on her|on them|own that|take responsibility|take accountability)\\b",
        "\\b(own|take) my part\\b",
        "\\b(owned|owns|owning) (his|her|their|my) part\\b",
        "\\b(fault|blame)\\b",
        "\\bpass(?:ed|es|ing)?\\s+the\\s+buck\\b",
        "\\b(?:take|takes|taking|took)\\s+the\\s+fall\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z\\'-]{1,30}) (?:took|take|takes) responsibility\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z\\'-]{1,30}) (?:am|is|are|was|were)(?: not|n't| never)? responsible\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z\\'-]{1,30})\\s+(?:own|owns|owned)\\s+(?:what happened|the mistake|the failure|the harm|it)\\b",
        "\\b(accept|accepted|acknowledge|acknowledged)\\b.{0,15}\\b(my|our|his|her|their) part\\b"
      ]
    },
    {
      "id": "expectation_axis",
      "priority": 160,
      "axes": [
        "expectation"
      ],
      "patterns": [
        "expectation"
      ],
      "phrases": [
        "i expected",
        "i was expecting",
        "supposed to",
        "was supposed to",
        "i thought they would",
        "i thought it would",
        "was expected to",
        "expected to",
        "expecting"
      ],
      "regexPatterns": [
        "\\b(thought|expected|anticipated)\\b.{0,60}\\b(would|was going to|should)\\b",
        "\\bexpect\\w*\\b",
        "\\b(anticipat|foresee|count(?:ed|ing)? on|bank(?:ed|ing)? on)\\w*\\b",
        "\\b(figured|thought|assumed)\\b.{0,45}\\b(would|will|was going to|were going to)\\b"
      ]
    },
    {
      "id": "causation_axis",
      "priority": 170,
      "axes": [
        "causation"
      ],
      "patterns": [
        "causation"
      ],
      "phrases": [
        "caused",
        "because of that",
        "led to",
        "made me",
        "made them",
        "the reason why"
      ],
      "regexPatterns": [
        "\\b(is|was|were) (why|what caused)\\b",
        "\\b(due to|owing to|as a result of)\\b",
        "\\b(cause|caused|causes|causing|trigger(?:ed|s)?|produced|created)\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z\\'-]{1,30})\\s+made\\s+(?:it|that|this)\\s+happen\\b"
      ]
    },
    {
      "id": "certainty_axis",
      "priority": 180,
      "axes": [
        "certainty"
      ],
      "patterns": [
        "certainty"
      ],
      "phrases": [
        "i know for sure",
        "i am certain",
        "definitely",
        "without a doubt",
        "there is no way",
        "has to be true",
        "i do not know",
        "i don't know",
        "not sure",
        "uncertain",
        "cannot know",
        "can't know",
        "maybe"
      ],
      "regexPatterns": [
        "\\b(no doubt|without doubt|certain|sure|undeniable|definite)\\b",
        "\\b(do not know|don.t know|not sure|uncertain|unclear)\\b",
        "\\b(cannot|can.t) know\\b",
        "\\bmaybe\\b"
      ]
    },
    {
      "id": "authority_axis",
      "priority": 190,
      "axes": [
        "authority"
      ],
      "patterns": [
        "authority"
      ],
      "phrases": [
        "who decides",
        "has authority",
        "authority over",
        "permission to",
        "allowed to decide",
        "gets to decide"
      ],
      "regexPatterns": [
        "\\b(not|isn.t|wasn.t)\\b.{0,20}\\b(his|her|their|your) call\\b",
        "\\b(who gets to decide|decision is mine|decision is theirs)\\b",
        "\\b(not|isn.t|wasn.t|no)\\b.{0,35}\\b(his|her|their|your|someone.s)\\b.{0,20}\\b(decision|choice)\\b",
        "\\b(no right|had no right|has no right)\\b.{0,35}\\b(assign|decide|choose|order|require)\\w*\\b",
        "\\b(has|have|had) (the )?authority to\\b"
      ]
    },
    {
      "id": "control_axis",
      "priority": 200,
      "axes": [
        "control"
      ],
      "patterns": [
        "control"
      ],
      "phrases": [
        "i can control",
        "cannot control",
        "can't control",
        "out of my control",
        "control over",
        "under my control",
        "hands are tied"
      ],
      "regexPatterns": [
        "\\b(outside|beyond|not in)\\b.{0,20}\\b(my|our|their) (hands|control|power)\\b",
        "\\bpull(?:ed|s|ing)?\\s+the\\s+strings\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z\\'-]{1,30}) control(?:s|led)?\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z\\'-]{1,30})\\s+(?:kept|keeps|held|holds|retained|retains|had|has)\\s+control\\b"
      ],
      "excludePatterns": [
        "\\bcontrol panel\\b"
      ]
    },
    {
      "id": "choice_axis",
      "priority": 210,
      "axes": [
        "choice"
      ],
      "patterns": [
        "choice"
      ],
      "phrases": [
        "i chose",
        "i choose",
        "my choice",
        "their choice",
        "decided to",
        "decision to",
        "choice",
        "decision"
      ],
      "regexPatterns": [
        "\\b(decid|choos|opted|elected)\\w*\\b",
        "\\b(choice|decision)\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z\\'-]{1,30}) (?:chose|choose|chooses|decided|decides)\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z\\'-]{1,30}) (?:refused|accepted|rejected) (?:the )?(?:choice|decision)\\b"
      ],
      "excludePatterns": [
        "\\bchoice menu\\b"
      ]
    },
    {
      "id": "obligation_axis",
      "priority": 220,
      "axes": [
        "obligation"
      ],
      "patterns": [
        "obligation"
      ],
      "phrases": [
        "i have to",
        "i must",
        "i need to",
        "obligated",
        "owe them",
        "required to"
      ],
      "regexPatterns": [
        "\\b(required|obligated|expected) to\\b",
        "\\b(required|obligated)\\b.{0,20}\\b(me|him|her|them|us|you)\\b.{0,10}\\bto\\b"
      ]
    },
    {
      "id": "boundary_axis",
      "priority": 230,
      "axes": [
        "boundary"
      ],
      "patterns": [
        "boundary"
      ],
      "phrases": [
        "my boundary",
        "crossed a boundary",
        "set a boundary",
        "limit with",
        "not okay with",
        "will not accept",
        "the boundary",
        "crossing the boundary"
      ],
      "regexPatterns": [
        "\\b(i will not|i won.t|not willing to|draw the line|limit is)\\b",
        "\\bcross\\w*\\b.{0,20}\\bboundar\\w*\\b",
        "\\bcross\\w*\\s+(?:the|a)\\s+line\\b",
        "\\b(i|we|you|he|she|they) cross(?:ed|es)? it\\b",
        "\\b(set|sets|set a|establish(?:ed|es)?|state(?:d|s)?|draw|drew)\\b.{0,18}\\b(limit|line)\\b",
        "\\b(limit|line)\\b.{0,25}\\b(i|we|you|he|she|they|[a-z][a-z\\'-]{1,30})\\b.{0,12}\\b(set|established|stated|drew)\\b"
      ],
      "excludePatterns": [
        "\\bboundary (line|marker|layer)\\b"
      ]
    },
    {
      "id": "ownership_axis",
      "priority": 240,
      "axes": [
        "ownership"
      ],
      "patterns": [
        "ownership"
      ],
      "phrases": [
        "belongs to me",
        "belongs to them",
        "mine to carry",
        "theirs to carry",
        "my part",
        "their part",
        "mine to"
      ],
      "regexPatterns": [
        "\\b(hers|his|theirs|mine) to (carry|handle|own|work through|solve)\\b",
        "\\b(belongs?|belonged) to (her|him|them|me|us)\\b",
        "\\b(her|his|their|my) (reaction|emotion|feeling|response|problem)\\b.{0,35}\\b(not mine|theirs|hers|his|belongs)\\b",
        "\\b(mine|theirs|hers|his) to\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z\\'-]{1,30}) own(?:s|ed)? (?:my|our|your|his|her|their)\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z'-]{1,30}) own(?:s|ed)? (?:the|a|this|that)\\b",
        "\\b(task|job|role|problem|responsibility|decision|work)\\b.{0,18}\\b(was|is|were|are)\\b.{0,8}\\b(hers|his|theirs|mine|ours|yours)\\b"
      ]
    },
    {
      "id": "comparison_axis",
      "priority": 250,
      "axes": [
        "comparison"
      ],
      "patterns": [
        "comparison"
      ],
      "phrases": [
        "compared to",
        "better than",
        "worse than",
        "more than them",
        "less than them",
        "as good as"
      ],
      "regexPatterns": [
        "\\b(more|less|heavier|lighter|greater|smaller) than\\b",
        "\\b(more|less|fewer)\\b.{0,30}\\bthan\\b",
        "\\b(compared with|compared against|relative to)\\b",
        "\\bcompar(?:e|ed|es|ing)\\b.{0,45}\\b(with|to|against|two|both|outcomes?|results?|options?)\\b"
      ]
    },
    {
      "id": "contradiction_axis",
      "priority": 260,
      "axes": [
        "contradiction"
      ],
      "patterns": [
        "contradiction"
      ],
      "phrases": [
        "contradicts",
        "contradiction",
        "both cannot be true",
        "both can't be true",
        "does not line up",
        "doesn't line up"
      ],
      "regexPatterns": [
        "\\b(cannot|can.t|could not|couldn.t) both be\\b",
        "\\b(conflict with|inconsistent with)\\b",
        "\\bcontradict\\w*\\b"
      ]
    },
    {
      "id": "reciprocity_axis",
      "priority": 270,
      "axes": [
        "reciprocity"
      ],
      "patterns": [
        "reciprocity"
      ],
      "phrases": [
        "in return",
        "reciprocate",
        "goes both ways",
        "same effort back",
        "give and take",
        "we both contributed",
        "both contributed"
      ],
      "regexPatterns": [
        "\\b(comes?|gets?|gives?) back\\b",
        "\\b(other way|both ways|one[- ]sided)\\b",
        "\\b(without|but not|never)\\b.{0,45}\\b(same|equal|similar)\\b.{0,20}\\b(effort|support|care|help)\\b.{0,20}\\b(back|return|other way)\\b",
        "\\b(effort|support|care|help)\\b.{0,35}\\b(coming|comes|came) back\\b",
        "\\b(little|no|less)\\b.{0,20}\\b(support|effort|care|help)\\b.{0,12}\\bback\\b",
        "\\bboth\\b.{0,30}\\b(contribut|gave|helped|supported)\\w*\\b"
      ]
    },
    {
      "id": "trust_axis",
      "priority": 280,
      "axes": [
        "trust"
      ],
      "patterns": [
        "trust"
      ],
      "phrases": [
        "i trust",
        "do not trust",
        "don't trust",
        "trust was broken",
        "earn my trust",
        "trust them",
        "trusting",
        "trusted",
        "i rely on"
      ],
      "regexPatterns": [
        "\\b(rely|depend|count) on\\b.{0,50}\\b(her|him|them|you|me|word|follow through)\\b",
        "\\btrust\\w*\\b",
        "\\brely on\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z\\'-]{1,30})\\s+rel(?:y|ied|ies) on\\b"
      ],
      "excludePatterns": [
        "\\btrust (account|fund|instrument)\\b"
      ]
    },
    {
      "id": "respect_axis",
      "priority": 290,
      "axes": [
        "respect"
      ],
      "patterns": [
        "respect"
      ],
      "phrases": [
        "respect me",
        "disrespect",
        "disrespected",
        "mutual respect",
        "treated with respect",
        "i respect",
        "respect her",
        "respect him",
        "respect them"
      ],
      "regexPatterns": [
        "\\b(talked|spoke) over me\\b",
        "\\b(dismissed|belittled|mocked|demeaned) me\\b",
        "\\b(talk|talked|talking|speak|spoke|speaking)\\b.{0,12}\\bover me\\b",
        "\\b(talked|talking|spoke|speaking) over\\b",
        "\\brespect\\w*\\b",
        "\\b(disregard|ignored|honor|honoured|honored)\\w*\\b.{0,30}\\b(boundary|choice|decision|request|limit)\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z\\'-]{1,30})\\s+(?:no longer\\s+)?(?:respect|respects|respected|disregard|disregards|disregarded)\\b"
      ]
    },
    {
      "id": "fairness_axis",
      "priority": 300,
      "axes": [
        "fairness"
      ],
      "patterns": [
        "fairness"
      ],
      "phrases": [
        "fair to me",
        "unfair",
        "not fair",
        "double standard",
        "same standard",
        "not in equal ways",
        "equal ways"
      ],
      "regexPatterns": [
        "\\b(same|equal)\\b.{0,50}\\b(only one|different treatment|different pay|one of us)\\b",
        "\\b(unequal|inequitable|uneven|one-sided)\\b.{0,25}\\b(arrangement|treatment|split|share|deal|work|pay)?\\b",
        "\\b(not )?equal\\b.{0,20}\\b(ways|share|parts|contribution)\\b",
        "\\b(fair|unfair|equitable|inequitable)\\b",
        "\\b(equal|unequal)\\b.{0,25}\\b(treatment|split|share|standard|burden|workload)\\b"
      ],
      "excludePatterns": [
        "\\b(the )?fair\\b.{0,20}\\b(opens?|closes?|grounds|rides?|saturday|sunday|monday|tuesday|wednesday|thursday|friday)\\b"
      ]
    },
    {
      "id": "temporal_scope_axis",
      "priority": 310,
      "axes": [
        "temporal_scope"
      ],
      "patterns": [
        "temporal_scope"
      ],
      "phrases": [
        "used to",
        "before this",
        "after that",
        "since then",
        "right now",
        "at the time",
        "yesterday",
        "tomorrow",
        "this morning",
        "this week",
        "after tuesday"
      ],
      "regexPatterns": [
        "\\b(last year|last month|back then|at the time|nowadays|today|currently)\\b",
        "\\b(yesterday|tomorrow|this morning|this week|this month)\\b",
        "\\b(before|after|since)\\b.{0,20}\\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\\b"
      ]
    },
    {
      "id": "effort_axis",
      "priority": 320,
      "axes": [
        "effort"
      ],
      "patterns": [
        "effort"
      ],
      "phrases": [
        "i tried",
        "i keep trying",
        "put in effort",
        "worked hard",
        "doing everything i can",
        "gave it my all",
        "did more work",
        "did less work",
        "everything i could"
      ],
      "regexPatterns": [
        "\\b(spent|worked|kept going|persisted|put)\\b.{0,50}\\b(time|hours|afternoon|work|effort|trying)\\b",
        "\\b(more|less) work\\b",
        "\\b(everything|all) i could\\b",
        "\\b(try|tried|tries|trying|work(?:ed|ing)?|labor(?:ed|ing)?|persist(?:ed|ing)?)\\b.{0,22}\\b(hard|at it|on it|through it)\\b",
        "\\bput\\b.{0,25}\\b(everything|all|energy|work|time)\\b.{0,20}\\b(into|toward|towards)\\b"
      ]
    },
    {
      "id": "outcome_axis",
      "priority": 330,
      "axes": [
        "outcome"
      ],
      "patterns": [
        "outcome"
      ],
      "phrases": [
        "the result was",
        "ended up",
        "outcome",
        "what happened was",
        "it worked",
        "it did not work",
        "did not finish",
        "didn't finish",
        "finishing it",
        "the result"
      ],
      "regexPatterns": [
        "\\b(came out of|turned out|resulted|ended with|left us with)\\b",
        "\\b(finish|finished|finishing|result)\\w*\\b",
        "\\b(ended|ends)\\b.{0,18}\\b(badly|well|poorly|successfully)\\b",
        "\\b(got|reached|achieved|obtained)\\b.{0,25}\\b(result|outcome|end state)\\b"
      ],
      "excludePatterns": [
        "\\boutcome (variable|column|field|measure)\\b"
      ]
    },
    {
      "id": "sufficiency_axis",
      "priority": 340,
      "axes": [
        "sufficiency"
      ],
      "patterns": [
        "sufficiency"
      ],
      "phrases": [
        "still not enough",
        "enough for",
        "nothing i do is enough",
        "did enough",
        "good enough",
        "sufficient"
      ],
      "regexPatterns": [
        "\\b(insufficient|still falls short|never feels sufficient|doesn.t feel enough)\\b",
        "\\b(did not|does not|doesn.t|didn.t|still doesn.t|still did not)\\b.{0,25}\\b(feel|seem)\\b.{0,12}\\b(enough|sufficient)\\b",
        "\\bsufficient\\b",
        "\\b(?:still\\s+)?(?:was|is|were|are|had|have)?\\s*(?:not\\s+)?enough\\b",
        "\\benough\\b.{0,20}\\b(to|for)\\b"
      ]
    },
    {
      "id": "change_axis",
      "priority": 350,
      "axes": [
        "change"
      ],
      "patterns": [
        "change"
      ],
      "phrases": [
        "has changed",
        "things changed",
        "different now",
        "not the same anymore",
        "became different",
        "changed"
      ],
      "regexPatterns": [
        "\\b(no longer|not anymore|used to be)\\b.{0,60}\\b(way|same|different|like)\\b",
        "\\b(grown|became|become|turned)\\b.{0,25}\\b(distant|closer|different|apart)\\b",
        "\\bwhat changed between\\b",
        "\\b(change|changed|changes|changing)\\b"
      ],
      "excludePatterns": [
        "\\bchange machine\\b"
      ]
    },
    {
      "id": "connection_axis",
      "priority": 360,
      "axes": [
        "connection"
      ],
      "patterns": [
        "connection"
      ],
      "phrases": [
        "feel connected",
        "connection with",
        "close to them",
        "distant from",
        "feel disconnected",
        "still connected",
        "connected"
      ],
      "regexPatterns": [
        "\\b(feel|felt|remain|stayed) close to\\b",
        "\\b(bond|closeness)\\b",
        "\\b(care|cared|caring) about (him|her|them|you|us)\\b",
        "\\bconnect\\w*\\b"
      ],
      "excludePatterns": [
        "\\bconnection (timed out|timeout|socket|pool|string)\\b"
      ]
    },
    {
      "id": "repair_axis",
      "priority": 370,
      "axes": [
        "repair"
      ],
      "patterns": [
        "repair"
      ],
      "phrases": [
        "make it right",
        "repair this",
        "fix what happened",
        "rebuild trust",
        "make amends",
        "the repair",
        "repair has not",
        "repair hasn't"
      ],
      "regexPatterns": [
        "\\b(address|undo|repair|mend)\\b.{0,40}\\b(damage|harm|what happened|relationship)\\b",
        "\\bput (it|things) back in order\\b",
        "\\brepair\\w*\\b"
      ]
    },
    {
      "id": "acceptance_rejection_axis",
      "priority": 380,
      "axes": [
        "acceptance_rejection"
      ],
      "patterns": [
        "acceptance_rejection"
      ],
      "phrases": [
        "accepted me",
        "rejected me",
        "turned me away",
        "welcomed me",
        "did not accept",
        "didn't accept"
      ],
      "regexPatterns": [
        "\\b(excluded|included|welcomed|turned away|shut out|accepted|rejected)\\b",
        "\\b(i|we|you|he|she|they|[a-z][a-z'-]{1,30}) (?:do not|don.t|did not|didn.t|will not|won.t|cannot|can.t)?\\s*accept(?:s|ed)?\\b"
      ]
    }
  ],
  "output_contract": {
    "axes": "deduped axis list in registry priority order",
    "dominant_axis": "first detected axis or null",
    "patterns": "deduped detected pattern list",
    "axis_evidence": "matched evidence phrases, contributing rule ids, additive evidence states (asserted/negated/uncertain), and actor attribution when structurally supported; non-authoritative"
  },
  "containment_notes": [
    "AxisEngine evaluates registry rules only.",
    "Axis rules remain backend-owned in Obsidian markdown.",
    "Moving this registry must not grant authority, diagnosis, therapy framing, or self-approval.",
    "Rule-local excludePatterns may suppress known lexical homonyms; exclusions do not create axes or authority."
  ]
}
```
