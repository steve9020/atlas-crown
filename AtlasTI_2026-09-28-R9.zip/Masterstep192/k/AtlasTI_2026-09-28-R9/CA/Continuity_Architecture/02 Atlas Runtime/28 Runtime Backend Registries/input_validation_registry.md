# Input Validation Registry

Purpose: stores runtime input validation rules in the Obsidian backend so `InputValidator.js` remains a generic validation-rule evaluator instead of owning Atlas/Compass-specific validation behavior.

Boundary: this registry may declare input type, trimming, minimum length, issue identifiers, and evaluation order. It may not diagnose, interpret user meaning, mutate backend files, bypass governance, expand authority, or rewrite user input.

Runtime use: `InputValidator.js` reads this JSON registry and applies generic validation checks to the incoming input. The validator reports pass/fail and issue IDs only; it does not alter, interpret, or classify the user's meaning.

```json
{
  "version": "OBSIDIAN_INPUT_VALIDATION_REGISTRY_STAGE6",
  "validationMode": "generic_input_rule_evaluation",
  "rules": [
    {
      "id": "input_must_be_string",
      "type": "type_is_string",
      "issue": "input_not_string"
    },
    {
      "id": "input_must_not_be_empty",
      "type": "trimmed_minimum_length",
      "minimum": 1,
      "issue": "input_empty",
      "stringOnly": true
    },
    {
      "id": "input_must_have_minimum_detail",
      "type": "trimmed_minimum_length",
      "minimum": 3,
      "issue": "input_too_short",
      "stringOnly": true
    }
  ],
  "nonMutationRule": "Input validation reports issues only. It does not rewrite input, infer user meaning, bypass governance, diagnose, or expand authority."
}
```
