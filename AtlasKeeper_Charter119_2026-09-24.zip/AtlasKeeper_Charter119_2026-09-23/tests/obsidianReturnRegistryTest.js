const assert = require("assert");
const { selectReturn } = require("../Cognition/return/ReturnEngine.js");
const { readJsonRegistry } = require("../runtime/backend/ObsidianRegistryReader.js");

const RETURN_MODE_REGISTRY_PATH = "CA/Continuity_Architecture/07 Atlas Response Construction/40 Obsidian Runtime Response Registry/return_mode_registry.md";

const registry = readJsonRegistry(RETURN_MODE_REGISTRY_PATH);

assert.strictEqual(registry.version, "OBSIDIAN_RETURN_REGISTRY_STAGE3");
assert.ok(Array.isArray(registry.rules), "return registry rules must be an array");
assert.strictEqual(registry.rules.length, 7, "return registry should preserve seven return-mode rules");
assert.ok(registry.fallback, "return registry must define a fallback");
assert.strictEqual(registry.fallback.returnMode, "neutral_return", "return registry fallback must preserve neutral_return");

assert.strictEqual(selectReturn({ axes: ["worth", "permanence"], patterns: [] }), "worth_return");
assert.strictEqual(selectReturn({ axes: ["identity"], patterns: [] }), "identity_return");
assert.strictEqual(selectReturn({ axes: ["belonging"], patterns: [] }), "belonging_return");
assert.strictEqual(selectReturn({ axes: ["emotional_validity"], patterns: [] }), "emotional_validity_return");
assert.strictEqual(selectReturn({ axes: ["perfection"], patterns: [] }), "perfection_return");
assert.strictEqual(selectReturn({ axes: ["detachment"], patterns: [] }), "detachment_return");
assert.strictEqual(selectReturn({ axes: ["permanence"], patterns: [] }), "permanence_return");
assert.strictEqual(selectReturn({ axes: [], patterns: [] }), "neutral_return");

console.log("obsidianReturnRegistryTest.js — PASSED");
console.log("Return mode selection is now read from Obsidian backend markdown.");
