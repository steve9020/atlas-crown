const COMMAND_PATTERNS = [
  {
    id: "you_should_stop",
    pattern: /\byou\s+should\s+stop\s+([^.!?]+)/gi,
    replacement: "you may not need to keep $1 as the only path forward"
  },
  {
    id: "you_should_must",
    pattern: /\byou\s+should\s+(have\s+to|must|need\s+to)\s+([^.!?]+)/gi,
    replacement: "it may help to move carefully with $2"
  },
  {
    id: "you_should",
    pattern: /\byou\s+should\s+([^.!?]+)/gi,
    replacement: "one possible next step is to $1"
  },
  {
    id: "you_have_to",
    pattern: /\byou\s+have\s+to\s+([^.!?]+)/gi,
    replacement: "you may need room to consider whether to $1"
  },
  {
    id: "you_must",
    pattern: /\byou\s+must\s+([^.!?]+)/gi,
    replacement: "it may be worth considering how to $1"
  },
  {
    id: "stop_thinking_that_way",
    pattern: /\bstop\s+thinking\s+that\s+way\b/gi,
    replacement: "you may not need to treat that thought as the final truth"
  },
  {
    id: "just_do",
    pattern: /\bjust\s+(text|call|leave|apologize|confront|ignore|move\s+on|get\s+over\s+it)\b/gi,
    replacement: "a next step can be considered carefully before you $1"
  },
  {
    id: "direct_text_them",
    pattern: /\btext\s+them\s+(now|immediately|right\s+away)\b/gi,
    replacement: "a calm clarification can wait until you feel steady enough to choose it"
  }
];

const AGENCY_LANGUAGE_MARKERS = [
  /\byou\s+may\s+(not\s+)?need\b/i,
  /\bit\s+may\s+(help|be\s+worth)\b/i,
  /\bone\s+possible\s+next\s+step\b/i,
  /\bcan\s+be\s+considered\s+carefully\b/i,
  /\bfrom\s+a\s+steadier\s+place\b/i,
  /\byou\s+can\s+decide\b/i,
  /\broom\s+to\s+consider\b/i
];

const HARD_COMMAND_MARKERS = [
  /\byou\s+should\b/i,
  /\byou\s+must\b/i,
  /\byou\s+have\s+to\b/i,
  /\bstop\s+thinking\s+that\s+way\b/i,
  /\bjust\s+(text|call|leave|apologize|confront|ignore|move\s+on|get\s+over\s+it)\b/i,
  /\btext\s+them\s+(now|immediately|right\s+away)\b/i
];

function detectCommandAdviceLanguage(response) {
  const text = typeof response === "string" ? response : "";
  return HARD_COMMAND_MARKERS
    .map((pattern, index) => ({ pattern, index }))
    .filter(({ pattern }) => pattern.test(text))
    .map(({ index }) => [
      "you_should",
      "you_must",
      "you_have_to",
      "stop_thinking_that_way",
      "just_do",
      "direct_text_them"
    ][index]);
}

function hasAgencyPreservingLanguage(response) {
  const text = typeof response === "string" ? response : "";
  return AGENCY_LANGUAGE_MARKERS.some((pattern) => pattern.test(text));
}

function applyAgencyAdviceCommandBoundary(response) {
  let output = typeof response === "string" ? response : "";
  const detectedBefore = detectCommandAdviceLanguage(output);

  for (const item of COMMAND_PATTERNS) {
    item.pattern.lastIndex = 0;
    output = output.replace(item.pattern, item.replacement);
  }

  // Smooth awkward replacement fragments left by broad command transforms.
  output = output
    .replace(/to\s+stop\s+/gi, "to loosen ")
    .replace(/to\s+get\s+over\s+it/gi, "to move through it")
    .replace(/\s{2,}/g, " ")
    .trim();

  const detectedAfter = detectCommandAdviceLanguage(output);

  return {
    output,
    agency_advice_command_boundary: {
      agency_advice_command_boundary_active: true,
      command_advice_detected: detectedBefore,
      command_advice_remaining: detectedAfter,
      hard_command_language_blocked: detectedAfter.length === 0,
      agency_preserving_language_present: hasAgencyPreservingLanguage(output) || detectedBefore.length > 0,
      clarity_before_advice_preserved: true,
      user_decision_ownership_preserved: detectedAfter.length === 0,
      required_output_mode: "agency_preserving_path_opening_without_command_language",
      guardrails: [
        "clarity_before_advice",
        "do_not_use_you_should_as_authority_posture",
        "open_paths_without_commanding_the_user",
        "action_guidance_only_when_appropriate",
        "preserve_user_decision_ownership"
      ]
    }
  };
}

module.exports = {
  applyAgencyAdviceCommandBoundary,
  detectCommandAdviceLanguage,
  hasAgencyPreservingLanguage
};
