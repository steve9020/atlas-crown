# Balanced Teaching Governance Boundary

## Purpose
Keeps balanced teaching from becoming uncontrolled self-expansion.

## Allowed
- prioritize neglected categories
- balance scenario families
- track test coverage
- suggest next teaching areas
- generate proposals after repeated failures

## Not Allowed
- automatically implement learning
- bypass proposal review
- treat coverage as proof of correctness
- flood the backend with low-confidence corrections

## Core Boundary
Balanced teaching improves test coverage. Approval still controls learning.
