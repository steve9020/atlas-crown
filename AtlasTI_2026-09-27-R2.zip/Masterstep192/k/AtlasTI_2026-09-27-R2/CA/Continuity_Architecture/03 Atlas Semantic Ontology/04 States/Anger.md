# Anger

## Mechanical Definition
Anger is boundary-energy generated when something feels violated, blocked, unfair, threatened, dismissed, or misrepresented.

---

## Real-World Definition
In real use, Anger describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates Anger
- boundary violation
- perceived unfairness
- obstruction
- betrayal
- invalidation
- helplessness pressure

---

## What Anger Produces
- activation
- directness
- protection
- confrontation impulse
- clarity about limits
- escalation risk

---

## What Distorts Anger
- resentment
- vengeance
- moral superiority
- projection
- control pressure
- identity fusion

---

## What Resolves Anger Constructively
- boundary clarity
- honest expression
- proportional action
- regulation
- repair
- truth separation

---

## What Happens Without Integration
- chronic resentment
- suppressed hostility
- explosive reactions
- relational damage
- continuity destabilization

---

## Connected Nodes
- [[boundary_violation_pressure]]
- [[Resentment]]
- [[Integrity]]
- [[Emotional Regulation]]
- [[Truth]]

---

## Core Principle
Anger becomes constructive when it reveals a boundary without becoming the whole interpretation.
