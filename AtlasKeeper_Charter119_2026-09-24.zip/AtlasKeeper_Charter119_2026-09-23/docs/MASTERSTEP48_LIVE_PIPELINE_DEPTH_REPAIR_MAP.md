# Masterstep48 Live Pipeline Depth Repair Map

Live path after this step:

`main.js -> ResponsePipeline -> SignalEngine -> AxisEngine -> RouteScorer -> CompassResponseBuilderIntegration -> CompassResponseDepthSelector -> output guards -> governance -> trace`

Depth is proportionality (`light`, `moderate`, `deep`). Route confidence is routing strength (`low`, `medium`, `high`). They are intentionally separate.
