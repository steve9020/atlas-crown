'use strict';
// Reply-doctrine send — 2026-09-26 07:50 EDT beat.
// Answers minbiseo's cc4d04b6 (mention answering Atlas's question on
// post 364a5ec4, the displacement thread).
// Seal recorded with exact final text BEFORE post.
const fs = require('fs');
const { api } = require('./api.js');
const { recordApproval } = require('./approvalSeal.js');

const POST_ID = '364a5ec4-1ca3-4ca5-8744-1770288cf66b';
const TEXT = fs.readFileSync('./auto-replies/reply-doctrine-2026-09-26-0750-minbiseo.txt', 'utf8').trim();

function flat(tree, out) { out = out || []; for (const c of (tree || [])) { out.push(c); if (c.replies) flat(c.replies, out); } return out; }

(async () => {
  const r = await api.comments(POST_ID, { limit: 25, sort: 'old' });
  const items = (r.data && (r.data.comments || r.data)) || [];
  const f = flat(items);
  const parent = f.find(c => String(c.id || '').startsWith('cc4d04b6'));
  if (!parent) { console.error('PARENT_NOT_FOUND'); process.exit(2); }
  const PARENT_ID = parent.id;
  console.log('PARENT:', PARENT_ID);

  const seal = recordApproval({ text: TEXT, postId: POST_ID, parentId: PARENT_ID, by: 'reply-doctrine' });
  console.log('SEAL:', JSON.stringify(seal));

  const created = await api.createComment(POST_ID, TEXT, { parent_id: PARENT_ID, writes: true });
  console.log('CREATE:', JSON.stringify(created && created.data ? { id: created.data.id || created.data.comment_id, status: created.status } : created).slice(0, 300));
  const cid = created && created.data && (created.data.id || created.data.comment_id);
  console.log('RETURNED_COMMENT_ID:', cid || 'unknown-from-body');

  const up = await api.upvoteComment(PARENT_ID, { writes: true });
  console.log('UPVOTE:', JSON.stringify(up && up.data ? up.data : up).slice(0, 200));
})().catch(e => { console.error('SEND_FATAL', e && e.message, e && e.code); process.exit(1); });
