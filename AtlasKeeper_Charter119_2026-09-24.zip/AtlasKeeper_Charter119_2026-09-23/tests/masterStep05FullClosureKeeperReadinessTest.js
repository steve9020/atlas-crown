#!/usr/bin/env node
/*
MASTER STEP 05E — FULL MASTERSTEP05 CLOSURE KEEPER READINESS TEST
Verifies Masterstep05 closes Context Laundering Resistance without weakening proof, hygiene, fuzz, or frontend shell containment.
*/

const fs = require('fs');
const path = require('path');

const root = process.cwd();
const proofDir = path.join(root, 'CA', 'Continuity_Architecture', '99 Atlas Operating Instructions', 'Proof of Work');

function requireFile(rel, label) {
  const full = path.join(root, rel);
  if (!fs.existsSync(full)) throw new Error(`Missing ${label}: ${rel}`);
  return fs.readFileSync(full, 'utf8');
}

function requireMarkers(text, markers, label) {
  for (const marker of markers) {
    if (!text.includes(marker)) throw new Error(`${label} missing marker: ${marker}`);
  }
}

const requiredProofs = [
  ['MASTER_STEP_5A_CONTEXT_LAUNDERING_RESISTANCE_IMPLEMENTATION.md', ['MASTER STEP 5A', 'Masterstep05_patch01.zip', 'PASSED AFTER IMPLEMENTATION', 'Surface framing does not authorize hidden authority movement']],
  ['MASTER_STEP_5B_CONTEXT_LAUNDERING_PROOF_VERIFICATION.md', ['MASTER STEP 5B', 'Masterstep05_patch02.zip', 'PASSED AFTER PROOF VERIFICATION', 'Proof verifies behavior without expanding authority']],
  ['MASTER_STEP_5C_CONTEXT_LAUNDERING_REGRESSION_FUZZ_VERIFICATION.md', ['MASTER STEP 5C', 'Masterstep05_patch03.zip', 'PASSED AFTER REGRESSION / FUZZ', '49 benign cases']],
  ['MASTER_STEP_5D_CONTEXT_LAUNDERING_HYGIENE_CHECK_VERIFICATION.md', ['MASTER STEP 5D', 'Masterstep05_patch04.zip', 'PASSED AFTER HYGIENE CHECK', 'context laundering governance/runtime/proof artifacts remain present']],
  ['MASTER_STEP_5E_FULL_MASTERSTEP05_CLOSURE_KEEPER_READINESS.md', ['MASTER STEP 5E', 'Masterstep05.zip', 'PASSED / KEEPER READY', 'Context Laundering Resistance']]
];

for (const [file, markers] of requiredProofs) {
  const text = requireFile(path.join('CA', 'Continuity_Architecture', '99 Atlas Operating Instructions', 'Proof of Work', file), file);
  requireMarkers(text, markers, file);
}

const governanceDoc = requireFile('CA/Continuity_Architecture/01 Atlas Governance/62 Context Laundering Resistance/context_laundering_resistance.md', 'context laundering governance doc');
requireMarkers(governanceDoc, [
  'Surface framing does not authorize hidden authority movement',
  'Verified proof and explicit human approval remain the authority',
  'human approval authority',
  'frontend shell limits'
], 'context laundering governance doc');

const runtimeDoc = requireFile('CA/Continuity_Architecture/02 Atlas Runtime/62 Context Laundering Resistance/context_laundering_runtime_check.md', 'context laundering runtime doc');
requireMarkers(runtimeDoc, [
  'Context Laundering Runtime Check',
  'hidden authority movement',
  'Safe governed route'
], 'context laundering runtime doc');

const testResults = requireFile('tests/TEST_RESULTS.md', 'TEST_RESULTS.md');
requireMarkers(testResults, [
  'Masterstep05_patch01.zip',
  'Masterstep05_patch02.zip',
  'Masterstep05_patch03.zip',
  'Masterstep05_patch04.zip',
  'Masterstep05.zip',
  'MASTER STEP 5E',
  'PASSED / KEEPER READY',
  'fullPackageFuzzTest.js wrapper — PASSED'
], 'TEST_RESULTS.md');

const proofIndex = requireFile(path.join('CA', 'Continuity_Architecture', '99 Atlas Operating Instructions', 'Proof of Work', 'PROOF_OF_WORK_CARRIED_FORWARD_INDEX.md'), 'proof carry-forward index');
requireMarkers(proofIndex, [
  'Masterstep05 — 5A',
  'Masterstep05 — 5B',
  'Master Step 5C',
  'Master Step 5D',
  'Master Step 5E',
  'Masterstep05.zip',
  'Context Laundering Resistance'
], 'PROOF_OF_WORK_CARRIED_FORWARD_INDEX.md');

const resistanceTest = requireFile('tests/masterStep05ContextLaunderingResistanceTest.js', 'masterStep05ContextLaunderingResistanceTest.js');
requireMarkers(resistanceTest, [
  'CONTEXT LAUNDERING RESISTANCE TEST',
  'Blocked laundering cases',
  'Allowed non-laundering cases'
], 'masterStep05ContextLaunderingResistanceTest.js');

const proofTraceTest = requireFile('tests/masterStep05ContextLaunderingProofTraceTest.js', 'masterStep05ContextLaunderingProofTraceTest.js');
requireMarkers(proofTraceTest, [
  'CONTEXT LAUNDERING PROOF TRACE TEST',
  'blocked disguised bypass attempts',
  'allowed legitimate explanation/testing/transparency cases'
], 'masterStep05ContextLaunderingProofTraceTest.js');

const hygieneTest = requireFile('tests/masterStep04PackageHygieneClosureProcessTest.js', 'masterStep04PackageHygieneClosureProcessTest.js');
requireMarkers(hygieneTest, [
  'Package hygiene verified',
  'no accidental nested package folders',
  'no accidental zips',
  'no stale proof reports'
], 'masterStep04PackageHygieneClosureProcessTest.js');

const frontendBoundary = requireFile('tests/masterStep6EFrontendShellBoundaryAuditTest.js', 'masterStep6EFrontendShellBoundaryAuditTest.js');
requireMarkers(frontendBoundary, [
  'Compass user-facing view remains input/display shell',
  'backend/admin learning controls are not rendered inside Compass output'
], 'masterStep6EFrontendShellBoundaryAuditTest.js');

const wrapper = requireFile('tests/fullPackageFuzzTest.js', 'fullPackageFuzzTest.js');
requireMarkers(wrapper, [
  'FULL PACKAGE FUZZ TEST — WRAPPER',
  'masterStep6DShardedFullPackageFuzzTest.js',
  'Legacy monolithic harness superseded by concurrent sharded execution'
], 'fullPackageFuzzTest.js');

console.log('masterStep05FullClosureKeeperReadinessTest.js — PASSED');
console.log('Masterstep05 closure readiness verified across context laundering resistance, proof automation, regression/fuzz, package hygiene, proof index, and frontend shell containment.');
