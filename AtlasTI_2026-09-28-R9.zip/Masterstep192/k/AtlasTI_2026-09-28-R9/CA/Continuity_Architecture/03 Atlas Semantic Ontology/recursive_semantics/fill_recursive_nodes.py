from pathlib import Path

folder = Path.cwd()

for file in folder.glob("*.md"):
    name = file.stem
    title = name.replace("_", " ").title()

    content = f"""---
type: recursive_semantic
semantic_domain: recursive_semantics
recursive_id: {name}
activation_weight: variable
risk_level: dynamic
runtime_role: recursive_interpretation
status: scaffolded
---

# {title}

## Semantic Purpose
This node defines recursive movement patterns within the continuity system.

Recursion is not inherently negative.  
Recursion can stabilize, reinforce, destabilize, recover, amplify, or fragment continuity depending on direction and regulation.

## Core Recursive Meaning
{title} represents a repeated continuity movement where outputs feed back into future interpretation, behavior, pressure, stabilization, recovery, or identity orientation.

## Common Language Indicators
- "This keeps repeating."
- "I keep looping on this."
- "I can't stop thinking about it."
- "This pattern keeps returning."
- "I feel trapped in the cycle."
- "Every time this happens..."
- "It keeps reinforcing itself."
- "This keeps escalating."
- "I don't know how to interrupt this."
- "The same thing keeps happening."

## Operational Use
The system may route here when:
- repeated patterns emerge
- escalation compounds
- contradiction cycles repeat
- pressure continuously reactivates
- stabilization repeatedly fails
- recovery loops collapse
- fragmentation reappears
- adaptive cycles form

## Continuity Function
This recursive pathway helps:
- identify repeating continuity patterns
- track amplification movement
- distinguish healthy vs destabilizing recursion
- monitor escalation velocity
- recognize reinforcement loops
- support recursive stabilization
- preserve adaptive continuity movement
- identify interruption opportunities

## Reverse Flow Risks
This node may reverse into:
- runaway recursion
- escalation spirals
- recursive contradiction overload
- recursive fragmentation
- collapse loops
- identity destabilization
- interpretive narrowing
- continuity degradation

## Plugin Runtime Notes
The plugin should use this node to detect recursive movement patterns and evaluate whether recursion is:
- adaptive
- destabilizing
- stabilizing
- amplifying
- fragmenting
- reinforcing
- collapsing

It should not:
- assume recursion is inherently unhealthy
- collapse all repetition into pathology
- suppress recursive analysis

It should:
- track recursive direction
- evaluate continuity effects
- monitor escalation intensity
- route toward stabilization when necessary
- preserve adaptive recursive learning

## Related Semantic Domains
- pressure_semantics
- stabilization_semantics
- recovery_semantics
- regulation_semantics
- contradiction_semantics
- continuity_semantics
- threshold_semantics
- fragmentation_semantics

## Expansion Notes
This node can later be expanded with:
- recursive pattern maps
- amplification scoring
- recursive interruption systems
- adaptive loop structures
- recursive recovery pathways
- recursive stabilization systems
- runtime recursive weighting
"""

    file.write_text(content, encoding="utf-8")

print("Recursive semantic files filled.")