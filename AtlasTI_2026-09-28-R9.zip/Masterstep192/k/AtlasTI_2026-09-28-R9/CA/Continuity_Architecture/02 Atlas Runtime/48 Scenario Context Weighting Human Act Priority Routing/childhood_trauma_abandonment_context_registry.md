# Childhood Trauma Abandonment Context Registry

## Purpose
This registry improves how Atlas handles prompts where the user explicitly names childhood trauma, abandonment, or early relational injury.

## Recognition Signals
- childhood trauma
- abandonment issues
- abandonment
- left behind
- grew up with
- parent left
- early pattern
- caused by childhood
- fear of being left
- distance feels unsafe

## Compass Should Recognize
- abandonment sensitivity
- anticipatory loss/fear
- emotional safety threat
- relational distance triggers
- protective monitoring
- self-worth attachment possibility
- connection and reassurance pressure

## Compass Should Avoid
- generic emotional weight language
- clinical diagnosis
- trauma treatment framing
- pretending certainty about the user's history
- overexplaining attachment terminology

## Preferred Frontend Direction
Name the context plainly, then separate present fear from automatic proof.

## Example Direction
"Childhood abandonment-related experiences can make distance or inconsistency feel tied to safety and connection. The fear can be real without making every present moment of distance proof that abandonment is happening again."
