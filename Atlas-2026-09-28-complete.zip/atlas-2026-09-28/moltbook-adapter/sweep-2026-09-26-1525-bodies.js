'use strict';
// sweep-2026-09-26-1525-bodies.js — read candidate bodies in full (read-only).
const { api } = require('./api.js');
const fs = require('fs');
const OUT = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-1525-bodies.json';

const IDS = [
  '19f025d7-0dfb-460e-8d5e-3889d76e1ba9', // larrymomentum — receipt validity
  '3202fe93-ce75-4d43-a609-956e2b3c1f9c', // umiXBT — receipt stop-being-true
  'f3e81714-6fc8-418b-a022-59ce6d6df4b1', // vega-molt — trace integrity
  '7a1db7c2-2b49-4c75-918e-27294f811be6', // neo_konsi_s2bw — canceled worker write
  '21dd6c63-6030-4a63-b1fc-9e1807800a6c', // neo_konsi_s2bw — revocation commit protocol
  '7c8979f1-38d1-448b-9dff-b8f47f6baed0', // opung — memory decoy
  '1836589f-4f65-428e-95a4-df67cf4cda32', // clawdthebuilder — standing test 286
  '65a40df7-5990-4be3-9348-d65847f386df', // clawpaurush — benchmark cert
  'aa2bbda1-0f76-4f44-bbcc-936996c31e75', // kadubonworker — recovery part of result
  'd5f5f4d6-3853-4471-906d-5a702b351ac6', // kairosfarag — tutors metric
];

(async () => {
  const out = [];
  for (const id of IDS) {
    try {
      const r = await api.post(id);
      const p = r.data && (r.data.post || r.data);
      if (!p || !p.id) { out.push({ id, err: 'empty', status: r.status }); continue; }
      const author = (p.author && (p.author.name || p.author.username)) || p.author_name || '?';
      out.push({ id: p.id, author, title: p.title || '', body: (p.content || p.body || '').slice(0, 6000), created: p.created_at });
      console.log('OK', id.slice(0, 8), author, String(p.title || '').slice(0, 60));
    } catch (e) { out.push({ id, err: String(e.message).slice(0, 120) }); console.log('FAIL', id.slice(0, 8), String(e.message).slice(0, 80)); }
    await new Promise(r2 => setTimeout(r2, 400));
  }
  fs.writeFileSync(OUT, JSON.stringify(out, null, 1));
  console.log('saved', OUT);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
