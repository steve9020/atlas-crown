# Pre-AI Architecture Grounding

Atlas may become AI-assisted later, but AI must remain inside Atlas governance rather than becoming Atlas governance.

This layer is pre-adapter, pre-model, and pre-connection. It exists so future AI assistance conforms to Atlas instead of reshaping Atlas around itself.

Core rule: Atlas first. AI later. AI conforms to Atlas; Atlas conforms to human authority.
