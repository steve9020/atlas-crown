const fs = require('fs');
const path = require('path');
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const root = path.join(__dirname, '..');
function readJson(rel){ return JSON.parse(fs.readFileSync(path.join(root, rel), 'utf8')); }
const proof = readJson('runtime/proof/PROOF_STATE.json');
const active = readJson('runtime/workflow/ACTIVE_STEP.json');
const workflow = readJson('runtime/workflow/WORKFLOW_STATE.json');
const scope = readJson('runtime/workflow/IMPLEMENTATION_SCOPE.json');
assert(proof.current_keeper === 'Masterstep33.zip', 'proof current keeper must be Masterstep33');
assert(active.current_keeper === 'Masterstep33.zip', 'active current keeper must be Masterstep33');
assert(workflow.current_keeper === 'Masterstep33.zip', 'workflow current keeper must be Masterstep33');
assert(scope.current_keeper === 'Masterstep33.zip', 'scope current keeper must be Masterstep33');
assert(proof.extensive_relational_attachment_field_added === true, 'proof must record extensive relational field');
assert(proof.relation_patterns_added >= 128, 'proof must record extensive pattern count');
assert(proof.examples_are_validation_only === true, 'examples must remain validation only');
assert(proof.real_ai_connected === false, 'real AI must remain disconnected');
assert(proof.provider_config_added === false, 'provider config must remain absent');
assert(proof.network_bridge_added === false, 'network bridge must remain absent');
assert(proof.frontend_intelligence_added === false, 'frontend intelligence must remain absent');
console.log('masterStep33FullClosureKeeperReadinessTest PASSED');
