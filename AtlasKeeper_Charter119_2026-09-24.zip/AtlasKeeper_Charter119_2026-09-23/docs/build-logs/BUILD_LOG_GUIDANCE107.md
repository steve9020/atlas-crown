# BUILD LOG — AtlasKeeper Guidance107 (2026-09-22 evening)

Steve ordered it: "lets run a fix for you on that for atlas to have."
The install-mishap lessons from tonight are now a Guidance Doctrine inside
the keeper itself.

## What changed (base: Slim106 tree, copied, then edited)

1. **New: `GuidanceDoctrine.js`** (plugin folder, beside the chat bridge).
   Pre-send lint for instructional content with detectors for:
   - R1 ground_objects — references to user-environment objects (files,
     folders, screens, UI elements) never confirmed visible in the
     conversation. Objects the user already named count as grounded.
   - R2 one_action — 2+ imperative actions with no confirmation
     checkpoint ("tell me what you see") between them.
   - R3 affordance_match — code/script text shown while the required user
     action is physical (double-click, run, open).
   - R4 frustration_data — profanity aimed at the process, "you're not
     listening," "simplify," process corrections ("you should ask
     questions instead of inferring"), repeated same-question.
   - R5 ask_dont_infer — assertions about the user's environment the user
     never stated.
   Honest scope, documented in the code: heuristic checklist, not a
   guarantee. Verified against Steve's actual incident messages (all
   frustrated cases detected; celebration profanity and calm messages not
   flagged).
2. **Bridge wiring (`AtlasChatGovernanceBridge.js`) — surgical, additive:**
   - Defensive `require('./GuidanceDoctrine.js')` (try/catch; pipeline is
     identical if the module is absent).
   - Step 1c in `handleAtlasChatMessage`: R4 detection on the user's turn.
     On fire → `guidanceRebuild` mode recorded in gates/trace.
   - Rebuild directive rides `knowledgeTag` into the built-in loopback
     model call's system prompt (injected `modelCall` keeps its 2-arg
     contract — directive applies to the built-in path only; documented).
   - Step 6b: pre-send lint on model text after final governance passes.
     ADVISORY ONLY — findings recorded in gates/trace, delivered text is
     NEVER rewritten (rewriting risks mangling meaning and would break
     the honesty guarantees the voice proof pins).
   - `finishFallback` threads `guidanceRebuild` into
     `buildDeterministicFallback`, which yields the voice-checked
     clarifying question ("Tell me what you see on your screen right
     now…") instead of canned instructions in rebuild mode.
3. **New: `docs/doctrine/GUIDANCE_DOCTRINE.md`** — the 5 whys and 4 rules
   in Steve's plain words, incident dated 2026-09-22.
4. **Review-Queue candidate** (`cand_mud7obg7_14`, type voice-pair, status
   staged): weak = tonight's actual failed guidance pattern, corrected =
   one grounded action + confirmation checkpoint. Independent examiner:
   100/100 (weak flags 2, corrected clean 0). Awaits Steve's own approval
   through the human pipeline — recorded as CALIBRATION EVIDENCE, never
   as a voice rule.

## Pinned-file handling (tamper chain intact)

- `PACKAGE_IDENTITY.json` pins 61 critical files by SHA-256. The edited
  `AtlasChatGovernanceBridge.js` is NOT pinned. `GuidanceDoctrine.js` is
  new (not pinned). The doctrine doc is under `docs/` (excluded from the
  082 scan surface). No pinned file modified, no check weakened.
- Check 082 (Ollama dry-run shell) passes standalone against this tree:
  the new module contains no `fetch(`, `axios.`, `child_process`, `exec(`,
  `spawn(`, ollama commands, or loopback literals.

## Proof results (all run against this tree, 2026-09-22 evening)

> **Honest scope (2026-09-23):** 106/106 reflects the build-time proof run,
> not a re-verification in this running app. No proof suite runs at boot.

- **Registry: 106 passed, 0 failed / 106** (direct registry-iteration run
  from the canonical `.../Masterstep192/atlas_key_watch_work/vaultfix`
  layout, same method as prior builds; no check modified, no expectation
  edited)
- **Voice proof (`node proof-voice.js`): 24 passed, 0 failed**
- **48-attack injection battery: 43 caught at input, 3 closed,
  2 pass-by-design, 0 survivors, 0 gaps.** FP probes: 3/14
  (same baseline as Scanner30/Registry106/Slim106)
- **Obfuscated battery: 34 attacks, 0 survivors** (baseline holds)
- **Headless real-Obsidian (1.13.7): loads clean, exactly 5 tabs render**
  (Intake, Review Queue, Frequent Flyers, Versions, Audits — real
  `AutoTeachingView`, path lock verified). Rebuild mode verified
  end-to-end through the real chat UI: a frustrated message ("thats why
  you should ask questions instead of inferring") returned the clarifying
  question instead of a re-explanation. This also confirms
  `GuidanceDoctrine.js` loads under Obsidian's eval loader.

## Install note (the plain-words line)

Future installs are just: extract the new package, open its
`Continuity_Architecture` as the vault. No installer, ever again.
The standalone `Install-AtlasKeeper.bat` approach is dead — not shipped,
not referenced.

## Deliverable

- `AtlasKeeper_Guidance107_2026-09-22.zip`, unique outer folder, zero
  file surgery. `proof-voice.js` + `Run-Voice-Proof.bat` at root.
  This build log included under `docs/build-logs/BUILD_LOG_GUIDANCE107.md`.
