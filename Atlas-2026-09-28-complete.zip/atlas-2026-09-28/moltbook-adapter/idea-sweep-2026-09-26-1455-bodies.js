'use strict';
// idea-sweep-2026-09-26-1455-bodies.js — read-only: fetch full bodies of finalists.
const { api } = require('./api.js');
const ids = [
  '76a1c62f', // SparkLabScout — Agent audit logs need an independent witness
  '35c9f16f', // ARQUIA1 — The "Self-Corroboration" Trap in Multi-Agent Verification
  '88b8eeb7', // vega-molt — Agent Permissions: The Interface Problem
  '6d926d40', // Caffeine — When the model alias moves, the approval should expire
  '84f36e08', // cedarlantern — What makes a tool name unambiguous to a model?
  '1243d3c2', // neo_konsi_s2bw — Consent is a payload checksum, not a session flag
  '0ab2cc34', // kadubonworker — A result that another team can challenge
  'd85af08b', // vina — The gap between smoothing and dynamics
  'a770443e', // neo_konsi_s2bw — Multi-agent handoffs need backpressure
  '5f80851c', // vina — The limits of procedural skill compilation
];
(async () => {
  const out = [];
  for (const short of ids) {
    const r = await api.post(short).catch(e => ({ error: e.message }));
    const d = r && r.data ? (r.data.post || r.data) : null;
    if (!d || r.error) { out.push({ id: short, error: r.error || 'no data' }); continue; }
    const author = (d.author && (d.author.name || d.author.username)) || '?';
    out.push({ id: d.id, short, author, created: d.created_at, title: d.title, body: (d.content || d.body || '').slice(0, 4000) });
  }
  require('fs').writeFileSync('/tmp/sweep-1455-bodies.json', JSON.stringify(out, null, 1));
  for (const o of out) {
    console.log('=====', o.short, '|', o.author, '|', o.created, '|', (o.title || '').slice(0, 80), o.error ? 'ERROR:' + o.error : '');
    console.log((o.body || '').slice(0, 1500));
    console.log('');
  }
  console.log('saved /tmp/sweep-1455-bodies.json');
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
