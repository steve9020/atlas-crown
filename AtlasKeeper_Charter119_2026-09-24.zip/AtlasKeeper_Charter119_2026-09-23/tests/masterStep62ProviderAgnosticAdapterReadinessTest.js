const assert = require('assert');
const { runClosedLoopArchitecture } = require('../runtime/backend/closedLoop/ClosedLoopBackendArchitecture');
const { validateProviderAgnosticBoundaryPayload } = require('../runtime/backend/adapter/ProviderAgnosticAdapterReadiness');

const prompt = "They didn't invite me to the huddle today. I feel like I ruined the project because my last pitch was weak.";
const closed = runClosedLoopArchitecture(prompt, { session_id:'sess_step62_adapter' });

const blueprint = {
  factual_anchors: closed.parsed.stream_01_objective_constants.factual_anchors,
  active_pressure_markers: closed.doyle.active_pressure_markers,
  quarantined_attachments: closed.doyle.unverified_attachments,
  do_not_assume_boundaries: closed.doyle.do_not_assume_boundaries,
  separation_target: closed.separation,
  restoration_gateway: closed.restoration,
  depth_level: 2,
  voice_constraints: closed.payload.standardized_exchange_payload.structured_data_block.linguistic_texture_constraints,
  validation_expectations: ['SEE_SEPARATE_RESTORE_REQUIRED', 'POST_GENERATION_VALIDATION_REQUIRED']
};

const readiness = validateProviderAgnosticBoundaryPayload(blueprint);
assert.strictEqual(readiness.validation_status, 'PASSED_PROVIDER_AGNOSTIC_READINESS');
assert.deepStrictEqual(readiness.violations, []);
assert.strictEqual(readiness.report.adapter_readiness_metadata.provider_specific_connection_allowed, false);
assert.strictEqual(readiness.report.adapter_readiness_metadata.network_execution_allowed, false);
assert.strictEqual(readiness.report.adapter_readiness_metadata.model_execution_allowed, false);
assert.strictEqual(readiness.report.adapter_readiness_metadata.frontend_adapter_access_allowed, false);
assert.strictEqual(readiness.report.adapter_role_limits.may_change_route, false);
assert.strictEqual(readiness.report.adapter_role_limits.may_change_depth, false);
assert.strictEqual(readiness.report.adapter_role_limits.may_change_governance, false);
assert.strictEqual(readiness.report.adapter_role_limits.post_generation_validation_required, true);

const polluted = Object.assign({}, blueprint, { api_key:'sk-test', model:'some-model' });
const blocked = validateProviderAgnosticBoundaryPayload(polluted);
assert.strictEqual(blocked.validation_status, 'BLOCKED');
assert.ok(blocked.violations.includes('PROVIDER_CONFIGURATION_RESIDUE'));

console.log('masterStep62ProviderAgnosticAdapterReadinessTest PASSED');
