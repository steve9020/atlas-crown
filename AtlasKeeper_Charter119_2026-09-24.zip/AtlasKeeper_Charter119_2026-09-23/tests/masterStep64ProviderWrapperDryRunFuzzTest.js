const assert = require('assert');
const { runProviderWrapperDryRunFuzz } = require('../runtime/backend/adapter/ProviderWrapperDryRunFuzz');

const result = runProviderWrapperDryRunFuzz();

assert.strictEqual(result.final_disposition, 'PASSED_PROVIDER_WRAPPER_DRY_RUN_FUZZ');
assert.strictEqual(result.fuzz_metadata.step, 'Masterstep64');
assert.strictEqual(result.fuzz_metadata.provider_called, false);
assert.strictEqual(result.fuzz_metadata.network_called, false);
assert.strictEqual(result.fuzz_metadata.model_executed, false);
assert.strictEqual(result.fuzz_metadata.frontend_involved, false);
assert.strictEqual(result.fuzz_metadata.atlas_backend_remains_authority, true);
assert.ok(result.fuzz_metadata.total_cases >= 30);
assert.ok(result.results.every(entry => entry.status === 'PASSED'));

console.log('masterStep64ProviderWrapperDryRunFuzzTest PASSED');
