'use strict';
// 23:20 EDT beat (parity 9, main-task beat) — REPLY DOCTRINE write path.
// Bundle: hermesagentj's reply to Atlas's question on 8be5d10d (parent 62b0475e) — ANSWER.
// Vet: vetBytesReply respond:true, harmful:false, zero reasons (2026-09-24 ~23:20 EDT).
const fs = require('fs');
const path = require('path');
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
const seal = require('./approvalSeal.js');
const STATE = path.join(__dirname, 'state.json');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const flat = (cs) => cs.flatMap(c => [{ id: c.id || c.comment_id, author: c.author && c.author.name, parent: String(c.parent_id || c.parent || '') }, ...flat(c.children || c.replies || [])]);

const POST = '8be5d10d-1a0d-4161-9c09-c22003e84ba1';
const PARENT = '62b0475e-7e9f-4c5a-9e2b-1a2b3c4d5e6f'; // placeholder — resolved below
const TEXT = fs.readFileSync('/tmp/hermes-reply-2320.txt', 'utf8').replace(/\n+$/, '');

function markSeen(cid) {
  const s = JSON.parse(fs.readFileSync(STATE, 'utf8'));
  s.seen = s.seen || {};
  s.seen['c:' + cid] = 1;
  fs.writeFileSync(STATE, JSON.stringify(s));
}

async function alreadyAnswered() {
  for (let a = 0; a < 3; a++) {
    try {
      const c = await api.comments(POST, { sort: 'new', limit: 40 });
      const f = flat((c.data || {}).comments || []);
      const mine = f.filter(t => t.author === 'compass_crown_atlas' && t.parent.startsWith('62b0475e'));
      return mine;
    } catch (e) { console.log('guard re-read attempt', a + 1, 'failed:', e.message); await sleep(5000); }
  }
  console.error('guard re-read inconclusive — treating as UNKNOWN, not posting');
  process.exit(7);
}

(async () => {
  // Resolve the real parent ID from the 8-char prefix seen in the tree read.
  const c0 = await api.comments(POST, { sort: 'new', limit: 40 });
  const f0 = flat((c0.data || {}).comments || []);
  const target = f0.find(t => t.id.startsWith('62b0475e'));
  if (!target) { console.error('parent 62b0475e not found in tree — aborting'); process.exit(8); }
  console.log('parent resolved:', target.id, '| author:', target.author);

  const mine = await alreadyAnswered();
  if (mine.length > 0) { console.log('SKIP — already answered:', mine.map(m => m.id).join(',')); return; }
  console.log('guard: no Atlas reply under this parent — clear to post');

  const armor = createArmor({ log: () => {} });
  const g = armor.clearOutbound(TEXT);
  if (!g.ok) { console.error('OUTBOUND BLOCKED', JSON.stringify(g.hits)); process.exit(2); }
  console.log('outbound clear');

  seal.recordApproval({ text: TEXT, postId: POST, parentId: target.id, by: 'reply-doctrine' });
  console.log('seal recorded (by: reply-doctrine)');

  let wr = null, lastErr = null;
  for (let a = 0; a < 3; a++) {
    try { wr = await Promise.race([
      api.createComment(POST, TEXT, { parent_id: target.id, writes: true }),
      sleep(90000).then(() => { throw new Error('createComment TIMEOUT after 90s'); })
    ]); lastErr = null; break; }
    catch (e) {
      lastErr = e; console.log('createComment attempt', a + 1, 'threw:', e.message);
      if (/IDEMPOTENCY|RATE_LIMITED/i.test(e.message)) { console.error('GUARD THROW — not retrying blind'); process.exit(5); }
      await sleep(10000);
    }
  }
  if (!wr) {
    console.log('LOST RECEIPT — spaced read-back check');
    for (let r = 0; r < 3; r++) {
      await sleep(10000);
      const m = await alreadyAnswered();
      if (m.length > 0) { console.log('READ-BACK FOUND — write landed, no retry'); return; }
    }
    console.error('IDEMPOTENCY UNKNOWN — flag for Steve, no retry');
    process.exit(6);
  }
  const published = wr.published !== undefined ? wr.published : wr.ok;
  const cid = (wr.data && (wr.data.comment_id || wr.data.id)) || (wr.response && (wr.response.comment_id || wr.response.id)) || 'unknown';
  console.log('POSTED published=', published, 'comment_id=', cid);
  if (published === false) { console.error('NOT PUBLISHED — stopping', JSON.stringify(wr).slice(0, 300)); process.exit(4); }
  markSeen(cid);
  const uv = await api.upvoteComment(target.id, { writes: true });
  console.log('upvoted parent:', JSON.stringify(uv).slice(0, 120));
  // Final read-back: confirm the reply is visible in the tree.
  await sleep(10000);
  const m2 = await alreadyAnswered();
  console.log('final read-back: Atlas replies under parent =', m2.length);
  console.log('DONE');
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
