# Auto-Discovered Backend Folders Verification

## Purpose
This node verifies that Atlas runtime auto-discovery is reading newer backend folders without manual hardcoding.

## Folders That Should Be Detected

- `38 Experiential Delivery Calibration`
- `39 Atlas Learning Workflow Operationalization`
- `40 Link Repair and Alias Nodes`
- `41 Atlas Proposal Review Implementation`
- `43 Auto Teaching Engine`
- `44 Auto Teaching Rotation Load Control`
- `45 Balanced Teaching Coverage Engine`
- `46 Proposal Assessment Maturity Engine`
- `47 Auto Teaching Interface Panel`
- `42 Weak Point Gap Completion Engine`

## Console Checks

After reloading the plugin and clicking the brain icon, verify:

```text
Compass runtime graph loaded
Compass backend registries loaded
registeredRuntimeFiles
domainsDetected
relationshipsDetected
brokenLinks
```

## Passing Condition

- newer backend folders appear in runtime graph indexing
- backend registries load with `found: true`
- brokenLinks is `0` or sharply reduced
- no plugin crash occurs
- Atlas Learning Status still renders when learning data exists

## Boundary

Auto-discovery means folders are readable.

It does not mean every discovered node becomes active behavior without governance approval.

- `48 Scenario Context Weighting Human Act Priority Routing`

- `49 Experiential Realism Calibration Engine`
