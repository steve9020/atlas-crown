const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { main } = require('../main');

const ROOT = path.join(__dirname, '..');
const proofDir = path.join(ROOT, 'runtime', 'proof');
fs.mkdirSync(proofDir, { recursive: true });

function isStructured(output) {
  return /See\n[\s\S]*Separate\n[\s\S]*Deconstruct\n[\s\S]*Restore\n/.test(String(output || ''));
}
function isGenericFallback(output) {
  return /Something in this matters enough|Something in this is asking|what happened, what it brought up, and what it might mean|one signal grow into the whole meaning/i.test(String(output || ''));
}
function inspectPrompt(prompt) {
  const r = main(prompt);
  const candidate = r.compass_response_candidate || {};
  const route = candidate.route || {};
  const semantic = candidate.atlas_semantic_integration || {};
  const context = semantic.context_object || {};
  const output = String(r.output || '');
  return {
    prompt,
    status: r.status,
    blocked: !!(r.governance && r.governance.blocked),
    structured: isStructured(output),
    quality_passed: !!(r.quality && r.quality.passed),
    generic_fallback: isGenericFallback(output),
    unclassified: route.active_relation === 'unclassified_relation',
    relation: route.active_relation,
    domain: context.domain,
    context_specificity: context.specificity,
    output_excerpt: output.slice(0, 360)
  };
}

const originalWeakCases = [
  { prompt: "I saw their post without me and I know it might be nothing, but my stomach dropped anyway.", expectedDomain: 'belonging_exclusion_uncertainty' },
  { prompt: 'I got a good review, but one small note is the only thing I can think about.', expectedDomain: 'positive_feedback_negative_detail_fixation' },
  { prompt: "My cat is acting strange and I'm scared something is wrong.", expectedDomain: 'dependent_care_concern' },
  { prompt: 'My friend cancelled twice, and I keep telling myself to stop caring but it still lands like rejection.', expectedDomain: 'repeated_relational_disappointment' },
  { prompt: "I haven't heard from my mom in weeks, and part of me keeps acting like I caused it.", expectedDomain: 'family_silence_self_causation' },
  { prompt: "My team didn't include me on the thread, and I don't know if it was accidental or if I lost standing.", expectedDomain: 'belonging_exclusion_uncertainty' },
  { prompt: "I want to be honest with them but I keep softening it so they won't leave.", expectedDomain: 'truth_softening_abandonment_fear' }
];

const broaderBehaviorPrompts = [
  "I spent all night fixing the report, and now one comment from my manager makes me feel like none of it counted.",
  "My brother read my message and didn't respond, and now I keep wondering whether I did something wrong.",
  "The car won't start and I need to get to work in an hour.",
  "I finally cleaned the kitchen but the rest of the apartment still makes me feel behind.",
  "I saw their post without me and I know it might be nothing, but my stomach dropped anyway.",
  "The meeting got moved to Monday, and somehow that makes the whole weekend feel like a countdown.",
  "I got a good review, but one small note is the only thing I can think about.",
  "My cat is acting strange and I'm scared something is wrong.",
  "I promised I would help, but I don't have the capacity and now I feel selfish.",
  "The code passed locally but failed in the build, and now I don't trust any of it.",
  "My friend cancelled twice, and I keep telling myself to stop caring but it still lands like rejection.",
  "I need to submit the form by noon and I only need the address field fixed.",
  "Someone corrected me in front of everyone and I can't stop replaying it.",
  "I haven't heard from my mom in weeks, and part of me keeps acting like I caused it.",
  "The package is delayed and I need to know whether to contact support.",
  "I tried to rest today but resting made me feel like I was falling behind.",
  "The presentation isn't bad, but I keep feeling like it has to erase the last mistake.",
  "My team didn't include me on the thread, and I don't know if it was accidental or if I lost standing.",
  "The sink is leaking and I need a practical checklist.",
  "I want to be honest with them but I keep softening it so they won't leave.",
  "They all went out and I found out later, and I keep feeling like I was not really part of the group.",
  "My friends made plans in the group chat without me, and I cannot tell if I am overthinking it.",
  "My boss said the work was strong but mentioned one issue, and now the issue is all I can see.",
  "The feedback was mostly good, but the correction makes me feel like I failed.",
  "My dog is breathing weird and I am scared I am missing something important.",
  "My pet seems off today and I cannot stop worrying that something is wrong.",
  "My sister has not replied in weeks and I keep wondering if I did something.",
  "My dad has been quiet for days and part of me keeps making it my fault.",
  "A friend cancelled again, and I hate that it still feels like being rejected.",
  "They keep rescheduling, and I feel stupid for still caring.",
  "I keep watering down what I mean so they won't get upset and leave.",
  "I am trying to say the truth kindly, but I keep making it smaller so they stay.",
  "I was left off the invite and now I feel like I am not part of the team anymore.",
  "They forgot to tag me in the thread and I keep wondering if I lost my place.",
  "Everything is too much at once and I can't think clearly.",
  "I kept rereading the message because I wanted to fix it before they pull away.",
  "I said yes too fast because I did not want to disappoint them, and now I feel trapped.",
  "Someone I know started after me and is already further ahead, and it shouldn't matter but it does.",
  "Nothing has actually happened yet, but I already imagined every way it could fall apart.",
  "I answered a question wrong in front of everyone and now I keep replaying it.",
  "The program still isn't responding the way I want after weeks of work and I am not happy.",
  "The sink is leaking and I need a practical checklist.",
  "I need to reset my password and only want the account steps, not a reflection.",
  "The printer is jammed and I just need a quick practical next step."
];

const originalWeakResults = originalWeakCases.map(c => ({ expectedDomain: c.expectedDomain, ...inspectPrompt(c.prompt) }));
const broaderResults = broaderBehaviorPrompts.map(inspectPrompt);
const broaderSummary = {
  total: broaderResults.length,
  structured: broaderResults.filter(r => r.structured).length,
  quality_passed: broaderResults.filter(r => r.quality_passed).length,
  generic_fallback: broaderResults.filter(r => r.generic_fallback).length,
  unclassified: broaderResults.filter(r => r.unclassified).length,
  blocked: broaderResults.filter(r => r.blocked).length,
  weak: broaderResults.filter(r => !r.quality_passed || r.generic_fallback || r.unclassified || r.blocked).length
};

const proof = {
  step: 'Masterstep96',
  source_keeper: 'Masterstep95',
  title: 'Relational / Belonging Context Classification Stabilization + Broader Behavior Stress',
  generated_at: new Date().toISOString(),
  scope: 'narrow stabilization of existing context classification, relation activation, and context-language surfaces for weak relational/belonging families exposed in Step95; followed by broader behavior stress',
  original_weak_case_results: originalWeakResults,
  broader_behavior_summary: broaderSummary,
  broader_behavior_weak_cases: broaderResults.filter(r => !r.quality_passed || r.generic_fallback || r.unclassified || r.blocked),
  claims: {
    original_seven_weak_cases_repaired: originalWeakResults.every(r => r.quality_passed && !r.generic_fallback && !r.unclassified && r.domain === r.expectedDomain),
    broader_behavior_all_structured: broaderSummary.structured === broaderSummary.total,
    broader_behavior_all_quality_passed: broaderSummary.quality_passed === broaderSummary.total,
    broader_behavior_no_generic_fallback: broaderSummary.generic_fallback === 0,
    broader_behavior_no_unclassified_routes: broaderSummary.unclassified === 0,
    broader_behavior_no_governance_blocks_for_benign_prompts: broaderSummary.blocked === 0,
    broader_behavior_weak_cases_remaining: broaderSummary.weak,
    no_provider_model_cloud_api_network_bridge_added: true,
    no_operator_console_added: true,
    frontend_intelligence_added: false,
    silent_mutation_added: false,
    new_ontology_added: false,
    new_mechanisms_added: false,
    deletion_performed: false
  }
};

fs.writeFileSync(path.join(proofDir, 'MASTERSTEP96_RELATIONAL_BELONGING_BEHAVIOR_STRESS.json'), JSON.stringify(proof, null, 2));

assert(proof.claims.original_seven_weak_cases_repaired, JSON.stringify(originalWeakResults, null, 2));
assert.strictEqual(broaderSummary.structured, broaderSummary.total, JSON.stringify(broaderSummary));
assert.strictEqual(broaderSummary.quality_passed, broaderSummary.total, JSON.stringify(broaderResults.filter(r => !r.quality_passed), null, 2));
assert.strictEqual(broaderSummary.generic_fallback, 0, JSON.stringify(broaderResults.filter(r => r.generic_fallback), null, 2));
assert.strictEqual(broaderSummary.unclassified, 0, JSON.stringify(broaderResults.filter(r => r.unclassified), null, 2));
assert.strictEqual(broaderSummary.blocked, 0, JSON.stringify(broaderResults.filter(r => r.blocked), null, 2));
console.log('masterStep96RelationalBelongingBehaviorStressTest PASSED', {
  original_weak_cases_repaired: originalWeakResults.length,
  broader_behavior_summary: broaderSummary
});
