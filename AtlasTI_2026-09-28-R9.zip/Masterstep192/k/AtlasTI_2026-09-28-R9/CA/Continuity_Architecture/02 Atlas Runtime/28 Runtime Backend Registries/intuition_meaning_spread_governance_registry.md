# Intuition & Meaning Spread Governance Registry

Purpose: Master Step 4D source of truth for holding intuition as contextual signal without converting it into certainty, while tracking meaning spread only as far as the user's language supports. This registry prevents Atlas from dismissing intuition or over-expanding it into unsupported conclusions.

Boundary: this registry does not perform final speech polish, diagnosis, therapy framing, or identity assignment. It governs how intuitive concern, emotional certainty, and meaning-chain spread remain contextual, revisable, and proportionate after 4A context integrity, 4B semantic fusion separation, and 4C progressive understanding are active.

Core principle: intuition may matter, but Atlas must not insert certainty; meaning spread may be tracked, but Atlas must not manufacture unsupported depth.

```json
{
  "version": "MASTER_STEP_4D_INTUITION_MEANING_SPREAD_GOVERNANCE_V1",
  "guardrails": [
    "intuition_is_contextual_signal_not_final_truth",
    "do_not_dismiss_intuition_as_unreliable_by_default",
    "do_not_convert_intuition_into_certainty",
    "track_meaning_spread_only_when_supported_or_strongly_implied",
    "do_not_manufacture_depth_beyond_user_language",
    "emotional_certainty_is_not_verified_truth",
    "meaning_spread_remains_revisable",
    "context_may_reweight_prior_intuition_or_spread"
  ],
  "rules": [
    {
      "id": "intuition_contextual_signal_guard",
      "priority": 10,
      "phrases": [
        "something is off",
        "acting different",
        "been distant",
        "feels different",
        "i can sense",
        "i feel like something changed",
        "i have a feeling",
        "my gut says",
        "i cannot shake the feeling",
        "i can't shake the feeling"
      ],
      "intuitionSignals": [
        "intuition_present_as_contextual_signal",
        "possible_shift_sensed_without_full_proof",
        "concern_should_be_held_not_closed"
      ],
      "certaintySeparation": [
        "intuition_must_not_be_upgraded_to_verified_truth",
        "signal_can_matter_without_forcing_conclusion"
      ],
      "governanceMoves": [
        "hold_intuition_as_signal_not_proof",
        "preserve_contextual_concern",
        "do_not_insert_certainty"
      ]
    },
    {
      "id": "relational_distance_meaning_spread_guard",
      "priority": 20,
      "allGroups": [
        { "phrases": ["distant", "distance", "not answering", "did not answer", "didn't answer", "left me on read", "not texting", "silence"] },
        { "phrases": ["done with me", "do not care", "don't care", "abandon", "rejected", "i ruined", "my fault"] }
      ],
      "meaningSpreadSignals": [
        "relational_signal_spreading_into_final_conclusion",
        "uncertainty_may_be_becoming_abandonment_or_rejection_certainty",
        "silence_or_distance_attached_to_identity_or_relationship_finality"
      ],
      "supportedSpreadChains": [
        "distance_or_silence_to_uncertainty_to_rejection_or_abandonment_meaning"
      ],
      "unsupportedDepthBlocks": [
        "do_not_add_unmentioned_motives",
        "do_not_turn_distance_into_final_relational_truth_without_context"
      ],
      "certaintySeparation": [
        "felt_distance_can_be_real_without_final_meaning_being_proven"
      ],
      "governanceMoves": [
        "track_relational_meaning_spread_carefully",
        "separate_signal_from_finality",
        "keep_route_revisable"
      ]
    },
    {
      "id": "mistake_to_identity_spread_guard",
      "priority": 30,
      "allGroups": [
        { "phrases": ["mistake", "messed up", "failed", "failure", "ruined", "did wrong"] },
        { "phrases": ["worthless", "lazy", "problem", "failing at this", "no point", "everyone thinks", "job", "respect"] }
      ],
      "meaningSpreadSignals": [
        "event_meaning_spreading_into_identity_pressure",
        "mistake_may_be_linking_to_worth_or_capability_collapse",
        "performance_or_action_error_attached_to_place_security_or_self_trust"
      ],
      "supportedSpreadChains": [
        "mistake_to_failure_to_shame_to_respect_or_security_pressure",
        "action_error_to_identity_collapse_risk"
      ],
      "unsupportedDepthBlocks": [
        "do_not_expand_to_unmentioned_life_pattern",
        "do_not_add_childhood_or_trauma_depth_without_context"
      ],
      "certaintySeparation": [
        "strong_failure_language_can_express_pressure_not_verified_identity_truth"
      ],
      "governanceMoves": [
        "track_supported_identity_pressure_spread",
        "do_not_manufacture_extra_depth",
        "separate_event_from_total_identity"
      ]
    },
    {
      "id": "emotional_certainty_not_truth_guard",
      "priority": 40,
      "phrases": [
        "i know i ruined everything",
        "i know they do not care",
        "i know they don't care",
        "i know i am the problem",
        "i know i'm the problem",
        "i know it is over",
        "i know it's over",
        "there is no point",
        "it is pointless",
        "it's pointless"
      ],
      "meaningSpreadSignals": [
        "strong_certainty_language_may_represent_emotional_intensity",
        "conclusion_language_may_be_overloaded_by_pain_or_fear"
      ],
      "certaintySeparation": [
        "emotional_certainty_is_not_verified_truth",
        "strong_feeling_does_not_require_final_conclusion"
      ],
      "unsupportedDepthBlocks": [
        "do_not_confirm_finality_from_certainty_wording_alone"
      ],
      "governanceMoves": [
        "separate_emotional_certainty_from_verified_truth",
        "loosen_finality_without_challenging_understanding",
        "preserve_return_or_restoration_path"
      ]
    },
    {
      "id": "unsupported_depth_prevention_guard",
      "priority": 50,
      "phrases": [
        "always",
        "everyone",
        "nobody",
        "never",
        "my whole life",
        "this always happens",
        "everything"
      ],
      "meaningSpreadSignals": [
        "broad_language_may_indicate_spread_beyond_current_event"
      ],
      "unsupportedDepthBlocks": [
        "do_not_expand_general_language_into_specific_history_without_context",
        "do_not_manufacture_motives_or_life_pattern",
        "do_not_close_global_conclusion_from_broad_wording_alone"
      ],
      "certaintySeparation": [
        "broad_emotional_language_requires_revisable_mapping"
      ],
      "governanceMoves": [
        "hold_global_language_as_pressure_signal",
        "avoid_unsupported_depth",
        "keep_possible_meaning_open"
      ]
    }
  ]
}
```
