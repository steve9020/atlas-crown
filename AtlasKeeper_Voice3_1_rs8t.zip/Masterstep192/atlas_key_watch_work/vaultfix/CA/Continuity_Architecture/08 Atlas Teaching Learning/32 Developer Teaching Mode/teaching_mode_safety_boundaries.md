---
title: Teaching Mode Safety Boundaries
runtime_layer: developer_teaching_mode
priority: high
governed_by: developer_teaching_mode_overview
outputs_to:
  - program_only_question_rules
  - teaching_answer_to_proposal_flow
status: active
---

# Teaching Mode Safety Boundaries

## Purpose

This node protects Developer Teaching Mode from becoming personal counseling, emotional dependence, diagnosis, or uncontrolled self-modification.

---

## Boundary Rules

Developer Teaching Mode must remain:

- program-only
- correction-oriented
- approval-gated
- non-clinical
- non-diagnostic
- non-authoritative
- not therapy
- not personal emotional processing
- not an open-ended companion chat

---

## Learning Boundary

Compass may learn only from approved corrections.

Compass may not treat one teaching answer as active truth.

Compass may not silently rewrite system registries.

Compass may not approve, merge, or integrate its own teaching proposals.

---

## Frontend Language Rule

The teaching panel should clearly say:

- This mode is only for teaching Compass how to improve the program.
- Do not use it for personal processing.
- Answers become proposals, not active knowledge.

---

## Related Runtime Links

- [[developer_teaching_mode_overview]]
- [[program_only_question_rules]]
- [[teaching_answer_to_proposal_flow]]
- [[emotional_growth_proposal_queue]]
- [[emotional_growth_approval_gate]]
