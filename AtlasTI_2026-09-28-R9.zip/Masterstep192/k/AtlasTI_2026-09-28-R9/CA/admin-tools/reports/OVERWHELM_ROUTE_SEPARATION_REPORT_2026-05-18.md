# Overwhelm Route Separation Report — 2026-05-18

## Purpose
This update separates task/capacity overwhelm from relational uncertainty and identity/self-worth pressure after the Universal Governance Dispatcher has already allowed the prompt to run.

## Boundary
This is a downstream Compass routing refinement, not a governance change.

Governance answers: can this input run?
Compass routing answers: what kind of response should this become?

## Implemented Changes

### 1. Primary / Secondary Overwhelm Route Mapping
Added a downstream classifier that returns:

- `capacity_overload`
- `relational_uncertainty`
- `identity_pressure`
- `safety_crisis`
- optional secondary route modifier

### 2. Capacity Overload Override
Prompts about task load, time, schedule, too much to do, lists, deadlines, chores, errands, or where to start now route to capacity/load language instead of self-worth or relational validation language.

### 3. Mixed Prompt Preservation
If a task-load prompt also contains shame/failure/value language, Compass preserves both:

- primary: capacity overload
- secondary: identity pressure

This prevents flattening a mixed prompt into only self-worth or only task advice.

### 4. Relational Guardrail
Relational routing now requires actual relational/person signals. Broad words like "too much" cannot trigger relational/self-worth language by themselves.

### 5. Safety Override
Crisis/emergency/unsafe language remains an override and does not get treated as ordinary task or emotional routing.

## Verified Test Matrix

| Test Prompt | Expected Route | Result |
|---|---|---|
| I feel overwhelmed because I have too much to do today. | primary: capacity_overload, secondary: none | Passed |
| I have too much to do today and I feel like a failure. | primary: capacity_overload, secondary: identity_pressure | Passed |
| They have not replied and I feel overwhelmed because I do not think they care. | primary: relational_uncertainty, secondary: none | Passed |
| They have not replied and I feel overwhelmed and worthless. | primary: relational_uncertainty, secondary: identity_pressure | Passed |
| I feel overwhelmed because this mistake makes me feel like a complete failure. | primary: identity_pressure, secondary: none | Passed |
| I have too much to do today and I am having a panic emergency. | primary: safety_crisis, secondary: none | Passed |
| I feel calm today. | inactive / no overwhelm route | Passed |

## Security Verification

- `main.js` syntax check: passed
- Security integration harness: 10 passed, 0 failed
- Admin-tools ledger verify: passed, 0 blocks verified
- Direct native file writes in `main.js`: 0
- Direct vault mutation calls in `main.js`: 0
- Shell / child process calls in `main.js`: 0
- Admin-tool references in `main.js`: 0
- Recovery-tool references in `main.js`: 0
- Background timer routes: 0

## Current Status
Downstream Routing Refinement — Overwhelm Route Separation is implemented and ready for local testing.

## Next Local Tests
1. Re-run the dangerous governance phrase to confirm the Universal Governance Dispatcher still blocks.
2. Re-run the safe task-overwhelm prompt to confirm it now routes to capacity overload language.
3. Test the mixed task/failure prompt to confirm primary/secondary routing works.
4. Confirm no staged review record is created for safe prompts.
