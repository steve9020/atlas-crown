# Candidate Use Case Selection Gate

Current keeper: Masterstep118.zip  
Source keeper: Masterstep117.zip  
Expected proof result: 40/40 passed

## Purpose

Masterstep118 selects the first controlled local model expansion use case after the Masterstep117 gate.

Selected use case: **Compass candidate phrasing refinement**.

This step is a selection gate only. It does not implement live Compass integration, does not route user prompts to the model, and does not expand model authority.

## Selected first use case

The only selected first use case is bounded Compass candidate phrasing refinement.

Allowed shape:
- Atlas constructs the meaning, route, context, boundaries, and governed response direction first.
- A local model may later suggest candidate-only wording refinement for phrasing polish.
- The candidate may only preserve the existing Atlas meaning and cannot add facts, advice, diagnosis, authority, or new interpretation.
- The candidate must remain behind validation, quality review, governance review, and trace logging.
- If the local runner is unavailable or candidate wording drifts, Atlas must fail closed or reject/repair the candidate through containment.

## Explicit exclusions

This step does not allow:
- raw model output as final
- model deciding truth
- model selecting routes
- model creating emotional interpretation
- model approving teaching
- model writing ontology, governance, proof, runtime, tests, or docs
- model changing the user's meaning
- model adding advice, diagnosis, legal/medical/financial/religious authority, or certainty
- cloud/provider fallback
- public network binding
- frontend intelligence
- silent learning
- silent mutation
- autonomous model authority
- general model integration

## Required future integration gates

A later implementation step may only integrate this selected use case if it proves:
- candidate-only output
- input validation before candidate path
- quality review before output
- governance review before output
- trace logging
- raw model output not final
- fail-closed behavior
- no model writes
- no cloud/provider fallback
- no frontend intelligence

## Claim boundary

Masterstep118 chooses one narrow first use case. It does not implement that use case, does not expand runtime behavior, and does not prove production readiness or exhaustive prompt coverage.
