---
runtime_layer: atlas_scenario_specific_response_construction
registry_type: scenario_context_objects
status: object_index_ready_for_directed_teaching
object_count: 45
purpose: Define the runtime layer that identifies what kind of human situation is being confessed or described before emotional routing occurs.
governed_by:
  - scenario_specific_response_construction_overview
  - human_act_meaning_chain_registry
  - runtime_execution_permissions_registry
---

# Scenario Context Object Registry

This registry is the container for scenario context objects.

This file now defines the approved **45-object scenario context index**. The objects are named and reserved, but they are not fully taught yet.

The purpose of this layer is to help Atlas understand what kind of human act, relational situation, or internal event is being described before reducing the prompt to an emotion word.

## Runtime Purpose

Atlas should identify the kind of human situation described before reducing the prompt to an emotion word.

The question this registry serves is:

```text
What kind of human act or situation is actually being confessed, described, or carried by the user?
```

## Core Runtime Chain

Scenario context objects should support this chain:

```text
what human act happened
→ what relational expectation was attached
→ what response failed or changed
→ what meaning the user attached to themselves
→ what needs separated
```

## Approved Scenario Context Object Index

These objects are approved as the first full scenario-context layer. They are not detailed teaching entries yet.

```text
1. personal_disclosure
2. emotional_mishandling
3. dismissed_importance
4. public_visibility
5. repair_attempt
6. boundary_expression
7. trust_offer
8. need_for_reassurance
9. relational_inconsistency
10. care_mismatch
11. conflict_after_vulnerability
12. confession_or_admission
13. asking_for_support
14. being_misread
15. effort_not_returned
16. rejection_or_nonselection
17. abandonment_or_withdrawal
18. comparison_or_being_outshined
19. criticism_or_correction
20. failure_or_mistake
21. responsibility_or_accountability_moment
22. forgiveness_or_return_attempt
23. grief_or_ending
24. change_or_transition
25. overwhelm_or_capacity_limit
26. emotional_shutdown_or_numbness
27. self_doubt_after_reaction
28. loyalty_break_or_chosen_elsewhere
29. uncertainty_or_lack_of_closure
30. growth_after_pain
31. exclusion_or_left_out
32. being_used_or_overextended
33. unmet_expectation
34. waiting_or_uncertain_response
35. misunderstood_intention
36. being_judged_or_labeled
37. unfair_blame_or_projection
38. pressure_to_perform_or_prove
39. success_or_progress_discomfort
40. internal_conflict_without_clear_external_trigger
41. moral_conflict_or_values_tension
42. loss_of_control_or_power_shift
43. being_seen_too_clearly_or_not_seen_enough
44. returning_after_avoidance
45. ending_or_detachment_choice
```

## Coverage Boundary

These 45 objects are the main top-level scenario objects for now.

Atlas should not keep expanding the top-level list unless a real operational gap appears. Future depth should mostly be added as subpatterns under these objects.

## Required Future Entry Shape

Each taught scenario object should include:

```text
scenario_object:
human_act:
relational_expectation:
response_failure_or_change:
attached_self_meaning:
what_needs_separated:
reverse_flow_direction:
not_to_confuse_with:
frontend_translation_guidance:
```

## Runtime Boundary

This registry should guide scenario understanding. It should not display backend labels directly in the Compass Reflection.

## Teaching Status

The 45 scenario objects have been indexed and reserved. Detailed teaching has not been added yet.

## Related Runtime Links

- [[human_act_meaning_chain_registry]]
- [[relational_expectation_registry]]
- [[response_failure_or_change_registry]]
- [[attached_self_meaning_from_scenario_registry]]
- [[scenario_separation_guidance_registry]]

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

