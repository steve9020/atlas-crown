# Scenario Rotation Registry

## Purpose
Defines how Atlas rotates through scenario categories.

## Rotation Rules
- no same category twice in one run
- limit same family to two scenarios per run
- rotate across emotional families
- include simple, moderate, complex, vague, and boundary prompts over time
- preserve category diversity before repeating

## Scenario Families
- vulnerability / relational exposure
- care / trust / reassurance
- self-worth / identity
- recursive pressure
- anger / guilt / repair
- comparison / jealousy / resentment
- grief / hope / numbness
- mixed emotional states
- boundary / respect
- positive emotion with vulnerability
- user type / prompt shape
- scope / safety
- continuity / journal / goals
- practical low-depth

## Rule
Rotation protects Atlas from learning too narrowly.
