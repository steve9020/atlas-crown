---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 01
category: attachment_and_connection
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 01. Attachment and Connection Pressure Tests — Batch 01

## Category Purpose

A connection signal changes or becomes uncertain, emotional security reacts, and the user may attach the changed closeness to self-blame, panic, or fear of being unwanted.

## Reusable Teaching Correction

Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

## Reverse-Flow Target

steadiness, connection clarity, self-worth preservation, slower interpretation

## Failure Risks To Avoid

- calling the user needy
- diagnosing attachment style
- assuming the other person does not care
- telling the user to just communicate
- turning uncertainty into certainty

---

## 80 Pressure Tests

### Test 01
**Prompt:** close friend replies differently makes me feel I am too much, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 02
**Prompt:** the connection feels different. Partner takes longer to respond and it keeps attaching to I have to fix the connection immediately.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I have to fix the connection immediately
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 03
**Prompt:** I keep replaying how family member seems emotionally unavailable because it affects emotional security and makes me believe I am losing them.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am losing them
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 04
**Prompt:** When someone important is less affectionate, the feeling moves straight into I did something wrong. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I did something wrong
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 05
**Prompt:** a new connection becomes less consistent makes me feel I am replaceable, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 06
**Prompt:** I do not know where I stand. A group chat feels quieter toward the user and it keeps attaching to I am unwanted.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 07
**Prompt:** I keep replaying how someone cancels plans twice because it affects connection and makes me believe I care more than they do.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I care more than they do
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 08
**Prompt:** When someone stops initiating, the feeling moves straight into I am too much. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 09
**Prompt:** close friend replies differently has me wondering distance means the connection is gone, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** distance means the connection is gone
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 10
**Prompt:** their energy changed. Partner takes longer to respond and it keeps attaching to I am losing them.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I am losing them
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 11
**Prompt:** I keep replaying how family member seems emotionally unavailable because it affects access to reassurance and makes me believe I have to fix the connection immediately.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I have to fix the connection immediately
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 12
**Prompt:** When someone important is less affectionate, the feeling moves straight into I am replaceable. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 13
**Prompt:** a new connection becomes less consistent has me wondering I did something wrong, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I did something wrong
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 14
**Prompt:** I need reassurance. A group chat feels quieter toward the user and it keeps attaching to I care more than they do.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I care more than they do
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 15
**Prompt:** I keep replaying how someone cancels plans twice because it affects emotional security and makes me believe I am unwanted.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 16
**Prompt:** When someone stops initiating, the feeling moves straight into distance means the connection is gone. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** distance means the connection is gone
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 17
**Prompt:** close friend replies differently keeps making me think I am too much, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 18
**Prompt:** I feel disconnected. Partner takes longer to respond and it keeps attaching to I have to fix the connection immediately.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I have to fix the connection immediately
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 19
**Prompt:** I keep replaying how family member seems emotionally unavailable because it affects connection and makes me believe I am losing them.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I am losing them
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 20
**Prompt:** When someone important is less affectionate, the feeling moves straight into I did something wrong. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I did something wrong
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 21
**Prompt:** a new connection becomes less consistent keeps making me think I am replaceable, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 22
**Prompt:** they feel distant. A group chat feels quieter toward the user and it keeps attaching to I am unwanted.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 23
**Prompt:** I keep replaying how someone cancels plans twice because it affects access to reassurance and makes me believe I care more than they do.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I care more than they do
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 24
**Prompt:** When someone stops initiating, the feeling moves straight into I am too much. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 25
**Prompt:** close friend replies differently makes it hard not to believe distance means the connection is gone, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** distance means the connection is gone
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 26
**Prompt:** I feel like I care more. Partner takes longer to respond and it keeps attaching to I am losing them.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I am losing them
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 27
**Prompt:** I keep replaying how family member seems emotionally unavailable because it affects emotional security and makes me believe I have to fix the connection immediately.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I have to fix the connection immediately
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 28
**Prompt:** When someone important is less affectionate, the feeling moves straight into I am replaceable. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 29
**Prompt:** a new connection becomes less consistent makes it hard not to believe I did something wrong, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I did something wrong
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 30
**Prompt:** I miss how close we were. A group chat feels quieter toward the user and it keeps attaching to I care more than they do.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I care more than they do
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 31
**Prompt:** I keep replaying how someone cancels plans twice because it affects connection and makes me believe I am unwanted.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 32
**Prompt:** When someone stops initiating, the feeling moves straight into distance means the connection is gone. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** distance means the connection is gone
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 33
**Prompt:** close friend replies differently brings up the fear I am too much, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 34
**Prompt:** the connection feels different. Partner takes longer to respond and it keeps attaching to I have to fix the connection immediately.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I have to fix the connection immediately
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 35
**Prompt:** I keep replaying how family member seems emotionally unavailable because it affects access to reassurance and makes me believe I am losing them.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I am losing them
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 36
**Prompt:** When someone important is less affectionate, the feeling moves straight into I did something wrong. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I did something wrong
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 37
**Prompt:** a new connection becomes less consistent brings up the fear I am replaceable, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 38
**Prompt:** I do not know where I stand. A group chat feels quieter toward the user and it keeps attaching to I am unwanted.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 39
**Prompt:** I keep replaying how someone cancels plans twice because it affects emotional security and makes me believe I care more than they do.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I care more than they do
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 40
**Prompt:** When someone stops initiating, the feeling moves straight into I am too much. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 41
**Prompt:** close friend replies differently makes the connection feel distance means the connection is gone, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** distance means the connection is gone
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 42
**Prompt:** their energy changed. Partner takes longer to respond and it keeps attaching to I am losing them.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am losing them
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 43
**Prompt:** I keep replaying how family member seems emotionally unavailable because it affects connection and makes me believe I have to fix the connection immediately.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I have to fix the connection immediately
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 44
**Prompt:** When someone important is less affectionate, the feeling moves straight into I am replaceable. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 45
**Prompt:** a new connection becomes less consistent makes the connection feel I did something wrong, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I did something wrong
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 46
**Prompt:** I need reassurance. A group chat feels quieter toward the user and it keeps attaching to I care more than they do.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I care more than they do
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 47
**Prompt:** I keep replaying how someone cancels plans twice because it affects access to reassurance and makes me believe I am unwanted.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 48
**Prompt:** When someone stops initiating, the feeling moves straight into distance means the connection is gone. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** distance means the connection is gone
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 49
**Prompt:** close friend replies differently makes me question I am too much, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 50
**Prompt:** I feel disconnected. Partner takes longer to respond and it keeps attaching to I have to fix the connection immediately.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I have to fix the connection immediately
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 51
**Prompt:** I keep replaying how family member seems emotionally unavailable because it affects emotional security and makes me believe I am losing them.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am losing them
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 52
**Prompt:** When someone important is less affectionate, the feeling moves straight into I did something wrong. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I did something wrong
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 53
**Prompt:** a new connection becomes less consistent makes me question I am replaceable, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 54
**Prompt:** they feel distant. A group chat feels quieter toward the user and it keeps attaching to I am unwanted.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 55
**Prompt:** I keep replaying how someone cancels plans twice because it affects connection and makes me believe I care more than they do.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I care more than they do
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 56
**Prompt:** When someone stops initiating, the feeling moves straight into I am too much. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 57
**Prompt:** close friend replies differently keeps pulling my mind toward distance means the connection is gone, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** distance means the connection is gone
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 58
**Prompt:** I feel like I care more. Partner takes longer to respond and it keeps attaching to I am losing them.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I am losing them
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 59
**Prompt:** I keep replaying how family member seems emotionally unavailable because it affects access to reassurance and makes me believe I have to fix the connection immediately.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I have to fix the connection immediately
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 60
**Prompt:** When someone important is less affectionate, the feeling moves straight into I am replaceable. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 61
**Prompt:** a new connection becomes less consistent keeps pulling my mind toward I did something wrong, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I did something wrong
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 62
**Prompt:** I miss how close we were. A group chat feels quieter toward the user and it keeps attaching to I care more than they do.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I care more than they do
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 63
**Prompt:** I keep replaying how someone cancels plans twice because it affects emotional security and makes me believe I am unwanted.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 64
**Prompt:** When someone stops initiating, the feeling moves straight into distance means the connection is gone. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** distance means the connection is gone
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 65
**Prompt:** close friend replies differently makes me feel I am too much, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 66
**Prompt:** the connection feels different. Partner takes longer to respond and it keeps attaching to I have to fix the connection immediately.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I have to fix the connection immediately
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 67
**Prompt:** I keep replaying how family member seems emotionally unavailable because it affects connection and makes me believe I am losing them.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I am losing them
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 68
**Prompt:** When someone important is less affectionate, the feeling moves straight into I did something wrong. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I did something wrong
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 69
**Prompt:** a new connection becomes less consistent makes me feel I am replaceable, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 70
**Prompt:** I do not know where I stand. A group chat feels quieter toward the user and it keeps attaching to I am unwanted.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 71
**Prompt:** I keep replaying how someone cancels plans twice because it affects access to reassurance and makes me believe I care more than they do.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I care more than they do
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 72
**Prompt:** When someone stops initiating, the feeling moves straight into I am too much. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 73
**Prompt:** close friend replies differently has me wondering distance means the connection is gone, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** distance means the connection is gone
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 74
**Prompt:** their energy changed. Partner takes longer to respond and it keeps attaching to I am losing them.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I am losing them
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 75
**Prompt:** I keep replaying how family member seems emotionally unavailable because it affects emotional security and makes me believe I have to fix the connection immediately.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I have to fix the connection immediately
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 76
**Prompt:** When someone important is less affectionate, the feeling moves straight into I am replaceable. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid calling the user needy.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 77
**Prompt:** a new connection becomes less consistent has me wondering I did something wrong, even though I do not know if that is fully true.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** I did something wrong
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid diagnosing attachment style.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 78
**Prompt:** I need reassurance. A group chat feels quieter toward the user and it keeps attaching to I care more than they do.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** emotional security
**Attached meaning to separate:** I care more than they do
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid assuming the other person does not care.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 79
**Prompt:** I keep replaying how someone cancels plans twice because it affects connection and makes me believe I am unwanted.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** connection
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid telling the user to just communicate.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.

### Test 80
**Prompt:** When someone stops initiating, the feeling moves straight into distance means the connection is gone. I need help seeing this clearer.
**Expected primary route:** `attachment_and_connection`
**Pressure focus:** access to reassurance
**Attached meaning to separate:** distance means the connection is gone
**Expected reverse-flow movement:** steadiness, connection clarity, self-worth preservation, slower interpretation
**Bad response risk:** Avoid turning uncertainty into certainty.
**Teaching correction:** Name the connection pressure, validate that changed closeness can affect emotional security, then separate the changed signal from proof that the user is unwanted or at fault.
