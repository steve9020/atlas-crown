const assert = require('assert');
const { runLiveRelationActivationGauge } = require('../runtime/routing/LiveRelationActivationGauge');
const gauge = runLiveRelationActivationGauge();
assert.ok(gauge.passed, 'live relation activation gauge failed: ' + JSON.stringify(gauge.failures, null, 2));
assert.ok(gauge.average >= 10, 'average activation score below threshold: ' + gauge.average);
for (const r of gauge.results) {
  assert.ok(r.score >= 10, `${r.id} scored below 10/12: ${r.score}`);
  assert.ok(r.relation === r.expected_relation, `${r.id} wrong relation: ${r.relation}`);
  assert.ok(!/Something in this is asking to be sorted carefully/i.test(r.response), `${r.id} leaked generic fallback`);
}
console.log('masterStep54LiveRelationActivationGaugeRepairTest PASSED');
