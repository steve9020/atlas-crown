const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function exists(rel){ return fs.existsSync(path.join(root, rel)); }
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const hist = json('runtime/proof/HISTORICAL_KEEPER_INDEX.json');
assert(hist.mode === 'historical_integrity_not_current_state', 'historical keeper index mode mismatch');
const required = ['masterstep07','masterstep08','masterstep09','masterstep10','masterstep11','masterstep12','masterstep12_patch01','masterstep12_patch02','masterstep12_patch03','masterstep12_patch04'];
for (const key of required) {
  assert(hist.records[key], `missing historical record ${key}`);
  assert(hist.records[key].package && hist.records[key].objective, `incomplete historical record ${key}`);
}
const vs = json('tests/VERSION_STATUS.json');
assert(vs.prior_keeper_history.masterstep12_patch05_pass1, 'pass1 historical record missing after closure');
assert(vs.prior_keeper_history.masterstep12_patch05_pass1.status === 'master_step_12_patch05_pass1_staged_not_closed', 'pass1 historical status missing');
assert(vs.active_keeper === 'Masterstep12_patch05.zip', 'active keeper should be patch05 after closure');
for (const key of required) {
  assert(vs.prior_keeper_history[key], `VERSION_STATUS missing prior history ${key}`);
  assert(vs.prior_keeper_history[key].snapshot === hist.records[key].package, `prior history snapshot mismatch for ${key}`);
}
const proofState = json('runtime/proof/PROOF_STATE.json');
assert(proofState.historical_keeper_tests_reconciled === true, 'proof state missing historical reconciliation flag');
assert(proofState.current_state_tests_isolated_to_active_package === true, 'current-state isolation flag missing');
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md');
assert(summary.includes('Current keeper: `Masterstep12_patch05.zip`'), 'summary missing current keeper after closure');
assert(summary.includes('Historical keeper tests operate in historical-integrity mode'), 'summary missing historical reconciliation closure statement');
assert(exists('CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_12J_PATCH05_PASS1_NO_HIDDEN_INPUT_HISTORICAL_RECONCILIATION.md'), 'pass1 proof doc missing');
console.log('masterStep12Patch05Pass1HistoricalTestReconciliationTest PASSED');
