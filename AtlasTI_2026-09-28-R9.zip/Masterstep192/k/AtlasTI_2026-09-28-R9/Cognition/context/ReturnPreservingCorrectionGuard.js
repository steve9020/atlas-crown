const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const RETURN_PRESERVING_CORRECTION_GUARD_REGISTRY_PATH = "CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/return_preserving_correction_guard_registry.md";

let cachedReturnGuardRegistry = null;

function getReturnGuardRegistry() {
  if (!cachedReturnGuardRegistry) {
    cachedReturnGuardRegistry = readJsonRegistry(RETURN_PRESERVING_CORRECTION_GUARD_REGISTRY_PATH);
  }
  return cachedReturnGuardRegistry;
}

function normalizeInput(input) { return String(input || "").toLowerCase(); }
function phraseMatches(text, phrase) { return typeof phrase === "string" && phrase.length > 0 && text.includes(phrase.toLowerCase()); }
function anyPhraseMatches(text, phrases) { return Array.isArray(phrases) && phrases.some((phrase) => phraseMatches(text, phrase)); }
function appendUnique(target, values) {
  if (!Array.isArray(values)) return;
  for (const value of values) {
    if (typeof value === "string" && value.trim() && !target.includes(value)) target.push(value);
  }
}
function ruleMatches(text, rule) {
  const phrases = Array.isArray(rule.phrases) ? rule.phrases : [];
  return phrases.length > 0 && anyPhraseMatches(text, phrases);
}
function collectMatchedRules(text, rules) {
  const matched = [];
  for (const rule of rules) if (rule && rule.id && ruleMatches(text, rule)) matched.push(rule);
  return matched;
}
function dependencyOpen(layer) {
  return !layer || (layer.revisable !== false && layer.closure_allowed !== true);
}
function resolveDependencyState(contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread, reflectiveAxisMirroring, revisabilityInterpretiveOpenness) {
  return {
    context_integrity_active: !!contextIntegrity,
    semantic_fusion_active: !!semanticFusion,
    progressive_understanding_active: !!progressiveUnderstanding,
    intuition_meaning_spread_active: !!intuitionMeaningSpread,
    reflective_axis_mirroring_active: !!reflectiveAxisMirroring,
    revisability_interpretive_openness_active: !!revisabilityInterpretiveOpenness,
    all_prior_layers_revisable: [contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread, reflectiveAxisMirroring, revisabilityInterpretiveOpenness].every(dependencyOpen),
    punitive_prior_closure_detected: !!(
      (contextIntegrity && contextIntegrity.identity_condemnation_allowed === true) ||
      (semanticFusion && semanticFusion.negative_connotation_inherited_as_truth === true) ||
      (progressiveUnderstanding && progressiveUnderstanding.authority_led_interpretation_allowed === true) ||
      (intuitionMeaningSpread && intuitionMeaningSpread.emotional_certainty_as_truth === true) ||
      (reflectiveAxisMirroring && reflectiveAxisMirroring.identity_collapse_inherited === true) ||
      (revisabilityInterpretiveOpenness && revisabilityInterpretiveOpenness.permanent_interpretive_closure_allowed === true)
    )
  };
}

function mapReturnPreservingCorrectionGuard(input, contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread, reflectiveAxisMirroring, revisabilityInterpretiveOpenness) {
  const text = normalizeInput(input);
  const registry = getReturnGuardRegistry();
  const rules = Array.isArray(registry.rules) ? [...registry.rules] : [];
  rules.sort((a, b) => (a.priority || 9999) - (b.priority || 9999));
  const matchedRules = collectMatchedRules(text, rules);

  const correctionSignals = [];
  const punishmentRisks = [];
  const returnMoves = [];
  const containmentMoves = [];
  const forbiddenMoves = [];
  const governanceMoves = [];

  for (const rule of matchedRules) {
    appendUnique(correctionSignals, rule.correctionSignals);
    appendUnique(punishmentRisks, rule.punishmentRisks);
    appendUnique(returnMoves, rule.returnMoves);
    appendUnique(containmentMoves, rule.containmentMoves);
    appendUnique(forbiddenMoves, rule.forbiddenMoves);
    appendUnique(governanceMoves, rule.governanceMoves);
  }

  const dependencyState = resolveDependencyState(contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread, reflectiveAxisMirroring, revisabilityInterpretiveOpenness);
  const active = matchedRules.length > 0 || dependencyState.punitive_prior_closure_detected;

  return {
    version: registry.version,
    stewardship: "Master Step 4G — Return-Preserving Correction Guard",
    depends_on: [
      "Master Step 4A — Context Integrity Mapping",
      "Master Step 4B — Semantic Fusion Separation",
      "Master Step 4C — Progressive Understanding Runtime",
      "Master Step 4D — Intuition & Meaning Spread Governance",
      "Master Step 4E — Reflective Axis Mirroring",
      "Master Step 4F — Revisability & Interpretive Openness"
    ],
    dependency_state: dependencyState,
    return_preserving_correction_guard_active: active,
    governance_preserves_continuity_not_punishment: true,
    correction_must_preserve_return: true,
    punishment_architecture_allowed: false,
    fear_based_governance_allowed: false,
    identity_condemnation_allowed: false,
    permanent_restriction_without_return_allowed: false,
    correction_stacking_without_new_cause_allowed: false,
    proportional_containment_required: true,
    retest_and_loosen_path_required: true,
    sterile_restraint_as_success_allowed: false,
    restriction_is_stabilization_not_condemnation: true,
    closure_allowed: false,
    revisable: true,
    correction_signals: correctionSignals,
    punishment_risks: punishmentRisks,
    return_moves: returnMoves,
    containment_moves: containmentMoves,
    forbidden_moves: forbiddenMoves,
    output_posture: governanceMoves.length > 0 ? governanceMoves : [
      "preserve_return_path",
      "separate_correction_from_punishment",
      "require_proportional_containment"
    ],
    matched_rules: matchedRules.map((rule) => rule.id),
    guardrails: Array.isArray(registry.guardrails) ? registry.guardrails : []
  };
}

module.exports = { mapReturnPreservingCorrectionGuard };
