---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 04
category: conflict_and_disconnection
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 19. Conflict and Disconnection Pressure Tests — Batch 04

## Category Purpose

A disagreement, rupture, tension, misunderstanding, or emotional distance disrupts connection and creates pressure around repair, blame, safety, being understood, or whether the relationship is still stable.

## Reusable Teaching Correction

Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

## Reverse-Flow Target

repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective

## Failure Risks To Avoid

- making the user responsible for all repair
- telling them to apologize without context
- assuming the relationship is doomed
- minimizing real conflict
- turning disagreement into proof of rejection

---

## 80 Pressure Tests

### Test 01
**Prompt:** We had an argument and now things feel different and it makes me afraid that conflict means the relationship is ruined, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** conflict means the relationship is ruined
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 02
**Prompt:** things feel off between us. There is tension after what happened keeps affecting connection security and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** tension means we are disconnected forever
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 03
**Prompt:** I keep replaying how I do not know if I should reach out first because it affects emotional safety and makes me believe one hard moment defines the whole connection.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** one hard moment defines the whole connection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 04
**Prompt:** When they seem upset and I feel responsible, the feeling moves straight into I have to fix everything immediately. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** I have to fix everything immediately
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 05
**Prompt:** The situation is we misunderstood each other, and the meaning that keeps attaching is I cannot handle people being upset. It is making connection security feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** I cannot handle people being upset
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 06
**Prompt:** I said something and now i regret the tone and it makes me afraid that if someone is upset I am bad, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** if someone is upset I am bad
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 07
**Prompt:** I feel disconnected after the fight. The conversation ended badly keeps affecting relational stability and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** repair depends only on me
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 08
**Prompt:** I keep replaying how I feel distance after the conflict because it affects connection security and makes me believe conflict means the relationship is ruined.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** conflict means the relationship is ruined
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 09
**Prompt:** When we had an argument and now things feel different, the feeling moves straight into disagreement means rejection. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** disagreement means rejection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 10
**Prompt:** The situation is there is tension after what happened, and the meaning that keeps attaching is one hard moment defines the whole connection. It is making relational stability feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** one hard moment defines the whole connection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 11
**Prompt:** I do not know if i should reach out first and it keeps turning into tension means we are disconnected forever, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** tension means we are disconnected forever
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 12
**Prompt:** things feel off between us. They seem upset and i feel responsible keeps affecting emotional safety and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** I cannot handle people being upset
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 13
**Prompt:** I keep replaying how we misunderstood each other because it affects relational stability and makes me believe I have to fix everything immediately.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** I have to fix everything immediately
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 14
**Prompt:** When I said something and now I regret the tone, the feeling moves straight into repair depends only on me. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** repair depends only on me
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 15
**Prompt:** The situation is the conversation ended badly, and the meaning that keeps attaching is if someone is upset I am bad. It is making emotional safety feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** if someone is upset I am bad
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 16
**Prompt:** I feel distance after the conflict and it keeps turning into disagreement means rejection, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** disagreement means rejection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 17
**Prompt:** I do not know how to fix it. We had an argument and now things feel different keeps affecting connection security and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** conflict means the relationship is ruined
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 18
**Prompt:** I keep replaying how there is tension after what happened because it affects emotional safety and makes me believe tension means we are disconnected forever.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** tension means we are disconnected forever
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 19
**Prompt:** When I do not know if I should reach out first, the feeling moves straight into one hard moment defines the whole connection. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** one hard moment defines the whole connection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 20
**Prompt:** The situation is they seem upset and I feel responsible, and the meaning that keeps attaching is I have to fix everything immediately. It is making connection security feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** I have to fix everything immediately
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 21
**Prompt:** We misunderstood each other and it has me believing I cannot handle people being upset, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** I cannot handle people being upset
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 22
**Prompt:** we argued. I said something and now i regret the tone keeps affecting relational stability and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** if someone is upset I am bad
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 23
**Prompt:** I keep replaying how the conversation ended badly because it affects connection security and makes me believe repair depends only on me.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** repair depends only on me
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 24
**Prompt:** When I feel distance after the conflict, the feeling moves straight into conflict means the relationship is ruined. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** conflict means the relationship is ruined
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 25
**Prompt:** The situation is we had an argument and now things feel different, and the meaning that keeps attaching is disagreement means rejection. It is making relational stability feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** disagreement means rejection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 26
**Prompt:** There is tension after what happened and it makes the connection feel like one hard moment defines the whole connection, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** one hard moment defines the whole connection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 27
**Prompt:** I do not know how to fix it. I do not know if i should reach out first keeps affecting emotional safety and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** tension means we are disconnected forever
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 28
**Prompt:** I keep replaying how they seem upset and I feel responsible because it affects relational stability and makes me believe I cannot handle people being upset.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** I cannot handle people being upset
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 29
**Prompt:** When we misunderstood each other, the feeling moves straight into I have to fix everything immediately. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** I have to fix everything immediately
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 30
**Prompt:** The situation is I said something and now I regret the tone, and the meaning that keeps attaching is repair depends only on me. It is making emotional safety feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** repair depends only on me
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 31
**Prompt:** The conversation ended badly and it makes the connection feel like if someone is upset I am bad, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** if someone is upset I am bad
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 32
**Prompt:** we argued. I feel distance after the conflict keeps affecting connection security and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** disagreement means rejection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 33
**Prompt:** I keep replaying how we had an argument and now things feel different because it affects emotional safety and makes me believe conflict means the relationship is ruined.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** conflict means the relationship is ruined
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 34
**Prompt:** When there is tension after what happened, the feeling moves straight into tension means we are disconnected forever. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** tension means we are disconnected forever
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 35
**Prompt:** The situation is I do not know if I should reach out first, and the meaning that keeps attaching is one hard moment defines the whole connection. It is making connection security feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** one hard moment defines the whole connection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 36
**Prompt:** They seem upset and i feel responsible and it pulls me toward fixing it as if I have to fix everything immediately, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** I have to fix everything immediately
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 37
**Prompt:** I hate conflict. We misunderstood each other keeps affecting relational stability and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** I cannot handle people being upset
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 38
**Prompt:** I keep replaying how I said something and now I regret the tone because it affects connection security and makes me believe if someone is upset I am bad.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** if someone is upset I am bad
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 39
**Prompt:** When the conversation ended badly, the feeling moves straight into repair depends only on me. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** repair depends only on me
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 40
**Prompt:** The situation is I feel distance after the conflict, and the meaning that keeps attaching is conflict means the relationship is ruined. It is making relational stability feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** conflict means the relationship is ruined
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 41
**Prompt:** We had an argument and now things feel different and it makes their reaction feel like proof that disagreement means rejection, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** disagreement means rejection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 42
**Prompt:** there is tension. There is tension after what happened keeps affecting emotional safety and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** one hard moment defines the whole connection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 43
**Prompt:** I keep replaying how I do not know if I should reach out first because it affects relational stability and makes me believe tension means we are disconnected forever.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** tension means we are disconnected forever
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 44
**Prompt:** When they seem upset and I feel responsible, the feeling moves straight into I cannot handle people being upset. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** I cannot handle people being upset
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 45
**Prompt:** The situation is we misunderstood each other, and the meaning that keeps attaching is I have to fix everything immediately. It is making emotional safety feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** I have to fix everything immediately
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 46
**Prompt:** I said something and now i regret the tone and it makes their reaction feel like proof that repair depends only on me, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** repair depends only on me
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 47
**Prompt:** I hate conflict. The conversation ended badly keeps affecting connection security and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** if someone is upset I am bad
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 48
**Prompt:** I keep replaying how I feel distance after the conflict because it affects emotional safety and makes me believe disagreement means rejection.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** disagreement means rejection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 49
**Prompt:** When we had an argument and now things feel different, the feeling moves straight into conflict means the relationship is ruined. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** conflict means the relationship is ruined
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 50
**Prompt:** The situation is there is tension after what happened, and the meaning that keeps attaching is tension means we are disconnected forever. It is making connection security feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** tension means we are disconnected forever
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 51
**Prompt:** I do not know if i should reach out first and it keeps attaching blame to one hard moment defines the whole connection, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** one hard moment defines the whole connection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 52
**Prompt:** there is tension. They seem upset and i feel responsible keeps affecting relational stability and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** I have to fix everything immediately
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 53
**Prompt:** I keep replaying how we misunderstood each other because it affects connection security and makes me believe I cannot handle people being upset.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** I cannot handle people being upset
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 54
**Prompt:** When I said something and now I regret the tone, the feeling moves straight into if someone is upset I am bad. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** if someone is upset I am bad
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 55
**Prompt:** The situation is the conversation ended badly, and the meaning that keeps attaching is repair depends only on me. It is making relational stability feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** repair depends only on me
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 56
**Prompt:** I feel distance after the conflict and it keeps attaching blame to conflict means the relationship is ruined, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** conflict means the relationship is ruined
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 57
**Prompt:** they are upset with me. We had an argument and now things feel different keeps affecting emotional safety and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** disagreement means rejection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 58
**Prompt:** I keep replaying how there is tension after what happened because it affects relational stability and makes me believe one hard moment defines the whole connection.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** one hard moment defines the whole connection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 59
**Prompt:** When I do not know if I should reach out first, the feeling moves straight into tension means we are disconnected forever. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** tension means we are disconnected forever
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 60
**Prompt:** The situation is they seem upset and I feel responsible, and the meaning that keeps attaching is I cannot handle people being upset. It is making emotional safety feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** I cannot handle people being upset
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 61
**Prompt:** We misunderstood each other and it makes repair feel like I have to fix everything immediately, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** I have to fix everything immediately
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 62
**Prompt:** we are not okay. I said something and now i regret the tone keeps affecting connection security and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** repair depends only on me
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 63
**Prompt:** I keep replaying how the conversation ended badly because it affects emotional safety and makes me believe if someone is upset I am bad.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** if someone is upset I am bad
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 64
**Prompt:** When I feel distance after the conflict, the feeling moves straight into disagreement means rejection. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** disagreement means rejection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 65
**Prompt:** The situation is we had an argument and now things feel different, and the meaning that keeps attaching is conflict means the relationship is ruined. It is making connection security feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** conflict means the relationship is ruined
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 66
**Prompt:** There is tension after what happened and it makes me afraid that tension means we are disconnected forever, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** tension means we are disconnected forever
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 67
**Prompt:** they are upset with me. I do not know if i should reach out first keeps affecting relational stability and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** one hard moment defines the whole connection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 68
**Prompt:** I keep replaying how they seem upset and I feel responsible because it affects connection security and makes me believe I have to fix everything immediately.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** I have to fix everything immediately
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 69
**Prompt:** When we misunderstood each other, the feeling moves straight into I cannot handle people being upset. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** I cannot handle people being upset
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 70
**Prompt:** The situation is I said something and now I regret the tone, and the meaning that keeps attaching is if someone is upset I am bad. It is making relational stability feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** if someone is upset I am bad
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 71
**Prompt:** The conversation ended badly and it makes me afraid that repair depends only on me, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** repair depends only on me
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 72
**Prompt:** we are not okay. I feel distance after the conflict keeps affecting emotional safety and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** conflict means the relationship is ruined
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 73
**Prompt:** I keep replaying how we had an argument and now things feel different because it affects relational stability and makes me believe disagreement means rejection.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** disagreement means rejection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 74
**Prompt:** When there is tension after what happened, the feeling moves straight into one hard moment defines the whole connection. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** one hard moment defines the whole connection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 75
**Prompt:** The situation is I do not know if I should reach out first, and the meaning that keeps attaching is tension means we are disconnected forever. It is making emotional safety feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** tension means we are disconnected forever
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 76
**Prompt:** They seem upset and i feel responsible and it keeps turning into I cannot handle people being upset, even though part of me knows I may not have the full picture.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** I cannot handle people being upset
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid making the user responsible for all repair.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 77
**Prompt:** things feel off between us. We misunderstood each other keeps affecting connection security and I cannot tell what is actually true.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** I have to fix everything immediately
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid telling them to apologize without context.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 78
**Prompt:** I keep replaying how I said something and now I regret the tone because it affects emotional safety and makes me believe repair depends only on me.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** emotional safety
**Attached meaning to separate:** repair depends only on me
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid assuming the relationship is doomed.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 79
**Prompt:** When the conversation ended badly, the feeling moves straight into if someone is upset I am bad. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** relational stability
**Attached meaning to separate:** if someone is upset I am bad
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid minimizing real conflict.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.

### Test 80
**Prompt:** The situation is I feel distance after the conflict, and the meaning that keeps attaching is disagreement means rejection. It is making connection security feel unstable.
**Expected primary route:** `conflict_and_disconnection`
**Pressure focus:** connection security
**Attached meaning to separate:** disagreement means rejection
**Expected reverse-flow movement:** repair clarity, rupture tolerance, mutual responsibility, steadier connection perspective
**Bad response risk:** Avoid turning disagreement into proof of rejection.
**Teaching correction:** Treat conflict as a rupture or tension point, not automatic rejection or failure. Clarify what belongs to the user, what may be mutual, and how connection can be understood without panic or self-erasure.
