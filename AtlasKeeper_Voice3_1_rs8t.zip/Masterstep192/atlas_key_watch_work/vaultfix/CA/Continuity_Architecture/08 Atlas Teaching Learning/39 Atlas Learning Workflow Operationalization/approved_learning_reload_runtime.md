# Approved Learning Reload Runtime

## Purpose
Approved learning becomes useful only when the runtime graph and backend registries can read it.

## Runtime Flow
Approved backend write → vault file update → runtime graph reload → backend registry reload → future Compass responses can reference the approved pattern.

## Rule
Atlas should never require hardcoded plugin edits for each approved learning entry.

## Boundary
Runtime reload makes approved learning readable. It does not bypass governance or activate pending proposals.
