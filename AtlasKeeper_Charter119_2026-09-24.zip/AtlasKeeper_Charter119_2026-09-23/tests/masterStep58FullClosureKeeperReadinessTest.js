const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const required = [
  'runtime/backend/closedLoop/DoyleSpireRelationalLookup.js',
  'runtime/backend/closedLoop/SeparationTargetSelector.js',
  'runtime/backend/closedLoop/RestorationGatewaySelector.js',
  'runtime/proof/MASTERSTEP58_DOYLE_SEPARATION_RESTORATION_ALIGNMENT.md',
  'runtime/proof/MASTERSTEP58_TEST_RESULTS.md',
  'docs/MASTERSTEP58_DOYLE_SEPARATION_RESTORATION_MATRIX_MAP.md'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(root, rel)), `missing ${rel}`);
const frontendDir = path.join(root, 'atlas_key_watch_work', 'vaultfix', 'CA', 'Continuity_Architecture', '.obsidian', 'plugins', 'continuity-interface');
if (fs.existsSync(frontendDir)) {
  const frontendFiles = fs.readdirSync(frontendDir).filter(f => f.endsWith('.js'));
  for (const file of frontendFiles) {
    const text = fs.readFileSync(path.join(frontendDir, file), 'utf8').toLowerCase();
    assert.ok(!text.includes('doylespire'), 'frontend must not contain Doyle logic');
    assert.ok(!text.includes('separationtarget'), 'frontend must not contain separation selector logic');
    assert.ok(!text.includes('restorationgateway'), 'frontend must not contain restoration selector logic');
  }
}
console.log('masterStep58FullClosureKeeperReadinessTest PASSED');
