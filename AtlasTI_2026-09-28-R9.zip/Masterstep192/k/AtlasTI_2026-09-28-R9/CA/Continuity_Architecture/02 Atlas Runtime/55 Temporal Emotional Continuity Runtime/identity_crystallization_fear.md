# Identity Crystallization Fear

## Purpose
Recognizes fear that emotional weight may harden into identity.

## Examples
- I don't want this to make me cold.
- I don't want this to make me guarded.
- I don't want this to become who I am.
- I don't want this to harden me.

## Runtime Direction
Separate temporary protection from permanent identity.
