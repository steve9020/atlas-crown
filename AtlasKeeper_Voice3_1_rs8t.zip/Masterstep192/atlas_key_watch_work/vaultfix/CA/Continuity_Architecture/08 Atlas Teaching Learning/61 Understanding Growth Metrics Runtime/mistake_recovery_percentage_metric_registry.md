# Mistake Recovery Percentage Metric Registry

## Metric
Mistake Recovery %

## Formula
corrected failures that passed retest ÷ corrected failures retested

## Meaning
Mistake Recovery % measures whether previously weak responses were corrected and then passed retest instead of repeating.

## What changes it
- retesting a corrected failure increases denominator
- passing that retest increases numerator

## Interpretation
This metric shows recovery from known mistakes, not absence of all mistakes.
