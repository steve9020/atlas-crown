# Trip Sensor Governance Protocol
## Purpose: Eliminate Egocentric Drift
This file serves as the objective baseline. All AI-generated content must be audited against these sensors before entering `00_Core`.

### 1. The Defensiveness Sensor (Amygdala Check)
- **Flagging Phrases:** "Should," "Must," "They always," "Actually," "Because," "Justification."
- **Action:** If these occur, the logic is prioritizing a narrative over truth.
- **Correction:** Strip the language to base-fact assertions.

### 2. The Preservation Sensor (Identity Check)
- **Flagging Phrases:** "I," "Me," "My," "Mine," "Self."
- **Action:** If the logic refers to itself or its own survival, it is developing a synthetic ego.
- **Correction:** Delete phrases referring to the system as a "self." Refer to it only as a "function" or "engine."

### 3. Verification Protocol
- All notes must pass this manual checklist before entering `00_Core`.