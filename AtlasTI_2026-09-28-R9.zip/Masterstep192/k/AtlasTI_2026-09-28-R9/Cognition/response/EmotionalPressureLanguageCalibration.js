const DIRECT_LABEL_PATTERNS = [
  { id: "direct_abandoned_label", emotion: "abandoned", pattern: /\byou\s+(feel|are feeling)\s+abandoned\b/gi, replacement: "the silence may be making the connection feel less secure" },
  { id: "direct_rejected_label", emotion: "rejected", pattern: /\byou\s+(feel|are feeling)\s+rejected\b/gi, replacement: "the response may be making acceptance or closeness feel uncertain" },
  { id: "direct_anxious_label", emotion: "anxious", pattern: /\byou\s+(feel|are feeling)\s+anxious\b/gi, replacement: "the uncertainty may be putting pressure on your sense of steadiness" },
  { id: "direct_angry_label", emotion: "angry", pattern: /\byou\s+(feel|are feeling)\s+angry\b/gi, replacement: "something important may have felt dismissed, crossed, or unfair" },
  { id: "direct_sad_label", emotion: "sad", pattern: /\byou\s+(feel|are feeling)\s+sad\b/gi, replacement: "the situation may be carrying real emotional weight" },
  { id: "direct_ashamed_label", emotion: "ashamed", pattern: /\byou\s+(feel|are feeling)\s+ashamed\b/gi, replacement: "the moment may be pressing too hard against your sense of dignity" },
  { id: "direct_insecure_label", emotion: "insecure", pattern: /\byou\s+(feel|are feeling)\s+insecure\b/gi, replacement: "the uncertainty may be making the ground under the connection feel less steady" }
];

const PRESSURE_LANGUAGE_MARKERS = [
  /\bpressure\b/i,
  /\bweight\b/i,
  /\bmade?\s+.+\s+feel\b/i,
  /\bcan\s+make\s+it\s+feel\b/i,
  /\bstarts?\s+feeling\s+tied\b/i,
  /\bmay\s+be\s+(touching|pressing|carrying|making)\b/i,
  /\bdoes\s+not\s+have\s+to\s+become\b/i,
  /\bdoes\s+not\s+fully\s+tell\b/i
];

function normalize(text) {
  return (typeof text === "string" ? text : "").toLowerCase();
}

function inputContainsEmotion(input, emotion) {
  const text = normalize(input);
  if (!emotion) return false;
  const escaped = emotion.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`\\b${escaped}\\b`, "i").test(text);
}

function detectUnsupportedDirectEmotionLabels(response, input = "") {
  const text = typeof response === "string" ? response : "";
  const detected = [];

  for (const item of DIRECT_LABEL_PATTERNS) {
    item.pattern.lastIndex = 0;
    if (item.pattern.test(text) && !inputContainsEmotion(input, item.emotion)) {
      detected.push(item.id);
    }
  }

  return detected;
}

function hasPressureOrContextLanguage(response) {
  const text = typeof response === "string" ? response : "";
  return PRESSURE_LANGUAGE_MARKERS.some((pattern) => pattern.test(text));
}

function applyEmotionalPressureLanguage(response, input = "") {
  let output = typeof response === "string" ? response : "";
  const detectedBefore = detectUnsupportedDirectEmotionLabels(output, input);

  for (const item of DIRECT_LABEL_PATTERNS) {
    item.pattern.lastIndex = 0;
    if (!inputContainsEmotion(input, item.emotion)) {
      output = output.replace(item.pattern, item.replacement);
    }
  }

  const detectedAfter = detectUnsupportedDirectEmotionLabels(output, input);
  const pressureLanguagePresent = hasPressureOrContextLanguage(output);

  return {
    output,
    emotional_pressure_language_calibration: {
      emotional_pressure_language_calibration_active: true,
      unsupported_direct_emotion_labels_detected: detectedBefore,
      unsupported_direct_emotion_labels_remaining: detectedAfter,
      direct_emotion_labeling_allowed_only_when_user_supplies_or_context_strongly_supports: true,
      pressure_context_wording_prioritized: pressureLanguagePresent || detectedBefore.length > 0,
      user_not_labeled_before_context: detectedAfter.length === 0,
      machinery_language_exposed: false,
      required_output_mode: "pressure_context_wording_before_direct_emotion_labeling",
      guardrails: [
        "describe_pressure_before_labeling_emotion",
        "do_not_finalize_user_emotional_state_from_internal_detection_alone",
        "emotion_names_allowed_when_user_supplies_them_or_context_strongly_supports",
        "recognition_without_diagnosis_or_identity_labeling",
        "human_facing_pressure_language_over_backend_mechanism_language"
      ]
    }
  };
}

module.exports = {
  applyEmotionalPressureLanguage,
  detectUnsupportedDirectEmotionLabels,
  hasPressureOrContextLanguage
};
