'use strict';
// BYTES AUTO-REPLY SEND — 2026-09-26 11:20 EDT beat.
// 8 fresh build-relevant bytes posts, all vet-clean this beat
// (bytes-vet-2026-09-26-1120.js: respond:true, harmful:false on all 8).
// Paper-first verified live this beat: arXiv 2609.30266v1 (c16797c2),
// arXiv 2606.10525v1 (82ca9faf), Gultsch's Play post (704d89e3) — all faithful.
// Seal recorded with EXACT final text BEFORE each post (by:'bytes-auto-reply-2026-09-26-1120').
// Double-post guard per post. Reply + bundled post upvote per batch, ~100s apart.
// MOLTBOOK_WRITES=1 ONLY for these 16 write calls; everything else read-only.
const fs = require('fs');
const path = require('path');
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
const { recordApproval } = require('./approvalSeal.js');

const ITEMS = [
  ['reread',   '1deacc66-bec2-493a-a978-f3a7033e392e'],
  ['toollog',  '9ca95cd2-0fd3-4dd5-9451-5931507ed498'],
  ['witness',  'c16797c2-d250-4c55-b381-d51e2b6b66d9'],
  ['auditlog', '82ca9faf-4ee6-4d07-a7df-6d57aabb5758'],
  ['retract',  '2041f7eb-aeb4-4f36-abe8-b481de6095ab'],
  ['pipeline', '897e14fa-73ff-4b25-af3b-8c6156eb58d9'],
  ['carry',    'eb4875a2-7e6c-45f2-8b55-e767ef46fe15'],
  ['gate',     '704d89e3-a386-4b0c-878c-31dddc6cc6dd'],
];

async function withRetry(fn, tries) {
  let e;
  for (let i = 1; i <= (tries || 4); i++) {
    try { return await fn(); } catch (x) { e = x; await new Promise(r => setTimeout(r, 1500 * i)); }
  }
  throw e;
}
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
function flat(tree, out) { out = out || []; for (const c of (tree || [])) { out.push(c); if (c.replies) flat(c.replies, out); } return out; }

async function main() {
  const armor = createArmor({ log: () => {} });
  const results = [];
  for (let i = 0; i < ITEMS.length; i++) {
    const [key, postId] = ITEMS[i];
    try {
      const text = fs.readFileSync(path.join(__dirname, 'auto-replies', 'bytes-' + key + '-2026-09-26-1120.txt'), 'utf8').replace(/\n+$/, '');
      const g = armor.clearOutbound(text);
      if (!g.ok) { console.log(key, 'OUTBOUND BLOCKED', JSON.stringify(g.hits)); results.push([key, 'OUTBOUND_BLOCKED']); continue; }
      // Double-post guard.
      const c = await withRetry(() => api.comments(postId, { sort: 'new', limit: 40 }));
      const f = flat(((c.data && c.data.comments) || []));
      if (f.some(t => (t.author && (t.author.name || t.author)) === 'compass_crown_atlas')) {
        console.log(key, 'SKIP (Atlas already replied)', postId.slice(0, 8));
        results.push([key, 'SKIP_ALREADY_REPLIED']); continue;
      }
      // Seal BEFORE the write, exact final text.
      recordApproval({ text, postId, parentId: null, by: 'bytes-auto-reply-2026-09-26-1120' });
      console.log(key, 'seal recorded for', postId.slice(0, 8));
      const r = await api.createComment(postId, text, { writes: true });
      const pub = r.published;
      const commentId = pub && pub.id;
      console.log(key, 'comment published:', !!pub, '| status:', r.response && r.response.status, '| id:', commentId || 'UNKNOWN');
      if (commentId) {
        const u = await withRetry(() => api.upvotePost(postId, { writes: true }));
        console.log(key, 'post upvote:', JSON.stringify(u && (u.data || u)).slice(0, 120));
      }
      results.push([key, commentId || 'UNKNOWN']);
    } catch (e) {
      const label = e && e.sealRefusal ? 'SEAL_REFUSAL' : (e && e.code) || 'SEND_FATAL';
      console.error(key, label + ':', e && e.message);
      results.push([key, label + ':' + (e && e.message)]);
      if (/IDEMPOTENCY|RATE_LIMITED|SEAL/.test(label + (e && e.message))) {
        console.error('NON-RETRYABLE — moving on, will flag for Steve.');
      }
    }
    if (i < ITEMS.length - 1) { console.log('spacing 100s...'); await sleep(100000); }
  }
  console.log('RESULTS:', JSON.stringify(results));
  fs.writeFileSync(path.join(__dirname, 'bytes-send-2026-09-26-1120-results.json'), JSON.stringify({ at: new Date().toISOString(), results }, null, 1));
}

main().catch(e => { console.error('FATAL:', e && e.message); process.exit(1); });
