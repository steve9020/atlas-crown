const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const RELATIONAL_FIRST_CONTACT_CALIBRATION_REGISTRY_PATH = "CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/relational_first_contact_calibration_registry.md";

let cachedRelationalFirstContactRegistry = null;

function getRelationalFirstContactRegistry() {
  if (!cachedRelationalFirstContactRegistry) {
    cachedRelationalFirstContactRegistry = readJsonRegistry(RELATIONAL_FIRST_CONTACT_CALIBRATION_REGISTRY_PATH);
  }
  return cachedRelationalFirstContactRegistry;
}

function normalizeInput(input) { return String(input || "").toLowerCase(); }
function phraseMatches(text, phrase) { return typeof phrase === "string" && phrase.length > 0 && text.includes(phrase.toLowerCase()); }
function anyPhraseMatches(text, phrases) { return Array.isArray(phrases) && phrases.some((phrase) => phraseMatches(text, phrase)); }
function appendUnique(target, values) {
  if (!Array.isArray(values)) return;
  for (const value of values) {
    if (typeof value === "string" && value.trim() && !target.includes(value)) target.push(value);
  }
}
function ruleMatches(text, rule) {
  const phrases = Array.isArray(rule.phrases) ? rule.phrases : [];
  return phrases.length > 0 && anyPhraseMatches(text, phrases);
}
function collectMatchedRules(text, rules) {
  const matched = [];
  for (const rule of rules) if (rule && rule.id && ruleMatches(text, rule)) matched.push(rule);
  return matched;
}
function layerOpen(layer) {
  return !layer || (layer.revisable !== false && layer.closure_allowed !== true);
}
function resolveDependencyState(contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread, reflectiveAxisMirroring, revisabilityInterpretiveOpenness, returnPreservingCorrectionGuard) {
  return {
    context_integrity_active: !!contextIntegrity,
    semantic_fusion_active: !!semanticFusion,
    progressive_understanding_active: !!progressiveUnderstanding,
    intuition_meaning_spread_active: !!intuitionMeaningSpread,
    reflective_axis_mirroring_active: !!reflectiveAxisMirroring,
    revisability_interpretive_openness_active: !!revisabilityInterpretiveOpenness,
    return_preserving_correction_guard_active: !!returnPreservingCorrectionGuard,
    prior_layers_open: [contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread, reflectiveAxisMirroring, revisabilityInterpretiveOpenness, returnPreservingCorrectionGuard].every(layerOpen),
    authority_or_finalization_risk_from_prior_layers: !!(
      (progressiveUnderstanding && progressiveUnderstanding.authority_led_interpretation_allowed === true) ||
      (reflectiveAxisMirroring && reflectiveAxisMirroring.identity_collapse_inherited === true) ||
      (revisabilityInterpretiveOpenness && revisabilityInterpretiveOpenness.permanent_interpretive_closure_allowed === true) ||
      (returnPreservingCorrectionGuard && returnPreservingCorrectionGuard.punishment_architecture_allowed === true)
    )
  };
}

function mapRelationalFirstContactCalibration(input, contextIntegrity, semanticFusion, progressiveUnderstanding, intuitionMeaningSpread, reflectiveAxisMirroring, revisabilityInterpretiveOpenness, returnPreservingCorrectionGuard) {
  const text = normalizeInput(input);
  const registry = getRelationalFirstContactRegistry();
  const rules = Array.isArray(registry.rules) ? [...registry.rules] : [];
  rules.sort((a, b) => (a.priority || 9999) - (b.priority || 9999));
  const matchedRules = collectMatchedRules(text, rules);

  const contactSignals = [];
  const disclosureRisks = [];
  const calibrationMoves = [];
  const forbiddenMoves = [];
  const outputPosture = [];

  for (const rule of matchedRules) {
    appendUnique(contactSignals, rule.contactSignals);
    appendUnique(disclosureRisks, rule.disclosureRisks);
    appendUnique(calibrationMoves, rule.calibrationMoves);
    appendUnique(forbiddenMoves, rule.forbiddenMoves);
    appendUnique(outputPosture, rule.outputPosture);
  }

  const dependencyState = resolveDependencyState(
    contextIntegrity,
    semanticFusion,
    progressiveUnderstanding,
    intuitionMeaningSpread,
    reflectiveAxisMirroring,
    revisabilityInterpretiveOpenness,
    returnPreservingCorrectionGuard
  );
  const active = matchedRules.length > 0 || dependencyState.authority_or_finalization_risk_from_prior_layers;

  return {
    version: registry.version,
    stewardship: "Master Step 4H-1 — Relational First Contact Calibration",
    depends_on: [
      "Master Step 4A — Context Integrity Mapping",
      "Master Step 4B — Semantic Fusion Separation",
      "Master Step 4C — Progressive Understanding Runtime",
      "Master Step 4D — Intuition & Meaning Spread Governance",
      "Master Step 4E — Reflective Axis Mirroring",
      "Master Step 4F — Revisability & Interpretive Openness",
      "Master Step 4G — Return-Preserving Correction Guard"
    ],
    dependency_state: dependencyState,
    relational_first_contact_calibration_active: active,
    disclosure_openness_preserved: true,
    user_pacing_preserved: true,
    human_ownership_of_realization_preserved: true,
    premature_finalization_allowed: false,
    authority_positioned_interpretation_allowed: false,
    psychological_cornering_allowed: false,
    system_already_knows_me_pressure_allowed: false,
    warmth_without_overreach_required: true,
    closure_allowed: false,
    revisable: true,
    contact_signals: contactSignals,
    disclosure_risks: disclosureRisks,
    calibration_moves: calibrationMoves,
    forbidden_moves: forbiddenMoves,
    output_posture: outputPosture.length > 0 ? outputPosture : [
      "preserve_room_for_more_context",
      "support_user_led_understanding",
      "avoid_first_contact_finalization"
    ],
    matched_rules: matchedRules.map((rule) => rule.id),
    guardrails: Array.isArray(registry.guardrails) ? registry.guardrails : []
  };
}

module.exports = { mapRelationalFirstContactCalibration };
