---
title: External Teaching To Proposal Flow
runtime_layer: external_teaching_channel
priority: high
governed_by: gpt_assisted_teaching_channel_overview
supports:
  - emotional_growth_proposal_queue
  - emotional_growth_approval_gate
  - teaching_answer_to_proposal_flow
outputs_to:
  - emotional_growth_proposal_queue
status: active
---

# External Teaching To Proposal Flow

## Purpose

The **External Teaching To Proposal Flow** defines how GPT-assisted teaching becomes reviewable system growth.

No external teaching becomes active automatically.

---

## Flow

1. Steven sends Compass material to GPT for program review.
2. GPT identifies the response problem.
3. GPT drafts a teaching correction.
4. The teaching correction becomes a proposal.
5. The proposal is sent to the proposal queue.
6. The approval gate reviews it.
7. Approved proposals generate integration drafts.
8. Steven decides whether to integrate, hold, or cancel.

---

## Proposal Types

External teaching may generate proposals for:

- route correction
- sentence construction improvement
- meaning construction improvement
- approved response example
- detector refinement
- merge assessment refinement
- response quality scoring improvement
- user-facing focal card improvement

---

## Required Proposal Fields

Each external teaching proposal should include:

- source: GPT assisted teaching channel
- original prompt or response issue
- correction type
- teaching correction
- reason for change
- duplicate/merge risk
- target system area
- user-facing behavior note
- approval status

---

## Approval Rule

External teaching proposals must enter the same approval system as all other system growth.

GPT-assisted teaching does not bypass:

- proposal queue
- approval gate
- integration draft review
- Steven's final decision

---

## Related Runtime Links

- [[gpt_assisted_teaching_channel_overview]]
- [[external_teacher_input_format]]
- [[gpt_response_review_template]]
- [[emotional_growth_proposal_queue]]
- [[emotional_growth_approval_gate]]
- [[teaching_answer_to_proposal_flow]]
