const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const version = require('../version_status');

const root = path.resolve(__dirname, '..');
const required = [
  'runtime/backend/liveOutput/LiveBackendOutputProofBatch.js',
  'runtime/proof/MASTERSTEP65_LIVE_BACKEND_OUTPUT_PROOF_BATCH.json',
  'runtime/proof/MASTERSTEP65_LIVE_BACKEND_OUTPUT_PROOF_BATCH.md',
  'docs/MASTERSTEP65_LIVE_BACKEND_OUTPUT_PROOF_BATCH_MAP.md',
  'tests/masterStep65LiveBackendOutputProofBatchTest.js'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(root, rel)), `missing Step65 artifact: ${rel}`);

const proof = JSON.parse(fs.readFileSync(path.join(root, 'runtime/proof/MASTERSTEP65_LIVE_BACKEND_OUTPUT_PROOF_BATCH.json'), 'utf8'));
assert.strictEqual(proof.passed, true, 'proof JSON must record Step65 pass');
assert.strictEqual(proof.provider_connected, false, 'proof JSON must record provider disconnected');
assert.strictEqual(proof.model_connected, false, 'proof JSON must record model disconnected');
assert.strictEqual(proof.frontend_intelligence_added, false, 'proof JSON must record no frontend intelligence');
assert.strictEqual(proof.decision, 'CLOSE_STEP_65_AND_MOVE_TO_STEP_66', 'proof JSON must close Step65 cleanly');

assert.strictEqual(version.currentKeeper, 'Masterstep65', 'version_status currentKeeper must be Masterstep65');
assert.strictEqual(version.step, 'Live Backend Output Proof Batch', 'version_status step must be Step65 title');
assert.strictEqual(version.aiConnected, false, 'AI must remain disconnected');
assert.strictEqual(version.providerConfigured, false, 'provider must remain unconfigured');
assert.strictEqual(version.providerWrapperExecutionEnabled, false, 'provider wrapper execution must remain disabled');
assert.strictEqual(version.networkBridgeEnabled, false, 'network bridge must remain disabled');
assert.strictEqual(version.liveBackendOutputProofBatchComplete, true, 'Step65 completion flag missing');
assert.strictEqual(version.frontendIntelligenceAllowed, false, 'frontend intelligence must remain blocked');
assert.strictEqual(version.backendOwnsIntelligence, true, 'backend ownership must remain true');

console.log('masterStep65FullClosureKeeperReadinessTest PASSED');
