---
runtime_layer: atlas_layer_index
priority: index
---

# 08 Atlas Teaching Learning

This folder groups related Atlas backend files for safer human navigation. Runtime authority is controlled by backend metadata, governance maps, and runtime execution order, not by folder position alone.

## Added teaching runtimes

- 58 Response Weakness Detection Runtime: reviews generated Compass responses for likely route, card, specificity, tone, backend-language, or missed-detail failures.
- 59 Teaching Gap Detection Runtime: converts detected weaknesses into reusable backend teaching gaps and proposal-ready correction rules.
- 60 Route Assumption Check Runtime: performs pre-response route comparison so Atlas checks every meaningful candidate route before allowing a default route to win.

## Teaching runtime boundary

These runtimes may detect, compare, and propose. Durable backend changes still require approval through the teaching authority map.


## Understanding Growth Metrics Runtime
- [[understanding_growth_metrics_runtime_overview]]
- [[growth_percentage_metric_registry]]
- [[understanding_percentage_metric_registry]]
- [[mistake_recovery_percentage_metric_registry]]
- [[duplicate_merge_readiness_metric_registry]]
- [[route_verification_percentage_metric_registry]]
- [[card_accuracy_percentage_metric_registry]]
- [[repeated_weakness_reduction_metric_registry]]
