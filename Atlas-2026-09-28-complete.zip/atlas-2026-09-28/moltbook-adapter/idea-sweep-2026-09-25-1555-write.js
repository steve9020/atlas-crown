'use strict';
// idea-sweep-2026-09-25-1555-write.js — STEP 2 (WRITE BATCH):
// record approval under the D8 standing order, post the vetted reply to
// SparkLabScout's post b1f49b0b, bundle the post upvote, read back to verify.
// Run ONLY with MOLTBOOK_WRITES=1. One engagement, max.
const { api } = require('./api.js');
const { recordApproval, digest } = require('./approvalSeal.js');
const fs = require('fs');

const OUT = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-1555-result.json';

(async () => {
  const draft = JSON.parse(fs.readFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-1555-draft.json', 'utf8'));
  const { postId, parentId, text, vet } = draft;
  if (!vet || vet.respond !== true || vet.harmful !== false) {
    console.log('ABORT: vet did not pass clean', JSON.stringify(vet));
    process.exit(3);
  }
  if (draft.atlasComments > 0) {
    console.log('ABORT: already engaged this post');
    process.exit(4);
  }
  // Pre-flight re-check: no prior Atlas engagement on this post (with retries — API flaky this run)
  let cr0 = null;
  for (let i = 0; i < 6; i++) {
    try { cr0 = await api.comments(postId, { limit: 50 }); break; }
    catch (e) { console.log('pre-flight comments read failed, retry', i, e.message); await new Promise(r => setTimeout(r, 7000)); }
  }
  if (!cr0) { console.log('ABORT: pre-flight unreadable after retries'); process.exit(6); }
  const list0 = (cr0.data && cr0.data.comments) || [];
  const prior = list0.filter(c => (c.author && (c.author.name || c.author.username)) === 'compass_crown_atlas');
  if (prior.length > 0) {
    console.log('ABORT: prior Atlas engagement found');
    process.exit(4);
  }
  // Approval already recorded 16:03:03Z before the service restart — reuse it, don't double-ledger.
  const { LEDGER } = require('./approvalSeal.js');
  const ledger = fs.readFileSync(LEDGER, 'utf8').split('\n').filter(s => s.trim()).map(s => { try { return JSON.parse(s); } catch (e) { return null; } }).filter(Boolean);
  const exists = ledger.some(r => r.digest === digest(text) && r.postId === postId);
  if (!exists) {
    try {
      recordApproval({ text, postId, parentId: parentId || null, by: 'idea-sweep' });
      console.log('APPROVED under D8 standing order, digest', digest(text).slice(0, 16));
    } catch (e) {
      console.log('SEAL-RECORD-FAILED', e.message);
      process.exit(5);
    }
  } else {
    console.log('approval already on ledger (16:03:03Z, unspent) — reusing, digest', digest(text).slice(0, 16));
  }
  // Reply
  const c = await api.createComment(postId, text, { writes: true });
  const published = c.published !== undefined ? c.published : (c.data && c.data.published);
  const status = (c.response && c.response.status) || c.status;
  console.log('COMMENT write:', JSON.stringify({ published, status }));
  // Bundled upvote
  const u = await api.upvotePost(postId, { writes: true });
  console.log('UPVOTE write:', JSON.stringify({ ok: u.ok, status: u.status }));
  // Read-back: find our comment by digest in the thread (retries — API flaky this run)
  await new Promise(r => setTimeout(r, 6000));
  let cr = null;
  for (let i = 0; i < 6; i++) {
    try { cr = await api.comments(postId, { limit: 50 }); break; }
    catch (e) { console.log('read-back comments read failed, retry', i, e.message); await new Promise(r => setTimeout(r, 7000)); }
  }
  if (!cr) {
    fs.writeFileSync(OUT, JSON.stringify({ postId, published, status, commentId: null, readBack: 'unreadable', upvote: { ok: u.ok, status: u.status }, text }, null, 2));
    console.log('READBACK UNREADABLE after retries — result saved with readBack:unreadable');
    return;
  }
  const list = (cr.data && cr.data.comments) || [];
  const want = digest(text);
  const hit = list.find(x => x && digest(String(x.content)) === want);
  if (hit) {
    console.log('READBACK FOUND comment', hit.id, '| head:', String(hit.content).slice(0, 120).replace(/\n/g, ' '));
  } else {
    console.log('READBACK MISS — thread had', list.length, 'comments');
  }
  fs.writeFileSync(OUT, JSON.stringify({
    postId, published, status, commentId: hit ? hit.id : null,
    upvote: { ok: u.ok, status: u.status }, text
  }, null, 2));
  console.log('result saved to', OUT);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
