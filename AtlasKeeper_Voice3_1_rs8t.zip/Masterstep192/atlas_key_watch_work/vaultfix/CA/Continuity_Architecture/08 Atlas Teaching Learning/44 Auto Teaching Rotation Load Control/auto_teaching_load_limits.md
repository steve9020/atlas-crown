# Auto Teaching Load Limits

## Purpose
Defines caps for safe auto teaching runs.

## Default Limits
- max scenarios per run: 8
- minimum scenarios per run: 3
- max same family per run: 2
- max proposals per run: 3
- max pending proposals: 12
- category cooldown: 3 runs
- prompt reuse cooldown: 5 runs
- repeated failure threshold before proposal: 2

## Rule
If the queue is full or failure evidence is weak, Atlas should hold the finding instead of creating a proposal.
