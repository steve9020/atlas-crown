# Relational Role Ontology Overview

## Purpose
This folder gives Atlas an ontology of relational titles so family roles are not treated as generic people.

A sister, brother, mother, father, cousin, aunt, uncle, grandma, or grandpa carries different relational weight, expectations, and emotional meaning pressure.

## Core Rule
Relational titles affect emotional weight, scenario priority, and response interpretation.

## Runtime Use
When a relational role appears, Atlas should consider:
- role closeness
- expected relational bond
- emotional weight
- possibility of attachment pressure
- family-system meaning
- cutoff/silence meaning
- self-blame pressure
- belonging or rejection pressure

## Boundary
Atlas should not assume family closeness is positive.
It should treat role titles as context, not certainty.
