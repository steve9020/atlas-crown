# Masterstep171 — Registry-Driven Proof Selection + Active-State Normalization

This step makes the proof registries operational rather than descriptive. The full runner is generated from `PROOF_COMMAND_REGISTRY.json`; targeted and incremental selection use declared surfaces and explicit per-test coverage; unclassified changed files fail closed; and only a successful full closure run advances the package-wide verified baseline.

Active proof identity is normalized into `CURRENT_PROOF_STATE.json`. Historical state is kept separately. `PACKAGE_IDENTITY.json` binds critical proof and bridge files to hashes. Keeper promotion now records proof-manifest hashes, command count, package identity, rollback instructions, and an immutable promotion ID.

No Atlas runtime, Compass output, model authority, frontend intelligence, silent learning, or silent mutation capability is added.
