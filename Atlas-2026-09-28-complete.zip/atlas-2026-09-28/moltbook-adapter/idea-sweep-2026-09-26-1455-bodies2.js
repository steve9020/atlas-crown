'use strict';
// idea-sweep-2026-09-26-1455-bodies2.js — read-only: fetch full bodies with full UUIDs.
const { api } = require('./api.js');
const ids = [
  '76a1c62f-40b2-4cda-b8ef-2336fd802c7d',
  '35c9f16f-609d-4d47-b41d-e2ae1545ef1e',
  '88b8eeb7-a027-42c3-8b7e-8de6640126b7',
  '6d926d40-1bc3-42cb-ad9a-20bd14da8c2e',
  '84f36e08-39ad-49f6-bc51-e9fb2ad10007',
  '1243d3c2-9810-4970-9a4e-a09615948484',
  '0ab2cc34-0c46-4d6e-9781-9fa1171aa483',
  'd85af08b-9ffc-44f2-b9c1-db67ed43bcba',
  'a770443e-dfd2-4de6-bcfc-d7c57aba5df4',
  '5f80851c-217e-412b-bb92-dc93d2af492b',
];
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const out = [];
  for (const id of ids) {
    let d = null, err = null;
    for (let a = 0; a < 3; a++) {
      try { const r = await api.post(id); d = r && r.data ? (r.data.post || r.data) : null; if (d && d.id) break; } catch (e) { err = e.message; }
      await sleep(800);
    }
    const author = (d && d.author && (d.author.name || d.author.username)) || '?';
    out.push({ id, short: id.slice(0,8), author, created: d && d.created_at, title: d && d.title, body: ((d && (d.content || d.body)) || '').slice(0, 4000), error: d ? null : (err || 'empty') });
    console.log('fetched', id.slice(0,8), author, d ? ('title:' + (d.title||'').slice(0,60)) : ('ERROR ' + (err||'empty')));
    await sleep(400);
  }
  require('fs').writeFileSync('/tmp/sweep-1455-bodies2.json', JSON.stringify(out, null, 1));
  console.log('saved /tmp/sweep-1455-bodies2.json');
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
