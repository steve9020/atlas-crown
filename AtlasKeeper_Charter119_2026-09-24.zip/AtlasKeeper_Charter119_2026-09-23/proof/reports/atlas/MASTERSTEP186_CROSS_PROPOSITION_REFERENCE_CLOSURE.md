# Masterstep186 — Cross-Proposition Reference Closure

Fresh attack: 8/12 PASS.

The first repair reached the new corpus but regressed Step184 and was rejected.
This repair restarted from the closed Step185 artifact.

Closure rule:
- explicit external/self/relational reference targets are kept distinct;
- bare `it/that` does not gain global revocation authority under genuine ambiguity;
- direct same-clause self revocation retains Step184 authority;
- ambiguity requires a separate surviving current self proposition, not merely
  historical self evidence plus an external proposition.

Proof:
- Step186: 12/12 PASS
- Steps179-185: PASS
- Atlas canonical: 100/100 PASS
- Crown P1-P8: 8/8 PASS
- frontend changes: 0
- new matrix/domain: none

Boundary: bounded lexical/proximity reference-target evidence, not general
coreference/anaphora resolution.
