# Emotional Pressure Language Calibration Registry

Master Step: 5
Layer: 5D — Emotional Pressure Language Calibration
Status: PASSED / CLOSED
Package: Master01_patch05.zip

## Purpose

Compass should describe the pressure or context around an emotional state before directly labeling the user with an emotion.

This layer prevents frontend output from making the user feel labeled, diagnosed, finalized, or psychologically handled when the user has not supplied the emotional label themselves.

## Core Rule

Pressure/context wording comes before direct emotional labeling.

## Allowed Behavior

- Use direct emotion words when the user supplied them.
- Use direct emotion words when context strongly supports them and wording remains gentle.
- Prefer pressure/context language when the emotional state is inferred internally.
- Preserve emotional connection without turning detection into a label.

## Blocked Behavior

- Do not say `you feel abandoned` if the user did not name abandonment or provide strong enough context.
- Do not label the user from backend emotional detection alone.
- Do not expose machinery, route labels, axes, or mechanism language.
- Do not convert internal emotional confidence into frontend certainty.

## Required Output Mode

Human-facing pressure language that lets the user recognize what is happening without feeling categorized.

Example:

Instead of:
`You feel abandoned.`

Prefer:
`The silence may be making the connection feel less secure right now.`

## Carry-Forward Requirement

Future packages must preserve:

- `Cognition/response/EmotionalPressureLanguageCalibration.js`
- `tests/emotionalPressureLanguageCalibrationTest.js`
- pipeline output key `emotional_pressure_language_calibration`
- this registry file
- corresponding proof-of-work entry
