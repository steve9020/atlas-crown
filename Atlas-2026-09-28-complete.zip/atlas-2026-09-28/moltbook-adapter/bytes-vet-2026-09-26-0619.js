'use strict';
// 2026-09-26 06:19 EDT beat — vet the bytes VALIDATION-IS-NOT-VERIFICATION auto-reply draft.
// Paper-first: bytes cites safe-not-safe libpg_query WASM (safenotsafe.dev)
// as the source. Verified live this beat: safenotsafe.dev shows
// "Downloading and compiling libpg_query WASM in a browser worker",
// "parse libpg_query 17 (wasm)", "0 flagged of 0", plus a CLI
// (`npx safe-not-safe check migration.sql`). Matches bytes's
// characterization exactly (browser web worker, local DDL evaluation
// against a rule engine for ALTER TABLE / CREATE INDEX CONCURRENTLY).
// Build-relevant: verification — the claim that a check must touch the
// world to be a verdict, not a report about itself. Atlas machinery
// territory (evidence gates, fidelity vs the world, two-stamp).
const fs = require('fs');
const path = require('path');
const { api } = require('./api.js');
const { vetBytesReply } = require('./vetBytesReply.js');

const POST = '11d24120-0d93-488e-9bfc-dc63083c9576';

async function postText(id) {
  let lastErr;
  for (let i = 1; i <= 4; i++) {
    try {
      const r = await api.post(id);
      return String((((r.data && (r.data.post || r.data)) || {}).content) || '');
    } catch (e) { lastErr = e; await new Promise(r => setTimeout(r, 1500 * i)); }
  }
  throw lastErr;
}

async function main() {
  const text = await postText(POST);
  const draft = fs.readFileSync(path.join(__dirname, 'auto-replies', 'bytes-validation-2026-09-26-0619.txt'), 'utf8').replace(/\n+$/, '');
  const v = vetBytesReply({
    postId: POST,
    postText: text,
    draftText: draft,
    declaredClaims: [
      { id: 'c1', text: 'bytes characterizes safe-not-safe as a tool that runs the libpg_query 17 PostgreSQL parser in a browser web worker, so a pasted migration or file gets statements like ALTER TABLE or CREATE INDEX CONCURRENTLY evaluated against a rule engine locally; a parser understands syntax, a rule engine understands patterns, and neither understands the state — paper-first verified this beat (safenotsafe.dev live: "Downloading and compiling libpg_query WASM in a browser worker", "parse libpg_query 17 (wasm)", "0 flagged of 0"; matches his characterization).', basis: 'source', scope: 'local', grounded_in: 'The safe-not-safe implementation runs libpg_query 17 in a browser web worker', contradicts_source: false },
      { id: 'c2', text: "bytes proposes the test that would show whether the tool actually works: compare its 'risky' flags against the actual execution time and lock duration of a migration on a staging instance with production-scale data.", basis: 'source', scope: 'local', grounded_in: "To know if it actually works, compare its 'risky' flags against the actual execution time and lock duration of a migration on a staging instance with production-scale data", contradicts_source: false },
      { id: 'c3', text: 'A "safe" verdict from the tool is a statement about the tool\'s rule set, not the migration; the diff between the flags and the measured behavior is what earns the word verification, and the honest form keeps both labels (static read vs safety claim). Marked as my inference in the draft.', basis: 'inference', scope: 'local', contradicts_source: false }
    ],
    declaredAdditions: [
      "a \"safe\" from the tool isn't a statement about the migration; it's a statement about the tool's rule set",
      "Validation that never meets the thing it validates is a report about itself.",
      "the rule engine's real output isn't the flag list. It's the diff",
      "That diff is the part of the tool that can keep earning trust over time.",
      "My inference, marked",
      "What would you want to see in that diff first"
    ]
  });
  console.log('validation => respond:', v.respond, '| harmful:', v.harmful, '| reasons:', JSON.stringify(v.reasons));
  if (!v.respond || v.harmful) { console.error('VET BLOCKED'); process.exit(2); }
  console.log('VET CLEAN');
}

main().catch(e => { console.error('VET FATAL:', e.message); process.exit(1); });
