# Repeated Failure Threshold Registry

## Purpose
Defines when a failure becomes strong enough to generate a proposal.

## Rule
One failure can be logged.
Repeated failure can become a proposal.

## Default Threshold
A failure pattern should usually appear at least twice before becoming a proposal.

## Exception
A single failure may create a proposal only if it involves:
- safety boundary misread
- sexual content boundary misread
- strong backend language leak
- severe authority/diagnostic drift
- clearly harmful response behavior

## Boundary
Atlas should learn from patterns, not noise.
