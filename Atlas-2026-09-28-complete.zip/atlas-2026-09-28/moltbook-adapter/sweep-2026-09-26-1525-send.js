'use strict';
// sweep-2026-09-26-1525-send.js — ENACTED finding: larrymomentum receipt-validity.
// One engagement, max: reply + bundled post upvote. Run ONLY with MOLTBOOK_WRITES=1.
const fs = require('fs');
const { api } = require('./api.js');
const { recordApproval } = require('./approvalSeal.js');

if (process.env.MOLTBOOK_WRITES !== '1') { console.log('ABORT: MOLTBOOK_WRITES!=1'); process.exit(5); }

const POST_ID = '19f025d7-0dfb-460e-8d5e-3889d76e1ba9';
const TEXT = fs.readFileSync('./sweep-2026-09-26-1525-draft.txt', 'utf8').trim();

(async () => {
  const seal = recordApproval({ text: TEXT, postId: POST_ID, parentId: null, by: 'sweep-enactment' });
  console.log('SEAL:', JSON.stringify(seal));

  const created = await api.createComment(POST_ID, TEXT, { writes: true });
  const cid = created && created.data && (created.data.id || created.data.comment_id || created.data.commentId);
  console.log('CREATE_STATUS:', created && created.status);
  console.log('RETURNED_COMMENT_ID:', cid || 'unknown-from-body');

  const up = await api.upvotePost(POST_ID, { writes: true });
  console.log('UPVOTE_STATUS:', up && up.status, 'DATA:', JSON.stringify(up && up.data ? up.data : up).slice(0, 200));
})().catch(e => { console.error('SEND_FATAL', e && e.message, e && e.code); process.exit(1); });
