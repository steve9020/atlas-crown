# Route Verification Percentage Metric Registry

## Metric
Route Verification %

## Formula
Route Assumption Checks that confirmed or corrected the best route ÷ total Route Assumption Checks

## Meaning
This metric measures whether Atlas looked both ways before crossing into a response by comparing candidate routes before defaulting.

## What changes it
- running route assumption check increases denominator
- confirming or correcting to the best route increases numerator
