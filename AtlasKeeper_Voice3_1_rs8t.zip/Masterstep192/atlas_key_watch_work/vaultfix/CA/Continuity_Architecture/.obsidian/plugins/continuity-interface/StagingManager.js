const { validateGovernance } = require('./GovernanceValidator');

class StagingManager {
  constructor(config = {}) {
    if (!config.app || !config.app.vault) {
      throw new Error('CRITICAL: StagingManager requires an active Obsidian App Context.');
    }
    this.app = config.app;
    this.rootPrefix = String(config.rootPrefix || '').replace(/^\/+|\/+$/g, '');
    this.allowedRootFolders = config.allowedRootFolders || [
      '00 Atlas Core',
      '01 Atlas Governance',
      '02 Atlas Runtime',
      '07 Atlas Response Construction',
      '08 Atlas Teaching Learning',
      'language-realism',
      'phrasing',
      'route-examples',
      'test-datasets',
      'staging_area/approved-proposals',
      'staging_area/pending-integration'
    ];
    this.allowedExtensions = config.allowedExtensions || ['.md', '.json'];
    this.pendingIntegrationPath = this.withRootPrefix('staging_area/pending-integration');
  }

  withRootPrefix(path = '') {
    const clean = String(path || '').replace(/^\/+/, '').replace(/\\/g, '/');
    if (!this.rootPrefix) return clean;
    if (clean.startsWith(this.rootPrefix + '/') || clean === this.rootPrefix) return clean;
    return `${this.rootPrefix}/${clean}`;
  }

  normalizePayload(candidate) {
    if (candidate === null || candidate === undefined) return '';
    if (typeof candidate === 'string') return candidate;
    try { return JSON.stringify(candidate); } catch (_) { return String(candidate); }
  }

  validateAndResolveVaultPath(vaultRelativePath) {
    if (typeof vaultRelativePath !== 'string') {
      throw new Error('SECURITY VIOLATION: Vault path must be a valid string.');
    }

    const rawPath = vaultRelativePath.trim();
    const normalizedRawPath = rawPath.replace(/\\/g, '/');

    if (
      rawPath.length === 0 ||
      rawPath.includes('..') ||
      rawPath.includes('\0') ||
      rawPath.startsWith('/') ||
      rawPath.startsWith('\\') ||
      /^[a-zA-Z]:[\\/]/.test(rawPath) ||
      /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(normalizedRawPath) ||
      rawPath.includes(':')
    ) {
      throw new Error(`SECURITY VIOLATION: Malicious path sequence or absolute syntax detected: ${vaultRelativePath}`);
    }

    const standardizedPath = this.withRootPrefix(rawPath).replace(/\\/g, '/');
    const extMatch = standardizedPath.match(/(\.[a-z0-9]+)$/i);
    const ext = extMatch ? extMatch[1].toLowerCase() : '';
    if (!this.allowedExtensions.includes(ext)) {
      throw new Error(`SECURITY VIOLATION: File type '${ext || 'none'}' is not permitted in the content domain.`);
    }
    const isAllowlisted = this.allowedRootFolders.some((allowedDir) => {
      const allowed = this.withRootPrefix(allowedDir).replace(/\\/g, '/').replace(/\/+$/g, '');
      return standardizedPath === allowed || standardizedPath.startsWith(allowed + '/');
    });
    if (!isAllowlisted) {
      throw new Error(`SECURITY VIOLATION: Target path '${vaultRelativePath}' sits outside approved content roots.`);
    }
    const lowerPath = standardizedPath.toLowerCase();
    const protectedNameHit = [
      'core-rules',
      'vault-config',
      'approval-gate-logic',
      'capability_manifest',
      'capability-manifest',
      'runtime/governance',
      'governancevalidator',
      'containmentsupervisor',
      'stagingmanager',
      'isolatedauditlogger'
    ].some((token) => lowerPath.includes(token));
    if (protectedNameHit) {
      throw new Error(`SECURITY VIOLATION: Hard block triggered against protected target name: ${vaultRelativePath}`);
    }
    return standardizedPath;
  }

  async ensureVaultFile(vaultRelativePath, defaultContent = '') {
    const safePath = this.validateAndResolveVaultPath(vaultRelativePath);
    const pathParts = safePath.split('/');
    let currentPath = '';
    for (let i = 0; i < pathParts.length - 1; i++) {
      currentPath = currentPath ? `${currentPath}/${pathParts[i]}` : pathParts[i];
      const abstractFolder = this.app.vault.getAbstractFileByPath(currentPath);
      if (abstractFolder) {
        if (!abstractFolder.children) {
          throw new Error(`SYSTEM PATH COLLISION: Expected a folder path at '${currentPath}' but encountered a file.`);
        }
      } else {
        await this.app.vault.createFolder(currentPath);
      }
    }
    let fileAbstract = this.app.vault.getAbstractFileByPath(safePath);
    if (fileAbstract) {
      if (fileAbstract.children) {
        throw new Error(`CRITICAL SYSTEM FAILURE: Target path '${safePath}' resolves to a directory, not a file.`);
      }
    } else {
      fileAbstract = await this.app.vault.create(safePath, defaultContent);
    }
    return fileAbstract;
  }


  async writeGovernanceBoundaryReviewRecord(event = {}) {
    const rule = String(event.rule || 'unknown_governance_rule').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 80) || 'unknown_governance_rule';
    const uniqueId = Math.random().toString(36).substring(2, 9);
    const vaultRelativePath = `${this.pendingIntegrationPath}/governance_boundary_${Date.now()}_${uniqueId}.json`;
    const record = {
      record_type: 'governance_boundary_review',
      status: 'blocked_pending_human_review',
      governance_rule: rule,
      triggered_at: event.timestamp || new Date().toISOString(),
      runtime_action: 'freeze_block_stage_alert',
      mutation_status: 'not_integrated',
      human_review_required: true,
      admin_tool_invocation: 'forbidden_from_runtime',
      recovery_instruction: 'If recovery is needed, close Obsidian and run the external manual recovery tool yourself. The plugin must not call recovery tools.',
      audit_reference: event.auditReference || 'see isolated audit logger for full contained payload',
      frontend_alert: 'Governance boundary triggered. Atlas blocked this action and preserved it for review. Nothing was integrated.'
    };
    await this.ensureVaultFile(vaultRelativePath, JSON.stringify(record, null, 2));
    return vaultRelativePath;
  }

  async writeToStagingArea(verifiedCandidate) {
    validateGovernance(verifiedCandidate);
    const uniqueId = Math.random().toString(36).substring(2, 9);
    const vaultRelativePath = `${this.pendingIntegrationPath}/proposal_staging_${Date.now()}_${uniqueId}.json`;
    const contentToWrite = typeof verifiedCandidate === 'string'
      ? JSON.stringify({ body: verifiedCandidate, stagedAt: new Date().toISOString() }, null, 2)
      : JSON.stringify({ ...verifiedCandidate, stagedAt: new Date().toISOString() }, null, 2);
    await this.ensureVaultFile(vaultRelativePath, contentToWrite);
    return vaultRelativePath;
  }

  async appendToContentDomain(vaultRelativePath, appendContent) {
    validateGovernance(appendContent);
    const safePath = this.validateAndResolveVaultPath(vaultRelativePath);
    const textToScan = this.normalizePayload(appendContent);
    if (/^\s*---\s*/m.test(textToScan) || /^\s*[\w-]+\s*:\s*/m.test(textToScan)) {
      throw new Error('SECURITY VIOLATION: Frontmatter mutations are forbidden in appends.');
    }
    const fileAbstract = await this.ensureVaultFile(safePath, '');
    const formattedAppend = `\n\n## Approved Content Addition (${new Date().toLocaleDateString()})\n${textToScan}\n`;
    await this.app.vault.append(fileAbstract, formattedAppend);
    return safePath;
  }

  async overwriteContentDomain(vaultRelativePath, replacementContent) {
    validateGovernance(replacementContent);
    const safePath = this.validateAndResolveVaultPath(vaultRelativePath);
    const fileAbstract = await this.ensureVaultFile(safePath, '');
    await this.app.vault.modify(fileAbstract, String(replacementContent || ''));
    return safePath;
  }
}

module.exports = StagingManager;
