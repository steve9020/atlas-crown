---
title: Recommendation Scoring Registry
runtime_layer: adaptive_backend_recommendation_engine
priority: high
governed_by: adaptive_backend_recommendation_engine_overview
receives_from:
  - backend_detector_generation_registry
  - missing_pattern_detection_registry
outputs_to:
  - emotional_growth_proposal_queue
  - emotional_growth_approval_gate
status: active
---

# Recommendation Scoring Registry

## Purpose

This registry defines how Compass scores backend growth recommendations before showing them in the frontend.

The goal is high accuracy, not high volume.

---

## Core Rule

Recommendations below 50 percent confidence must not be shown.

A low-confidence match is not a recommendation.

Duplicate suppression is not a merge recommendation.

Merge remains a separate review decision when overlap is real but potentially useful.

---

## Scoring Dimensions

Each recommendation should be scored across:

1. prompt evidence strength
2. pattern specificity
3. emotional loop clarity
4. attached meaning clarity
5. context clarity
6. target registry fit
7. duplicate risk
8. already-covered status
9. too-broad risk
10. false-assumption risk
11. frontend usefulness
12. merge likelihood

---

## Confidence Bands

### 90 to 100 percent

Very strong recommendation.

Use when the prompt clearly contains emotion, context, attached meaning, loop structure, and a distinct pattern.

### 75 to 89 percent

Strong recommendation.

Use when enough evidence exists and duplicate risk is low or manageable.

### 50 to 74 percent

Reviewable recommendation.

Use only when the pattern is specific enough and not already covered. Merge guidance may be needed.

### Below 50 percent

Do not recommend.

The system may ignore the match or wait for stronger evidence.

---

## Duplicate Handling

If a pattern is already active, queued, reviewed, integrated, revoked, or suppressed, do not recommend it again.

This should not appear as a duplicate recommendation card.

---

## Merge Handling

Merge assessment should appear when:

- the pattern is not exact duplicate
- the pattern overlaps an existing pattern
- the new wording may strengthen an existing backend area
- confidence remains 50 percent or higher

Merge recommendation should include:

- possible merge target
- reason for overlap
- why it may not need its own standalone pattern

---

## Too-Broad Handling

A recommendation is too broad when it lacks a specific loop, specific attached meaning, or specific emotional context.

Too-broad recommendations should usually be revoked or deferred, not approved.

---

## Frontend Assessment Fields

Compass should show:

- Needed
- Confidence
- Duplicate risk
- Already covered
- Too broad
- Possible merge target
- Recommended action
- Reason

---

## Related Runtime Links

- [[adaptive_backend_recommendation_engine_overview]]
- [[backend_detector_generation_registry]]
- [[missing_pattern_detection_registry]]
- [[proposal_draft_generation_registry]]
- [[emotional_growth_proposal_queue]]
- [[emotional_growth_approval_gate]]
