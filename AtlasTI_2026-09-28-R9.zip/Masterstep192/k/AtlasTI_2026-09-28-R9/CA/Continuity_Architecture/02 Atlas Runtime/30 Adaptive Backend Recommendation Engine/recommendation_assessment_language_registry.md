# Recommendation Assessment Language Registry

Defines that recommendation reasons must explain the real human pattern detected, not generic backend section matches. A useful reason names the scenario object, emotion role, attached meaning, and why it may need review or merge.
