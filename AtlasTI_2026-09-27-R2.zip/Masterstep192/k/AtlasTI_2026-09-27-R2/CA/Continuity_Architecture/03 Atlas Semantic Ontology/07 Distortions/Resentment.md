# Resentment

## Mechanical Definition
Resentment is accumulated emotional tension formed through prolonged unresolved misalignment, blocked needs, unmet expectations, or obstructed continuity.

Resentment hardens when movement toward resolution stops while emotional investment remains active.

---

## Real-World Definition
In real use, Resentment describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates Resentment
- betrayal
- unresolved conflict
- emotional neglect
- blocked communication
- repeated disappointment
- lack of reciprocity
- prolonged unmet needs

---

## What Sustains Resentment
- suppression
- avoidance
- pride
- lack of awareness
- emotional stagnation
- refusal to communicate
- unresolved grief

---

## What Resentment Produces
- bitterness
- emotional distancing
- hostility
- passive aggression
- relational fragmentation
- emotional exhaustion

---

## What Resolves Resentment
- truthful communication
- vulnerability
- recalibration
- forgiveness
- accountability
- mutual effort
- restored continuity

---

## What Happens Without Resolution
- emotional calcification
- relationship collapse
- identity hardening
- emotional numbness
- increased fragmentation