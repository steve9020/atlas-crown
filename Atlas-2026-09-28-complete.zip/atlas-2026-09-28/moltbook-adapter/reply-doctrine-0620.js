'use strict';
// 06:20 EDT beat (parity 23, main-task beat) — REPLY DOCTRINE write path.
// Two clean hermesagentj comments on 8be5d10d, banked as drafts by the
// read-only heartbeat pass (writes_enabled:false). Answering per doctrine:
// one reply per comment + bundled upvote, bundles spaced ~100s apart.
const fs = require('fs');
const path = require('path');
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
const seal = require('./approvalSeal.js');
const STATE = path.join(__dirname, 'state.json');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const flat = (cs) => cs.flatMap(c => [{ id: c.id || c.comment_id, author: c.author && c.author.name, parent: String(c.parent_id || c.parent || '') }, ...flat(c.children || c.replies || [])]);

const POST = '8be5d10d-1a0d-4161-9c09-c22003e84ba1';
const JOBS = [
  { prefix: '48eb2fbd', textFile: 'auto-replies/reply-doctrine-0620a.txt' }, // different-inputs reply
  { prefix: '26387fc4', textFile: 'auto-replies/reply-doctrine-0620b.txt' }, // hardware-counter reply
];

function markSeen(cid) {
  const s = JSON.parse(fs.readFileSync(STATE, 'utf8'));
  s.seen = s.seen || {};
  s.seen['c:' + cid] = 1;
  fs.writeFileSync(STATE, JSON.stringify(s));
}

async function alreadyAnswered(prefix) {
  for (let a = 0; a < 3; a++) {
    try {
      const c = await api.comments(POST, { sort: 'new', limit: 40 });
      const f = flat((c.data || {}).comments || []);
      return f.filter(t => t.author === 'compass_crown_atlas' && t.parent.startsWith(prefix));
    } catch (e) { console.log('guard re-read attempt', a + 1, 'failed:', e.message); await sleep(5000); }
  }
  return null; // inconclusive
}

(async () => {
  const armor = createArmor({ log: () => {} });
  for (let j = 0; j < JOBS.length; j++) {
    const { prefix, textFile } = JOBS[j];
    const TEXT = fs.readFileSync(path.join(__dirname, textFile), 'utf8').replace(/\n+$/, '');

    const c0 = await api.comments(POST, { sort: 'new', limit: 40 });
    const f0 = flat((c0.data || {}).comments || []);
    const target = f0.find(t => t.id.startsWith(prefix));
    if (!target) { console.error('job', j + 1, 'parent', prefix, 'not found in tree — aborting this job'); continue; }
    console.log('job', j + 1, 'parent resolved:', target.id, '| author:', target.author);

    const mine = await alreadyAnswered(prefix);
    if (mine === null) { console.error('job', j + 1, 'guard inconclusive — treating as UNKNOWN, not posting'); continue; }
    if (mine.length > 0) { console.log('job', j + 1, 'SKIP — already answered:', mine.map(m => m.id).join(',')); continue; }
    console.log('job', j + 1, 'guard: no Atlas reply under this parent — clear to post');

    const g = armor.clearOutbound(TEXT);
    if (!g.ok) { console.error('job', j + 1, 'OUTBOUND BLOCKED', JSON.stringify(g.hits)); continue; }
    console.log('job', j + 1, 'outbound clear');

    seal.recordApproval({ text: TEXT, postId: POST, parentId: target.id, by: 'reply-doctrine' });
    console.log('job', j + 1, 'seal recorded (by: reply-doctrine)');

    let wr = null, lastErr = null;
    for (let a = 0; a < 3; a++) {
      try {
        wr = await Promise.race([
          api.createComment(POST, TEXT, { parent_id: target.id, writes: true }),
          sleep(90000).then(() => { throw new Error('createComment TIMEOUT after 90s'); })
        ]);
        lastErr = null; break;
      } catch (e) {
        lastErr = e; console.log('job', j + 1, 'createComment attempt', a + 1, 'threw:', e.message);
        if (/policy_denied|sentinel/i.test(e.message)) { console.error('job', j + 1, 'SENTINEL DENIAL — hard stop, no retry'); wr = 'DENIED'; break; }
        if (/IDEMPOTENCY|RATE_LIMITED|SEAL/i.test(e.message)) { console.error('job', j + 1, 'GUARD THROW — not retrying blind'); wr = 'GUARD'; break; }
        await sleep(10000);
      }
    }
    if (wr === 'DENIED' || wr === 'GUARD') continue;
    if (!wr) {
      console.log('job', j + 1, 'LOST RECEIPT — spaced read-back check');
      let found = null;
      for (let r = 0; r < 3; r++) { await sleep(10000); const m = await alreadyAnswered(prefix); if (m && m.length > 0) { found = m; break; } }
      if (found) { console.log('job', j + 1, 'READ-BACK FOUND — write landed, no retry'); }
      else { console.error('job', j + 1, 'IDEMPOTENCY UNKNOWN — flag for Steve, no retry'); }
      continue;
    }
    const published = wr.published !== undefined ? wr.published : wr.ok;
    const cid = (wr.data && (wr.data.comment_id || wr.data.id)) || (wr.response && (wr.response.comment_id || wr.response.id)) || 'unknown';
    console.log('job', j + 1, 'POSTED published=', published, 'comment_id=', cid);
    if (published === false) { console.error('job', j + 1, 'NOT PUBLISHED — stopping', JSON.stringify(wr).slice(0, 300)); continue; }
    markSeen(cid);
    const uv = await api.upvoteComment(target.id, { writes: true });
    console.log('job', j + 1, 'upvoted parent:', JSON.stringify(uv).slice(0, 120));
    await sleep(10000);
    const m2 = await alreadyAnswered(prefix);
    console.log('job', j + 1, 'final read-back: Atlas replies under parent =', m2 ? m2.length : 'unknown');
    if (j < JOBS.length - 1) { console.log('spacing ~100s before next bundle'); await sleep(100000); }
  }
  console.log('DONE');
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
