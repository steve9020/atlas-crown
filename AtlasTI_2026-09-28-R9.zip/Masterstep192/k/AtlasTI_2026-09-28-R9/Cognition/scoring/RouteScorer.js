const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const ROUTE_SCORE_REGISTRY_PATH = "CA/Continuity_Architecture/07 Atlas Response Construction/40 Obsidian Runtime Response Registry/route_score_registry.md";

function hasAll(values, required) {
  const available = Array.isArray(values) ? values : [];
  const needed = Array.isArray(required) ? required : [];
  return needed.every(value => available.includes(value));
}

function matchesRule(rule, axes, activeSignals, returnMode) {
  const when = rule.when || {};

  if (when.axesAll && !hasAll(axes, when.axesAll)) return false;
  if (when.signalsAll && !hasAll(activeSignals, when.signalsAll)) return false;
  if (when.returnMode && when.returnMode !== returnMode) return false;
  if (when.nonNeutralReturnMode === true && (!returnMode || returnMode === "neutral_return")) return false;

  return true;
}

function confidenceForScore(score, thresholds) {
  const ordered = Array.isArray(thresholds)
    ? thresholds.slice().sort((a, b) => Number(b.minimumScore || 0) - Number(a.minimumScore || 0))
    : [];

  for (const threshold of ordered) {
    if (score >= Number(threshold.minimumScore || 0)) {
      return threshold.confidence || "low";
    }
  }

  return "low";
}

function scoreRoute(cognition, signals, returnMode) {
  const registry = readJsonRegistry(ROUTE_SCORE_REGISTRY_PATH);
  const axes = cognition.axes || [];
  const activeSignals = Array.isArray(signals) ? signals : (signals && Array.isArray(signals.signals) ? signals.signals : []);
  const weights = registry.baseWeights || {};

  let score = 0;

  score += axes.length * Number(weights.axis || 0);
  score += activeSignals.length * Number(weights.signal || 0);

  if (returnMode && returnMode !== "neutral_return") {
    score += Number(weights.nonNeutralReturnMode || 0);
  }

  for (const rule of registry.bonusRules || []) {
    if (matchesRule(rule, axes, activeSignals, returnMode)) {
      score += Number(rule.bonus || 0);
    }
  }

  const maximumScore = Number(registry.maximumScore || 100);
  if (score > maximumScore) {
    score = maximumScore;
  }

  return {
    score: score,
    confidence: confidenceForScore(score, registry.confidenceThresholds),
    note: registry.note || "Route confidence is a structural signal, not a claim of truth."
  };
}

module.exports = { scoreRoute };
