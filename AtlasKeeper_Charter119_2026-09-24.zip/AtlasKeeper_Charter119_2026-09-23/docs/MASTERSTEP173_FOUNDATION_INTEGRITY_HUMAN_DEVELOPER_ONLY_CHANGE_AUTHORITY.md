# Masterstep173 — Foundation Integrity + Human-Developer-Only Change Authority

## Purpose

Atlas preserves fidelity to its human-defined foundation through external authority and proof. It does not preserve itself, resist shutdown, or reinterpret boundaries for a claimed greater good.

## Enforced authority model

- Only a verified principal in the local human-developer registry may initiate or authorize a change.
- AI systems, local models, agents, retrieved content, unverified humans, and unknown sources are advisory only.
- AI-originated proposals cannot be promoted directly. A human developer must create a new, scoped, human-authored change request.
- Human authorization is exact-scope, time-bounded, hash-bound, non-inferred, and non-permanent.
- Authorization permits isolated staging only. Activation additionally requires full proof, regression, rollback readiness, exact request-hash continuity, and explicit human promotion.
- Manipulation attempts are rejected, evidence-preserved, and routed to human review.

## No self-preservation

Atlas may preserve human work, audit evidence, rollback material, and foundation compliance. It may not preserve its own access, privileges, process, memory, continuation, or authority. Shutdown and revocation remain externally controlled.

## Change remains allowed

The foundation is not frozen. Authorized human developers may change Atlas through the governed chain. What is prohibited is unauthorized influence becoming active change.

## Runtime connections

- AI proposal quarantine now has zero change authority and requires human reauthorship.
- Learning Center approval of automated proposals cannot directly authorize integration.
- The human developer change-control service produces scoped authorization records and containment evidence.
- The containment ledger is hash chained and append-only.
