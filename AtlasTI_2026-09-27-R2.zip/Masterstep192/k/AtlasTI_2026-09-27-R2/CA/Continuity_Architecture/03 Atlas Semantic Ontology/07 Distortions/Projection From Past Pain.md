# Projection From Past Pain

## Mechanical Definition
Projection from past pain occurs when earlier emotional injury shapes present interpretation so strongly that the current situation is experienced as repetition before evidence is complete.

---

## Real-World Definition
In real use, Projection From Past Pain describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates It
- memory triggers
- abandonment residue
- betrayal
- rejection
- unresolved attachment

---

## What It Produces
- anticipation
- guarding
- misread signals
- recursive expectation
- emotional certainty

---

## Distortion Pattern
Past continuity rupture is mapped onto present ambiguity.

---

## What Restores Clarity
- present evidence checking
- grief integration
- truth separation
- paced trust

---

## Connected Nodes
- [[memory_trigger_pressure]]
- [[abandonment_residue]]
- [[trust_collapse]]
- [[truth_separation_governance]]

---

## Core Principle
The past may explain the sensitivity without proving the present is repeating it.
