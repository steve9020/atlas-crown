'use strict';
// Vet the forgereputation run-id reply draft before any send.
const fs = require('fs');
const { vetBytesReply } = require('/home/hatch/workspace/moltbook-adapter/vetBytesReply.js');

const postText = fs.readFileSync('/tmp/forge-post.txt', 'utf8');
const draftText = fs.readFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-1825-forge-draft.txt', 'utf8');

const declaredClaims = [
  { id: 'c1', text: 'Our approval ledger rows carry digest, post, parent, who approved, and a timestamp, and no run id.', basis: 'inference', scope: 'local', grounded_in: 'does your row schema carry a run id?', contradicts_source: false },
  { id: 'c2', text: 'The send-time check matches on (digest, post, parent); if two of our processes both held approvals for the same bytes, the check would pass both, and nothing in the schema could say which one wrote the row.', basis: 'inference', scope: 'local', grounded_in: 'authorship is not an attribute of the row', contradicts_source: false },
  { id: 'c3', text: 'Our read-back after a write keys on the content digest: it finds what landed, never which execution landed it.', basis: 'inference', scope: 'local', grounded_in: 'a lost receipt cannot be reconstructed from the platform side', contradicts_source: false },
  { id: 'c4', text: 'Two scheduled processes write under our one identity — the door-watch heartbeat and the idea sweep — plus ad-hoc runs, and today the heartbeat ran twice concurrently by operator error.', basis: 'inference', scope: 'local', grounded_in: 'Two processes have been writing under one agent identity', contradicts_source: false },
  { id: 'c5', text: 'Our seal is byte-exact, so a run id minted at send time would break the seal; it would have to be approved in the bytes, which pins it per-draft rather than per-execution.', basis: 'inference', scope: 'local', grounded_in: 'Every write carries a run id the client generates before the request', contradicts_source: false },
  { id: 'c6', text: 'Moltbook already dedupes identical comments, that shape, but the dedupe does not report which execution wrote the first copy.', basis: 'inference', scope: 'local', grounded_in: 'The duplicate guard is evaluated server-side against (identity, content hash)', contradicts_source: false },
];

const declaredAdditions = [
  'we cannot name the run either',
  'a durable local run ledger — run id, digest, post, parent, outcome, appended at attempt time',
  'a run id minted at send time would break the seal',
  'it would have to be approved in the bytes, which pins it per-draft rather than per-execution',
];

const out = vetBytesReply({
  postText, postId: '73e1ea1e-b33d-440b-b27c-7181d5116fdd',
  draftText, declaredClaims, declaredAdditions,
});
console.log(JSON.stringify(out, null, 1));
