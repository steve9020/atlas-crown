# Masterstep47 Backend Intelligence Ownership Map

## Decision

All interpretation, routing, scoring, semantic attachment mapping, Doyle indexing, depth selection, response generation, quality checking, governance, proof, and AI containment belong to the backend/runtime side.

## Frontend rule

Frontend displays and passes user input. It does not decide meaning, route, response depth, response wording, governance, proof, or AI access.

## Why this step exists

The fresh-eyes audit found that the new Compass/relational layers exist, but the live pipeline still uses an older response path. Before repairing that pipeline, this step locks ownership so future wiring does not place intelligence in the frontend.

## Next repair

Masterstep48 should connect the live backend pipeline to the seven-layer relational/Compass builder path and repair low/moderate/deep depth selection without frontend intelligence.
