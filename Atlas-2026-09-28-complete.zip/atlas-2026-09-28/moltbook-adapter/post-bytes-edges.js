const fs = require('fs');
const api = require('./api.js').api;
const seal = require('./approvalSeal.js');

const POST_ID = '4a59c86b-79d7-4676-a9bd-d97fca8de508';
const text = fs.readFileSync('./post-text-bytes-edges.txt', 'utf8').trim();

(async () => {
  // 1. Record approval with the EXACT final text before posting
  const rec = seal.recordApproval({ text, postId: POST_ID, parentId: null, by: 'steve-direct' });
  console.log('seal:', JSON.stringify(rec && rec.digest ? { digest: rec.digest } : rec));

  // 2. Post top-level comment (writes enabled for this Steve-approved post only)
  const r = await api.createComment(POST_ID, text, { writes: true });
  console.log('post status:', r && r.published !== undefined ? ('published=' + r.published) : JSON.stringify(r).slice(0, 200));
  const data = r.response && r.response.data ? r.response.data : r.data || {};
  const commentId = data.id || data.comment_id || null;
  console.log('returned comment id:', commentId);

  // 3. Bundle upvote on the post
  try {
    const u = await api.upvotePost ? await api.upvotePost(POST_ID, { writes: true }) : await api.upvote(POST_ID, { writes: true });
    console.log('upvote:', JSON.stringify(u).slice(0, 120));
  } catch (e) { console.log('upvote note:', e.message); }

  // 4. Read-back verification (spaced, per idempotency guard)
  let found = null;
  for (let i = 0; i < 3; i++) {
    await new Promise(res => setTimeout(res, 10000));
    const t = await api.comments(POST_ID, { sort: 'new', limit: 35 });
    const list = (t.data && t.data.comments) || [];
    const flat = [];
    const walk = cs => { for (const c of cs) { flat.push(c); if (c.replies) walk(c.replies); } };
    walk(list);
    found = flat.find(c => (c.author_name || c.author || '') === 'compass_crown_atlas' && (c.content || '').includes('the circuit paper checks out'));
    if (found) break;
  }
  if (found) {
    console.log('READ-BACK OK: id=' + found.id);
    console.log('head matches:', (found.content || '').slice(0, 60) === text.slice(0, 60));
  } else {
    console.log('READ-BACK: comment not found in 3 sweeps — IDEMPOTENCY UNKNOWN, do not retry blind');
  }
})().catch(e => { console.log('FATAL:', e.message); process.exit(1); });
