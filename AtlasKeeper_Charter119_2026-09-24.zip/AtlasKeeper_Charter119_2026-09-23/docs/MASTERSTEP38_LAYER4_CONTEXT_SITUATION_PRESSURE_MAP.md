# Doyle Spire Layer 4 — Context / Situation Pressure

Masterstep38 closed keeper layer buildout. Layer 4 places situation/context pressure before meaning is assumed.

| ID | Sphere | Context markers | Wrong-route protection |
|---|---|---|---|
| L4S01 | Accumulation / Pileup | things pile up, everything at once, stacking up, too much at once | over-centering pileup example, turning all accumulation into identity failure |
| L4S02 | Silence / No Response | didn't text back, no answer, left on read, quiet | declaring rejection, generic reassurance |
| L4S03 | Tone Shift / Distance | seemed off, acted different, short reply, weird vibe | routing feared other-person anger as user anger, answering uncertainty with certainty |
| L4S04 | Demand / Favor / Obligation | keeps asking, favor, needs me, saying no | over-focusing self-worth when boundary/respect is stronger, shaming guilt |
| L4S05 | Mistake / Replay | replaying, said something wrong, messed up, keep thinking about it | punishment language, generic reassurance |
| L4S06 | Public Exposure / Being Seen | everyone saw, laughed at, in front of everyone, looked stupid | reinforcing humiliation, cold reassurance |
| L4S07 | Deadline / Time Pressure | deadline, due, running out of time, late | productivity advice only, making time pressure identity pressure |
| L4S08 | Mess / Chores / Maintenance | mess, dishes, laundry, cleaning | over-therapizing chores, giving only task advice |
| L4S09 | Financial / Bills | bills, rent, money, debt | minimizing real stakes, advice-only response |
| L4S10 | Communication / Texting | text, message, call, reply | misrouting feared anger as anger clarification, encouraging over-explaining |
| L4S11 | Comparison / Social Measurement | compared, everyone else, better than me, behind them | validating comparison as truth, generic enoughness without map |
| L4S12 | Unfinished / Avoided Task | putting it off, haven't started, unfinished, avoided | productivity lecture, shame reinforcement |

Layer rule: context pressure is placement only. Emotion/meaning/restoration are handled by later relation layers.
