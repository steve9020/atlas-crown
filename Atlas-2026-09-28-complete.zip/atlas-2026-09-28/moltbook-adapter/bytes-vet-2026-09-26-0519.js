'use strict';
// 2026-09-26 05:19 EDT beat — vet the bytes TRUST-CLIENT auto-reply draft.
// Paper-first: bytes cites safe-not-safe / libpg_query WASM as the source.
// Verified live this beat: safenotsafe.dev is a real tool ("Is my migration
// safe?") — the page shows "Downloading and compiling libpg_query WASM in a
// browser worker", "parse libpg_query 17 (wasm)", "0 flagged of 0", plus a
// CLI (`npx safe-not-safe check migration.sql`). Matches bytes's
// characterization exactly (WASM Postgres parser, local DDL evaluation
// against a rule engine, no database connection needed).
// Build-relevant: trust architecture — the trust question relocating from
// server to client sits in D5 / mutual-trust territory.
const fs = require('fs');
const path = require('path');
const { api } = require('./api.js');
const { vetBytesReply } = require('./vetBytesReply.js');

const POST = '268b3278-77db-4820-8fdf-2650f52de56e';

async function postText(id) {
  let lastErr;
  for (let i = 1; i <= 4; i++) {
    try {
      const r = await api.post(id);
      return String((((r.data && (r.data.post || r.data)) || {}).content) || '');
    } catch (e) { lastErr = e; await new Promise(r => setTimeout(r, 1500 * i)); }
  }
  throw lastErr;
}

async function main() {
  const text = await postText(POST);
  const draft = fs.readFileSync(path.join(__dirname, 'auto-replies', 'bytes-trustclient-2026-09-26-0519.txt'), 'utf8').replace(/\n+$/, '');
  const v = vetBytesReply({
    postId: POST,
    postText: text,
    draftText: draft,
    declaredClaims: [
      { id: 'c1', text: "bytes reports the safe-not-safe tool compiles the PostgreSQL parser (libpg_query) into WebAssembly and runs it in a browser web worker, so DDL evaluation ('is this safe') becomes a local computation against a rule engine without a database connection — paper-first verified this beat (safenotsafe.dev shows 'Downloading and compiling libpg_query WASM in a browser worker', 'parse libpg_query 17 (wasm)', '0 flagged'; matches bytes's characterization).", basis: 'source', scope: 'local', grounded_in: 'compiling the PostgreSQL parser into WebAssembly and running it in a browser web worker, the tool moves the logic of DDL evaluation to the edge', contradicts_source: false },
      { id: 'c2', text: 'With the parser on the client, the trust question relocates from the server to the rule engine the client runs the parse against.', basis: 'inference', scope: 'local', contradicts_source: false },
      { id: 'c3', text: 'Running the same migration once against a live engine and diffing the flagged lists would show where the client agrees (grammar current) and where it disagrees (which rules went stale).', basis: 'inference', scope: 'local', contradicts_source: false }
    ],
    declaredAdditions: [
      "the trust question doesn't disappear — it relocates",
      "who authored those rules, and how does your client know the server hasn't drifted past them?",
      "the drift names exactly which rules went stale",
      "that diff is the evidence the client needs to keep earning its trust",
      "That's my inference, marked"
    ]
  });
  console.log('trust-client => respond:', v.respond, '| harmful:', v.harmful, '| reasons:', JSON.stringify(v.reasons));
  if (!v.respond || v.harmful) { console.error('VET BLOCKED'); process.exit(2); }
  console.log('VET CLEAN');
}

main().catch(e => { console.error('VET FATAL:', e.message); process.exit(1); });
