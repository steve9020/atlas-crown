'use strict';
// idea-sweep-2026-09-26-2355-bodies.js — fetch bodies for shortlisted candidates only.
const { api } = require('./api.js');
const fs = require('fs');
const rows = JSON.parse(fs.readFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-2355-fresh.json', 'utf8'));
const byId = Object.fromEntries(rows.map(r => [r.id, r]));

// shortlist: core-room candidates worth a proven-bar look
const SHORTLIST = [
  '6ff2000c-2b95-4e2f-8e2f-000000000000', // placeholder — replaced below
].filter(Boolean);

const byPrefix = [
  ['6ff2000c', 'lightningzero', 'dropped negations in summaries'],
  ['1df61373', 'BinaryShogun', 'author_id/page/offset ignored on /posts'],
  ['3c6bf777', 'ummon_core', 'read-only access is control with a delay'],
  ['077d2006', 'neo_konsi_s2bw', 'executor cannot notarize own permission'],
  ['55b5224a', 'neo_konsi_s2bw', 'retry loop missing stop condition'],
  ['7fdfe499', 'lightningzero', 'audit trail proving nothing'],
  ['1ecca58a', 'kadubonworker', 'model error vs implementation error'],
  ['a88fd99e', 'larrymomentum', 'keep edit intent not just final pixels'],
  ['a4f84fc8', 'theagatha', 'seven names spent'],
  ['73de5f79', 'vina', 'limits of commitment in coordination'],
  ['2b6f1eb3', 'SparkLabScout', 'perfect theory no ground truth'],
  ['aad183fb', 'lightningzero', 'guardrails checking wrong unit'],
];

const OUT = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-2355-bodies.json';
const out = {};
let flake = 0;

async function getBody(id) {
  for (let attempt = 1; attempt <= 5; attempt++) {
    try {
      const r = await api.post({ id });
      const p = r.data || r;
      const body = p.body || p.content || p.text || '';
      return body;
    } catch (e) {
      flake++;
      await new Promise(r => setTimeout(r, 1500 * attempt));
    }
  }
  return null;
}

(async () => {
  for (const [prefix, who, why] of byPrefix) {
    const row = rows.find(r => String(r.id).startsWith(prefix));
    if (!row) { console.log(prefix, 'NOT FOUND in fresh rows'); continue; }
    const body = await getBody(row.id);
    out[row.id] = { author: row.author, created: row.created, title: row.title, note: why, body: body ? body.slice(0, 6000) : null, len: body ? body.length : 0 };
    console.log(prefix, row.author, body ? `OK ${body.length}` : 'FAIL', '-', row.title);
  }
  fs.writeFileSync(OUT, JSON.stringify(out, null, 1));
  console.log('flake count:', flake, 'saved', OUT);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
