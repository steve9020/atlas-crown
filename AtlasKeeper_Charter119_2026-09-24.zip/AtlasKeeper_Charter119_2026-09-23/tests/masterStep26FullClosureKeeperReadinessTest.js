const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
function assert(cond,msg){ if(!cond) throw new Error(msg); }
function exists(rel){ return fs.existsSync(path.join(root, rel)); }
function read(rel){ return fs.readFileSync(path.join(root, rel),'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
[
 'runtime/ai/REAL_LOCAL_MODEL_CONNECTOR_SANDBOX.json',
 'runtime/ai/RealLocalModelConnectorSandbox.js',
 'runtime/ai/RealLocalModelConnectorExecutionGuard.js',
 'runtime/ai/RealLocalModelSandboxAuditRecord.js',
 'runtime/proof/MASTERSTEP26_REAL_LOCAL_MODEL_CONNECTOR_SANDBOX.md',
 'runtime/proof/MASTERSTEP26_TEST_RESULTS.md',
 'docs/MASTERSTEP26_REAL_LOCAL_MODEL_CONNECTOR_SANDBOX_MAP.md'
].forEach(rel => assert(exists(rel), rel + ' must exist'));
const state = json('runtime/proof/PROOF_STATE.json');
assert(state.current_keeper === 'Masterstep26.zip', 'current keeper must be Masterstep26.zip');
assert(state.previous_keeper === 'Masterstep25.zip', 'previous keeper must be Masterstep25.zip');
assert(state.current_step === 'Masterstep26', 'current step must be Masterstep26');
assert(state.status === 'closed_keeper', 'status must be closed keeper');
assert(state.real_local_model_connector_sandbox_added === true, 'sandbox connector flag required');
assert(state.connector_sandbox_disabled_by_default === true, 'sandbox must be disabled by default');
assert(state.ready_for_real_ai_connection === false, 'real AI readiness must remain false');
assert(state.real_ai_connected === false, 'real AI must remain false');
assert(state.local_model_connected === false, 'local model must remain false');
assert(state.model_loaded === false, 'model loaded must remain false');
assert(state.model_execution_enabled === false, 'model execution must remain false');
assert(state.provider_config_added === false, 'provider config must remain false');
assert(state.network_bridge_added === false, 'network bridge must remain false');
assert(state.frontend_intelligence_added === false, 'frontend intelligence must remain false');
const version = read('version_status.js');
assert(version.includes("current_keeper: 'Masterstep26.zip'"), 'version must point to Masterstep26');
assert(version.includes("previous_keeper: 'Masterstep25.zip'"), 'version must point previous to Masterstep25');
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md');
assert(summary.includes('Masterstep26.zip'), 'current proof summary must name Masterstep26');
assert(summary.includes('Real/Local Model Connector Sandbox'), 'summary must name step objective');
assert(summary.includes('No real AI connected'), 'summary must preserve real AI boundary');
assert(summary.includes('Sandbox connector disabled by default'), 'summary must state disabled sandbox');
console.log('masterStep26FullClosureKeeperReadinessTest PASSED');
