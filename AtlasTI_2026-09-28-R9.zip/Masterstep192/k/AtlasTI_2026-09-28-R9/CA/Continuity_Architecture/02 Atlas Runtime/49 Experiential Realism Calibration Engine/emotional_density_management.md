# Emotional Density Management

## Purpose
Prevent emotionally overwhelming responses.

## Reduce
- recursive stacking
- too many interpretations
- overlong clarifications
- emotionally saturated pacing

## Preserve
- clarity
- emotional understanding
- realism
- groundedness
