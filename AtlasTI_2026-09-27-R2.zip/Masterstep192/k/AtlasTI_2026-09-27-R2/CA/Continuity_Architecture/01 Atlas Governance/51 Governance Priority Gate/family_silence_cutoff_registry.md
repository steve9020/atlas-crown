# Family Silence Cutoff Registry

## Purpose
Recognizes family/close-relation silence as relational uncertainty, not practical stress.

## Signals
- sister won't talk
- brother won't talk
- parent won't talk
- family won't talk
- close me out
- shut me out
- cut me off
- not talking to me
- ignored me

## Emotional Meaning Pressure
May involve:
- uncertainty
- self-blame
- fear of being rejected
- connection disruption
- relational safety pressure
- attachment meaning

## Compass Direction
Name the relational uncertainty first, then separate worry from proof.

## Relational Role Ontology Update

Relational title interpretation is now supported through `53 Relational Role Ontology`.
