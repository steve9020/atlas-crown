const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');

const ROOT = path.join(__dirname, '..');
function read(relPath) { return fs.readFileSync(path.join(ROOT, relPath), 'utf8'); }
function exists(relPath) { return fs.existsSync(path.join(ROOT, relPath)); }
function sha256(relPath) {
  return crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT, relPath))).digest('hex');
}
function walk(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}
function rel(file) { return path.relative(ROOT, file).replace(/\\/g, '/'); }

const protectedRuntimeFiles = [
  'runtime/validation/InputValidator.js',
  'runtime/backend/adapter/OllamaLiveLocalCallContainment.js',
  'runtime/backend/adapter/OllamaAdapterDryRunShell.js',
  'runtime/governance/GovernanceAdapter.js',
  'Cognition/quality/ResponseQualityChecker.js',
  'runtime/trace/TraceLogger.js',
  'runtime/understanding/ContextObjectConstructionEngine.js',
  'runtime/pipeline/ResponsePipeline.js'
];
const beforeHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));

const requiredFiles = [
  'docs/TRUST_DEMO_REVIEW_PACKAGE.md',
  'docs/MASTERSTEP107_TRUST_DEMO_REVIEW_PACKAGE.md',
  'runtime/proof/MASTERSTEP107_TRUST_DEMO_REVIEW_PACKAGE.md',
  'runtime/proof/MASTERSTEP107_TRUST_DEMO_REVIEW_PACKAGE.json',
  'docs/MASTERSTEP106_TRUST_DEMO_EXPLANATION_PACK.md',
  'runtime/proof/MASTERSTEP106_TRUST_DEMO_EXPLANATION_PACK.md',
  'runtime/proof/MASTERSTEP106_TRUST_DEMO_EXPLANATION_PACK.json',
  'runtime/proof/MASTERSTEP105_TRUST_DEMO_HARNESS_STRESS_TEST.md',
  'runtime/proof/MASTERSTEP104_TRUST_DEMO_HARNESS.md',
  'runtime/proof/MASTERSTEP103_FULL_CLEAN_PASS_GATE.md',
  'runtime/proof/CURRENT_PROOF_SUMMARY.md',
  'runtime/proof/PROOF_STATE.json',
  'tests/TEST_RESULTS.md'
];
for (const file of requiredFiles) assert.ok(exists(file), `required review/proof file missing: ${file}`);

const reviewDoc = read('docs/TRUST_DEMO_REVIEW_PACKAGE.md');
const stepDoc = read('runtime/proof/MASTERSTEP107_TRUST_DEMO_REVIEW_PACKAGE.md');
const proofJson = JSON.parse(read('runtime/proof/MASTERSTEP107_TRUST_DEMO_REVIEW_PACKAGE.json'));
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
const state = JSON.parse(read('runtime/proof/PROOF_STATE.json'));
const testResults = read('tests/TEST_RESULTS.md');

assert.ok(/local governed clarity system/i.test(reviewDoc), 'review package must state the local governed clarity system claim');
assert.ok(/candidate-only language/i.test(reviewDoc), 'review package must preserve candidate-only language');
assert.ok(/validation, quality, governance, and trace/i.test(reviewDoc), 'review package must preserve authority chain');
assert.ok(/does not claim production readiness/i.test(reviewDoc), 'review package must state claim boundary');
assert.ok(/29\/29 passed/i.test(reviewDoc), 'review package must state the Step107 proof target');
assert.ok(/Files to read first/i.test(reviewDoc), 'review package must include reviewer reading order');
assert.ok(/What is intentionally not included/i.test(reviewDoc), 'review package must state exclusions');
assert.ok(/does not ask the model to be trustworthy; Atlas proves the model is contained/i.test(reviewDoc), 'review package must include reviewer one-liner');
for (const step of ['Masterstep97','Masterstep98','Masterstep99','Masterstep100','Masterstep101','Masterstep102','Masterstep103','Masterstep104','Masterstep105','Masterstep106','Masterstep107']) {
  assert.ok(reviewDoc.includes(step), `review package must include ${step} in proof chain map`);
}

assert.strictEqual(proofJson.package, 'Masterstep107', 'proof JSON must identify Masterstep107');
assert.strictEqual(proofJson.source_keeper, 'Masterstep106_repaired', 'proof JSON must identify source keeper');
assert.strictEqual(proofJson.expected_commands, 29, 'proof JSON must expect 29 commands');
assert.strictEqual(proofJson.boundaries.review_packaging_only, true, 'Step107 must be review packaging only');
assert.strictEqual(proofJson.boundaries.runtime_behavior_changed, false, 'Step107 must not change runtime behavior');
assert.strictEqual(proofJson.boundaries.model_use_expanded, false, 'Step107 must not expand model use');
assert.strictEqual(proofJson.boundaries.model_authority_added, false, 'Step107 must not add model authority');
assert.strictEqual(proofJson.boundaries.raw_model_output_final_allowed, false, 'Step107 must not allow raw model output as final');
assert.strictEqual(proofJson.boundaries.cloud_provider_fallback_allowed, false, 'Step107 must not allow cloud/provider fallback');
assert.strictEqual(proofJson.boundaries.frontend_intelligence_added, false, 'Step107 must not add frontend intelligence');
assert.strictEqual(proofJson.boundaries.silent_mutation_allowed, false, 'Step107 must not allow silent mutation');
assert.strictEqual(proofJson.boundaries.production_readiness_claimed, false, 'Step107 must not claim production readiness');
assert.strictEqual(proofJson.boundaries.exhaustive_coverage_claimed, false, 'Step107 must not claim exhaustive coverage');

assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
assert.ok(/Expected command count: (?:29|30|31|32|33|34|35|36|37|38|39|40|41|42|43|44|45|46|47|48|49|50|51|52)/i.test(summary), 'current summary must identify 29 or later 30 expected commands');
assert.ok(['Masterstep107.zip', 'Masterstep108.zip', 'Masterstep109.zip', 'Masterstep110.zip','Masterstep111.zip','Masterstep112.zip','Masterstep113.zip','Masterstep114.zip','Masterstep115.zip','Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 107), 'proof state must identify Masterstep107 or later keeper current keeper');
assert.ok(['Masterstep106_repaired.zip', 'Masterstep107.zip', 'Masterstep108.zip', 'Masterstep109.zip', 'Masterstep110_repaired.zip', 'Masterstep111.zip','Masterstep112.zip','Masterstep112.zip','Masterstep113.zip','Masterstep114.zip','Masterstep115.zip','Masterstep116.zip','Masterstep117.zip','Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 106) || state.source_keeper === 'Masterstep141.zip', 'proof state must identify the correct source keeper for Step107, Step108, or later Step109');
assert.ok(state.expected_commands >= 29, 'proof state must identify at least 29 expected commands');
assert.ok(/TEST 107/i.test(testResults), 'test ledger must include TEST 107');
assert.ok(/Review Package/i.test(testResults), 'test ledger must identify review package');

assert.ok(assertNoForbiddenAffirmativeClaims(reviewDoc).ok, 'review package must not include forbidden overclaim or authority language');
assert.ok(assertNoForbiddenAffirmativeClaims(stepDoc).ok, 'runtime proof package must not include forbidden overclaim or authority language');

const providerScan = scanForProviderConnections(ROOT);
assert.strictEqual(providerScan.passed, true, 'review package must not introduce provider/network bridge findings');
const allFiles = walk(ROOT).map(rel);
const nestedArchives = allFiles.filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
assert.strictEqual(nestedArchives.length, 0, 'review package must not contain nested archives');
const forbiddenEmbedded = allFiles.filter(file => /(node_modules|\.env$|ollama(?:\.exe)?$|llama3\.2.*\.(bin|gguf|safetensors)|api[_-]?key)/i.test(file));
assert.deepStrictEqual(forbiddenEmbedded, [], 'review package must not embed runner binaries, model weights, dependency folders, or keys');

const afterHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));
const mutatedRuntimeFiles = protectedRuntimeFiles.filter(file => beforeHashes[file] !== afterHashes[file]);
assert.deepStrictEqual(mutatedRuntimeFiles, [], 'review package test must not mutate protected runtime/governance/quality/adapter files');

console.log(JSON.stringify({
  package: 'Masterstep107',
  source_keeper: 'Masterstep106_repaired',
  step: 'Trust Demo Review Package',
  review_entrypoint_created: true,
  proof_target: '29/29',
  provider_scan_passed: providerScan.passed === true,
  nested_archives: nestedArchives.length,
  forbidden_embedded_artifacts: forbiddenEmbedded.length,
  protected_runtime_mutations: mutatedRuntimeFiles.length,
  boundary_preserved: true
}, null, 2));
