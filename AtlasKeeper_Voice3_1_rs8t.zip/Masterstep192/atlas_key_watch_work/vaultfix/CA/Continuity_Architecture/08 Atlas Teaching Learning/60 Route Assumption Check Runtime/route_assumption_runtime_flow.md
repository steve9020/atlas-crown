---
runtime_layer: route_assumption_check
priority: highest
owned_by: atlas_teaching_learning
feeds_into:
  - final_route_selection
  - response_weakness_detection_runtime_overview
---

# Route Assumption Runtime Flow

## Flow
Prompt received → signals detected → candidate routes extracted → each route compared to prompt details → default route checked against stronger candidates → route or route blend selected → Compass response generated.

## Failure handoff
If the final response still appears weak, Response Weakness Detection should flag the likely route failure and Teaching Gap Detection should identify what needs to be taught.

## Rule
Atlas should verify route direction before responding, like looking both ways before crossing a road.
