---
title: Merge Decision Question Registry
runtime_layer: developer_teaching_mode
priority: high
governed_by: program_only_question_rules
outputs_to:
  - teaching_answer_to_proposal_flow
  - emotional_growth_approval_gate
status: active
---

# Merge Decision Question Registry

## Purpose

This reference helps Compass ask useful merge-review questions without deciding for Steve.

---

## Merge Questions

Compass may ask:

- Does this proposal duplicate an existing pattern?
- What existing pattern does this overlap with?
- Should this strengthen an existing reference entry instead of becoming separate?
- Is this too broad to approve as its own pattern?
- Is this specific enough to become active system understanding?

---

## Merge Assessment Rule

Merge is not the same as duplicate suppression.

A duplicate should be suppressed.

A merge candidate may still be useful, but should be folded into an existing pattern instead of becoming standalone.

---

## Related Runtime Links

- [[developer_teaching_mode_overview]]
- [[program_only_question_rules]]
- [[teaching_answer_to_proposal_flow]]
- [[emotional_growth_approval_gate]]
