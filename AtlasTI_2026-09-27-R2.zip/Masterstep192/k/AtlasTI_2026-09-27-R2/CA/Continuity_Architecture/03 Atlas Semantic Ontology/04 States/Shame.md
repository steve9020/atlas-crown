# Shame

## Mechanical Definition
Shame is painful identity-based perception that the self is fundamentally flawed, inadequate, unworthy, or unacceptable.

Unlike guilt, which focuses on behavior, shame attacks identity itself.

Shame distorts continuity by fusing mistakes, rejection, or perceived inadequacy into the core self-structure.

---

## Real-World Definition
In real use, Shame describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates Shame
- rejection
- humiliation
- emotional neglect
- betrayal
- comparison
- criticism
- conditional love
- unresolved guilt
- traumatic invalidation

---

## What Sustains Shame
- secrecy
- fear of exposure
## Related Flows
- [[Fragmentation Flows]]
- [[Reinforcement Flows]]
- [[Recovery Flows]]
- [[Stabilization Flows]]

## Related Reverse Flows
- [[Shame Reverse Flows]]