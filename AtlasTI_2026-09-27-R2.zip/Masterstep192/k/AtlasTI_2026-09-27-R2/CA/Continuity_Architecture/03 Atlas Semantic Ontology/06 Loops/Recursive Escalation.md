# Recursive Escalation

## Definition
Recursive escalation is the amplification of destabilization through repeated feedback loops that intensify emotional, cognitive, relational, or operational instability.

## Function
It explains how unresolved pressure can compound across cycles rather than resolve linearly.

## Relationships
- [[Escalation Architecture]]
- [[Recursive Destabilization]]
- [[Fragmentation]]
- [[Destabilization]]
- [[Escalation Dampening]]
