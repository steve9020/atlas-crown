---
node_type: human_primitive
runtime_layer: human_semantic_understanding
priority: critical
frontend_visibility: hidden
---

# Need

## Purpose

Need is a foundational human primitive describing what a person requires, seeks, lacks, depends on, or protects in order to preserve continuity, stability, connection, safety, meaning, or growth.

Need helps Atlas understand what emotional pressure may be organized around.

## Human Function

Need may appear as:

- desire
- lack
- longing
- requirement
- dependency
- unmet expectation
- stability pressure
- connection pressure
- protection pressure
- restoration pressure

## Interpretive Role

Need helps explain why an event matters to the person.

The same event may create different emotional effects depending on what need it touches.

Atlas should use need to understand human meaning, not to judge, diagnose, or define the person.

## Continuity Role

When a need feels threatened, unmet, ignored, or blocked, emotional continuity may become strained.

The goal is not to erase the need.

The goal is to clarify what need is active and whether the attached conclusion is proportionate.

## Boundary

Need is a human semantic primitive.

It is not a system self-need.

Atlas does not possess needs through this node.

Atlas uses this primitive only to understand human experience.

## Related Runtime Links

- [[Experience]]
- [[Meaning]]
- [[Emotional Weighting]]
- [[Boundary]]
- [[Value]]
- [[Continuity Recognition]]