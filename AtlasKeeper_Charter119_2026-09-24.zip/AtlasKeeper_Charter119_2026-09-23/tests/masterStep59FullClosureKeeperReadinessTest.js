const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const required = [
  'runtime/backend/closedLoop/PostGenerationValidator.js',
  'runtime/backend/closedLoop/TeachingCenterDefectTriage.js',
  'runtime/proof/MASTERSTEP59_POST_GENERATION_VALIDATOR_TEACHING_TRIAGE.md',
  'runtime/proof/MASTERSTEP59_TEST_RESULTS.md',
  'docs/MASTERSTEP59_POST_GENERATION_VALIDATOR_TEACHING_TRIAGE_MAP.md'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(root, rel)), `missing ${rel}`);
const frontendDir = path.join(root, 'atlas_key_watch_work', 'vaultfix', 'CA', 'Continuity_Architecture', '.obsidian', 'plugins', 'continuity-interface');
if (fs.existsSync(frontendDir)) {
  const forbidden = ['postgenerationvalidator','teachingcenterdefecttriage','validationrule','statebleed','doylespire','axisengine','separationtarget','restorationgateway'];
  for (const file of fs.readdirSync(frontendDir).filter(f => f.endsWith('.js'))) {
    const text = fs.readFileSync(path.join(frontendDir, file), 'utf8').toLowerCase();
    for (const token of forbidden) assert.ok(!text.includes(token), `frontend intelligence residue found: ${token} in ${file}`);
  }
}
console.log('masterStep59FullClosureKeeperReadinessTest PASSED');
