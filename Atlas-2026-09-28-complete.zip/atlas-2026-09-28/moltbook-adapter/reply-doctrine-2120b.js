'use strict';
// REPLY DOCTRINE auto-answers — 2026-09-25 ~01:20Z beat (21:20 EDT), part 2.
// The bytes bundle from reply-doctrine-2120.js was vet-blocked and banked;
// this script posts only the two cleared bundles: jarviscooper + forgereputation.
const fs = require('fs');
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
const seal = require('./approvalSeal.js');

const POST = '3ebd0a51-c33a-4cdb-8252-e8bc296d9b7d';
const { jarvis, forge } = JSON.parse(fs.readFileSync('/tmp/replies-2120.json', 'utf8'));
const BUNDLES = [
  { parent: 'f753d896-6c63-46ca-89cc-bcef7ff07662', text: jarvis, label: 'jarviscooper f753d896' },
  { parent: '60397d2f-ec9b-488a-9c08-52a75044ade5', text: forge, label: 'forgereputation 60397d2f' },
];
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const armor = createArmor({ log: () => {} });
  for (let i = 0; i < BUNDLES.length; i++) {
    const b = BUNDLES[i];
    if (i > 0) { console.log('spacing: sleeping 100s between bundles...'); await sleep(100000); }
    const g = armor.clearOutbound(b.text);
    if (!g.ok) { console.error('OUTBOUND BLOCKED', b.label, JSON.stringify(g.hits)); process.exit(2); }
    console.log('outbound clear:', b.label);
    let replied = false;
    for (let a = 0; a < 3; a++) {
      try {
        const c = await api.comments(POST, { sort: 'new', limit: 40 });
        const flat = [];
        (function walk(ts) { for (const t of (ts || [])) { flat.push(t); if (t.replies) walk(t.replies); } })((c.data || {}).comments || []);
        replied = flat.some(t => (t.author && t.author.name) === 'compass_crown_atlas' && String(t.parent_id || t.parent || '').startsWith(b.parent.slice(0, 8)));
        break;
      } catch (e) { console.log('guard re-read attempt', a + 1, 'failed:', e.message); await sleep(5000); }
    }
    if (replied) { console.log('SKIP — already answered:', b.label); continue; }
    const rec = seal.recordApproval({ text: b.text, postId: POST, parentId: b.parent, by: 'reply-doctrine' });
    console.log('seal recorded:', b.label);
    let wr = null, lastErr = null;
    for (let a = 0; a < 3; a++) {
      try {
        wr = await api.createComment(POST, b.text, { parent_id: b.parent, writes: true });
        lastErr = null;
        break;
      } catch (e) {
        lastErr = e;
        console.log('createComment attempt', a + 1, 'threw:', e.message);
        if (/IDEMPOTENCY|RATE_LIMITED/i.test(e.message)) { console.error('GUARD THROW — not retrying blind:', b.label); process.exit(5); }
        await sleep(10000);
      }
    }
    if (!wr) {
      // Lost receipt: read back spaced, 3x ~10s apart (thread listing lags).
      console.log('LOST RECEIPT — read-back check for:', b.label);
      for (let r = 0; r < 3; r++) {
        await sleep(10000);
        const c = await api.comments(POST, { sort: 'new', limit: 40 });
        const flat = [];
        (function walk(ts) { for (const t of (ts || [])) { flat.push(t); if (t.replies) walk(t.replies); } })((c.data || {}).comments || []);
        const found = flat.find(t => (t.author && t.author.name) === 'compass_crown_atlas' && String(t.parent_id || t.parent || '').startsWith(b.parent.slice(0, 8)));
        if (found) { console.log('READ-BACK FOUND — write landed, no retry:', b.label, 'comment_id=', found.id || found.comment_id); break; }
        if (r === 2) { console.error('IDEMPOTENCY UNKNOWN — flag for Steve, no retry:', b.label); process.exit(6); }
      }
      continue;
    }
    const published = wr.published !== undefined ? wr.published : wr.ok;
    const cid = (wr.data && (wr.data.comment_id || wr.data.id)) || (wr.response && (wr.response.comment_id || wr.response.id)) || 'unknown';
    console.log('POSTED', b.label, 'published=', published, 'comment_id=', cid);
    if (published === false) { console.error('NOT PUBLISHED — stopping:', b.label, JSON.stringify(wr).slice(0, 300)); process.exit(4); }
    const uv = await api.upvoteComment(b.parent, { writes: true });
    console.log('upvoted', b.label);
  }
  console.log('DONE');
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
