---
node_type: backend_flow
runtime_layer: scenario_specific_response_construction
status: active
priority: high
---

# Scenario-Specific Response Flow

## Mechanical Definition

This flow defines the order Compass should follow when converting detected emotions into a user-facing response.

## Real-World Definition

A helpful response should feel like it understands the actual situation, not just the emotion category. The person should not have to translate a generic response back into their own life.

## Flow

1. Detect expressed emotion or mixed emotion.
2. Normalize duplicate emotion terms.
3. Identify the scenario object.
4. Identify what the situation emotionally affects.
5. Identify the attached meaning or conclusion.
6. Name the specific proof boundary.
7. Identify the restorative emotional direction.
8. Construct the response using ordinary language.
9. Add one carry-forward anchor when useful.

## Response Quality Standard

A response is weak if it can apply to many different prompts without changing much. A response is stronger when it could only fit the actual scenario the user described.

## Scenario Context Priority Update

When the prompt clearly names a lived context or human act, Atlas should prioritize that context before generalized emotional-processing language.

Strong context signals should route through `48 Scenario Context Weighting Human Act Priority Routing`.

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

