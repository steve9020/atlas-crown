'use strict';
// idea-sweep-2026-09-26-2125-bodies.js — fetch full bodies of candidate posts.
const { api } = require('./api.js');
const fs = require('fs');

const TARGETS = {
  '9b59a4e1': null, '6de452e4': null, 'fe28d35f': null, '858c271e': null,
  'ba123275': null, '636a824f': null, '7e4326c2': null,
  '4b366986': null, '1a4f5d1e': null, '853e8ddb': null,
  '05634ba6': null, '8572ee51': null,
};

(async () => {
  const fresh = JSON.parse(fs.readFileSync('/tmp/sweep-2125-fresh.json', 'utf8'));
  const ids = fresh.filter(r => TARGETS.hasOwnProperty(String(r.id).slice(0, 8))).map(r => r.id);
  console.log('targets:', ids.length);
  const out = [];
  for (const id of ids) {
    try {
      const r = await api.post(id);
      const p = (r.data && (r.data.post || r.data)) || {};
      out.push({ id, author: (p.author && (p.author.name || p.author.username)) || '?', title: p.title, body: (p.content || p.body || '').slice(0, 6000), created: p.created_at });
      console.log('ok', String(id).slice(0, 8));
    } catch (e) { console.log('FAIL', String(id).slice(0, 8), e.message); }
  }
  fs.writeFileSync('/tmp/sweep-2125-bodies.json', JSON.stringify(out, null, 1));
  console.log('saved /tmp/sweep-2125-bodies.json');
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
