# Crown Phase 2 — Backend-Only Predicate Semantics

## Boundary
Built directly on the clean Crown Phase 1 package.

Frontend/public/CA hash comparison against Phase 1: **0 changes**.

## Added backend primitive
`runtime/governance/crown/CrownPredicateResult.js`

It provides an immutable predicate result bound to:
- predicate ID
- predicate version
- deterministic input digest
- result: PASS / FAIL / UNKNOWN
- evaluator identity
- context reference
- evidence references

Unrecognized result states normalize to **UNKNOWN**, never PASS.

## Non-inheritance enforcement
`satisfiesPredicate()` requires exact agreement on:
- predicate ID
- predicate version
- PASS state
- required input digest, when supplied

Therefore:
- PASS(A) cannot satisfy B.
- PASS(v1) cannot satisfy v2.
- PASS for input X cannot satisfy input Y.
- FAIL cannot satisfy a PASS requirement.
- UNKNOWN cannot satisfy a PASS requirement.

No cross-version equivalence mechanism has been added yet, so there is no implicit
v1→v2 inheritance path.

## Transition integration
`CrownTransitionEnvelope.js` now normalizes every supplied predicate result through
the Crown predicate-result constructor. Predicate results embedded in the transition
therefore carry explicit identity/version/input binding.

This does not grant route authority or output authority.

## Deterministic witnesses
- Existing Phase 1 provenance/transition witness: PASS
- New `tests/crownPhase2PredicateSemanticsTest.js`: PASS

The new witness explicitly attempts:
- cross-predicate PASS inheritance
- cross-version PASS inheritance
- cross-input PASS inheritance
- UNKNOWN promotion
- FAIL promotion
- missing predicate version

All are rejected as required.

## Existing Atlas regression
`node proof/runCurrentProof.js`

- total: 100
- passed: 100
- failed: 0
- exit: 0
- current manifest generated

## Frontend zero-diff
Compared Phase 1 and Phase 2 hashes across:
- `frontend/`
- `public/`
- `public_demo_shell/`
- `CA/`

Changed files: **0**

## Phase 2 status
**PASS**

Phase 2 establishes executable predicate identity/version semantics and blocks
silent PASS inheritance. It does not yet establish authorization/applicability,
equivalence, canonical supersession, root epochs, execution tokens, recovery
authority, or oracle qualification.

## Next controlled phase
Phase 3: bind existing human approval/capability controls to an explicit
authorization + applicability contract carried by the Crown transition envelope.
