{
  "registry": "machinery_leakage_prevention_registry",
  "master_step": "5A",
  "title": "Machinery Leakage Prevention",
  "status": "active",
  "purpose": "Prevent backend machinery, runtime labels, route labels, axes, scoring, registries, and governance mechanics from appearing in human-facing Compass output.",
  "core_rule": "Deep internal understanding; clean human-facing language; no visible machinery.",
  "forbidden_output": [
    "route scores or route explanations",
    "axis or axes labels as frontend truth",
    "runtime, pipeline, backend, registry, trace, or governance adapter language",
    "internal module names such as context_integrity or semantic_fusion",
    "technical scoring or confidence mechanics"
  ],
  "required_output": [
    "human-facing language",
    "natural meaning explanation",
    "pressure/context wording instead of module labels",
    "no machinery leakage even when backend signals are high"
  ],
  "integration": {
    "runtime_file": "Cognition/response/MachineryLeakagePrevention.js",
    "pipeline_key": "machinery_leakage_prevention",
    "test_file": "tests/machineryLeakagePreventionTest.js"
  }
}
