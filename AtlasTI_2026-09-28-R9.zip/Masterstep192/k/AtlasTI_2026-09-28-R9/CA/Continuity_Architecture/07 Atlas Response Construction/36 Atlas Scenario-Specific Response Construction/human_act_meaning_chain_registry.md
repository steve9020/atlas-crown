---
runtime_layer: atlas_scenario_specific_response_construction
registry_type: human_act_meaning_chain
status: scaffold_ready_for_teaching
purpose: Establish the order Atlas should use to understand what a prompt is saying before choosing emotional route language.
governed_by:
  - scenario_context_object_registry
  - scenario_specific_response_flow
---

# Human Act Meaning Chain Registry

This registry defines the interpretation sequence Atlas should use when a user describes a situation.

It is a scaffold only. Specific taught patterns should be added later.

## Core Chain

Atlas should read prompts through this chain:

```text
what human act happened
→ what relational expectation was attached
→ what response failed or changed
→ what meaning the user attached to themselves
→ what needs separated
```

## Runtime Purpose

This prevents Atlas from over-prioritizing single emotion words before understanding the situation.

Atlas should not begin with only:

```text
emotion word detected
→ category route
```

Atlas should first ask:

```text
What did the user do, reveal, ask, risk, attempt, protect, repair, confess, express, or carry?
```


## Scenario Object Index Relationship

The active scenario object index currently contains 45 reserved top-level objects in [[scenario_context_object_registry]].

This registry does not teach those objects yet. It defines the interpretation chain that each object must eventually follow:

```text
what human act happened
→ what relational expectation was attached
→ what response failed or changed
→ what meaning the user attached to themselves
→ what needs separated
```

Atlas should use this chain as the required teaching format when those 45 objects are populated later.

## Required Future Teaching Fields

```text
human_act_signal_language:
expected_relational_response:
failed_or_changed_response:
self_meaning_risk:
necessary_separation:
route_weighting_effect:
```

## Runtime Boundary

This registry should influence response construction internally. The chain name should not appear in user-facing Compass reflections.

## Teaching Status

Await directed teaching.

## Related Runtime Links

- [[scenario_context_object_registry]]
- [[relational_expectation_registry]]
- [[response_failure_or_change_registry]]
- [[attached_self_meaning_from_scenario_registry]]
- [[scenario_separation_guidance_registry]]

## Scenario Context Priority Update

When the prompt clearly names a lived context or human act, Atlas should prioritize that context before generalized emotional-processing language.

Strong context signals should route through `48 Scenario Context Weighting Human Act Priority Routing`.

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

## Relational Role Ontology Update

Relational title interpretation is now supported through `53 Relational Role Ontology`.
