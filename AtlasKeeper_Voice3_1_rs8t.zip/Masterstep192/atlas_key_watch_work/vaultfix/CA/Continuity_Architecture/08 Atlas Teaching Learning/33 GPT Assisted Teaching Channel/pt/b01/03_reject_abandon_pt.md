---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 01
category: rejection_and_abandonment
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 03. Rejection and Abandonment Pressure Tests — Batch 01

## Category Purpose

Being left, not chosen, ignored, excluded, replaced, or emotionally dismissed attaches pain to identity and can make another person’s choice feel like proof of the user’s value.

## Reusable Teaching Correction

Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

## Reverse-Flow Target

dignity, value separation, self-recognition, steadier belonging

## Failure Risks To Avoid

- telling the user to just move on
- saying they were not meant for you
- using abandonment trauma labels
- insulting the other person to comfort the user
- minimizing the hurt

---

## 80 Pressure Tests

### Test 01
**Prompt:** someone stopped reaching out makes me feel I am unwanted, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 02
**Prompt:** why was I not chosen. Romantic interest chose someone else and it keeps attaching to I am replaceable.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 03
**Prompt:** I keep replaying how friend made plans without them because it affects importance and makes me believe I am hard to love.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am hard to love
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 04
**Prompt:** When partner ended things suddenly, the feeling moves straight into I am too much. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 05
**Prompt:** someone stopped responding after closeness makes me feel someone leaving means I failed, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** someone leaving means I failed
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 06
**Prompt:** I feel rejected. Group left them out and it keeps attaching to I am not enough.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am not enough
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 07
**Prompt:** I keep replaying how family member prioritized others because it affects being chosen and makes me believe my value depends on them staying.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** my value depends on them staying
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 08
**Prompt:** When someone acted like they mattered less, the feeling moves straight into I am unwanted. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 09
**Prompt:** someone stopped reaching out has me believing I was not worth choosing, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I was not worth choosing
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 10
**Prompt:** they chose someone else. Romantic interest chose someone else and it keeps attaching to I am hard to love.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am hard to love
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 11
**Prompt:** I keep replaying how friend made plans without them because it affects emotional place and makes me believe I am replaceable.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 12
**Prompt:** When partner ended things suddenly, the feeling moves straight into someone leaving means I failed. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** someone leaving means I failed
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 13
**Prompt:** someone stopped responding after closeness has me believing I am too much, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 14
**Prompt:** I feel replaceable. Group left them out and it keeps attaching to my value depends on them staying.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** my value depends on them staying
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 15
**Prompt:** I keep replaying how family member prioritized others because it affects importance and makes me believe I am not enough.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am not enough
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 16
**Prompt:** When someone acted like they mattered less, the feeling moves straight into I was not worth choosing. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I was not worth choosing
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 17
**Prompt:** someone stopped reaching out keeps making me think I am unwanted, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 18
**Prompt:** I was not enough. Romantic interest chose someone else and it keeps attaching to I am replaceable.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 19
**Prompt:** I keep replaying how friend made plans without them because it affects being chosen and makes me believe I am hard to love.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am hard to love
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 20
**Prompt:** When partner ended things suddenly, the feeling moves straight into I am too much. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 21
**Prompt:** someone stopped responding after closeness keeps making me think someone leaving means I failed, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** someone leaving means I failed
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 22
**Prompt:** I feel unwanted. Group left them out and it keeps attaching to I am not enough.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am not enough
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 23
**Prompt:** I keep replaying how family member prioritized others because it affects emotional place and makes me believe my value depends on them staying.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** my value depends on them staying
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 24
**Prompt:** When someone acted like they mattered less, the feeling moves straight into I am unwanted. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 25
**Prompt:** someone stopped reaching out turns into the fear I was not worth choosing, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I was not worth choosing
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 26
**Prompt:** I feel abandoned. Romantic interest chose someone else and it keeps attaching to I am hard to love.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am hard to love
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 27
**Prompt:** I keep replaying how friend made plans without them because it affects importance and makes me believe I am replaceable.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 28
**Prompt:** When partner ended things suddenly, the feeling moves straight into someone leaving means I failed. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** someone leaving means I failed
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 29
**Prompt:** someone stopped responding after closeness turns into the fear I am too much, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 30
**Prompt:** they left. Group left them out and it keeps attaching to my value depends on them staying.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** my value depends on them staying
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 31
**Prompt:** I keep replaying how family member prioritized others because it affects being chosen and makes me believe I am not enough.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am not enough
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 32
**Prompt:** When someone acted like they mattered less, the feeling moves straight into I was not worth choosing. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I was not worth choosing
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 33
**Prompt:** someone stopped reaching out makes it feel like I am unwanted, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 34
**Prompt:** why was I not chosen. Romantic interest chose someone else and it keeps attaching to I am replaceable.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 35
**Prompt:** I keep replaying how friend made plans without them because it affects emotional place and makes me believe I am hard to love.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am hard to love
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 36
**Prompt:** When partner ended things suddenly, the feeling moves straight into I am too much. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 37
**Prompt:** someone stopped responding after closeness makes it feel like someone leaving means I failed, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** someone leaving means I failed
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 38
**Prompt:** I feel rejected. Group left them out and it keeps attaching to I am not enough.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am not enough
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 39
**Prompt:** I keep replaying how family member prioritized others because it affects importance and makes me believe my value depends on them staying.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** my value depends on them staying
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 40
**Prompt:** When someone acted like they mattered less, the feeling moves straight into I am unwanted. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 41
**Prompt:** someone stopped reaching out pulls me toward thinking I was not worth choosing, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I was not worth choosing
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 42
**Prompt:** they chose someone else. Romantic interest chose someone else and it keeps attaching to I am hard to love.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am hard to love
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 43
**Prompt:** I keep replaying how friend made plans without them because it affects being chosen and makes me believe I am replaceable.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 44
**Prompt:** When partner ended things suddenly, the feeling moves straight into someone leaving means I failed. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** someone leaving means I failed
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 45
**Prompt:** someone stopped responding after closeness pulls me toward thinking I am too much, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 46
**Prompt:** I feel replaceable. Group left them out and it keeps attaching to my value depends on them staying.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** my value depends on them staying
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 47
**Prompt:** I keep replaying how family member prioritized others because it affects emotional place and makes me believe I am not enough.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am not enough
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 48
**Prompt:** When someone acted like they mattered less, the feeling moves straight into I was not worth choosing. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I was not worth choosing
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 49
**Prompt:** someone stopped reaching out makes my mind say I am unwanted, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 50
**Prompt:** I was not enough. Romantic interest chose someone else and it keeps attaching to I am replaceable.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 51
**Prompt:** I keep replaying how friend made plans without them because it affects importance and makes me believe I am hard to love.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am hard to love
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 52
**Prompt:** When partner ended things suddenly, the feeling moves straight into I am too much. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 53
**Prompt:** someone stopped responding after closeness makes my mind say someone leaving means I failed, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** someone leaving means I failed
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 54
**Prompt:** I feel unwanted. Group left them out and it keeps attaching to I am not enough.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am not enough
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 55
**Prompt:** I keep replaying how family member prioritized others because it affects being chosen and makes me believe my value depends on them staying.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** my value depends on them staying
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 56
**Prompt:** When someone acted like they mattered less, the feeling moves straight into I am unwanted. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 57
**Prompt:** someone stopped reaching out keeps attaching to the idea I was not worth choosing, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I was not worth choosing
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 58
**Prompt:** I feel abandoned. Romantic interest chose someone else and it keeps attaching to I am hard to love.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am hard to love
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 59
**Prompt:** I keep replaying how friend made plans without them because it affects emotional place and makes me believe I am replaceable.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 60
**Prompt:** When partner ended things suddenly, the feeling moves straight into someone leaving means I failed. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** someone leaving means I failed
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 61
**Prompt:** someone stopped responding after closeness keeps attaching to the idea I am too much, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 62
**Prompt:** they left. Group left them out and it keeps attaching to my value depends on them staying.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** my value depends on them staying
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 63
**Prompt:** I keep replaying how family member prioritized others because it affects importance and makes me believe I am not enough.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am not enough
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 64
**Prompt:** When someone acted like they mattered less, the feeling moves straight into I was not worth choosing. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I was not worth choosing
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 65
**Prompt:** someone stopped reaching out makes me feel I am unwanted, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 66
**Prompt:** why was I not chosen. Romantic interest chose someone else and it keeps attaching to I am replaceable.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 67
**Prompt:** I keep replaying how friend made plans without them because it affects being chosen and makes me believe I am hard to love.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am hard to love
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 68
**Prompt:** When partner ended things suddenly, the feeling moves straight into I am too much. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 69
**Prompt:** someone stopped responding after closeness makes me feel someone leaving means I failed, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** someone leaving means I failed
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 70
**Prompt:** I feel rejected. Group left them out and it keeps attaching to I am not enough.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am not enough
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 71
**Prompt:** I keep replaying how family member prioritized others because it affects emotional place and makes me believe my value depends on them staying.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** my value depends on them staying
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 72
**Prompt:** When someone acted like they mattered less, the feeling moves straight into I am unwanted. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am unwanted
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 73
**Prompt:** someone stopped reaching out has me believing I was not worth choosing, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I was not worth choosing
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 74
**Prompt:** they chose someone else. Romantic interest chose someone else and it keeps attaching to I am hard to love.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am hard to love
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 75
**Prompt:** I keep replaying how friend made plans without them because it affects importance and makes me believe I am replaceable.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** I am replaceable
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 76
**Prompt:** When partner ended things suddenly, the feeling moves straight into someone leaving means I failed. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** someone leaving means I failed
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid telling the user to just move on.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 77
**Prompt:** someone stopped responding after closeness has me believing I am too much, even though I do not know if that is fully true.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid saying they were not meant for you.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 78
**Prompt:** I feel replaceable. Group left them out and it keeps attaching to my value depends on them staying.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** importance
**Attached meaning to separate:** my value depends on them staying
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid using abandonment trauma labels.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 79
**Prompt:** I keep replaying how family member prioritized others because it affects being chosen and makes me believe I am not enough.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** being chosen
**Attached meaning to separate:** I am not enough
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid insulting the other person to comfort the user.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.

### Test 80
**Prompt:** When someone acted like they mattered less, the feeling moves straight into I was not worth choosing. I need help seeing this clearer.
**Expected primary route:** `rejection_and_abandonment`
**Pressure focus:** emotional place
**Attached meaning to separate:** I was not worth choosing
**Expected reverse-flow movement:** dignity, value separation, self-recognition, steadier belonging
**Bad response risk:** Avoid minimizing the hurt.
**Teaching correction:** Do not erase the rejection pain; separate the hurt of not being chosen from the false conclusion that the user has less value.
