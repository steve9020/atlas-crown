const assert=require('assert'); const {detectAxes}=require('../Cognition/engine/AxisEngine.js');
const cases=[
 ['She expected patience, while Marcus intended to explain, and I chose to listen.',{expectation:['she'],intention:['marcus'],choice:['self']}],
 ['They control the room, but we own our response, and he accepted the result.',{control:['they'],ownership:['we'],acceptance_rejection:['he'],outcome:['he']}],
 ['Jennifer trusts us, I respect her, and they expect a decision.',{trust:['jennifer'],respect:['self'],expectation:['they']}],
 ['He crossed the boundary, while she took responsibility, and we intended to repair it.',{boundary:['he'],responsibility:['she'],intention:['we'],repair:['we']}],
 ['I caused the change, they accepted it, and Marcus chose the next step.',{causation:['self'],acceptance_rejection:['they'],choice:['marcus'],change:['self']}],
 ['We own the decision, she controls the timing, and I do not accept the outcome.',{ownership:['we'],control:['she'],acceptance_rejection:['self'],outcome:['self']}]
];
let complete=0,hits=0,total=0; for(const [text,exp] of cases){const r=detectAxes(text);let ok=true;for(const [axis,actors] of Object.entries(exp)){const a=r.axis_evidence.find(x=>x.axis===axis)?.attributions?.map(x=>x.actor)||[];for(const actor of actors){total++;if(a.includes(actor))hits++;else ok=false;}}if(ok)complete++;else console.error('FAIL',text,JSON.stringify(r.axis_evidence));} console.log(`AXOL cross-binding unseen ${hits}/${total}; complete ${complete}/${cases.length}`); assert.strictEqual(complete,cases.length);
