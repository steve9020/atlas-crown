# AI Assistance Boundary Principles

AI is not treated as automatically unsafe. Ungoverned autonomy is unsafe.

AI may later assist only as bounded, proposal-only, logged, removable, and non-authoritative support.

Forbidden: AI self-permission, AI governance mutation, AI direct file writes, AI approval authority, hidden memory, default internet access, or making Atlas Core dependent on AI.
