---
title: Atlas Prompt Response Runtime Scoring Registry
runtime_layer: response_intelligence
priority: 97
governed_by: [[runtime_governance_source_of_truth_registry]]
---

# Atlas Prompt Response Runtime Scoring Registry

This registry owns the prompt-response scoring terms and modifier rules used by Atlas during live prompt interpretation.

The plugin may execute scoring mechanics, but the terms, aliases, and weighting rules should come from this backend registry before bridge fallback is used.

## Runtime Rule

- Prompt scoring vocabulary belongs here.
- Category alias compatibility belongs here.
- Runtime scoring modifiers belong here.
- The plugin may parse this JSON and apply the rules.
- The plugin may keep fallback scaffolding only so the interface does not break if this file is missing.

## Scoring JSON

```json
{
  "purpose": "Backend-owned prompt response scoring terms and modifier rules. Plugin may execute scoring but should read terms and category-specific weighting from here before bridge fallback.",
  "term_sets": {
    "practical_terms": [
      "clean",
      "room",
      "bill",
      "pay",
      "task",
      "tasks",
      "appointment",
      "email",
      "deadline",
      "chores",
      "errands",
      "schedule",
      "today",
      "tomorrow",
      "list",
      "organize"
    ],
    "meaning_terms": [
      "means i",
      "mean i",
      "meaning",
      "proves",
      "prove",
      "my fault",
      "too much",
      "not enough",
      "unwanted",
      "worthless",
      "something wrong with me",
      "who i am",
      "my worth",
      "my value",
      "i ruin",
      "i did something wrong"
    ],
    "relational_terms": [
      "someone",
      "they",
      "them",
      "their",
      "texting",
      "pulling away",
      "pulled away",
      "distant",
      "ignored",
      "left on read",
      "relationship",
      "friend",
      "partner"
    ],
    "positive_terms": [
      "proud",
      "pride",
      "relief",
      "relieved",
      "hope",
      "hopeful",
      "peaceful",
      "joy",
      "happy",
      "excited",
      "grateful",
      "gratitude",
      "safe",
      "secure",
      "confident"
    ],
    "discomfort_terms": [
      "but",
      "uncomfortable",
      "guilty",
      "ashamed",
      "arrogant",
      "selfish",
      "foolish",
      "wrong",
      "bad",
      "afraid",
      "scared",
      "distrust",
      "suspicious"
    ],
    "inconsistency_terms": [
      "inconsistent",
      "actions feel inconsistent",
      "say they care",
      "saying they care",
      "but their actions",
      "hot and cold",
      "mixed signals",
      "something is off",
      "asking for too much"
    ],
    "dismissal_terms": [
      "dismissed",
      "disrespected",
      "not taken seriously",
      "invalidated",
      "unheard",
      "minimized",
      "dramatic",
      "too sensitive"
    ],
    "self_worth_terms": [
      "too much",
      "not enough",
      "unwanted",
      "worthless",
      "my value",
      "my worth",
      "something wrong with me"
    ],
    "repair_terms": [
      "apologize",
      "repair",
      "make it right",
      "accountability",
      "hurt them",
      "own what i did"
    ],
    "reassurance_terms": [
      "reassurance",
      "reassure",
      "need to hear",
      "need proof",
      "clingy",
      "needy"
    ]
  },
  "patterns": {
    "positive_state_phrases": [
      "\\b(i feel|i felt|feeling|felt|am|i'm|im)\\b.{0,24}\\b(proud|happy|excited|relieved|hopeful|peaceful|joyful|grateful|confident|safe|secure)\\b",
      "\\b(proud of|finished something|accomplished|good about|hopeful about|excited about|relieved that)\\b"
    ],
    "other_person_distance": [
      "(someone|they|them|he|she|my friend|my partner|person).{0,45}(pulling away|pulled away|pull away|distant|stopped texting|ignored|left on read|losing interest)",
      "(pulling away|pulled away|distant|stopped texting|ignored|left on read)"
    ],
    "user_pulling_away": [
      "\\b(i|i'm|im|me|myself)\\b.{0,20}\\b(pulled away|pulling away|pull away|withdrew|withdraw|shut down|shutting down)\\b"
    ],
    "not_user_pulling_away_when_other_distance": [
      "(someone|they|he|she).{0,45}(pulling away|pulled away|pull away|distant|stopped texting|ignored)"
    ],
    "boundary_guilt": [
      "\\b(boundary|boundaries|say no|said no|saying no|need space|needed space|protect my peace|put myself first)\\b",
      "\\b(guilty|selfish|wrong|hurt them|hurting them|doing something wrong)\\b"
    ],
    "trust_betrayal": [
      "\\b(betrayed|betrayal|lied|dishonest|secret|hidden|used against me|mishandled trust|replaceable)\\b",
      "\\b(not enough|hurt|replaceable|unwanted|value|worth|vulnerable|trust)\\b"
    ],
    "long_term_relationship_duration": [
      "\\b(1 year|one year|a year together|year together|years together|7 years|seven years|long[- ]term|marriage|married)\\b"
    ],
    "relationship_rupture": [
      "\\b(breakup|broke up|broken up|ended things|left me|separated|divorced|relationship ended)\\b"
    ],
    "comparison_worth": [
      "\\b(jealous|jealousy|envy|envious|comparing myself|comparison|behind|not doing enough|their good moment|got something i|wanted for a long time)\\b"
    ],
    "attached_meaning": [
      "\\b(feel|felt|feeling)\\b.{0,40}\\b(means|mean|proves|prove)\\b"
    ],
    "identity_fusion": [
      "\\b(i am|i'm|im)\\b.{0,20}\\b(too much|not enough|worthless|unwanted|the problem|the reason|bad|broken|a failure)\\b"
    ],
    "protective_overthinking": [
      "\\boverthink|overthinking|replay|replaying|checking|scan|scanning\\b"
    ],
    "protective_shutdown": [
      "\\bshut down|numb|guard|guarded|avoid|avoiding\\b"
    ]
  },
  "category_aliases": {
    "attachment_and_connection": [
      "attachment_and_connection"
    ],
    "trust_and_betrayal": [
      "trust_and_betrayal"
    ],
    "rejection_and_abandonment": [
      "rejection_and_abandonment"
    ],
    "abandonment_and_inconsistency": [
      "abandonment_and_inconsistency"
    ],
    "self_worth_and_identity": [
      "self_worth_and_identity"
    ],
    "identity_confusion_and_self_doubt": [
      "identity_confusion_and_self_doubt"
    ],
    "shame_and_embarrassment": [
      "shame_and_embarrassment"
    ],
    "guilt_and_responsibility": [
      "guilt_and_responsibility"
    ],
    "accountability_and_repair": [
      "accountability_and_repair"
    ],
    "grief_and_loss": [
      "grief_and_loss"
    ],
    "fear_and_anxiety": [
      "fear_and_anxiety"
    ],
    "anger_and_injustice": [
      "anger_and_injustice"
    ],
    "resentment_and_bitterness": [
      "resentment_and_bitterness"
    ],
    "jealousy_and_envy": [
      "jealousy_and_envy"
    ],
    "loneliness_and_belonging": [
      "loneliness_and_belonging"
    ],
    "boundaries_and_respect": [
      "boundaries_and_respect"
    ],
    "disrespect_and_dismissal": [
      "disrespect_and_dismissal"
    ],
    "invalidation_and_unheardness": [
      "invalidation_and_unheardness"
    ],
    "conflict_and_disconnection": [
      "conflict_and_disconnection"
    ],
    "control_and_uncertainty": [
      "control_and_uncertainty"
    ],
    "overwhelm_and_pressure": [
      "overwhelm_and_pressure"
    ],
    "helplessness_and_powerlessness": [
      "helplessness_and_powerlessness"
    ],
    "numbness_and_shutdown": [
      "numbness_and_shutdown"
    ],
    "regret_and_past_meaning": [
      "regret_and_past_meaning"
    ],
    "comparison_and_inferiority": [
      "comparison_and_inferiority"
    ],
    "love_and_vulnerability": [
      "love_and_vulnerability"
    ],
    "loyalty_and_being_chosen": [
      "loyalty_and_being_chosen"
    ],
    "forgiveness_and_reconciliation": [
      "forgiveness_and_reconciliation"
    ],
    "emotional_dependence_and_reassurance": [
      "emotional_dependence_and_reassurance"
    ],
    "hope_and_disappointment": [
      "hope_and_disappointment"
    ],
    "relief_and_permission": [
      "relief_and_permission"
    ],
    "pride_and_visibility": [
      "pride_and_visibility"
    ],
    "change_and_transition": [
      "change_and_transition"
    ],
    "motivation_and_avoidance": [
      "motivation_and_avoidance"
    ],
    "practical_clarity": [
      "practical_clarity"
    ],
    "positive_growth_and_security": [
      "positive_growth_and_security"
    ],
    "transition_from_pain_to_growth": [
      "transition_from_pain_to_growth"
    ],
    "mixed_emotional_states": [
      "mixed_emotional_states"
    ],
    "safety_scope_boundary": [
      "safety_scope_boundary"
    ],
    "general_fallback": [
      "general_fallback"
    ],
    "rejection": [
      "rejection",
      "rejection_and_abandonment"
    ],
    "boundary_selfishness": [
      "boundary_selfishness",
      "boundaries_and_respect"
    ],
    "trust_betrayal": [
      "trust_betrayal",
      "trust_and_betrayal"
    ],
    "relationship_loss": [
      "relationship_loss",
      "grief_and_loss"
    ],
    "worth": [
      "worth",
      "self_worth_and_identity"
    ],
    "trust": [
      "trust",
      "trust_and_betrayal"
    ],
    "responsibility": [
      "responsibility",
      "guilt_and_responsibility"
    ],
    "positive_mixed": [
      "positive_mixed",
      "mixed_emotional_states"
    ],
    "conflict": [
      "conflict",
      "conflict_and_disconnection"
    ],
    "practical": [
      "practical",
      "practical_clarity"
    ],
    "general": [
      "general",
      "general_fallback"
    ],
    "shame": [
      "shame",
      "shame_and_embarrassment"
    ],
    "grief": [
      "grief",
      "grief_and_loss"
    ]
  },
  "scoring_modifiers": [
    {
      "alias": "practical",
      "when": "has_practical_without_meaning_relational_or_mixed",
      "score": 12
    },
    {
      "alias": "positive_mixed",
      "when": "mixed_state_without_boundary_guilt",
      "score": 16
    },
    {
      "alias": "positive_mixed",
      "when": "missing_positive_state",
      "score": -20
    },
    {
      "alias": "boundary_selfishness",
      "when": "boundary_guilt",
      "score": 34
    },
    {
      "alias": "trust_betrayal",
      "when": "trust_betrayal",
      "score": 38
    },
    {
      "alias": "trust_betrayal",
      "when": "not_trust_betrayal",
      "score": -26
    },
    {
      "alias": "worth",
      "when": "comparison_worth",
      "score": 36
    },
    {
      "alias": "rejection",
      "when": "other_person_distance",
      "score": 14
    },
    {
      "alias": "relationship_loss",
      "when": "long_term_relationship_rupture_without_trust_betrayal",
      "score": 34
    },
    {
      "alias": "relationship_loss",
      "when": "missing_long_term_relationship_duration",
      "score": -20
    },
    {
      "alias": "not_practical",
      "when": "practical_without_meaning_relational_or_mixed",
      "score": -8
    }
  ],
  "fallback_selection": {
    "practical_key": "practical_clarity",
    "general_key": "general_fallback",
    "practical_label": "practical pressure",
    "general_label": "emotional pressure"
  }
}
```

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

