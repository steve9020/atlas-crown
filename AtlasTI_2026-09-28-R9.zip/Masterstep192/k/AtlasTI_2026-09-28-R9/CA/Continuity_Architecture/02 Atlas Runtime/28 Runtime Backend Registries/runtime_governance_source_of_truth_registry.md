---
title: Runtime Governance Source of Truth Registry
runtime_layer: backend_registry
priority: 100
governed_by:
  - [[runtime_backend_registries_overview]]
  - [[governance_enforcement_registry]]
---

# Runtime Governance Source of Truth Registry

## Core Rule

Atlas governance belongs in backend markdown.

The plugin may read, execute, display, route, and debug governance, but it must not silently become the source of governance truth.

## Backend-Owned Governance Areas

The backend owns:

- safety and scope boundaries
- sexual-content exclusion rules
- crisis and abuse routing rules
- language suppression rules
- soft authority rules
- response behavior constraints
- teaching mode permissions
- approval gate requirements
- duplicate and drift rules
- recommendation scoring rules
- integration draft constraints
- frontend translation limits

## Plugin-Owned Areas

The plugin owns only:

- user interface rendering
- input capture
- button and keyboard handling
- runtime graph loading
- markdown file reading
- registry parsing
- non-authoritative route execution
- debug display
- local proposal panel rendering

## Forbidden Plugin Drift

The plugin must not silently add:

- new emotional interpretation rules
- new safety categories
- new scope exclusions
- new teaching permissions
- new approval bypasses
- new response authority
- new backend learning without approval

Any change in those areas must appear in backend markdown first.

## Runtime Contract

When plugin behavior and backend registry content disagree, the backend registry governs.

The plugin should be corrected to match the backend rather than the backend being reshaped around plugin convenience.

## Related Runtime Links

- [[runtime_backend_registries_overview]]
- [[governance_enforcement_registry]]
- [[hard_scope_safety_boundary_registry]]
- [[sexual_content_scope_boundary_registry]]
- `plugin_frontend_only_execution_contract`
