# Error Handling Registry

Purpose: stores runtime error handling output rules in the Obsidian backend so `ErrorHandler.js` remains a generic error-normalization and response assembler instead of owning Atlas/Compass-specific fallback wording.

Boundary: this registry may declare status text, safe fallback output, exposed error fields, and non-mutation rules. It may not diagnose, interpret user meaning, bypass governance, hide trace evidence, silently erase errors, mutate backend files, expand authority, or rewrite truth for comfort.

Runtime use: `ErrorHandler.js` reads this JSON registry and applies generic error response assembly when runtime processing fails. The handler preserves error name/message evidence while returning a stable user-facing fallback output.

```json
{
  "version": "OBSIDIAN_ERROR_HANDLING_REGISTRY_STAGE7",
  "errorHandlingMode": "generic_registry_backed_error_response",
  "status": "runtime error handled",
  "exposedErrorFields": ["message", "name"],
  "defaultErrorName": "Error",
  "defaultErrorMessage": "Unknown runtime error",
  "fallbackOutput": "Something did not process correctly, but the system stayed stable. Please try again with a little more detail.",
  "nonMutationRule": "Error handling reports and stabilizes runtime failure only. It does not rewrite input, interpret user meaning, bypass governance, hide trace evidence, erase errors, diagnose, or expand authority."
}
```
