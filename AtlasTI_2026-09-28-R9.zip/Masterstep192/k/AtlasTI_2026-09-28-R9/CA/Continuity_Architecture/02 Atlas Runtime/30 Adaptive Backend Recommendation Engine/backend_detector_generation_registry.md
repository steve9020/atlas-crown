---
title: Backend Detector Generation Registry
runtime_layer: adaptive_backend_recommendation_engine
priority: high
governed_by: adaptive_backend_recommendation_engine_overview
outputs_to:
  - missing_pattern_detection_registry
  - recommendation_scoring_registry
status: active
---

# Backend Detector Generation Registry

## Purpose

This registry defines how the runtime may generate detector candidates from approved backend markdown nodes.

The runtime should not rely only on hidden hardcoded detector lists. Approved backend content may teach the runtime what emotional loops, attached meanings, protective reactions, and continuity patterns to look for.

---

## Core Rule

Generated detectors must come from approved backend sources.

A generated detector must have:

- source node
- source section or heading
- pattern identifier
- required evidence groups
- emotional contact signals
- attached meaning signals
- loop signals
- target registry
- confidence scoring path

A generated detector must not become active backend understanding by itself.

---

## Detector Evidence Groups

A detector is more accurate when it requires multiple signal groups.

Preferred groups:

1. emotional state
2. context or situation
3. attached meaning
4. loop language
5. self-worth / safety / belonging / control / future impact
6. time context when relevant

A detector should not fire from one loose word.

---

## Minimum Signal Rule

A backend-generated detector should usually require at least two evidence groups.

Higher-risk patterns should require three or more evidence groups.

Examples:

- reassurance / clarity / support
- burden / too much / wrong with me
- fear of needing something

This is stronger than only matching "support."

---

## Source-Based Teaching Rule

Every generated detector should be traceable to the backend content that taught it.

Recommended metadata:

- source_registry
- source_heading
- source_proposal
- generated_detector_id
- required_signal_groups
- target_registry

---

## Duplicate Protection

If the same pattern already exists in active backend registries, the runtime should not recommend it as new.

Duplicate detection should suppress recommendations rather than create duplicate proposal cards.

Duplicate is different from merge.

A duplicate means "do not recommend again."

A merge means "this may be useful, but belongs inside an existing pattern."

---

## Confidence Threshold

If generated detector confidence is below 50 percent, Compass should not show the recommendation.

Low-confidence matches may be ignored or held internally, but they should not be surfaced as backend growth recommendations.

---

## Related Runtime Links

- [[adaptive_backend_recommendation_engine_overview]]
- [[missing_pattern_detection_registry]]
- [[recommendation_scoring_registry]]
- [[emotional_growth_proposal_queue]]
- [[emotional_growth_approval_gate]]
