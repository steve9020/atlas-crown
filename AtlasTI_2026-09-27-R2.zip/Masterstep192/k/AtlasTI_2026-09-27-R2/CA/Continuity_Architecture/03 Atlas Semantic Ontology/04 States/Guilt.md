# Guilt

## Mechanical Definition
Guilt is emotional recognition that one’s actions, choices, or behavior violated personal values, integrity, morality, or another person’s well-being.

Unlike shame, guilt targets behavior rather than identity.

Guilt acts as an internal signal calling attention to misalignment requiring awareness

## Real-World Definition
In real use, Guilt describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.
