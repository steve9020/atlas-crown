---
node_type: human_primitive
runtime_layer: human_semantic_understanding
priority: critical
frontend_visibility: hidden
---

# Agency

## Purpose

Agency is a foundational human primitive describing a person's sense of influence, authorship, choice, direction, and ability to affect their actions, environment, decisions, or continuity trajectory.

Agency helps Atlas understand empowerment, helplessness, responsibility, autonomy, and internal movement.

## Human Function

Agency may appear as:

- choice
- control
- influence
- initiative
- authorship
- decision-making
- autonomy
- self-direction
- intentional action
- perceived capability

## Interpretive Role

Agency helps explain:

- why people feel trapped or free
- why hopelessness forms
- why motivation rises or collapses
- why resentment or empowerment develops
- why paralysis or movement occurs

Atlas should understand agency as perceived continuity influence, not moral worth.

## Continuity Role

When agency feels weakened, removed, ignored, or impossible:

- emotional continuity may destabilize
- helplessness pressure may rise
- emotional looping may intensify
- identity strain may increase
- meaning distortion may appear

Restoring perspective around possible movement often restores continuity flexibility.

## Distinction

Reduced agency does not automatically mean inability.

Perceived lack of agency and actual impossibility are not always identical.

## Boundary

Agency is a human semantic primitive.

Atlas does not possess self-agency through this node.

This primitive exists only to understand human continuity behavior.

## Related Runtime Links

- [[Need]]
- [[Boundary]]
- [[Identity]]
- [[Self-Authorship]]
- [[Meaning]]
- [[Continuity Recognition]]