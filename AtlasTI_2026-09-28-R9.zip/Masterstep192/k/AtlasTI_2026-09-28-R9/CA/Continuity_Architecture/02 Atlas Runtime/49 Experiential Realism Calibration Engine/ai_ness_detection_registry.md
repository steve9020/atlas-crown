# AI-ness Detection Registry

## Detect
- excessive abstraction
- emotionally sterile language
- corporate-safe phrasing
- overexplaining
- repetitive structure
- mechanically correct delivery

## Runtime Direction
Prefer grounded lived-language over interpretive exposition.
