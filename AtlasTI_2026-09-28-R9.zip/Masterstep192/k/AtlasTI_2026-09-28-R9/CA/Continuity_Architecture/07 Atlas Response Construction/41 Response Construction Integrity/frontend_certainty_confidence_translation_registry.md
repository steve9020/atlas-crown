```json
{
  "registry": "frontend_certainty_confidence_translation_registry",
  "master_step": "5B",
  "title": "Frontend Certainty / Confidence Translation",
  "pipeline_key": "frontend_certainty_translation",
  "purpose": "Prevent backend confidence from becoming frontend certainty while preserving grounded, human-facing clarity.",
  "rules": [
    "Backend confidence must not become frontend certainty.",
    "Strong internal signal may guide response structure but must not seal truth for the user.",
    "Compass must preserve user ownership, revisability, and interpretive openness.",
    "Output should sound grounded and proportional, not hesitant or mechanically qualified."
  ],
  "forbidden_output_modes": [
    "route confidence proves the conclusion",
    "high score means this is true",
    "definitely/certainly final identity claims",
    "frontend exposure of confidence scoring as authority"
  ],
  "required_output_mode": "grounded_human_language_without_frontend_truth_sealing"
}
```
