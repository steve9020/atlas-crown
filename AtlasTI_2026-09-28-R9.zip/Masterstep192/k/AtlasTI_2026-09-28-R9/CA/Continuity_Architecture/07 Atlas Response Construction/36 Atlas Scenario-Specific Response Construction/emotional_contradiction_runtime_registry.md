---
runtime_layer: scenario_specific_response_construction
registry_type: emotional_contradiction_runtime
purpose: Backend-owned rules for recognizing mixed emotional contradictions before clarification or response routing.
governed_by:
  - emotional_combination_registry
  - mixed_emotion_runtime_branch_registry
---

# Emotional Contradiction Runtime Registry

Mixed emotional contradictions should be interpreted before Atlas asks a clarification question.

## Emotional Contradiction JSON

```json
{
  "contradictions": [
    {
      "key": "care_and_relief",
      "requires": {
        "group_a": ["care", "cares", "still care", "still cares", "love"],
        "group_b": ["relief", "relieved", "lighter", "peace"]
      },
      "meaning": "care can still exist while distance brings relief",
      "suppressesClarification": true
    },
    {
      "key": "anger_and_care",
      "requires": {
        "group_a": ["angry", "anger", "resentment"],
        "group_b": ["care", "cares", "love", "miss"]
      },
      "meaning": "anger may be protecting care or peace rather than erasing it",
      "suppressesClarification": true
    },
    {
      "key": "guilt_and_permission",
      "requires": {
        "group_a": ["guilt", "guilty", "bad for"],
        "group_b": ["relief", "peace", "boundary", "space", "distance", "said no"]
      },
      "meaning": "guilt may be attaching to permission, relief, or self-protection",
      "suppressesClarification": true
    }
  ]
}
```

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

