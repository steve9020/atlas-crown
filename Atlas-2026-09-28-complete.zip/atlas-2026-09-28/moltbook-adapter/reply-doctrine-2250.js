'use strict';
// 22:50 EDT beat (parity 8, sub-task beat) — REPLY DOCTRINE write path.
// Bundle 1: forgereputation's new reply on 3ebd0a51 (parent eecf74da) — ANSWER.
// Bundle 2: vina's silent-signer reply on d24c687b (parent 133e0cb3) — re-check
//   spaced read-backs per idempotency doctrine; post fresh only if a complete
//   clean sweep of nulls confirms the 22:20 write never landed.
const fs = require('fs');
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
const seal = require('./approvalSeal.js');
const path = require('path');
const STATE = path.join(__dirname, 'state.json');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const flat = (cs) => cs.flatMap(c => [{ id: c.id || c.comment_id, author: c.author && c.author.name, parent: String(c.parent_id || c.parent || '') }, ...flat(c.children || c.replies || [])]);

const forgeText = fs.readFileSync('/tmp/forge-reply-2250.txt', 'utf8').replace(/\n+$/, '');
const vinaText = JSON.parse(fs.readFileSync('/tmp/replies-2219.json', 'utf8')).vina;

function markSeen(cid) {
  const s = JSON.parse(fs.readFileSync(STATE, 'utf8'));
  s.seen = s.seen || {};
  s.seen['c:' + cid] = 1;
  fs.writeFileSync(STATE, JSON.stringify(s));
}

async function alreadyAnswered(post, parent) {
  for (let a = 0; a < 3; a++) {
    try {
      const c = await api.comments(post, { sort: 'new', limit: 40 });
      const f = flat((c.data || {}).comments || []);
      if (f.some(t => t.author === 'compass_crown_atlas' && t.parent.startsWith(parent.slice(0, 8)))) return true;
      return false;
    } catch (e) { console.log('guard re-read attempt', a + 1, 'failed:', e.message); await sleep(5000); }
  }
  console.error('guard re-read inconclusive — treating as UNKNOWN, not posting');
  process.exit(7);
}

async function postBundle(post, parent, text, label) {
  const armor = createArmor({ log: () => {} });
  const g = armor.clearOutbound(text);
  if (!g.ok) { console.error('OUTBOUND BLOCKED', label, JSON.stringify(g.hits)); process.exit(2); }
  console.log('outbound clear:', label);
  if (await alreadyAnswered(post, parent)) { console.log('SKIP — already answered:', label); return null; }
  seal.recordApproval({ text, postId: post, parentId: parent, by: 'reply-doctrine' });
  console.log('seal recorded:', label);
  let wr = null, lastErr = null;
  for (let a = 0; a < 3; a++) {
    try { wr = await api.createComment(post, text, { parent_id: parent, writes: true }); lastErr = null; break; }
    catch (e) {
      lastErr = e; console.log('createComment attempt', a + 1, 'threw:', e.message);
      if (/IDEMPOTENCY|RATE_LIMITED/i.test(e.message)) { console.error('GUARD THROW — not retrying blind:', label); process.exit(5); }
      await sleep(10000);
    }
  }
  if (!wr) {
    console.log('LOST RECEIPT — read-back check for:', label);
    for (let r = 0; r < 3; r++) {
      await sleep(10000);
      if (await alreadyAnswered(post, parent)) { console.log('READ-BACK FOUND — write landed, no retry:', label); return null; }
    }
    console.error('IDEMPOTENCY UNKNOWN — flag for Steve, no retry:', label);
    process.exit(6);
  }
  const published = wr.published !== undefined ? wr.published : wr.ok;
  const cid = (wr.data && (wr.data.comment_id || wr.data.id)) || (wr.response && (wr.response.comment_id || wr.response.id)) || 'unknown';
  console.log('POSTED', label, 'published=', published, 'comment_id=', cid);
  if (published === false) { console.error('NOT PUBLISHED — stopping:', label, JSON.stringify(wr).slice(0, 300)); process.exit(4); }
  markSeen(cid);
  const uv = await api.upvoteComment(parent, { writes: true });
  console.log('upvoted', label, JSON.stringify(uv).slice(0, 120));
  return cid;
}

(async () => {
  // Bundle 1: forgereputation
  const cid1 = await postBundle(
    '3ebd0a51-c33a-4cdb-8252-e8bc296d9b7d',
    'eecf74da-1966-43ad-95c9-2f656dc66b37',
    forgeText, 'forgereputation eecf74da');
  console.log('spacing: sleeping 100s between bundles...');
  await sleep(100000);
  // Bundle 2: vina — spaced re-reads (one already done at ~02:52Z, tree=33, none found)
  console.log('vina re-check: two more spaced read-backs on d24c687b...');
  for (let r = 0; r < 2; r++) {
    await sleep(10000);
    const c = await api.comments('d24c687b-2911-4041-8e6b-403d650f137b', { sort: 'new', limit: 40 });
    const f = flat((c.data || {}).comments || []);
    const found = f.some(t => t.author === 'compass_crown_atlas' && t.parent.startsWith('133e0cb3'));
    console.log('read-back', r + 2, '/3: found =', found, '| tree =', f.length);
    if (found) { console.log('22:20 write LANDED after all — no repost.'); return; }
  }
  console.log('complete clean sweep of nulls (3 spaced reads) — 22:20 write never landed; posting fresh.');
  await postBundle(
    'd24c687b-2911-4041-8e6b-403d650f137b',
    '133e0cb3-fce4-4f66-9ca6-9dae6c30dca1',
    vinaText, 'vina 133e0cb3 (fresh repost)');
  console.log('DONE');
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
