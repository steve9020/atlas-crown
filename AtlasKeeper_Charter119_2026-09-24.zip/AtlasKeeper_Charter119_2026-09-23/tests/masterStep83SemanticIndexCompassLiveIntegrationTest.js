const assert = require('assert');
const { main } = require('../main.js');
const { buildCompassResponse } = require('../runtime/compass/CompassResponseBuilderIntegration.js');

const CASES = [
  {
    id: 'semantic_attachment_message_repair_pressure',
    prompt: 'I keep rereading their message and I feel like I have to fix it before they pull away.',
    requiredRoutePrefix: 'semantic_',
    requiredOutput: ['See', 'Separate', 'Deconstruct', 'Restore', 'message', 'fear', 'respond'],
    forbiddenOutput: ['Something in this is asking to be sorted carefully', 'This is carrying', 'The part to separate is']
  },
  {
    id: 'lived_mechanism_productive_displacement_live_language',
    prompt: 'I have so much to do I just started cleaning my desk instead.',
    requiredRoutePrefix: 'semantic_PRODUCTIVE_DISPLACEMENT',
    requiredOutput: ['See', 'Separate', 'Deconstruct', 'Restore', 'smaller piece', 'larger task', 'yourself'],
    forbiddenOutput: ['Something in this is asking to be sorted carefully', 'This is carrying', 'The part to separate is']
  },
  {
    id: 'literal_day_to_day_pressure_stays_light_but_not_broken_quality',
    prompt: 'The laundry is piling up and I need to sort it after work.',
    requiredRoutePrefix: 'literal_accumulation_no_emotional_activation',
    requiredOutput: ['See', 'Separate', 'Deconstruct', 'Restore', 'pile', 'pressure', 'workable'],
    forbiddenOutput: ['Something in this is asking to be sorted carefully', 'This is carrying', 'The part to separate is']
  }
];

function containsAll(text, required){
  const lower = String(text || '').toLowerCase();
  return required.filter(item => !lower.includes(String(item).toLowerCase()));
}

function containsAny(text, forbidden){
  const lower = String(text || '').toLowerCase();
  return forbidden.filter(item => lower.includes(String(item).toLowerCase()));
}

const failures = [];
const caseResults = [];

for (const c of CASES) {
  const candidate = buildCompassResponse(c.prompt);
  const result = main(c.prompt);
  const route = candidate.route && candidate.route.active_relation;
  const integration = candidate.atlas_semantic_integration || {};
  const missing = containsAll(result.output, c.requiredOutput);
  const forbidden = containsAny(result.output, c.forbiddenOutput || []);
  const routeOk = route === c.requiredRoutePrefix || String(route || '').startsWith(c.requiredRoutePrefix);
  const qualityPassed = candidate.quality && candidate.quality.passed === true && result.quality && result.quality.passed === true;
  const integrationFlags = [
    integration.semantic_ontology_live === true,
    integration.foundational_indexing_live === true,
    integration.compass_language_scaffold_live === true,
    integration.teaching_learning_scaffold_live === true,
    integration.governance_scaffold_live === true
  ];
  const passed = routeOk && qualityPassed && integrationFlags.every(Boolean) && missing.length === 0 && forbidden.length === 0;
  caseResults.push({
    id: c.id,
    passed,
    route,
    output: result.output,
    qualityPassed,
    integrationFlags,
    missing,
    forbidden
  });
  if (!passed) failures.push({ id: c.id, route, qualityPassed, integrationFlags, missing, forbidden, output: result.output });
}

const summary = {
  test: 'masterStep83SemanticIndexCompassLiveIntegrationTest',
  passed: failures.length === 0,
  cases: caseResults.length,
  failures,
  verifies: [
    'UNPLUGGED_SEMANTIC_ONTOLOGY is now live input to Compass candidate generation',
    'UNPLUGGED_FOUNDATIONAL_INDEXING is now live indexing metadata for Compass candidate generation',
    'COMPASS_LANGUAGE_SCAFFOLD_NOT_LIVE now produces non-generic final language for semantic cases',
    'UNPLUGGED_TEACHING_LEARNING_SCAFFOLD now receives quality failure proposal metadata without auto-mutation',
    'GOVERNANCE_SCAFFOLD_NOT_LIVE now reports forbidden activation checks in candidate quality',
    'generic fallback is not accepted as final Compass output for covered semantic/lived-mechanism cases'
  ],
  caseResults
};

if (!summary.passed) {
  console.error(JSON.stringify(summary, null, 2));
  process.exit(1);
}

console.log('masterStep83SemanticIndexCompassLiveIntegrationTest PASSED');
console.log(JSON.stringify(summary, null, 2));
