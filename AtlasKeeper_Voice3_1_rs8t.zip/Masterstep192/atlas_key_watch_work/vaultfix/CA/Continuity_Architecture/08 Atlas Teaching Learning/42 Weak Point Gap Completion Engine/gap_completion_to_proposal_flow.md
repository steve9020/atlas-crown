# Gap Completion To Proposal Flow

## Flow
Weak point detected → missing gap identified → target selected → integration draft created → proposal validated → sent to review.

## Required Fields
The completed proposal must include all required proposal fields before entering review.

## Boundary
Incomplete proposals are blocked.
