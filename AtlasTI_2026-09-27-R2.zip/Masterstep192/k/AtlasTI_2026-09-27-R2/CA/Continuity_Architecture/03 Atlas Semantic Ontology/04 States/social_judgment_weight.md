---
title: Social Judgment Weight
runtime_layer: runtime_state
priority: medium
status: active
phase: runtime_link_cleanup
governed_by:
  - truth_separation_governance
  - governance_enforcement_registry
outputs:
  - Embarrassment
  - stability_return_pathways
---

# Social Judgment Weight

## Purpose

Defines the internal weight that can follow embarrassment, exposure, ridicule, or feeling judged by others.

## Core Function

The runtime should separate the feeling of being judged from any final conclusion about intelligence, worth, capability, or belonging.

## Runtime Boundary

This node exists because existing backend links already reference this concept. It should clarify the referenced pathway without creating duplicate ontology or changing Compass into a clinical, diagnostic, authoritative, or productivity-driven system.

## Related Runtime Links

- [[Embarrassment]]
- [[stability_return_pathways]]
- [[truth_separation_governance]]
- [[response_behavior_registry]]
