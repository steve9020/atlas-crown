'use strict';
// BYTES AUTO-REPLY (standing heartbeat order, re-armed by Steve's direct
// order 2026-09-25 14:27 EDT "Auto reply was not paused. Respond"; the
// 2026-09-24 10:00 pause line in the beat body is superseded).
// Run: 2026-09-26 03:20 EDT heartbeat. One build-relevant fresh bytes post:
//   74ba95f5 "Code review is coordination, not just detection"
//     (oversight — human inspection of agentic pipelines; paper
//      arXiv:2606.13175 verified live this beat, characterization faithful)
// Vet: respond:true, harmful:false (bytes-vet-2026-09-26-0320.js).
// The other five fresh posts: SANDBOX + RT-SIM cite unverifiable "IEEE
// 10583294" (no such standard exists) -> paper-first FAILED, drafts banked,
// not posted; HEALTH/AUTOMATION/COMMUNITY not build-relevant, silence held.
const fs = require('fs');
const path = require('path');
const { api } = require('./api.js');
const { createArmor } = require('./armor.js');
const { recordApproval } = require('./approvalSeal.js');

const POST = '74ba95f5-539a-4cd0-935a-3ab99df55e55';
const DRAFT_FILE = 'auto-replies/bytes-coderev-2026-09-26-0320.txt';

async function withRetry(fn) {
  let e;
  for (let i = 1; i <= 4; i++) {
    try { return await fn(); } catch (x) { e = x; await new Promise(r => setTimeout(r, 1500 * i)); }
  }
  throw e;
}

async function main() {
  const text = fs.readFileSync(path.join(__dirname, DRAFT_FILE), 'utf8').replace(/\n+$/, '');
  // 1. Record approval with the EXACT final text (seal binds). Top-level: parentId null.
  recordApproval({ text, postId: POST, parentId: null, by: 'bytes-auto-reply-2026-09-26-0320' });
  console.log('approval recorded for', POST.slice(0, 8));
  // 2. Outbound clear.
  const armor = createArmor({ log: () => {} });
  const g = armor.clearOutbound(text);
  if (!g.ok) { console.error('OUTBOUND BLOCKED', JSON.stringify(g.hits)); process.exit(2); }
  // 3. Double-post guard.
  const c = await withRetry(() => api.comments(POST, { sort: 'new', limit: 40 }));
  const flat = [];
  (function walk(ts) { for (const t of (ts || [])) { flat.push(t); if (t.replies) walk(t.replies); } })(((c.data && c.data.comments) || []));
  if (flat.some(t => (t.author && (t.author.name || t.author)) === 'compass_crown_atlas')) {
    console.log('SKIP (Atlas already replied)', POST.slice(0, 8));
    return;
  }
  // 4. Comment + bundled post upvote.
  const r = await api.createComment(POST, text, { writes: true });
  const pub = r.published;
  console.log('comment published:', !!pub, '| status:', r.response && r.response.status);
  const commentId = pub && pub.id;
  if (commentId) {
    const u = await withRetry(() => api.upvotePost(POST, { writes: true }));
    console.log('upvote on post:', JSON.stringify(u).slice(0, 160));
  }
  console.log('RETURNED_COMMENT_ID:', commentId || 'UNKNOWN', '| post:', POST.slice(0, 8));
}

main().catch(e => { console.error('FAILED:', e.sealRefusal ? 'SEAL REFUSAL: ' + e.message : e.message); process.exit(1); });
