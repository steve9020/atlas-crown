# Masterstep91 — Expression Preservation / Restore Evidence Binding

## Purpose

Masterstep91 prevents Atlas understanding from being compressed before Compass exposes it to the user.

The correction preserves the current Atlas structure while enforcing two rules:

1. Restore principles must be evidence-bound to the active route before route-specific language can appear.
2. Compass must expose the movement from reality to conclusion and back, instead of summarizing Atlas understanding into a short slogan.

## Scope

- No deletion.
- No new ontology.
- No new mechanisms.
- No provider/model/cloud/API/network bridge.
- No operator console.
- No frontend intelligence.
- Backend-only final-language correction.

## Corrected failure

A route-specific restoration phrase, such as productive-displacement language about “smaller movement / larger task,” must not leak into unrelated prompts.

Compass must not shorten a correct internal understanding into generic language such as “let the signal matter without letting it become everything” when the person needs the actual movement exposed.

## Proof target

Fresh prompts are tested for:

- silence / missing information
- wrong answer in public
- care / overextension
- future projection
- comparison pressure

Each must avoid route leakage, avoid formulaic restore openers, and expose the relevant reality-to-conclusion movement.
