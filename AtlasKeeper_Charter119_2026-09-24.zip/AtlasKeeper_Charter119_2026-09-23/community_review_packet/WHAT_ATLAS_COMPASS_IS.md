# What Atlas / Compass Is

Atlas is the governed backend architecture being developed to separate context, meaning, pressure, attachment, and restoration direction before producing a user-facing response.

Compass is the user-facing clarity function. It is intended to translate an experience into a grounded response that helps preserve meaning without turning the system into a therapist, authority, diagnosis engine, or persuasion layer.

The current review request is not asking reviewers to inspect the implementation. It is asking whether the explanation, boundaries, and demo framing are understandable enough for external feedback.
