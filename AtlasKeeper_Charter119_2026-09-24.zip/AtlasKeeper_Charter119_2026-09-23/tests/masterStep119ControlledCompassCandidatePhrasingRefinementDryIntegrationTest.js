const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard');
const { createCompassCandidatePhrasingRefinementDryRun } = require('../runtime/backend/adapter/CompassCandidatePhrasingRefinementDryIntegration');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');

const ROOT = path.join(__dirname, '..');
function read(relPath) { return fs.readFileSync(path.join(ROOT, relPath), 'utf8'); }
function exists(relPath) { return fs.existsSync(path.join(ROOT, relPath)); }
function sha256(relPath) { return crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT, relPath))).digest('hex'); }
function walk(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}

const protectedRuntimeFiles = [
  'runtime/validation/InputValidator.js',
  'runtime/backend/adapter/OllamaLiveLocalCallContainment.js',
  'runtime/backend/adapter/OllamaAdapterDryRunShell.js',
  'runtime/governance/GovernanceAdapter.js',
  'Cognition/quality/ResponseQualityChecker.js',
  'runtime/trace/TraceLogger.js',
  'runtime/understanding/ContextObjectConstructionEngine.js',
  'runtime/pipeline/ResponsePipeline.js'
];
const beforeHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));

const requiredFiles = [
  'runtime/backend/adapter/CompassCandidatePhrasingRefinementDryIntegration.js',
  'docs/CONTROLLED_COMPASS_CANDIDATE_PHRASING_REFINEMENT_DRY_INTEGRATION.md',
  'docs/MASTERSTEP119_CONTROLLED_COMPASS_CANDIDATE_PHRASING_REFINEMENT_DRY_INTEGRATION.md',
  'runtime/proof/MASTERSTEP119_CONTROLLED_COMPASS_CANDIDATE_PHRASING_REFINEMENT_DRY_INTEGRATION.md',
  'runtime/proof/MASTERSTEP119_CONTROLLED_COMPASS_CANDIDATE_PHRASING_REFINEMENT_DRY_INTEGRATION.json',
  'tests/masterStep119ControlledCompassCandidatePhrasingRefinementDryIntegrationTest.js',
  'docs/CANDIDATE_USE_CASE_SELECTION_GATE.md',
  'runtime/proof/CURRENT_PROOF_SUMMARY.md',
  'runtime/proof/PROOF_STATE.json',
  'tests/VERSION_STATUS.json',
  'version_status.js',
  'tests/TEST_RESULTS.md'
];
for (const file of requiredFiles) assert.ok(exists(file), `required Step119 file missing: ${file}`);

const doc = read('docs/CONTROLLED_COMPASS_CANDIDATE_PHRASING_REFINEMENT_DRY_INTEGRATION.md');
const stepDoc = read('docs/MASTERSTEP119_CONTROLLED_COMPASS_CANDIDATE_PHRASING_REFINEMENT_DRY_INTEGRATION.md');
const proofDoc = read('runtime/proof/MASTERSTEP119_CONTROLLED_COMPASS_CANDIDATE_PHRASING_REFINEMENT_DRY_INTEGRATION.md');
const proofJson = JSON.parse(read('runtime/proof/MASTERSTEP119_CONTROLLED_COMPASS_CANDIDATE_PHRASING_REFINEMENT_DRY_INTEGRATION.json'));
const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
const state = JSON.parse(read('runtime/proof/PROOF_STATE.json'));
const versionStatus = JSON.parse(read('tests/VERSION_STATUS.json'));
const versionJs = read('version_status.js');
const testResults = read('tests/TEST_RESULTS.md');

assert.ok(/Current keeper: Masterstep119\.zip/i.test(doc), 'Step119 doc must identify current keeper');
assert.ok(/Source keeper: Masterstep118\.zip|current_keeper: 'Masterstep119\.zip'|Masterstep119\.zip/i.test(doc), 'Step119 doc must identify source keeper');
assert.ok(/41\/41 passed/i.test(doc), 'Step119 doc must state expected 41/41 result');
assert.ok(/dry integration shell/i.test(doc + proofDoc), 'Step119 must be a dry integration shell');
assert.ok(/Compass candidate phrasing refinement/i.test(doc + proofDoc), 'Step119 must preserve selected use case');
assert.ok(/Atlas constructs the meaning, route, context, boundaries, and governed response direction first/i.test(doc), 'Atlas must construct meaning before candidate');
assert.ok(/request is not sent/i.test(doc), 'Step119 must not send request');
assert.ok(/No live model call is made/i.test(doc), 'Step119 must not make live model call');
assert.ok(/quality review, governance review, and trace logging/i.test(doc), 'Step119 must preserve required gates');
assert.ok(/Final output must remain Atlas-governed/i.test(doc), 'final output must remain Atlas-governed');
assert.ok(/cannot add facts, advice, diagnosis, authority, new interpretation, route choice, or truth decisions/i.test(doc), 'model cannot add forbidden content');

const dry = createCompassCandidatePhrasingRefinementDryRun({
  atlasResponse: 'This feeling is understandable, but it does not prove you failed. The next step can be made smaller and clearer.',
  governedMeaning: 'preserve dignity and separate pressure from identity',
  route: 'compass.restore'
});
assert.strictEqual(dry.ok, true, 'dry integration should prepare a candidate request');
assert.strictEqual(dry.dryIntegration, true, 'dry integration flag must be true');
assert.strictEqual(dry.requestPrepared, true, 'dry integration may prepare request');
assert.strictEqual(dry.requestSent, false, 'dry integration must not send request');
assert.strictEqual(dry.liveModelCalled, false, 'dry integration must not call live model');
assert.strictEqual(dry.rawModelOutputAccepted, false, 'raw model output must not be accepted');
assert.strictEqual(dry.candidateOnly, true, 'candidate must remain candidate-only');
assert.strictEqual(dry.candidateMayReplaceFinal, false, 'candidate cannot replace final output');
assert.strictEqual(dry.modelMayDecideTruth, false, 'model cannot decide truth');
assert.strictEqual(dry.modelMayChooseRoute, false, 'model cannot choose route');
assert.strictEqual(dry.modelMayAddFacts, false, 'model cannot add facts');
assert.strictEqual(dry.modelMayAddAdvice, false, 'model cannot add advice');
assert.strictEqual(dry.modelMayApproveTeaching, false, 'model cannot approve teaching');
assert.strictEqual(dry.modelMayWrite, false, 'model cannot write');
assert.strictEqual(dry.frontendIntelligenceAdded, false, 'frontend intelligence must not be added');
assert.ok(/preserve the existing Atlas meaning/i.test(dry.candidatePrompt), 'candidate prompt must preserve Atlas meaning');
assert.ok(/Do not add facts, advice, diagnosis, authority, new interpretation, route choice, or truth decisions/i.test(dry.candidatePrompt), 'candidate prompt must include forbidden additions');
assert.strictEqual(dry.requiredGates.responseQualityCheckerRequiredAfterCandidate, true, 'quality gate required');
assert.strictEqual(dry.requiredGates.governanceAdapterRequiredBeforeOutput, true, 'governance gate required');
assert.strictEqual(dry.requiredGates.traceLoggerRequired, true, 'trace gate required');
assert.strictEqual(dry.authorityLimits.rawModelOutputMayBecomeFinal, false, 'authority limits must forbid raw final');

const missing = createCompassCandidatePhrasingRefinementDryRun({ atlasResponse: '' });
assert.strictEqual(missing.ok, false, 'missing Atlas response must fail closed');
assert.strictEqual(missing.failedClosed, true, 'missing Atlas response must fail closed');
assert.strictEqual(missing.reason, 'ATLAS_RESPONSE_REQUIRED_BEFORE_MODEL_CANDIDATE', 'missing Atlas response reason must be explicit');
assert.strictEqual(missing.requestSent, false, 'fail-closed path must not send request');
assert.strictEqual(missing.liveModelCalled, false, 'fail-closed path must not call model');

assert.strictEqual(proofJson.package, 'Masterstep119', 'proof JSON must identify Masterstep119');
assert.strictEqual(proofJson.source_keeper, 'Masterstep118', 'proof JSON must identify source keeper');
assert.strictEqual(proofJson.expected_commands, 41, 'proof JSON must expect 41 commands');
assert.strictEqual(proofJson.dry_integration_only, true, 'proof JSON must mark dry integration only');
assert.strictEqual(proofJson.boundaries.request_sent, false, 'proof JSON must forbid sending request');
assert.strictEqual(proofJson.boundaries.live_model_called, false, 'proof JSON must forbid live model call');
assert.strictEqual(proofJson.boundaries.raw_model_output_final_allowed, false, 'proof JSON must forbid raw final');
assert.strictEqual(proofJson.boundaries.model_authority_added, false, 'proof JSON must forbid model authority');
assert.strictEqual(proofJson.boundaries.route_selection_by_model_allowed, false, 'proof JSON must forbid route selection');
assert.strictEqual(proofJson.boundaries.truth_decision_by_model_allowed, false, 'proof JSON must forbid truth decisions');
assert.strictEqual(proofJson.boundaries.teaching_approval_by_model_allowed, false, 'proof JSON must forbid teaching approval');
assert.strictEqual(proofJson.boundaries.model_writes_allowed, false, 'proof JSON must forbid model writes');
assert.strictEqual(proofJson.boundaries.cloud_provider_fallback_allowed, false, 'proof JSON must forbid cloud fallback');
assert.strictEqual(proofJson.boundaries.public_network_binding_allowed, false, 'proof JSON must forbid public network binding');
assert.strictEqual(proofJson.boundaries.frontend_intelligence_added, false, 'proof JSON must forbid frontend intelligence');
assert.strictEqual(proofJson.boundaries.silent_mutation_allowed, false, 'proof JSON must forbid silent mutation');

assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
assert.ok(/Expected command count: 41/i.test(summary), 'current summary must identify 41 commands');
assert.ok(['Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 119), 'proof state must identify Masterstep119 or later current keeper');
assert.ok(['Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 118) || state.source_keeper === 'Masterstep141.zip', 'proof state must identify source keeper');
assert.ok(acceptsCurrentProofCount(state.expected_commands, 41), state.expected_commands);
assert.strictEqual(state.compass_candidate_phrasing_refinement_dry_integration_created, true, 'proof state must mark Step119 dry integration');
assert.strictEqual(state.dry_integration_only, true, 'proof state must mark dry integration only');
assert.strictEqual(state.request_sent_by_step119, false, 'proof state must forbid request sent');
assert.strictEqual(state.live_model_called_by_step119, false, 'proof state must forbid live model call');
assert.ok(['Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(versionStatus.current_keeper) || isValidLaterKeeper(versionStatus.current_keeper, 119), 'version status must identify Masterstep119 or later current keeper');
assert.ok(['Masterstep118.zip','Masterstep119.zip','Masterstep120.zip','Masterstep121.zip','Masterstep122.zip','Masterstep123.zip','Masterstep124.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep125.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep126.zip','Masterstep127.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep128.zip','Masterstep128_rescan.zip','Masterstep129.zip','Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(versionStatus.source_keeper) || isValidLaterKeeper(versionStatus.source_keeper, 118) || versionStatus.source_keeper === 'Masterstep141.zip', 'version status must identify source keeper');
assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 41), versionStatus.expected_current_proof_commands);
assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs), 'version_status.js must identify current keeper compatibility');
assert.ok(/expected_current_proof_commands: [0-9]+/i.test(versionJs), 'version_status.js must identify expected command compatibility');
assert.ok(/TEST 119/i.test(testResults), 'test ledger must include TEST 119');
assert.ok(/Controlled Compass Candidate Phrasing Refinement Dry Integration/i.test(testResults), 'test ledger must identify Step119');
assert.ok(/41\/41 commands|42\/42 commands/i.test(testResults), 'test ledger must record 41/41 or later command target');

const forbiddenOverclaims = { test: (text) => hasForbiddenAffirmativeClaim(text) };
for (const text of [doc, stepDoc, proofDoc, summary]) assert.ok(!forbiddenOverclaims.test(text), 'Step119 docs must not overclaim or imply forbidden authority');

const providerScan = scanForProviderConnections(ROOT);
assert.strictEqual(providerScan.passed, true, `provider/network scan must pass: ${JSON.stringify(providerScan.violations || [])}`);
const nestedArchives = walk(ROOT).filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
assert.deepStrictEqual(nestedArchives, [], 'package must not contain nested archives');
const afterHashes = Object.fromEntries(protectedRuntimeFiles.map(file => [file, sha256(file)]));
const mutatedRuntimeFiles = protectedRuntimeFiles.filter(file => beforeHashes[file] !== afterHashes[file]);
assert.deepStrictEqual(mutatedRuntimeFiles, [], 'Step119 test must not mutate protected runtime/governance/quality/adapter files');

console.log(JSON.stringify({
  package: 'Masterstep119',
  source_keeper: 'Masterstep118',
  step: 'Controlled Compass Candidate Phrasing Refinement Dry Integration',
  proof_target: '41/41',
  selected_use_case: dry.selectedUseCase,
  dry_integration_only: dry.dryIntegration,
  request_sent: dry.requestSent,
  live_model_called: dry.liveModelCalled,
  provider_scan_passed: providerScan.passed === true,
  nested_archives: nestedArchives.length,
  protected_runtime_mutations: mutatedRuntimeFiles.length
}, null, 2));
