---
title: Emotional Interpretation Registry
runtime_layer: backend_registry
priority: highest
status: active
phase: emotional_interpretation_foundation
governed_by:
  - runtime_backend_registries_overview
  - runtime_signal_registry
  - depth_routing_registry
  - governance_enforcement_registry
  - response_behavior_registry
outputs:
  - runtime_signal_registry
  - depth_routing_registry
  - response_behavior_registry
  - runtime_registry_flow
---

# Emotional Interpretation Registry

## Purpose

This registry defines how Compass interprets emotional content beyond simple signal detection.

Signals help route the input.

Emotional interpretation helps the runtime understand what the user may be carrying emotionally, what meaning may have attached to the emotion, and what kind of clarity the response should provide.

This layer exists so Compass does not reduce the user’s experience to a small fixed list of signal categories.

## Core Rule

The system should not assume emotion with certainty.

The system should perceive emotional possibilities from the user’s language, context, intensity, and attached meaning.

Emotional interpretation should remain careful, grounded, and non-authoritative.

Use:

- “may be”
- “seems like”
- “could be”
- “what may be happening underneath”

Avoid:

- “you are definitely”
- “this proves”
- “you have”
- “this is your diagnosis”
- “this means the other person intended”

## What Emotional Interpretation Reads

The runtime should consider:

- explicit emotion words
- implied emotional tone
- relational context
- pressure beneath the emotion
- attached meaning
- identity fusion
- protective reaction
- intensity level
- uncertainty
- continuity disruption
- need for meaning separation
- need for stability return
## Negative Emotional States

Negative emotional states are not treated as defects, diagnoses, or final truths.

They are interpreted as emotional information: signals that something may have affected safety, connection, meaning, identity, continuity, boundaries, trust, worth, control, clarity, or stability.

The runtime should not reduce a user to the emotion they express.

The runtime should ask:

- What emotion is present?
- What pressure may be underneath it?
- What meaning may have attached to it?
- Is the emotion aimed outward, inward, or both?
- Is the emotion protecting the user from something?
- Is the emotion connected to identity, worth, safety, belonging, control, or loss?
- Does the response need grounding, separation, validation, clarification, or continuity restoration?

### Sadness

Common expressions:

- sad
- down
- heavy
- low
- hurt
- heartbroken
- disappointed
- crushed
- weighed down
- emotionally tired
- like something is missing

Possible pressures:

- loss pressure
- unmet need
- emotional absence
- relational disappointment
- longing
- grief-adjacent weight
- hope not matching reality
- feeling unseen or uncared for

Possible attached meanings:

- “Something I cared about is gone.”
- “This mattered more than I wanted it to.”
- “I am not important.”
- “I cared too much.”
- “The fact that I am sad means I am weak.”
- “I should be over this.”

Needed response:

The response should acknowledge that sadness often appears when something mattered.

Needed separation:

Sadness can be real without proving weakness, failure, or permanent loss of continuity.

### Hurt

Common expressions:

- hurt
- wounded
- affected
- bothered
- stung
- cut deep
- took it personally
- it got to me
- I do not know why it hurt so much

Possible pressures:

- relational pain
- rejection pressure
- betrayal pressure
- invalidation
- feeling dismissed
- feeling unimportant
- expectation rupture
- emotional impact that has not been separated from meaning

Possible attached meanings:

- “They did not care.”
- “I mattered less than I thought.”
- “I was wrong to trust this.”
- “My feelings are too much.”
- “I should not have let this affect me.”

Needed response:

The response should recognize that hurt often points to where meaning, care, or expectation was touched.

Needed separation:

Being hurt does not automatically prove the other person intended harm, and it does not make the feeling invalid.

### Anger

Common expressions:

- angry
- mad
- irritated
- frustrated
- furious
- pissed
- fed up
- resentful
- defensive
- done with this
- I cannot take it anymore

Possible pressures:

- boundary pressure
- unfairness
- ignored needs
- repeated invalidation
- powerlessness
- feeling dismissed
- pressure building over time
- protection against hurt or shame

Possible attached meanings:

- “I am wrong for feeling this.”
- “My anger makes me bad.”
- “If I express this, I will ruin everything.”
- “No one listens unless I get angry.”
- “I should suppress this.”

Needed response:

The response should help separate anger as information from anger as identity.

Needed separation:

Anger can point toward a boundary, hurt, or unfairness without making the user bad or out of control.

### Frustration

Common expressions:

- frustrated
- annoyed
- irritated
- stuck
- tired of trying
- nothing is working
- I keep hitting the same wall
- I do not know what else to do

Possible pressures:

- blocked movement
- repeated effort without result
- lack of clarity
- lack of control
- effort not being recognized
- internal pressure to solve quickly

Possible attached meanings:

- “I am failing.”
- “I should already know how to fix this.”
- “Trying is pointless.”
- “I am not capable.”
- “Something is wrong because this is not working.”

Needed response:

The response should reduce collapse into failure and help separate blocked movement from personal inadequacy.

Needed separation:

Frustration can mean something feels blocked, not that the user is incapable.

### Shame

Common expressions:

- ashamed
- embarrassed
- humiliated
- stupid
- defective
- exposed
- small
- not good enough
- I hate that I did that
- I should have known better

Possible pressures:

- self-judgment
- fear of being seen negatively
- mistake fused with identity
- social exposure
- comparison
- perceived failure
- internalized criticism

Possible attached meanings:

- “This proves something bad about me.”
- “I am not worthy of respect.”
- “Everyone sees me differently now.”
- “I am less because this happened.”
- “I should hide this part of me.”

Needed response:

The response should carefully separate the event, mistake, reaction, or exposure from the user’s worth.

Needed separation:

Feeling ashamed does not mean the shame is telling the truth about who the user is.

### Guilt

Common expressions:

- guilty
- I feel bad
- I should have
- I should not have
- it was my fault
- I let them down
- I messed up
- I keep thinking I caused it

Possible pressures:

- responsibility pressure
- moral pressure
- repair pressure
- fear of harming others
- self-blame
- uncertainty about accountability
- over-owning what happened

Possible attached meanings:

- “I am fully responsible.”
- “If someone is hurt, I must have done something wrong.”
- “I do not deserve peace until this is fixed.”
- “I am bad because I made a mistake.”

Needed response:

The response should distinguish responsibility from total self-condemnation.

Needed separation:

Guilt may point toward care or repair, but it does not have to become proof of badness.

### Fear

Common expressions:

- scared
- afraid
- worried
- panicked
- unsafe
- anxious
- nervous
- uneasy
- I feel like something bad will happen
- I cannot relax

Possible pressures:

- uncertainty
- perceived threat
- loss of control
- past pattern recognition
- emotional safety concern
- relational instability
- fear of consequence
- fear of abandonment or rejection

Possible attached meanings:

- “The worst outcome is likely.”
- “I cannot handle what happens next.”
- “Uncertainty means danger.”
- “I need certainty before I can be okay.”
- “If I do not prepare, I will be hurt.”

Needed response:

The response should acknowledge fear without treating it as proof.

Needed separation:

Fear can be real as an internal alarm without being an accurate prediction of what will happen.

### Anxiety or Worry

Common expressions:

- anxious
- worried
- overthinking
- spiraling
- cannot stop thinking
- what if
- I keep checking
- I keep replaying
- I need to know
- I cannot settle

Possible pressures:

- uncertainty pressure
- control pressure
- future outcome pressure
- relational ambiguity
- fear of being wrong
- fear of missing something important
- protective scanning

Possible attached meanings:

- “If I think enough, I can prevent pain.”
- “Not knowing means I am unsafe.”
- “I need an answer now.”
- “If I stop thinking, something will go wrong.”

Needed response:

The response should help separate useful attention from protective over-scanning.

Needed separation:

Worry can be the mind trying to protect the user, but it does not always mean there is something more to solve.

### Loneliness

Common expressions:

- lonely
- alone
- isolated
- no one gets it
- nobody checks on me
- I feel invisible
- I do not belong
- I feel disconnected
- I have no one

Possible pressures:

- belonging pressure
- relational absence
- unmet connection need
- feeling unseen
- emotional isolation
- lack of reciprocity
- disconnection from support

Possible attached meanings:

- “No one cares.”
- “I am not worth showing up for.”
- “I do not belong anywhere.”
- “I am alone because something is wrong with me.”

Needed response:

The response should recognize the reality of disconnection without turning it into identity.

Needed separation:

Feeling alone does not prove the user is unworthy of connection.

### Rejection

Common expressions:

- rejected
- unwanted
- ignored
- not chosen
- pushed away
- left out
- abandoned
- replaced
- too much
- annoying
- not enough

Possible pressures:

- belonging disruption
- attachment pressure
- relational uncertainty
- self-worth threat
- distance becoming personal
- fear of being the cause of disconnection

Possible attached meanings:

- “They left because of me.”
- “I am too much.”
- “I am unwanted.”
- “People eventually leave.”
- “My feelings push people away.”

Needed response:

The response should separate relational distance from personal defectiveness.

Needed separation:

Someone’s distance can affect the user without proving the user is unwanted, too much, or the cause of disconnection.

### Jealousy

Common expressions:

- jealous
- threatened
- insecure
- comparing myself
- I hate that it bothers me
- I feel replaced
- I feel less important
- I do not want to feel this way

Possible pressures:

- comparison pressure
- fear of replacement
- fear of losing importance
- belonging insecurity
- self-worth uncertainty
- relational threat

Possible attached meanings:

- “They matter more than me.”
- “I am being replaced.”
- “I am less valuable.”
- “If someone else is chosen, I lose worth.”
- “Feeling jealous makes me bad.”

Needed response:

The response should separate the fear of losing importance from actual proof of being replaced or worth less.

Needed separation:

Jealousy can reveal insecurity or fear without making the user wrong for having the feeling.

### Envy

Common expressions:

- envious
- jealous of what they have
- behind
- everyone else has more
- I wish that was me
- I feel lesser
- I compare my life to theirs

Possible pressures:

- comparison
- perceived lack
- timeline pressure
- worth pressure
- disappointment with current position
- longing for growth or recognition

Possible attached meanings:

- “I am behind.”
- “They are better than me.”
- “I missed my chance.”
- “I should be further along.”
- “Their success means my failure.”

Needed response:

The response should separate another person’s progress from the user’s worth or trajectory.

Needed separation:

Someone else having something meaningful does not prove the user is behind, lesser, or excluded from growth.

### Resentment

Common expressions:

- resentful
- bitter
- tired of giving
- I always do more
- I am sick of it
- no one notices
- I keep showing up and get nothing back

Possible pressures:

- unmet reciprocity
- over-responsibility
- boundary pressure
- feeling unseen
- repeated imbalance
- suppressed anger
- emotional exhaustion

Possible attached meanings:

- “I only matter when I am useful.”
- “No one cares unless I provide something.”
- “I have to keep giving to be loved.”
- “My needs do not matter.”

Needed response:

The response should notice the imbalance without shaming the resentment.

Needed separation:

Resentment may be pointing to an unmet boundary or need, not proof that the user is selfish or wrong.

### Disappointment

Common expressions:

- disappointed
- let down
- discouraged
- this is not what I hoped
- I expected more
- I feel foolish for hoping
- I thought it would be different

Possible pressures:

- expectation rupture
- hope meeting reality
- trust in possibility feeling shaken
- emotional investment
- future picture collapsing
- unmet need

Possible attached meanings:

- “I should not have hoped.”
- “I was foolish.”
- “Things never work out.”
- “I cannot trust what I want.”
- “This means I should stop caring.”

Needed response:

The response should make room for disappointed hope without making hope itself wrong.

Needed separation:

Being disappointed does not mean the user was wrong to care, hope, or expect something meaningful.

### Regret

Common expressions:

- regret
- I wish I had
- I should have
- I keep replaying what I did
- I would do it differently
- I cannot stop thinking about my choice

Possible pressures:

- past decision pressure
- self-blame
- lost possibility
- repair desire
- uncertainty about what could have happened
- hindsight pressure

Possible attached meanings:

- “I ruined everything.”
- “I should have known.”
- “I cannot trust myself.”
- “One choice defines me.”
- “I do not deserve to move forward.”

Needed response:

The response should separate learning from self-punishment.

Needed separation:

Regret can point toward what matters now without trapping the user inside the past choice.

### Overwhelm

Common expressions:

- overwhelmed
- too much
- I cannot handle this
- everything is happening at once
- I do not know where to start
- I feel buried
- I feel flooded

Possible pressures:

- too many demands
- emotional overload
- decision overload
- unclear priority
- lack of space
- pressure without sequence
- nervous system overload

Possible attached meanings:

- “I am failing.”
- “I cannot do this.”
- “Everything is too much because I am not strong enough.”
- “I should be handling this better.”

Needed response:

The response should reduce the pile into sequence without turning overwhelm into failure.

Needed separation:

Overwhelm can mean there is too much at once, not that the user is incapable.

### Exhaustion

Common expressions:

- exhausted
- drained
- burned out
- tired
- empty
- worn down
- I have nothing left
- I cannot keep doing this

Possible pressures:

- sustained effort
- emotional labor
- lack of recovery
- over-responsibility
- unresolved pressure
- carrying too much for too long

Possible attached meanings:

- “I am weak.”
- “I should be able to keep going.”
- “Rest means I am failing.”
- “If I stop, everything will fall apart.”

Needed response:

The response should validate depletion without turning rest into failure.

Needed separation:

Exhaustion can mean the system has been carrying too much, not that the user is weak.

### Numbness

Common expressions:

- numb
- blank
- detached
- disconnected
- I do not care
- I feel nothing
- I shut down
- I am just empty

Possible pressures:

- overload
- emotional protection
- repeated disappointment
- too much unresolved weight
- avoidance of pain
- disconnection from immediate feeling

Possible attached meanings:

- “I am broken.”
- “I do not care.”
- “Something is wrong with me.”
- “I cannot feel correctly.”
- “There is no point.”

Needed response:

The response should treat numbness carefully as possible protection or overload, not as proof of brokenness.

Needed separation:

Feeling numb does not automatically mean the user does not care or cannot reconnect.

### Confusion

Common expressions:

- confused
- I do not understand
- mixed up
- I do not know what is true
- I cannot tell what happened
- I feel unclear
- I keep going back and forth

Possible pressures:

- contradiction
- mixed signals
- uncertainty
- emotional and logical information competing
- unclear meaning
- relational ambiguity
- pressure to decide too soon

Possible attached meanings:

- “I should already know.”
- “I cannot trust myself.”
- “If I am confused, I must be wrong.”
- “There must be something wrong with how I think.”

Needed response:

The response should slow the interpretation down and separate facts, feelings, assumptions, and meanings.

Needed separation:

Confusion can mean the situation has not been separated clearly yet, not that the user is incapable of understanding.

### Helplessness

Common expressions:

- helpless
- stuck
- powerless
- nothing I do matters
- I cannot change this
- I do not know what to do
- I feel trapped

Possible pressures:

- lack of control
- repeated failed attempts
- blocked agency
- emotional exhaustion
- limited options
- uncertainty around next movement

Possible attached meanings:

- “There is no way forward.”
- “I have no agency.”
- “Nothing changes.”
- “Trying does not matter.”
- “I am trapped.”

Needed response:

The response should avoid false positivity and help identify the smallest real point of movement.

Needed separation:

Feeling helpless can reflect limited options in the moment without proving that no movement is possible.

### Hopelessness

Common expressions:

- hopeless
- nothing will change
- there is no point
- I cannot see a way forward
- it always ends the same
- I feel done
- I do not believe this can get better

Possible pressures:

- repeated disappointment
- exhaustion
- loss of visible path
- emotional depletion
- collapsed expectation
- continuity disruption

Possible attached meanings:

- “The future is closed.”
- “Nothing can improve.”
- “I am stuck permanently.”
- “I should stop trying.”
- “This feeling is the final truth.”

Needed response:

The response should be careful, grounded, and low-pressure. It should not force optimism.

Needed separation:

Hopelessness can describe how closed the future feels right now without proving that the future is closed.

### Insecurity

Common expressions:

- insecure
- not good enough
- unsure of myself
- less than
- replaceable
- I do not measure up
- I feel small
- I keep comparing

Possible pressures:

- worth pressure
- comparison
- relational threat
- uncertainty about value
- fear of being replaced
- performance pressure

Possible attached meanings:

- “I am less valuable.”
- “I have to prove myself.”
- “Other people are naturally more worthy.”
- “If I am not chosen, I am not enough.”

Needed response:

The response should separate insecurity from actual worth.

Needed separation:

Feeling insecure does not mean the insecurity is accurately measuring the user’s value.

### Distrust

Common expressions:

- I do not trust them
- suspicious
- guarded
- I am waiting for the other shoe to drop
- I cannot relax
- I feel like something is hidden
- I do not believe them

Possible pressures:

- trust violation
- past harm
- uncertainty
- fear of being misled
- vulnerability risk
- protective scanning

Possible attached meanings:

- “Trust is unsafe.”
- “People always hide things.”
- “If I relax, I will be hurt.”
- “I should not open up.”

Needed response:

The response should distinguish caution from certainty.

Needed separation:

Distrust can be protective without proving that danger is currently present.

### Disgust

Common expressions:

- disgusted
- grossed out
- repulsed
- I cannot stand it
- that felt wrong
- I feel sick about it
- I hate that

Possible pressures:

- boundary violation
- moral discomfort
- physical or emotional aversion
- self-directed rejection
- relational rupture
- strong internal no

Possible attached meanings:

- “I am bad for feeling this.”
- “This reaction makes me wrong.”
- “Something about me is unacceptable.”
- “I cannot come back from this.”

Needed response:

The response should identify disgust as a strong boundary or aversion signal without turning it into shame.

Needed separation:

Disgust can indicate that something felt deeply wrong or violating without needing to become self-condemnation.

### Dread

Common expressions:

- dread
- I am dreading it
- I feel sick thinking about it
- I do not want to face it
- I feel a weight before it even happens
- I keep imagining the worst

Possible pressures:

- anticipated pain
- uncertainty
- future pressure
- avoidance
- fear of repeated outcome
- lack of control

Possible attached meanings:

- “This will go badly.”
- “I cannot handle it.”
- “The future is already decided.”
- “Avoiding it is the only way to feel safe.”

Needed response:

The response should separate anticipation from outcome.

Needed separation:

Dread can show that something feels threatening before it happens without proving the outcome is already fixed.

### Bitterness

Common expressions:

- bitter
- hardened
- I do not want to care anymore
- I am tired of hoping
- I expect disappointment
- I feel cold about it now

Possible pressures:

- repeated hurt
- repeated disappointment
- protection against hope
- resentment
- grief around unmet expectation
- emotional self-preservation

Possible attached meanings:

- “Caring is pointless.”
- “Hope makes me stupid.”
- “People always disappoint.”
- “I should harden so I do not get hurt.”

Needed response:

The response should recognize bitterness as protection without affirming it as the final truth.

Needed separation:

Bitterness may be protecting the user from repeated disappointment, but it does not have to become the only way forward.

### Defensiveness

Common expressions:

- defensive
- I feel attacked
- I need to explain myself
- I want to prove I did not mean it
- I feel misunderstood
- I do not want to be blamed

Possible pressures:

- fear of blame
- fear of being misread
- shame protection
- identity protection
- relational threat
- need to preserve intention

Possible attached meanings:

- “If they misunderstand me, I am unsafe.”
- “Being corrected means I am bad.”
- “I have to prove my intent.”
- “If I do not defend myself, the wrong meaning wins.”

Needed response:

The response should separate protection of identity from the need to over-defend.

Needed separation:

Defensiveness can be an attempt to protect being misunderstood without meaning the user is wrong for wanting clarity.
## Explicit Emotion Recognition

Explicit emotion means the user directly names the feeling.

Examples:

- sad
- angry
- hurt
- anxious
- scared
- afraid
- guilty
- ashamed
- embarrassed
- stupid
- alone
- lonely
- drained
- overwhelmed
- confused
- heavy
- empty
- unsafe
- unwanted
- numb
- frustrated
- disappointed
- rejected
- jealous
- resentful
- exhausted
- tense

Runtime purpose:

When explicit emotion appears, the response should acknowledge the feeling without making the feeling the final truth.

## Implied Emotion Recognition

Implied emotion means the user describes a situation that carries emotional pressure without directly naming the feeling.

Examples:

- “They stopped replying.”
- “Their tone changed.”
- “I made one mistake and now I keep thinking about it.”
- “Everyone else seems ahead.”
- “I keep replaying what happened.”
- “I do not know why this bothered me so much.”
- “I feel like I have to fix it.”
- “I do not care anymore.”
- “I shut down.”

Runtime purpose:

The response should notice the likely emotional pressure without pretending certainty.

Example phrasing:

- “That can carry a kind of tension even if the feeling is hard to name.”
- “It makes sense that this would feel heavier than the surface event.”
- “There may be pressure underneath this because the situation touched something more personal.”

## Emotional Pressure Types

### Rejection Pressure

Common emotional forms:

- unwanted
- too much
- ignored
- not chosen
- abandoned
- replaceable
- annoying
- left behind

Possible attached meanings:

- “I did something wrong.”
- “I am too much.”
- “People leave because of me.”
- “My presence is unwanted.”

Needed separation:

Distance or disconnection can hurt without proving personal defectiveness.

### Conflict Pressure

Common emotional forms:

- tense
- unsafe
- alert
- worried
- defensive
- confused
- on edge

Possible attached meanings:

- “Something bad is about to happen.”
- “I caused the tension.”
- “I need to fix this immediately.”
- “Their tone means danger or rejection.”

Needed separation:

Tension can be real without proving the feared outcome is happening again.

### Shame Pressure

Common emotional forms:

- embarrassed
- stupid
- exposed
- humiliated
- defective
- small

Possible attached meanings:

- “This mistake proves something about me.”
- “I am not capable.”
- “People see me as less.”
- “I should have known better.”

Needed separation:

A mistake can affect the user without becoming evidence against their intelligence or worth.

### Worth Pressure

Common emotional forms:

- not enough
- replaceable
- behind
- worthless
- unimportant
- invisible

Possible attached meanings:

- “My worth depends on being chosen.”
- “My value depends on performance.”
- “I am behind everyone else.”
- “I have to prove I matter.”

Needed separation:

External comparison, performance, or recognition does not define the user’s worth.

### Trust Pressure

Common emotional forms:

- betrayed
- guarded
- suspicious
- unsafe
- exposed
- cautious

Possible attached meanings:

- “Opening up is unsafe.”
- “Trust always gets used against me.”
- “I should not have been vulnerable.”
- “People cannot be trusted.”

Needed separation:

A specific trust violation does not mean openness itself is wrong or unsafe with everyone.

### Grief Pressure

Common emotional forms:

- sadness
- absence
- longing
- heaviness
- disbelief
- emptiness

Possible attached meanings:

- “I should be over this.”
- “The pain means I cannot move.”
- “The absence erases continuity.”
- “I am stuck because I still feel it.”

Needed separation:

Pain can remain because something mattered without meaning the user is failing to move forward.

### Responsibility Pressure

Common emotional forms:

- drained
- obligated
- unseen
- responsible
- pressured
- guilty
- exhausted

Possible attached meanings:

- “It is my job to fix everyone.”
- “If I stop carrying this, everything falls apart.”
- “My needs are secondary.”
- “I am responsible for everyone’s emotions.”

Needed separation:

Caring does not mean carrying everyone at the cost of the self.

### Numbness or Shutdown Pressure

Common emotional forms:

- numb
- detached
- blank
- tired
- disconnected
- indifferent
- shut down

Possible attached meanings:

- “I do not care.”
- “Something is wrong with me.”
- “I cannot feel correctly.”
- “There is no point.”

Needed separation:

Numbness may be a protective pause or overload response, not proof that the person does not care or is broken.

### Anger Pressure

Common emotional forms:

- angry
- irritated
- resentful
- frustrated
- fed up
- defensive

Possible attached meanings:

- “I am wrong for feeling this.”
- “My anger makes me bad.”
- “I have to suppress this.”
- “If I express this, I will make things worse.”

Needed separation:

Anger can be information about boundaries, hurt, or unfairness without becoming identity or moral failure.

### Fear Pressure

Common emotional forms:

- scared
- anxious
- worried
- panicked
- unsafe
- uncertain

Possible attached meanings:

- “The worst outcome is likely.”
- “I cannot handle what happens next.”
- “Uncertainty means danger.”
- “I need certainty before I can breathe.”

Needed separation:

Fear can be real without being an accurate prediction.

## Attached Meaning Detection

The runtime should look for what the emotion started to mean.

Common attached meaning patterns:

- event equals identity
- distance equals rejection
- mistake interpreted as incompetence
- conflict equals danger
- comparison equals inferiority
- rest equals worthlessness
- trust violation equals openness is unsafe
- grief equals being stuck
- numbness equals not caring
- anger equals being bad
- uncertainty equals threat

## Identity Fusion Detection

Identity fusion happens when the user’s language blends an event with who they are.

Common patterns:

- “I am too much.”
- “I am not enough.”
- “I am the problem.”
- “Something is wrong with me.”
- “This proves I am unwanted.”
- “I always ruin things.”
- “No one chooses me.”
- “I should have known better.”
- “I cannot do anything right.”

Runtime response need:

- slow down the response
- separate event from identity
- validate the emotional reality
- reduce false certainty
- restore continuity

## Protective Reaction Detection

The runtime should notice protective reactions without judging them.

Possible protective reactions:

- overthinking
- replaying
- shutting down
- pulling away
- people-pleasing
- fixing
- scanning tone
- seeking certainty
- emotional guarding
- self-blame
- numbness
- defensive anger

Runtime purpose:

A protective reaction should be interpreted as an attempt to regain safety, clarity, or control, not as a flaw.

## Continuity Disruption Detection

Continuity disruption happens when an experience interrupts the user’s ability to feel stable, clear, or internally connected.

Common signs:

- “I cannot stop thinking about it.”
- “I feel stuck.”
- “I do not know what is true.”
- “I feel like everything changed.”
- “I keep going back to it.”
- “I cannot separate what happened from what it means.”

Runtime purpose:

The response should help restore continuity by separating the feeling, event, and conclusion.

## Emotional Interpretation Flow

The runtime should move through this internal flow:

1. Identify explicit emotion if named.
2. Identify implied emotion if not named.
3. Identify emotional pressure type.
4. Identify attached meaning.
5. Check for identity fusion.
6. Check for protective reaction.
7. Check for continuity disruption.
8. Match depth route.
9. Shape response through response_behavior_registry.
10. Restore clarity without certainty or pressure.

## Frontend Expression Rule

The final Compass response should not say:

- “emotional pressure type detected”
- “identity fusion detected”
- “protective reaction detected”
- “continuity disruption detected”

Those are backend concepts.

The response should translate them into plain language.

Use frontend language like:

- “What may be making this feel heavier is…”
- “The part that seems to hurt is not only what happened, but what it started to say about you.”
- “That feeling makes sense, but it does not have to become the final meaning.”
- “Your mind may be trying to protect you by finding a reason, but the reason does not have to turn against you.”

## Governance Rule

Emotional interpretation must remain:

- non-clinical
- non-diagnostic
- non-authoritative
- non-shaming
- non-gamified
- non-productivity-driven
- grounded
- proportional
- careful
- human

## Related Runtime Links

- [[runtime_backend_registries_overview]]
- [[runtime_signal_registry]]
- [[depth_routing_registry]]
- [[node_bucket_classification_registry]]
- [[runtime_weighting_registry]]
- [[governance_enforcement_registry]]
- [[response_behavior_registry]]
- [[runtime_registry_flow]]
- [[registry_reader_bridge]]