# Card Accuracy Percentage Metric Registry

## Metric
Card Accuracy %

## Formula
correct callout card retests ÷ total card retests

## Meaning
This metric measures whether Compass selected the correct callout card for the route: What Needs to Separate, What Needs to Stay Clear, or What Needs to Be Clarified.

## What changes it
- card retest increases denominator
- correct card selection increases numerator
