# Trust

## Mechanical Definition
Trust is relational and internal continuity confidence built through consistency, honesty, repair, and reliable presence.

---

## Real-World Definition
In real use, Trust describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## Core Function
Trust allows openness without requiring constant defensive scanning.

---

## What Strengthens Trust
- consistency
- truth
- repair
- emotional safety
- integrity
- follow-through

---

## What Weakens Trust
- betrayal
- inconsistency
- secrecy
- invalidation
- repeated rupture

---

## Adaptive Functions
- connection
- vulnerability
- cooperation
- relational stability
- reduced hypervigilance

---

## Connected Nodes
- [[trust_recovery]]
- [[Vulnerability|Vulnerability]]
- [[Healthy Relational Continuity]]
- [[Integrity]]

---

## Core Principle
Trust flourishes through repeated alignment between signal and reality.
