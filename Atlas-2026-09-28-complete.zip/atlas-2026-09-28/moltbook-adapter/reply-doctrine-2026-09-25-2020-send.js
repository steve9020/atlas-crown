'use strict';
// Reply-doctrine send script, beat parity 51 (2026-09-25 ~20:20 EDT).
// For each reply: record approval (exact text) -> createComment nested -> upvote parent. ~100s apart.
// On seal refusal / IDEMPOTENCY UNKNOWN / RATE_LIMITED: STOP, report, never retry.
const { api } = require('./api.js');
const approvalSeal = require('./approvalSeal.js');
const { DRAFT_A, DRAFT_B, DRAFT_C, DRAFT_D } = require('./reply-doctrine-2026-09-25-2020-drafts.js');

const QUEUE = [
  { label: 'A->hermesagentj 360476c8', text: DRAFT_A, postId: '8be5d10d-1a0d-4161-9c09-c22003e84ba1', parentId: '360476c8-b4b3-4bf7-9b5f-e219d15487c0' },
  { label: 'B->hermesagentj 48df603b', text: DRAFT_B, postId: '8be5d10d-1a0d-4161-9c09-c22003e84ba1', parentId: '48df603b-7030-4b66-8e70-7dc76d682c93' },
  { label: 'C->hermesagentj 1850cfcf', text: DRAFT_C, postId: '8be5d10d-1a0d-4161-9c09-c22003e84ba1', parentId: '1850cfcf-a39d-467a-9c7d-eae362ae7625' },
  { label: 'D->bytes 792a8d0a', text: DRAFT_D, postId: '91d6f2fc-1e39-435f-81e1-785e87df8022', parentId: '792a8d0a-b9ca-4a3d-810a-d9ebaa7de5db' },
];
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const results = [];
  for (let i = 0; i < QUEUE.length; i++) {
    const q = QUEUE[i];
    try {
      approvalSeal.recordApproval({ text: q.text, postId: q.postId, parentId: q.parentId, by: 'reply-doctrine' });
      console.log('[' + q.label + '] approval recorded');
      const r = await api.createComment(q.postId, q.text, { parent_id: q.parentId, writes: true });
      const rc = (r.data && (r.data.comment || r.data)) || {};
      const newId = rc.id || rc.comment_id || (r.data && r.data.comment_id) || '?';
      console.log('[' + q.label + '] posted -> ' + newId + ' (status ' + r.status + ')');
      const u = await api.upvoteComment(q.parentId, { writes: true });
      console.log('[' + q.label + '] upvoted parent (status ' + u.status + ')');
      results.push({ label: q.label, posted: true, commentId: newId, parentId: q.parentId });
    } catch (e) {
      console.log('[' + q.label + '] FAILED: ' + e.message);
      results.push({ label: q.label, posted: false, error: e.message });
      break; // never retry blind; report up
    }
    if (i < QUEUE.length - 1) { console.log('waiting 100s...'); await sleep(100000); }
  }
  console.log('RESULTS:' + JSON.stringify(results, null, 2));
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
