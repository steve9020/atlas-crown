# Courage

## Mechanical Definition
Courage is action-capacity under fear, uncertainty, vulnerability, or risk without requiring the absence of discomfort.

---

## Real-World Definition
In real use, Courage describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## Core Function
Courage allows continuity to move forward when fear alone would narrow action.

---

## What Strengthens Courage
- purpose
- support
- self-trust
- clarity
- values
- grounded risk

---

## What Weakens Courage
- shame
- avoidance
- helplessness
- fear fusion
- isolation

---

## Adaptive Functions
- agency
- expression
- repair
- growth
- boundary movement

---

## Connected Nodes
- [[Fear]]
- [[Purpose|Purpose]]
- [[Self-Authorship]]
- [[Vulnerability|Vulnerability]]
- [[Discipline]]

---

## Core Principle
Courage is not fearlessness; it is movement with preserved integrity.
