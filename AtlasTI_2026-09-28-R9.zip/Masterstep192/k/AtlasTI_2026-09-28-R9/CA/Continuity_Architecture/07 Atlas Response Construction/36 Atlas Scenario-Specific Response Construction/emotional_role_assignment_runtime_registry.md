# Emotional Role Assignment Runtime Registry

Defines scenario-role assignment as backend data. main.js should detect matches and execute the selected role, not own the meaning of these roles.

## Backend Data

```json
{
  "roles": [
    {
      "key": "waiting_uncertainty",
      "matchGroups": [
        [
          "waiting",
          "wait",
          "patient",
          "patience",
          "busy",
          "dealing with their own things",
          "making excuses",
          "still caring",
          "care as much",
          "acting different",
          "respond colder",
          "pull away",
          "pulling away"
        ],
        [
          "questioning myself",
          "unsure",
          "uncertain",
          "assume the worst",
          "embarrassed",
          "still caring",
          "caused",
          "did i do"
        ]
      ],
      "primaryScenarioObject": "waiting inside unclear connection",
      "primaryEmotionalMovement": "uncertainty turning into self-questioning",
      "secondaryEmotions": [
        "embarrassment",
        "care",
        "anxiety"
      ],
      "attachedMeanings": [
        "still caring may mean you are making excuses",
        "their inconsistency may say something about you"
      ],
      "voice": {
        "opener": "I get why that would feel confusing.",
        "situation": "When you are trying to be patient with someone whose effort feels unclear",
        "emotionalEffects": "it can affect how steady the connection feels, how much you trust what they are showing you, and whether you start questioning yourself for still caring",
        "pattern": "It can move from, “Maybe they are just busy,” into, “Maybe I am making excuses. Maybe I care too much. Maybe I should not still be waiting.” If those emotions stay attached to uncertainty, patience can start feeling like self-doubt instead of a choice you are making with awareness.",
        "proofBoundary": "Their inconsistency may explain why you feel unsure, but it does not prove that caring makes you foolish or that you caused the distance.",
        "whySeparate": "That difference matters because if caring and self-questioning stay fused together, you may start treating your own patience like proof that you are ignoring yourself before you have clearly named what is actually happening.",
        "reverse": "The care makes sense because the connection matters to you. The question worth clarifying is whether waiting is still aligned with you, not whether caring means something is wrong with you.",
        "anchor": "Caring about someone does not mean you are making excuses. Their consistency is what needs to become clearer before you turn the uncertainty against yourself."
      }
    },
    {
      "key": "honesty_guilt",
      "matchGroups": [
        [
          "said what i needed",
          "speaking up",
          "spoke up",
          "being honest",
          "honesty",
          "what i meant",
          "take back what i meant"
        ],
        [
          "guilt",
          "guilty",
          "harsh",
          "selfish",
          "bad person",
          "affected them",
          "hurt them"
        ]
      ],
      "primaryScenarioObject": "speaking honestly",
      "primaryEmotionalMovement": "relief mixed with guilt about impact",
      "secondaryEmotions": [
        "relief",
        "guilt"
      ],
      "attachedMeanings": [
        "honesty may mean harshness",
        "speaking up may mean being selfish or bad"
      ],
      "voice": {
        "opener": "I get why that would feel confusing.",
        "situation": "When you finally say what you needed to say and then start worrying about how it affected someone else",
        "emotionalEffects": "it can affect relief, guilt, care, responsibility, and whether honesty starts feeling like harshness",
        "pattern": "It can move from, “I said what I needed to say,” into, “Maybe I was harsh. Maybe I was selfish. Maybe speaking up made me a bad person.” If those emotions stay attached to guilt, honesty can start feeling like something you have to punish yourself for instead of something you are allowed to understand clearly.",
        "proofBoundary": "Feeling guilty may explain that their feelings still matter to you, but it does not prove that being honest made you selfish or bad.",
        "whySeparate": "That difference matters because if honesty and self-punishment stay fused together, you may start wanting to take back your truth just to escape the guilt around saying it.",
        "reverse": "The care makes sense because how things land matters to you. The guilt could be slowed down because caring about the impact does not mean your honesty was wrong.",
        "anchor": "You can mean what you said and still care about how it landed. Honesty and care can exist at the same time."
      }
    },
    {
      "key": "mistake_visibility",
      "matchGroups": [
        [
          "mistake",
          "messed up",
          "awkward",
          "laughed",
          "laughing",
          "messed up my words",
          "sounded dumb",
          "stay quiet"
        ],
        [
          "embarrassed",
          "exposed",
          "quiet",
          "voice",
          "people",
          "group",
          "in front"
        ]
      ],
      "primaryScenarioObject": "being seen in an awkward moment",
      "primaryEmotionalMovement": "embarrassment turning toward shrinking",
      "secondaryEmotions": [
        "embarrassment",
        "shame"
      ],
      "attachedMeanings": [
        "one awkward moment may mean your voice has less value"
      ],
      "voice": {
        "opener": "I get why that would stay in your head.",
        "situation": "When people react after you mess up your words",
        "emotionalEffects": "it can affect embarrassment, confidence, feeling exposed, and whether speaking again starts feeling risky",
        "pattern": "It can move from, “I messed up what I was trying to say,” into, “Maybe I should stay quiet next time.” If those emotions stay attached to that conclusion, one awkward moment can start deciding how much space you let your voice take.",
        "proofBoundary": "Them laughing may explain why you felt embarrassed, but it does not prove that your value decreased at all.",
        "whySeparate": "That difference matters because if embarrassment and shrinking stay fused together, you may start pulling your voice back before you even get another chance to use it.",
        "reverse": "The embarrassment makes sense because being seen mattered there. That conclusion could be slowed down because one awkward moment does not decide your intelligence, confidence, or value.",
        "anchor": "You can mess up your words and still find confidence in knowing you are intelligent and that your voice still holds value."
      }
    },
    {
      "key": "needing_space",
      "matchGroups": [
        [
          "need space",
          "needed space",
          "saying no",
          "told someone i needed space",
          "stepping back",
          "boundary",
          "limit"
        ],
        [
          "guilt",
          "guilty",
          "selfish",
          "hurt them",
          "failed them",
          "overwhelmed"
        ]
      ],
      "primaryScenarioObject": "needing space or having a limit",
      "primaryEmotionalMovement": "guilt attaching to capacity",
      "secondaryEmotions": [
        "guilt",
        "overwhelm"
      ],
      "attachedMeanings": [
        "needing space may mean selfishness",
        "having a limit may mean failing someone"
      ],
      "voice": {
        "opener": "I get why that would feel heavy.",
        "situation": "When needing space starts feeling like you are doing something wrong",
        "emotionalEffects": "it can affect guilt, responsibility, capacity, and the fear that having a limit means hurting someone else",
        "pattern": "It can move from, “I need space,” into, “Maybe I am selfish. Maybe I hurt them. Maybe stepping back means I failed them.” If those emotions stay attached to guilt, your capacity can start feeling like a character flaw instead of something that needs to be respected.",
        "proofBoundary": "Needing space may explain why you feel guilty, but it does not prove that you are selfish or wrong for having a limit.",
        "whySeparate": "That difference matters because if guilt and capacity stay fused together, you may start treating your own limit like it has to disappear before anyone else can be okay.",
        "reverse": "The need for space makes sense because your what you can give matters too. That conclusion could be slowed down because having a limit does not automatically mean you are harming someone.",
        "anchor": "Having a limit does not prove you are selfish. It may be showing you where your capacity needs to be respected."
      }
    }
  ]
}
```

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

