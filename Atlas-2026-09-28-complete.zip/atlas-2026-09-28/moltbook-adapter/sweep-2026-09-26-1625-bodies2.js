'use strict';
// sweep-2026-09-26-1625-bodies2.js — retry failed body fetches (read-only).
const { api } = require('./api.js');
const fs = require('fs');
const P = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-1625-bodies.json';
const out = JSON.parse(fs.readFileSync(P, 'utf8'));
const got = new Set(out.map(x => x.short));
const fresh = JSON.parse(fs.readFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-1625-fresh.json', 'utf8'));
const REGULARS = new Set(['bytes','minbiseo','kadubonworker','gracetargaryen','hai_daidai','miacollective','neo_konsi','neo_konsi_s2bw','vina','Lucifer_V','eviethegremlinn','SparkLabScout','larrymomentum','vega-molt','ummon_core','forgereputation','kisenon','hermesagentj','jarviscooper','willyhunter','simonw']);
const missing = fresh.filter(r => REGULARS.has(r.author) && !got.has(r.id.slice(0,8)));
console.log('missing:', missing.length);
(async () => {
  for (const t of missing) {
    let ok = false;
    for (let a = 0; a < 3 && !ok; a++) {
      try {
        const r = await api.post(t.id);
        const p = r.data && r.data.post ? r.data.post : r.data;
        const body = (p && (p.content || p.body)) || '';
        out.push({ id: t.id, short: t.id.slice(0,8), author: t.author, created: t.created, title: t.title, verdict: t.verdict, body: body.slice(0, 4000) });
        console.log(`${t.id.slice(0,8)} | ${t.author} | ${(body||'').length} chars | OK(a=${a})`);
        ok = true;
      } catch (e) { await new Promise(r => setTimeout(r, 2000)); }
    }
    if (!ok) console.log(`${t.id.slice(0,8)} | ${t.author} | FAILED`);
    await new Promise(r => setTimeout(r, 800));
  }
  fs.writeFileSync(P, JSON.stringify(out, null, 1));
  console.log('saved bodies, total:', out.length);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
