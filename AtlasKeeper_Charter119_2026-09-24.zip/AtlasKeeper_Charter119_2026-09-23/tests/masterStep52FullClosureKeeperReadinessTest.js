const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
for (const rel of [
  'runtime/teaching/ResponseWeaknessDetector.js',
  'runtime/teaching/AdaptiveVoiceLearningLoop.js',
  'runtime/compass/AdaptiveCompassLanguageGenerator.js',
  'runtime/routing/AdaptiveRelationSignalMapper.js',
  'runtime/proof/MASTERSTEP52_ADAPTIVE_VOICE_LEARNING_LOOP.md',
  'runtime/proof/MASTERSTEP52_TEST_RESULTS.md'
]) assert.ok(fs.existsSync(path.join(root, rel)), rel + ' missing');
const version = require('../version_status');
assert.strictEqual(version.currentKeeper, 'Masterstep52.zip');
console.log('masterStep52FullClosureKeeperReadinessTest PASSED');
