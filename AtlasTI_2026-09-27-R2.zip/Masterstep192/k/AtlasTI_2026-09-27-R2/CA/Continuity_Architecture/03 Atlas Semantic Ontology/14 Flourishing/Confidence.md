# Confidence

## Mechanical Definition
Confidence is grounded self-trust in capacity, direction, or response ability without requiring certainty or superiority.

---

## Real-World Definition
In real use, Confidence describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## Core Function
Confidence supports agency and reduces excessive dependency on external validation.

---

## What Strengthens Confidence
- competence
- practice
- integrity
- feedback integration
- self-worth
- resilience

---

## What Weakens Confidence
- comparison
- shame
- repeated failure
- invalidation
- perfectionism

---

## Adaptive Functions
- action
- stability
- expression
- decision-making
- recovery after error

---

## Connected Nodes
- [[Self-Worth]]
- [[Discipline]]
- [[Integrity]]
- [[Self-Authorship]]
- [[Resilience|Resilience]]

---

## Core Principle
Confidence is stable enough self-trust, not certainty that failure cannot happen.
