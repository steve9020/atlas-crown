# Frontend Feel Calibration Registry

## Questions
- does this feel safe?
- relieving?
- emotionally invasive?
- too polished?
- too AI?
- too emotionally heavy?
- too emotionally absent?

## Goal
The frontend should feel understood, grounded, and clarifying rather than analyzed.
