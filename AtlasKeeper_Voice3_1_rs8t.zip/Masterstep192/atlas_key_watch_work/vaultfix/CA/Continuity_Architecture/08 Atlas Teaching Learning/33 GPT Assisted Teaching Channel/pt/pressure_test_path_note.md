---
runtime_layer: teaching_archive
purpose: Explains shortened pressure-test paths for Windows extraction compatibility.
---

# Pressure Test Path Note

The pressure-test folder and filenames were shortened to avoid Windows path-length errors during copying/extraction.

The content was not removed. The short `pt/b01` through `pt/b08` folders correspond to the eight category pressure-test batches.

These files remain teaching/archive material. Approved reusable lessons still live in `31 Atlas Response Intelligence`.
