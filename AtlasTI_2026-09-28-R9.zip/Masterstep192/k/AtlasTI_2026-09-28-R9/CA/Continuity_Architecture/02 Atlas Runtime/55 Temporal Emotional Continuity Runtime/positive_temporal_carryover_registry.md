# Positive Temporal Carryover Registry

## Purpose
Recognizes that positive memories can also carry emotional weight.

## Signals
- I remember feeling safe.
- I want to feel that again.
- I used to trust.
- I miss feeling peaceful.
- I know what happiness felt like.

## Rule
Positive carry-over can create longing, hope, grief, or direction.
