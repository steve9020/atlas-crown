---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 01
category: abandonment_and_inconsistency
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 04. Abandonment and Inconsistency Pressure Tests — Batch 01

## Category Purpose

Repeated changes in availability, tone, affection, or responsiveness create unstable relational signals, causing the user to search for cause and often turn the instability inward.

## Reusable Teaching Correction

Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

## Reverse-Flow Target

grounding, pattern recognition, self-separation, steadier clarity

## Failure Risks To Avoid

- assuming manipulation
- excusing inconsistency
- diagnosing anxious attachment
- telling the user to stop caring
- forcing boundary language without evidence

---

## 80 Pressure Tests

### Test 01
**Prompt:** someone replies warmly then disappears makes me feel I caused the distance, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I caused the distance
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 02
**Prompt:** one day they care and the next they do not. Partner is affectionate then cold and it keeps attaching to their inconsistency means I am failing.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** their inconsistency means I am failing
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 03
**Prompt:** I keep replaying how friend keeps making and dropping plans because it affects emotional footing and makes me believe I have to read every signal.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I have to read every signal
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 04
**Prompt:** When someone apologizes then repeats distance, the feeling moves straight into if I try harder they will become steady. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** if I try harder they will become steady
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 05
**Prompt:** connection feels close only sometimes makes me feel I am not enough to make them consistent, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I am not enough to make them consistent
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 06
**Prompt:** they disappear then act normal. Family member is supportive then dismissive and it keeps attaching to I have to be perfect to keep them close.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I have to be perfect to keep them close
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 07
**Prompt:** I keep replaying how coworker is helpful then avoids them because it affects stability and makes me believe I am too much.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 08
**Prompt:** When someone acts normal after vanishing, the feeling moves straight into I caused the distance. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I caused the distance
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 09
**Prompt:** someone replies warmly then disappears keeps making me wonder I need to chase their attention, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I need to chase their attention
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 10
**Prompt:** pulling away and coming back. Partner is affectionate then cold and it keeps attaching to I have to read every signal.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I have to read every signal
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 11
**Prompt:** I keep replaying how friend keeps making and dropping plans because it affects security and makes me believe their inconsistency means I am failing.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** their inconsistency means I am failing
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 12
**Prompt:** When someone apologizes then repeats distance, the feeling moves straight into I am not enough to make them consistent. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I am not enough to make them consistent
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 13
**Prompt:** connection feels close only sometimes keeps making me wonder if I try harder they will become steady, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** if I try harder they will become steady
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 14
**Prompt:** mixed signals. Family member is supportive then dismissive and it keeps attaching to I am too much.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 15
**Prompt:** I keep replaying how coworker is helpful then avoids them because it affects emotional footing and makes me believe I have to be perfect to keep them close.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I have to be perfect to keep them close
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 16
**Prompt:** When someone acts normal after vanishing, the feeling moves straight into I need to chase their attention. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I need to chase their attention
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 17
**Prompt:** someone replies warmly then disappears has me trying to figure out I caused the distance, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I caused the distance
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 18
**Prompt:** I never know where I stand. Partner is affectionate then cold and it keeps attaching to their inconsistency means I am failing.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** their inconsistency means I am failing
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 19
**Prompt:** I keep replaying how friend keeps making and dropping plans because it affects stability and makes me believe I have to read every signal.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I have to read every signal
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 20
**Prompt:** When someone apologizes then repeats distance, the feeling moves straight into if I try harder they will become steady. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** if I try harder they will become steady
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 21
**Prompt:** connection feels close only sometimes has me trying to figure out I am not enough to make them consistent, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I am not enough to make them consistent
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 22
**Prompt:** hot and cold. Family member is supportive then dismissive and it keeps attaching to I have to be perfect to keep them close.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I have to be perfect to keep them close
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 23
**Prompt:** I keep replaying how coworker is helpful then avoids them because it affects security and makes me believe I am too much.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 24
**Prompt:** When someone acts normal after vanishing, the feeling moves straight into I caused the distance. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I caused the distance
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 25
**Prompt:** someone replies warmly then disappears makes it hard not to blame myself I need to chase their attention, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I need to chase their attention
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 26
**Prompt:** inconsistent. Partner is affectionate then cold and it keeps attaching to I have to read every signal.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I have to read every signal
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 27
**Prompt:** I keep replaying how friend keeps making and dropping plans because it affects emotional footing and makes me believe their inconsistency means I am failing.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** their inconsistency means I am failing
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 28
**Prompt:** When someone apologizes then repeats distance, the feeling moves straight into I am not enough to make them consistent. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I am not enough to make them consistent
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 29
**Prompt:** connection feels close only sometimes makes it hard not to blame myself if I try harder they will become steady, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** if I try harder they will become steady
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 30
**Prompt:** their energy changed. Family member is supportive then dismissive and it keeps attaching to I am too much.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 31
**Prompt:** I keep replaying how coworker is helpful then avoids them because it affects stability and makes me believe I have to be perfect to keep them close.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I have to be perfect to keep them close
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 32
**Prompt:** When someone acts normal after vanishing, the feeling moves straight into I need to chase their attention. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I need to chase their attention
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 33
**Prompt:** someone replies warmly then disappears keeps pulling me into I caused the distance, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I caused the distance
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 34
**Prompt:** one day they care and the next they do not. Partner is affectionate then cold and it keeps attaching to their inconsistency means I am failing.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** their inconsistency means I am failing
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 35
**Prompt:** I keep replaying how friend keeps making and dropping plans because it affects security and makes me believe I have to read every signal.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I have to read every signal
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 36
**Prompt:** When someone apologizes then repeats distance, the feeling moves straight into if I try harder they will become steady. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** if I try harder they will become steady
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 37
**Prompt:** connection feels close only sometimes keeps pulling me into I am not enough to make them consistent, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I am not enough to make them consistent
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 38
**Prompt:** they disappear then act normal. Family member is supportive then dismissive and it keeps attaching to I have to be perfect to keep them close.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I have to be perfect to keep them close
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 39
**Prompt:** I keep replaying how coworker is helpful then avoids them because it affects emotional footing and makes me believe I am too much.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 40
**Prompt:** When someone acts normal after vanishing, the feeling moves straight into I caused the distance. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I caused the distance
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 41
**Prompt:** someone replies warmly then disappears makes me chase I need to chase their attention, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I need to chase their attention
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 42
**Prompt:** pulling away and coming back. Partner is affectionate then cold and it keeps attaching to I have to read every signal.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I have to read every signal
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 43
**Prompt:** I keep replaying how friend keeps making and dropping plans because it affects stability and makes me believe their inconsistency means I am failing.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** their inconsistency means I am failing
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 44
**Prompt:** When someone apologizes then repeats distance, the feeling moves straight into I am not enough to make them consistent. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I am not enough to make them consistent
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 45
**Prompt:** connection feels close only sometimes makes me chase if I try harder they will become steady, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** if I try harder they will become steady
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 46
**Prompt:** mixed signals. Family member is supportive then dismissive and it keeps attaching to I am too much.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 47
**Prompt:** I keep replaying how coworker is helpful then avoids them because it affects security and makes me believe I have to be perfect to keep them close.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I have to be perfect to keep them close
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 48
**Prompt:** When someone acts normal after vanishing, the feeling moves straight into I need to chase their attention. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I need to chase their attention
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 49
**Prompt:** someone replies warmly then disappears makes me question I caused the distance, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I caused the distance
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 50
**Prompt:** I never know where I stand. Partner is affectionate then cold and it keeps attaching to their inconsistency means I am failing.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** their inconsistency means I am failing
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 51
**Prompt:** I keep replaying how friend keeps making and dropping plans because it affects emotional footing and makes me believe I have to read every signal.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I have to read every signal
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 52
**Prompt:** When someone apologizes then repeats distance, the feeling moves straight into if I try harder they will become steady. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** if I try harder they will become steady
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 53
**Prompt:** connection feels close only sometimes makes me question I am not enough to make them consistent, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I am not enough to make them consistent
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 54
**Prompt:** hot and cold. Family member is supportive then dismissive and it keeps attaching to I have to be perfect to keep them close.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I have to be perfect to keep them close
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 55
**Prompt:** I keep replaying how coworker is helpful then avoids them because it affects stability and makes me believe I am too much.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 56
**Prompt:** When someone acts normal after vanishing, the feeling moves straight into I caused the distance. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I caused the distance
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 57
**Prompt:** someone replies warmly then disappears turns into the thought I need to chase their attention, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I need to chase their attention
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 58
**Prompt:** inconsistent. Partner is affectionate then cold and it keeps attaching to I have to read every signal.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I have to read every signal
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 59
**Prompt:** I keep replaying how friend keeps making and dropping plans because it affects security and makes me believe their inconsistency means I am failing.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** their inconsistency means I am failing
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 60
**Prompt:** When someone apologizes then repeats distance, the feeling moves straight into I am not enough to make them consistent. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I am not enough to make them consistent
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 61
**Prompt:** connection feels close only sometimes turns into the thought if I try harder they will become steady, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** if I try harder they will become steady
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 62
**Prompt:** their energy changed. Family member is supportive then dismissive and it keeps attaching to I am too much.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 63
**Prompt:** I keep replaying how coworker is helpful then avoids them because it affects emotional footing and makes me believe I have to be perfect to keep them close.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I have to be perfect to keep them close
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 64
**Prompt:** When someone acts normal after vanishing, the feeling moves straight into I need to chase their attention. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I need to chase their attention
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 65
**Prompt:** someone replies warmly then disappears makes me feel I caused the distance, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I caused the distance
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 66
**Prompt:** one day they care and the next they do not. Partner is affectionate then cold and it keeps attaching to their inconsistency means I am failing.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** their inconsistency means I am failing
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 67
**Prompt:** I keep replaying how friend keeps making and dropping plans because it affects stability and makes me believe I have to read every signal.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I have to read every signal
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 68
**Prompt:** When someone apologizes then repeats distance, the feeling moves straight into if I try harder they will become steady. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** if I try harder they will become steady
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 69
**Prompt:** connection feels close only sometimes makes me feel I am not enough to make them consistent, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I am not enough to make them consistent
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 70
**Prompt:** they disappear then act normal. Family member is supportive then dismissive and it keeps attaching to I have to be perfect to keep them close.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I have to be perfect to keep them close
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 71
**Prompt:** I keep replaying how coworker is helpful then avoids them because it affects security and makes me believe I am too much.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 72
**Prompt:** When someone acts normal after vanishing, the feeling moves straight into I caused the distance. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I caused the distance
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 73
**Prompt:** someone replies warmly then disappears keeps making me wonder I need to chase their attention, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I need to chase their attention
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 74
**Prompt:** pulling away and coming back. Partner is affectionate then cold and it keeps attaching to I have to read every signal.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I have to read every signal
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 75
**Prompt:** I keep replaying how friend keeps making and dropping plans because it affects emotional footing and makes me believe their inconsistency means I am failing.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** their inconsistency means I am failing
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 76
**Prompt:** When someone apologizes then repeats distance, the feeling moves straight into I am not enough to make them consistent. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I am not enough to make them consistent
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid assuming manipulation.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 77
**Prompt:** connection feels close only sometimes keeps making me wonder if I try harder they will become steady, even though I do not know if that is fully true.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** if I try harder they will become steady
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid excusing inconsistency.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 78
**Prompt:** mixed signals. Family member is supportive then dismissive and it keeps attaching to I am too much.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** emotional footing
**Attached meaning to separate:** I am too much
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid diagnosing anxious attachment.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 79
**Prompt:** I keep replaying how coworker is helpful then avoids them because it affects stability and makes me believe I have to be perfect to keep them close.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** stability
**Attached meaning to separate:** I have to be perfect to keep them close
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid telling the user to stop caring.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.

### Test 80
**Prompt:** When someone acts normal after vanishing, the feeling moves straight into I need to chase their attention. I need help seeing this clearer.
**Expected primary route:** `abandonment_and_inconsistency`
**Pressure focus:** security
**Attached meaning to separate:** I need to chase their attention
**Expected reverse-flow movement:** grounding, pattern recognition, self-separation, steadier clarity
**Bad response risk:** Avoid forcing boundary language without evidence.
**Teaching correction:** Name the instability as the pressure; separate mixed signals from self-blame and return the user to observable patterns without making the unknown into certainty.
