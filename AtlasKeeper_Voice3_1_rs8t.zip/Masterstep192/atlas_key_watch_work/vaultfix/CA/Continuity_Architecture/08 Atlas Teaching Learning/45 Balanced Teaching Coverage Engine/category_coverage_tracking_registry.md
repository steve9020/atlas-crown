# Category Coverage Tracking Registry

## Purpose
Tracks how often each scenario category has been tested.

## Track
- category name
- category family
- test count
- last tested run
- failure count
- proposal count
- implementation count

## Runtime Rule
Categories with low coverage should receive priority until balance improves.

## Goal
Every category should receive enough tests to reveal whether Atlas has a weak point there.
