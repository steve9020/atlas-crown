const {detectAxes}=require(process.cwd()+'/Cognition/engine/AxisEngine');
const cases=[
['He was aiming to finish before noon.',['intention']],['They banked on the delivery arriving.',['expectation']],['I accept my part in the failure.',['responsibility','acceptance_rejection']],
['She established a limit around weekend calls.',['boundary']],['I depend on her follow-through.',['trust']],['He honored the decision even though he disliked it.',['respect']],
['The workload was inequitable.',['fairness']],['We compared both options before moving.',['comparison']],['That triggered the outage.',['causation']],['She persisted at it for hours.',['effort']],
['The attempt ended poorly.',['outcome']],['What we had was enough to proceed.',['sufficiency']],['The role was theirs.',['ownership']],['He viewed the silence as rejection.',['interpretation']],
['I witnessed the event happen.',['observation_evidence']],['They chose the route and expected us to follow.',['choice','expectation']],['She meant to repair it, but the result still felt insufficient.',['intention','repair','outcome','sufficiency']],
['I cannot know whether that caused the change.',['certainty','causation','change']],['He relied on her, yet she disregarded the limit he had set.',['trust','respect','boundary']],
['The socket connection timed out again.',[]],['The change machine is beside the vending machine.',[]],['The trust fund statement arrived.',[]],['The control panel rebooted.',[]],['The boundary layer is documented.',[]],['The outcome column contains nulls.',[]],['The choice menu is disabled.',[]],['The county fair closes tonight.',[]]
];
let hit=0,total=0,fp=0; const misses=[], falsepos=[];
for(const [text,expected] of cases){const r=detectAxes(text); for(const a of expected){total++; if(r.axes.includes(a))hit++;else misses.push({text,a,got:r.axes});} if(!expected.length&&r.axes.length){fp++;falsepos.push({text,got:r.axes});}}
console.log(JSON.stringify({cases:cases.length,expected:{hit,total},neutral_false_positive_cases:fp,misses,falsepos},null,2));
if(hit!==total||fp) process.exitCode=1;
