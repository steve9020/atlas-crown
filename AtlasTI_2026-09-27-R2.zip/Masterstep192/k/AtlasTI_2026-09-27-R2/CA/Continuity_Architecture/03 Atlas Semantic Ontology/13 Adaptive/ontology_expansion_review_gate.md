---
title: Ontology Expansion Review Gate
status: active
runtime_layer: ontology_growth
priority: high
governed_by: [[human_approval_gate_overview]]
---

# Ontology Expansion Review Gate

Atlas may detect ontology gaps, but it must not silently create or activate new ontology intelligence.

## Runtime rule
A proposed ontology expansion must identify the missing pattern, the closest existing node, duplicate risk, merge path, target folder, and retest reason.

## Expansion states
- gap detected
- proposal drafted
- duplicate/merge checked
- approved
- retested
- integrated

## Related Runtime Links
- [[semantic_proposal_system_overview]]
- [[duplicate_detection_overview]]
- [[safe_merge_cleanup_report]]
