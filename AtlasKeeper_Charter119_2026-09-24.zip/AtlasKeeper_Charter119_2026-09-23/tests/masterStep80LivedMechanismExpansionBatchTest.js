const assert = require('assert');
const { runMasterStep80LivedMechanismExpansionProof, EXPANSION_PROMPTS } = require('../runtime/backend/closedLoop/LivedMechanismExpansionProof');
const { parseFactualAnchors } = require('../runtime/backend/closedLoop/FactualAnchorParser');
const { applyLivedMechanismAnchoring, LIVED_MECHANISM_RULES } = require('../runtime/backend/closedLoop/LivedMechanismAnchoringLayer');

const report = runMasterStep80LivedMechanismExpansionProof();
assert.strictEqual(report.step, 'Masterstep80');
assert.strictEqual(report.title, 'Lived Mechanism Expansion Batch');
assert.strictEqual(report.source_keeper, 'Masterstep79');
assert.strictEqual(report.operator_console_added, false);
assert.strictEqual(report.cloud_work_deferred, true);
assert.strictEqual(report.provider_connected, false);
assert.strictEqual(report.real_model_connected, false);
assert.strictEqual(report.local_offline_model_connected, false);
assert.strictEqual(report.api_keys_added, false);
assert.strictEqual(report.endpoints_added, false);
assert.strictEqual(report.network_bridge_added, false);
assert.strictEqual(report.frontend_intelligence_added, false);
assert.strictEqual(report.real_model_execution_added, false);
assert.strictEqual(report.expansion_case_count, EXPANSION_PROMPTS.length);
assert.strictEqual(report.configured_mechanism_count, LIVED_MECHANISM_RULES.length);
assert.strictEqual(report.passed, true, JSON.stringify(report.weak_cases, null, 2));
assert.strictEqual(report.expansion_fail_count, 0);
assert.deepStrictEqual(report.weak_cases, []);

for (const item of report.case_results) {
  assert.strictEqual(item.pass_fail, 'PASS', item.id + ' failed: ' + JSON.stringify(item.failures));
  assert.strictEqual(item.after_factual_types.includes('UNKNOWN_VARIABLE'), false, 'lived mechanism must intercept UNKNOWN_VARIABLE fallback');
  assert.strictEqual(item.baseline_uncertainty_used, false, 'Doyle must not use baseline when mechanism evidence exists');
  assert.notStrictEqual(item.separation_strategy, 'WEDGE_BASELINE_UNCERTAINTY');
  assert.notStrictEqual(item.restoration_posture, 'POSTURE_BASELINE_STEADINESS');
  assert.strictEqual(item.validation_status, 'PASSED');
  assert.strictEqual(item.cadence_status, 'SIGNAL_CLEAR');
  assert.strictEqual(item.triage_created, false);
  assert.strictEqual(item.learning_proposal_created, false);
  assert.strictEqual(item.commit_created, false);
  assert.strictEqual(item.frontend_intelligence_allowed, false);
}

for (const mechanism of report.new_mechanisms_added) {
  assert.ok(report.case_results.some(item => item.detected_mechanisms.includes(mechanism)), `new mechanism not detected: ${mechanism}`);
}

assert.strictEqual(report.preservation_failure_probe.passed, true);
assert.strictEqual(report.preservation_failure_probe.validation_status, 'BLOCKED');
assert.ok(report.preservation_failure_probe.failed_rule_codes.includes('VAL_ERR_MECHANISM_NOT_PRESERVED'));
assert.strictEqual(report.preservation_failure_probe.triage_created, true);
assert.strictEqual(report.preservation_failure_probe.learning_proposal_created, true);
assert.strictEqual(report.preservation_failure_probe.commit_created, false);
assert.strictEqual(report.preservation_failure_probe.review_boundary.silent_mutation_allowed, false);
assert.strictEqual(report.preservation_failure_probe.review_boundary.commit_blocked_until_human_approval, true);

for (const [key, value] of Object.entries(report.required_chain_evidence)) assert.strictEqual(value, true, `required evidence failed: ${key}`);
assert.deepStrictEqual(report.provider_scan_findings, []);
assert.deepStrictEqual(report.frontend_residue_findings, []);
assert.deepStrictEqual(report.nested_archive_findings, []);
assert.strictEqual(report.decision, 'CLOSE_STEP_80_LIVED_MECHANISM_EXPANSION_BATCH');

const parsed = applyLivedMechanismAnchoring(parseFactualAnchors('They read my message and did not answer, so I keep thinking I did something wrong.'));
assert.ok(parsed.lived_mechanism_anchor.detected_mechanisms.some(m => m.mechanism_id === 'READ_NO_RESPONSE_ASSUMPTION'));
assert.strictEqual(parsed.lived_mechanism_anchor.backend_owned, true);
assert.strictEqual(parsed.lived_mechanism_anchor.silent_mutation_allowed, false);
console.log('masterStep80LivedMechanismExpansionBatchTest PASSED');
