# Failure Pattern Detection Registry

## Purpose
Detects repeated weaknesses across automated scenarios.

## Pattern Signals
- same weak point appears repeatedly
- same category routes incorrectly
- same tone issue repeats
- same depth issue repeats
- same reverse-flow issue repeats
- same boundary/scope problem repeats
- same attached meaning is missed across prompts

## Rule
Repeated failure patterns should become stronger candidates for proposal.
