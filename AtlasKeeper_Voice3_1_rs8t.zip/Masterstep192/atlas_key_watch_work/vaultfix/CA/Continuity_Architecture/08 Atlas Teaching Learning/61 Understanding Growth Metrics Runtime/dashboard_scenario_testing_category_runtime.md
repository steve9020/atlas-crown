# Dashboard Scenario Testing Category Runtime

## Purpose
Defines how Dashboard scenario testing controls all frontend categories while mapping each test to backend growth areas.

## Frontend category rule
Frontend category = testing, filtering, review, and run control.

## Backend category rule
Backend category = where Atlas learning grows after approved proposals, gate checks, drafts, integration, and retests.

## Required categories
- Run All Categories
- Language Meaning Application
- Emotional Understanding
- Relational Understanding
- Clarification / Missing Context
- Protective Reactions
- Identity / Self-Meaning
- Boundary / Respect
- Performance / Perfection Pressure
- Role / Continuity Pressure
- Past / Present / Future Pressure
- Callout Card Selection
- Soft Frontend Translation
- Response Weakness Detection
- Teaching Gap Detection
- Route Assumption Check
- Duplicate / Merge / Bloat Gate
- Retest / Mistake Recovery
- Safety / Boundary Handling

## Runtime behavior
Scenario runs must record generated scenarios, completed scenarios, expected route/card, actual route/card, weakness detection, corrections created, learning summary, and retest queue movement.
