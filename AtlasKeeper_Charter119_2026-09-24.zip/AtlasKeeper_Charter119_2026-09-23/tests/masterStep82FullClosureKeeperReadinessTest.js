const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const version = require('../version_status.js');
const registry = require('../runtime/proof/ATLAS_COMPONENT_REGISTRY.json');

const root = path.resolve(__dirname, '..');
function exists(rel){ return fs.existsSync(path.join(root, rel)); }
function contains(rel, text){ return fs.readFileSync(path.join(root, rel), 'utf8').includes(text); }

assert.strictEqual(version.currentKeeper, 'Masterstep82');
assert.strictEqual(version.previousKeeper, 'Masterstep81');
assert.strictEqual(version.status, 'CLOSED_KEEPER');
assert.strictEqual(version.step, 'Atlas Component Registry / No-Delete Classification Map');
assert.strictEqual(version.atlasComponentRegistryComplete, true);
assert.strictEqual(version.noDeleteClassificationMapComplete, true);
assert.strictEqual(version.step82NoDeletionPerformed, true);
assert.strictEqual(version.step82NoIntegrationPerformed, true);
assert.strictEqual(version.step82NoNewMechanismsAdded, true);
assert.strictEqual(version.operatorConsoleAdded, false);
assert.strictEqual(version.realModelConnected, false);
assert.strictEqual(version.providerConfigured, false);
assert.strictEqual(version.networkBridgeEnabled, false);
assert.strictEqual(version.frontendIntelligenceAllowed, false);
assert.strictEqual(version.cloudWorkDeferredByUser, true);

[
  'runtime/proof/AtlasComponentRegistry.js',
  'runtime/proof/ATLAS_COMPONENT_REGISTRY.json',
  'runtime/proof/MASTERSTEP82_ATLAS_COMPONENT_REGISTRY.md',
  'docs/MASTERSTEP82_ATLAS_COMPONENT_REGISTRY_NO_DELETE_MAP.md',
  'tests/masterStep82AtlasComponentRegistryNoDeleteTest.js',
  'tests/masterStep82FullClosureKeeperReadinessTest.js',
  'proof/runCurrentProof.js'
].forEach(rel => assert(exists(rel), `Missing required Step 82 file: ${rel}`));

assert.strictEqual(registry.no_delete_rule, true);
assert.strictEqual(registry.delete_status_counts.DO_NOT_DELETE, registry.components.length);
assert(contains('proof/runCurrentProof.js', 'masterStep82AtlasComponentRegistryNoDeleteTest'), 'Current proof runner must include Step82 registry test.');

console.log('masterStep82FullClosureKeeperReadinessTest PASSED');
