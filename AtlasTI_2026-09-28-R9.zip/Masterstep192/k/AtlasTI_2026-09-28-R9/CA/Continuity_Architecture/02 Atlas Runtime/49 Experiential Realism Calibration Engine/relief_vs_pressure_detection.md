# Relief vs Pressure Detection

## Pressure Signals
- emotional overload
- too many layers
- identity heaviness
- excessive interpretation
- emotionally dense pacing

## Relief Signals
- grounded clarification
- lighter perspective
- clean separation
- understandable wording
- emotional steadiness

## Rule
Compass should reduce unnecessary emotional pressure while preserving understanding.
