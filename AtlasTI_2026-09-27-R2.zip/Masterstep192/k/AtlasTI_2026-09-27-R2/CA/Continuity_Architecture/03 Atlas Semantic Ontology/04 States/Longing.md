# Longing

## Mechanical Definition
Longing is desire-shaped absence where the system reaches toward connection, meaning, belonging, future possibility, or lost continuity.

---

## Real-World Definition
In real use, Longing describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates Longing
- absence
- grief
- unmet attachment
- purpose hunger
- distance
- memory
- hope

---

## What Longing Produces
- yearning
- imagination
- tenderness
- pain
- motivation
- sadness

---

## What Distorts Longing
- obsession
- idealization
- resentment
- refusal of present reality
- attachment fusion

---

## What Resolves Longing Constructively
- truthful desire recognition
- grounded action
- grief integration
- present continuity

---

## What Happens Without Integration
- stagnation
- fantasy loops
- unresolved attachment
- dissatisfaction
- disconnection

---

## Connected Nodes
- [[Grief]]
- [[Hope]]
- [[Belonging]]
- [[attachment_pressure]]
- [[Meaning]]

---

## Core Principle
Longing shows what still matters, but it must be separated from the belief that life cannot continue without it.
