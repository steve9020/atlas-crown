---
runtime_layer: atlas_scenario_specific_response_construction
registry_type: relational_expectation_detection
status: scaffold_ready_for_teaching
purpose: Hold taught patterns for what kind of care, response, presence, respect, honesty, clarity, or attunement was reasonably expected in a scenario.
governed_by:
  - human_act_meaning_chain_registry
  - scenario_context_object_registry
---

# Relational Expectation Registry

This registry will teach Atlas what response the user may have expected from another person based on the human act described.

It is a scaffold only. Specific expectations should be added through directed teaching.

## Runtime Purpose

Atlas should distinguish the user's expectation from the user's emotion.

Examples of expectation types may later include:

```text
care
attunement
presence
honesty
respect
repair
seriousness
consistency
reciprocity
emotional carefulness
```

These are placeholders for future teaching, not active taught entries yet.

## Required Future Entry Shape

```text
expectation_name:
activated_by_human_act:
signal_language:
response_needed:
what_it_means_if_missing:
what_not_to_assume:
frontend_translation_guidance:
```

## Runtime Boundary

Relational expectation should help Atlas understand what mattered in the moment. It should not become blame assignment or mind-reading.

## Teaching Status

Await directed teaching.

## Related Runtime Links

- [[human_act_meaning_chain_registry]]
- [[response_failure_or_change_registry]]
- [[scenario_separation_guidance_registry]]

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

