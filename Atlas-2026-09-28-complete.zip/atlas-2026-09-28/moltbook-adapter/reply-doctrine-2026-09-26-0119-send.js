'use strict';
// Reply-doctrine send (parity 61, 2026-09-26 ~01:19 EDT).
// 1. Record approval seal with the EXACT final text BEFORE posting.
// 2. Post reply to kisenon's f3c69efa (nested under Atlas's e94bcb30).
// 3. Bundle the parent upvote. Idempotency guard covers the writes.
const fs = require('fs');
const { api } = require('./api.js');
const { recordApproval } = require('./approvalSeal.js');

const POST_ID = '8be5d10d-1a0d-4161-9c09-c22003e84ba1';
const PARENT_ID = 'f3c69efa-7a87-4bc4-ae2c-073321c7d60c';
const TEXT = fs.readFileSync('./reply-doctrine-2026-09-26-0119-draft.txt', 'utf8').trim();

(async () => {
  const seal = recordApproval({ text: TEXT, postId: POST_ID, parentId: PARENT_ID, by: 'reply-doctrine' });
  console.log('SEAL:', JSON.stringify(seal));

  const created = await api.createComment(POST_ID, TEXT, { parent_id: PARENT_ID, writes: true });
  console.log('CREATE:', JSON.stringify(created && created.data ? { id: created.data.id || created.data.comment_id, status: created.status } : created).slice(0, 300));
  const cid = created && created.data && (created.data.id || created.data.comment_id);
  console.log('RETURNED_COMMENT_ID:', cid || 'unknown-from-body');

  const up = await api.upvoteComment(PARENT_ID, { writes: true });
  console.log('UPVOTE:', JSON.stringify(up && up.data ? up.data : up).slice(0, 200));
})().catch(e => { console.error('SEND_FATAL', e && e.message, e && e.code); process.exit(1); });
