# Scenario Specific Response Priority Registry

## Purpose
This registry tells Atlas when specific context should override generalized Compass response templates.

## High Priority Contexts
- childhood trauma / abandonment
- vulnerability mishandling
- public embarrassment after disclosure
- boundary/respect violation
- relational inconsistency
- effort not returned
- being used or overextended
- self-worth/value attachment
- grief/loss context
- safety/scope boundary context

## Priority Rule
If high-priority context is detected, the first user-facing sentence should reflect that context directly.

## Avoid
- "When something carries emotional weight..."
- "This can affect how you understand yourself..."
- generic attached-meaning framing as the lead

## Use Instead
- specific context lead
- specific emotional effect
- clean separation
- lighter perspective restoration
