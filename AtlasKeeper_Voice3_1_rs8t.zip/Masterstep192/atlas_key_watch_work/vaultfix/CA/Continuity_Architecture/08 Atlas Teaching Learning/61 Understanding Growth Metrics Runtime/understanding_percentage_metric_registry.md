# Understanding Percentage Metric Registry

## Metric
Understanding %

## Formula
passed route/card retests ÷ total route/card retests

## Meaning
Understanding % measures how often Atlas selected the expected route and callout card during retests.

## What changes it
- route/card retest performed increases denominator
- retest pass increases numerator

## Interpretation
This metric reflects tested interpretation accuracy, not total intelligence.
