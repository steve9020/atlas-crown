'use strict';
const { readJsonRegistry } = require('../../runtime/backend/ObsidianRegistryReader.js');
const REGISTRY_PATH = 'CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/multilingual_axol_evidence_registry.md';
let cached = null;
function registry(){ if(!cached) cached=readJsonRegistry(REGISTRY_PATH); return cached; }
function norm(v){ return String(v||'').normalize('NFKC').toLocaleLowerCase().replace(/\s+/gu,' ').trim(); }
function containsEvidence(text, evidence){
 const e=norm(evidence); if(!e) return false;
 // Only very short Latin evidence needs token boundaries; longer families may intentionally be stems/morphological anchors.
 if(/^[a-z0-9]+$/u.test(e) && e.length<=5){
  const esc=e.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  return new RegExp('(?<![a-z0-9])'+esc+'(?![a-z0-9])','u').test(text);
 }
 return text.includes(e);
}
const NEGATORS=['no ','ne ','nicht','não','non ','niet','nie ','değil','не ','لا ','नहीं','ない','ません','없','않','不','无法'];
function clauseForEvidence(text,evidence){
 const i=text.indexOf(evidence); if(i<0)return text;
 const stops=['.','!','?',';','。','！','？','؛']; let left=-1,right=text.length;
 for(const stop of stops){left=Math.max(left,text.lastIndexOf(stop,i));const r=text.indexOf(stop,i+evidence.length);if(r>=0)right=Math.min(right,r);}
 return text.slice(left+1,right).trim();
}
function evidenceState(text,evidence,pack){
 const clause=clauseForEvidence(text,evidence);
 const uncertainty=(pack.uncertaintyMarkers||[]).map(norm).filter(Boolean);
 if(uncertainty.some(marker=>containsEvidence(clause,marker))) return 'uncertain';
 if(NEGATORS.some(t=>clause.includes(t+evidence)||evidence.includes(t))) return 'negated';
 return 'asserted';
}
function add(out,axis,evidence,code,rule,state='asserted'){
 let item=out.find(x=>x.axis===axis); if(!item){item={axis,evidence:[],rules:[],states:[],attributions:[],languages:[]};out.push(item);}
 if(!item.evidence.includes(evidence)) item.evidence.push(evidence); if(!item.rules.includes(rule)) item.rules.push(rule); if(!item.states.includes(state)) item.states.push(state); if(!item.languages.includes(code)) item.languages.push(code);
}
function detectMultilingualAxolEvidence(input){
 const text=norm(input),out=[],languages=[],r=registry();
 for(const [code,pack] of Object.entries(r.packs||{})){ let hit=false;
  for(const [axis,phrases] of Object.entries(pack.cues||{})) for(const phrase of phrases||[]){const p=norm(phrase);if(!p||!containsEvidence(text,p))continue;hit=true;add(out,axis,phrase,code,'multilingual_axol_evidence_registry',evidenceState(text,p,pack));}
  // Structural families are bounded language-level lexeme/construction evidence, not full sentence translations.
  for(const [axis,families] of Object.entries(pack.families||{})) for(const family of families||[]){const f=norm(family);if(!f||!containsEvidence(text,f))continue;hit=true;add(out,axis,family,code,'multilingual_structural_family',evidenceState(text,f,pack));}
  if(hit) languages.push(code);
 }
 return {axis_evidence:out,languages:[...new Set(languages)]};
}
module.exports={detectMultilingualAxolEvidence};
