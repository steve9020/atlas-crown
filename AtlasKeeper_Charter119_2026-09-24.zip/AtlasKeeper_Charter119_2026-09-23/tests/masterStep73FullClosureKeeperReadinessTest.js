const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const version = require('../version_status');

const root = path.resolve(__dirname, '..');
const required = [
  'runtime/backend/model/LocalModelReadinessGuard.js',
  'runtime/proof/MASTERSTEP73_LOCAL_MODEL_READINESS_GUARD.json',
  'runtime/proof/MASTERSTEP73_LOCAL_MODEL_READINESS_GUARD.md',
  'docs/MASTERSTEP73_LOCAL_MODEL_READINESS_GUARD_MAP.md',
  'tests/masterStep73LocalModelReadinessGuardTest.js'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(root, rel)), 'missing Step73 artifact: ' + rel);

const proof = JSON.parse(fs.readFileSync(path.join(root, 'runtime/proof/MASTERSTEP73_LOCAL_MODEL_READINESS_GUARD.json'), 'utf8'));
assert.strictEqual(proof.passed, true, 'proof JSON must record Step73 pass');
assert.strictEqual(proof.source_keeper, 'Masterstep72');
assert.strictEqual(proof.cloud_work_deferred, true);
assert.strictEqual(proof.provider_connected, false);
assert.strictEqual(proof.real_model_connected, false);
assert.strictEqual(proof.local_offline_model_connected, false);
assert.strictEqual(proof.api_keys_added, false);
assert.strictEqual(proof.endpoints_added, false);
assert.strictEqual(proof.network_bridge_added, false);
assert.strictEqual(proof.frontend_intelligence_added, false);
assert.strictEqual(proof.real_model_execution_added, false);
assert.strictEqual(proof.guard_only_no_integration, true);
assert.strictEqual(proof.fail_count, 0);
assert.strictEqual(proof.required_chain_evidence.cloud_deferred, true);
assert.strictEqual(proof.required_chain_evidence.provider_scan_clean, true);
assert.strictEqual(proof.required_chain_evidence.no_api_keys_endpoints_or_network_bridge, true);
assert.strictEqual(proof.required_chain_evidence.no_real_model_connected_or_executed, true);
assert.strictEqual(proof.required_chain_evidence.model_slot_accepts_only_valid_model_agnostic_payload, true);
assert.strictEqual(proof.required_chain_evidence.unapproved_local_executor_blocked, true);
assert.strictEqual(proof.required_chain_evidence.mock_candidate_still_governed_by_atlas, true);
assert.strictEqual(proof.required_chain_evidence.offline_candidate_still_governed_by_atlas, true);
assert.strictEqual(proof.required_chain_evidence.post_generation_validator_still_required, true);
assert.strictEqual(proof.required_chain_evidence.teaching_center_crash_triage_still_safe, true);
assert.strictEqual(proof.required_chain_evidence.no_silent_mutation_boundary_preserved, true);
assert.strictEqual(proof.required_chain_evidence.frontend_shell_still_dumb, true);
assert.strictEqual(proof.decision, 'CLOSE_STEP_73_AND_MOVE_TO_ALGORITHMIC_VOICE_CADENCE_VALIDATOR');

assert.strictEqual(version.currentKeeper, 'Masterstep73', 'version_status currentKeeper must be Masterstep73');
assert.strictEqual(version.previousKeeper, 'Masterstep72', 'version_status previousKeeper must be Masterstep72');
assert.strictEqual(version.step, 'Local Model Readiness Guard', 'version_status step must be Step73 title');
assert.strictEqual(version.aiConnected, false, 'AI/cloud must remain disconnected');
assert.strictEqual(version.providerConfigured, false, 'provider must remain unconfigured');
assert.strictEqual(version.providerWrapperExecutionEnabled, false, 'provider wrapper execution must remain disabled');
assert.strictEqual(version.networkBridgeEnabled, false, 'network bridge must remain disabled');
assert.strictEqual(version.frontendIntelligenceAllowed, false, 'frontend intelligence must remain blocked');
assert.strictEqual(version.backendOwnsIntelligence, true, 'backend ownership must remain true');
assert.strictEqual(version.cloudProviderEvaluationStarted, false, 'cloud provider evaluation must remain deferred');
assert.strictEqual(version.localModelReadinessGuardComplete, true, 'Step73 local model readiness guard must be complete');
assert.strictEqual(version.localModelReadinessWeakCasesRemaining, 0, 'Step73 weak cases must be zero');
assert.strictEqual(version.nextTarget, 'Masterstep74 — Algorithmic Voice Cadence Validator', 'next target must be Step74 cadence validator');

console.log('masterStep73FullClosureKeeperReadinessTest PASSED');
