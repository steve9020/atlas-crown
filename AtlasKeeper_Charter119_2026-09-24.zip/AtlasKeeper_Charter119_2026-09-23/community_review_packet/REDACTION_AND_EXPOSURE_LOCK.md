# Redaction and Exposure Lock

Withheld by default:

- source packages
- runtime files
- private vault material
- proof internals and generated logs
- tests
- raw model outputs
- credentials, keys, tokens, and local machine paths
- internal governance mechanics that could be copied, bypassed, or scraped

Allowed in this packet:

- plain-language summary
- claim boundary
- non-sensitive evidence summary
- reviewer feedback guide
- safe demo walkthrough
- do-not-share list
