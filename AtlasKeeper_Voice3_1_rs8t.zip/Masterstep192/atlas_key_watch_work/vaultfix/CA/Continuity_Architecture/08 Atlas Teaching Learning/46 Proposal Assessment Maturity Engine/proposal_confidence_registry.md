# Proposal Confidence Registry

## Confidence Levels

### High
Proposal is complete, specific, properly targeted, and low-risk.

### Medium
Proposal is usable but should be reviewed carefully.

### Low
Proposal likely needs revision or more examples.

### Hold
Proposal should not enter active review yet.

## Rule
Confidence guides review priority, not automatic implementation.
