---
runtime_layer: response_weakness_detection
priority: high
owned_by: atlas_teaching_learning
feeds_into:
  - teaching_gap_detection_runtime_overview
---

# Missed Prompt Detail Detection Registry

## Purpose
Detects when Compass ignores details that should have changed the route or response.

## Detail types that should not be missed
- human act or event
- relational action or silence
- assumed judgment
- identity conclusion
- perfection or repair demand
- collapse language
- role, belonging, or security pressure
- protective reaction
- present stuckness or replaying
- future fear or redemption pressure

## Rule
If a detail changes the meaning of the prompt, it must influence route selection or response construction.
