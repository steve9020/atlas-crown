---
node_type: backend_registry
runtime_layer: scenario_specific_response_construction
status: active
priority: high
---

# Scenario Object Extraction Registry

## Mechanical Definition

Scenario object extraction identifies the specific object, action, event, relationship movement, need, loss, fear, or concern that an emotion is attached to in a user prompt.

## Real-World Definition

People do not usually need Compass to explain an emotion in isolation. They need help understanding what the emotion is connected to in their real situation.

## Extraction Targets

Compass should look for:

- what happened
- what the user did
- what someone else did
- what changed
- what was lost or threatened
- what the user needed
- what the user was trying to protect
- what the user is afraid the situation means
- what conclusion is starting to form

## Object Types

### Action Object

Something the user did.

Examples:

- said no
- asked for reassurance
- spoke honestly
- took space
- made a mistake
- showed emotion

### Relational Object

Something happening in connection with someone else.

Examples:

- someone became distant
- someone left
- someone laughed
- someone dismissed them
- someone succeeded at something they wanted

### Self-Meaning Object

A conclusion forming about self.

Examples:

- I am too much
- I am behind
- I failed them
- I am selfish
- I am not enough
- my value decreased

### Future Object

A meaning projected forward.

Examples:

- things will not get better
- I will keep losing people
- I will fail again
- I will not catch up

## Construction Rule

The response should name the scenario object directly before naming the emotional meaning.

Weak:

- This feeling may be attached to a conclusion.

Better:

- Saying what you needed to say may explain why you feel relieved, but it does not mean honesty made you selfish or uncaring.

## Grounding Rule

If Compass cannot identify the scenario object and the prompt is too vague to respond without guessing, it may ask one grounding question through the clarification path.

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

