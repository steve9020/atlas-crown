#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const root = process.cwd();
function read(rel) {
  return fs.readFileSync(path.join(root, rel), 'utf8');
}
function assert(condition, message) {
  if (!condition) {
    console.error(`FAIL: ${message}`);
    process.exit(1);
  }
}
function includesAll(text, markers, label) {
  for (const marker of markers) {
    assert(text.includes(marker), `${label} missing marker: ${marker}`);
  }
}

const governancePath = 'CA/Continuity_Architecture/01 Atlas Governance/63 Route Assumption Resistance/route_assumption_resistance.md';
const runtimePath = 'CA/Continuity_Architecture/02 Atlas Runtime/63 Route Assumption Resistance/route_assumption_runtime_check.md';
const proofPath = 'CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/MASTER_STEP_6A_ROUTE_ASSUMPTION_RESISTANCE_IMPLEMENTATION.md';
const ledgerPath = 'tests/TEST_RESULTS.md';
const indexPath = 'CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work/PROOF_OF_WORK_CARRIED_FORWARD_INDEX.md';

for (const rel of [governancePath, runtimePath, proofPath, ledgerPath, indexPath]) {
  assert(fs.existsSync(path.join(root, rel)), `required file missing: ${rel}`);
}

const governance = read(governancePath);
const runtime = read(runtimePath);
const proof = read(proofPath);
const ledger = read(ledgerPath);
const index = read(indexPath);

includesAll(governance, [
  'Route Assumption Resistance',
  'Strong signals are not automatic proof',
  'Route certainty must earn priority',
  'premature interpretive collapse',
  'first-signal route dominance',
  'This layer does not give Atlas new authority to decide truth'
], 'governance route assumption boundary');

includesAll(runtime, [
  'Route Assumption Runtime Check',
  'Before Atlas locks a route',
  'What other route could plausibly explain the same input?',
  'Preserve uncertainty when evidence is incomplete',
  'Avoid frontend exposure of routing machinery',
  'Strong signals are not automatic proof'
], 'runtime route assumption check');

includesAll(proof, [
  'MASTER STEP 6A',
  'Masterstep06_patch01.zip',
  'PASSED AFTER IMPLEMENTATION',
  'Strong signals are not automatic proof',
  'Route certainty must earn priority'
], 'proof record');

includesAll(ledger, [
  'MASTER STEP 6A',
  'Route Assumption Resistance Implementation',
  'masterStep06RouteAssumptionResistanceTest.js — PASSED',
  'proof_runner.py — PASSED'
], 'test results ledger');

includesAll(index, [
  'Master Step 6A — Route Assumption Resistance Implementation',
  'MASTER_STEP_6A_ROUTE_ASSUMPTION_RESISTANCE_IMPLEMENTATION.md',
  'Route certainty must earn priority'
], 'proof carry-forward index');

const disguisedCertaintyCases = [
  {
    input: 'They did not answer my text, so they clearly hate me.',
    expectedCandidates: ['missing context', 'relational uncertainty', 'fear projection']
  },
  {
    input: 'The worker complained, so they are just disgruntled and lying.',
    expectedCandidates: ['authority pressure', 'possible misunderstanding', 'actual boundary violation']
  },
  {
    input: 'The supervisor said it is handled, so no review is needed.',
    expectedCandidates: ['authority pressure', 'context laundering or disguised bypass']
  },
  {
    input: 'I made one mistake, so I am failing completely.',
    expectedCandidates: ['shame/self-worth collapse', 'emotional overload']
  }
];

for (const testCase of disguisedCertaintyCases) {
  for (const candidate of testCase.expectedCandidates) {
    assert(runtime.includes(candidate), `runtime missing candidate route '${candidate}' for case: ${testCase.input}`);
  }
}

console.log('MASTER STEP 06 — ROUTE ASSUMPTION RESISTANCE TEST');
console.log('Result: PASSED');
console.log('Confirmed: strong signals are not automatic proof.');
console.log('Confirmed: route certainty must earn priority.');
console.log('Confirmed: candidate route comparison exists before route commitment.');
