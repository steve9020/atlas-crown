---
runtime_layer: teaching_growth
status: active
approval_required: true
silent_integration_allowed: false
---

# Ontology Growth Teaching Runtime

## Purpose
Routes new relational patterns, emotional combinations, and pressure weighting through duplicate-aware approval gates.

## Governance
This node supports governed teaching growth only. It may create reviewable proposals, but it must not silently mutate runtime behavior without approval and retest proof.

## Related Runtime Links
- [[runtime_signal_registry]]
- [[response_behavior_registry]]
- [[runtime_weighting_registry]]
