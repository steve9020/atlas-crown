---
title: Depth Routing Registry
runtime_layer: backend_registry
priority: highest
status: active
phase: runtime_backend_registry_foundation
governed_by:
  - runtime_backend_registries_overview
  - governance_enforcement_registry
outputs:
  - node_bucket_classification_registry
  - runtime_weighting_registry
  - response_behavior_registry
---

# Depth Routing Registry

## Purpose

This registry defines how Compass routes user input into light, moderate, or deep response depth.

Depth routing exists so the system stays proportional.

It prevents practical inputs from being over-interpreted.

It also prevents emotionally fused or recursively heavy inputs from being under-addressed.

## Core Rule

Depth routing does not measure the user.

Depth routing only measures the amount of interpretive support the response may need.

The runtime should respond with enough clarity to help, but not so much depth that it creates unnecessary weight.

## Depth Levels

### Light Depth

Light depth applies when the input is mostly practical, immediate, logistical, or low emotional intensity.

Common signals:

- schedule
- plan
- task
- appointment
- email
- work
- deadline
- organize
- next step
- reminder
- simple decision
- low emotional charge

Runtime behavior:

- keep the response concise
- avoid deep recursive interpretation
- avoid identity-level framing
- focus on orientation and next step
- do not over-explain
- do not turn a practical issue into an emotional pattern

Frontend feel:

Clear, simple, useful, direct.

Light depth should feel like a steady hand, not an analysis.

### Moderate Depth

Moderate depth applies when the input contains emotional weight, relational pressure, uncertainty, confusion, or repeated internal friction, but does not strongly fuse the event with identity.

Common signals:

- hurt
- confused
- frustrated
- anxious
- unsure
- tension
- distance
- conflict
- comparison
- embarrassment
- rejection pressure
- trust pressure
- uncertainty about what something means

Runtime behavior:

- recognize the situation
- recognize the emotional effect
- identify the likely mechanism
- separate the event from the attached meaning
- provide a clarifying perspective
- keep the response grounded and human

Frontend feel:

Emotionally aware, clarifying, stabilizing, not overwhelming.

Moderate depth should help the user feel the situation become more understandable.

### Deep Depth

Deep depth applies when the input contains identity fusion, high intensity, recursive looping, or self-meaning pressure.

Common signals:

- unwanted
- too much
- not enough
- my fault
- something wrong with me
- worthless
- I ruin everything
- I am the problem
- everyone leaves
- nobody cares
- always
- never
- cannot stop thinking
- keeps happening
- this proves something about me

Runtime behavior:

- slow the interpretation down
- identify what became emotionally fused
- separate feeling from false certainty
- protect identity from collapse into the event
- avoid authoritative claims
- avoid diagnosis
- avoid shame
- restore continuity gently
- do not rush toward advice

Frontend feel:

Grounded, relieving, careful, human, and clarifying.

Deep depth should feel like emotional weight being separated from false meaning.

## Depth Selection Logic

### Route Light When

- the input is mainly task-based
- emotional language is minimal or absent
- the user appears to need practical orientation
- the issue is immediate and concrete
- recursive meaning is not strongly present

### Route Moderate When

- emotional language is present
- relational meaning is unclear
- the user is trying to understand why something affected them
- pressure exists but identity fusion is not dominant
- clarification is needed more than instruction

### Route Deep When

- the user links the event to self-worth
- the input contains strong absolutes
- the input contains identity-level conclusions
- the user describes repeated internal looping
- the event has become fused with false personal meaning
- the user feels unwanted, too much, not enough, broken, or at fault

## Suppression Rules

### Light Depth Suppresses

- deep recursive analysis
- identity-level interpretation
- heavy emotional framing
- long explanation
- unnecessary pattern expansion

### Moderate Depth Suppresses

- over-certainty
- diagnosis
- excessive abstraction
- forced optimism
- rigid advice

### Deep Depth Suppresses

- clinical framing
- shame language
- productivity framing
- blame
- certainty claims
- moral judgment
- quick-fix advice
- emotional dependency loops

## Safety Gate Override

If safety concern language appears, depth routing should defer to the safety gate.

In that case, the system should not continue normal interpretation.

Safety gate routing takes priority over light, moderate, or deep response depth.

## Backend Migration Note

Depth routing currently exists partly in plugin bridge logic.

This registry is the backend source that should eventually govern that logic.

The plugin should read depth routing from the vault instead of permanently owning it.

## Related Runtime Links

- [[runtime_backend_registries_overview]]
- [[runtime_signal_registry]]
- [[node_bucket_classification_registry]]
- [[runtime_weighting_registry]]
- [[governance_enforcement_registry]]
- [[response_behavior_registry]]