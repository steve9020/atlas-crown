---
runtime_layer: clarification_grounding
registry_type: clarification_suppression_runtime
purpose: Backend-owned rules for suppressing clarification questions when the prompt already provides enough context.
governed_by:
  - runtime_context_sufficiency_registry
  - clarification_grounding_question_registry
---

# Clarification Suppression Runtime Registry

Clarification is useful only when Atlas would otherwise guess. It should not interrupt a prompt that already contains the emotional source, attached meaning, contradiction, or scenario object.

## Suppression JSON

```json
{
  "suppress_if": [
    "context_sufficiency_score >= enough_context_score",
    "scenario_object_present and attached_meaning_present",
    "mixed_emotion_present and source_present",
    "boundary_context_present and guilt_present and relief_present",
    "prompt already answers the grounding question that would be asked"
  ],
  "single_word_override_prevention": true,
  "clarification_priority": "last_resort_after_context_reading",
  "suppression_message_for_audit": "Grounding question suppressed because the prompt already contains enough context for Compass to respond."
}
```
