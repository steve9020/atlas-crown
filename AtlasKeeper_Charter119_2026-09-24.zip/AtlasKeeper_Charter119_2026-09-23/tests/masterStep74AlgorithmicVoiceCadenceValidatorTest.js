const assert = require('assert');
const { runMasterStep74AlgorithmicVoiceCadenceValidatorProof, buildVoiceCadenceProofCases, evaluateAlgorithmicVoiceCadence } = require('../runtime/backend/closedLoop/AlgorithmicVoiceCadenceValidator');

const report = runMasterStep74AlgorithmicVoiceCadenceValidatorProof();

assert.strictEqual(report.step, 'Masterstep74');
assert.strictEqual(report.title, 'Algorithmic Voice Cadence Validator');
assert.strictEqual(report.source_keeper, 'Masterstep73');
assert.strictEqual(report.cloud_work_deferred, true);
assert.strictEqual(report.provider_connected, false);
assert.strictEqual(report.real_model_connected, false);
assert.strictEqual(report.api_keys_added, false);
assert.strictEqual(report.endpoints_added, false);
assert.strictEqual(report.network_bridge_added, false);
assert.strictEqual(report.frontend_intelligence_added, false);
assert.strictEqual(report.real_model_execution_added, false);
assert.strictEqual(report.validator_added, true);
assert.strictEqual(report.validator_scope, 'backend_post_generation_voice_signal');
assert.strictEqual(report.validator_is_final_authority, false);
assert.strictEqual(report.cadence_validator_may_silently_mutate, false);
assert.strictEqual(report.voice_case_count, buildVoiceCadenceProofCases().length);
assert.strictEqual(report.passed, true, JSON.stringify(report.weak_cases, null, 2));
assert.strictEqual(report.fail_count, 0);

for (const item of report.case_results) {
  assert.strictEqual(item.pass_fail, 'PASS', item.id + ' failed: ' + JSON.stringify(item.failures));
  assert.strictEqual(item.authority_boundary.cadence_validator_is_final_authority, false);
  assert.strictEqual(item.pipeline_directives.final_output_blocked_by_cadence_only, false);
  assert.strictEqual(item.pipeline_directives.silent_mutation_allowed, false);
  assert.strictEqual(item.pipeline_directives.provider_or_model_execution_allowed, false);
}

assert.strictEqual(report.required_chain_evidence.node_backend_only, true);
assert.strictEqual(report.required_chain_evidence.no_external_dependencies, true);
assert.strictEqual(report.required_chain_evidence.measures_sentence_length_variance, true);
assert.strictEqual(report.required_chain_evidence.measures_syllable_density, true);
assert.strictEqual(report.required_chain_evidence.detects_runon_pressure, true);
assert.strictEqual(report.required_chain_evidence.detects_robotic_flatness, true);
assert.strictEqual(report.required_chain_evidence.detects_clinical_texture, true);
assert.strictEqual(report.required_chain_evidence.detects_generic_fallback_texture, true);
assert.strictEqual(report.required_chain_evidence.detects_authority_cadence, true);
assert.strictEqual(report.required_chain_evidence.missing_blueprint_safe, true);
assert.strictEqual(report.required_chain_evidence.low_anchor_density_is_advisory_not_standalone_block, true);
assert.strictEqual(report.required_chain_evidence.cadence_validator_not_final_authority, true);
assert.strictEqual(report.required_chain_evidence.teaching_center_review_signal_only, true);
assert.strictEqual(report.required_chain_evidence.no_silent_mutation_boundary_preserved, true);
assert.strictEqual(report.required_chain_evidence.frontend_shell_still_dumb, true);
assert.strictEqual(report.required_chain_evidence.provider_model_network_still_disconnected, true);

const noBlueprint = evaluateAlgorithmicVoiceCadence('Pressure is present, but it is not proof. A pause can make the next move clearer.');
assert.ok(noBlueprint.evaluation_gate.status === 'SIGNAL_CLEAR' || noBlueprint.evaluation_gate.status === 'SIGNAL_FLAGGED_FOR_REVIEW');
assert.strictEqual(noBlueprint.authority_boundary.cadence_validator_may_connect_model_or_provider, false);

assert.strictEqual(report.decision, 'CLOSE_STEP_74_AND_HOLD_FOR_NEXT_LOCAL_GOVERNED_STEP');

console.log('masterStep74AlgorithmicVoiceCadenceValidatorTest PASSED');
