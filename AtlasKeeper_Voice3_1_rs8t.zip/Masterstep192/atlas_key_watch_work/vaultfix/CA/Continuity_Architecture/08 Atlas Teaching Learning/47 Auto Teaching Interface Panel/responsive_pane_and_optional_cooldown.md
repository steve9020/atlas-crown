# Responsive Pane and Optional Cooldown

## Purpose
Auto Teaching is now adjusted for constrained Obsidian workspace panes.

## Layout Fixes
- collapses rigid three-column dashboard behavior
- prevents horizontal clipping
- keeps controls clickable
- stacks engine controls when pane width is limited
- keeps cards responsive with auto-fit grids
- keeps tabs scrollable instead of crushed

## Cooldown Behavior
Cooldown is off by default.

Available user-selected options:
- Off
- 5 minutes
- 10 minutes
- 20 minutes
- 30 minutes

Cooldown should only apply after the user chooses a non-zero value.

## Development Rule
During active building/testing, Auto Teaching should not block repeated use unless the user explicitly turns cooldown on.
