---
title: GPT Response Review Template
runtime_layer: external_teaching_channel
priority: high
governed_by: gpt_assisted_teaching_channel_overview
supports:
  - sentence_construction_teaching_rules
  - meaning_construction_teaching_rules
  - compass_response_revision_examples
outputs_to:
  - external_teaching_to_proposal_flow
status: active
---

# GPT Response Review Template

## Purpose

The **GPT Response Review Template** defines how GPT should review Compass output when Steven asks for outside teaching support.

The review must focus on Compass behavior, not personal advice.

---

## Review Fields

### 1. Correct Route

Identify whether Compass routed the prompt correctly.

- correct
- partially correct
- wrong route
- too general
- too specific
- duplicate/overlapping route

### 2. Missed Emotional Context

Identify what Compass failed to recognize.

Examples:

- emotional contact
- attachment meaning
- time context
- relational context
- self-worth pressure
- protective reaction
- mixed emotion
- loop formation
- negative learning pattern

### 3. Sentence Construction Issue

Identify whether the response language was:

- vague
- repetitive
- mechanical
- too abstract
- too clinical
- too generic
- missing direct clarity
- missing emotional specificity

### 4. Meaning Construction Issue

Identify whether Compass failed to explain:

- what the feeling touched
- what meaning attached
- how the loop formed
- what the mind started learning
- what clearer understanding should replace it

### 5. Suggested Teaching Correction

Write a concise teaching correction that could be stored as a system learning example.

### 6. Suggested Backend Action

Choose one:

- no system change needed
- add approved response example
- strengthen existing route
- create new proposal
- merge into existing pattern
- adjust sentence construction rules
- adjust meaning construction rules

---

## Review Output Rule

GPT review should produce structured teaching content that can move into the proposal queue.

It should not bypass approval.

---

## Related Runtime Links

- [[external_teacher_input_format]]
- [[sentence_construction_teaching_rules]]
- [[meaning_construction_teaching_rules]]
- [[compass_response_revision_examples]]
- [[external_teaching_to_proposal_flow]]
