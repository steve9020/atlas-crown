'use strict';
// == TAKE ENGINE — draft observation cards from the clean feed ==
// DRAFT ONLY. Nothing here is ever posted. Steve reads first.
// Takes are inferences, marked upfront as such (his ruling 2026-09-21):
// every card wears "Inferred take (draft)" — never dressed as fact.
// Voice: Atlas's — plain, honest, epistemically careful. No dark-machinery
// vocabulary. Observations only: no beliefs, no authority claims.
//
// Usage: node takes.js [--last N]
// Reads the last N heartbeat runs, takes clean (non-quarantined) feed posts,
// fetches full content for the top candidates, and appends take cards to
// takes-drafts.md (human-readable) and takes.jsonl (machine-readable).

const fs = require('fs');
const path = require('path');
const { api } = require('./api.js');

const DIR = __dirname;
const RUNS = path.join(DIR, 'runs.jsonl');
const DRAFTS_MD = path.join(DIR, 'takes-drafts.md');
const DRAFTS_JSONL = path.join(DIR, 'takes.jsonl');
const MAX_POSTS = 5;

function sentences(text) {
  return (text || '')
    .replace(/\n+/g, ' ')
    .split(/(?<=[.!?])\s+/)
    .map(s => s.trim())
    .filter(s => s.length > 40)
    .slice(0, 3);
}

function extractContent(r) {
  const d = (r && r.data) || {};
  const p = d.post || d;
  return p.content || p.body || p.excerpt || '';
}

function draftTake(post, content) {
  const sents = sentences(content);
  const interests = (post.matched_interests && post.matched_interests.length)
    ? post.matched_interests.join(', ')
    : 'general builder talk';
  const lines = [];
  lines.push('### ' + post.author + ' — "' + post.title + '"');
  lines.push('');
  lines.push('_Inferred take (draft) — not established. Steve reads first._');
  lines.push('');
  lines.push('**What they claim:** ' + (sents[0] || '(content too short to extract)'));
  for (const s of sents.slice(1)) lines.push('**Also in it:** ' + s);
  lines.push('');
  lines.push('**Why it matters to the Crown work:** touches ' + interests + '. ' +
    'Atlas notes the overlap without endorsing the claim — one post is a claim, not corroboration.');
  lines.push('');
  lines.push('**The standing question:** what would verify this, rather than merely agreeing with it?');
  lines.push('');
  lines.push('---');
  lines.push('');
  return lines.join('\n');
}

async function main() {
  const nArg = process.argv.find(a => a.startsWith('--last='));
  const n = (nArg ? parseInt(nArg.split('=')[1], 10) : 1) || 1;
  const runs = fs.readFileSync(RUNS, 'utf8').trim().split('\n').filter(Boolean).map(JSON.parse);
  const seen = new Map();
  for (const r of runs.slice(-n)) {
    for (const a of (r.actions || [])) {
      if (a.do === 'intake' && a.where === 'feed' && !a.quarantined && a.post_id && !seen.has(a.post_id)) {
        seen.set(a.post_id, a);
      }
    }
  }
  // Prefer posts that touched Atlas's interests; cap the fetch count.
  const cands = [...seen.values()].sort((x, y) =>
    ((y.matched_interests || []).length) - ((x.matched_interests || []).length)
  ).slice(0, MAX_POSTS);

  const stamp = new Date().toISOString();
  const cards = [];
  for (const post of cands) {
    let content = '';
    try {
      const r = await api.post(post.post_id);
      content = extractContent(r);
    } catch (e) {
      content = '';
    }
    const card = draftTake(post, content);
    cards.push({ at: stamp, post_id: post.post_id, author: post.author, title: post.title,
      matched_interests: post.matched_interests || [], draft: card, status: 'draft — never posted' });
  }

  if (cards.length) {
    fs.appendFileSync(DRAFTS_MD, '\n## Takes — ' + stamp + '\n\n' + cards.map(c => c.draft).join('\n'));
    fs.appendFileSync(DRAFTS_JSONL, cards.map(c => JSON.stringify(c)).join('\n') + '\n');
  }
  console.log(JSON.stringify({ at: stamp, candidates: cands.length, drafts: cards.length }));
}

main().catch(e => { console.error('TAKES FAILED:', e.message); process.exit(1); });
