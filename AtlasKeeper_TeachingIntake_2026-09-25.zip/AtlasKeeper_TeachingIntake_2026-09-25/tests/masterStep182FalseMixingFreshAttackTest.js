'use strict';
const {arbitrateSemanticPlacements}=require('../runtime/understanding/SemanticPlacementArbitrator');
const cases=[["My dad has been quiet because he is finishing a work deadline.", "not_mixed"], ["She has stayed quiet while completing her tasks for the evening.", "not_mixed"], ["My mom is quiet at work because she has a lot to finish.", "not_mixed"], ["He has been quiet and says he needs to do more work before calling.", "not_mixed"], ["My sister remains quiet because her workload is heavy.", "not_mixed"], ["Dad has been quiet since he is trying to meet every requirement for his job.", "not_mixed"], ["My brother is quiet when he is concentrating on finishing everything.", "not_mixed"], ["She has been quiet because the standard at work moved higher and she is busy.", "not_mixed"], ["My mom is quiet tonight; she feels inadequate about her own performance.", "not_mixed"], ["Dad remains quiet because he is disappointed in himself about what he got done.", "not_mixed"], ["I finished everything at work and my phone has been quiet all day.", "not_mixed"], ["The office has been quiet, and I still feel like I did not do enough today.", "not_mixed"], ["Work has stayed quiet even though I completed every requirement.", "not_mixed"], ["My notifications are quiet while I keep judging my performance as inadequate.", "not_mixed"], ["The house is quiet and I am disappointed in myself for not producing more.", "not_mixed"], ["It has been quiet at work, and I feel guilty for stopping after finishing everything.", "not_mixed"]];
let passed=0; const failures=[];
for(const [prompt] of cases){
 const r=arbitrateSemanticPlacements({prompt});
 const mixed=r.context_object && r.context_object.domain==='mixed_semantic_context';
 if(!mixed) passed++; else failures.push({
   prompt,
   domain:r.context_object&&r.context_object.domain,
   candidates:(r.candidates||[]).map(x=>({domain:x.domain,evidence:x.evidence})),
   evaluated:(r.evaluated||[]).map(x=>({matrix:x.matrix,qualified:x.qualified,matched:x.matched,evidence:x.evidence,exclusions:x.exclusions}))
 });
}
console.log(JSON.stringify({total:cases.length,passed,failed:cases.length-passed,failures},null,2));
process.exit(failures.length?1:0);
