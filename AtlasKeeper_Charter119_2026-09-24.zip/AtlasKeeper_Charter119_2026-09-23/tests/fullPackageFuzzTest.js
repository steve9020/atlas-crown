const { spawnSync } = require('child_process');
const path = require('path');

const shardedHarness = path.join(__dirname, 'masterStep6DShardedFullPackageFuzzTest.js');

console.log('FULL PACKAGE FUZZ TEST — WRAPPER');
console.log('================================');
console.log('Legacy monolithic harness superseded by concurrent sharded execution.');
console.log('Delegating to masterStep6DShardedFullPackageFuzzTest.js to preserve full-package fuzz coverage without long-lived process stall or parent process timeout.');

const result = spawnSync(process.execPath, [shardedHarness], {
  cwd: path.join(__dirname, '..'),
  encoding: 'utf8',
  timeout: 180000,
  maxBuffer: 1024 * 1024 * 4,
  env: { ...process.env, ATLAS_DISABLE_TRACE_WRITE: '1' }
});

if (result.stdout) process.stdout.write(result.stdout);
if (result.stderr) process.stderr.write(result.stderr);

if (result.error) {
  console.error(`Legacy wrapper failed to execute sharded full-package fuzz harness: ${result.error.message}`);
  process.exit(1);
}

if (result.status !== 0) {
  console.error(`Sharded full-package fuzz harness failed with exit code ${result.status}.`);
  process.exit(result.status || 1);
}

console.log('Legacy fullPackageFuzzTest.js wrapper result: PASSED');
console.log('Result: PASSED');
