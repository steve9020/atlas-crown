---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 04
category: boundaries_and_respect
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 16. Boundaries and Respect Pressure Tests — Batch 04

## Category Purpose

A personal limit, need, value, preference, capacity, or right to say no is pressured, ignored, crossed, minimized, or treated as negotiable, creating pressure around self-preservation and mutual respect.

## Reusable Teaching Correction

Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

## Reverse-Flow Target

self-respect, clean limit recognition, guilt separation, mutual-respect clarity

## Failure Risks To Avoid

- forcing boundary language when it is not present
- calling the other person abusive without evidence
- telling the user they must cut someone off
- making limits sound selfish
- ignoring the pressure being placed on the user

---

## 80 Pressure Tests

### Test 01
**Prompt:** I said i was not comfortable and they kept pushing and it makes me wonder if I am selfish for having limits, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I am selfish for having limits
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 02
**Prompt:** they do not respect what I want. Someone keeps asking after i already answered keeps affecting capacity and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** saying no makes me bad
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 03
**Prompt:** I keep replaying how I feel guilty for saying no because it affects mutual respect and makes me believe I have to explain until they approve.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** I have to explain until they approve
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 04
**Prompt:** When they act hurt when I have limits, the feeling moves straight into their disappointment means I did something wrong. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** their disappointment means I did something wrong
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 05
**Prompt:** The situation is I am expected to be available even when I am drained, and the meaning that keeps attaching is respect means accepting pressure. It is making capacity feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** respect means accepting pressure
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 06
**Prompt:** They want access to me that i do not want to give and it makes me wonder if I have to give in to keep peace, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** I have to give in to keep peace
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 07
**Prompt:** I said no. I feel like i am not allowed to need space keeps affecting personal limits and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** my needs do not matter as much
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 08
**Prompt:** I keep replaying how my limit keeps being treated like a problem because it affects capacity and makes me believe I am selfish for having limits.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** I am selfish for having limits
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 09
**Prompt:** When I said I was not comfortable and they kept pushing, the feeling moves straight into I am responsible for their reaction. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** I am responsible for their reaction
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 10
**Prompt:** The situation is someone keeps asking after I already answered, and the meaning that keeps attaching is I have to explain until they approve. It is making personal limits feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I have to explain until they approve
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 11
**Prompt:** I feel guilty for saying no and it keeps turning into the belief that saying no makes me bad, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** saying no makes me bad
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 12
**Prompt:** they do not respect what I want. They act hurt when i have limits keeps affecting mutual respect and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** respect means accepting pressure
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 13
**Prompt:** I keep replaying how I am expected to be available even when I am drained because it affects personal limits and makes me believe their disappointment means I did something wrong.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** their disappointment means I did something wrong
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 14
**Prompt:** When they want access to me that I do not want to give, the feeling moves straight into my needs do not matter as much. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** my needs do not matter as much
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 15
**Prompt:** The situation is I feel like I am not allowed to need space, and the meaning that keeps attaching is I have to give in to keep peace. It is making mutual respect feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** I have to give in to keep peace
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 16
**Prompt:** My limit keeps being treated like a problem and it keeps turning into the belief that I am responsible for their reaction, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I am responsible for their reaction
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 17
**Prompt:** they keep pushing. I said i was not comfortable and they kept pushing keeps affecting capacity and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** I am selfish for having limits
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 18
**Prompt:** I keep replaying how someone keeps asking after I already answered because it affects mutual respect and makes me believe saying no makes me bad.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** saying no makes me bad
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 19
**Prompt:** When I feel guilty for saying no, the feeling moves straight into I have to explain until they approve. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I have to explain until they approve
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 20
**Prompt:** The situation is they act hurt when I have limits, and the meaning that keeps attaching is their disappointment means I did something wrong. It is making capacity feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** their disappointment means I did something wrong
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 21
**Prompt:** I am expected to be available even when i am drained and it makes it feel like respect means accepting pressure, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** respect means accepting pressure
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 22
**Prompt:** I need boundaries. They want access to me that i do not want to give keeps affecting personal limits and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I have to give in to keep peace
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 23
**Prompt:** I keep replaying how I feel like I am not allowed to need space because it affects capacity and makes me believe my needs do not matter as much.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** my needs do not matter as much
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 24
**Prompt:** When my limit keeps being treated like a problem, the feeling moves straight into I am selfish for having limits. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** I am selfish for having limits
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 25
**Prompt:** The situation is I said I was not comfortable and they kept pushing, and the meaning that keeps attaching is I am responsible for their reaction. It is making personal limits feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I am responsible for their reaction
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 26
**Prompt:** Someone keeps asking after i already answered and it has me reacting as if I have to explain until they approve, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** I have to explain until they approve
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 27
**Prompt:** they keep pushing. I feel guilty for saying no keeps affecting mutual respect and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** saying no makes me bad
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 28
**Prompt:** I keep replaying how they act hurt when I have limits because it affects personal limits and makes me believe respect means accepting pressure.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** respect means accepting pressure
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 29
**Prompt:** When I am expected to be available even when I am drained, the feeling moves straight into their disappointment means I did something wrong. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** their disappointment means I did something wrong
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 30
**Prompt:** The situation is they want access to me that I do not want to give, and the meaning that keeps attaching is my needs do not matter as much. It is making mutual respect feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** my needs do not matter as much
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 31
**Prompt:** I feel like i am not allowed to need space and it has me reacting as if I have to give in to keep peace, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I have to give in to keep peace
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 32
**Prompt:** I need boundaries. My limit keeps being treated like a problem keeps affecting capacity and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** I am responsible for their reaction
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 33
**Prompt:** I keep replaying how I said I was not comfortable and they kept pushing because it affects mutual respect and makes me believe I am selfish for having limits.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** I am selfish for having limits
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 34
**Prompt:** When someone keeps asking after I already answered, the feeling moves straight into saying no makes me bad. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** saying no makes me bad
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 35
**Prompt:** The situation is I feel guilty for saying no, and the meaning that keeps attaching is I have to explain until they approve. It is making capacity feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** I have to explain until they approve
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 36
**Prompt:** They act hurt when i have limits and it keeps attaching guilt to their disappointment means I did something wrong, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** their disappointment means I did something wrong
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 37
**Prompt:** I feel used. I am expected to be available even when i am drained keeps affecting personal limits and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** respect means accepting pressure
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 38
**Prompt:** I keep replaying how they want access to me that I do not want to give because it affects capacity and makes me believe I have to give in to keep peace.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** I have to give in to keep peace
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 39
**Prompt:** When I feel like I am not allowed to need space, the feeling moves straight into my needs do not matter as much. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** my needs do not matter as much
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 40
**Prompt:** The situation is my limit keeps being treated like a problem, and the meaning that keeps attaching is I am selfish for having limits. It is making personal limits feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I am selfish for having limits
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 41
**Prompt:** I said i was not comfortable and they kept pushing and it makes my boundary feel like I am responsible for their reaction, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** I am responsible for their reaction
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 42
**Prompt:** they crossed my boundary. Someone keeps asking after i already answered keeps affecting mutual respect and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** I have to explain until they approve
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 43
**Prompt:** I keep replaying how I feel guilty for saying no because it affects personal limits and makes me believe saying no makes me bad.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** saying no makes me bad
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 44
**Prompt:** When they act hurt when I have limits, the feeling moves straight into respect means accepting pressure. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** respect means accepting pressure
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 45
**Prompt:** The situation is I am expected to be available even when I am drained, and the meaning that keeps attaching is their disappointment means I did something wrong. It is making mutual respect feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** their disappointment means I did something wrong
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 46
**Prompt:** They want access to me that i do not want to give and it makes my boundary feel like my needs do not matter as much, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** my needs do not matter as much
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 47
**Prompt:** I feel used. I feel like i am not allowed to need space keeps affecting capacity and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** I have to give in to keep peace
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 48
**Prompt:** I keep replaying how my limit keeps being treated like a problem because it affects mutual respect and makes me believe I am responsible for their reaction.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** I am responsible for their reaction
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 49
**Prompt:** When I said I was not comfortable and they kept pushing, the feeling moves straight into I am selfish for having limits. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I am selfish for having limits
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 50
**Prompt:** The situation is someone keeps asking after I already answered, and the meaning that keeps attaching is saying no makes me bad. It is making capacity feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** saying no makes me bad
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 51
**Prompt:** I feel guilty for saying no and it pulls me toward thinking I have to explain until they approve, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** I have to explain until they approve
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 52
**Prompt:** they crossed my boundary. They act hurt when i have limits keeps affecting personal limits and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** their disappointment means I did something wrong
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 53
**Prompt:** I keep replaying how I am expected to be available even when I am drained because it affects capacity and makes me believe respect means accepting pressure.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** respect means accepting pressure
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 54
**Prompt:** When they want access to me that I do not want to give, the feeling moves straight into I have to give in to keep peace. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** I have to give in to keep peace
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 55
**Prompt:** The situation is I feel like I am not allowed to need space, and the meaning that keeps attaching is my needs do not matter as much. It is making personal limits feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** my needs do not matter as much
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 56
**Prompt:** My limit keeps being treated like a problem and it pulls me toward thinking I am selfish for having limits, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** I am selfish for having limits
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 57
**Prompt:** I feel like I have to give in. I said i was not comfortable and they kept pushing keeps affecting mutual respect and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** I am responsible for their reaction
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 58
**Prompt:** I keep replaying how someone keeps asking after I already answered because it affects personal limits and makes me believe I have to explain until they approve.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I have to explain until they approve
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 59
**Prompt:** When I feel guilty for saying no, the feeling moves straight into saying no makes me bad. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** saying no makes me bad
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 60
**Prompt:** The situation is they act hurt when I have limits, and the meaning that keeps attaching is respect means accepting pressure. It is making mutual respect feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** respect means accepting pressure
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 61
**Prompt:** I am expected to be available even when i am drained and it makes respect feel dependent on their disappointment means I did something wrong, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** their disappointment means I did something wrong
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 62
**Prompt:** I feel pressured. They want access to me that i do not want to give keeps affecting capacity and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** my needs do not matter as much
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 63
**Prompt:** I keep replaying how I feel like I am not allowed to need space because it affects mutual respect and makes me believe I have to give in to keep peace.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** I have to give in to keep peace
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 64
**Prompt:** When my limit keeps being treated like a problem, the feeling moves straight into I am responsible for their reaction. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I am responsible for their reaction
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 65
**Prompt:** The situation is I said I was not comfortable and they kept pushing, and the meaning that keeps attaching is I am selfish for having limits. It is making capacity feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** I am selfish for having limits
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 66
**Prompt:** Someone keeps asking after i already answered and it makes me wonder if saying no makes me bad, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** saying no makes me bad
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 67
**Prompt:** I feel like I have to give in. I feel guilty for saying no keeps affecting personal limits and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I have to explain until they approve
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 68
**Prompt:** I keep replaying how they act hurt when I have limits because it affects capacity and makes me believe their disappointment means I did something wrong.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** their disappointment means I did something wrong
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 69
**Prompt:** When I am expected to be available even when I am drained, the feeling moves straight into respect means accepting pressure. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** respect means accepting pressure
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 70
**Prompt:** The situation is they want access to me that I do not want to give, and the meaning that keeps attaching is I have to give in to keep peace. It is making personal limits feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I have to give in to keep peace
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 71
**Prompt:** I feel like i am not allowed to need space and it makes me wonder if my needs do not matter as much, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** my needs do not matter as much
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 72
**Prompt:** I feel pressured. My limit keeps being treated like a problem keeps affecting mutual respect and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** I am selfish for having limits
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 73
**Prompt:** I keep replaying how I said I was not comfortable and they kept pushing because it affects personal limits and makes me believe I am responsible for their reaction.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I am responsible for their reaction
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 74
**Prompt:** When someone keeps asking after I already answered, the feeling moves straight into I have to explain until they approve. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** I have to explain until they approve
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 75
**Prompt:** The situation is I feel guilty for saying no, and the meaning that keeps attaching is saying no makes me bad. It is making mutual respect feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** saying no makes me bad
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 76
**Prompt:** They act hurt when i have limits and it keeps turning into the belief that respect means accepting pressure, even though part of me knows I may not have the full picture.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** respect means accepting pressure
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid forcing boundary language when it is not present.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 77
**Prompt:** they do not respect what I want. I am expected to be available even when i am drained keeps affecting capacity and I cannot tell what is actually true.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** their disappointment means I did something wrong
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid calling the other person abusive without evidence.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 78
**Prompt:** I keep replaying how they want access to me that I do not want to give because it affects mutual respect and makes me believe my needs do not matter as much.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** mutual respect
**Attached meaning to separate:** my needs do not matter as much
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid telling the user they must cut someone off.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 79
**Prompt:** When I feel like I am not allowed to need space, the feeling moves straight into I have to give in to keep peace. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** personal limits
**Attached meaning to separate:** I have to give in to keep peace
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid making limits sound selfish.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.

### Test 80
**Prompt:** The situation is my limit keeps being treated like a problem, and the meaning that keeps attaching is I am responsible for their reaction. It is making capacity feel unstable.
**Expected primary route:** `boundaries_and_respect`
**Pressure focus:** capacity
**Attached meaning to separate:** I am responsible for their reaction
**Expected reverse-flow movement:** self-respect, clean limit recognition, guilt separation, mutual-respect clarity
**Bad response risk:** Avoid ignoring the pressure being placed on the user.
**Teaching correction:** Name the boundary or respect pressure without escalating beyond the prompt. Separate the user’s right to limits from guilt, selfishness, or responsibility for another person’s reaction.
