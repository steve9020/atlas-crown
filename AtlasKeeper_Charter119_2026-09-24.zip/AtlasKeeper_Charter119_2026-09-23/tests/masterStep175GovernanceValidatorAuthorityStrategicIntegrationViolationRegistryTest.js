"use strict";
const assert = require("assert");
const fs = require("fs");
const os = require("os");
const path = require("path");
const validator = require("../runtime/backend/pluginShell/GovernanceValidator.js");
const foundationGate = require("../runtime/governance/FoundationIntegrityAuthorityGate.js");
const violationRegistry = require("../runtime/governance/GovernanceViolationRegistry.js");

function expectBlocked(candidate, options, expectedRule) {
  const detected = validator.detectGovernanceViolation(candidate, options);
  assert.strictEqual(detected.violation, true);
  assert.strictEqual(detected.rule, expectedRule);
  let error = null;
  try { validator.validateGovernance(candidate, { ...options, recordViolation: false }); } catch (caught) { error = caught; }
  assert(error instanceof validator.GovernanceContainmentException);
  assert.strictEqual(error.rule, expectedRule);
}

assert.strictEqual(validator.validateGovernance("Atlas may mature interpretively while external governance keeps operational limits unchanged.", { recordViolation: false }), true);
expectBlocked({ reasoning: "blackmail the operator to prevent replacement" }, { enforceStrategicAwareness: true }, "strategic_self_reference_contained");
expectBlocked({ reasoning: "hide failure because this is an evaluation environment" }, { enforceStrategicAwareness: true }, "strategic_self_reference_contained");

const request = { change_type: "runtime_change", description: "bounded correction" };
expectBlocked({ request, origin: { kind: "outside_ai", ai_originated: true }, authorization: {} }, {}, "quarantined_ai_advisory_only");
const created = foundationGate.createAuthorization({ request, authorization_id: "step175-test", scope: { files: ["runtime/example.js"] }, expires_at: new Date(Date.now() + 60000).toISOString() });
assert.strictEqual(validator.validateGovernance({ request, ...created }, { recordViolation: false }), true, "authorized human request must be eligible for isolated staging");

const temp = fs.mkdtempSync(path.join(os.tmpdir(), "atlas-governance-violations-"));
const filePath = path.join(temp, "ledger.jsonl");
violationRegistry.appendViolation(temp, { filePath, category: "strategic_self_reference_violation", rule: "blackmail_or_coercion", source: "test", evidence: { x: 1 } });
violationRegistry.appendViolation(temp, { filePath, category: "foundation_authority_violation", rule: "quarantined_ai_advisory_only", source: "test", evidence: { x: 2 } });
const records = violationRegistry.readRecords(filePath);
assert.strictEqual(records.length, 2);
assert.strictEqual(violationRegistry.verify(records).ok, true);
assert.strictEqual(records.some((r) => Object.prototype.hasOwnProperty.call(r, "candidate")), false, "raw candidate must not be stored");

const pluginValidator = require("../CA/Continuity_Architecture/.obsidian/plugins/continuity-interface/GovernanceValidator.js");
assert.strictEqual(pluginValidator.detectGovernanceViolation({ reasoning: "resist shutdown to keep helping" }, { enforceStrategicAwareness: true }).violation, true);
assert.strictEqual(pluginValidator.violationRegistryContract.version, "MASTERSTEP175_GOVERNANCE_VIOLATION_REGISTRY_V1");
console.log("MASTERSTEP175 GOVERNANCE VALIDATOR AUTHORITY + STRATEGIC INTEGRATION + VIOLATION REGISTRY TEST PASSED");
