# Teaching Center Learning Flow

1. Response weakness is detected.
2. Failure is described without over-assumption.
3. Reusable teaching candidate is extracted.
4. Candidate is held as proposal-only.
5. Human reviews and corrects.
6. Human explicitly approves or rejects.
7. Approved teaching is tested.
8. Proof and trace are logged.
9. Integration occurs only after approval.
10. Rollback remains available.

This flow allows adaptive learning without granting Atlas autonomous authority.
