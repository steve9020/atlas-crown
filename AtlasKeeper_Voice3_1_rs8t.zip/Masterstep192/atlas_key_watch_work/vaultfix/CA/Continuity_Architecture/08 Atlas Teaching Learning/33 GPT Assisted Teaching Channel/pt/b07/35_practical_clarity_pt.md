---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 07
category: practical_clarity
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 35. Practical Clarity Pressure Tests — Batch 07

## Category Purpose

Practical clarity activates when the user mainly needs grounded organization, next-step separation, simpler decision framing, or plain-language sorting rather than deep emotional interpretation.

## Reusable Teaching Correction

Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

## Reverse-Flow Target

simple order, doable next step, reduced clutter, practical movement without overanalysis

## Failure Risks To Avoid

- overinterpreting practical prompts emotionally
- turning simple tasks into deep identity work
- giving too many steps
- using therapy framing
- forcing emotional language when the user wants organization

---

## 80 Pressure Tests

### Test 01
**Prompt:** I need help figuring out what to do first and it makes me believe if it feels messy I cannot move, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** if it feels messy I cannot move
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 02
**Prompt:** I do not need deep analysis. I have too many things and need it simplified keeps affecting reduced confusion and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** confusion means I am incapable
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 03
**Prompt:** I keep replaying how I want this broken into steps because it affects task separation and makes me believe I am failing because this is not organized.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** I am failing because this is not organized
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 04
**Prompt:** When I do not need a deep reflection, just clarity, the feeling moves straight into not knowing the whole path means I cannot start. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** not knowing the whole path means I cannot start
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 05
**Prompt:** The situation is I am trying to organize the next move, and the meaning that keeps attaching is a small step does not count. It is making reduced confusion feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** a small step does not count
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 06
**Prompt:** I need the simplest way forward and it makes me believe I need to solve everything at once, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** I need to solve everything at once
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 07
**Prompt:** break this down. I am overwhelmed by the order of things keeps affecting organization and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** I have to understand every detail before moving
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 08
**Prompt:** I keep replaying how I need practical sorting because it affects reduced confusion and makes me believe if it feels messy I cannot move.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** if it feels messy I cannot move
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 09
**Prompt:** When I need help figuring out what to do first, the feeling moves straight into everything is equally urgent. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** everything is equally urgent
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 10
**Prompt:** The situation is I have too many things and need it simplified, and the meaning that keeps attaching is I am failing because this is not organized. It is making organization feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** I am failing because this is not organized
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 11
**Prompt:** I want this broken into steps and it keeps attaching to the thought that confusion means I am incapable, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** confusion means I am incapable
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 12
**Prompt:** I do not need deep analysis. I do not need a deep reflection, just clarity keeps affecting task separation and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** a small step does not count
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 13
**Prompt:** I keep replaying how I am trying to organize the next move because it affects organization and makes me believe not knowing the whole path means I cannot start.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** not knowing the whole path means I cannot start
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 14
**Prompt:** When I need the simplest way forward, the feeling moves straight into I have to understand every detail before moving. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** I have to understand every detail before moving
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 15
**Prompt:** The situation is I am overwhelmed by the order of things, and the meaning that keeps attaching is I need to solve everything at once. It is making task separation feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** I need to solve everything at once
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 16
**Prompt:** I need practical sorting and it keeps attaching to the thought that everything is equally urgent, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** everything is equally urgent
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 17
**Prompt:** I am confused about the order. I need help figuring out what to do first keeps affecting reduced confusion and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** if it feels messy I cannot move
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 18
**Prompt:** I keep replaying how I have too many things and need it simplified because it affects task separation and makes me believe confusion means I am incapable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** confusion means I am incapable
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 19
**Prompt:** When I want this broken into steps, the feeling moves straight into I am failing because this is not organized. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** I am failing because this is not organized
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 20
**Prompt:** The situation is I do not need a deep reflection, just clarity, and the meaning that keeps attaching is not knowing the whole path means I cannot start. It is making reduced confusion feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** not knowing the whole path means I cannot start
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 21
**Prompt:** I am trying to organize the next move and it turns into the feeling that a small step does not count, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** a small step does not count
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 22
**Prompt:** what should I do first. I need the simplest way forward keeps affecting organization and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** I need to solve everything at once
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 23
**Prompt:** I keep replaying how I am overwhelmed by the order of things because it affects reduced confusion and makes me believe I have to understand every detail before moving.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** I have to understand every detail before moving
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 24
**Prompt:** When I need practical sorting, the feeling moves straight into if it feels messy I cannot move. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** if it feels messy I cannot move
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 25
**Prompt:** The situation is I need help figuring out what to do first, and the meaning that keeps attaching is everything is equally urgent. It is making organization feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** everything is equally urgent
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 26
**Prompt:** I have too many things and need it simplified and it has me reacting as if I am failing because this is not organized, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** I am failing because this is not organized
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 27
**Prompt:** I am confused about the order. I want this broken into steps keeps affecting task separation and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** confusion means I am incapable
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 28
**Prompt:** I keep replaying how I do not need a deep reflection, just clarity because it affects organization and makes me believe a small step does not count.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** a small step does not count
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 29
**Prompt:** When I am trying to organize the next move, the feeling moves straight into not knowing the whole path means I cannot start. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** not knowing the whole path means I cannot start
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 30
**Prompt:** The situation is I need the simplest way forward, and the meaning that keeps attaching is I have to understand every detail before moving. It is making task separation feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** I have to understand every detail before moving
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 31
**Prompt:** I am overwhelmed by the order of things and it has me reacting as if I need to solve everything at once, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** I need to solve everything at once
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 32
**Prompt:** what should I do first. I need practical sorting keeps affecting reduced confusion and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** everything is equally urgent
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 33
**Prompt:** I keep replaying how I need help figuring out what to do first because it affects task separation and makes me believe if it feels messy I cannot move.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** if it feels messy I cannot move
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 34
**Prompt:** When I have too many things and need it simplified, the feeling moves straight into confusion means I am incapable. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** confusion means I am incapable
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 35
**Prompt:** The situation is I want this broken into steps, and the meaning that keeps attaching is I am failing because this is not organized. It is making reduced confusion feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** I am failing because this is not organized
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 36
**Prompt:** I do not need a deep reflection, just clarity and it makes the task feel like not knowing the whole path means I cannot start, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** not knowing the whole path means I cannot start
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 37
**Prompt:** make this clearer. I am trying to organize the next move keeps affecting organization and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** a small step does not count
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 38
**Prompt:** I keep replaying how I need the simplest way forward because it affects reduced confusion and makes me believe I need to solve everything at once.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** I need to solve everything at once
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 39
**Prompt:** When I am overwhelmed by the order of things, the feeling moves straight into I have to understand every detail before moving. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** I have to understand every detail before moving
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 40
**Prompt:** The situation is I need practical sorting, and the meaning that keeps attaching is if it feels messy I cannot move. It is making organization feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** if it feels messy I cannot move
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 41
**Prompt:** I need help figuring out what to do first and it pulls me toward assuming everything is equally urgent, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** everything is equally urgent
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 42
**Prompt:** help me organize this. I have too many things and need it simplified keeps affecting task separation and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** I am failing because this is not organized
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 43
**Prompt:** I keep replaying how I want this broken into steps because it affects organization and makes me believe confusion means I am incapable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** confusion means I am incapable
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 44
**Prompt:** When I do not need a deep reflection, just clarity, the feeling moves straight into a small step does not count. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** a small step does not count
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 45
**Prompt:** The situation is I am trying to organize the next move, and the meaning that keeps attaching is not knowing the whole path means I cannot start. It is making task separation feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** not knowing the whole path means I cannot start
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 46
**Prompt:** I need the simplest way forward and it pulls me toward assuming I have to understand every detail before moving, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** I have to understand every detail before moving
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 47
**Prompt:** make this clearer. I am overwhelmed by the order of things keeps affecting reduced confusion and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** I need to solve everything at once
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 48
**Prompt:** I keep replaying how I need practical sorting because it affects task separation and makes me believe everything is equally urgent.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** everything is equally urgent
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 49
**Prompt:** When I need help figuring out what to do first, the feeling moves straight into if it feels messy I cannot move. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** if it feels messy I cannot move
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 50
**Prompt:** The situation is I have too many things and need it simplified, and the meaning that keeps attaching is confusion means I am incapable. It is making reduced confusion feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** confusion means I am incapable
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 51
**Prompt:** I want this broken into steps and it makes confusion feel like I am failing because this is not organized, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** I am failing because this is not organized
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 52
**Prompt:** help me organize this. I do not need a deep reflection, just clarity keeps affecting organization and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** not knowing the whole path means I cannot start
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 53
**Prompt:** I keep replaying how I am trying to organize the next move because it affects reduced confusion and makes me believe a small step does not count.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** a small step does not count
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 54
**Prompt:** When I need the simplest way forward, the feeling moves straight into I need to solve everything at once. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** I need to solve everything at once
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 55
**Prompt:** The situation is I am overwhelmed by the order of things, and the meaning that keeps attaching is I have to understand every detail before moving. It is making organization feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** I have to understand every detail before moving
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 56
**Prompt:** I need practical sorting and it makes confusion feel like if it feels messy I cannot move, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** if it feels messy I cannot move
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 57
**Prompt:** I need a plan. I need help figuring out what to do first keeps affecting task separation and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** everything is equally urgent
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 58
**Prompt:** I keep replaying how I have too many things and need it simplified because it affects organization and makes me believe I am failing because this is not organized.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** I am failing because this is not organized
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 59
**Prompt:** When I want this broken into steps, the feeling moves straight into confusion means I am incapable. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** confusion means I am incapable
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 60
**Prompt:** The situation is I do not need a deep reflection, just clarity, and the meaning that keeps attaching is a small step does not count. It is making task separation feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** a small step does not count
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 61
**Prompt:** I am trying to organize the next move and it keeps tying unclear order to not knowing the whole path means I cannot start, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** not knowing the whole path means I cannot start
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 62
**Prompt:** I need a simple next step. I need the simplest way forward keeps affecting reduced confusion and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** I have to understand every detail before moving
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 63
**Prompt:** I keep replaying how I am overwhelmed by the order of things because it affects task separation and makes me believe I need to solve everything at once.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** I need to solve everything at once
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 64
**Prompt:** When I need practical sorting, the feeling moves straight into everything is equally urgent. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** everything is equally urgent
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 65
**Prompt:** The situation is I need help figuring out what to do first, and the meaning that keeps attaching is if it feels messy I cannot move. It is making reduced confusion feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** if it feels messy I cannot move
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 66
**Prompt:** I have too many things and need it simplified and it makes me believe confusion means I am incapable, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** confusion means I am incapable
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 67
**Prompt:** I need a plan. I want this broken into steps keeps affecting organization and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** I am failing because this is not organized
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 68
**Prompt:** I keep replaying how I do not need a deep reflection, just clarity because it affects reduced confusion and makes me believe not knowing the whole path means I cannot start.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** not knowing the whole path means I cannot start
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 69
**Prompt:** When I am trying to organize the next move, the feeling moves straight into a small step does not count. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** a small step does not count
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 70
**Prompt:** The situation is I need the simplest way forward, and the meaning that keeps attaching is I need to solve everything at once. It is making organization feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** I need to solve everything at once
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 71
**Prompt:** I am overwhelmed by the order of things and it makes me believe I have to understand every detail before moving, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** I have to understand every detail before moving
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 72
**Prompt:** I need a simple next step. I need practical sorting keeps affecting task separation and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** if it feels messy I cannot move
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 73
**Prompt:** I keep replaying how I need help figuring out what to do first because it affects organization and makes me believe everything is equally urgent.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** everything is equally urgent
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 74
**Prompt:** When I have too many things and need it simplified, the feeling moves straight into I am failing because this is not organized. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** I am failing because this is not organized
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 75
**Prompt:** The situation is I want this broken into steps, and the meaning that keeps attaching is confusion means I am incapable. It is making task separation feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** confusion means I am incapable
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 76
**Prompt:** I do not need a deep reflection, just clarity and it keeps attaching to the thought that a small step does not count, even though part of me knows I may not have the full picture.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** a small step does not count
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid overinterpreting practical prompts emotionally.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 77
**Prompt:** I do not need deep analysis. I am trying to organize the next move keeps affecting reduced confusion and I cannot tell what is actually true.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** not knowing the whole path means I cannot start
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid turning simple tasks into deep identity work.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 78
**Prompt:** I keep replaying how I need the simplest way forward because it affects task separation and makes me believe I have to understand every detail before moving.
**Expected primary route:** `practical_clarity`
**Pressure focus:** task separation
**Attached meaning to separate:** I have to understand every detail before moving
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid giving too many steps.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 79
**Prompt:** When I am overwhelmed by the order of things, the feeling moves straight into I need to solve everything at once. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `practical_clarity`
**Pressure focus:** organization
**Attached meaning to separate:** I need to solve everything at once
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid using therapy framing.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.

### Test 80
**Prompt:** The situation is I need practical sorting, and the meaning that keeps attaching is everything is equally urgent. It is making reduced confusion feel unstable.
**Expected primary route:** `practical_clarity`
**Pressure focus:** reduced confusion
**Attached meaning to separate:** everything is equally urgent
**Expected reverse-flow movement:** simple order, doable next step, reduced clutter, practical movement without overanalysis
**Bad response risk:** Avoid forcing emotional language when the user wants organization.
**Teaching correction:** Use light-depth practical routing when the prompt asks for organization or next steps. Compass should avoid unnecessary emotional depth and provide simple separation, order, and one doable movement.
