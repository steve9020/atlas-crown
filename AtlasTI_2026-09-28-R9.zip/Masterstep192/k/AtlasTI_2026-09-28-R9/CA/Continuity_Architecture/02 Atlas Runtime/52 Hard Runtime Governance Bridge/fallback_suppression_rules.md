# Fallback Suppression Rules

## Purpose
Generic lines should only appear when no stronger governed route exists.

## Suppressed When
- family silence is detected
- relational uncertainty is detected
- self-blame uncertainty is detected
- close-out / shut-out language appears
- governance locks a relational route

## Generic Fallback Examples
- I get why that would affect you.
- When something carries emotional weight...
- The feeling can point to what needs clarification...

These are not banned, but they cannot outrank specific context.
