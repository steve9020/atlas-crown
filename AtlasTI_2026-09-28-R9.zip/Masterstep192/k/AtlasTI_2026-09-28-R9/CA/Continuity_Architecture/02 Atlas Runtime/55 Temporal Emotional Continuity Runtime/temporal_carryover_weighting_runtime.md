---
runtime_layer: teaching_growth
status: active
approval_required: true
silent_integration_allowed: false
---

# Temporal Carryover Weighting Runtime

## Purpose
Tracks past emotional weight active in present interpretation and future pressure attached to unresolved meaning.

## Governance
This node supports governed teaching growth only. It may create reviewable proposals, but it must not silently mutate runtime behavior without approval and retest proof.

## Related Runtime Links
- [[runtime_signal_registry]]
- [[response_behavior_registry]]
- [[runtime_weighting_registry]]
