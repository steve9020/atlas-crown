---
runtime_layer: response_weakness_detection
priority: high
owned_by: atlas_teaching_learning
feeds_into:
  - teaching_gap_detection_runtime_overview
---

# Backend Language Leak Detection Registry

## Purpose
Detects when Compass exposes Atlas backend classification language in a user-facing response.

## Leak examples
- this does not read as only a practical task problem
- time-layer
- work-continuity signal
- blocked movement
- route
- signal
- governance
- backend
- practical-only classification language

## User-facing correction direction
Backend recognition should be translated into soft, human language before Compass speaks.

## Rule
Compass should sound like it understands what the person is carrying, not like Atlas is reporting which category it detected.
