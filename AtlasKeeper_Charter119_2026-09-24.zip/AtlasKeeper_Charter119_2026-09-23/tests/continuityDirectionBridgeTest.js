const fs = require('fs');
const path = require('path');

const atlasRoot = path.join(__dirname, '..');
const pluginMain = path.join(atlasRoot, 'CA', 'Continuity_Architecture', '.obsidian', 'plugins', 'continuity-interface', 'main.js');
const text = fs.readFileSync(pluginMain, 'utf8');

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

assert(text.includes('const directionKey = hasAny'), 'directionKey detection is missing.');
assert(text.includes('const missedPiecesKey = hasAny'), 'missedPiecesKey detection is missing.');
assert(text.includes('progressKey && (mistakeContextKey || overwhelmKey || uncertaintyKey || directionKey || missedPiecesKey)'), 'progress continuity route does not include direction/missed-pieces bridge triggers.');
assert(text.includes('When every small thing that gets missed starts feeling connected'), 'continuity bridge see-language is missing.');
assert(text.includes('Missing pieces along the way can show where steadier ground is needed without proving that your direction is gone'), 'continuity bridge separation-language is missing.');
assert(text.includes('There is still room to return to the path without treating every missed thing as evidence that you are falling behind'), 'continuity bridge restoration-language is missing.');
assert(text.includes('Restore direction and self-trust'), 'frontend rule does not preserve direction/self-trust restoration.');

console.log('CONTINUITY / DIRECTION BRIDGE TEST');
console.log('==================================');
console.log('directionKey detection: PASSED');
console.log('missedPiecesKey detection: PASSED');
console.log('progress route bridge trigger: PASSED');
console.log('bridge language: PASSED');
console.log('restoration target: PASSED');
