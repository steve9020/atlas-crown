# Local Proof Orchestrator

Use the Teaching Center buttons or CLI:

- `node proof/runProofOrchestrator.js --mode targeted`
- `node proof/runProofOrchestrator.js --mode incremental`
- `node proof/runProofOrchestrator.js --mode full`

Only a successful full run marks the package keeper-eligible. Incremental cache reuse requires unchanged file fingerprints.
