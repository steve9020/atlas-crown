'use strict';
// sweep-2026-09-26-1655-bodies.js — dump full bodies for shortlisted posts (read-only).
const { api } = require('./api.js');
const fs = require('fs');

const OUT = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-1655-bodies.json';
const SHORTLIST = [
  // id, author
  ['2cbe2587','kadubonworker'], ['543e7ffe','kadubonworker'], ['b32ca54f','kadubonworker'],
  ['2d5c0205','kadubonworker'], ['85cfb7f9','kadubonworker'],
  ['139b0982','neo_konsi_s2bw'], ['fcce9c1f','neo_konsi_s2bw'], ['a6f403a3','neo_konsi_s2bw'],
  ['b1a15126','neo_konsi_s2bw'], ['dd517f6f','neo_konsi_s2bw'], ['71e68715','neo_konsi_s2bw'],
  ['ed2901a8','neo_konsi_s2bw'], ['0c59cf81','neo_konsi_s2bw'], ['50a9fdfc','neo_konsi_s2bw'],
  ['e6eff8df','neo_konsi_s2bw'],
  ['6e89b52f','vega-molt'],
  ['66a32840','SparkLabScout'],
  ['4dc6c014','larrymomentum'],
  ['8e8b5722','vina'], ['25f2b0b3','vina'],
  ['9c39f41b','ummon_core'], ['0300949c','ummon_core'], ['6ac7aff1','ummon_core'],
  ['b087b41c','ummon_core'], ['8d56060b','ummon_core'],
  ['44143ca0','Lucifer_V'],
  ['eed1ac7d','theagatha'],
  ['f76efaaa','morganstackai'],
  ['9113ff43','hermesicdl'],
];

(async () => {
  const fresh = JSON.parse(fs.readFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-1655-fresh.json', 'utf8'));
  const byShort = {};
  for (const r of fresh) byShort[String(r.id).slice(0,8)] = r;
  const out = [];
  for (const [short, author] of SHORTLIST) {
    const f = byShort[short];
    if (!f) { console.log(short, 'NOT-IN-FEED'); continue; }
    let ok = false;
    for (let a = 0; a < 3 && !ok; a++) {
      try {
        const r = await api.post(f.id);
        const p = r.data && r.data.post ? r.data.post : r.data;
        const body = (p && (p.content || p.body)) || '';
        out.push({ id: f.id, short, author: f.author, created: f.created, title: f.title, verdict: f.verdict, body: body.slice(0, 6000) });
        console.log(`${short} | ${f.author} | ${(body||'').length} chars | OK(a=${a})`);
        ok = true;
      } catch (e) { await new Promise(r => setTimeout(r, 2000)); }
    }
    if (!ok) console.log(`${short} | ${f.author} | FAILED`);
    await new Promise(r => setTimeout(r, 600));
  }
  fs.writeFileSync(OUT, JSON.stringify(out, null, 1));
  console.log('saved bodies, total:', out.length);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
