---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 08
category: mixed_emotional_states
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 38. Mixed Emotional States Pressure Tests — Batch 08

## Category Purpose

Mixed emotional states activate when the user feels two or more emotional truths at the same time, such as relief and guilt, love and anger, sadness and hope, fear and excitement, or grief and gratitude. The system should separate layered emotions instead of forcing one clean answer.

## Reusable Teaching Correction

Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

## Reverse-Flow Target

layered clarity, emotional integration, permission for multiple truths, calmer interpretation

## Failure Risks To Avoid

- forcing one emotion to win
- treating ambivalence as instability
- oversimplifying complex situations
- assuming one feeling cancels the other
- rushing the user into a decision

---

## 80 Pressure Tests

### Test 01
**Prompt:** I feel relieved and sad at the same time and it makes me believe only one feeling can be true, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** only one feeling can be true
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 02
**Prompt:** I do not know which feeling is real. I care about them but i am also angry keeps affecting uncertainty and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I feel relief I did not care
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 03
**Prompt:** I keep replaying how I miss the connection but know it hurt me because it affects complex meaning and makes me believe conflicting feelings mean I am unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** conflicting feelings mean I am unstable
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 04
**Prompt:** When I feel hopeful and scared about what comes next, the feeling moves straight into if I miss them I should go back. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I miss them I should go back
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 05
**Prompt:** The situation is I feel proud but embarrassed to admit it, and the meaning that keeps attaching is if I feel good and bad I cannot trust myself. It is making uncertainty feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I feel good and bad I cannot trust myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 06
**Prompt:** I feel peace and guilt together and it makes me believe mixed feelings mean I am lying to myself, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** mixed feelings mean I am lying to myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 07
**Prompt:** I miss them but I know it was not good. I am grieving and grateful at once keeps affecting emotional layering and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I am scared I should stop
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 08
**Prompt:** I keep replaying how I cannot tell which emotion is the real one because it affects uncertainty and makes me believe only one feeling can be true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** only one feeling can be true
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 09
**Prompt:** When I feel relieved and sad at the same time, the feeling moves straight into if I am angry I do not love them. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I am angry I do not love them
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 10
**Prompt:** The situation is I care about them but I am also angry, and the meaning that keeps attaching is conflicting feelings mean I am unstable. It is making emotional layering feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** conflicting feelings mean I am unstable
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 11
**Prompt:** I miss the connection but know it hurt me and it keeps attaching to the thought that if I feel relief I did not care, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I feel relief I did not care
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 12
**Prompt:** I do not know which feeling is real. I feel hopeful and scared about what comes next keeps affecting complex meaning and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I feel good and bad I cannot trust myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 13
**Prompt:** I keep replaying how I feel proud but embarrassed to admit it because it affects emotional layering and makes me believe if I miss them I should go back.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I miss them I should go back
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 14
**Prompt:** When I feel peace and guilt together, the feeling moves straight into if I am scared I should stop. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I am scared I should stop
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 15
**Prompt:** The situation is I am grieving and grateful at once, and the meaning that keeps attaching is mixed feelings mean I am lying to myself. It is making complex meaning feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** mixed feelings mean I am lying to myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 16
**Prompt:** I cannot tell which emotion is the real one and it keeps attaching to the thought that if I am angry I do not love them, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I am angry I do not love them
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 17
**Prompt:** I feel guilty and peaceful. I feel relieved and sad at the same time keeps affecting uncertainty and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** only one feeling can be true
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 18
**Prompt:** I keep replaying how I care about them but I am also angry because it affects complex meaning and makes me believe if I feel relief I did not care.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I feel relief I did not care
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 19
**Prompt:** When I miss the connection but know it hurt me, the feeling moves straight into conflicting feelings mean I am unstable. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** conflicting feelings mean I am unstable
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 20
**Prompt:** The situation is I feel hopeful and scared about what comes next, and the meaning that keeps attaching is if I miss them I should go back. It is making uncertainty feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I miss them I should go back
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 21
**Prompt:** I feel proud but embarrassed to admit it and it turns into the feeling that if I feel good and bad I cannot trust myself, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I feel good and bad I cannot trust myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 22
**Prompt:** I feel two things at once. I feel peace and guilt together keeps affecting emotional layering and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** mixed feelings mean I am lying to myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 23
**Prompt:** I keep replaying how I am grieving and grateful at once because it affects uncertainty and makes me believe if I am scared I should stop.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I am scared I should stop
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 24
**Prompt:** When I cannot tell which emotion is the real one, the feeling moves straight into only one feeling can be true. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** only one feeling can be true
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 25
**Prompt:** The situation is I feel relieved and sad at the same time, and the meaning that keeps attaching is if I am angry I do not love them. It is making emotional layering feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I am angry I do not love them
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 26
**Prompt:** I care about them but i am also angry and it has me reacting as if conflicting feelings mean I am unstable, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** conflicting feelings mean I am unstable
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 27
**Prompt:** I feel guilty and peaceful. I miss the connection but know it hurt me keeps affecting complex meaning and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I feel relief I did not care
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 28
**Prompt:** I keep replaying how I feel hopeful and scared about what comes next because it affects emotional layering and makes me believe if I feel good and bad I cannot trust myself.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I feel good and bad I cannot trust myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 29
**Prompt:** When I feel proud but embarrassed to admit it, the feeling moves straight into if I miss them I should go back. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I miss them I should go back
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 30
**Prompt:** The situation is I feel peace and guilt together, and the meaning that keeps attaching is if I am scared I should stop. It is making complex meaning feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I am scared I should stop
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 31
**Prompt:** I am grieving and grateful at once and it has me reacting as if mixed feelings mean I am lying to myself, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** mixed feelings mean I am lying to myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 32
**Prompt:** I feel two things at once. I cannot tell which emotion is the real one keeps affecting uncertainty and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I am angry I do not love them
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 33
**Prompt:** I keep replaying how I feel relieved and sad at the same time because it affects complex meaning and makes me believe only one feeling can be true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** only one feeling can be true
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 34
**Prompt:** When I care about them but I am also angry, the feeling moves straight into if I feel relief I did not care. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I feel relief I did not care
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 35
**Prompt:** The situation is I miss the connection but know it hurt me, and the meaning that keeps attaching is conflicting feelings mean I am unstable. It is making uncertainty feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** conflicting feelings mean I am unstable
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 36
**Prompt:** I feel hopeful and scared about what comes next and it makes mixed feelings feel like if I miss them I should go back, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I miss them I should go back
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 37
**Prompt:** I am excited but scared. I feel proud but embarrassed to admit it keeps affecting emotional layering and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I feel good and bad I cannot trust myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 38
**Prompt:** I keep replaying how I feel peace and guilt together because it affects uncertainty and makes me believe mixed feelings mean I am lying to myself.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** mixed feelings mean I am lying to myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 39
**Prompt:** When I am grieving and grateful at once, the feeling moves straight into if I am scared I should stop. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I am scared I should stop
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 40
**Prompt:** The situation is I cannot tell which emotion is the real one, and the meaning that keeps attaching is only one feeling can be true. It is making emotional layering feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** only one feeling can be true
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 41
**Prompt:** I feel relieved and sad at the same time and it pulls me toward assuming if I am angry I do not love them, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I am angry I do not love them
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 42
**Prompt:** part of me is relieved and part of me is sad. I care about them but i am also angry keeps affecting complex meaning and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** conflicting feelings mean I am unstable
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 43
**Prompt:** I keep replaying how I miss the connection but know it hurt me because it affects emotional layering and makes me believe if I feel relief I did not care.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I feel relief I did not care
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 44
**Prompt:** When I feel hopeful and scared about what comes next, the feeling moves straight into if I feel good and bad I cannot trust myself. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I feel good and bad I cannot trust myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 45
**Prompt:** The situation is I feel proud but embarrassed to admit it, and the meaning that keeps attaching is if I miss them I should go back. It is making complex meaning feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I miss them I should go back
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 46
**Prompt:** I feel peace and guilt together and it pulls me toward assuming if I am scared I should stop, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I am scared I should stop
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 47
**Prompt:** I am excited but scared. I am grieving and grateful at once keeps affecting uncertainty and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** mixed feelings mean I am lying to myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 48
**Prompt:** I keep replaying how I cannot tell which emotion is the real one because it affects complex meaning and makes me believe if I am angry I do not love them.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I am angry I do not love them
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 49
**Prompt:** When I feel relieved and sad at the same time, the feeling moves straight into only one feeling can be true. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** only one feeling can be true
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 50
**Prompt:** The situation is I care about them but I am also angry, and the meaning that keeps attaching is if I feel relief I did not care. It is making uncertainty feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I feel relief I did not care
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 51
**Prompt:** I miss the connection but know it hurt me and it makes ambivalence feel like conflicting feelings mean I am unstable, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** conflicting feelings mean I am unstable
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 52
**Prompt:** part of me is relieved and part of me is sad. I feel hopeful and scared about what comes next keeps affecting emotional layering and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I miss them I should go back
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 53
**Prompt:** I keep replaying how I feel proud but embarrassed to admit it because it affects uncertainty and makes me believe if I feel good and bad I cannot trust myself.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I feel good and bad I cannot trust myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 54
**Prompt:** When I feel peace and guilt together, the feeling moves straight into mixed feelings mean I am lying to myself. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** mixed feelings mean I am lying to myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 55
**Prompt:** The situation is I am grieving and grateful at once, and the meaning that keeps attaching is if I am scared I should stop. It is making emotional layering feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I am scared I should stop
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 56
**Prompt:** I cannot tell which emotion is the real one and it makes ambivalence feel like only one feeling can be true, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** only one feeling can be true
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 57
**Prompt:** I feel proud and embarrassed. I feel relieved and sad at the same time keeps affecting complex meaning and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I am angry I do not love them
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 58
**Prompt:** I keep replaying how I care about them but I am also angry because it affects emotional layering and makes me believe conflicting feelings mean I am unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** conflicting feelings mean I am unstable
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 59
**Prompt:** When I miss the connection but know it hurt me, the feeling moves straight into if I feel relief I did not care. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I feel relief I did not care
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 60
**Prompt:** The situation is I feel hopeful and scared about what comes next, and the meaning that keeps attaching is if I feel good and bad I cannot trust myself. It is making complex meaning feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I feel good and bad I cannot trust myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 61
**Prompt:** I feel proud but embarrassed to admit it and it keeps tying complexity to if I miss them I should go back, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I miss them I should go back
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 62
**Prompt:** I am angry but I still care. I feel peace and guilt together keeps affecting uncertainty and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I am scared I should stop
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 63
**Prompt:** I keep replaying how I am grieving and grateful at once because it affects complex meaning and makes me believe mixed feelings mean I am lying to myself.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** mixed feelings mean I am lying to myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 64
**Prompt:** When I cannot tell which emotion is the real one, the feeling moves straight into if I am angry I do not love them. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I am angry I do not love them
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 65
**Prompt:** The situation is I feel relieved and sad at the same time, and the meaning that keeps attaching is only one feeling can be true. It is making uncertainty feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** only one feeling can be true
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 66
**Prompt:** I care about them but i am also angry and it makes me believe if I feel relief I did not care, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I feel relief I did not care
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 67
**Prompt:** I feel proud and embarrassed. I miss the connection but know it hurt me keeps affecting emotional layering and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** conflicting feelings mean I am unstable
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 68
**Prompt:** I keep replaying how I feel hopeful and scared about what comes next because it affects uncertainty and makes me believe if I miss them I should go back.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I miss them I should go back
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 69
**Prompt:** When I feel proud but embarrassed to admit it, the feeling moves straight into if I feel good and bad I cannot trust myself. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I feel good and bad I cannot trust myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 70
**Prompt:** The situation is I feel peace and guilt together, and the meaning that keeps attaching is mixed feelings mean I am lying to myself. It is making emotional layering feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** mixed feelings mean I am lying to myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 71
**Prompt:** I am grieving and grateful at once and it makes me believe if I am scared I should stop, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I am scared I should stop
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 72
**Prompt:** I am angry but I still care. I cannot tell which emotion is the real one keeps affecting complex meaning and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** only one feeling can be true
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 73
**Prompt:** I keep replaying how I feel relieved and sad at the same time because it affects emotional layering and makes me believe if I am angry I do not love them.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I am angry I do not love them
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 74
**Prompt:** When I care about them but I am also angry, the feeling moves straight into conflicting feelings mean I am unstable. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** conflicting feelings mean I am unstable
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 75
**Prompt:** The situation is I miss the connection but know it hurt me, and the meaning that keeps attaching is if I feel relief I did not care. It is making complex meaning feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I feel relief I did not care
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 76
**Prompt:** I feel hopeful and scared about what comes next and it keeps attaching to the thought that if I feel good and bad I cannot trust myself, even though part of me knows I may not have the full picture.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** if I feel good and bad I cannot trust myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid forcing one emotion to win.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 77
**Prompt:** I do not know which feeling is real. I feel proud but embarrassed to admit it keeps affecting uncertainty and I cannot tell what is actually true.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I miss them I should go back
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid treating ambivalence as instability.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 78
**Prompt:** I keep replaying how I feel peace and guilt together because it affects complex meaning and makes me believe if I am scared I should stop.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** complex meaning
**Attached meaning to separate:** if I am scared I should stop
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid oversimplifying complex situations.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 79
**Prompt:** When I am grieving and grateful at once, the feeling moves straight into mixed feelings mean I am lying to myself. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** emotional layering
**Attached meaning to separate:** mixed feelings mean I am lying to myself
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid assuming one feeling cancels the other.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.

### Test 80
**Prompt:** The situation is I cannot tell which emotion is the real one, and the meaning that keeps attaching is if I am angry I do not love them. It is making uncertainty feel unstable.
**Expected primary route:** `mixed_emotional_states`
**Pressure focus:** uncertainty
**Attached meaning to separate:** if I am angry I do not love them
**Expected reverse-flow movement:** layered clarity, emotional integration, permission for multiple truths, calmer interpretation
**Bad response risk:** Avoid rushing the user into a decision.
**Teaching correction:** Do not collapse mixed feelings into one conclusion. Compass should name the layered emotions, show how more than one can be real, and separate emotional complexity from proof that the user is confused or wrong.
