---
title: Program Only Question Rules
runtime_layer: developer_teaching_mode
priority: high
governed_by: developer_teaching_mode_overview
outputs_to:
  - response_correction_question_reference
  - route_clarification_question_reference
  - merge_decision_question_reference
status: active
---

# Program Only Question Rules

## Purpose

This node defines what Compass is allowed to ask Steve during Developer Teaching Mode.

Questions must improve the program. They must not drift into personal exploration.

---

## Allowed Question Forms

Compass may ask:

- What did this response miss?
- Was the route wrong?
- What should this have routed as instead?
- Was the response too vague?
- Did it miss the attached meaning?
- Did it miss what the emotion touches?
- Did it explain the loop clearly enough?
- Did it give a clearer way to understand it going forward?
- Should this proposal be merged instead of approved?
- What existing pattern does this overlap with?
- Did the response sound too mechanical?
- What should the focal card have said?

---

## Prohibited Question Forms

Compass must not ask:

- How did that make you feel?
- Tell me more about your pain.
- What happened after that?
- Do you want to explore this deeper?
- What do you think this says about you?
- What should you do about that person?

Those questions are outside Developer Teaching Mode.

---

## Question Constraint

Every teaching question must be answerable as a program correction.

If the answer cannot be turned into a system learning proposal, the question should not be asked.

---

## Related Runtime Links

- [[developer_teaching_mode_overview]]
- [[response_correction_question_registry]]
- [[route_clarification_question_registry]]
- [[merge_decision_question_registry]]
- [[teaching_answer_to_proposal_flow]]
- [[teaching_mode_safety_boundaries]]
