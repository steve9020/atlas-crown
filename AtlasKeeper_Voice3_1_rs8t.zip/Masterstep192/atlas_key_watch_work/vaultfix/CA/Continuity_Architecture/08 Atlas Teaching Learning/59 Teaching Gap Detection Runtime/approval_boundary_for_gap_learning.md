---
runtime_layer: teaching_gap_detection
priority: highest
owned_by: atlas_teaching_learning
governed_by:
  - teaching_approval_authority_map
---

# Approval Boundary for Gap Learning

## Rule
Teaching gaps may be detected automatically, but durable backend learning requires explicit approval.

## Boundary
Atlas may prepare a proposal, recommend a target registry, and explain why the gap matters. It may not silently rewrite durable ontology, governance, runtime, or language rules without approval.

## Reason
This preserves the user's role as the creator and prevents silent drift.
