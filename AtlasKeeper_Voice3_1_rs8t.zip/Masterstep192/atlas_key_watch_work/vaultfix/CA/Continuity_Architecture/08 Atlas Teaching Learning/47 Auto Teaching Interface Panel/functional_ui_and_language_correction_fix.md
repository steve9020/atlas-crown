# Functional UI and Language Correction Fix

## Purpose
This update turns the Auto Teaching dashboard from a mostly visual layout into a functional interface.

## Fixes
- dashboard navigation remains clickable
- overview tabs switch visible panels
- engine buttons provide action feedback
- cooldown remains selectable
- coverage colors now coordinate with category labels
- category overview percentage is weighted by category counts
- donut center text is properly centered
- bottom controls no longer cut off text
- visible Language Correction panel added

## Language Correction
The Language Correction panel creates a proposal-style correction targeting:
`49 Experiential Realism Calibration Engine/human_realism_scoring_registry.md`

This allows the user to teach Atlas response-language preferences such as:
- too robotic
- too clinical
- too emotionally heavy
- too generic
- too soft
- too authoritative
- needs context first
- needs stronger reverse-flow
