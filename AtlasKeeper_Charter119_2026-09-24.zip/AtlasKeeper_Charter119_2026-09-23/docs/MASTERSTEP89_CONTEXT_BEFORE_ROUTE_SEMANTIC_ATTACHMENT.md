# Masterstep89 — Context-Before-Route Semantic Attachment

Purpose: enforce the existing Atlas context-before-route / route assumption resistance principle inside the live semantic attachment scorer.

## Correction

The broad phrase `don’t know how` may no longer win ability/capability pressure by itself when the surrounding context clearly points to communication, answer/reply uncertainty, and fear of making the situation worse.

## Scope

- No deletion.
- No new ontology.
- No new mechanisms.
- No provider/model/cloud/API/network bridge.
- No operator console.
- No frontend intelligence.

## Expected behavior

- `don’t know how to answer without making it worse` routes as relational response uncertainty.
- `don’t know how to keep up with everything / falling behind` still routes as ability/capability pressure.
- Full context must confirm broad phrase routes before they can become the primary attachment family.
