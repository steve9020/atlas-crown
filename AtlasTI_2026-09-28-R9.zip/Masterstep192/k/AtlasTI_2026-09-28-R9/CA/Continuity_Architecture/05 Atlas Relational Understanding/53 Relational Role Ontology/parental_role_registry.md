# Parental Role Registry

## Roles
- mother / mom / mama / mommy
- father / dad / daddy / papa

## Priority
Very high emotional weight.

## Common Meaning Pressure
- attachment
- approval
- protection
- care
- abandonment
- worth
- belonging
- safety

## Runtime Rule
Parental roles should strongly increase context priority when paired with distance, silence, rejection, anger, abandonment, shame, guilt, or approval pressure.
