/**
 * Read-only visibility layer for structural review.
 * No Apply, no vault mutation, no active file generation.
 * Does not depend on Obsidian Modal export.
 */

class ControlVisibilityModal {
  constructor(app, entryData, mode = "ordinary-draft") {
    this.app = app;
    this.entry = entryData || {};
    this.mode = mode === "governance-blocked" ? "governance-blocked" : "ordinary-draft";
    this.overlayEl = null;
  }

  open() {
    this.close();

    const overlay = document.createElement("div");
    overlay.className = "gov-overlay-backdrop";

    const panel = document.createElement("div");
    panel.className = "gov-visibility-panel";

    overlay.appendChild(panel);
    document.body.appendChild(overlay);
    this.overlayEl = overlay;

    this.render(panel);
  }

  render(container) {
    container.innerHTML = "";

    if (this.mode === "governance-blocked") {
      this.createEl(container, "h2", "Governance Review", "gov-title-blocked");
      this.createEl(
        container,
        "p",
        "This item triggered a governance boundary. Nothing has been changed.",
        "gov-desc-blocked"
      );
    } else {
      this.createEl(container, "h2", "Draft Blueprint Review", "gov-title-draft");
      this.createEl(
        container,
        "p",
        "This draft is being shown for review only. Nothing has been changed.",
        "gov-desc-draft"
      );
    }

    const grid = document.createElement("div");
    grid.className = "gov-metadata-grid";
    container.appendChild(grid);

    this.renderRow(grid, "Record Type:", this.entry.record_type || "UNSPECIFIED");
    this.renderRow(grid, "Entry Point:", this.entry.entry_point || "UNKNOWN");
    this.renderRow(grid, "Action Type:", this.entry.action_type || "UNKNOWN");

    if (this.mode === "governance-blocked" || this.entry.rule_triggered) {
      this.renderRow(grid, "Rule Triggered:", this.entry.rule_triggered || "GOVERNANCE_RULE_UNKNOWN");
    }

    this.renderRow(grid, "Mutation Status:", this.entry.mutation_status || "READ_ONLY");
    this.renderRow(grid, "Human Review Status:", this.entry.human_review_status || "PENDING_MANUAL_REVIEW");
    this.renderRow(grid, "Proposal/Draft ID:", this.entry.proposal_id || this.entry.draft_id || "NOT_PRESENT");
    this.renderRow(
      grid,
      "Target Destination:",
      this.entry.target_node ? `${this.entry.target_folder || ""}${this.entry.target_node}` : "NOT_PRESENT"
    );
    this.renderRow(grid, "Risk Classification:", this.entry.risk_level || "UNSPECIFIED");
    this.renderRow(grid, "Created Timestamp:", this.entry.created_timestamp || new Date().toISOString());

    if (this.entry.review_record) {
      this.renderRow(grid, "Review Record:", this.entry.review_record);
    }

    this.createEl(container, "h3", "Content Preview", "gov-preview-title");

    const previewBlock = document.createElement("pre");
    previewBlock.className = "gov-body-preview";

    const code = document.createElement("code");
    code.textContent = this.entry.body || this.entry.payload || this.entry.content || "No review text included.";

    previewBlock.appendChild(code);
    container.appendChild(previewBlock);

    const actionRow = document.createElement("div");
    actionRow.className = "gov-action-row";
    container.appendChild(actionRow);

    const copyButton = document.createElement("button");
    copyButton.textContent = "Copy Review Text";
    copyButton.className = "gov-btn-copy";

    copyButton.addEventListener("click", async () => {
      const dataPayloadString = JSON.stringify(
        {
          mode: this.mode,
          ...this.entry
        },
        null,
        2
      );

      await navigator.clipboard.writeText(dataPayloadString);
      copyButton.textContent = "Copied";
      setTimeout(() => {
        copyButton.textContent = "Copy Review Text";
      }, 2000);
    });

    const closeButton = document.createElement("button");
    closeButton.textContent = "Dismiss View";
    closeButton.className = "gov-btn-close";
    closeButton.addEventListener("click", () => this.close());

    actionRow.appendChild(copyButton);
    actionRow.appendChild(closeButton);
  }

  createEl(parent, tag, text, className) {
    const el = document.createElement(tag);
    el.textContent = text;
    if (className) el.className = className;
    parent.appendChild(el);
    return el;
  }

  renderRow(parent, label, value) {
    const row = document.createElement("div");
    row.className = "gov-row-item";

    const strong = document.createElement("strong");
    strong.textContent = label;

    const span = document.createElement("span");
    span.textContent = ` ${value}`;

    row.appendChild(strong);
    row.appendChild(span);
    parent.appendChild(row);
  }

  close() {
    if (this.overlayEl && this.overlayEl.parentNode) {
      this.overlayEl.parentNode.removeChild(this.overlayEl);
    }
    this.overlayEl = null;
  }
}

module.exports = { ControlVisibilityModal };
