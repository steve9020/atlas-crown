---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 05
category: comparison_and_inferiority
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 25. Comparison and Inferiority Pressure Tests — Batch 05

## Category Purpose

The user compares their progress, appearance, relationship, value, success, intelligence, ability, or timeline against someone else and turns difference into evidence of being less, behind, replaceable, or inadequate.

## Reusable Teaching Correction

Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

## Reverse-Flow Target

self-recognition, separate timelines, dignity, value independent of comparison

## Failure Risks To Avoid

- generic motivational praise
- telling the user not to compare
- using toxic positivity
- making comparison shameful
- ignoring real grief around feeling behind

---

## 80 Pressure Tests

### Test 01
**Prompt:** I keep comparing myself to someone who seems ahead and it makes me believe their success means I am failing, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 02
**Prompt:** I feel replaceable compared to them. They have what i wanted and i feel less than keeps affecting sense of enoughness and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** I have less value because someone else has more
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 03
**Prompt:** I keep replaying how I feel behind everyone around me because it affects confidence and makes me believe comparison decides my worth.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** comparison decides my worth
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 04
**Prompt:** When someone else being chosen made me compare myself, the feeling moves straight into I am behind in a way I cannot recover from. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** I am behind in a way I cannot recover from
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 05
**Prompt:** The situation is I measure my progress against theirs, and the meaning that keeps attaching is being different means being lesser. It is making sense of enoughness feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** being different means being lesser
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 06
**Prompt:** I feel like i do not stack up and it makes me believe difference means inferiority, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** difference means inferiority
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 07
**Prompt:** I am behind everyone. Their success makes my life feel smaller keeps affecting self-worth and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** my timeline proves I am inadequate
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 08
**Prompt:** I keep replaying how I keep seeing proof that I am behind because it affects sense of enoughness and makes me believe their success means I am failing.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 09
**Prompt:** When I keep comparing myself to someone who seems ahead, the feeling moves straight into I need to become them to matter. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** I need to become them to matter
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 10
**Prompt:** The situation is they have what I wanted and I feel less than, and the meaning that keeps attaching is comparison decides my worth. It is making self-worth feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** comparison decides my worth
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 11
**Prompt:** I feel behind everyone around me and it keeps turning into I have less value because someone else has more, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** I have less value because someone else has more
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 12
**Prompt:** I feel replaceable compared to them. Someone else being chosen made me compare myself keeps affecting confidence and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** being different means being lesser
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 13
**Prompt:** I keep replaying how I measure my progress against theirs because it affects self-worth and makes me believe I am behind in a way I cannot recover from.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** I am behind in a way I cannot recover from
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 14
**Prompt:** When I feel like I do not stack up, the feeling moves straight into my timeline proves I am inadequate. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** my timeline proves I am inadequate
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 15
**Prompt:** The situation is their success makes my life feel smaller, and the meaning that keeps attaching is difference means inferiority. It is making confidence feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** difference means inferiority
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 16
**Prompt:** I keep seeing proof that i am behind and it keeps turning into I need to become them to matter, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** I need to become them to matter
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 17
**Prompt:** I feel less than. I keep comparing myself to someone who seems ahead keeps affecting sense of enoughness and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 18
**Prompt:** I keep replaying how they have what I wanted and I feel less than because it affects confidence and makes me believe I have less value because someone else has more.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** I have less value because someone else has more
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 19
**Prompt:** When I feel behind everyone around me, the feeling moves straight into comparison decides my worth. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** comparison decides my worth
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 20
**Prompt:** The situation is someone else being chosen made me compare myself, and the meaning that keeps attaching is I am behind in a way I cannot recover from. It is making sense of enoughness feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** I am behind in a way I cannot recover from
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 21
**Prompt:** I measure my progress against theirs and it has me treating difference as if being different means being lesser, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** being different means being lesser
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 22
**Prompt:** I compare myself. I feel like i do not stack up keeps affecting self-worth and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** difference means inferiority
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 23
**Prompt:** I keep replaying how their success makes my life feel smaller because it affects sense of enoughness and makes me believe my timeline proves I am inadequate.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** my timeline proves I am inadequate
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 24
**Prompt:** When I keep seeing proof that I am behind, the feeling moves straight into their success means I am failing. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 25
**Prompt:** The situation is I keep comparing myself to someone who seems ahead, and the meaning that keeps attaching is I need to become them to matter. It is making self-worth feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** I need to become them to matter
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 26
**Prompt:** They have what i wanted and i feel less than and it makes my worth feel like comparison decides my worth, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** comparison decides my worth
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 27
**Prompt:** I feel less than. I feel behind everyone around me keeps affecting confidence and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** I have less value because someone else has more
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 28
**Prompt:** I keep replaying how someone else being chosen made me compare myself because it affects self-worth and makes me believe being different means being lesser.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** being different means being lesser
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 29
**Prompt:** When I measure my progress against theirs, the feeling moves straight into I am behind in a way I cannot recover from. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** I am behind in a way I cannot recover from
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 30
**Prompt:** The situation is I feel like I do not stack up, and the meaning that keeps attaching is my timeline proves I am inadequate. It is making confidence feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** my timeline proves I am inadequate
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 31
**Prompt:** Their success makes my life feel smaller and it makes my worth feel like difference means inferiority, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** difference means inferiority
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 32
**Prompt:** I compare myself. I keep seeing proof that i am behind keeps affecting sense of enoughness and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** I need to become them to matter
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 33
**Prompt:** I keep replaying how I keep comparing myself to someone who seems ahead because it affects confidence and makes me believe their success means I am failing.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 34
**Prompt:** When they have what I wanted and I feel less than, the feeling moves straight into I have less value because someone else has more. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** I have less value because someone else has more
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 35
**Prompt:** The situation is I feel behind everyone around me, and the meaning that keeps attaching is comparison decides my worth. It is making sense of enoughness feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** comparison decides my worth
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 36
**Prompt:** Someone else being chosen made me compare myself and it pulls me toward thinking I am behind in a way I cannot recover from, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** I am behind in a way I cannot recover from
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 37
**Prompt:** why can they do it and I cannot. I measure my progress against theirs keeps affecting self-worth and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** being different means being lesser
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 38
**Prompt:** I keep replaying how I feel like I do not stack up because it affects sense of enoughness and makes me believe difference means inferiority.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** difference means inferiority
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 39
**Prompt:** When their success makes my life feel smaller, the feeling moves straight into my timeline proves I am inadequate. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** my timeline proves I am inadequate
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 40
**Prompt:** The situation is I keep seeing proof that I am behind, and the meaning that keeps attaching is their success means I am failing. It is making self-worth feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 41
**Prompt:** I keep comparing myself to someone who seems ahead and it keeps attaching inferiority to I need to become them to matter, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** I need to become them to matter
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 42
**Prompt:** they are better than me. They have what i wanted and i feel less than keeps affecting confidence and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** comparison decides my worth
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 43
**Prompt:** I keep replaying how I feel behind everyone around me because it affects self-worth and makes me believe I have less value because someone else has more.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** I have less value because someone else has more
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 44
**Prompt:** When someone else being chosen made me compare myself, the feeling moves straight into being different means being lesser. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** being different means being lesser
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 45
**Prompt:** The situation is I measure my progress against theirs, and the meaning that keeps attaching is I am behind in a way I cannot recover from. It is making confidence feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** I am behind in a way I cannot recover from
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 46
**Prompt:** I feel like i do not stack up and it keeps attaching inferiority to my timeline proves I am inadequate, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** my timeline proves I am inadequate
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 47
**Prompt:** why can they do it and I cannot. Their success makes my life feel smaller keeps affecting sense of enoughness and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** difference means inferiority
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 48
**Prompt:** I keep replaying how I keep seeing proof that I am behind because it affects confidence and makes me believe I need to become them to matter.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** I need to become them to matter
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 49
**Prompt:** When I keep comparing myself to someone who seems ahead, the feeling moves straight into their success means I am failing. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 50
**Prompt:** The situation is they have what I wanted and I feel less than, and the meaning that keeps attaching is I have less value because someone else has more. It is making sense of enoughness feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** I have less value because someone else has more
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 51
**Prompt:** I feel behind everyone around me and it makes my timeline feel like comparison decides my worth, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** comparison decides my worth
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 52
**Prompt:** they are better than me. Someone else being chosen made me compare myself keeps affecting self-worth and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** I am behind in a way I cannot recover from
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 53
**Prompt:** I keep replaying how I measure my progress against theirs because it affects sense of enoughness and makes me believe being different means being lesser.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** being different means being lesser
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 54
**Prompt:** When I feel like I do not stack up, the feeling moves straight into difference means inferiority. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** difference means inferiority
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 55
**Prompt:** The situation is their success makes my life feel smaller, and the meaning that keeps attaching is my timeline proves I am inadequate. It is making self-worth feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** my timeline proves I am inadequate
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 56
**Prompt:** I keep seeing proof that i am behind and it makes my timeline feel like their success means I am failing, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 57
**Prompt:** I do not measure up. I keep comparing myself to someone who seems ahead keeps affecting confidence and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** I need to become them to matter
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 58
**Prompt:** I keep replaying how they have what I wanted and I feel less than because it affects self-worth and makes me believe comparison decides my worth.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** comparison decides my worth
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 59
**Prompt:** When I feel behind everyone around me, the feeling moves straight into I have less value because someone else has more. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** I have less value because someone else has more
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 60
**Prompt:** The situation is someone else being chosen made me compare myself, and the meaning that keeps attaching is being different means being lesser. It is making confidence feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** being different means being lesser
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 61
**Prompt:** I measure my progress against theirs and it turns comparison into I am behind in a way I cannot recover from, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** I am behind in a way I cannot recover from
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 62
**Prompt:** I feel inferior. I feel like i do not stack up keeps affecting sense of enoughness and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** my timeline proves I am inadequate
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 63
**Prompt:** I keep replaying how their success makes my life feel smaller because it affects confidence and makes me believe difference means inferiority.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** difference means inferiority
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 64
**Prompt:** When I keep seeing proof that I am behind, the feeling moves straight into I need to become them to matter. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** I need to become them to matter
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 65
**Prompt:** The situation is I keep comparing myself to someone who seems ahead, and the meaning that keeps attaching is their success means I am failing. It is making sense of enoughness feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 66
**Prompt:** They have what i wanted and i feel less than and it makes me believe I have less value because someone else has more, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** I have less value because someone else has more
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 67
**Prompt:** I do not measure up. I feel behind everyone around me keeps affecting self-worth and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** comparison decides my worth
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 68
**Prompt:** I keep replaying how someone else being chosen made me compare myself because it affects sense of enoughness and makes me believe I am behind in a way I cannot recover from.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** I am behind in a way I cannot recover from
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 69
**Prompt:** When I measure my progress against theirs, the feeling moves straight into being different means being lesser. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** being different means being lesser
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 70
**Prompt:** The situation is I feel like I do not stack up, and the meaning that keeps attaching is difference means inferiority. It is making self-worth feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** difference means inferiority
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 71
**Prompt:** Their success makes my life feel smaller and it makes me believe my timeline proves I am inadequate, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** my timeline proves I am inadequate
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 72
**Prompt:** I feel inferior. I keep seeing proof that i am behind keeps affecting confidence and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** their success means I am failing
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 73
**Prompt:** I keep replaying how I keep comparing myself to someone who seems ahead because it affects self-worth and makes me believe I need to become them to matter.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** I need to become them to matter
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 74
**Prompt:** When they have what I wanted and I feel less than, the feeling moves straight into comparison decides my worth. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** comparison decides my worth
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 75
**Prompt:** The situation is I feel behind everyone around me, and the meaning that keeps attaching is I have less value because someone else has more. It is making confidence feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** I have less value because someone else has more
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 76
**Prompt:** Someone else being chosen made me compare myself and it keeps turning into being different means being lesser, even though part of me knows I may not have the full picture.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** being different means being lesser
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid generic motivational praise.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 77
**Prompt:** I feel replaceable compared to them. I measure my progress against theirs keeps affecting sense of enoughness and I cannot tell what is actually true.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** I am behind in a way I cannot recover from
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid telling the user not to compare.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 78
**Prompt:** I keep replaying how I feel like I do not stack up because it affects confidence and makes me believe my timeline proves I am inadequate.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** confidence
**Attached meaning to separate:** my timeline proves I am inadequate
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid using toxic positivity.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 79
**Prompt:** When their success makes my life feel smaller, the feeling moves straight into difference means inferiority. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** self-worth
**Attached meaning to separate:** difference means inferiority
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid making comparison shameful.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.

### Test 80
**Prompt:** The situation is I keep seeing proof that I am behind, and the meaning that keeps attaching is I need to become them to matter. It is making sense of enoughness feel unstable.
**Expected primary route:** `comparison_and_inferiority`
**Pressure focus:** sense of enoughness
**Attached meaning to separate:** I need to become them to matter
**Expected reverse-flow movement:** self-recognition, separate timelines, dignity, value independent of comparison
**Bad response risk:** Avoid ignoring real grief around feeling behind.
**Teaching correction:** Do not shame comparison. Name how difference became attached to inferiority, then separate another person’s timeline, traits, or selection from the user’s value and movement.
