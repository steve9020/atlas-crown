---
runtime_layer: relational_silence_clarification
priority: high
owned_by: atlas_relational_understanding
feeds_into:
  - route_assumption_check_runtime_overview
---

# Assumption Before Clarification Registry

## Purpose
Detects when the user turns missing information into a conclusion.

## Examples
- they did not respond, so I annoyed them
- they are quiet, so I did something wrong
- they pulled away, so I was too much
- they read it, so they must be rejecting me

## Rule
When the prompt shows missing context, Compass should clarify uncertainty before restoring self-worth or naming a conclusion as if it were established.
