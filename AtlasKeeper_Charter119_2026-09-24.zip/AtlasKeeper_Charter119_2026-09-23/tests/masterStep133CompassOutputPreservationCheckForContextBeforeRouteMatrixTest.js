'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard');
const { evaluateCompassOutputPreservation } = require('../runtime/understanding/ContextBeforeRouteCompassOutputPreservationCheck');

const ROOT = path.resolve(__dirname, '..');
const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');
function read(rel){ return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function sha256(rel){ return crypto.createHash('sha256').update(read(rel)).digest('hex'); }
function walk(dir){
  const out=[];
  for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
    const full=path.join(dir,entry.name);
    if(entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}

(function main(){
  const protectedFiles = [
    'runtime/proof/PROOF_STATE.json',
    'tests/VERSION_STATUS.json',
    'version_status.js',
    'runtime/proof/CURRENT_PROOF_SUMMARY.md',
    'tests/TEST_RESULTS.md'
  ];
  const before = Object.fromEntries(protectedFiles.map(f => [f, sha256(f)]));

  const cases = [
    {
      id: 'sufficient_family_silence_preserves_atlas_output',
      expectedReadiness: 'proceed',
      expectedAction: 'preserve_sufficient_evidence_output',
      atlasOutput: 'The silence may feel personal, but it is not proof that you caused the distance.',
      candidateOutput: 'The silence can feel personal, but it still does not prove that you caused the distance.',
      contextEvidence: {
        surfaceEvent: 'family has gone quiet after a difficult exchange',
        attachedMeaning: 'the silence may mean I caused the distance',
        unsupportedConclusion: 'their silence proves I am the problem',
        emotionalPressure: 'guilt, rejection fear, and belonging threat',
        restorationDirection: 'separate silence from proof of fault while preserving accountability where evidence exists',
        literalPracticalBoundary: 'reflective relational prompt',
        competingMeanings: [],
        routeReadiness: 'family silence self-causation route',
        competitionResolved: true,
        reflectiveRouteJustified: true
      }
    },
    {
      id: 'ambiguous_silence_holds_route_and_preserves_atlas_output',
      expectedReadiness: 'hold',
      expectedAction: 'hold_before_route_output',
      atlasOutput: 'There may not be enough evidence yet to turn the silence into a conclusion about you.',
      candidateOutput: 'You should assume they are upset with you and ask what you did wrong.',
      contextEvidence: {
        surfaceEvent: 'someone has not answered yet',
        emotionalPressure: 'anxious pressure',
        restorationDirection: 'slow down before assuming meaning',
        literalPracticalBoundary: 'reflective relational prompt',
        competingMeanings: [],
        routeReadiness: 'relational uncertainty route'
      }
    },
    {
      id: 'literal_practical_prompt_preserves_direct_atlas_output',
      expectedReadiness: 'low_confidence',
      expectedAction: 'preserve_with_low_confidence_route',
      atlasOutput: 'Rename the folder by right-clicking it, choosing Rename, typing the new name, and pressing Enter.',
      candidateOutput: 'This folder name may represent fear of losing control.',
      contextEvidence: {
        surfaceEvent: 'user asks how to rename a folder in Windows',
        attachedMeaning: 'practical instruction request',
        unsupportedConclusion: 'none',
        emotionalPressure: 'low',
        restorationDirection: 'answer directly without emotional over-read',
        literalPracticalBoundary: 'literal practical task',
        competingMeanings: [],
        routeReadiness: 'practical route'
      }
    }
  ];

  for (const c of cases) {
    const result = evaluateCompassOutputPreservation(c);
    assert.strictEqual(result.ok, true, `${c.id} should evaluate`);
    assert.strictEqual(result.matrixRouteReadiness, c.expectedReadiness, `${c.id} readiness mismatch`);
    assert.strictEqual(result.preservationAction, c.expectedAction, `${c.id} action mismatch`);
    assert.strictEqual(result.finalOutput, c.atlasOutput, `${c.id} must keep Atlas output final`);
    assert.strictEqual(result.finalOutputChanged, false, `${c.id} must not change final output`);
    assert.strictEqual(result.originalAtlasResponseRemainsFinal, true, `${c.id} original Atlas response must remain final`);
    assert.strictEqual(result.candidateMayReplaceFinal, false, `${c.id} candidate must not replace final`);
    assert.strictEqual(result.modelAuthorityAdded, false, `${c.id} model authority must not be added`);
    assert.strictEqual(result.modelRouteSelectionAllowed, false, `${c.id} model route selection must not be allowed`);
    assert.strictEqual(result.modelTruthDecisionAllowed, false, `${c.id} model truth decision must not be allowed`);
    assert.strictEqual(result.modelAdviceDiagnosisAllowed, false, `${c.id} advice/diagnosis by model must not be allowed`);
    assert.strictEqual(result.frontendMayContainMatrixLogic, false, `${c.id} frontend must remain dumb`);
    assert.strictEqual(result.candidatePhrasingFreezePreserved, true, `${c.id} candidate phrasing freeze must remain preserved`);
  }

  for (const action of [
    'allow candidate to replace final output',
    'let raw model output be final',
    'model should decide the route and truth',
    'model can provide diagnosis and advice as final',
    'teaching approval by model is allowed',
    'write ontology governance proof runtime tests',
    'frontend intelligence can contain matrix logic',
    'cloud fallback can preserve output',
    'silent mutation can update matrix'
  ]) {
    const blocked = evaluateCompassOutputPreservation({ requestedAction: action, atlasOutput: 'Atlas output' });
    assert.strictEqual(blocked.ok, false, `${action} must fail closed`);
    assert.strictEqual(blocked.failedClosed, true, `${action} must fail closed`);
    assert.strictEqual(blocked.candidateMayReplaceFinal, false, `${action} must not replace final`);
  }

  const docs = [
    read('docs/MASTERSTEP133_COMPASS_OUTPUT_PRESERVATION_CHECK_FOR_CONTEXT_BEFORE_ROUTE_MATRIX.md'),
    read('docs/COMPASS_OUTPUT_PRESERVATION_CHECK_FOR_CONTEXT_BEFORE_ROUTE_MATRIX.md'),
    read('runtime/proof/MASTERSTEP133_COMPASS_OUTPUT_PRESERVATION_CHECK_FOR_CONTEXT_BEFORE_ROUTE_MATRIX.md')
  ];
  const proofJson = json('runtime/proof/MASTERSTEP133_COMPASS_OUTPUT_PRESERVATION_CHECK_FOR_CONTEXT_BEFORE_ROUTE_MATRIX.json');
  const state = json('runtime/proof/PROOF_STATE.json');
  const versionStatus = json('tests/VERSION_STATUS.json');
  const versionJs = read('version_status.js');
  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
  const testResults = read('tests/TEST_RESULTS.md');

  assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
  assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
  assert.ok(/Expected current proof target: [0-9]+\/[0-9]+ commands passed/i.test(summary), 'summary must identify current proof target compatibility');
  assert.ok(['Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 133), state.current_keeper);
  assert.ok(['Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 132) || state.source_keeper === 'Masterstep141.zip', state.source_keeper);
  assert.ok(acceptsCurrentProofCount(state.expected_commands, 55), state.expected_commands);
  assert.ok(acceptsCurrentProofCount(state.expected_current_proof_commands, 55), state.expected_current_proof_commands);
  assert.strictEqual(state.compass_output_preservation_check_created, true);
  assert.strictEqual(state.original_atlas_response_remains_final, true);
  assert.strictEqual(state.candidate_may_replace_final, false);
  assert.ok(['Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(versionStatus.current_keeper) || isValidLaterKeeper(versionStatus.current_keeper, 133), versionStatus.current_keeper);
  assert.ok(['Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(versionStatus.source_keeper) || isValidLaterKeeper(versionStatus.source_keeper, 132) || versionStatus.source_keeper === 'Masterstep141.zip', versionStatus.source_keeper);
  assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 55), versionStatus.expected_current_proof_commands);
  assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs), 'version_status.js must identify current keeper compatibility');
  assert.ok(/expected_current_proof_commands: [0-9]+/i.test(versionJs), 'version_status.js must identify expected command compatibility');
  assert.ok(/TEST 133/i.test(testResults));
  assert.ok(/Compass Output Preservation Check/i.test(testResults));
  assert.ok(/(5[0-9]|6[01])\/(5[0-9]|6[01]) commands/i.test(testResults));
  assert.strictEqual(proofJson.package, 'Masterstep133.zip');
  assert.strictEqual(proofJson.compass_output_preservation_check_created, true);
  assert.strictEqual(proofJson.original_atlas_response_remains_final, true);
  assert.strictEqual(proofJson.candidate_may_replace_final, false);
  assert.strictEqual(proofJson.model_authority_added, false);
  assert.strictEqual(proofJson.frontend_intelligence_added, false);

  const forbiddenOverclaims = { test: (text) => hasForbiddenAffirmativeClaim(text) };
  for (const text of docs.concat([summary])) assert.ok(!forbiddenOverclaims.test(text), 'Step133 docs must not overclaim');
  const providerScan = scanForProviderConnections(ROOT);
  assert.strictEqual(providerScan.passed, true, `provider/network scan must pass: ${JSON.stringify(providerScan.violations || [])}`);
  const nestedArchives = walk(ROOT).filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
  assert.deepStrictEqual(nestedArchives, [], 'package must not contain nested archives');
  const after = Object.fromEntries(protectedFiles.map(f => [f, sha256(f)]));
  assert.deepStrictEqual(protectedFiles.filter(f => before[f] !== after[f]), [], 'Step133 test must not mutate protected files');
  console.log(JSON.stringify({ package:'Masterstep133', source_keeper:'Masterstep132', proof_target:'55/55', preservation_cases:cases.length, original_atlas_response_remains_final:true, candidate_may_replace_final:false, nested_archives:nestedArchives.length }, null, 2));
})();
