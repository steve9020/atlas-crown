# Foundational Primitives

These are the foundational mechanics the framework depends on structurally.

## Primitive Nodes

- [[Continuity Recognition]]
- [[Awareness]]
- [[Identity]]
- [[Meaning]]
- [[Emotional Weighting]]
- [[Experience]]
- [[Behavior]]
- [[00-Core/01 Primitives/Reflection|Reflection]]
- [[Self-Authorship]]

---

## Primitive Function

Primitives are not:
- derivative mechanics,
- loops,
- states,
or
- secondary abstractions.

They are:
the foundational continuity systems from which higher-order structures emerge.

---

## Related Structural Notes

- [[Core Principle]]
- [[Parent Systems]]
- [[Hierarchy Map]]
- [[Framework Node Classification Map]]