# Context Integrity Mapping Registry

Purpose: Master Step 4A source of truth for holding full context before meaning closure. This registry prevents isolated word interpretation, premature semantic closure, and artificial certainty before the outer structure of the user's input is mapped.

Boundary: this registry does not perform Semantic Fusion Separation, identity restoration, or final speech polishing. It only governs context-first mapping, meaning openness, revisability, and careful narrowing.

```json
{
  "version": "MASTER_STEP_4A_CONTEXT_INTEGRITY_MAPPING_V1",
  "minimumContextWordCount": 8,
  "guardrails": [
    "full_context_before_word_level_conclusion",
    "no_isolated_word_interpretation",
    "multiple_meanings_remain_open_until_context_narrows_them",
    "context_outranks_single_word_weighting",
    "meaning_narrows_progressively_not_instantly",
    "interpretations_remain_revisable",
    "new_context_may_reweight_prior_interpretation",
    "reduce_uncertainty_carefully_not_artificially"
  ],
  "rules": [
    {
      "id": "isolated_word_or_fragment_hold_open",
      "priority": 10,
      "phrases": [
        "attachment",
        "attached",
        "control",
        "controlling",
        "need",
        "needy",
        "failure",
        "worthless",
        "distance",
        "distant"
      ],
      "contextSignals": [
        "isolated_word_or_fragment",
        "outer_context_required_before_conclusion"
      ],
      "holdMeaningsOpen": [
        "clean_semantic_meaning",
        "relational_meaning",
        "emotional_meaning",
        "possible_negative_attachment"
      ],
      "closureBlocks": [
        "insufficient_context_for_word_level_conclusion",
        "single_word_weighting_cannot_close_meaning"
      ]
    },
    {
      "id": "multi_meaning_relational_language_hold_open",
      "priority": 20,
      "phrases": [
        "she is controlling",
        "he is controlling",
        "they are controlling",
        "she's controlling",
        "he's controlling",
        "they're controlling",
        "they have been distant",
        "acting different",
        "something is off"
      ],
      "contextSignals": [
        "multi_meaning_word_detected",
        "relational_context_needed"
      ],
      "holdMeaningsOpen": [
        "protective_or_fearful",
        "boundary_crossing",
        "anxious_or_overinvolved",
        "manipulative_or_restrictive",
        "unclear_shift_or_distance"
      ],
      "closureBlocks": [
        "relational_meaning_not_finalized",
        "future_context_may_reweight_interpretation"
      ]
    },
    {
      "id": "context_supported_narrowing_without_final_closure",
      "priority": 30,
      "allGroups": [
        {
          "phrases": [
            "checks my phone",
            "controls my phone",
            "tells me who i can talk to",
            "won't let me leave",
            "keeps me from seeing",
            "tracks where i go"
          ]
        },
        {
          "phrases": [
            "controlling",
            "control",
            "restrict",
            "restricted",
            "permission"
          ]
        }
      ],
      "contextSignals": [
        "outer_context_available",
        "meaning_can_be_narrowed_with_context"
      ],
      "holdMeaningsOpen": [
        "boundary_or_control_pressure"
      ],
      "narrowingSupport": [
        "specific_behavior_context_present",
        "word_function_supported_by_surrounding_context"
      ]
    },
    {
      "id": "emotional_certainty_hold_open",
      "priority": 40,
      "phrases": [
        "i know i ruined everything",
        "i know they do not care",
        "i know they don't care",
        "i know i am the problem",
        "i know i'm the problem"
      ],
      "contextSignals": [
        "emotional_certainty_language",
        "certainty_may_express_pain_not_verified_truth"
      ],
      "holdMeaningsOpen": [
        "pain_or_fear_signal",
        "unverified_conclusion",
        "possible_identity_pressure"
      ],
      "closureBlocks": [
        "certainty_wording_does_not_equal_final_truth",
        "emotional_intensity_cannot_close_reality_claim"
      ]
    },
    {
      "id": "progressive_context_reweighting",
      "priority": 50,
      "phrases": [
        "later i found out",
        "then she told me",
        "then he told me",
        "after that i learned",
        "new context",
        "turns out"
      ],
      "contextSignals": [
        "new_context_available",
        "prior_interpretation_may_reweight"
      ],
      "holdMeaningsOpen": [
        "prior_meaning_revisable",
        "new_context_may_change_route"
      ],
      "closureBlocks": [
        "prior_interpretation_not_permanent"
      ],
      "narrowingSupport": [
        "follow_up_context_present"
      ]
    }
  ]
}
```
