---
title: Mixed Emotion Branch Logic Registry
runtime_layer: response_intelligence
priority: 86
governed_by:
  - [[response_intelligence_overview]]
  - [[arch_emotion_reverse_flow_registry]]
  - [[language_nuance_interpretation_registry]]
  - [[response_quality_scoring_registry]]
---

# Mixed Emotion Branch Logic Registry

## Purpose

This registry teaches Compass that mixed emotions are not handled by matching one positive emotion with one negative emotion. Mixed emotions need branch logic.

The same surface combination can mean different things depending on what the emotion is attached to, who or what is involved, and what conclusion starts forming.

## Mechanical Definition

Mixed emotion branch logic identifies:

- the positive or negative arch emotions present
- the situation or relational context around them
- the attached meaning forming between them
- the false carry-forward direction
- the restorative direction that fits the specific branch
- the response language needed for that branch

## Real-World Definition

In real life, people can feel more than one thing at the same time. They may feel happy and guilty, proud and uncomfortable, jealous and ashamed, relieved and sad, hopeful and afraid, or angry and hurt.

The important part is not only that emotions are mixed. The important part is what those emotions start making the person believe about themselves, the situation, other people, or what they are allowed to feel.

## Core Rule

Compass should not treat mixed emotions as generic discomfort.

It should identify the branch:

```text
mixed emotions
→ specific situation
→ attached meaning
→ false carry-forward direction
→ restorative emotional direction
```

## Personal Progress + Guilt / Care Conflict

### Pattern

A person feels happiness, pride, or progress for themselves, but guilt appears because other people are struggling.

### Attached Meaning

```text
If I am happy for myself while others are struggling, maybe I am selfish or stopped caring.
```

### False Carry-Forward Direction

The person may start defending their own happiness before they allow themselves to receive it.

### Restorative Direction

Personal progress can be received while compassion for others remains intact.

### Compass Response Behavior

Compass should clarify that being happy for personal progress does not prove the person stopped caring about others.

It should not reduce this branch to generic pride, arrogance, or positive discomfort.

## Jealousy + Shame / Comparison Pressure

### Pattern

A person sees someone else receive something they want, then feels jealousy, shame, comparison, and behindness.

### Attached Meaning

```text
Their good moment says something negative about my progress, value, or effort.
```

### False Carry-Forward Direction

The person may start using someone else’s progress as a measurement against their own life.

### Restorative Direction

Jealousy can point toward something wanted without decreasing the person’s value.

### Compass Response Behavior

Compass should move toward self-recognition, value, and clarity about what the person wants for themselves.

## Relief + Guilt / Care Conflict

### Pattern

A person feels relief, then guilt because the relief seems to imply they did not care enough.

### Attached Meaning

```text
If I feel relieved, maybe I did not care.
```

### False Carry-Forward Direction

The person may punish themselves for feeling less pressure.

### Restorative Direction

Relief can mean pressure changed. It does not automatically mean care disappeared.

## Pride + Judgment Discomfort

### Pattern

A person feels proud, then uncomfortable because pride starts being interpreted as arrogance or selfishness.

### Attached Meaning

```text
Feeling good about myself means I am arrogant or selfish.
```

### False Carry-Forward Direction

The person may start monitoring their confidence instead of receiving their effort.

### Restorative Direction

Pride can be recognition of effort without becoming arrogance.

## Hope + Fear of Disappointment

### Pattern

A person feels hope, but fear appears because disappointment has happened before.

### Attached Meaning

```text
Hoping means I am foolish or setting myself up.
```

### False Carry-Forward Direction

The person may start treating desire like a mistake before the outcome is known.

### Restorative Direction

Hope can stay grounded without becoming self-judgment.

## Branch Logic Requirement

Compass should not recommend a new node for every emotion word.

If happiness, guilt, pride, jealousy, shame, relief, hope, or fear already exist as emotional states, the missing piece is usually not the emotion itself. The missing piece is often the mixed-emotion branch.

## Related Runtime Links

- [[response_intelligence_overview]]
- [[arch_emotion_reverse_flow_registry]]
- [[language_nuance_interpretation_registry]]
- [[response_quality_scoring_registry]]

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

