const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const proofState = JSON.parse(fs.readFileSync(path.join(root, 'runtime/proof/PROOF_STATE.json'), 'utf8'));
const active = JSON.parse(fs.readFileSync(path.join(root, 'runtime/workflow/ACTIVE_STEP.json'), 'utf8'));
assert.strictEqual(proofState.current_keeper, 'Masterstep42.zip');
assert.strictEqual(active.current_keeper, 'Masterstep42.zip');
assert.strictEqual(proofState.current_step, 'Masterstep42');
assert.strictEqual(active.current_step, 'Masterstep42');
assert.strictEqual(proofState.seven_layer_relational_routing_proof_added, true);
assert.strictEqual(proofState.false_positive_routing_guard_added, true);
assert.strictEqual(proofState.real_ai_connected, false);
assert.strictEqual(proofState.local_model_connected, false);
assert.strictEqual(proofState.network_bridge_added, false);
assert.strictEqual(proofState.frontend_intelligence_added, false);
for (const rel of ['runtime/routing/SevenLayerRelationalRoutingProof.js','runtime/routing/SevenLayerScenarioBank.js','runtime/routing/SevenLayerFalsePositiveGuard.js','runtime/proof/MASTERSTEP42_SEVEN_LAYER_RELATIONAL_ROUTING_PROOF.md']) {
  assert.ok(fs.existsSync(path.join(root, rel)), `missing ${rel}`);
}
console.log('masterStep42FullClosureKeeperReadinessTest PASSED');
