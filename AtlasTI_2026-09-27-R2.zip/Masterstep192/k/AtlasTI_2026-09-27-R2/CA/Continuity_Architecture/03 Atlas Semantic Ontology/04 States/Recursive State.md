# Recursive State

## Definition
A recursive state is the condition in which a system is actively processing feedback, self-reference, repeated patterns, or recursive interaction loops.

## Function
Recursive states can support adaptation when regulated, or destabilization when unresolved loops amplify contradiction, distortion, or escalation.

## Relationships
- [[Recursion]]
- [[Recursive Architecture]]
- [[Recursive Awareness]]
- [[Recursive Destabilization]]
- [[# Recursive Trajectory]]
