'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { evaluateProofStateCleanup } = require('../runtime/proof/ProofStateCleanupCompatibilityMarkerConsolidation');
const { evaluatePositiveStateMatrixMaturity } = require('../runtime/understanding/PositiveStateMatrixMaturity');

const ROOT = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function exists(rel){ return fs.existsSync(path.join(ROOT, rel)); }
function sha256(rel){ return crypto.createHash('sha256').update(read(rel)).digest('hex'); }

(function main(){
  const required = [
    'runtime/proof/ProofStateCleanupCompatibilityMarkerConsolidation.js',
    'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md',
    'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.json',
    'runtime/proof/MASTERSTEP148_PROOF_STATE_CLEANUP_COMPATIBILITY_MARKER_CONSOLIDATION.md',
    'runtime/proof/MASTERSTEP148_PROOF_STATE_CLEANUP_COMPATIBILITY_MARKER_CONSOLIDATION.json',
    'docs/MASTERSTEP148_PROOF_STATE_CLEANUP_COMPATIBILITY_MARKER_CONSOLIDATION.md',
    'docs/PROOF_STATE_CLEANUP_COMPATIBILITY_MARKER_CONSOLIDATION.md',
    'tests/masterStep148ProofStateCleanupCompatibilityMarkerConsolidationTest.js'
  ];
  for (const rel of required) assert.ok(exists(rel), `missing required file: ${rel}`);

  const protectedRuntime = [
    'runtime/understanding/PositiveStateMatrixMaturity.js',
    'runtime/understanding/TranslationPreservationMatrix.js',
    'runtime/understanding/MixedContextEvidenceSeparationMatrix.js',
    'runtime/understanding/ContextBeforeRouteEvidenceSufficiencyMatrix.js'
  ];
  const before = Object.fromEntries(protectedRuntime.map(rel => [rel, sha256(rel)]));

  const cleanup = evaluateProofStateCleanup();
  const currentVersion = json('tests/VERSION_STATUS.json');
  assert.strictEqual(cleanup.ok || currentVersion.shared_semantic_multi_domain_migration_created, true, 'proof-state cleanup evaluation or explicitly proved later semantic migration should pass');
  assert.ok(require('../runtime/proof/ProofCompatibilityHelper').isValidLaterKeeper(cleanup.currentKeeper, 148), cleanup.currentKeeper);
  assert.ok(require('../runtime/proof/ProofCompatibilityHelper').isValidLaterKeeper(cleanup.sourceKeeper, 147), cleanup.sourceKeeper);
  assert.ok(require('../runtime/proof/ProofCompatibilityHelper').acceptsCurrentProofCount(cleanup.expectedCommands, 70), cleanup.expectedCommands);
  assert.strictEqual(cleanup.proofCleanupOnly, true);
  assert.deepStrictEqual(cleanup.duplicateVersionStatusKeys, [], 'version_status.js should not contain duplicate object keys');
  assert.strictEqual(cleanup.runtimeBehaviorChanged, false);
  assert.strictEqual(cleanup.compassOutputChanged, false);
  assert.strictEqual(cleanup.matrixCapabilityAdded, false);

  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md');
  assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary));
  assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary));
  assert.ok(/Expected current proof target: [0-9]+\/[0-9]+ commands passed/i.test(summary) || /Expected proof commands:\s*[0-9]+/i.test(summary));
  assert.strictEqual((summary.match(/^# Current Proof Summary$/gm) || []).length, 1, 'current summary should contain one active heading');
  assert.ok(!summary.includes('the active keeper remains Masterstep145.zip'), 'current summary should not carry contradictory legacy-active wording');

  const markers = read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md');
  for (const marker of ['Masterstep135','Mixed-Context Evidence Separation','Translation Preservation Matrix','Positive-State Matrix Maturity','CROSS_WINDOW_PROOF_CONTINUITY_LEDGER']) {
    assert.ok(markers.includes(marker) || summary.includes(marker), `historical marker preserved: ${marker}`);
  }

  const markerJson = json('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.json');
  assert.strictEqual(markerJson.compatibility_scope, 'proof-recognition only; no runtime or Compass output behavior authority');

  const versionSource = read('version_status.js');
  const keyMatches = Array.from(versionSource.matchAll(/^\s*([A-Za-z0-9_]+)\s*:/gm)).map(m => m[1]);
  assert.strictEqual(keyMatches.length, new Set(keyMatches).size, 'version_status.js should not have duplicate keys');

  const proofState = json('runtime/proof/PROOF_STATE.json');
  assert.ok(require('../runtime/proof/ProofCompatibilityHelper').isValidLaterKeeper(proofState.current_keeper, 148), proofState.current_keeper);
  assert.ok(require('../runtime/proof/ProofCompatibilityHelper').acceptsCurrentProofCount(proofState.expected_commands, 70), proofState.expected_commands);
  assert.strictEqual(proofState.runtime_behavior_changed, currentVersion.shared_semantic_multi_domain_migration_created ? true : false);
  assert.strictEqual(proofState.compass_output_logic_changed, currentVersion.shared_semantic_multi_domain_migration_created ? true : false);
  assert.strictEqual(proofState.matrix_capability_added, currentVersion.shared_semantic_multi_domain_migration_created ? true : false);

  const positive = evaluatePositiveStateMatrixMaturity();
  assert.strictEqual(positive.ok, true, 'positive-state matrix maturity remains intact');

  for (const rel of protectedRuntime) {
    assert.strictEqual(sha256(rel), before[rel], `runtime implementation should remain unchanged: ${rel}`);
  }

  console.log('Masterstep148 proof-state cleanup compatibility marker consolidation passed');
})();
