# Shame Loop

## Structural Flow

Rejection, failure, humiliation, criticism, betrayal, or conditional acceptance
→ create emotional pain tied to [[Identity]]

Pain internalized into identity
→ forms [[Shame]]

[[Shame]]
→ convinces the individual:
- they are inadequate
- unworthy
- flawed
- unacceptable

This distorted identity perception
→ increases:
- fear
- emotional hiding
- social masking
- validation seeking
- self-preservation behaviors

Protective behaviors
→ weaken [[Authenticity|Authenticity]] and [[Vulnerability|Vulnerability]]

Reduced authenticity
→ prevents truthful connection and emotional recognition

Lack of truthful recognition
→ reinforces loneliness, insecurity, and unstable self-worth

These conditions
→ deepen shame further

The loop compounds automatically over time.

---

## Distortion Pathway

The Shame Loop intensifies through:
- secrecy
- suppression
- avoidance
- comparison
- emotional isolation
- unresolved guilt
- external validation dependency

Over time:
identity continuity increasingly organizes around inadequacy.

---

## What the Shame Loop Produces
- insecurity
- addiction
- emotional withdrawal
- people pleasing
- narcissistic compensation
- fear of exposure
- fragmented identity
- unstable relationships

---

## Interruption Pathway

The loop can be interrupted through:
- [[Awareness]]
- vulnerability
- truthful acceptance
- emotional safety
- self-worth stabilization
- integrity
- authentic connection
- healing

---

## What Healthy Processing Does
Healthy processing separates:
- the self
from
- the wound,
- mistake,
- rejection,
or
- emotional injury.

---

## Connected Nodes
- [[Shame]]
- [[Identity]]
- [[Fear]]
- [[Self-Worth]]
- [[Authenticity|Authenticity]]
- [[Validation Dependency]]
- [[Healing]]
- [[Vulnerability|Vulnerability]]

---

## Core Principle

Shame compounds when perceived inadequacy fuses into identity continuity without truthful separation, healing, or self-worth stabilization.