---
title: Performance Conditioned Worth
runtime_layer: meaning_separation
priority: high
status: active
phase: runtime_link_cleanup
governed_by:
  - truth_separation_governance
  - governance_enforcement_registry
outputs:
  - Worth Contingency Distortion
  - worth_continuity_return
---

# Performance Conditioned Worth

## Purpose

Defines the distortion where worth becomes tied to performance, achievement, output, usefulness, or being seen as successful.

## Core Function

The runtime should separate recognition, achievement, or failure from the conclusion that the user’s value rises or falls with performance.

## Runtime Boundary

This node exists because existing backend links already reference this concept. It should clarify the referenced pathway without creating duplicate ontology or changing Compass into a clinical, diagnostic, authoritative, or productivity-driven system.

## Related Runtime Links

- [[Worth Contingency Distortion]]
- [[worth_continuity_return]]
- [[truth_separation_governance]]
- [[response_behavior_registry]]
