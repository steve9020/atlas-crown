# Interpret Structure Governance Pipeline

## Purpose
`interpretStructure()` must be the runtime bridge, not just a UI submit handler.

## Required Calls
- interpret emotional content
- build governed runtime profile
- select governed response definition
- construct governed response
- finalize through governance/context/realism calibration
- return governed metadata

## Failure Prevented
Generic fallback responses cannot bypass governance when stronger scenario or relational routes exist.
