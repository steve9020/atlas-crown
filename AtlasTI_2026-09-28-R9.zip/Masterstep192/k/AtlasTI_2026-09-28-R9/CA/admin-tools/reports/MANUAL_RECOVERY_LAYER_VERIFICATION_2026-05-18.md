# Manual Recovery Layer Verification — 2026-05-18

## Added Layer

External manual recovery layer added under:

```txt
admin-tools/recovery/
```

## Added Files

```txt
admin-tools/recovery/manual-recovery-manager.js
admin-tools/recovery/README_MANUAL_RECOVERY_MANAGER.md
admin-tools/recovery/snapshots/
admin-tools/recovery/quarantine/
admin-tools/recovery/reports/
```

## Boundary Rules

```txt
manual only
external admin tool only
Obsidian must be closed
not callable by main.js
not callable by Atlas
not automatic
quarantine before restore
hash-verify after restore
```

## Supported Commands

```cmd
node manual-recovery-manager.js --snapshot <path_to_Continuity_Architecture> [label]
node manual-recovery-manager.js --verify-snapshot <path_to_snapshot_folder>
node manual-recovery-manager.js --dry-run-restore <path_to_snapshot_folder> <path_to_Continuity_Architecture>
node manual-recovery-manager.js --restore <path_to_snapshot_folder> <path_to_Continuity_Architecture> "<Developer Signature>"
```

## Verification Results

```txt
manual-recovery-manager.js syntax check: passed
staging-chain-manager.js syntax check: passed
admin-tools ledger verify: passed, 0 blocks verified
manual recovery help command: passed
manual snapshot creation on sandbox copy: passed
manual snapshot verification on sandbox copy: passed
manual dry-run restore on sandbox copy: passed
main.js recovery references: 0
main.js admin-tools recovery calls: 0
main.js direct native file writes: 0
main.js direct vault mutation calls: 0
main.js shell execution: 0
main.js background timer routes: 0
metadataCache runtime watcher added: 0
```

## Important Note

This layer increases Steven's manual recovery capability without increasing Atlas/plugin authority.

The plugin runtime does not call recovery. Recovery remains a human-only, out-of-band safety tool.
