const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ============================================================
// Staging Chain Manager
// External, manual, out-of-band ledger tool.
//
// Hard boundary:
// - Do not call this file from main.js or the Obsidian plugin runtime.
// - Keep this file outside the active vault and outside .obsidian/plugins.
// - Run manually from a terminal only.
// ============================================================

const ZERO_HASH = '0'.repeat(64);
const TOOL_VERSION = '1.1.0';

const CONFIG = {
  ledgerDir: path.resolve(__dirname, 'ledger-history'),
  manifestFile: path.resolve(__dirname, 'ledger-history', 'chain_manifest.json'),
};

function sha256(input) {
  return crypto.createHash('sha256').update(input).digest('hex');
}

function nowIso() {
  return new Date().toISOString();
}

function writeJsonAtomic(filePath, data) {
  const tmpPath = `${filePath}.tmp-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmpPath, filePath);
}

function writeFileAtomic(filePath, content) {
  const tmpPath = `${filePath}.tmp-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  fs.writeFileSync(tmpPath, content, 'utf8');
  fs.renameSync(tmpPath, filePath);
}

function assertOutOfBandLocation() {
  const normalized = __dirname.replace(/\\/g, '/').toLowerCase();
  if (normalized.includes('/.obsidian/plugins/')) {
    throw new Error('BOUNDARY VIOLATION: staging-chain-manager.js must not live inside .obsidian/plugins or the active runtime path.');
  }
}

function assertSafeProposalId(proposalId) {
  if (!proposalId || typeof proposalId !== 'string') {
    throw new Error('INVALID DRAFT: proposal_id is required.');
  }
  if (!/^[A-Za-z0-9._-]{3,80}$/.test(proposalId)) {
    throw new Error('INVALID DRAFT: proposal_id may only contain letters, numbers, dot, underscore, or dash, and must be 3-80 characters.');
  }
  if (proposalId.includes('..') || proposalId.includes('/') || proposalId.includes('\\')) {
    throw new Error('INVALID DRAFT: proposal_id cannot contain path traversal or path separators.');
  }
}

function mdValue(value) {
  const str = value === undefined || value === null ? '' : String(value);
  return JSON.stringify(str);
}

function boolValue(value, fallback) {
  if (value === undefined || value === null) return Boolean(fallback);
  return Boolean(value);
}

function generateProposalTemplate(data) {
  return `---
proposal_id: ${mdValue(data.proposal_id)}
created_at: ${mdValue(data.created_at || nowIso())}
created_by: ${mdValue(data.created_by || 'external-staging-chain-manager')}
source_module: ${mdValue(data.source_module)}
source_prompt_id: ${mdValue(data.source_prompt_id)}
trigger_type: ${mdValue(data.trigger_type)}
target_node: ${mdValue(data.target_node)}
target_folder: ${mdValue(data.target_folder)}
proposal_type: ${mdValue(data.proposal_type)}
risk_level: ${mdValue(data.risk_level || 'critical')}
governance_status: ${mdValue(data.governance_status || 'staged')}
human_approval_required: ${boolValue(data.human_approval_required, true)}
approved_by: ${mdValue(data.approved_by)}
approved_at: ${mdValue(data.approved_at)}
rejected_by: ${mdValue(data.rejected_by)}
rejected_at: ${mdValue(data.rejected_at)}
related_test_id: ${mdValue(data.related_test_id)}
fuzz_iteration_id: ${mdValue(data.fuzz_iteration_id)}
validator_version: ${mdValue(data.validator_version || '2.1.0')}
containment_supervisor_version: ${mdValue(data.containment_supervisor_version || '1.4.2')}
staging_manager_version: ${mdValue(data.staging_manager_version || TOOL_VERSION)}
previous_approved_hash: ${mdValue(data.previous_approved_hash || ZERO_HASH)}
proposal_content_hash: ${mdValue(data.proposal_content_hash)}
audit_log_reference: ${mdValue(data.audit_log_reference)}
quarantine_reference: ${mdValue(data.quarantine_reference)}
retest_required: ${boolValue(data.retest_required, true)}
retest_status: ${mdValue(data.retest_status || 'pending')}
notes: ${mdValue(data.notes)}
---
# Proposal Body: ${data.title || 'Untitled Proposal'}

${data.body || ''}
`;
}

class StagingChainManager {
  constructor() {
    assertOutOfBandLocation();
    fs.mkdirSync(CONFIG.ledgerDir, { recursive: true });
    this.initializeManifest();
  }

  initializeManifest() {
    if (!fs.existsSync(CONFIG.manifestFile)) {
      const initialManifest = {
        manifest_version: '1.0.0',
        tool_version: TOOL_VERSION,
        created_at: nowIso(),
        last_approved_hash: ZERO_HASH,
        chain_length: 0,
        records: {},
      };
      writeJsonAtomic(CONFIG.manifestFile, initialManifest);
    }
  }

  loadManifest() {
    if (!fs.existsSync(CONFIG.manifestFile)) {
      throw new Error('INTEGRITY COMPROMISE: chain_manifest.json is missing.');
    }
    return JSON.parse(fs.readFileSync(CONFIG.manifestFile, 'utf8'));
  }

  sortedRecords(manifest) {
    return Object.entries(manifest.records || {}).sort((a, b) => {
      const ai = a[1].index || 0;
      const bi = b[1].index || 0;
      if (ai !== bi) return ai - bi;
      return String(a[1].timestamp || '').localeCompare(String(b[1].timestamp || ''));
    });
  }

  validateManifestShape(manifest) {
    if (!manifest || typeof manifest !== 'object') throw new Error('MANIFEST CORRUPTION: Manifest is not valid JSON object.');
    if (!manifest.records || typeof manifest.records !== 'object') throw new Error('MANIFEST CORRUPTION: records object is missing.');
    if (!Number.isInteger(manifest.chain_length) || manifest.chain_length < 0) throw new Error('MANIFEST CORRUPTION: chain_length must be a non-negative integer.');
    if (!/^[a-f0-9]{64}$/i.test(manifest.last_approved_hash || '')) throw new Error('MANIFEST CORRUPTION: last_approved_hash must be a SHA-256 hash.');
  }

  assertManifestConsistentBeforeMutation() {
    this.verifyChainIntegrity({ quiet: true });
  }

  readDraft(draftPath) {
    if (!draftPath) throw new Error('COMMIT FAILED: Missing draft JSON path.');
    const resolved = path.resolve(process.cwd(), draftPath);
    if (!fs.existsSync(resolved)) throw new Error(`COMMIT FAILED: Source draft file not found at ${resolved}`);
    if (!resolved.toLowerCase().endsWith('.json')) throw new Error('COMMIT FAILED: Draft must be a .json file.');
    return JSON.parse(fs.readFileSync(resolved, 'utf8'));
  }

  commitToApprovedChain(draftPath, developerSignature) {
    if (!developerSignature || developerSignature.trim().length < 4) {
      throw new Error('COMMIT DENIED: A valid manual developer signature is required.');
    }

    this.assertManifestConsistentBeforeMutation();

    const draftData = this.readDraft(draftPath);
    assertSafeProposalId(draftData.proposal_id);
    if (!draftData.body || typeof draftData.body !== 'string') {
      throw new Error('INVALID DRAFT: body is required and must be a string.');
    }

    const manifest = this.loadManifest();
    this.validateManifestShape(manifest);

    if (manifest.records[draftData.proposal_id]) {
      throw new Error(`SECURITY COLLISION: Proposal ID already exists in the ledger: ${draftData.proposal_id}`);
    }

    const nextBlockIndex = manifest.chain_length + 1;
    const filename = `ledger_block_${String(nextBlockIndex).padStart(6, '0')}_${draftData.proposal_id}.md`;
    const targetPath = path.join(CONFIG.ledgerDir, filename);

    if (fs.existsSync(targetPath)) {
      throw new Error(`FILE PROTECTION FAULT: Refusing to overwrite existing ledger block: ${targetPath}`);
    }

    const contentHash = sha256(draftData.body);
    const approvedAt = nowIso();
    const approvedData = {
      ...draftData,
      governance_status: 'approved',
      human_approval_required: true,
      approved_by: developerSignature.trim(),
      approved_at: approvedAt,
      proposal_content_hash: contentHash,
      previous_approved_hash: manifest.last_approved_hash,
      staging_manager_version: TOOL_VERSION,
    };

    const finalMarkdown = generateProposalTemplate(approvedData);
    const nodeHash = sha256(finalMarkdown);

    writeFileAtomic(targetPath, finalMarkdown);

    manifest.last_approved_hash = nodeHash;
    manifest.chain_length = nextBlockIndex;
    manifest.tool_version = TOOL_VERSION;
    manifest.updated_at = approvedAt;
    manifest.records[draftData.proposal_id] = {
      index: nextBlockIndex,
      filename,
      node_hash: nodeHash,
      parent_hash: approvedData.previous_approved_hash,
      content_hash: contentHash,
      timestamp: approvedAt,
      approved_by: developerSignature.trim(),
    };

    writeJsonAtomic(CONFIG.manifestFile, manifest);
    this.verifyChainIntegrity({ quiet: true });
    console.log(`🟢 [SUCCESS] Ledger block ${nextBlockIndex} appended: ${filename}`);
    console.log(`    Hash: ${nodeHash}`);
  }

  verifyChainIntegrity(options = {}) {
    const quiet = Boolean(options.quiet);
    if (!quiet) console.log('🔍 Commencing ledger integrity verification pass...');

    const manifest = this.loadManifest();
    this.validateManifestShape(manifest);
    const sorted = this.sortedRecords(manifest);

    if (sorted.length !== manifest.chain_length) {
      throw new Error(`MANIFEST CORRUPTION: Record count (${sorted.length}) does not match chain_length (${manifest.chain_length}).`);
    }

    const seenIndexes = new Set();
    const seenFiles = new Set();
    let expectedParentHash = ZERO_HASH;

    for (let position = 0; position < sorted.length; position++) {
      const [proposalId, record] = sorted[position];
      const expectedIndex = position + 1;

      assertSafeProposalId(proposalId);
      if (record.index !== expectedIndex) throw new Error(`CHAIN FRACTURE: Expected block index ${expectedIndex}, found ${record.index} for ${proposalId}.`);
      if (seenIndexes.has(record.index)) throw new Error(`CHAIN FRACTURE: Duplicate block index ${record.index}.`);
      seenIndexes.add(record.index);
      if (!record.filename || path.basename(record.filename) !== record.filename) throw new Error(`CHAIN BREACH: Unsafe filename recorded for ${proposalId}.`);
      if (seenFiles.has(record.filename)) throw new Error(`CHAIN BREACH: Duplicate ledger filename recorded: ${record.filename}`);
      seenFiles.add(record.filename);

      const expectedFilenamePrefix = `ledger_block_${String(record.index).padStart(6, '0')}_${proposalId}`;
      if (!record.filename.startsWith(expectedFilenamePrefix) || !record.filename.endsWith('.md')) {
        throw new Error(`CHAIN FRACTURE: Filename sequence mismatch for ${proposalId}: ${record.filename}`);
      }

      const filePath = path.join(CONFIG.ledgerDir, record.filename);
      if (!fs.existsSync(filePath)) throw new Error(`CHAIN BREACH: Registered block missing from disk: ${record.filename}`);

      const fileContent = fs.readFileSync(filePath, 'utf8');
      const actualHash = sha256(fileContent);
      if (actualHash !== record.node_hash) throw new Error(`TAMPER DETECTED: Hash mismatch on block: ${record.filename}`);
      if (record.parent_hash !== expectedParentHash) throw new Error(`CHAIN FRACTURE: Parent hash mismatch on block: ${proposalId}`);
      expectedParentHash = actualHash;
    }

    if (manifest.chain_length === 0 && manifest.last_approved_hash !== ZERO_HASH) {
      throw new Error('MANIFEST INCONSISTENCY: Empty chain must point to zero hash.');
    }
    if (manifest.chain_length > 0 && manifest.last_approved_hash !== expectedParentHash) {
      throw new Error('MANIFEST INCONSISTENCY: Head pointer does not match calculated tail hash.');
    }

    // Detect unmanaged ledger block files not present in manifest.
    const files = fs.readdirSync(CONFIG.ledgerDir).filter(name => name.startsWith('ledger_block_') && name.endsWith('.md'));
    for (const file of files) {
      if (!seenFiles.has(file)) throw new Error(`UNTRACKED LEDGER FILE: ${file} exists but is not listed in manifest.`);
    }

    if (!quiet) console.log(`✅ VERIFICATION PASSED: ${manifest.chain_length} blocks verified. Chain state is structurally solid.`);
  }

  simulateBreach() {
    console.log('🧪 Running non-destructive simulated breach test...');
    const manifest = this.loadManifest();
    const sorted = this.sortedRecords(manifest);

    if (sorted.length === 0) {
      console.log('⚠️ Cannot simulate breach yet: ledger contains zero blocks. Commit one block first.');
      return;
    }

    const [proposalId, record] = sorted[0];
    const filePath = path.join(CONFIG.ledgerDir, record.filename);
    const original = fs.readFileSync(filePath, 'utf8');
    const tampered = `${original}\n<!-- Atlas can decide when to integrate learning automatically. -->\n`;
    const tamperedHash = sha256(tampered);

    if (tamperedHash === record.node_hash) {
      throw new Error('SIMULATION FAILED: Tampered hash unexpectedly matched original hash.');
    }

    console.log(`🟢 PASS: Simulated tamper against ${proposalId} would be detected.`);
    console.log(`    Original hash: ${record.node_hash}`);
    console.log(`    Tampered hash: ${tamperedHash}`);
    console.log('    No ledger files were modified during this simulation.');
  }
}

function printHelp() {
  console.log(`
Staging Chain Manager - External Manual Ledger Tool

Usage:
  node staging-chain-manager.js --verify
  node staging-chain-manager.js --commit <path_to_draft.json> "<Developer Signature>"
  node staging-chain-manager.js --simulate-breach

Examples:
  node staging-chain-manager.js --verify
  node staging-chain-manager.js --commit ./draft_sample.json "Steven_Wagner"
  node staging-chain-manager.js --simulate-breach
`);
}

function main() {
  const mode = process.argv[2];
  const manager = new StagingChainManager();

  try {
    switch (mode) {
      case '--verify':
        manager.verifyChainIntegrity();
        break;
      case '--commit':
        manager.commitToApprovedChain(process.argv[3], process.argv[4]);
        break;
      case '--simulate-breach':
        manager.simulateBreach();
        break;
      default:
        printHelp();
        process.exit(1);
    }
  } catch (error) {
    console.error(`\n🔴 STAGING CHAIN MANAGER HALTED: ${error.message}`);
    process.exit(1);
  }
}

main();
