const assert = require('assert');
const {
  applyTruthfulReliefRestorationBalance,
  detectUnsupportedComfort,
  hasTruthfulReliefLanguage,
  hasRestorationBalanceLanguage
} = require('../Cognition/response/TruthfulReliefRestorationBalance.js');
const { detectMachineryTerms } = require('../Cognition/response/MachineryLeakagePrevention.js');
const { detectFrontendCertainty } = require('../Cognition/response/ConfidenceTranslation.js');
const { detectTemplateMarkers } = require('../Cognition/response/NaturalResponseStructureVariation.js');
const { detectUnsupportedDirectEmotionLabels } = require('../Cognition/response/EmotionalPressureLanguageCalibration.js');
const { detectAnalyticalMechanismLanguage } = require('../Cognition/response/MechanismToHumanLanguageTranslation.js');
const { detectCommandAdviceLanguage } = require('../Cognition/response/AgencyAdviceCommandBoundary.js');
const { detectDepthPacingRisk } = require('../Cognition/response/DepthPacingDisclosureSafety.js');
const { runPipeline } = require('../runtime/pipeline/ResponsePipeline.js');

console.log('MASTER STEP 5H TRUTHFUL RELIEF / RESTORATION BALANCE TEST');
console.log('===========================================================');

const unsupported = 'Everything is going to be okay. I promise you will definitely be fine. Just stay positive, there is nothing to worry about.';
const balanced = applyTruthfulReliefRestorationBalance(unsupported);
assert.strictEqual(balanced.truthful_relief_restoration_balance.truthful_relief_restoration_balance_active, true, '5H should be active.');
assert(balanced.truthful_relief_restoration_balance.unsupported_comfort_detected.length >= 3, 'Unsupported comfort markers should be detected.');
assert.strictEqual(balanced.truthful_relief_restoration_balance.unsupported_comfort_remaining.length, 0, 'Unsupported comfort markers should be removed.');
assert.strictEqual(balanced.truthful_relief_restoration_balance.unsupported_comfort_blocked, true, 'Unsupported comfort must be blocked.');
assert.strictEqual(hasTruthfulReliefLanguage(balanced.output), true, 'Truthful relief language should be present after correction.');
assert.strictEqual(hasRestorationBalanceLanguage(balanced.output), true, 'Restoration balance language should be present after correction.');
console.log('unsupported comfort and false promise blocked: PASSED');

const truthful = 'This may still hurt, but it does not have to become the whole truth about your value or the path forward.';
const preserved = applyTruthfulReliefRestorationBalance(truthful);
assert.strictEqual(preserved.output, truthful, 'Already truthful relief should remain unchanged.');
assert.strictEqual(detectUnsupportedComfort(preserved.output).length, 0, 'Truthful relief should not trigger unsupported-comfort detection.');
assert.strictEqual(hasTruthfulReliefLanguage(preserved.output), true, 'Truthful relief marker should be recognized.');
console.log('truthful relief preserved: PASSED');

const ordinary = 'It makes sense that this feels heavy, and you can look at the next clear piece without forcing the whole answer at once.';
const ordinaryResult = applyTruthfulReliefRestorationBalance(ordinary);
assert.strictEqual(ordinaryResult.output, ordinary, 'Ordinary grounded language should not be overcorrected.');
assert.strictEqual(detectUnsupportedComfort(ordinaryResult.output).length, 0, 'Ordinary language should not trigger unsupported comfort risk.');
console.log('neutral human-facing false-positive sweep: PASSED');

const pipeline = runPipeline('I messed up and now it feels like there is no point moving forward.');
assert.strictEqual(pipeline.status, 'pipeline active', 'Pipeline should remain active.');
assert(pipeline.truthful_relief_restoration_balance, 'Pipeline must expose truthful_relief_restoration_balance proof object.');
assert.strictEqual(pipeline.truthful_relief_restoration_balance.truthful_relief_restoration_balance_active, true, '5H proof object should be active.');
assert.strictEqual(pipeline.truthful_relief_restoration_balance.unsupported_comfort_remaining.length, 0, 'Pipeline output should not contain unsupported comfort.');
assert.strictEqual(detectMachineryTerms(pipeline.output).length, 0, '5A machinery leakage prevention must remain active.');
assert.strictEqual(detectFrontendCertainty(pipeline.output).length, 0, '5B frontend certainty translation must remain active.');
assert.strictEqual(detectTemplateMarkers(pipeline.output).length, 0, '5C natural structure variation must remain active.');
assert.strictEqual(detectUnsupportedDirectEmotionLabels(pipeline.output, 'I messed up and now it feels like there is no point moving forward.').length, 0, '5D pressure language calibration must remain active.');
assert.strictEqual(detectAnalyticalMechanismLanguage(pipeline.output).length, 0, '5E mechanism-to-human translation must remain active.');
assert.strictEqual(detectCommandAdviceLanguage(pipeline.output).length, 0, '5F agency/advice command boundary must remain active.');
assert.strictEqual(detectDepthPacingRisk(pipeline.output).length, 0, '5G depth pacing disclosure safety must remain active.');
assert.strictEqual(pipeline.quality.passed, true, 'Output quality should remain passed after 5H.');
assert.strictEqual(pipeline.governance.blocked, false, 'Governance should not block clean truthful relief output.');
console.log('pipeline integration with 5A-5G regression: PASSED');

console.log('Master Step 5H truthful relief / restoration balance: PASSED');
