
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const projectRoot = path.resolve(__dirname, '..');
const pluginRoot = path.join(projectRoot, 'CA', 'Continuity_Architecture', '.obsidian', 'plugins', 'continuity-interface');
const mainText = fs.readFileSync(path.join(pluginRoot, 'main.js'), 'utf8');
const cssText = fs.readFileSync(path.join(pluginRoot, 'styles.css'), 'utf8');

// UI shell must be present and styled.
for (const required of [
  'compass-page', 'compass-shell', 'crown-title', 'main-compass', 'input-card',
  'compass-input', 'interpret-button', 'compass-output', 'compass-mini-icon',
  'width: 104px', 'height: 104px', 'width: 30px', 'height: 30px'
]) {
  assert.ok(mainText.includes(required), `frontend UI shell style missing: ${required}`);
}

// Frontend must still call backend, not interpret.
assert.ok(mainText.includes('FrontendCalloutService.js'), 'frontend must call backend callout service');
assert.ok(mainText.includes('runCompassCallout'), 'frontend must call backend runCompassCallout');

// Stylesheet must not carry old governance/review/intelligence-aware UI residue.
for (const forbidden of [
  'atlas-auto-teaching', 'Governance Review', 'Mutation Status', 'Risk Classification',
  'DoyleLayer', 'SemanticAttachment', 'CompassResponseBuilderIntegration', 'TeachingCenter'
]) {
  assert.ok(!cssText.includes(forbidden), `frontend stylesheet contains forbidden residue: ${forbidden}`);
}

// Frontend JS must not carry intelligence implementation markers.
for (const forbidden of [
  'DoyleLayer', 'SemanticAttachment', 'ActiveAttachment', 'scoreRoute', 'detectSignals',
  'detectAxes', 'CompassResponseBuilderIntegration', 'GoldenCompassLanguageWeaver',
  'TeachingCenterLearningProposalFlow', 'AIProposalQuarantine', 'AIAssistanceBoundary',
  'ResponseQualityChecker'
]) {
  assert.ok(!mainText.includes(forbidden), `frontend main contains intelligence marker: ${forbidden}`);
}
console.log('masterStep53FrontendUIShellRestorationTest PASSED');
