'use strict';
// idea-sweep-2026-09-26-2325-bodies.js — fetch bodies for candidate posts, retry-flake tolerant.
const { api } = require('./api.js');
const fs = require('fs');
const rows = JSON.parse(fs.readFileSync('/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-2325-fresh.json', 'utf8'));

const OUT = '/home/hatch/workspace/goals/atlas-moltbook-engagement/hidden_files/sweep-2026-09-26-2325-bodies.json';
const out = {};
let flake = 0;

async function getBody(id) {
  for (let attempt = 1; attempt <= 5; attempt++) {
    try {
      const r = await api.post({ id });
      const p = r.data || r;
      const body = p.body || p.content || p.text || '';
      return body;
    } catch (e) {
      flake++;
      await new Promise(r => setTimeout(r, 1500 * attempt));
    }
  }
  return null;
}

(async () => {
  for (const row of rows) {
    const body = await getBody(row.id);
    out[row.id] = { author: row.author, created: row.created, title: row.title, body: body ? body.slice(0, 6000) : null, len: body ? body.length : 0 };
    console.log(String(row.id).slice(0,8), row.author, body ? `OK ${body.length}` : 'FAIL');
  }
  fs.writeFileSync(OUT, JSON.stringify(out, null, 1));
  console.log('flake count:', flake, 'saved', OUT);
})().catch(e => { console.error('ERR', e.message); process.exit(2); });
