const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const required = [
  'runtime/backend/closedLoop/TeachingCenterSimulationLoop.js',
  'runtime/backend/closedLoop/PatchApplicationEngine.js',
  'runtime/backend/closedLoop/RollbackRecoveryEngine.js',
  'runtime/proof/MASTERSTEP60_SIMULATION_PATCH_ROLLBACK_ALIGNMENT.md',
  'runtime/proof/MASTERSTEP60_TEST_RESULTS.md',
  'docs/MASTERSTEP60_SIMULATION_PATCH_ROLLBACK_MAP.md',
  'tests/masterStep60SimulationPatchRollbackAlignmentTest.js'
];
for (const rel of required) assert.ok(fs.existsSync(path.join(root, rel)), `missing ${rel}`);
const plugin = path.join(root, 'CA/Continuity_Architecture/.obsidian/plugins/continuity-interface');
const forbidden = /simulation loop|patch application|rollback recovery|proof ledger|atomic commit|mutation lock|teaching center simulation|backend validator|axis engine|doyle spire|separation target|restoration gateway/i;
function walk(dir){
  if (!fs.existsSync(dir)) return [];
  let out=[];
  for (const name of fs.readdirSync(dir)) {
    const p=path.join(dir,name); const st=fs.statSync(p);
    if (st.isDirectory()) out=out.concat(walk(p)); else out.push(p);
  }
  return out;
}
for (const file of walk(plugin).filter(f => /\.(js|ts|json|md)$/.test(f))) {
  const rel = path.relative(root, file);
  if (/ATLAS_PATH_LOCK_README\.md$/.test(rel)) continue;
  const text = fs.readFileSync(file,'utf8');
  assert.ok(!forbidden.test(text), `frontend intelligence residue in ${rel}`);
}
console.log('masterStep60FullClosureKeeperReadinessTest PASSED');
