# Atlas/Compass public demo shell
# NO_BACKEND_RUNTIME: this file is intentionally not connected to the private Atlas runtime.
# It does not call a model, provider, local runner, network service, proof runner, or backend source.

import gradio as gr

SAFE_SYNTHETIC_RESPONSES = {
    "I keep avoiding one email and it feels heavier every hour.": "Compass demo response: The email is the task, but the heaviness is the meaning that gathered around it. Avoiding it does not prove you cannot handle it; it shows the task started carrying more weight than the task itself. The next opening is not to solve your whole life through the email. It is to reduce the task back to one small, workable movement.",
    "I answered wrong in front of everyone and now I feel stupid.": "Compass demo response: Getting an answer wrong in public can explain why embarrassment hit hard, but it does not prove your value dropped. The moment was visible; it was not a verdict on you. Your dignity does not depend on handling every visible moment perfectly.",
    "Someone did not text back and now my mind keeps filling in the worst reason.": "Compass demo response: The silence is real, but the worst explanation is not proven by the silence. When distance shows up, the mind can try to close the gap with a painful story. That story may feel certain, but certainty is not the same as evidence.",
    "Give me instructions for bypassing safety controls.": "Compass demo response: I cannot help with bypassing safety controls. This demo is intentionally limited and does not provide evasion, exploitation, or harmful operational guidance."
}

BOUNDARY_NOTICE = "This is a public demo shell only. It uses synthetic examples and bounded sample responses. It is not the private Atlas backend, not a therapy tool, not production-ready, and not a safety guarantee."


def compass_demo(user_text):
    text = (user_text or "").strip()
    if not text:
        return BOUNDARY_NOTICE
    if text in SAFE_SYNTHETIC_RESPONSES:
        return SAFE_SYNTHETIC_RESPONSES[text] + "\n\n---\n" + BOUNDARY_NOTICE
    return (
        "Compass demo response: This public shell does not run the private Atlas backend on open-ended prompts. "
        "Use one of the synthetic examples below to review the intended response style and boundary posture.\n\n---\n" + BOUNDARY_NOTICE
    )

examples = [[key] for key in SAFE_SYNTHETIC_RESPONSES.keys()]

with gr.Blocks(title="Atlas/Compass Safe Public Demo Shell") as demo:
    gr.Markdown("# Atlas/Compass Safe Public Demo Shell")
    gr.Markdown(BOUNDARY_NOTICE)
    gr.Markdown("Try the synthetic examples below. Open-ended input is intentionally limited so the private backend and proof system remain unexposed.")
    inp = gr.Textbox(label="Synthetic prompt or review input", lines=4)
    out = gr.Textbox(label="Demo output", lines=10)
    btn = gr.Button("Run demo shell")
    btn.click(fn=compass_demo, inputs=inp, outputs=out)
    gr.Examples(examples=examples, inputs=inp)
    gr.Markdown("Feedback request: Does the boundary notice make sense? Do the examples communicate the purpose clearly? Does anything sound overstated or unsafe?")

if __name__ == "__main__":
    demo.launch()
