# Narcissism

## Mechanical Definition
Narcissism is inflated identity preservation sustained through external validation, superiority maintenance, emotional control, and resistance to truthful recalibration.

Narcissism protects constructed identity from destabilization.

---

## Real-World Definition
In real use, Narcissism describes how this backend idea appears in ordinary human experience, decision-making, relationships, meaning, or continuity so the system does not treat the concept as only a mechanical structure.

## What Creates Narcissism
- deep insecurity
- unstable self-worth
- fear of inadequacy
- validation dependency
- emotional neglect
- ego attachment
- identity overcompensation

---

## What Sustains Narcissism
- external validation
- superiority reinforcement
- manipulation
- emotional control
- criticism avoidance
- lack of humility
- refusal to recalibrate

---

## What Narcissism Produces
- manipulation
- emotional domination
- lack of accountability
- distorted self-perception
- exploitation
- emotional instability beneath the surface
- fragmented relationships

---

## What Narcissism Fears Most
- exposure
- criticism
- vulnerability
- inadequacy
- loss of superiority
- identity destabilization

---

## What Resolves Narcissistic Distortion
- humility
- awareness
- truthful confrontation
- accountability
- emotional grounding
- stable self-worth
- recalibration

---

## Connected Nodes
- [[Self-Worth]]
- [[Fear]]
- [[Identity]]
- [[Integrity]]
- [[Corruption]]
- [[Humility]]
- [[Validation Dependency]]

---

## Core Principle
Narcissism inflates identity externally to protect unstable continuity internally.