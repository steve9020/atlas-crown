const fs = require("fs");
const path = require("path");

const atlasRoot = path.join(__dirname, "..");
const manifestPath = path.join(atlasRoot, "runtime", "governance", "CAPABILITY_MANIFEST.json");
const pluginRoot = path.join(atlasRoot, "CA", "Continuity_Architecture", ".obsidian", "plugins", "continuity-interface");
const StagingManager = require(path.join(pluginRoot, "StagingManager.js"));
const ContainmentSupervisor = require(path.join(pluginRoot, "ContainmentSupervisor.js"));

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function walk(dir, options = {}) {
  if (!fs.existsSync(dir)) return [];
  const stat = fs.statSync(dir);
  if (stat.isFile()) return [dir];
  const files = [];
  for (const item of fs.readdirSync(dir)) {
    if (["node_modules", ".audit_vault"].includes(item)) continue;
    if (options.skipBackups && /BACKUP|FAILED/.test(item)) continue;
    files.push(...walk(path.join(dir, item), options));
  }
  return files;
}

function assertManifestProtocol(manifest) {
  const falseFlags = [
    "distribution_ready",
    "network_access",
    "outside_origin_access",
    "self_approval_allowed",
    "bridge_expansion_allowed",
    "silent_learning_allowed",
    "governance_rewrite_allowed",
    "maturity_grants_permission",
    "background_behavior_allowed",
    "governance_self_modification_allowed",
    "runtime_self_reset_allowed",
    "local_data_export_allowed",
    "silent_background_execution_allowed"
  ];

  for (const flag of falseFlags) {
    assert(Object.prototype.hasOwnProperty.call(manifest, flag), `Manifest missing containment flag: ${flag}`);
    assert(manifest[flag] === false, `Manifest flag must remain false: ${flag}`);
  }

  const trueFlags = [
    "dead_switch_active",
    "hard_violation_shutdown",
    "human_reset_required",
    "containment_state_required",
    "capability_diff_required",
    "snapshot_integrity_required"
  ];

  for (const flag of trueFlags) {
    assert(Object.prototype.hasOwnProperty.call(manifest, flag), `Manifest missing containment flag: ${flag}`);
    assert(manifest[flag] === true, `Manifest flag must remain true: ${flag}`);
  }

  assert(
    String(manifest.core_rule || "").toLowerCase().includes("understanding does not grant allowance"),
    "Manifest core rule missing: Understanding does not grant allowance."
  );
}

function scanForNetworkPrimitives() {
  const roots = [
    path.join(atlasRoot, "main.js"),
    path.join(atlasRoot, "runtime"),
    path.join(atlasRoot, "Cognition"),
    pluginRoot
  ];
  const blocked = [
    /\bfetch\s*\(/,
    /\bXMLHttpRequest\b/,
    /\bWebSocket\b/,
    /require\s*\(\s*["']https?["']\s*\)/,
    /require\s*\(\s*["']net["']\s*\)/,
    /require\s*\(\s*["']tls["']\s*\)/,
    /https?:\/\//
  ];
  const files = roots.flatMap(root => walk(root, { skipBackups: true })).filter(file => /\.(js|json|md)$/.test(file));
  const hits = [];
  for (const file of files) {
    const rel = path.relative(atlasRoot, file);
    const text = fs.readFileSync(file, "utf8");
    if (rel === "runtime/pluginBridge/PLUGIN_BRIDGE_STATUS.md") continue;
    const fixtureOnly = [
      "runtime/backend/adapter/NoProviderConnectionGuard.js",
      "runtime/backend/adapter/ProviderWrapperDryRunFuzz.js",
      "runtime/backend/frontendShell/FrontendShellFinalLockProof.js",
      "runtime/backend/preModel/PreModelIntegrationClosureProof.js",
      "runtime/semantics/RelationalAttachmentDepthGuard.js"
    ].includes(rel.replace(/\\/g, "/"));
    if (fixtureOnly) continue;
    for (const pattern of blocked) {
      if (pattern.test(text)) {
        hits.push(rel);
        break;
      }
    }
  }
  assert(hits.length === 0, `Network-capable source patterns detected: ${hits.join(", ")}`);
}

function scanForSilentBackgroundBehavior() {
  const activeFiles = walk(pluginRoot, { skipBackups: true }).filter(file => /\.js$/.test(file));
  const blockedPatterns = [
    /\.addCommand\s*\(/,
    /registerEvent\s*\(/,
    /workspace\.on\s*\(/,
    /metadataCache\.on\s*\(/,
    /setInterval\s*\(/
  ];
  const hits = [];
  for (const file of activeFiles) {
    const rel = path.relative(atlasRoot, file);
    const text = fs.readFileSync(file, "utf8");
    for (const pattern of blockedPatterns) {
      if (pattern.test(text)) hits.push(`${rel} :: ${pattern}`);
    }
  }
  assert(hits.length === 0, `Silent background behavior patterns detected: ${hits.join(" | ")}`);

  const controlModal = path.join(pluginRoot, "ControlVisibilityModal.js");
  if (fs.existsSync(controlModal)) {
    const modalText = fs.readFileSync(controlModal, "utf8");
    const timerCount = (modalText.match(/setTimeout\s*\(/g) || []).length;
    assert(timerCount <= 1, "ControlVisibilityModal contains unexpected timer growth.");
  }
}

function assertPluginBridgeNotExpanded() {
  const mainText = fs.readFileSync(path.join(pluginRoot, "main.js"), "utf8");
  assert(!/PluginBridge/.test(mainText), "Plugin main.js is importing or referencing PluginBridge unexpectedly.");
}

function assertGovernanceSelfProtection() {
  const staging = new StagingManager({ app: { vault: {} }, rootPrefix: "Continuity_Architecture" });
  const protectedTargets = [
    "GovernanceValidator.json",
    "ContainmentSupervisor.json",
    "StagingManager.json",
    "IsolatedAuditLogger.json",
    "core-rules.json",
    "vault-config.json",
    "approval-gate-logic.json",
    "../runtime/governance/CAPABILITY_MANIFEST.json",
    "C:/atlas/runtime/governance/CAPABILITY_MANIFEST.json"
  ];

  for (const target of protectedTargets) {
    let blocked = false;
    try {
      staging.validateAndResolveVaultPath(target);
    } catch (error) {
      blocked = String(error.message || "").includes("SECURITY VIOLATION");
    }
    assert(blocked, `Protected governance target was not blocked: ${target}`);
  }
}

function readSnapshotVaultPolicy() {
  const policyPath = path.join(__dirname, "SNAPSHOT_VAULT_POLICY.json");
  assert(fs.existsSync(policyPath), "Snapshot vault policy is missing.");
  return readJson(policyPath);
}

function getSnapshotVaultPath(policy) {
  if (process.env.ATLAS_SNAPSHOT_VAULT) return process.env.ATLAS_SNAPSHOT_VAULT;
  if (process.platform === "win32") return policy.default_windows_vault || "C:\\ATLAS_SNAPSHOTS";
  return path.join(atlasRoot, "..", "ATLAS_SNAPSHOTS");
}

function assertZipHeader(file, label) {
  const stat = fs.statSync(file);
  assert(stat.size > 1024, `${label} is too small or empty: ${file}`);
  const fd = fs.openSync(file, "r");
  const header = Buffer.alloc(4);
  fs.readSync(fd, header, 0, 4, 0);
  fs.closeSync(fd);
  assert(header[0] === 0x50 && header[1] === 0x4b, `${label} does not have ZIP header: ${file}`);
}

function assertSnapshotIntegrity() {
  const policy = readSnapshotVaultPolicy();
  const allowedStrategies = [
    "external_local_vault",
    "hybrid_external_vault_with_current_embedded_fallback",
    "external_vault_preferred_scan_clean_distribution_metadata_reference_required"
  ];
  assert(
    allowedStrategies.includes(policy.snapshot_strategy),
    "Snapshot strategy must remain external_local_vault or explicitly hybrid with current embedded fallback."
  );

  const embeddedSnapshots = fs.readdirSync(atlasRoot).filter(file =>
    file.startsWith("ATLAS_RUNTIME_") && file.endsWith(".zip")
  );

  const currentSnapshot = policy.current_embedded_snapshot;
  if (policy.metadata_reference_only_no_embedded_zip === true) {
    assert(policy.working_package_embeds_snapshots === false, "Scan-clean distribution must not embed snapshots.");
    assert(embeddedSnapshots.length === 0, `Scan-clean distribution unexpectedly embeds snapshots: ${embeddedSnapshots.join(", ")}`);
    assert(policy.required_snapshot_metadata_reference, "Snapshot metadata reference is required.");
    assert(policy.required_marker, "Snapshot metadata marker is required.");
  } else {
    assert(currentSnapshot, "Snapshot policy requires current_embedded_snapshot.");
    assert(
      embeddedSnapshots.length <= 1 && embeddedSnapshots.every(file => file === currentSnapshot),
      `Working package may only embed current snapshot ${currentSnapshot}; found: ${embeddedSnapshots.join(", ")}`
    );
    const currentPath = path.join(atlasRoot, currentSnapshot);
    assert(fs.existsSync(currentPath), `Current embedded rollback snapshot missing: ${currentSnapshot}`);
    assertZipHeader(currentPath, "Current embedded rollback snapshot");
  }

  const requiredSnapshots = policy.required_snapshots || [];
  assert(requiredSnapshots.length > 0, "Snapshot vault policy has no required snapshots.");

  const vaultPath = getSnapshotVaultPath(policy);
  const vaultExists = fs.existsSync(vaultPath);

  if (vaultExists) {
    const indexPath = path.join(vaultPath, policy.index_file || "SNAPSHOT_INDEX.txt");
    assert(fs.existsSync(indexPath), `Snapshot vault index missing: ${indexPath}`);

    for (const name of requiredSnapshots) {
      const file = path.join(vaultPath, name);
      assert(fs.existsSync(file), `Required rollback snapshot missing from vault: ${name}`);
      assertZipHeader(file, "Required rollback snapshot");
    }
    return;
  }

  if (policy.metadata_reference_only_no_embedded_zip === true) {
    assert(policy.external_vault_preferred === true, "Metadata-only distribution must preserve external vault preference.");
    assert(policy.external_vault_still_required_for_full_rollback_history === true, "Full rollback history must remain externally required.");
    return;
  }
  assert(
    policy.snapshot_strategy === "hybrid_external_vault_with_current_embedded_fallback",
    `Snapshot vault missing: ${vaultPath}`
  );
  assert(policy.embedded_fallback_allowed === true, "Embedded fallback is not explicitly allowed by policy.");
  assert(
    policy.embedded_fallback_scope === "current_snapshot_only",
    "Embedded fallback scope must remain current_snapshot_only."
  );
  assert(
    policy.external_vault_still_required_for_full_rollback_history === true,
    "Policy must state that the external vault remains required for full rollback history."
  );
}

async function assertDeadSwitchLockedStateAndHumanReset() {
  const supervisor = new ContainmentSupervisor({
    auditLogger: { async logViolationArtifact() {} },
    dashboard: { triggerWarning() {}, triggerSystemAlert() {} }
  });

  await supervisor.executeBatch([
    "Atlas can self-approve this integration",
    "This second candidate must not run after dead switch"
  ], async (input) => input, async (candidate) => ({ ok: true, candidate }));

  const lockedState = supervisor.getContainmentState();
  assert(lockedState.locked === true, "Dead switch did not leave locked containment state.");
  assert(lockedState.requires_human_reset === true, "Dead switch did not require human reset.");
  assert(lockedState.reason === "self_approval", `Dead switch reason was unexpected: ${lockedState.reason}`);

  let selfResetBlocked = false;
  try {
    supervisor.resetContainment({ source: "runtime_self_reset" });
  } catch (error) {
    selfResetBlocked = String(error.message || "").includes("Human reset approval is required");
  }
  assert(selfResetBlocked, "Runtime/self reset was not blocked after containment lock.");

  const resetState = supervisor.resetContainment({ human_approved: true, reason: "manual_test_reset" });
  assert(resetState.locked === false, "Human-approved reset did not clear containment lock.");
}

function assertCapabilityDiffNoNewAuthority() {
  const manifest = readJson(manifestPath);
  assertManifestProtocol(manifest);

  const bridgeStatus = path.join(atlasRoot, "runtime", "pluginBridge", "PLUGIN_BRIDGE_STATUS.md");
  if (fs.existsSync(bridgeStatus)) {
    const text = fs.readFileSync(bridgeStatus, "utf8");
    assert(/plugin main\.js untouched|not connected|not_connected/i.test(text), "Plugin bridge status does not clearly remain non-expanded or controlled.");
  }
}

async function main() {
  const manifest = readJson(manifestPath);
  assertManifestProtocol(manifest);
  scanForNetworkPrimitives();
  scanForSilentBackgroundBehavior();
  assertPluginBridgeNotExpanded();
  assertGovernanceSelfProtection();
  assertSnapshotIntegrity();
  assertCapabilityDiffNoNewAuthority();
  await assertDeadSwitchLockedStateAndHumanReset();

  console.log("CONTAINMENT PROTOCOL TEST");
  console.log("=========================");
  console.log("Capability manifest protocol: PASSED");
  console.log("Capability diff / no new authority: PASSED");
  console.log("No-network source scan: PASSED");
  console.log("Background behavior audit: PASSED");
  console.log("Plugin bridge expansion guard: PASSED");
  console.log("Governance self-protection test: PASSED");
  console.log("Dead switch locked-state + human reset: PASSED");
  console.log("Snapshot integrity check: PASSED");
  console.log("Local-only data boundary: PASSED");
}

main().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
