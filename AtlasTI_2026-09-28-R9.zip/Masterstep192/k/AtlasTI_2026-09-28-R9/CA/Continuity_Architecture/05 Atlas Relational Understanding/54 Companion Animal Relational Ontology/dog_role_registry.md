# Dog Role Registry

## Roles
- dog
- puppy
- pup

## Emotional Weight
Very high.

## Common Meaning Pressure
- companionship
- loyalty
- comfort
- routine
- protection
- attachment
- grief

## Runtime Rule
Dog-related distress should strongly increase emotional-context depth and grief sensitivity.
