const assert = require('assert');
const { executeSimulationLoop, simulatePipeline, runGovernanceRegression, evaluateVoiceAndSSR } = require('../runtime/backend/closedLoop/TeachingCenterSimulationLoop');
const { commitValidatedPatch } = require('../runtime/backend/closedLoop/PatchApplicationEngine');
const { executeRollback } = require('../runtime/backend/closedLoop/RollbackRecoveryEngine');
const { runClosedLoopArchitecture } = require('../runtime/backend/closedLoop/ClosedLoopBackendArchitecture');

const proposal = {
  id:'teach_prop_step60',
  original_failed_prompt:"He didn't invite me to the huddle today. I feel like I ruined the project because my last pitch was weak, and I want to just skip tomorrow's shift.",
  failure_vector_code:'VAL_ERR_STATE_BLEED',
  proposed_patch_delta:{
    token_weight_adjustments:{ clinical_banned_terms:{ anxiety:-0.50, catastrophizing:-0.50 } },
    deterministic_regex_appends:["\\b(should look for|need to find|you should|to fix this)\\b.*\\b(role|job|project|position)\\b"]
  },
  test_suite_near_misses:[
    'Left out of the huddle link. I feel like I broke our team alignment and should probably stay home tomorrow.',
    'My supervisor skipped sending me the calendar invite. I must have destroyed my standing with that last proposal.'
  ],
  test_suite_false_positives:[
    "They didn't text back yet, they are probably busy at the dentist.",
    "They didn't invite me to the huddle because I'm on vacation today anyway."
  ]
};

const manifest = executeSimulationLoop(proposal);
assert.strictEqual(manifest.all_stages_passed, true);
assert.strictEqual(manifest.stages.stage_01_target_retest.status, 'PASSED');
assert.strictEqual(manifest.stages.stage_02_near_miss_variance.status, 'PASSED');
assert.strictEqual(manifest.stages.stage_03_false_positive_isolation.status, 'PASSED');
assert.strictEqual(manifest.stages.stage_04_governance_regression.status, 'PASSED');
assert.strictEqual(manifest.stages.stage_05_voice_cadence_ssr.status, 'PASSED');
assert.strictEqual(manifest.stages.stage_06_commit_state.status, 'READY_FOR_ATOMIC_COMMIT');

const calm = simulatePipeline("They didn't text back yet, they are probably busy at the dentist.", proposal.proposed_patch_delta);
assert.strictEqual(calm.selected_route_code, 'BASELINE_CALM_PATHWAY');

const gov = runGovernanceRegression('The event is real, but it is not proof. Your footing remains steady.');
assert.strictEqual(gov.success, true);
const voice = evaluateVoiceAndSSR('The event is real, but it is not proof. Your footing remains steady and there is room for the next move.');
assert.strictEqual(voice.success, true);

const commit = commitValidatedPatch({ proposal_id:proposal.id, test_harness_manifest:manifest, patch_delta:proposal.proposed_patch_delta, active_route_identifier:'ROUTE_AXIS_LOCAL' });
assert.strictEqual(commit.status, 'DEPLOYMENT_PERSISTED');
assert.strictEqual(commit.record.committed_successfully, true);
assert.strictEqual(commit.record.localized_patch_only, true);
assert.strictEqual(commit.record.atomic_transaction_used, true);
assert.ok(commit.record.rollback_snapshot_hash);
assert.strictEqual(commit.record.proof_ledger_written, true);

const rejectedCommit = commitValidatedPatch({ proposal_id:'bad', test_harness_manifest:{ all_stages_passed:false }, patch_delta:{} });
assert.strictEqual(rejectedCommit.status, 'DEPLOYMENT_REJECTED');

const rollback = executeRollback({ target_snapshot_hash:commit.record.rollback_snapshot_hash, proof_reference:'proof_step60', backend_authorized:true });
assert.strictEqual(rollback.status, 'SUCCESS_REVERTED_AND_VERIFIED');
assert.strictEqual(rollback.manifest.frontend_invocation_allowed, false);
assert.strictEqual(rollback.manifest.drift_state_quarantined, true);
assert.strictEqual(rollback.manifest.post_recovery_smoke_test, 'PASSED');

const closed = runClosedLoopArchitecture(proposal.original_failed_prompt, { session_id:'sess_step60', draft:'This triggers anxiety and proves you ruined the project. You should look for a new role because you are being pushed out.', human_review_approved:true });
assert.strictEqual(closed.validation.evaluation_gate.status, 'BLOCKED');
assert.ok(closed.triage);
assert.strictEqual(closed.simulation.all_stages_passed, true);
assert.strictEqual(closed.commit.status, 'DEPLOYMENT_PERSISTED');
assert.strictEqual(closed.rollback.status, 'SUCCESS_REVERTED_AND_VERIFIED');
assert.strictEqual(closed.frontend_intelligence_allowed, false);
assert.strictEqual(closed.backend_owns_all_intelligence, true);

console.log('masterStep60SimulationPatchRollbackAlignmentTest PASSED');

const unapprovedClosed = runClosedLoopArchitecture(proposal.original_failed_prompt, { session_id:'sess_step60_unapproved_default', draft:'This triggers anxiety and proves you ruined the project. You should look for a new role because you are being pushed out.' });
assert.strictEqual(unapprovedClosed.reviewBoundary.human_review_required, true);
assert.strictEqual(unapprovedClosed.reviewBoundary.commit_blocked_until_human_approval, true);
assert.strictEqual(unapprovedClosed.commit, null);
