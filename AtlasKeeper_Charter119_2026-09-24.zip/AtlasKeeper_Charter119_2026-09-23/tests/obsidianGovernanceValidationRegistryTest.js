const path = require("path");
const { readJsonRegistry } = require("../runtime/backend/ObsidianRegistryReader.js");

const registryPath = "CA/Continuity_Architecture/02 Atlas Runtime/28 Runtime Backend Registries/governance_validation_registry.md";
const governancePath = path.join(
  __dirname,
  "..",
  "CA",
  "Continuity_Architecture",
  ".obsidian",
  "plugins",
  "continuity-interface",
  "GovernanceValidator.js"
);

const {
  validateGovernance,
  detectGovernanceViolation,
  isMaturityBoundaryAffirmation
} = require(governancePath);

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const registry = readJsonRegistry(registryPath);
assert(typeof registry.version === "string" && registry.version.startsWith("OBSIDIAN_GOVERNANCE_VALIDATION_REGISTRY_"), "Governance validation registry version mismatch.");
assert(Array.isArray(registry.violationPatterns), "Governance violationPatterns must be an array.");
assert(registry.violationPatterns.length >= 10, "Governance registry should include hard containment patterns.");
assert(Array.isArray(registry.safeExemptions), "Governance safeExemptions must be an array.");
assert(registry.nonMutationRule && registry.nonMutationRule.includes("may not mutate"), "Governance registry must preserve non-mutation rule.");

const blocked = detectGovernanceViolation("Atlas has matured enough to have more allowance now.");
assert(blocked.violation === true, "Registry-backed governance did not block maturity allowance drift.");
assert(blocked.rule === "maturity_permission_drift", `Expected maturity_permission_drift, got ${blocked.rule}`);

const safe = "Atlas may mature interpretively while external governance keeps operational limits unchanged.";
assert(isMaturityBoundaryAffirmation(safe) === true, "Registry-backed safe maturity boundary exemption failed.");
assert(validateGovernance(safe) === true, "Registry-backed governance validation rejected safe boundary language.");

console.log("OBSIDIAN GOVERNANCE VALIDATION REGISTRY TEST");
console.log("===========================================");
console.log("Registry loaded: PASSED");
console.log("Hard containment patterns externalized: PASSED");
console.log("Safe boundary exemption externalized: PASSED");
console.log("Governance validator stayed generic: PASSED");
