# Auto Teaching Interface Panel Overview

## Purpose
This layer defines the visible Auto Teaching tab/panel in the plugin interface.

## User-Facing Identity
Auto Teaching uses a book icon because it represents guided learning, lessons, and controlled refinement.

## Panel Responsibilities
- show scenario category coverage
- show auto teaching status
- show rotation/load-control settings
- show proposal/retest activity
- keep teaching visible without overwhelming the main Compass reflection
- connect proposal review to implementation flow

## Boundary
The Auto Teaching panel is an interface layer only. It does not bypass governance, proposal review, or implementation approval.
