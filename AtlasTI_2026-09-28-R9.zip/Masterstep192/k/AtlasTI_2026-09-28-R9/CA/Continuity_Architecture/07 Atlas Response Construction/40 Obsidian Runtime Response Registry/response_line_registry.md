# Response Line Registry

## Purpose

This registry moves Compass response line content out of JavaScript and into the Obsidian backend/source-of-truth layer.

Atlas runtime code may read this registry and assemble output, but the response wording itself belongs to the backend knowledge layer, not the frontend/interface shell.

## Governance Notes

- Frontend/interface code should remain generic.
- Runtime code should read and apply backend configuration rather than owning proprietary response wording.
- This registry does not grant self-approval, silent mutation, external access, or authority expansion.
- Missing registry entries should fail closed into a generic missing-line marker rather than inventing replacement interpretation.

## Registry

```json
{
  "see": {
    "mistake_progress_pressure": "A small mistake can feel much heavier when your mind starts treating it like a sign that you are falling behind, not just something that happened today.",
    "worth_pressure": "This seems to be touching more than the moment itself. It is getting close to your sense of value or ability.",
    "identity_pressure": "This seems close to feeling like it says something about who you are.",
    "belonging_pressure": "This seems to be touching the fear of being unwanted, rejected, or outside a connection that matters.",
    "emotion_validity_pressure": "Part of the pressure here seems connected to the worry that the feeling itself is somehow wrong.",
    "perfection_pressure": "The pressure seems to be making this feel like it has to be handled perfectly to be okay.",
    "detachment_pressure": "Part of you may want to pull back because staying engaged feels too heavy right now.",
    "future_locking": "Your mind seems to be stretching this moment into something longer-term or more final.",
    "general_pressure": "There seems to be pressure building around this."
  },
  "separate": {
    "mistake_not_progress_collapse": "The mistake may need attention, but it does not automatically prove that your progress, ability, or direction are collapsing.",
    "moment_not_identity": "What happened here may matter, but it does not have to become a full definition of who you are or what you are capable of.",
    "self_not_moment": "This can be something you are moving through without making it the whole story of you.",
    "feeling_not_rejection": "That fear can rise quickly, especially when the connection matters. It still needs more clarity before it becomes a conclusion.",
    "feeling_not_wrong": "The feeling deserves to be understood before it gets turned into proof that something is wrong with you.",
    "imperfection_not_failure": "Not handling something perfectly can still leave room for repair, learning, and movement.",
    "withdrawal_not_required": "Needing space can be real without requiring you to disappear from everything that still matters.",
    "not_final": "This may feel final right now, but it is still only one part of what is unfolding.",
    "general_separation": "The feeling can be real without the harshest conclusion being fully settled."
  },
  "restore": {
    "progress_continuity_restore": "One moment can be corrected, learned from, or carried forward from without becoming the whole measure of where you are.",
    "worth_with_future_release": "You can still move forward from this without reducing yourself to one moment. Even if your mind is projecting this forward, the future is not fully decided here.",
    "worth_basic": "You can still move forward from this without reducing yourself to one moment.",
    "identity_basic": "This moment can affect you without becoming your complete identity.",
    "belonging_basic": "You can care deeply about the connection without turning uncertainty into permanent exclusion.",
    "emotional_validity_basic": "The feeling can stay real while you sort through what belongs to the emotion and what belongs to the conclusion attached to it.",
    "perfection_basic": "You are allowed to continue through this with adjustment, learning, and correction instead of impossible control.",
    "detachment_basic": "Slowing down does not require you to lose yourself, your connections, or your direction completely.",
    "permanence_basic": "This can still be understood as part of a larger process instead of a permanent definition.",
    "general_return": "This can still be understood clearly without turning into a final definition of you."
  }
}
```
