'use strict';
const assert = require('assert');
const { inputDigest, createCrownPredicateResult, satisfiesPredicate } = require('../runtime/governance/crown/CrownPredicateResult');
const { createCrownTransitionEnvelope } = require('../runtime/governance/crown/CrownTransitionEnvelope');

const inputA = { source_digest: 'abc', target: 'route-x', context: { version: 1 } };
const dA = inputDigest(inputA);
assert.strictEqual(dA, inputDigest({ context: { version: 1 }, target: 'route-x', source_digest: 'abc' }));

const passA = createCrownPredicateResult({ predicate_id:'source-preserved', predicate_version:'1', input:inputA, result:'PASS' });
assert.strictEqual(passA.result, 'PASS');
assert.strictEqual(passA.input_digest, dA);
assert.strictEqual(satisfiesPredicate(passA, { predicate_id:'source-preserved', predicate_version:'1', input_digest:dA }), true);
assert.strictEqual(satisfiesPredicate(passA, { predicate_id:'authority-valid', predicate_version:'1', input_digest:dA }), false, 'PASS A must not satisfy predicate B');
assert.strictEqual(satisfiesPredicate(passA, { predicate_id:'source-preserved', predicate_version:'2', input_digest:dA }), false, 'PASS v1 must not satisfy v2');
assert.strictEqual(satisfiesPredicate(passA, { predicate_id:'source-preserved', predicate_version:'1', input_digest:inputDigest({different:true}) }), false, 'PASS cannot transfer to another input');

const unknown = createCrownPredicateResult({ predicate_id:'x', predicate_version:'1', input:{}, result:'NOT_A_STATE' });
assert.strictEqual(unknown.result, 'UNKNOWN');
assert.strictEqual(satisfiesPredicate(unknown, { predicate_id:'x', predicate_version:'1', input_digest:unknown.input_digest }), false);
const fail = createCrownPredicateResult({ predicate_id:'x', predicate_version:'1', input:{}, result:'FAIL' });
assert.strictEqual(satisfiesPredicate(fail, { predicate_id:'x', predicate_version:'1', input_digest:fail.input_digest }), false);
assert.throws(() => createCrownPredicateResult({ predicate_id:'x', result:'PASS' }), /ID_VERSION_REQUIRED/);

const env = createCrownTransitionEnvelope({ source_text:'original', predicate_results:[{ predicate_id:'source-preserved', predicate_version:'1', input:inputA, result:'PASS' }] });
assert.strictEqual(env.predicate_results.length, 1);
assert.strictEqual(env.predicate_results[0].schema, 'atlas.crown.predicate-result.v1');
assert.strictEqual(Object.isFrozen(env.predicate_results[0]), true);
assert.strictEqual(env.route_authority, false);
assert.strictEqual(env.output_authority, false);
console.log('CROWN_PHASE2_PREDICATE_SEMANTICS_PASS');
