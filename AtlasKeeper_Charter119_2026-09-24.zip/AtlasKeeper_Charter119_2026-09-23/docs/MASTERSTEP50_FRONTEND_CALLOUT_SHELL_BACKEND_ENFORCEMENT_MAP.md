# Masterstep50 Map

This step surgically relocates intelligence-bearing plugin files to backend ownership and leaves the Obsidian frontend as a callout/display shell.

`CA/Continuity_Architecture/.obsidian/plugins/continuity-interface/main.js` now only renders the input/display shell and calls `runtime/backend/FrontendCalloutService.js`.

Former plugin intelligence now lives in `runtime/backend/pluginShell/`.
