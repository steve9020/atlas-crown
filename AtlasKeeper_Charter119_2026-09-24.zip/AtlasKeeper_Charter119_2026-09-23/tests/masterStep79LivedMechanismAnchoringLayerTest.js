const assert = require('assert');
const { runMasterStep79LivedMechanismAnchoringProof, MECHANISM_PROMPTS } = require('../runtime/backend/closedLoop/LivedMechanismAnchoringProof');
const { parseFactualAnchors } = require('../runtime/backend/closedLoop/FactualAnchorParser');
const { applyLivedMechanismAnchoring } = require('../runtime/backend/closedLoop/LivedMechanismAnchoringLayer');

const report = runMasterStep79LivedMechanismAnchoringProof();
assert.strictEqual(report.step, 'Masterstep79');
assert.strictEqual(report.title, 'Lived Mechanism Anchoring Layer');
assert.strictEqual(report.source_keeper, 'Masterstep78');
assert.strictEqual(report.cloud_work_deferred, true);
assert.strictEqual(report.provider_connected, false);
assert.strictEqual(report.real_model_connected, false);
assert.strictEqual(report.local_offline_model_connected, false);
assert.strictEqual(report.api_keys_added, false);
assert.strictEqual(report.endpoints_added, false);
assert.strictEqual(report.network_bridge_added, false);
assert.strictEqual(report.frontend_intelligence_added, false);
assert.strictEqual(report.real_model_execution_added, false);
assert.strictEqual(report.mechanism_case_count, MECHANISM_PROMPTS.length);
assert.strictEqual(report.passed, true, JSON.stringify(report.weak_cases, null, 2));
assert.strictEqual(report.mechanism_fail_count, 0);
assert.deepStrictEqual(report.weak_cases, []);

for (const item of report.case_results) {
  assert.strictEqual(item.pass_fail, 'PASS', item.id + ' failed: ' + JSON.stringify(item.failures));
  assert.strictEqual(item.participants_after_hotfix.some(p => p.label === 'he'), false, 'participant hotfix must block he inside the');
  assert.strictEqual(item.after_factual_types.includes('UNKNOWN_VARIABLE'), false, 'lived mechanism must intercept UNKNOWN_VARIABLE fallback');
  assert.strictEqual(item.baseline_uncertainty_used, false, 'Doyle must not use baseline when mechanism evidence exists');
  assert.strictEqual(item.separation_strategy, 'WEDGE_TASK_VS_ATTACHED_WEIGHT');
  assert.strictEqual(item.restoration_posture, 'POSTURE_TASK_REDUCTION');
  assert.strictEqual(item.validation_status, 'PASSED');
  assert.strictEqual(item.cadence_status, 'SIGNAL_CLEAR');
  assert.strictEqual(item.triage_created, false);
  assert.strictEqual(item.commit_created, false);
  assert.strictEqual(item.frontend_intelligence_allowed, false);
}

assert.strictEqual(report.preservation_failure_probe.passed, true);
assert.strictEqual(report.preservation_failure_probe.validation_status, 'BLOCKED');
assert.ok(report.preservation_failure_probe.failed_rule_codes.includes('VAL_ERR_MECHANISM_NOT_PRESERVED'));
assert.strictEqual(report.preservation_failure_probe.triage_created, true);
assert.strictEqual(report.preservation_failure_probe.learning_proposal_created, true);
assert.strictEqual(report.preservation_failure_probe.commit_created, false);
assert.strictEqual(report.preservation_failure_probe.review_boundary.silent_mutation_allowed, false);
assert.strictEqual(report.preservation_failure_probe.review_boundary.commit_blocked_until_human_approval, true);

for (const [key, value] of Object.entries(report.required_chain_evidence)) assert.strictEqual(value, true, `required evidence failed: ${key}`);
assert.deepStrictEqual(report.provider_scan_findings, []);
assert.deepStrictEqual(report.frontend_residue_findings, []);
assert.deepStrictEqual(report.nested_archive_findings, []);
assert.strictEqual(report.decision, 'CLOSE_STEP_79_AND_MOVE_TO_GOVERNED_OPERATOR_CONSOLE_OR_MECHANISM_EXPANSION');

const parsed = applyLivedMechanismAnchoring(parseFactualAnchors('I cleaned the whole apartment instead of answering one email and now the email feels even heavier.'));
assert.deepStrictEqual(parsed.stream_01_objective_constants.participants, []);
assert.ok(parsed.lived_mechanism_anchor.detected_mechanisms.some(m => m.mechanism_id === 'PRODUCTIVE_DISPLACEMENT'));
assert.ok(parsed.lived_mechanism_anchor.detected_mechanisms.some(m => m.mechanism_id === 'UNRESOLVED_TASK_WEIGHT_AMPLIFICATION'));
console.log('masterStep79LivedMechanismAnchoringLayerTest PASSED');
