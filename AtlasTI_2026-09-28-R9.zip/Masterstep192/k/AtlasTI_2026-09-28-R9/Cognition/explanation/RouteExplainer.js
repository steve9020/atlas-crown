const { readJsonRegistry } = require("../../runtime/backend/ObsidianRegistryReader.js");

const ROUTE_EXPLANATION_REGISTRY_PATH = "CA/Continuity_Architecture/07 Atlas Response Construction/40 Obsidian Runtime Response Registry/route_explanation_registry.md";

function fillTemplate(template, replacements) {
  return String(template || "").replace(/\{(\w+)\}/g, (_, key) => {
    return Object.prototype.hasOwnProperty.call(replacements, key) ? replacements[key] : "";
  });
}

function explainRoute(cognition, signals, returnMode, routeScore) {
  const registry = readJsonRegistry(ROUTE_EXPLANATION_REGISTRY_PATH);
  const axes = cognition.axes || [];
  const activeSignals = signals.signals || [];
  const labels = registry.detectedLabels || {};
  const axisReasons = registry.axisReasons || {};

  const reasons = [];

  if (axes.length > 0 && labels.axes) {
    reasons.push(fillTemplate(labels.axes, { values: axes.join(", ") }));
  }

  if (activeSignals.length > 0 && labels.signals) {
    reasons.push(fillTemplate(labels.signals, { values: activeSignals.join(", ") }));
  }

  if (returnMode && returnMode !== "neutral_return" && labels.returnMode) {
    reasons.push(fillTemplate(labels.returnMode, { value: returnMode }));
  }

  if (routeScore && routeScore.confidence && labels.confidence) {
    reasons.push(fillTemplate(labels.confidence, { value: routeScore.confidence }));
  }

  for (const axis of axes) {
    if (axisReasons[axis]) {
      reasons.push(axisReasons[axis]);
    }
  }

  return {
    summary: reasons.length > 0
      ? reasons.join(" ")
      : registry.fallbackSummary || "No strong route explanation generated.",
    reasons: reasons,
    note: registry.note || "Route explanation is for internal review and debugging, not a claim of truth."
  };
}

module.exports = { explainRoute };
