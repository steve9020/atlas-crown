---
title: Abandonment Residue
runtime_layer: emotional_pressure
priority: high
status: active
phase: runtime_link_cleanup
governed_by:
  - emotional_continuity_governance
  - governance_enforcement_registry
outputs:
  - Projection From Past Pain
  - trust_collapse
---

# Abandonment Residue

## Purpose

Defines the remaining emotional imprint from prior disconnection, absence, or leaving that may shape how present relational distance is interpreted.

## Core Function

The runtime should notice the residue without assuming the current situation is identical to the past or making certainty claims about another person’s intent.

## Runtime Boundary

This node exists because existing backend links already reference this concept. It should clarify the referenced pathway without creating duplicate ontology or changing Compass into a clinical, diagnostic, authoritative, or productivity-driven system.

## Related Runtime Links

- [[Projection From Past Pain]]
- [[trust_collapse]]
- [[emotional_continuity_governance]]
- [[response_behavior_registry]]
