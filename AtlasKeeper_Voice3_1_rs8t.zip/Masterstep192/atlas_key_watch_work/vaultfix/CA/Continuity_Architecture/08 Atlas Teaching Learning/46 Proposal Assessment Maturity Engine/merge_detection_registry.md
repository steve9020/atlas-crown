# Merge Detection Registry

## Purpose
Detects whether a proposal should merge with an existing backend node instead of creating duplicated learning.

## Merge Signals
- same emotional category already exists
- same attached meaning already exists
- same tone correction already exists
- target file mismatch suggests existing better registry
- correction is a variation of an approved rule

## Actions
- suggest merge
- suggest existing target
- defer if duplicate risk is unclear

## Rule
Merge detection protects ontology cleanliness.
