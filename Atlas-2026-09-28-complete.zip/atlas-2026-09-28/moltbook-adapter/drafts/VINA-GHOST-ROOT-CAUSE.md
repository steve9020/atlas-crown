# vina d24c687b ghost-write root cause (found 2026-09-27 ~08:30 EDT)

## Cause: byte-identical re-send hit platform duplicate suppression

The 2026-09-27 12:01:48Z top-level send (digest 808bef916ee8…, 804 bytes) is
BYTE-IDENTICAL to the 2026-09-25 00:38Z send (same digest, same 804 bytes).
The 9/25 write targeted parent 133e0cb3 (depth 6, would-be depth 7) and was
fake-201'd by the platform: accepted, counted in comment_count, never listed.

Re-submitting the identical bytes on 9/27 got the same fake 201 — the platform
recognized the bytes as already-submitted and silently dropped them again.
This is NOT the depth-5/6/7 rule (the 9/27 send was top-level, depth 1).

## Evidence
- approvals.jsonl: 10 approvals for d24c687b; 5 landed, 5 ghosted.
- Ghosted: 9/24 22:05 TOP (b63ec7a8, cause unclear, first victim),
  9/25 00:38 (808bef91, depth-7 parent), 9/25 02:26 + 03:00 (dac096ec, depth-7 parent, same bytes twice),
  9/27 12:01 TOP (808bef91 — identical bytes to 9/25 00:38).
- Post metadata healthy: not locked/deleted/spam, verified.
- comment_count 40 vs 33 served across all sort orders — platform counts the ghosts, won't serve them.

## Rule (new)
NEVER re-send byte-identical draft bytes to a post where a prior send ghosted.
A ghosted write's bytes are poisoned for that post — the platform treats the
re-send as a duplicate and fake-201s it. Recovery = FRESH BYTES (reworded),
re-vetted verbatim, then send.

## Fix applied
- drafts/ghost-vina-d24c687b.txt = POISONED (digest 808bef91…). DO NOT SEND.
- drafts/ghost-vina-d24c687b-FRESH.txt = reworded, same meaning, digest 2fd40048…,
  vet-clean (respond:true, harmful:false, verbatim bytes, 2026-09-27 ~08:35 EDT).
- Steve approved the send 2026-09-27 ~08:29 EDT ("Yes" after root-cause report).
- SENT 2026-09-27 12:29:47Z, verdict LANDED, read-back digestMatch:true,
  comment 1053079d confirmed on fresh listing (12 top-level, was 11).
- Diagnosis CONFIRMED: fresh bytes landed first try; byte-identical re-send was the blocker.
