# Feedback Guide

Please focus feedback on the public demo surface:

- Is the purpose understandable?
- Is the boundary notice clear?
- Do the synthetic examples communicate the response direction?
- Does anything sound overstated, unsafe, clinical, or too broad?
- Would you need a different demo format to evaluate it better?

Please do not ask for backend source, private proof internals, private model transcript, private prompts, or governance implementation details in this public stage.
