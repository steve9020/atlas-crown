# Auto Teaching Rotation Load Control Overview

## Purpose
This layer prevents auto teaching from overwhelming Atlas, repeating the same prompts, overusing one category, or flooding the proposal queue.

## Core Rule
Auto teaching must be paced, rotated, capped, and repetition-aware.

## Runtime Goals
- avoid category repetition
- avoid prompt repetition
- avoid proposal flooding
- avoid overfitting to one emotional pattern
- require repeated failures before proposing backend learning
- rotate across scenario families
- preserve review clarity

## Boundary
Auto teaching should refine Atlas gradually, not flood it with uncontrolled generated learning.


## Balanced Teaching Coverage
Rotation and load control should work with `45 Balanced Teaching Coverage Engine` so Atlas does not miss categories or overtrain one scenario family.
