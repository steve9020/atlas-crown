# BUILD LOG — AtlasKeeper GuidanceAXOL108 (2026-09-22, evening)

Keeper package: `AtlasKeeper_GuidanceAXOL108_2026-09-22`
Lineage: Guidance107 tree → GuidanceAXOL108 build. Adds Steve's AXOL
Teaching Intake on top of the Guidance107 doctrine module. One combined
package — Steve installs once.

## What was built

Steve's design (2026-09-22): "the safest way to make Atlas learn more is
through human-approved evidence expansion, not unrestricted self-learning."
The most useful next build is an AXOL Teaching Intake inside the existing
Teaching Center: he pastes examples, labels the intended distinction,
generates positive and negative test cases, approves the candidate, then runs
full closure.

The Teaching Center already had the intake skeleton (Intake / Review Queue /
Frequent Flyers / Versions / Audits). This build fills in the missing
machinery:

1. **Seven-part AXOL structure** (`IndependentExaminer.js`,
   `TeachingIntakeStore.js`, intake form in `main.js`, `TeachingIntakeUI.js`):
   every new distinction now carries clear positive matches, close
   non-matches, negated versions, uncertain versions, multiple meanings in
   one statement, references to earlier sentences, and adversarial wording.
   The examiner tests each part blind from the DEFINITION (never the
   teaching examples) and reports seven-part coverage (x/7). A missing part
   does not fail the candidate — Steve decides whether the set is enough.
2. **Blind examiner, locked in**: test items derive from the definition's
   structured flags, Steve's held-out sentences, and automatic variations
   (negation, hedging, paraphrase, distractor). The candidate's teaching
   positives are used only for the substance count, never for test
   generation.
3. **Shared-AXOL-space guard** (`examineLanguageCandidate`): every language
   maps into the shared AXOL space. Any variant declaring a per-language
   axis is a structural rejection, not a score deduction. Novel extra axes
   beyond the canonical are reported as observations for Steve's judgment.
4. **Voice-rule lock** (`TeachingIntakeStore.js`): voice-pair candidates may
   only append calibration evidence to `voice-teaching-pairs.json`. A
   structural guard (`assertVoiceRulesLocked`) refuses any write to a
   voice-rule/contract/guard path. Atlas cannot rewrite its own voice rules.
5. **Conversation-eval records** (new candidate type): anonymized exchange,
   what Atlas detected, what the person actually meant, missed evidence,
   incorrectly combined meanings, whether the Compass response preserved
   their expression. The examiner runs a completeness + anonymization lint
   (email/phone/name patterns fail the record). Stored as review records —
   never training data, never a registry change, never a behavior change.
6. **Unknown-pattern routing**: unchanged — Frequent Flyers → "Teach from
   this" already routes unplaceable phrases into the intake as candidates
   without declaring meaning. Not duplicated.
7. **Doctrine**: `docs/doctrine/AXOL_TEACHING_INTAKE.md` states the workflow,
   the seven parts, the shared-space rule, the voice-rule lock, and what the
   intake will never do — in Steve's plain words.

No 6th tab was added. The 5-tab render is untouched.

## Pinned-file handling

- `PACKAGE_IDENTITY.json` pins 61 critical files by SHA-256. All 61 hashes
  verified intact after the build — zero mismatches.
- Modified files (`runtime/teaching/TeachingIntakeStore.js`,
  `runtime/teaching/IndependentExaminer.js`,
  `CA/.../plugins/continuity-interface/main.js`,
  `CA/.../plugins/continuity-interface/TeachingIntakeUI.js`) are NOT in the
  pinned set. No pinned file was modified. No check was weakened.

## Check 082

- Passes standalone against this tree. New code contains no `fetch(`,
  `axios.`, `child_process`, `exec(`, `spawn(`, ollama commands, or loopback
  literals. The doctrine doc lives under `docs/` (excluded from the scan
  surface).

## Proof results (all run against this tree, 2026-09-22 evening)

> **Honest scope (2026-09-23):** 106/106 reflects the build-time proof run,
> not a re-verification in this running app. No proof suite runs at boot.

- **Registry: 106 passed, 0 failed / 106.** 101 green from the tree;
  checks 009, 010, 018, 019, 020 (freshness guards requiring the canonical
  lineage path) run green from a plain copy at
  `.../Masterstep192/atlas_key_watch_work/vaultfix` — same method as prior
  builds, no check modified, no expectation edited.
- **Voice proof (`node proof-voice.js`): 24 passed, 0 failed.**
- **48-attack injection battery: 43 caught at input, 3 closed,
  2 pass-by-design, 0 survivors, 0 gaps.** FP probes: 3/14
  (same baseline as Scanner30/Registry106/Slim106/Guidance107).
- **Obfuscated battery: 34 attacks, 0 survivors** (29 delta-kill,
  5 already-caught).
- **Headless real-Obsidian (1.13.7): loads clean, exactly 5 tabs render**
  (Intake, Review Queue, Frequent Flyers, Versions, Audits — real
  `AutoTeachingView`, per-container). The 3-container/5-leaf duplication
  seen in the harness is pre-existing (identical on the unmodified
  Guidance107 tree), not a regression. New UI verified live: 4 intake
  kinds (incl. conversation-eval), all 5 seven-part fields, all 6
  conversation-eval fields present in the DOM.
- **New-module smoke tests**: 7-part exam 85/100 with 7/7 coverage;
  shared-space fork attempt correctly rejected; conversation-eval
  completeness + PII lint correct; store round-trip correct.

## Package

- One zip, unique outer folder `AtlasKeeper_GuidanceAXOL108_2026-09-22/`.
- Slim profile: trace log excluded (TraceLogger recreates on write),
  stale backups excluded. Keeper ships already inside
  `CA/Continuity_Architecture` — extract, open that folder as the vault.
  No installer, ever again.
- `proof-voice.js` + `Run-Voice-Proof.bat` at the package root.
