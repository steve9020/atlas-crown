# Automated Scenario Teaching Pipeline

## Flow
1. Generate scenario prompt.
2. Run Compass response.
3. Evaluate response quality.
4. Detect failure pattern.
5. Create proposal with required fields.
6. Send proposal to review panel.
7. Approve, implement, defer, reject, or revoke.
8. Runtime reloads after implementation.

## Teaching Principle
Prefer repeated failure patterns over isolated examples.
