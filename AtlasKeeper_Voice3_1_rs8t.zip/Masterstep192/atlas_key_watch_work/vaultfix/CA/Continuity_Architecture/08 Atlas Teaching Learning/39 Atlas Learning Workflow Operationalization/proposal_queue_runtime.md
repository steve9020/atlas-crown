# Proposal Queue Runtime

## Purpose
The proposal queue holds possible backend learning before approval.

## Statuses
- pending_review
- approved_by_gate
- merged
- deferred
- rejected
- integrated
- held
- cancelled

## Runtime Rule
Pending proposals are visible for review but not active backend understanding.

## Governance Rule
A proposal must remain inactive until the approval gate resolves it.
