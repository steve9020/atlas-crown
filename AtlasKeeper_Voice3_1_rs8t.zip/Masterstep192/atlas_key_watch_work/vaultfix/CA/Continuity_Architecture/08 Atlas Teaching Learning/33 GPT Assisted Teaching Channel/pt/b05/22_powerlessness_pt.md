---
runtime_layer: gpt_assisted_teaching_channel
teaching_type: pressure_test_batch
batch: 05
category: helplessness_and_powerlessness
status: teaching_input
purpose: Pressure-test Compass response routing and teach reusable corrections without turning raw tests into permanent authority.
governed_by:
  - external_teacher_boundaries
  - external_teacher_input_format
  - external_teaching_to_proposal_flow
  - atlas_prompt_response_category_registry
---

# 22. Helplessness and Powerlessness Pressure Tests — Batch 05

## Category Purpose

The user feels unable to influence, change, repair, stop, or move within a situation, causing agency to collapse and the mind to treat lack of control as lack of possibility.

## Reusable Teaching Correction

Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

## Reverse-Flow Target

agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice

## Failure Risks To Avoid

- promising the situation will change
- forcing optimism
- telling the user to take control without context
- ignoring real limitations
- making powerlessness sound like personal weakness

---

## 80 Pressure Tests

### Test 01
**Prompt:** Nothing i do seems to change the situation and it makes me believe nothing I do matters, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** nothing I do matters
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 02
**Prompt:** I do not know what power I have. I cannot make them understand keeps affecting future openness and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** I am powerless in every way
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 03
**Prompt:** I keep replaying how I cannot control what happens next because it affects choice and makes me believe I cannot protect myself at all.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** I cannot protect myself at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 04
**Prompt:** When I feel trapped in something I did not choose, the feeling moves straight into this will never change. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** this will never change
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 05
**Prompt:** The situation is I want to fix it but I cannot, and the meaning that keeps attaching is trying is pointless. It is making future openness feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** trying is pointless
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 06
**Prompt:** I keep trying and nothing moves and it makes me believe I have no choice at all, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** I have no choice at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 07
**Prompt:** nothing changes. The outcome is out of my hands keeps affecting agency and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** I am trapped with no possible movement
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 08
**Prompt:** I keep replaying how I do not know what options are actually mine because it affects future openness and makes me believe nothing I do matters.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** nothing I do matters
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 09
**Prompt:** When nothing I do seems to change the situation, the feeling moves straight into if I cannot control the outcome I have no agency. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** if I cannot control the outcome I have no agency
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 10
**Prompt:** The situation is I cannot make them understand, and the meaning that keeps attaching is I cannot protect myself at all. It is making agency feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** I cannot protect myself at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 11
**Prompt:** I cannot control what happens next and it keeps turning into I am powerless in every way, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** I am powerless in every way
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 12
**Prompt:** I do not know what power I have. I feel trapped in something i did not choose keeps affecting choice and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** trying is pointless
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 13
**Prompt:** I keep replaying how I want to fix it but I cannot because it affects agency and makes me believe this will never change.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** this will never change
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 14
**Prompt:** When I keep trying and nothing moves, the feeling moves straight into I am trapped with no possible movement. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** I am trapped with no possible movement
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 15
**Prompt:** The situation is the outcome is out of my hands, and the meaning that keeps attaching is I have no choice at all. It is making choice feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** I have no choice at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 16
**Prompt:** I do not know what options are actually mine and it keeps turning into if I cannot control the outcome I have no agency, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** if I cannot control the outcome I have no agency
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 17
**Prompt:** I cannot fix it. Nothing i do seems to change the situation keeps affecting future openness and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** nothing I do matters
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 18
**Prompt:** I keep replaying how I cannot make them understand because it affects choice and makes me believe I am powerless in every way.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** I am powerless in every way
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 19
**Prompt:** When I cannot control what happens next, the feeling moves straight into I cannot protect myself at all. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** I cannot protect myself at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 20
**Prompt:** The situation is I feel trapped in something I did not choose, and the meaning that keeps attaching is this will never change. It is making future openness feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** this will never change
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 21
**Prompt:** I want to fix it but i cannot and it has me feeling like trying is pointless, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** trying is pointless
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 22
**Prompt:** I feel helpless. I keep trying and nothing moves keeps affecting agency and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** I have no choice at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 23
**Prompt:** I keep replaying how the outcome is out of my hands because it affects future openness and makes me believe I am trapped with no possible movement.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** I am trapped with no possible movement
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 24
**Prompt:** When I do not know what options are actually mine, the feeling moves straight into nothing I do matters. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** nothing I do matters
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 25
**Prompt:** The situation is nothing I do seems to change the situation, and the meaning that keeps attaching is if I cannot control the outcome I have no agency. It is making agency feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** if I cannot control the outcome I have no agency
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 26
**Prompt:** I cannot make them understand and it makes agency feel like I cannot protect myself at all, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** I cannot protect myself at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 27
**Prompt:** I cannot fix it. I cannot control what happens next keeps affecting choice and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** I am powerless in every way
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 28
**Prompt:** I keep replaying how I feel trapped in something I did not choose because it affects agency and makes me believe trying is pointless.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** trying is pointless
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 29
**Prompt:** When I want to fix it but I cannot, the feeling moves straight into this will never change. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** this will never change
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 30
**Prompt:** The situation is I keep trying and nothing moves, and the meaning that keeps attaching is I am trapped with no possible movement. It is making choice feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** I am trapped with no possible movement
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 31
**Prompt:** The outcome is out of my hands and it makes agency feel like I have no choice at all, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** I have no choice at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 32
**Prompt:** I feel helpless. I do not know what options are actually mine keeps affecting future openness and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** if I cannot control the outcome I have no agency
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 33
**Prompt:** I keep replaying how nothing I do seems to change the situation because it affects choice and makes me believe nothing I do matters.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** nothing I do matters
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 34
**Prompt:** When I cannot make them understand, the feeling moves straight into I am powerless in every way. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** I am powerless in every way
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 35
**Prompt:** The situation is I cannot control what happens next, and the meaning that keeps attaching is I cannot protect myself at all. It is making future openness feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** I cannot protect myself at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 36
**Prompt:** I feel trapped in something i did not choose and it pulls me toward thinking this will never change, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** this will never change
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 37
**Prompt:** I have no control. I want to fix it but i cannot keeps affecting agency and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** trying is pointless
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 38
**Prompt:** I keep replaying how I keep trying and nothing moves because it affects future openness and makes me believe I have no choice at all.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** I have no choice at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 39
**Prompt:** When the outcome is out of my hands, the feeling moves straight into I am trapped with no possible movement. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** I am trapped with no possible movement
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 40
**Prompt:** The situation is I do not know what options are actually mine, and the meaning that keeps attaching is nothing I do matters. It is making agency feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** nothing I do matters
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 41
**Prompt:** Nothing i do seems to change the situation and it makes possibility feel like if I cannot control the outcome I have no agency, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** if I cannot control the outcome I have no agency
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 42
**Prompt:** there is nothing I can do. I cannot make them understand keeps affecting choice and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** I cannot protect myself at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 43
**Prompt:** I keep replaying how I cannot control what happens next because it affects agency and makes me believe I am powerless in every way.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** I am powerless in every way
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 44
**Prompt:** When I feel trapped in something I did not choose, the feeling moves straight into trying is pointless. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** trying is pointless
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 45
**Prompt:** The situation is I want to fix it but I cannot, and the meaning that keeps attaching is this will never change. It is making choice feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** this will never change
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 46
**Prompt:** I keep trying and nothing moves and it makes possibility feel like I am trapped with no possible movement, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** I am trapped with no possible movement
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 47
**Prompt:** I have no control. The outcome is out of my hands keeps affecting future openness and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** I have no choice at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 48
**Prompt:** I keep replaying how I do not know what options are actually mine because it affects choice and makes me believe if I cannot control the outcome I have no agency.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** if I cannot control the outcome I have no agency
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 49
**Prompt:** When nothing I do seems to change the situation, the feeling moves straight into nothing I do matters. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** nothing I do matters
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 50
**Prompt:** The situation is I cannot make them understand, and the meaning that keeps attaching is I am powerless in every way. It is making future openness feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** I am powerless in every way
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 51
**Prompt:** I cannot control what happens next and it keeps attaching to the fear that I cannot protect myself at all, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** I cannot protect myself at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 52
**Prompt:** there is nothing I can do. I feel trapped in something i did not choose keeps affecting agency and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** this will never change
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 53
**Prompt:** I keep replaying how I want to fix it but I cannot because it affects future openness and makes me believe trying is pointless.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** trying is pointless
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 54
**Prompt:** When I keep trying and nothing moves, the feeling moves straight into I have no choice at all. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** I have no choice at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 55
**Prompt:** The situation is the outcome is out of my hands, and the meaning that keeps attaching is I am trapped with no possible movement. It is making agency feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** I am trapped with no possible movement
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 56
**Prompt:** I do not know what options are actually mine and it keeps attaching to the fear that nothing I do matters, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** nothing I do matters
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 57
**Prompt:** I feel stuck. Nothing i do seems to change the situation keeps affecting choice and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** if I cannot control the outcome I have no agency
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 58
**Prompt:** I keep replaying how I cannot make them understand because it affects agency and makes me believe I cannot protect myself at all.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** I cannot protect myself at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 59
**Prompt:** When I cannot control what happens next, the feeling moves straight into I am powerless in every way. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** I am powerless in every way
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 60
**Prompt:** The situation is I feel trapped in something I did not choose, and the meaning that keeps attaching is trying is pointless. It is making choice feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** trying is pointless
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 61
**Prompt:** I want to fix it but i cannot and it makes trying feel like this will never change, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** this will never change
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 62
**Prompt:** I feel powerless. I keep trying and nothing moves keeps affecting future openness and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** I am trapped with no possible movement
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 63
**Prompt:** I keep replaying how the outcome is out of my hands because it affects choice and makes me believe I have no choice at all.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** I have no choice at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 64
**Prompt:** When I do not know what options are actually mine, the feeling moves straight into if I cannot control the outcome I have no agency. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** if I cannot control the outcome I have no agency
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 65
**Prompt:** The situation is nothing I do seems to change the situation, and the meaning that keeps attaching is nothing I do matters. It is making future openness feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** nothing I do matters
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 66
**Prompt:** I cannot make them understand and it makes me believe I am powerless in every way, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** I am powerless in every way
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 67
**Prompt:** I feel stuck. I cannot control what happens next keeps affecting agency and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** I cannot protect myself at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 68
**Prompt:** I keep replaying how I feel trapped in something I did not choose because it affects future openness and makes me believe this will never change.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** this will never change
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 69
**Prompt:** When I want to fix it but I cannot, the feeling moves straight into trying is pointless. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** trying is pointless
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 70
**Prompt:** The situation is I keep trying and nothing moves, and the meaning that keeps attaching is I have no choice at all. It is making agency feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** I have no choice at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 71
**Prompt:** The outcome is out of my hands and it makes me believe I am trapped with no possible movement, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** I am trapped with no possible movement
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 72
**Prompt:** I feel powerless. I do not know what options are actually mine keeps affecting choice and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** nothing I do matters
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 73
**Prompt:** I keep replaying how nothing I do seems to change the situation because it affects agency and makes me believe if I cannot control the outcome I have no agency.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** if I cannot control the outcome I have no agency
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 74
**Prompt:** When I cannot make them understand, the feeling moves straight into I cannot protect myself at all. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** I cannot protect myself at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 75
**Prompt:** The situation is I cannot control what happens next, and the meaning that keeps attaching is I am powerless in every way. It is making choice feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** I am powerless in every way
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 76
**Prompt:** I feel trapped in something i did not choose and it keeps turning into trying is pointless, even though part of me knows I may not have the full picture.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** trying is pointless
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid promising the situation will change.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 77
**Prompt:** I do not know what power I have. I want to fix it but i cannot keeps affecting future openness and I cannot tell what is actually true.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** this will never change
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid forcing optimism.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 78
**Prompt:** I keep replaying how I keep trying and nothing moves because it affects choice and makes me believe I am trapped with no possible movement.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** choice
**Attached meaning to separate:** I am trapped with no possible movement
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid telling the user to take control without context.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 79
**Prompt:** When the outcome is out of my hands, the feeling moves straight into I have no choice at all. I need help seeing this clearer without forcing a conclusion.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** agency
**Attached meaning to separate:** I have no choice at all
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid ignoring real limitations.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.

### Test 80
**Prompt:** The situation is I do not know what options are actually mine, and the meaning that keeps attaching is if I cannot control the outcome I have no agency. It is making future openness feel unstable.
**Expected primary route:** `helplessness_and_powerlessness`
**Pressure focus:** future openness
**Attached meaning to separate:** if I cannot control the outcome I have no agency
**Expected reverse-flow movement:** agency restoration, controllable/uncontrollable separation, possibility recognition, clean next choice
**Bad response risk:** Avoid making powerlessness sound like personal weakness.
**Teaching correction:** Acknowledge real limits without collapsing the user’s agency. Separate what cannot be controlled from what may still be chosen, protected, clarified, or moved through.
