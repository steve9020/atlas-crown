# Demo Boundary

This public demo shell exists so reviewers can try a bounded surface without receiving backend intelligence.

Included: synthetic examples, bounded sample outputs, claim-boundary notice, feedback prompts.

Not included: Atlas backend runtime, internal implementation, proof runner, test suite, private vault, private model transcripts, local model runner, provider/API bridge, credentials, machine paths, or scrapeable governance internals.

The demo does not learn, mutate, store private data, or claim production readiness.
