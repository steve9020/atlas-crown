---
runtime_layer: response_weakness_detection
priority: high
owned_by: atlas_teaching_learning
feeds_into:
  - teaching_gap_detection_runtime_overview
---

# Route Mismatch Detection Registry

## Purpose
Detects when the selected Compass route does not explain the most specific signals in the prompt.

## Detection questions
- Did the response restore self-worth when the prompt first needed clarification?
- Did the response treat a task as practical when the prompt carried identity fusion or collapse pressure?
- Did the response treat relational silence as rejection without clarifying uncertainty?
- Did the response choose a broad emotional route while ignoring a more precise scenario route?
- Did the response respond to a surface context instead of the core mechanism?

## Rule
A route is weak when another candidate route explains more prompt details with less assumption.
