---
runtime_layer: response_weakness_detection
priority: high
owned_by: atlas_teaching_learning
feeds_into:
  - teaching_gap_detection_runtime_overview
---

# Callout Card Weakness Registry

## Purpose
Detects when Compass selects the wrong callout card for the active route.

## Card weakness patterns
- What Needs to Separate was needed, but Compass used a generic steadier view.
- What Needs to Stay Clear was needed, but Compass summarized instead of protecting truth, intent, or proof boundaries.
- What Needs to Be Clarified was needed, but Compass restored value before naming missing information.
- The card repeated the response body instead of naming the exact separation, clarity, or clarification.

## Rule
The card must be specific to what is being called out.

## Card ownership
- What Needs to Separate: emotional attachments or fused meanings.
- What Needs to Stay Clear: intent, truth, proof boundaries, and what is not proven.
- What Needs to Be Clarified: missing context, uncertainty, and what needs more understanding before becoming a conclusion.
