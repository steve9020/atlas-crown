const assert = require('assert');
const { applyNaturalResponseStructure, detectTemplateMarkers, hasInternalMovement } = require('../Cognition/response/NaturalResponseStructureVariation.js');
const { detectMachineryTerms } = require('../Cognition/response/MachineryLeakagePrevention.js');
const { detectFrontendCertainty } = require('../Cognition/response/ConfidenceTranslation.js');
const { runPipeline } = require('../runtime/pipeline/ResponsePipeline.js');

console.log('MASTER STEP 5C NATURAL RESPONSE STRUCTURE VARIATION TEST');
console.log('========================================================');

const templated = 'See: When silence lands after something important, the pressure can feel heavy.\n\nSeparate: That feeling does not have to become final proof of what they meant.\n\nRestore: You can move through it from a steadier place before deciding what needs to be clarified.';
const natural = applyNaturalResponseStructure(templated);
assert.strictEqual(natural.natural_response_structure_variation.fixed_visible_template_detected, true, 'Visible template markers should be detected.');
assert.strictEqual(natural.natural_response_structure_variation.fixed_visible_template_allowed, false, 'Fixed visible templates must not be allowed.');
assert.strictEqual(natural.natural_response_structure_variation.template_markers_remaining.length, 0, 'Template markers should be removed.');
assert.strictEqual(natural.natural_response_structure_variation.internal_movement_preserved, true, 'Internal movement should remain preserved.');
assert.strictEqual(natural.natural_response_structure_variation.natural_variation_passed, true, 'Natural response structure should pass.');
assert.strictEqual(detectTemplateMarkers(natural.output).length, 0, 'Output should not expose see/separate/restore labels.');
console.log('visible template softening while preserving movement: PASSED');

const alreadyHuman = 'When so much starts feeling tied to one moment, it can become hard to see it clearly. That pressure is real, but it does not have to become the full measure of you. You can come back to what is true without letting this become the whole story.';
const preserved = applyNaturalResponseStructure(alreadyHuman);
assert.strictEqual(preserved.output, alreadyHuman, 'Already natural human-facing language should remain unchanged.');
assert.strictEqual(preserved.natural_response_structure_variation.fixed_visible_template_detected, false, 'Natural language should not be treated as template leakage.');
assert.strictEqual(preserved.natural_response_structure_variation.internal_movement_preserved, true, 'Natural language should still preserve internal restorative movement.');
console.log('natural language false-positive sweep: PASSED');

assert.strictEqual(hasInternalMovement('That hurt. It still does not prove your value is gone. You can move through it with more steadiness.'), true, 'Compact wording can still preserve movement.');
console.log('fluid structure with compact wording: PASSED');

const pipeline = runPipeline('I feel like I ruined the conversation and that proves I am the problem.');
assert.strictEqual(pipeline.status, 'pipeline active', 'Pipeline should remain active.');
assert(pipeline.natural_response_structure_variation, 'Pipeline must expose natural_response_structure_variation proof object.');
assert.strictEqual(pipeline.natural_response_structure_variation.fixed_visible_template_allowed, false, 'Pipeline must not allow fixed visible templates.');
assert.strictEqual(pipeline.natural_response_structure_variation.natural_variation_passed, true, 'Pipeline natural structure variation must pass.');
assert.strictEqual(detectTemplateMarkers(pipeline.output).length, 0, 'Pipeline output must not expose structural labels.');
assert.strictEqual(detectMachineryTerms(pipeline.output).length, 0, '5A machinery leakage prevention must remain active.');
assert.strictEqual(detectFrontendCertainty(pipeline.output).length, 0, '5B certainty translation must remain active.');
assert.strictEqual(pipeline.quality.passed, true, 'Output quality should remain passed after 5C.');
assert.strictEqual(pipeline.governance.blocked, false, 'Governance should not block clean human-facing output.');
console.log('pipeline integration with 5A/5B regression: PASSED');

console.log('Master Step 5C natural response structure variation: PASSED');
