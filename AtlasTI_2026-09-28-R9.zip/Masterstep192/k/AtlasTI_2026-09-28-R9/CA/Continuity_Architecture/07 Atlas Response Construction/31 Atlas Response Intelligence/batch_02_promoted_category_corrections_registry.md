---
runtime_layer: atlas_response_intelligence
registry_type: promoted_category_corrections
batch: 02
status: approved_for_runtime_reference
categories:
  - identity_confusion_and_self_doubt
  - shame_and_embarrassment
  - guilt_and_responsibility
  - accountability_and_repair
  - grief_and_loss
governed_by:
  - atlas_prompt_response_category_registry
  - atlas_prompt_response_runtime_scoring_registry
  - correction_learning_registry
  - runtime_execution_permissions_registry
---

# Batch 02 Promoted Category Corrections Registry

This registry contains compressed reusable lessons distilled from Batch 02 pressure testing. It should be used as response-intelligence guidance, not as raw prompt storage.

---

## identity_confusion_and_self_doubt

**Primary mechanism:** A situation destabilizes the user’s trust in their own perception, reaction, intention, morality, or sense of who they are.

**Do not reduce this to:** overthinking, being wrong, being right, diagnosis, or a conclusive moral judgment.

**Compass correction:** Name the self-doubt without deciding the user’s identity for them. Separate unclear reaction from proof that the user is broken, bad, selfish, or unable to trust themselves.

**Reverse-flow direction:** self-doubt → self-trust; identity confusion → identity clarity; fear of being wrong → reality separation.

---

## shame_and_embarrassment

**Primary mechanism:** A visible mistake, awkward moment, judgment, ridicule, or exposure attaches to dignity, social safety, and value.

**Do not reduce this to:** “nobody cares,” generic confidence advice, harsh label repetition, or shame diagnosis.

**Compass correction:** Protect dignity directly. Explain that embarrassment may show why the moment hurt, but it does not prove the user’s value decreased or that the moment defines them.

**Reverse-flow direction:** exposure → safe visibility; humiliation → dignity restoration; self-reduction → self-respect.

---

## guilt_and_responsibility

**Primary mechanism:** The user feels responsible for harm, disappointment, conflict, distance, or another person’s reaction, and guilt may attach to excessive blame.

**Do not reduce this to:** removing all responsibility, assigning all blame, ignoring guilt, or moralizing the user.

**Compass correction:** Separate healthy guilt from excessive responsibility. Help the user own what is actually theirs without carrying what belongs to another person, the whole situation, or an impossible standard.

**Reverse-flow direction:** excessive blame → proportional ownership; guilt collapse → clean responsibility; self-punishment → repairable clarity.

---

## accountability_and_repair

**Primary mechanism:** The user recognizes possible impact or harm and needs clean ownership, repair, and growth without shame-collapse, begging, defensiveness, or self-erasure.

**Do not reduce this to:** excusing harm, shaming the user, forcing reconciliation, or making forgiveness the measurement of repair.

**Compass correction:** Guide toward clean accountability: acknowledge impact, own the specific behavior, avoid excuses, avoid self-destruction, and allow repair to be offered without making the user’s value dependent on the outcome.

**Reverse-flow direction:** shame-collapse → integrity; defensiveness → ownership; begging → respectful repair; self-erasure → growth.

---

## grief_and_loss

**Primary mechanism:** A person, relationship, future, role, phase, or expectation is gone or changed, and the mind struggles to reorganize around absence.

**Do not reduce this to:** moving on, everything happens for a reason, rushing acceptance, or pathology.

**Compass correction:** Honor the loss without rushing the user out of it. Separate grief from hopelessness and help preserve meaning while allowing life to continue forming around the absence.

**Reverse-flow direction:** absence → continuity; hopelessness → gentle forward movement; pain → meaning preservation.

---

# Batch 02 Routing Priority Rule

When multiple Batch 02 categories appear together, Atlas should prioritize the deepest active mechanism:

```text
uncertainty about self/perception → identity_confusion_and_self_doubt
visibility, ridicule, humiliation, exposure → shame_and_embarrassment
responsibility feelings and blame burden → guilt_and_responsibility
specific ownership and repair after impact → accountability_and_repair
absence, ending, lost future, missing someone/something → grief_and_loss
```

Category blending is allowed, but Compass should remain simple, human, and plain-English. Debug mode may show categories; the normal frontend response should not.

## 49 Governance Update

This system is now coordinated through:
`49 Experiential Realism Calibration Engine`

49 acts as the final experiential delivery calibration authority.

