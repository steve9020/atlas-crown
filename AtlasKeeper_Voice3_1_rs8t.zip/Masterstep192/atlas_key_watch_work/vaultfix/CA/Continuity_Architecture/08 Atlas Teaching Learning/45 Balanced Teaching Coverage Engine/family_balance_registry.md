# Family Balance Registry

## Purpose
Tracks balance across broader scenario families.

## Families
- vulnerability / relational exposure
- care / trust / reassurance
- self-worth / identity
- recursive pressure
- anger / guilt / repair
- comparison / jealousy / resentment
- grief / hope / numbness
- mixed emotional states
- boundary / respect
- positive emotion with vulnerability
- user type / prompt shape
- scope / safety
- continuity / journal / goals
- practical low-depth

## Rule
No family should dominate auto teaching for too long.
