# Retest Controls Runtime

## Purpose
Separates retest setup from immediate execution.

## Controls
- View Retest Path = show expected route/card/behavior and test prompt.
- Queue Retest = add to retest queue.
- Run Retest Now = immediately run the retest when a draft/integration/correction is ready, compare expected versus actual, mark pass/fail, and update metrics.

## Metrics affected
- Understanding %
- Card Accuracy %
- Mistake Recovery %
- Retest Focus
- Repeated Weakness Reduction %
