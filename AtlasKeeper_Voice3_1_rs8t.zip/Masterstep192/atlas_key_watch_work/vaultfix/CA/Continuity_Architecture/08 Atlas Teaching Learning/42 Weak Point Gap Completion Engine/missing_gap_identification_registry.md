# Missing Gap Identification Registry

## Purpose
Defines how Atlas identifies what understanding was absent.

## Missing Gap Questions
- Did Atlas misunderstand what emotionally happened?
- Did Atlas miss the attached meaning?
- Did Atlas misunderstand the human act?
- Did Atlas miss the relational expectation?
- Did Atlas fail to separate feeling from conclusion?
- Did Atlas use the wrong depth?
- Did Atlas use the wrong tone?
- Did Atlas miss boundary or respect logic?
- Did Atlas overreach or underinterpret?

## Rule
A missing gap must be specific enough to become a backend correction.
