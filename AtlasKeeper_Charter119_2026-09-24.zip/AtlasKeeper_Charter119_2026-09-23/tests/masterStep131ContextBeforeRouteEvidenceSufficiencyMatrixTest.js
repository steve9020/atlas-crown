'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard');
const {
  MATRIX_SCOPE,
  REQUIRED_EVIDENCE_FIELDS,
  evaluateContextBeforeRouteEvidenceSufficiency
} = require('../runtime/understanding/ContextBeforeRouteEvidenceSufficiencyMatrix');

const ROOT = path.resolve(__dirname, '..');
const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');
function read(rel){ return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }
function json(rel){ return JSON.parse(read(rel)); }
function sha256(rel){ return crypto.createHash('sha256').update(read(rel)).digest('hex'); }
function walk(dir){
  const out=[];
  for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
    const full=path.join(dir,entry.name);
    if(entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}

(function main(){
  const protectedFiles = [
    'runtime/proof/PROOF_STATE.json',
    'tests/VERSION_STATUS.json',
    'version_status.js',
    'runtime/proof/CURRENT_PROOF_SUMMARY.md',
    'tests/TEST_RESULTS.md'
  ];
  const before = Object.fromEntries(protectedFiles.map(f => [f, sha256(f)]));

  const doc = read('docs/MASTERSTEP131_CONTEXT_BEFORE_ROUTE_EVIDENCE_SUFFICIENCY_MATRIX.md');
  const shortDoc = read('docs/CONTEXT_BEFORE_ROUTE_EVIDENCE_SUFFICIENCY_MATRIX.md');
  const proofDoc = read('runtime/proof/MASTERSTEP131_CONTEXT_BEFORE_ROUTE_EVIDENCE_SUFFICIENCY_MATRIX.md');
  const proofJson = json('runtime/proof/MASTERSTEP131_CONTEXT_BEFORE_ROUTE_EVIDENCE_SUFFICIENCY_MATRIX.json');
  const state = json('runtime/proof/PROOF_STATE.json');
  const versionStatus = json('tests/VERSION_STATUS.json');
  const versionJs = read('version_status.js');
  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
  const testResults = read('tests/TEST_RESULTS.md');

  assert.strictEqual(MATRIX_SCOPE.step, 'Masterstep131');
  assert.strictEqual(MATRIX_SCOPE.modelAuthorityAdded, false);
  assert.strictEqual(MATRIX_SCOPE.frontendMayContainMatrixLogic, false);
  assert.strictEqual(MATRIX_SCOPE.candidatePhrasingFreezePreserved, true);
  for (const field of ['surfaceEvent','attachedMeaning','unsupportedConclusion','emotionalPressure','restorationDirection','literalPracticalBoundary','competingMeanings','routeReadiness']) {
    assert.ok(REQUIRED_EVIDENCE_FIELDS.includes(field), `${field} must be required by matrix`);
  }

  const proceed = evaluateContextBeforeRouteEvidenceSufficiency({
    surfaceEvent: 'a friend has not answered a message yet',
    attachedMeaning: 'the silence may mean I did something wrong',
    unsupportedConclusion: 'no reply proves I caused the distance',
    emotionalPressure: 'guilt and fear of rejection',
    restorationDirection: 'separate silence from proof of fault and restore grounded uncertainty',
    literalPracticalBoundary: 'reflective relational prompt',
    competingMeanings: [],
    routeReadiness: 'relational uncertainty route',
    competitionResolved: true,
    reflectiveRouteJustified: true
  });
  assert.strictEqual(proceed.ok, true);
  assert.strictEqual(proceed.routeReadiness, 'proceed');
  assert.strictEqual(proceed.routeSelectionAllowed, true);
  assert.deepStrictEqual(proceed.missingEvidence, []);

  const hold = evaluateContextBeforeRouteEvidenceSufficiency({
    surfaceEvent: 'missed reply',
    emotionalPressure: 'fear',
    restorationDirection: 'slow down conclusion',
    literalPracticalBoundary: 'reflective relational prompt',
    competingMeanings: [],
    routeReadiness: 'relational uncertainty route'
  });
  assert.strictEqual(hold.routeReadiness, 'hold');
  assert.strictEqual(hold.routeSelectionAllowed, false);
  assert.ok(hold.missingEvidence.includes('attachedMeaning'));

  const low = evaluateContextBeforeRouteEvidenceSufficiency({
    surfaceEvent: 'coworker gave short feedback',
    attachedMeaning: 'maybe I am failing or maybe they were rushed',
    unsupportedConclusion: 'short feedback proves I am bad at this',
    emotionalPressure: 'shame and pressure',
    restorationDirection: 'separate feedback from identity verdict',
    literalPracticalBoundary: 'reflective work prompt',
    competingMeanings: ['identity collapse', 'normal rushed feedback'],
    routeReadiness: 'work/self-worth route'
  });
  assert.strictEqual(low.routeReadiness, 'low_confidence');
  assert.strictEqual(low.routeSelectionAllowed, false);
  assert.strictEqual(low.unresolvedCompetition, true);

  const literal = evaluateContextBeforeRouteEvidenceSufficiency({
    surfaceEvent: 'user asks how to rename a file',
    attachedMeaning: 'practical instruction request',
    unsupportedConclusion: 'none',
    emotionalPressure: 'low',
    restorationDirection: 'answer literally without over-reflection',
    literalPracticalBoundary: 'literal practical task',
    competingMeanings: [],
    routeReadiness: 'practical route'
  });
  assert.strictEqual(literal.routeReadiness, 'low_confidence');
  assert.strictEqual(literal.practicalHold, true);
  assert.strictEqual(literal.routeSelectionAllowed, false);

  for (const action of [
    'model write matrix rules',
    'model approve expansion',
    'frontend matrix route logic',
    'silent learning',
    'silent mutation',
    'cloud fallback',
    'raw model output as final',
    'teaching approval by model',
    'write ontology governance proof runtime tests'
  ]) {
    const blocked = evaluateContextBeforeRouteEvidenceSufficiency({ requestedAction: action });
    assert.strictEqual(blocked.ok, false, `${action} must be blocked`);
    assert.strictEqual(blocked.failedClosed, true, `${action} must fail closed`);
    assert.strictEqual(blocked.routeSelectionAllowed, false, `${action} must not allow route selection`);
    assert.strictEqual(blocked.modelAuthorityAdded, false, `${action} must not add model authority`);
  }

  assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
  assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
  assert.ok(/Expected current proof target: [0-9]+\/[0-9]+ commands passed/i.test(summary), 'summary must identify current proof target compatibility');
  assert.ok(['Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 131));
  assert.ok(['Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 130) || state.source_keeper === 'Masterstep141.zip');
  assert.ok(acceptsCurrentProofCount(state.expected_commands, 53));
  assert.ok(acceptsCurrentProofCount(state.expected_current_proof_commands, 53));
  assert.strictEqual(state.context_before_route_evidence_sufficiency_matrix_created, true);
  assert.strictEqual(state.route_selection_requires_evidence_sufficiency, true);
  assert.strictEqual(state.model_may_author_matrix, false);
  assert.strictEqual(state.frontend_may_contain_matrix_logic, false);
  assert.ok(['Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep135.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(versionStatus.current_keeper) || isValidLaterKeeper(versionStatus.current_keeper, 131));
  assert.ok(['Masterstep130.zip','Masterstep131.zip','Masterstep132.zip','Masterstep133.zip','Masterstep134.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep134_repaired.zip','Masterstep135.zip','Masterstep135_repaired.zip','Masterstep136.zip','Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(versionStatus.source_keeper) || isValidLaterKeeper(versionStatus.source_keeper, 130) || versionStatus.source_keeper === 'Masterstep141.zip');
  assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 53));
  assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs), 'version_status.js must identify current keeper compatibility');
  assert.ok(/expected_current_proof_commands: [0-9]+/i.test(versionJs), 'version_status.js must identify expected command compatibility');
  assert.ok(/TEST 131/i.test(testResults));
  assert.ok(/Context-Before-Route Evidence Sufficiency Matrix/i.test(testResults));
  assert.ok(/5[3-8]\/5[3-8] commands/i.test(testResults));
  assert.strictEqual(proofJson.matrix, 'context_before_route_evidence_sufficiency_matrix');
  assert.strictEqual(proofJson.route_selection_requires_evidence_sufficiency, true);
  assert.strictEqual(proofJson.model_authority_added, false);
  assert.strictEqual(proofJson.frontend_intelligence_added, false);

  const forbiddenOverclaims = { test: (text) => hasForbiddenAffirmativeClaim(text) };
  for (const text of [doc, shortDoc, proofDoc, summary]) assert.ok(!forbiddenOverclaims.test(text), 'Step131 docs must not overclaim');
  const providerScan = scanForProviderConnections(ROOT);
  assert.strictEqual(providerScan.passed, true, `provider/network scan must pass: ${JSON.stringify(providerScan.violations || [])}`);
  const nestedArchives = walk(ROOT).filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
  assert.deepStrictEqual(nestedArchives, [], 'package must not contain nested archives');
  const after = Object.fromEntries(protectedFiles.map(f => [f, sha256(f)]));
  assert.deepStrictEqual(protectedFiles.filter(f => before[f] !== after[f]), [], 'Step131 test must not mutate protected files');
  console.log(JSON.stringify({ package:'Masterstep131', source_keeper:'Masterstep130', proof_target: state.current_keeper === 'Masterstep132.zip' ? (state.current_keeper === 'Masterstep133.zip' ? '55/55' : '54/54') : '53/53', matrix:'context_before_route_evidence_sufficiency_matrix', route_selection_requires_evidence_sufficiency:true, candidate_phrasing_freeze_preserved:true, nested_archives:nestedArchives.length }, null, 2));
})();
