const assert=require('assert'); const {detectAxes}=require('../Cognition/engine/AxisEngine.js');
const cases=['The blue folder is on the table.','Marcus walked through the doorway.','She opened the window while I moved the chair.','We ate lunch and they drove home.'];
for(const text of cases){const r=detectAxes(text); assert.strictEqual(r.axes.length,0,`${text} => ${r.axes}`);}
console.log(`AXOL attribution neutral PASS ${cases.length}/${cases.length}`);
