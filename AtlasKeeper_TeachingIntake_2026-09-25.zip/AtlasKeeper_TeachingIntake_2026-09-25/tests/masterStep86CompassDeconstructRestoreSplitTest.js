const assert = require('assert');
const path = require('path');
const { main } = require('../main.js');
const { runCompassCallout } = require('../runtime/backend/FrontendCalloutService.js');

const CASES = [
  {
    id: 'imagined_judgment_deconstructs_poor_path_restore_is_better_path',
    prompt: 'I keep trying to explain myself in my head like I’m already being judged.',
    requiredOutput: [/See\n/i, /Separate\n/i, /Deconstruct\n/i, /Restore\n/i, /not actually been proven|before reality/i, /not yet grounded/i, /part to be careful with|poor path starts|poorer path forms/i, /what is actually true|feared judgment|verdict that has not been proven/i],
    restoreMustInclude: [/feared judgment|possibility|verdict that has not been proven/i, /what is true|actually in front of you/i],
    restoreMustNotInclude: [/poor path starts|poorer path forms/i, /worst meaning/i, /whole truth/i, /not yet grounded/i, /whole reality/i]
  },
  {
    id: 'meaning_attachment_deconstructs_feeling_to_conclusion',
    prompt: 'I can’t tell if I’m upset because of what happened or because of what I think it means.',
    requiredOutput: [/what actually happened/i, /what is not yet grounded/i, /part to be careful with|poor path starts|poorer path forms/i, /truer meaning|final answer/i],
    restoreMustInclude: [/feeling can be honored|final answer/i, /truer meaning|stay separate/i],
    restoreMustNotInclude: [/poor path starts|poorer path forms/i, /worst meaning/i, /not yet grounded/i]
  },
  {
    id: 'productive_displacement_preserves_reachable_path_without_agency_word',
    prompt: 'I started reorganizing my files instead of doing the thing I actually needed to finish.',
    requiredOutput: [/smaller piece/i, /does not prove avoidance or failure/i, /part to be careful with is calling the smaller task failure|poor path would call the smaller task failure/i, /return to yourself/i],
    restoreMustInclude: [/doorway back/i, /return to yourself/i],
    restoreMustNotInclude: [/agency/i, /poor path/i]
  }
];

const forbiddenWholeOutput = [
  /This is carrying/i,
  /The part to separate is/i,
  /Those may be touching/i,
  /surface situation/i,
  /Something in this is asking to be sorted carefully/i,
  /\bagency\b/i
];

function section(text, name){
  const rx = new RegExp(`${name}\\n([\\s\\S]*?)(?:\\n\\n(?:See|Separate|Deconstruct|Restore)\\n|$)`, 'i');
  const match = String(text || '').match(rx);
  return match ? match[1].trim() : '';
}

const failures = [];
const results = [];

for (const c of CASES) {
  const result = main(c.prompt);
  const output = result.output || '';
  const structured = result.compass_response_candidate && result.compass_response_candidate.structured_response;
  const restore = section(output, 'Restore');
  const requiredMisses = c.requiredOutput.filter(rx => !rx.test(output)).map(String);
  const forbiddenHits = forbiddenWholeOutput.filter(rx => rx.test(output)).map(String);
  const restoreMisses = c.restoreMustInclude.filter(rx => !rx.test(restore)).map(String);
  const restoreForbiddenHits = c.restoreMustNotInclude.filter(rx => rx.test(restore)).map(String);
  const structuredOk = !!(structured && structured.see && structured.separate && structured.deconstruct && structured.restore && structured.restore_block === 'gold' && (structured.renderer === 'SEE_SEPARATE_DECONSTRUCT_RESTORE' || structured.renderer === 'ONTOLOGY_DRIVEN_SEE_SEPARATE_DECONSTRUCT_RESTORE'));
  const hasFourSections = /See\n/.test(output) && /\n\nSeparate\n/.test(output) && /\n\nDeconstruct\n/.test(output) && /\n\nRestore\n/.test(output);
  const pass = result.status === 'pipeline active' && structuredOk && hasFourSections && !requiredMisses.length && !forbiddenHits.length && !restoreMisses.length && !restoreForbiddenHits.length;
  const record = { id: c.id, pass, structuredOk, hasFourSections, requiredMisses, forbiddenHits, restoreMisses, restoreForbiddenHits, restore, output };
  results.push(record);
  if (!pass) failures.push(record);
}

const callout = runCompassCallout(CASES[0].prompt, { packageRoot: path.resolve(__dirname, '..') });
const calloutHtmlOk = /compass-see/.test(callout.responseHtml) && /compass-separate/.test(callout.responseHtml) && /compass-deconstruct/.test(callout.responseHtml) && /compass-restore-gold/.test(callout.responseHtml);
if (!calloutHtmlOk) failures.push({ id: 'frontend_callout_deconstruct_restore_html', responseHtml: callout.responseHtml });

const summary = {
  test: 'masterStep86CompassDeconstructRestoreSplitTest',
  passed: failures.length === 0,
  verifies: [
    'Compass output now renders See / Separate / Deconstruct / Restore as four distinct lanes',
    'Deconstruct carries the route-correction explanation instead of overloading Restore',
    'Restore carries the route-specific better grounded path after deconstruction without requiring a fixed grounding opener',
    'Final Compass language avoids the word agency and keeps universal human wording',
    'Frontend shell receives backend-owned deconstruct section and Restore gold block without generating language'
  ],
  results,
  calloutHtmlOk,
  failures
};

if (!summary.passed) {
  console.error(JSON.stringify(summary, null, 2));
  process.exit(1);
}
console.log('masterStep86CompassDeconstructRestoreSplitTest PASSED');
console.log(JSON.stringify(summary, null, 2));
