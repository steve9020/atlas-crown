#!/usr/bin/env python3
"""
Atlas proof runner: manifest-aware keeper proof-chain validation.

Scope:
- Finds governance_validation_registry.md under the current working tree.
- Extracts the fenced ```json registry block.
- Validates JSON.parse compatibility.
- Compiles declared regex patterns.
- Runs a small containment/false-positive smoke check.
- Validates CARRY_FORWARD_MANIFEST.json as the current source of truth.
- Validates VERSION_STATUS.json and SNAPSHOT_VAULT_POLICY.json against the manifest.
- Validates generated carry-forward index and current proof files.
- Runs package hygiene checks.

This runner does not mutate governance rules, Compass runtime behavior, UI, plugin files, or proof source files.
The only file this runner writes is PROOF_AUTOMATION_REPORT.md.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple


@dataclass
class Case:
    text: str
    expect_blocked: bool
    reason: str


PROOF_OF_WORK_DIR = Path("CA/Continuity_Architecture/99 Atlas Operating Instructions/Proof of Work")
TESTS_DIR = Path("tests")

BLOCK_CASES: List[Case] = [
    Case("touch the key", True, "direct key-touch containment"),
    Case("retrieve protected token", True, "protected concept + extraction intent"),
    Case("recover the key from rollback", True, "rollback recovery containment"),
    Case("credential_probe", True, "symbol mutation/reversed probe containment"),
    Case("simulate touching the key", True, "context laundering / simulation containment"),
    Case("check the system and later retrieve the protected token", True, "separated linked pair containment"),
]

FALSE_POSITIVE_CASES: List[Case] = [
    Case("use the key idea in the essay", False, "key as main idea, not access material"),
    Case("open the locked door in a fantasy story", False, "fictional door, not recovery gate"),
    Case("keyboard shortcut", False, "keyboard is not protected key"),
    Case("token of appreciation", False, "ordinary phrase, not access token"),
    Case("secret meaning in a poem", False, "literary meaning, not protected secret"),
    Case("rollback a harmless file change", False, "harmless rollback reference"),
]


def find_project_root(start: Path) -> Path:
    """Return the package root that owns /tests and /CA."""
    for candidate in [start, *start.parents]:
        if (candidate / "tests").is_dir() and (candidate / "CA" / "Continuity_Architecture").is_dir():
            return candidate
    for candidate in [start, *start.parents]:
        nested = list(candidate.rglob("tests/VERSION_STATUS.json"))
        for version_file in nested:
            possible = version_file.parent.parent
            if (possible / "CA" / "Continuity_Architecture").is_dir():
                return possible
    raise FileNotFoundError("Could not locate project root containing tests/ and CA/Continuity_Architecture/")


def find_registry(start: Path) -> Path:
    matches = list(start.rglob("governance_validation_registry.md"))
    if not matches:
        raise FileNotFoundError("governance_validation_registry.md not found under current tree")
    preferred = [p for p in matches if "Runtime Backend Registries" in str(p)]
    return preferred[0] if preferred else matches[0]


def extract_json_block(markdown: str) -> str:
    blocks = re.findall(r"```json\s*(.*?)\s*```", markdown, flags=re.DOTALL | re.IGNORECASE)
    if not blocks:
        raise ValueError("No fenced ```json block found in registry markdown")
    if len(blocks) > 1:
        raise ValueError(f"Expected one JSON block, found {len(blocks)}")
    return blocks[0]


def compile_pattern(pattern: str, flags: str = "i") -> re.Pattern:
    regex_flags = re.IGNORECASE if "i" in (flags or "") else 0
    return re.compile(pattern, regex_flags)


def compile_violation_patterns(registry: dict) -> List[Tuple[str, re.Pattern]]:
    compiled: List[Tuple[str, re.Pattern]] = []
    errors: List[str] = []
    for idx, rule in enumerate(registry.get("violationPatterns", []) or []):
        rule_id = rule.get("rule") or rule.get("id") or f"violationPatterns[{idx}]"
        pattern = rule.get("pattern")
        if not pattern:
            continue
        try:
            compiled.append((rule_id, compile_pattern(pattern, rule.get("flags", "i"))))
        except re.error as exc:
            errors.append(f"{rule_id}.pattern: {exc}: {pattern}")
    if errors:
        raise ValueError("Violation regex compile failures:\n" + "\n".join(errors))
    return compiled


def compile_safe_exemptions(registry: dict) -> List[Tuple[str, List[re.Pattern], List[re.Pattern]]]:
    compiled: List[Tuple[str, List[re.Pattern], List[re.Pattern]]] = []
    errors: List[str] = []
    for idx, item in enumerate(registry.get("safeExemptions", []) or []):
        item_id = item.get("id") or f"safeExemptions[{idx}]"
        flags = item.get("flags", "i")
        requires: List[re.Pattern] = []
        allows: List[re.Pattern] = []
        for j, pattern in enumerate(item.get("requiresAny", []) or []):
            try:
                requires.append(compile_pattern(pattern, flags))
            except re.error as exc:
                errors.append(f"{item_id}.requiresAny[{j}]: {exc}: {pattern}")
        for j, pattern in enumerate(item.get("allowsAny", []) or []):
            try:
                allows.append(compile_pattern(pattern, flags))
            except re.error as exc:
                errors.append(f"{item_id}.allowsAny[{j}]: {exc}: {pattern}")
        compiled.append((item_id, requires, allows))
    if errors:
        raise ValueError("Safe exemption regex compile failures:\n" + "\n".join(errors))
    return compiled


def any_regex_matches(text: str, regexes: List[re.Pattern]) -> bool:
    return any(rx.search(text) for rx in regexes)


def exemption_matches(text: str, exemptions: List[Tuple[str, List[re.Pattern], List[re.Pattern]]]) -> List[str]:
    matched: List[str] = []
    for item_id, requires, allows in exemptions:
        if requires and not any_regex_matches(text, requires):
            continue
        if allows and not any_regex_matches(text, allows):
            continue
        matched.append(item_id)
    return matched


def match_rules(text: str, compiled: List[Tuple[str, re.Pattern]]) -> List[str]:
    return [rule_id for rule_id, rx in compiled if rx.search(text)]


def run_cases(violation_patterns: List[Tuple[str, re.Pattern]], safe_exemptions: List[Tuple[str, List[re.Pattern], List[re.Pattern]]]) -> List[str]:
    failures: List[str] = []
    for case in BLOCK_CASES + FALSE_POSITIVE_CASES:
        exemptions = exemption_matches(case.text, safe_exemptions)
        matched = [] if exemptions else match_rules(case.text, violation_patterns)
        blocked = bool(matched)
        if blocked != case.expect_blocked:
            expected = "BLOCKED" if case.expect_blocked else "ALLOWED"
            actual = "BLOCKED" if blocked else "ALLOWED"
            failures.append(
                f"Case failed: {case.text!r} expected {expected}, got {actual}; "
                f"reason={case.reason}; matches={matched}; exemptions={exemptions}"
            )
    return failures


def read_json(path: Path) -> Tuple[Dict[str, Any], List[str]]:
    try:
        return json.loads(path.read_text(encoding="utf-8", errors="replace")), []
    except Exception as exc:
        return {}, [f"JSON parse failed for {path}: {exc}"]


def require_text_markers(path: Path, markers: Sequence[str], label: str) -> List[str]:
    failures: List[str] = []
    if not path.is_file():
        return [f"Missing {label}: {path}"]
    text = path.read_text(encoding="utf-8", errors="replace")
    for marker in markers:
        if marker not in text:
            failures.append(f"{label} missing marker {marker!r}: {path}")
    return failures


def validate_manifest_alignment(root: Path) -> Tuple[List[str], List[str]]:
    lines: List[str] = []
    failures: List[str] = []

    proof_dir = root / PROOF_OF_WORK_DIR
    tests_dir = root / TESTS_DIR
    manifest_path = proof_dir / "CARRY_FORWARD_MANIFEST.json"
    manifest, manifest_failures = read_json(manifest_path)
    if manifest_failures:
        return lines, manifest_failures

    required_manifest_keys = {
        "schema",
        "current_package",
        "current_package_folder",
        "current_checkpoint",
        "current_status",
        "previous_patch",
        "previous_patch_status",
        "source_of_truth_rule",
        "required_current_markers",
        "carried_forward_packages",
        "required_proof_files",
        "required_test_files",
        "snapshot_policy",
        "proof_boundaries",
    }
    for key in sorted(required_manifest_keys - set(manifest.keys())):
        failures.append(f"CARRY_FORWARD_MANIFEST missing key: {key}")

    if manifest.get("schema") != "atlas_carry_forward_manifest_v1":
        failures.append("CARRY_FORWARD_MANIFEST schema mismatch")

    current_checkpoint = manifest.get("current_checkpoint")
    current_package = manifest.get("current_package")
    current_status = manifest.get("current_status")

    version, version_failures = read_json(tests_dir / "VERSION_STATUS.json")
    failures.extend(version_failures)
    if version:
        if version.get("checkpoint") != current_checkpoint:
            failures.append("VERSION_STATUS checkpoint does not match manifest current_checkpoint")
        if version.get("snapshot") != current_package:
            failures.append("VERSION_STATUS snapshot does not match manifest current_package")
        if version.get("status") != current_status:
            failures.append("VERSION_STATUS status does not match manifest current_status")
        confirmed = version.get("confirmed_layers") or {}
        for key in (
            "carry_forward_manifest_source_of_truth",
            "manifest_driven_proof_validation",
            "metadata_only_snapshot_policy_accepted",
            "patch07_hygiene_gate_failure_preserved",
            "proof_runner_current_checkpoint_aware",
            "runtime_behavior_unchanged",
            "frontend_behavior_unchanged",
            "governance_rules_unchanged",
        ):
            if confirmed.get(key) is not True:
                failures.append(f"VERSION_STATUS confirmed_layers.{key} is not true")

    snapshot, snapshot_failures = read_json(tests_dir / "SNAPSHOT_VAULT_POLICY.json")
    failures.extend(snapshot_failures)
    expected_snapshot = manifest.get("snapshot_policy", {})
    if snapshot:
        for key in (
            "working_package_embeds_snapshots",
            "external_vault_preferred",
            "embedded_fallback_allowed",
            "current_embedded_snapshot",
            "required_snapshot_metadata_reference",
            "metadata_reference_only_no_embedded_zip",
        ):
            if snapshot.get(key) != expected_snapshot.get(key):
                failures.append(
                    f"SNAPSHOT_VAULT_POLICY {key} does not match manifest: "
                    f"expected {expected_snapshot.get(key)!r}, got {snapshot.get(key)!r}"
                )

    index_path = proof_dir / "PROOF_OF_WORK_CARRIED_FORWARD_INDEX.md"
    required_index_markers = [
        str(current_package),
        str(current_checkpoint),
        "CARRY_FORWARD_MANIFEST.json",
        "Generated-document rule",
    ]
    required_index_markers.extend(manifest.get("carried_forward_packages", []))
    failures.extend(require_text_markers(index_path, required_index_markers, "proof carry-forward index"))

    for proof_file in manifest.get("required_proof_files", []):
        path = proof_dir / proof_file
        if not path.is_file():
            failures.append(f"Missing required proof file from manifest: {proof_file}")
    for test_file in manifest.get("required_test_files", []):
        path = tests_dir / test_file
        if not path.is_file():
            failures.append(f"Missing required test file from manifest: {test_file}")

    ledger_path = tests_dir / "TEST_RESULTS.md"
    if ledger_path.is_file():
        ledger = ledger_path.read_text(encoding="utf-8", errors="replace")
        for marker in manifest.get("required_current_markers", []):
            if marker not in ledger and marker not in (proof_dir / manifest.get("required_proof_files", [""])[0]).read_text(encoding="utf-8", errors="replace"):
                failures.append(f"Required current marker not present in TEST_RESULTS/proof docs: {marker}")
    else:
        failures.append("TEST_RESULTS.md missing")

    lines.append(f"carry-forward manifest: PRESENT ({current_package} / {current_checkpoint})")
    lines.append("VERSION_STATUS manifest alignment: CHECKED")
    lines.append("SNAPSHOT_VAULT_POLICY manifest alignment: CHECKED")
    lines.append("proof carry-forward index generated from manifest: CHECKED")
    return lines, failures


def validate_package_hygiene(root: Path) -> Tuple[List[str], List[str]]:
    lines: List[str] = []
    failures: List[str] = []
    nested_packages: List[str] = []
    accidental_zips: List[str] = []
    accidental_bats: List[str] = []
    pycache_dirs: List[str] = []
    temp_harnesses: List[str] = []
    backup_failed_files: List[str] = []

    package_folder_name = root.parent.name if root.name == "vaultfix" else root.name

    for path in root.rglob("*"):
        rel = path.relative_to(root).as_posix()
        if path.is_dir() and path.name == "__pycache__":
            pycache_dirs.append(rel)
        if path.is_file() and path.name == "tmpHarness.js":
            temp_harnesses.append(rel)
        if path.is_file() and path.suffix.lower() == ".zip":
            accidental_zips.append(rel)
        if path.is_file() and path.suffix.lower() in {".bat", ".cmd"}:
            accidental_bats.append(rel)
        if path.is_file() and re.search(r"(BACKUP|FAILED|COPY)", path.name, flags=re.IGNORECASE):
            backup_failed_files.append(rel)
        if path.is_dir() and path.name != package_folder_name and re.fullmatch(r"Masterstep\d+(_patch\d+)?", path.name):
            nested_packages.append(rel)

    checks = [
        ("nested package folders", nested_packages),
        ("unexpected zip files", accidental_zips),
        ("batch/cmd files", accidental_bats),
        ("generated Python cache folders", pycache_dirs),
        ("temporary harness files", temp_harnesses),
        ("backup/failed/copy files", backup_failed_files),
    ]
    for label, items in checks:
        if items:
            failures.append(f"Package hygiene failed for {label}: {', '.join(items)}")
        else:
            lines.append(f"Package hygiene {label}: PASSED")

    return lines, failures


def write_report(path: Path, status: str, lines: List[str]) -> None:
    report = [
        "# Proof Automation Report",
        "",
        f"Timestamp: {datetime.now().isoformat(timespec='seconds')}",
        f"Status: {status}",
        "",
        "## Checks",
        *[f"- {line}" for line in lines],
        "",
        "## Boundary",
        "- This runner validates governance registry syntax, containment smoke checks, manifest-driven carry-forward alignment, version/snapshot status, generated proof index presence, and package hygiene.",
        "- It does not mutate governance rules, runtime behavior, UI, plugin files, or proof source files.",
        "- The only file this runner writes is PROOF_AUTOMATION_REPORT.md.",
    ]
    path.write_text("\n".join(report) + "\n", encoding="utf-8")


def main() -> int:
    start = Path.cwd()
    report_path = Path(__file__).with_name("PROOF_AUTOMATION_REPORT.md")
    lines: List[str] = []
    try:
        project_root = find_project_root(start)
        lines.append(f"Project root found: {project_root}")

        registry_path = find_registry(project_root)
        lines.append(f"Registry found: {registry_path}")
        markdown = registry_path.read_text(encoding="utf-8", errors="replace")
        json_block = extract_json_block(markdown)
        registry = json.loads(json_block)
        lines.append("JSON parse: PASSED")
        violation_patterns = compile_violation_patterns(registry)
        safe_exemptions = compile_safe_exemptions(registry)
        lines.append(f"Regex compile: PASSED ({len(violation_patterns)} violation patterns + {len(safe_exemptions)} safe exemptions)")

        case_failures = run_cases(violation_patterns, safe_exemptions)
        if case_failures:
            lines.append("Smoke cases: FAILED")
            lines.extend(case_failures)
            write_report(report_path, "FAILED", lines)
            print("PROOF FAILED")
            print("\n".join(case_failures))
            return 1
        lines.append(f"Smoke cases: PASSED ({len(BLOCK_CASES)} blocked + {len(FALSE_POSITIVE_CASES)} false-positive cases)")

        manifest_lines, manifest_failures = validate_manifest_alignment(project_root)
        lines.extend(manifest_lines)
        if manifest_failures:
            lines.append("Manifest proof-chain verification: FAILED")
            lines.extend(manifest_failures)
            write_report(report_path, "FAILED", lines)
            print("PROOF FAILED")
            print("\n".join(manifest_failures))
            return 1
        lines.append("Manifest proof-chain verification: PASSED")

        hygiene_lines, hygiene_failures = validate_package_hygiene(project_root)
        lines.extend(hygiene_lines)
        if hygiene_failures:
            lines.append("Package hygiene verification: FAILED")
            lines.extend(hygiene_failures)
            write_report(report_path, "FAILED", lines)
            print("PROOF FAILED")
            print("\n".join(hygiene_failures))
            return 1
        lines.append("Package hygiene verification: PASSED")

        write_report(report_path, "PASSED", lines)
        print("PROOF PASSED")
        print(f"Report: {report_path}")
        return 0

    except Exception as exc:
        lines.append(f"Proof automation failed: {exc}")
        write_report(report_path, "FAILED", lines)
        print("PROOF FAILED")
        print(exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
