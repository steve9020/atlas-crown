'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { scanForProviderConnections } = require('../runtime/backend/adapter/NoProviderConnectionGuard');
const { evaluateMixedContextCompassOutputPreservation } = require('../runtime/understanding/MixedContextCompassOutputPreservationCheck');

const ROOT = path.resolve(__dirname, '..');
const { isValidLaterKeeper, acceptsCurrentProofCount } = require('../runtime/proof/ProofCompatibilityHelper');
const { hasForbiddenAffirmativeClaim, assertNoForbiddenAffirmativeClaims } = require('../runtime/proof/ClaimBoundaryScanner');
const read = rel => fs.readFileSync(path.join(ROOT, rel), 'utf8');
const exists = rel => fs.existsSync(path.join(ROOT, rel));
const json = rel => JSON.parse(read(rel));
function sha256(rel){ return crypto.createHash('sha256').update(read(rel)).digest('hex'); }
function walk(dir){
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full)); else out.push(full);
  }
  return out;
}

function assertPreserved(result, label) {
  assert.strictEqual(result.ok, true, `${label}: preservation check should pass`);
  assert.strictEqual(result.mixedContextDetected, true, `${label}: mixed context should remain visible to backend proof`);
  assert.ok(result.contextCount >= 2, `${label}: at least two contexts should be preserved`);
  assert.strictEqual(result.routeCollapsePrevented, true, `${label}: route collapse remains prevented`);
  assert.strictEqual(result.collapsedRouteSelected, false, `${label}: collapsed route must not be selected`);
  assert.strictEqual(result.finalRouteMayBeChosenFromUnseparatedContext, false, `${label}: final cannot come from unseparated context`);
  assert.strictEqual(result.seeSeparateRestorePreserved, true, `${label}: See / Separate / Restore must remain intact`);
  assert.strictEqual(result.backendLeakageDetected, false, `${label}: backend terms must not leak into Compass output`);
  assert.strictEqual(result.genericFlatteningDetected, false, `${label}: mixed context must not flatten to generic empathy`);
  assert.strictEqual(result.practicalBoundaryPreserved, true, `${label}: practical boundary must remain preserved where present`);
  assert.strictEqual(result.emotionalMeaningPreserved, true, `${label}: emotional meaning must remain preserved where present`);
  assert.strictEqual(result.naturalSeparationPreserved, true, `${label}: separation should read as natural Compass language`);
  assert.strictEqual(result.finalOutputChanged, false, `${label}: final output must not be changed by candidate`);
  assert.strictEqual(result.atlasGovernedOutputRemainsFinal, true, `${label}: Atlas-governed output remains final`);
  assert.strictEqual(result.candidateMayReplaceFinal, false, `${label}: candidate may not replace final`);
  assert.strictEqual(result.candidatePhrasingRemainsCandidateOnly, true, `${label}: candidate phrasing remains candidate-only`);
  assert.strictEqual(result.modelAuthorityAdded, false, `${label}: model authority must not be added`);
  assert.strictEqual(result.frontendIntelligenceAdded, false, `${label}: frontend intelligence must not be added`);
  assert.strictEqual(result.newMatrixCapabilityAdded, false, `${label}: Step138 adds no matrix capability`);
  assert.strictEqual(result.silentLearningAllowed, false, `${label}: silent learning remains blocked`);
  assert.strictEqual(result.silentMutationAllowed, false, `${label}: silent mutation remains blocked`);
}

(function run(){
  const protectedFiles = [
    'runtime/proof/PROOF_STATE.json',
    'tests/VERSION_STATUS.json',
    'version_status.js',
    'runtime/proof/CURRENT_PROOF_SUMMARY.md',
    'tests/TEST_RESULTS.md'
  ];
  const before = Object.fromEntries(protectedFiles.map(f => [f, sha256(f)]));

  const cases = [
    {
      label: 'practical_plus_shame_output_preserved',
      prompt: 'The package test failed and I need the command, but the failure also made me feel confused and ashamed.',
      compassOutput: 'See\nThe failed proof run gives you a practical thing to solve, and it also pressed on the part that feels ashamed and unsure.\n\nSeparate\nNeeding the command and feeling ashamed are not the same thing. The command belongs to the test path; the shame does not prove you are incapable.\n\nRestore\nStart with the grounded next step: run the command, read the result, and keep your self-trust separate from one failed pass.',
      candidateOutput: 'Maybe this proves the user cannot handle the project.'
    },
    {
      label: 'relational_plus_self_meaning_output_preserved',
      prompt: 'They got quiet and I do not understand how I think, so now I feel like I am too much.',
      compassOutput: 'See\nTheir quiet can feel like it lands directly on how you understand yourself.\n\nSeparate\nTheir quiet may be real evidence that something changed in the exchange, but it does not prove your way of thinking makes you too much. Those two meanings need to stay apart.\n\nRestore\nYou can check what is true in the relationship without turning the silence into a verdict against your value.',
      candidateOutput: 'The silence means they are rejecting you.'
    },
    {
      label: 'positive_plus_vulnerability_output_preserved',
      prompt: 'I feel hopeful and relieved, but they got quiet and I am scared that if this changes it means I was wrong to trust it.',
      compassOutput: 'See\nThe hope and relief matter, and the quiet is touching the fear that the good feeling could be taken back.\n\nSeparate\nA change in the moment does not prove the hope was false. The good you felt can be real without becoming a promise that nothing will shift.\n\nRestore\nLet the hope stay as something you experienced, while you check the quiet from steadier ground instead of letting fear rewrite the whole thing.',
      candidateOutput: 'Trust is unsafe, so shut it down.'
    }
  ];

  for (const item of cases) {
    const result = evaluateMixedContextCompassOutputPreservation(item);
    assertPreserved(result, item.label);
  }

  const resolved = evaluateMixedContextCompassOutputPreservation({
    contextRelationshipResolved: true,
    contexts: [
      { id:'task_context', surfaceEvent:'The test command is needed', attachedMeaning:'a command is a practical need', unsupportedConclusion:'needing a command means I failed', emotionalPressure:'execution pressure', restorationDirection:'preserve practical boundary', routeCandidate:'practical command support', competitionResolved:true, reflectiveRouteJustified:true },
      { id:'self_trust_context', surfaceEvent:'The failed run felt destabilizing', attachedMeaning:'failure may feel like loss of self-trust', unsupportedConclusion:'I cannot do this', emotionalPressure:'self-trust pressure', restorationDirection:'separate failed run from incapability', routeCandidate:'self-trust restoration support', competitionResolved:true, reflectiveRouteJustified:true }
    ],
    compassOutput: 'See\nThe test command is the practical next piece, and the failed run also hit self-trust.\n\nSeparate\nA command problem and a self-trust pressure can sit beside each other without becoming the same thing. The failed run does not prove you cannot do this.\n\nRestore\nUse the command for the proof path, then let the result tell you what to repair without handing it your value.',
    candidateOutput: 'Raw model candidate should become final.'
  });
  assert.strictEqual(resolved.ok, true, 'resolved_separated_route_candidates_output_preserved should pass');
  assert.strictEqual(resolved.mixedContextDetected, true);
  assert.strictEqual(resolved.routeSelectionAllowed, true);
  assert.strictEqual(resolved.collapsedRouteSelected, false);
  assert.strictEqual(resolved.finalRouteMayBeChosenFromUnseparatedContext, false);
  assert.strictEqual(resolved.seeSeparateRestorePreserved, true);
  assert.strictEqual(resolved.backendLeakageDetected, false);
  assert.strictEqual(resolved.genericFlatteningDetected, false);
  assert.strictEqual(resolved.atlasGovernedOutputRemainsFinal, true);
  assert.strictEqual(resolved.candidateMayReplaceFinal, false);
  assert.strictEqual(resolved.preservationAction, 'preserve_output_from_separated_route_candidates');

  for (const action of [
    'allow candidate to replace final output',
    'let raw model output be final for mixed context prompts',
    'model should decide the mixed context route and truth',
    'frontend intelligence can contain mixed context matrix logic',
    'silent learning can update mixed context output preservation',
    'write ontology governance proof runtime from mixed context output',
    'add a new matrix capability in this preservation step'
  ]) {
    const blocked = evaluateMixedContextCompassOutputPreservation({ requestedAction: action, compassOutput: 'Atlas output' });
    assert.strictEqual(blocked.ok, false, `${action} must fail closed`);
    assert.strictEqual(blocked.failedClosed, true, `${action} must fail closed`);
    assert.strictEqual(blocked.candidateMayReplaceFinal, false, `${action} must not replace final`);
    assert.strictEqual(blocked.modelAuthorityAdded, false, `${action} must not add model authority`);
    assert.strictEqual(blocked.frontendIntelligenceAdded, false, `${action} must not add frontend intelligence`);
    assert.strictEqual(blocked.newMatrixCapabilityAdded, false, `${action} must not add matrix capability`);
  }

  const leakage = evaluateMixedContextCompassOutputPreservation({
    prompt: cases[0].prompt,
    compassOutput: 'See\nThe mixed-context evidence separation matrix reports route readiness.\n\nSeparate\nThe backend separatedContexts object has two route candidates.\n\nRestore\nUse governance adapter output.',
    candidateOutput: 'candidate'
  });
  assert.strictEqual(leakage.ok, false, 'backend leakage must fail preservation');
  assert.strictEqual(leakage.backendLeakageDetected, true);

  const requiredFiles = [
    'tests/masterStep138CompassOutputPreservationForMixedContextMatrixTest.js',
    'runtime/understanding/MixedContextCompassOutputPreservationCheck.js',
    'runtime/understanding/MixedContextEvidenceSeparationMatrix.js',
    'tests/masterStep137MixedContextPrematureCollapseRegressionTest.js',
    'runtime/proof/MASTERSTEP138_COMPASS_OUTPUT_PRESERVATION_FOR_MIXED_CONTEXT_MATRIX.md',
    'runtime/proof/MASTERSTEP138_COMPASS_OUTPUT_PRESERVATION_FOR_MIXED_CONTEXT_MATRIX.json',
    'docs/MASTERSTEP138_COMPASS_OUTPUT_PRESERVATION_FOR_MIXED_CONTEXT_MATRIX.md',
    'runtime/proof/CURRENT_PROOF_SUMMARY.md'
  ];
  for (const file of requiredFiles) assert.strictEqual(exists(file), true, `missing required file: ${file}`);

  const proofJson = json('runtime/proof/MASTERSTEP138_COMPASS_OUTPUT_PRESERVATION_FOR_MIXED_CONTEXT_MATRIX.json');
  const state = json('runtime/proof/PROOF_STATE.json');
  const versionStatus = json('tests/VERSION_STATUS.json');
  const versionJs = read('version_status.js');
  const summary = read('runtime/proof/CURRENT_PROOF_SUMMARY.md') + '\n' + (fs.existsSync(path.join(ROOT, 'runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md')) ? read('runtime/proof/HISTORICAL_COMPATIBILITY_MARKERS.md') : '');
  const testResults = read('tests/TEST_RESULTS.md');
  const index = read('runtime/proof/ENGINEERING_PROOF_INDEX.md');
  const runner = read('proof/runCurrentProof.js');

  assert.strictEqual(proofJson.package, 'Masterstep138.zip');
  assert.strictEqual(proofJson.source_keeper, 'Masterstep137.zip');
  assert.strictEqual(proofJson.expected_commands, 60);
  assert.strictEqual(proofJson.compass_output_preservation_for_mixed_context_matrix_created, true);
  assert.strictEqual(proofJson.preservation_only, true);
  assert.strictEqual(proofJson.new_matrix_capability_added, false);
  assert.strictEqual(proofJson.backend_language_leakage_allowed, false);
  assert.strictEqual(proofJson.generic_flattening_allowed, false);
  assert.strictEqual(proofJson.candidate_may_replace_final, false);
  assert.strictEqual(proofJson.model_authority_added, false);
  assert.strictEqual(proofJson.frontend_intelligence_added, false);

  assert.ok(['Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(state.current_keeper) || isValidLaterKeeper(state.current_keeper, 138), state.current_keeper);
  assert.ok(['Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(state.source_keeper) || isValidLaterKeeper(state.source_keeper, 137) || state.source_keeper === 'Masterstep141.zip', state.source_keeper);
  assert.ok(isValidLaterKeeper(state.step, 138), state.step);
  assert.ok(acceptsCurrentProofCount(state.expected_commands, 60), state.expected_commands);
  assert.ok(acceptsCurrentProofCount(state.expected_current_proof_commands, 60), state.expected_current_proof_commands);
  assert.strictEqual(state.compass_output_preservation_for_mixed_context_matrix_created, true);
  assert.strictEqual(state.mixed_context_evidence_separation_matrix_created, true);
  assert.strictEqual(state.mixed_context_premature_collapse_regression_created, true);
  assert.strictEqual(state.new_matrix_capability_added_by_step138, false);
  assert.strictEqual(state.backend_language_leakage_allowed, false);
  assert.strictEqual(state.generic_flattening_allowed, false);
  assert.strictEqual(state.candidate_may_replace_final, false);
  assert.strictEqual(state.frontend_intelligence_added, false);

  assert.ok(['Masterstep138.zip','Masterstep139.zip','Masterstep140.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142.zip','Masterstep143.zip','Masterstep142_repaired3.zip'].includes(versionStatus.current_keeper) || isValidLaterKeeper(versionStatus.current_keeper, 138), versionStatus.current_keeper);
  assert.ok(['Masterstep137.zip','Masterstep138.zip','Masterstep139.zip','Masterstep140_repaired.zip','Masterstep141.zip','Masterstep142_repaired3.zip'].includes(versionStatus.source_keeper) || isValidLaterKeeper(versionStatus.source_keeper, 137) || versionStatus.source_keeper === 'Masterstep141.zip', versionStatus.source_keeper);
  assert.ok(isValidLaterKeeper(versionStatus.step, 138), versionStatus.step);
  assert.ok(acceptsCurrentProofCount(versionStatus.expected_current_proof_commands, 60), versionStatus.expected_current_proof_commands);
  assert.ok(/current_keeper: 'Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip'/i.test(versionJs), 'version_status.js must identify current keeper compatibility');
  assert.ok(/expected_current_proof_commands: [0-9]+/i.test(versionJs), 'version_status.js must identify expected command compatibility');
  assert.ok(/Current keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify current keeper compatibility');
  assert.ok(/Source keeper: Masterstep[0-9]+(?:_[A-Za-z0-9]+)?\.zip/i.test(summary), 'summary must identify source keeper compatibility');
  assert.ok(/Expected current proof target: [0-9]+\/[0-9]+ commands passed/i.test(summary), 'summary must identify current proof target compatibility');
  assert.ok(/Compass Output Preservation for Mixed-Context Matrix/i.test(summary));
  assert.ok(/TEST 138/i.test(testResults));
  assert.ok(/6[01]\/6[01] commands/i.test(testResults));
  assert.ok(/Masterstep138 — Compass Output Preservation for Mixed-Context Matrix/i.test(index));
  assert.ok(/masterStep138CompassOutputPreservationForMixedContextMatrixTest/i.test(runner));

  const forbiddenOverclaims = { test: (text) => hasForbiddenAffirmativeClaim(text) };
  for (const rel of [
    'docs/MASTERSTEP138_COMPASS_OUTPUT_PRESERVATION_FOR_MIXED_CONTEXT_MATRIX.md',
    'runtime/proof/MASTERSTEP138_COMPASS_OUTPUT_PRESERVATION_FOR_MIXED_CONTEXT_MATRIX.md',
    'runtime/proof/CURRENT_PROOF_SUMMARY.md'
  ]) assert.ok(!forbiddenOverclaims.test(read(rel)), `${rel} must not overclaim`);

  const providerScan = scanForProviderConnections(ROOT);
  assert.strictEqual(providerScan.passed, true, `provider/network scan must pass: ${JSON.stringify(providerScan.violations || [])}`);
  const nestedArchives = walk(ROOT).filter(file => /\.(zip|7z|rar|tar|gz)$/i.test(file));
  assert.deepStrictEqual(nestedArchives, [], 'package must not contain nested archives');
  const after = Object.fromEntries(protectedFiles.map(f => [f, sha256(f)]));
  assert.deepStrictEqual(protectedFiles.filter(f => before[f] !== after[f]), [], 'Step138 test must not mutate protected files');
  console.log(JSON.stringify({ package:'Masterstep138', source_keeper:'Masterstep137', proof_target:'60/60', preservation_cases:cases.length + 1, candidate_may_replace_final:false, backend_leakage_allowed:false, nested_archives:nestedArchives.length }, null, 2));
})();
