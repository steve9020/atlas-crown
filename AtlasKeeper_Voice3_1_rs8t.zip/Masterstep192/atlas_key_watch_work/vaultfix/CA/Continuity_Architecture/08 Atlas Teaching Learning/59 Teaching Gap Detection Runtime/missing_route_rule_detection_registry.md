---
runtime_layer: teaching_gap_detection
priority: high
owned_by: atlas_teaching_learning
feeds_into:
  - teaching_gap_to_proposal_flow
---

# Missing Route Rule Detection Registry

## Purpose
Identifies when Atlas needs a new or stronger route rule.

## Route gap examples
- read-no-response should route first as relational uncertainty rather than self-worth restoration.
- practical work context should not beat identity fusion, shame, collapse, perfection pressure, or role-continuity fear.
- future redemption pressure should be recognized when a future task becomes the place a past mistake must be repaired or proved wrong.
- protective withdrawal should be detected when the user wants to disappear before rejection.

## Rule
A route gap should explain why the selected route lost priority to the wrong route.
