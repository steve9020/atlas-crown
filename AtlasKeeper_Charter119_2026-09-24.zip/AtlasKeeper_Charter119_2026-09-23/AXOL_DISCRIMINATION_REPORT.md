# AXOL Discrimination Report — Masterstep191 Candidate

## Scope
Backend-only AXOL detection/discrimination work. No frontend, Crown authority, governance authority, or commercial-package changes.

## Finding
Collision coverage alone was insufficient: Atlas could identify an axis mention but did not encode whether the evidence was asserted, negated, or epistemically uncertain. This made structurally different statements look equivalent at the axis-evidence layer.

## Repair
- Preserved the existing `axes`, `dominant_axis`, and `patterns` contract.
- Extended additive `axis_evidence` with non-authoritative evidence states: `asserted`, `negated`, `uncertain`.
- Kept state evidence local to the matched clause/evidence rather than promoting it to authority or routing truth.
- Expanded registry-owned evidence families only where discrimination probes exposed a reproducible language gap.
- Removed an over-broad interpretation cue (`to me`) that produced a false interpretation detection.

## Results
- Initial discrimination probe: 5/20 under the pre-state detector; exposed the structural-state gap.
- State-aware discrimination corpus after repair: 20/20 PASS.
- Unseen discrimination corpus first run: 5/12 PASS.
- Unseen discrimination corpus after systemic/evidence-family repair: 12/12 PASS.
- Neutral controls: 6/6 clean.
- Existing Obsidian axis registry regression: PASS.
- Canonical proof: 100/100 PASS.

## Claim boundary
These results establish closure only for the tested discrimination contract and corpora. They do not establish exhaustive natural-language understanding or universal semantic correctness.
